package com.bsc.qa.webservices.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;





/**
 * Edi835Utility class that gets fields data from 835 file to be used for 835 file validation.
 * @author Automation team
 *
 */
public class Edi835Utility {

	
	/**
	 *For getting 835 file data from 835 EDI file
	 * @param strCompleteFilePath: 835 file path
	 * @param strInputFileName: 835 file name
	 * @return
	 * @throws Exception: To capture the exception
	 */
	public SortedMap<String, SortedMap<String, String>> get835FileData(
			 String strInputFileName)
			throws Exception {
	
		
		String primaryKey;
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		SortedMap<String, String> singleRecordMap = null;
		
		
		
		// To get 835 file type
		flatFileValuesMap = new TreeMap<String, SortedMap<String, String>>();
		
	
			// For capturing all claim ids from 835 file
			List<String> rowsListClaimIds = parse835FileForClaimIDs(strInputFileName);
			// Looping through all claim ids for validation
			for (String strClaimID : rowsListClaimIds) {
			
				singleRecordMap = new TreeMap<String, String>();
				
				primaryKey = strClaimID.trim().toLowerCase();
				// For retrieving Claim Id specific data from 835 file
				List<String> rowsList = parse835File(strInputFileName, 
						primaryKey.toUpperCase());
				//To retrieve first claim id section data 
				int intSubscriber = 0;
				String line1 = "";
				
				
				System.out.println(" Claim ID used while storing flat file data: " + strClaimID.trim().toLowerCase());

				// Displaying test data mandatory values in the logger

				// Looping through all Claim IDs to retrieve required values				
				for (int i = 0; i < rowsList.size(); i++) {
					//  Storing field values to validate payer  name			
					if (rowsList.get(i).startsWith("N1*PR*")) {
//						if (intSubscriber == 0) {
							line1 = rowsList.get(i).toString().toLowerCase();
							line1 = line1.replace("~", "");
							singleRecordMap.put("payer_name",
									line1.split("\\*")[2]);
							
//							intSubscriber = intSubscriber + 1;
						}

					
					//  Storing field values to validate payer's Address Line1
					if (rowsList.get(i).startsWith("N1*PR")) {
						line1 = rowsList.get(i+1).toString().toLowerCase();
						line1 = line1.replace("~", "");
						singleRecordMap.put("payer_address1",
								line1.split("\\*")[1].replace("~", ""));
					}
					
			// Storing field values to validate payer's city,state,zip
					if (rowsList.get(i).startsWith("N1*PR*")) {
						line1 = rowsList.get(i+2).toString().toLowerCase();

						line1 = line1.replace("~", "");
						String[] payer = line1.split("\\*");
						singleRecordMap.put("payer_city", payer[1]
								.substring(0).replace("~", ""));
						singleRecordMap.put("payer_state", payer[2]
								.substring(0).replace("~", ""));
						singleRecordMap.put("payer_zip", payer[3]
								.substring(0).replace("~", ""));
					
					}
					

					
			// Storing field values to validate payee's name
					if (rowsList.get(i).startsWith("N1*PE*")) {
						line1 = rowsList.get(i).toString().toLowerCase();

						line1 = line1.replace("~", "");
						String[] payee = line1.split("\\*");
						singleRecordMap.put("payee_name", payee[2]
								.substring(0).replace("~", ""));
					
					}
					
			//  Storing field values to validate payer's Address Line1
					if (rowsList.get(i).startsWith("N1*PE")) {
						line1 = rowsList.get(i+1).toString().toLowerCase();
						line1 = line1.replace("~", "");
						singleRecordMap.put("payee_address1",
								line1.split("\\*")[1].replace("~", ""));
					}
					
					
					
			// Storing field values to validate payee's city,state,zip
					if (rowsList.get(i).startsWith("N1*PE*")) {
						line1 = rowsList.get(i+2).toString().toLowerCase();

						line1 = line1.replace("~", "");
						String[] payee = line1.split("\\*");
						singleRecordMap.put("payee_city", payee[1]
								.substring(0).replace("~", ""));
						singleRecordMap.put("payee_state", payee[2]
								.substring(0).replace("~", ""));
						singleRecordMap.put("payee_zip", payee[3]
								.substring(0).replace("~", ""));
					
					}
					
			//  Storing field values to validate  Claim total Charges
					if (rowsList.get(i).startsWith("CLP*")) {
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						singleRecordMap.put("total_claim_charges",
								line1.split("\\*")[3].replace("~", ""));
					}
					
					
			//  Storing field values to validate  Claim payment Amount
					if (rowsList.get(i).startsWith("CLP*")) {
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						singleRecordMap.put("claim_paid_amt",
								line1.split("\\*")[4].replace("~", ""));
					}
					
					
					
//			//  Storing field values to validate  Check net Amount
//						if (rowsList.get(i).startsWith("BPR*")) {
//							line1 = rowsList.get(i).toString().toLowerCase();
//							line1 = line1.replace("~", "");
//							singleRecordMap.put("payment_net_Amount",
//									line1.split("\\*")[2].replace("~", ""));
//						}
			//  Storing field values to validate  Check payment date
						if (rowsList.get(i).startsWith("BPR*")) {
							line1 = rowsList.get(i).toString().toLowerCase();
							line1 = line1.replace("~", "");
							singleRecordMap.put("check_payment_date",
									line1.split("\\*")[16].replace("~", ""));
						}	
						
			//  Storing field values to validate member first name
						if (rowsList.get(i).startsWith("NM1*QC*")) {
							line1 = rowsList.get(i).toString().toLowerCase();
							line1 = line1.replace("~", "");
							singleRecordMap.put("mem_firstname",
									line1.split("\\*")[4].replace("~", ""));
						}
					
			//  Storing field values to validate member last name
					if (rowsList.get(i).startsWith("NM1*QC*")) {
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						singleRecordMap.put("mem_lastname",
								line1.split("\\*")[3].replace("~", ""));
					}
			
					

				
				}
			
				//Storing all subscriber filed values map as a value and subscriber id as key
				flatFileValuesMap.put(primaryKey, singleRecordMap);
			}	
		
		
		// Returning SortedMap<String, SortedMap<String, String>> with 835 file values
		return flatFileValuesMap;
	}

	


/**
 * Changing 835 EDI file format when it is having one line
 * @param strFlatFileCompletePath: 835 file complete path
 * @throws Exception: To capture exception
 */
public void fileFormatChange835(String strFlatFileCompletePath) throws Exception
{	
	FileWriter fileWriter = null;
	FileReader fileReader  = null;
	BufferedReader bufferedReader = null;
	
	try{
		File inputFile = new File(strFlatFileCompletePath);
		String strLines = "";
		String line = "";
		//Checking for the file existence
		if (!inputFile.exists()) { 
			  throw new IllegalStateException("File not found: " + strFlatFileCompletePath);
		  } 
		else 
		{
			fileReader =  new FileReader(inputFile);
			bufferedReader =        new BufferedReader(fileReader);
			int intICounter = 0;
			//Reading each line from the file
			while((line = bufferedReader.readLine())!=null)
			{
				strLines = strLines + line;
				intICounter += 1;
				//Checking for single line 835 file
				if(intICounter > 1)
				{
					bufferedReader.close();
					return;
				}
			}
		
			byte [] strBytes = strLines.getBytes();
			String strAllLines = new String (strBytes,StandardCharsets.UTF_8);
			//Replacing "~" symbol with "~\r\n"
			String strFormatLines = strAllLines.replaceAll("~", "~\r\n");
			fileWriter = new FileWriter(strFlatFileCompletePath);
			//Writing the data once again into the file after changes
			fileWriter.write(strFormatLines);
		  }
		
	}
	//For capturing exception
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try{
			//Closing all opened file objects
			fileReader.close();
			fileWriter.close();
			bufferedReader.close();
		}
		catch(Exception ex)
		{
			//ex.printStackTrace();
		}
	}
}

/**
 * @param testFlatFileCompletePath: File complete path
 * @param strCINNNumber: To capture specific subscriber section
 * @param strFileName: 835 file type
 * @return: List of subscriber lines
 * @throws Exception" To capture the exception
 */
public  List<String> parse835File(String testFlatFileCompletePath,String strclaimID) throws Exception {
	
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 //For checking file existence
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
		  		
				 
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader = new BufferedReader(fileReader);
						boolean flag=false;
						// Reading each line in the file 
				        while((line = bufferedReader.readLine()) != null) {
				        	//Checking for the patient Account  Number
				        	if(line.contains(strclaimID)){
				        		 flag=true;
				        	}
			        	//Checking for the starting line for each claim section
				        	if(line.startsWith("ST")){
			        		if(flag){
				        			break;
				        		}else{
				        			//To clear the records if it is not matches to the provided patient account number
				        			rowsList.clear();
				        		}
				        	}
				        	//Adding lines to the records list
				        	rowsList.add(line);
				       		}   
				  
				  
			

  	}
	 //To close the bufferedReader object
	 if(bufferedReader!=null)
		 bufferedReader.close();

	return rowsList;
}


/**
 * To capture patient account  Numbers from 835 file
 * @param testFlatFileCompletePath: 835 File complete path
 * @param strFileName: 837 file type
 * @return: List of p Numbers
 * @throws Exception: Throwing exception
 */
public  List<String> parse835FileForClaimIDs(String strFileName) {
	
	 File inputFile = new File(strFileName);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	try {
	//Checking for the file existence
	 if (!inputFile.exists())
	 { 
		  throw new IllegalStateException("File not found: " + strFileName);
	  } else {
		  		
		  		//To capture patient Account Numbers from 837 file
				  
						FileReader fileReader =  new FileReader(strFileName);
						bufferedReader = new BufferedReader(fileReader);
						//Looping through all lined for checking CINN Number line
				        while((line = bufferedReader.readLine()) != null)
				        {
				        	if(line.startsWith("CLP*"))
				        	{
				        		//Adding patient account number to the list
				        		rowsList.add(line.split("\\*")[7]);
				        	}
				
				 

  	}
				        
	  
	 //To close the bufferReader object
	if(bufferedReader != null)
		bufferedReader.close();

	  }
	 
	}
	//To capture and print the exception
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//For returning list of CINN numbers 
	return rowsList;
}





//below method is to handle the index out of bound exception
public String  partialStringRetrieval(String strKeyName,String line,int indexValue, int intStartPos, int intEndingPos){
       
	if(!(intStartPos == 0 && intEndingPos == 0)){
		 try{
             String strValue = line.split("\\*")[indexValue].substring(intStartPos,intEndingPos).replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    return strValue;
             }
             
       }
       catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
    	   return "";
       }
	}
	else{
      
		 try{
             String strValue = line.split("\\*")[indexValue].replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    
                    return strValue;
             }
             
       }
       catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
             return "";
       }
	}
	return "";
       
}



	
}
