package com.bsc.qa.facets.tests;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.csvreader.CsvWriter;

import org.apache.commons.io.FileUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.relevantcodes.extentreports.LogStatus;



public class BscaCare1stMMTest extends BaseTest implements IHookable{
	
	private String inputFileName = null;
	
	public BscaCare1stMMTest(String inputFileName) {
		this.inputFileName = (inputFileName);
	}
	
	public static String filePath;
    public static int strCSVIterator;
    public static String csvFilePath;
    public static String strDBName;
    public static String strDBUser;
    public static String strDBPwd;
    public static String strDBServer;
    public static String strDBPort;
    public static String strCompleteFilePath;
    public static String strResult;
    public static String strResultSC;
    public static String strResultSD;
    public static String strResultEC;
    public static String strResultED;
    public static String RootLocationOfFlatFiles = "src/test/resources/Test Data";
    //public static String ResultsDestinationFolderPath = "target/Results/";
    public static String ResultsDestinationFolderPath = "test-output/BSC-reports/";
    public static String TestDataSheetLocation = "src/test/resources/BscaCare1stMMTest.xlsx";
    public static String NameOfTestDataSheet = "qa2";
    public static String csvOutputFileGen;
    public static String strStatusCode;
    public static String strError;
    public static String strStatusCodeErr;
    public static String strStatusCodeErrAc;
    public static String strStatusDesc;
    public static String strErrCode;
    public static String strErrCodeDes;
    public static String strErrCodes;
    public static String strErrCodesVal = "";
    public static String strErrCodesDes;
    public static String strErrCodesDesVal = "";
    public static String strErrCode1 = "";
    public static String strErrCodeDes1 = "";
    public static String strEmail;
    public static String strEmailVal = "";
    public static String strElecVer;
    public static String strElecVerVal = "";
    public static String strDPPO;
    public static String strDPPOVal = "";
    public static String strHICNFound;
    public static String strElecVersioninFile;
    public static String strDentalPPOinFile;
    public static String strPremiumDeductedinFile;
    public static String strPremiumDeductSSinFile;
    public static String parameter2;
    public static String strHICNforQuery;
    public static String strHICNforQuery1;
    
 
    private static String sheetName;
	private static DBUtils objDBUtility;//Mandatory declaration 
	public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
	private static Path path;
	private static Path inputDataPath;
	private static String resultsDestinationFolderPath;

	private static	Map<String,String>queryDataMap=new HashMap<String,String>();
	private static	Map<String,String>queryDataMap1=new HashMap<String,String>();
	private static	Map<String,String>queryDataMap2=new HashMap<String,String>();
	private static	Map<String,String>queryDataMap3=new HashMap<String,String>();
	private static	Map<String,String>queryDataMap4=new HashMap<String,String>();
	private static	Map<String,String>queryDataMap5=new HashMap<String,String>();
	private static	Map<String,String>queryDataMap6=new HashMap<String,String>();
	private static	List<Map<String,String>>listOfRecords=new ArrayList<Map<String,String>>();
	private static	List<Map<String,String>>listOfRecordsNew=new ArrayList<Map<String,String>>();
	private static	List<Map<String,String>>listOfRecordsNewErr=new ArrayList<Map<String,String>>();
	private static	List<Map<String,String>>listOfRecordsNewErrDes=new ArrayList<Map<String,String>>();
	private static	List<Map<String,String>>listOfRecordsEmail=new ArrayList<Map<String,String>>();
	private static	List<Map<String,String>>listOfRecordsEV=new ArrayList<Map<String,String>>();
	private static	List<Map<String,String>>listOfRecordsDPPO=new ArrayList<Map<String,String>>();
	private static String rootLocationOfInputFiles;
	private static String SUCName;
	private static int strTotalHICNCount;
	
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles","ResultsDestinationFolderPath"}) //Note parrams order	
	public void setUpTest(){    //Args order matters should match to params order
		
		 strDBName = System.getenv("FACETS_DB");
		strDBUser = System.getenv("FACETS_USER");
		strDBPwd = System.getenv("FACETS_PASSWORD"); 
		strDBServer = System.getenv("FACETS_SERVER");
		strDBPort = System.getenv("FACETS_PORT");
			 
	
		filePath=TestDataSheetLocation;
		System.out.println("TestDate Loc:"+TestDataSheetLocation);
		
		//path = Paths.get("target\\Results\\"+timestamp);
		path = Paths.get(ResultsDestinationFolderPath);
		
		//public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
		 if(!Files.exists(path))
		{
		try 
		{
			Files.createDirectories(path);
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
		}
		 
		 	 
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		sheetName=NameOfTestDataSheet;
		
		rootLocationOfInputFiles = RootLocationOfFlatFiles;
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
		//NOTE DB UTIL OBJECT CREATION! 
		 
		 objDBUtility = new DBUtils(strDBName, strDBUser, strDBPwd, strDBServer, strDBPort); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required !
			 
	}

	//************************************** TEST METHODS************************
	
	
	// Validating in bound file and FACETS database column values in SUC546265-DRX To MAM
	@Test(dataProvider = "masterDataProvider")
	private void DRXToMAMInboundFileValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	
		strCSVIterator++;
		try {
			OtherUtilities.printTestCaseDeatilsInReport(data);
			SUCName = data.get("SUC Name").toString();
			Map<String,String> sourceRowMap=new HashMap<String,String>();
			System.out.println("Path"+strCompleteFilePath);
			List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithDelimeter(inputFileName);
			String primaryKeyColumnName="APPLICANTHICN";
			String ElecVerColumnName="ElectronicVersion";
			String DentalPPOColumnName="OptionalDentistPPO";
			//String PremiumWithHoldColumnName="APPLICANTHICN";
			String PremiumDeductedColumnName="PremiumDeducted";
			String PremiumDeductSSColumnName="PremiumDeductSS";
			
			System.out.println("source Map for the given Primary Key"+sourceRowMap);
			//Added by Shanker - For Finding all HICN present in File
			
			strTotalHICNCount = rowsList.size();
			logger.log(LogStatus.PASS, " Total Count of HICN in File is '"+ strTotalHICNCount + "'");
			//ifFileExist();
			if(strCSVIterator <= 1)
			{
				ifFileExist();
			}
			ifFileExists();
			strCSVIterator++;
			for(Map<String,String> map:rowsList)
			{
				queryDataMap.clear();
				queryDataMap1.clear();
				queryDataMap2.clear();
				queryDataMap3.clear();
				queryDataMap4.clear();
				queryDataMap5.clear();
				queryDataMap6.clear();
			String strHICN = map.get(primaryKeyColumnName);
			String strElecVersion = map.get(ElecVerColumnName);
			String strDentalPPO = map.get(DentalPPOColumnName);
			//String strHICN = map.get(PremiumWithHoldColumnName);
			String strPremiumDeducted = map.get(PremiumDeductedColumnName);
			String strPremiumDeductSS = map.get(PremiumDeductSSColumnName);
			
			System.out.println("strHICN"+strHICN);
			 strHICN.trim();
				if(strHICN != null && !strHICN.isEmpty())
					{
					//logger.log(LogStatus.PASS, " HICN number is : " + strHICN);
						queryDataS(data,strHICN);
						for(String key:queryDataMap.keySet())
				        {
							strStatusCodeErr = queryDataMap.get(key);
							if(strStatusCodeErr != null)
							{
								if(strStatusCodeErr.equals("06") || strStatusCodeErr.equals("04"))
								{
									queryDataE(data,strHICN);
									queryDataED(data,strHICN);
									strError = "ErrorFound";
								}
								else
								{
									strError = "NoErrorFound";
								}
							}
							else
							{	
								strStatusCode = "Null";
								strError = "NoErrorFound";
								//System.out.println("Status code is Null");
							}
						 }
					queryDataSD(data,strHICN);
					queryDataEmail(data,strHICN);
					queryDataEV(data,strHICN);
					queryDataDPPO(data,strHICN);
				
			writeIntoCsv(strHICN,queryDataMap,queryDataMap1,queryDataMap2,strError,queryDataMap4,queryDataMap5,queryDataMap6,strElecVersion,strDentalPPO,strPremiumDeducted,strPremiumDeductSS);
						strCSVIterator++;
						parameter2 = strHICN;
					
					OtherUtilities.validate(sourceRowMap,queryDataMap,queryDataMap1,queryDataMap2,softAssertion,parameter2,strHICNforQuery,strError);
					}
				else
					{
					logger.log(LogStatus.FAIL, " HICN Field is Blank For Confirmation No in the file");
					}
			
			}
		
			//OtherUtilities.getsourceMapHICN(sourceRowMap,primaryKeyColumnName,rowsList);
			System.out.println("source Map for the given Primary Key"+sourceRowMap);
			
			
			//OtherUtilities.validate(sourceRowMap,queryDataMap,softAssertion,parameter2,strHICNforQuery);
			
			//OtherUtilities.validate1(sourceRowMap,queryDataMap,softAssertion);
			 } catch (Exception e){
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					logger.log(LogStatus.INFO," Test Case Failed due to Exception.....!!");
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
				
	}
	
	public static void ifFileExist()
	{
		csvFilePath = System.getenv("OUTPUT_FILE_PATH");
		String csvOutputFile1 = csvFilePath+"DRXToMAMValidation.csv";
        csvOutputFileGen = csvOutputFile1;
		try
        { 
			
			Files.deleteIfExists(Paths.get(csvOutputFileGen));
			
	    	//logger.log(LogStatus.PASS," CSV File Already Exists with same name. Deleting old and creating new file");
			
        } 
        catch(NoSuchFileException e) 
        { 
            System.out.println("No such file/directory exists"); 
        } 
        catch(DirectoryNotEmptyException e) 
        { 
            System.out.println("Directory is not empty."); 
        } 
        catch(IOException e) 
        { 
            System.out.println("Invalid permissions."); 
        }

	}
	
	public static void ifFileExists()
	{
		csvFilePath = System.getenv("OUTPUT_FILE_PATH");
        String csvOutputFile1 = csvFilePath+"DRXToMAMValidation.csv";
        csvOutputFileGen = csvOutputFile1;
        boolean isCSVExist = new File(csvOutputFileGen).exists();
		if(isCSVExist)
		{
			logger.log(LogStatus.PASS," CSV File Already Exists with same name");
		}

	}
	
	private static void createDir()
	{
		boolean isCSVExist = new File(csvOutputFileGen).exists();
		if(isCSVExist)
		{
			 String csvOutputFile2 = csvFilePath+"ExistingCSVFiles";
			 boolean isFolderExist = new File(csvOutputFile2).exists();
			if(isFolderExist)
			{
				System.out.println("Directory Already Exists");
			}
			else
			{
				File file = new File(csvFilePath+"ExistingCSVFiles");
				file.mkdir();
				if(file.exists())
				{
					System.out.println("Directory Created");
				}
				else
				{
					System.out.println("Directory Creation Failed");
				}
			}
			
			logger.log(LogStatus.PASS," CSV File Exists");
		}
		else
		{
			logger.log(LogStatus.FAIL," CSV file not present");
		}
	}
	
	
	public static void writeIntoCsv(String strHICN,Map<String, String> queryDataMap,Map<String, String> queryDataMap1,Map<String, String> queryDataMap2, String strError,Map<String, String> queryDataMap4,Map<String, String> queryDataMap5,Map<String, String> queryDataMap6, String strElecVersion, String strDentalPPO, String strPremiumDeducted, String strPremiumDeductSS){
		strHICNFound = strHICN;
		strElecVersioninFile = strElecVersion;
		strDentalPPOinFile = strDentalPPO;
		strPremiumDeductedinFile = strPremiumDeducted;
		strPremiumDeductSSinFile = strPremiumDeductSS;
		strResult = "";
		strResultSC = "";
		strResultSD = "";
        csvFilePath = System.getenv("OUTPUT_FILE_PATH");
        String csvOutputFile = csvFilePath+"DRXToMAMValidation.csv";
        csvOutputFileGen = csvOutputFile;
    //check if file exist
        if (strElecVersioninFile == null || strElecVersioninFile.isEmpty())
        {
        	strElecVersioninFile = "Null";
        }
        if (strDentalPPOinFile == null || strDentalPPOinFile.isEmpty())
        {
        	strDentalPPOinFile = "Null";
        }
        if (strPremiumDeductedinFile == null || strPremiumDeductedinFile.isEmpty())
        {
        	strPremiumDeductedinFile = "Null";
        }
        if (strPremiumDeductSSinFile == null || strPremiumDeductSSinFile.isEmpty())
        {
        	strPremiumDeductSSinFile = "Null";
        }
        
        for(String key:queryDataMap.keySet())
        {
        strStatusCode = queryDataMap.get(key);
	        if (strStatusCode == null || strStatusCode.isEmpty())
	        {
	        	strStatusCode = "Null";
	        }
	        else
	        {
	        	strResultSC = "PASS";
	        }
        }
        for(String key:queryDataMap1.keySet())
        {
        strStatusDesc = queryDataMap1.get(key);
	        if (strStatusDesc == null || strStatusDesc.isEmpty())
	        {
	        	strStatusDesc = "Null";
	        }
	        else
	        {
	        	strResultSD = "PASS";
	        }
        }
        
        for(String key:queryDataMap4.keySet())
        {
        	strEmail = queryDataMap4.get(key);
	        if (strEmail == null || strEmail.isEmpty())
	        {
	        	strEmailVal = "Null";
	        }
	        else
	        {
	        	strEmailVal = strEmail;
	        }
        }
        
        for(String key:queryDataMap5.keySet())
        {
        	strElecVer = queryDataMap5.get(key);
	        if (strElecVer == null || strElecVer.isEmpty())
	        {
	        	strElecVerVal = "Null";
	        }
	        else
	        {
	        	strElecVerVal  = strElecVer;
	        }
        }
        
        for(String key:queryDataMap6.keySet())
        {
        	strDPPO = queryDataMap6.get(key);
	        if (strDPPO == null || strDPPO.isEmpty())
	        {
	        	strDPPOVal = "Null";
	        }
	        else
	        {
	        	strDPPOVal  = strDPPO;
	        }
        }
       
        
        if (strError == "NoErrorFound")
    	{
        	System.out.println("Entered First If");
        	strErrCode1 = "Null";
    	}
    	else
    	{
    		System.out.println("Entered else");
    		if(listOfRecordsNewErr.size() > 1)
    		{
    			System.out.println("Else -> If");
    			strErrCode1 = strErrCodesVal;
    			System.out.println("FInal Error Code Value"+strErrCode1);
    		}
    		else
    		{
    			System.out.println("Entered Else -> Else");
    			for(String key:queryDataMap2.keySet())
                {
                strErrCode = queryDataMap2.get(key);
        	        if (strErrCode == null || strErrCode.isEmpty())
        	        {
        	        	strErrCode1 = "Null";
        	        }
        	        else
        	        {
        	        	strErrCode1 = strErrCode1 + strErrCode;
        	        }
                }
    		
    		}
    	}
        
        if (strError == "NoErrorFound")
    	{
        	System.out.println("Entered First If");
        	strErrCodeDes1 = "Null";
    	}
    	else
    	{
    		System.out.println("Entered else");
    		if(listOfRecordsNewErrDes.size() > 1)
    		{
    			System.out.println("Else -> If");
    			strErrCodeDes1 = strErrCodesDesVal;
    			System.out.println("FInal Error Code Value"+strErrCodeDes1);
    		}
    		else
    		{
    			System.out.println("Entered Else -> Else");
    			for(String key:queryDataMap3.keySet())
                {
                strErrCodeDes = queryDataMap3.get(key);
        	        if (strErrCodeDes == null || strErrCodeDes.isEmpty())
        	        {
        	        	strErrCodeDes1 = "Null";
        	        }
        	        else
        	        {
        	        	strErrCodeDes1 = strErrCodeDes1 + strErrCodeDes;
        	        }
                }
    		
    		}
    	}
       
        if( strResultSC == "PASS" && strResultSD == "PASS")
        {
        	strResult = "PASS";
        }
        else
        {
        	strResult = "FAIL";
        }
        
    boolean isFileExist = new File(csvOutputFileGen).exists();
        try {
            //create a FileWriter constructor to open a file in appending mode
            CsvWriter testcases = new CsvWriter(new FileWriter(csvOutputFile, true), ',');
            //write header column if the file did not already exist
           
            if(!isFileExist)
            {
                testcases.write("HICN_No");
                testcases.write("StatusCode");
                testcases.write("StatusDescription");
                testcases.write("ErrorCode");
                testcases.write("ErrorDescription");
                testcases.write("EmailID");
                testcases.write("Result");
               // testcases.write("ElecVersioninDB");
                //testcases.write("DentalPPOinDB");
                testcases.write("ElecVersionInFile");
                testcases.write("DentalPPOInFile");
                testcases.write("PremiumWithHold");
                testcases.write("PremiumDeducted");
                testcases.write("PremiumDeductSS");
                
                //end the record
                testcases.endRecord();
            }
         //add record to the file
            testcases.write(strHICNFound);
            testcases.write(strStatusCode);
            testcases.write(strStatusDesc);
            testcases.write(strErrCode1);
            testcases.write(strErrCodeDes1);
            testcases.write(strEmailVal);
            testcases.write(strResult);
            //testcases.write(strElecVerVal);
            //testcases.write(strDPPOVal);
            testcases.write(strElecVersioninFile);
            testcases.write(strDentalPPOinFile);
            testcases.write("TBU");
            testcases.write(strPremiumDeductedinFile);
            testcases.write(strPremiumDeductSSinFile);
            //end the record
            testcases.endRecord();
            //close the file
            testcases.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        strStatusCodeErr = "";
		strStatusCode = "";
		strStatusDesc = "";
		strErrCode1 = "";
		strErrCodeDes1 = "";
		strEmailVal = "";
		strResult = "";
		strResultSC = "";
		strResultSD = "";
		strElecVerVal = "";
		strDPPOVal = "";
		      
    }

	
 public static Map<String,String> queryDataS(Map<String, String> data, String strHICN) throws SQLException{
	 	strStatusCodeErr = "";
		strStatusCode = "";
		queryDataMap.put(null, null);
	   strHICNforQuery = strHICN;
	   String queryFromDataSheet2 = data.get("SqlQuery2").toString();
		String	SQLQuery2=queryFromDataSheet2.replace( "Parameter1",strHICNforQuery.trim());
		System.out.println("Source Query: "+SQLQuery2);
		
		listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery2);//queryDataMap
		//listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery1);//queryDataMap
		
		if(listOfRecords.size() != 0){
		queryDataMap=listOfRecords.get(0);//First element of list
		System.out.println("If S"+queryDataMap);
		}
		else{
			//logger.log(LogStatus.FAIL," Data is not loaded into FACETS...!!");
			queryDataMap.put(null, null);
			System.out.println("Else S"+queryDataMap);
			//softAssertion.assertFalse(true, "Data is not loaded into FACETS...!!");
			}
	return queryDataMap;	
 }
 
 public static Map<String,String> queryDataEmail(Map<String, String> data, String strHICN) throws SQLException{
	 	strEmail = "";
	 	strEmailVal = "";
		queryDataMap4.put(null, null);
	   strHICNforQuery = strHICN;
	   String queryFromDataSheet5 = data.get("SqlQuery6").toString();
		String	SQLQuery6=queryFromDataSheet5.replace( "Parameter1",strHICNforQuery.trim());
		System.out.println("Source Query: "+SQLQuery6);
		
		listOfRecordsEmail = objDBUtility.resultSetToDictionary(SQLQuery6);//queryDataMap
		//listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery1);//queryDataMap
		
		if(listOfRecordsEmail.size() != 0){
		queryDataMap4=listOfRecordsEmail.get(0);//First element of list
		System.out.println("If S"+queryDataMap4);
		}
		else{
			//logger.log(LogStatus.FAIL," Data is not loaded into FACETS...!!");
			queryDataMap4.put(null, null);
			System.out.println("Else S"+queryDataMap4);
			//softAssertion.assertFalse(true, "Data is not loaded into FACETS...!!");
			}
	return queryDataMap4;	
}
 
 public static Map<String,String> queryDataEV(Map<String, String> data, String strHICN) throws SQLException{
	 	strElecVer = "";
	 	strElecVerVal = "";
		queryDataMap5.put(null, null);
	   strHICNforQuery = strHICN;
	   String queryFromDataSheet6 = data.get("SqlQuery7").toString();
		String	SQLQuery7=queryFromDataSheet6.replace( "Parameter1",strHICNforQuery.trim());
		System.out.println("Source Query: "+SQLQuery7);
		
		listOfRecordsEV = objDBUtility.resultSetToDictionary(SQLQuery7);//queryDataMap
		//listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery1);//queryDataMap
		
		if(listOfRecordsEV.size() != 0){
		queryDataMap5=listOfRecordsEV.get(0);//First element of list
		System.out.println("If S"+queryDataMap5);
		}
		else{
			//logger.log(LogStatus.FAIL," Data is not loaded into FACETS...!!");
			queryDataMap5.put(null, null);
			System.out.println("Else S"+queryDataMap5);
			//softAssertion.assertFalse(true, "Data is not loaded into FACETS...!!");
			}
	return queryDataMap5;	
}
 
 public static Map<String,String> queryDataDPPO(Map<String, String> data, String strHICN) throws SQLException{
	 	strDPPO = "";
	 	strDPPOVal = "";
		queryDataMap6.put(null, null);
	   strHICNforQuery = strHICN;
	   String queryFromDataSheet7 = data.get("SqlQuery8").toString();
		String	SQLQuery8=queryFromDataSheet7.replace( "Parameter1",strHICNforQuery.trim());
		System.out.println("Source Query: "+SQLQuery8);
		
		listOfRecordsDPPO= objDBUtility.resultSetToDictionary(SQLQuery8);//queryDataMap
		//listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery1);//queryDataMap
		
		if(listOfRecordsDPPO.size() != 0){
		queryDataMap6=listOfRecordsDPPO.get(0);//First element of list
		System.out.println("If S"+queryDataMap6);
		}
		else{
			//logger.log(LogStatus.FAIL," Data is not loaded into FACETS...!!");
			queryDataMap6.put(null, null);
			System.out.println("Else S"+queryDataMap6);
			//softAssertion.assertFalse(true, "Data is not loaded into FACETS...!!");
			}
	return queryDataMap6;	
}
 
 public static Map<String,String> queryDataSD(Map<String, String> data, String strHICN) throws SQLException{
	 strStatusDesc = "";
	 strHICNforQuery1 = strHICN;
	 queryDataMap1.put(null, null);
	   String queryFromDataSheet2 = data.get("SqlQuery3").toString();
		String	SQLQuery3=queryFromDataSheet2.replace( "Parameter1",strHICNforQuery1.trim());
		System.out.println("Source Query: "+SQLQuery3);
		
		listOfRecordsNew = objDBUtility.resultSetToDictionary(SQLQuery3);//queryDataMap
		//listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery1);//queryDataMap
		if(listOfRecordsNew.size() != 0){
		queryDataMap1=listOfRecordsNew.get(0);//First element of list
		System.out.println("If SD"+queryDataMap1);
		}
		else{
			//logger.log(LogStatus.FAIL," Data is not loaded into FACETS1...!!");
			//softAssertion.assertFalse(true, "Data is not loaded into FACETS...!!");
			queryDataMap1.put(null, null);
			System.out.println("Else SD"+queryDataMap1);
			}
	return queryDataMap1;	
}
	
 public static Map<String,String> queryDataE(Map<String, String> data, String strHICN) throws SQLException{
		//String strStatusCodeErrAc = strStatusCodeErr;
	   strHICNforQuery = strHICN;
	   strErrCodesVal = "";
	   String queryFromDataSheet3 = data.get("SqlQuery4").toString();
		String	SQLQuery4=queryFromDataSheet3.replace( "Parameter1",strHICNforQuery.trim());
		//String	SQLQuery5=SQLQuery4.replace( "Parameter2",strStatusCodeErrAc.trim());
		System.out.println("Source Query: "+SQLQuery4);
		
		listOfRecordsNewErr = objDBUtility.resultSetToDictionary(SQLQuery4);//queryDataMap
		
				
		if(listOfRecordsNewErr.size() != 0 && listOfRecordsNewErr.size() < 2)
		{
			System.out.println("Entered If - LOR"+listOfRecordsNewErr.size());
			queryDataMap2=listOfRecordsNewErr.get(0);//First element of list
			System.out.println("queryDataMap2 "+queryDataMap2);
		}
		else if(listOfRecordsNewErr.size()> 1)
		{
			System.out.println("Entered ElseIf"+listOfRecordsNewErr.size());
			strErrCodes = 	listOfRecordsNewErr.toString();
			String strErrCodesRep = strErrCodes.replace("ERR_OR_WARN_MSG_ID", "");
			String strErrCodesRep1 = strErrCodesRep.replace("=", "");
			String strErrCodesRep2 = strErrCodesRep1.replace("{", "");
			String strErrCodesRep3 = strErrCodesRep2.replace("}", "");
			String strErrCodesRep4 = strErrCodesRep3.replace("[", "");
			String strErrCodesRep5 = strErrCodesRep4.replace(" ", ":");
			String[]arrOfErrCodes = strErrCodesRep5.split(",", listOfRecordsNewErr.size()+1);
			int i=0;
			for(String a:arrOfErrCodes)
			{
				if(i <= listOfRecordsNewErr.size()-1)
				{
					strErrCodesVal = strErrCodesVal + a;
					System.out.println("strErrCodesVal"+strErrCodesVal);
					i = i+1;
				}
				else
				{
					break;
				}
				
			}
		}
		
		else{
			//logger.log(LogStatus.FAIL," Data is not loaded into FACETS...!!");
			queryDataMap2.put(null, null);
			//softAssertion.assertFalse(true, "Data is not loaded into FACETS...!!");
			}
	return queryDataMap2;	
}
 
 public static Map<String,String> queryDataED(Map<String, String> data, String strHICN) throws SQLException{
		//String strStatusCodeErrAc = strStatusCodeErr;
	   strHICNforQuery = strHICN;
	   strErrCodesDesVal = "";
	   String queryFromDataSheet4 = data.get("SqlQuery5").toString();
		String	SQLQuery5=queryFromDataSheet4.replace( "Parameter1",strHICNforQuery.trim());
		//String	SQLQuery5=SQLQuery4.replace( "Parameter2",strStatusCodeErrAc.trim());
		System.out.println("Source Query: "+SQLQuery5);
		
		listOfRecordsNewErrDes = objDBUtility.resultSetToDictionary(SQLQuery5);//queryDataMap
		
		if(listOfRecordsNewErrDes.size() != 0 && listOfRecordsNewErrDes.size() < 2)
		{
			System.out.println("Entered If - LOR"+listOfRecordsNewErrDes.size());
			queryDataMap3=listOfRecordsNewErrDes.get(0);//First element of list
			System.out.println("queryDataMap3 "+queryDataMap3);
		}
		else if(listOfRecordsNewErrDes.size()> 1)
		{
			System.out.println("Entered ElseIf"+listOfRecordsNewErrDes.size());
			strErrCodesDes = 	listOfRecordsNewErrDes.toString();
			System.out.println(strErrCodesDes);
			String strErrCodesDesRep = strErrCodesDes.replace("ERR_MSG_CD_DEFN", "");
			String strErrCodesDesRep1 = strErrCodesDesRep.replace("=", ":");
			String strErrCodesDesRep2 = strErrCodesDesRep1.replace("{", "");
			String strErrCodesDesRep3 = strErrCodesDesRep2.replace("}", "");
			String strErrCodesDesRep4 = strErrCodesDesRep3.replace("[", "");
			String[]arrOfErrCodesDes = strErrCodesDesRep4.split(",", listOfRecordsNewErrDes.size()+1);
			int i=0;
			for(String a:arrOfErrCodesDes)
			{
				if(i <= listOfRecordsNewErrDes.size()-1)
				{
					strErrCodesDesVal = strErrCodesDesVal + a;
					System.out.println("strErrCodesDesVal"+strErrCodesDesVal);
					i = i+1;
				}
				else
				{
					break;
				}
				
			}
		}
		
		else{
			//logger.log(LogStatus.FAIL," Data is not loaded into FACETS...!!");
			queryDataMap3.put(null, null);
			//softAssertion.assertFalse(true, "Data is not loaded into FACETS...!!");
			}
	return queryDataMap3;	
}

 
//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider annotation
	private static Object[][] getData(Method method) throws Exception{
		
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, sheetName);
		  Object[][] testDataArray= 	  ExcelUtils.getTableArray(filePath, sheetName);
		  List<Object> list=new ArrayList<Object>();
		  
		  int noOfTestCases=0;
		 String runMode="Y";
		  for(int row=0;row<=testDataArray.length-1;row++){
			  
			if(method.getName().equalsIgnoreCase(testDataArray[row][2].toString())&& runMode.equalsIgnoreCase(testDataArray[row][3].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name From Data Sheet:::"+testDataArray[row][1].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++){
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);
				//data[row][0]=rowDataMap;
				
			}
		}
		  
		  Object[][] data = new Object[noOfTestCases][1];
		  for(int row=0;row<list.size();row++){
			  data[row][0]=list.get(row);
		  }
		//data = new Object[][] { { list.get(0) },{ list.get(1) },{ list.get(2) }  };
		//System.out.println("Balu data:"+data[2][0]);
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		ReportFactory.closeReport();
	}
	
	@AfterMethod
	/*public void afterMethod() throws IOException{
		inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		File srcDir = new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
	}*/
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
			//try {
			
			/*//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
	//-----			TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
*/			//Copying input files
			
		/*	
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}*/

	  }

	
	
	  
}

