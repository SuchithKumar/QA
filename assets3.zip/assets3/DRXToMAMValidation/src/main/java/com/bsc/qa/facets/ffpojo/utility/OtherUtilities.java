package com.bsc.qa.facets.ffpojo.utility;

import java.time.Month;
import java.io.File;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import java.lang.Object;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;



public class OtherUtilities extends BaseTest{
	
	public static void getsourceMapHICN(Map<String, String> flatFileValuesMap, String primaryKeyColumnName, List<Map<String, String>> rowsList) {

		for(Map<String,String> map:rowsList)
			{
			 String strHICN = map.get(primaryKeyColumnName);
			 strHICN.trim();
				if(strHICN != null && !strHICN.isEmpty())
					{
					logger.log(LogStatus.PASS, " HICN number is : " + strHICN);
					
					}
				else
					{
					logger.log(LogStatus.FAIL, " HICN number is not present in the file");
					}
			}
}
	

		
	// Validating in bound file and FACETS database column values
	public static void validate(Map<String, String> flatFileValuesMap,	Map<String, String> queryDataMap,Map<String, String> queryDataMap1,Map<String, String> queryDataMap2,SoftAssert softAssertion, String Parameter2, String strHICN,String strError) {
		//SoftAssert softAssertion= new SoftAssert();
		String StrValue = Parameter2 ;
		String HICNinFile = strHICN;
		
		String strMapValue = queryDataMap.get(null);
		for(String key:queryDataMap.keySet()){
			for(String key1:queryDataMap1.keySet()){
				try{
			if (key.equalsIgnoreCase("ELECTRONICQ1")) {				
				flatFileValuesMap.put("ELECTRONICQ1".toUpperCase(), flatFileValuesMap.get("ELECTRONICCOMMUNICATIONQUESTION1"));
			}if (key.equalsIgnoreCase("ELECTRONICQ2")) {				
				flatFileValuesMap.put("ELECTRONICQ2".toUpperCase(), flatFileValuesMap.get("ELECTRONICCOMMUNICATIONQUESTION2"));
			}
				}
				catch(Exception E){
					System.out.println("Status Code is Null");
				}
		
			
			//if(flatFileValuesMap.containsKey(key)){ 
				
				// Added this code based on the front end portal new requirement
				//if(key.equalsIgnoreCase("MAILINGADDRESS1") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
				//	key = "ApplicantAddress1".toUpperCase();
				//if(key.equalsIgnoreCase("MAILINGADDRESS2") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
				//	key = "ApplicantAddress2".toUpperCase();
				//if(key.equalsIgnoreCase("ApplicantAddress3") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
				//	key = "ApplicantAddress3".toUpperCase();
				//if(key.equalsIgnoreCase("MailingCity") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
				//	key = "ApplicantCity".toUpperCase();
				//if(key.equalsIgnoreCase("MailingState") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
				//	key = "ApplicantState".toUpperCase();
				//if(key.equalsIgnoreCase("MailingZip") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
				//	key = "ApplicantZip".toUpperCase();
				
				
				
				//OtherUtilities.validateActualAndExpectedValues(key,flatFileValuesMap.get(key),queryDataMap.get(key),softAssertion);
				//System.out.println(" Key Name: " + key + ", Actual Value: " + flatFileValuesMap.get(key) + ", Expected Value: " + queryDataMap.get(key));
			//}else{
			//	System.out.println( "Element" + queryDataMap.get(key) + "Value not present in Input File");
				// softAssertion.assertTrue(flatFileValuesMap.containsKey(key), "Element " + key + " is not present" );
				 //logger.log(LogStatus.INFO, key+" is not present Input File");
			//}else{
				  //softAssertion.assertTrue(flatFileValuesMap.containsKey(key), "Element " + key + " is not present" );
				  //logger.log(LogStatus.INFO, key+" of HICN: " + StrValue  + " present in DB is " + queryDataMap.get(key));
			//}	
			//OtherUtilities.statusCodeDescription(key,flatFileValuesMap.get(key),queryDataMap.get(key),StrValue,True);
			OtherUtilities.statusCodeDescription(queryDataMap.get(key),queryDataMap1.get(key1),HICNinFile);
		  			}
				}
			}

	private static void statusCodeDescription(String dbValue,String dbValue1, String HICNinFile) 
	{
		String strValueFoundinFile = HICNinFile;
			if(dbValue != null && dbValue1 != null)	
				{
				dbValue = dbValue.trim();
				dbValue1 = dbValue1.trim();
				logger.log(LogStatus.PASS,"HICN No is : '" + strValueFoundinFile + "'" + " " + "  Status code in DB is '" + dbValue + "'"+ " " + "  Status Description in DB is '" + dbValue1 + "'"); 
				}
			else if (dbValue == null && dbValue1 == null)
			{
				logger.log(LogStatus.PASS,"HICN No is : '" + strValueFoundinFile + "'     Status code & Description in DB is 'NULL'");
			}
			else if(dbValue == null && dbValue1 != null)
				{
				logger.log(LogStatus.PASS,"HICN No is : '" + strValueFoundinFile + "'     Status code in DB is 'NULL'" + " " + "  Status Description in DB is '" + dbValue1 + "'"); 
				}
			else if(dbValue != null && dbValue1 == null)
			{
				logger.log(LogStatus.PASS,"HICN No is : '" + strValueFoundinFile + "'" + " " + "  Status code in DB is '" + dbValue + "'"+ "'     Status Description in DB is 'NULL'");
			}
			else
			{
				logger.log(LogStatus.PASS,"HICN No is : '" + strValueFoundinFile + "'     Status code & Description in DB is 'NULL'");
			}
	}
	
	
	// Description of Status Code for HICN in File 
	private static void statusCodeDescription(String key,String flatFileValue,String dbValue, String StrValue,Boolean True) 
	{
		//String flatFileValue = flatFileValue;
		//String dbValue = dbValue;
		//flatFileValue = FlatFileValue.trim();	
		String strValueFound = StrValue;
			
		if(dbValue.equals(strValueFound))  
		{ 
			System.out.println(" HICN Value: " + strValueFound );
		}
	else {
			if(dbValue != null)	
				{
				dbValue = dbValue.trim();
				logger.log(LogStatus.PASS, " HICN number : '" + strValueFound + "' is present in Input File ");
				logger.log(LogStatus.PASS," Status code of HICN '" + strValueFound + "' is " + dbValue); 
				}
			else 
				{
				logger.log(LogStatus.PASS," Status code of HICN '" + strValueFound + "' is Null"); 
				}
		}

			
				
		switch (dbValue){
			//	Status Code Description from MAM Database
			
			case "00":
				logger.log(LogStatus.PASS," Status Decsription of code '" + dbValue + "' is :  'Loaded into MAM' " );
				break;
			case "06":
			case "07":
				logger.log(LogStatus.PASS," Status Decsription of code '" + dbValue + "' is :  'Pending with Error' " );
				break;
			case "20":
				logger.log(LogStatus.PASS," Status Decsription of code '" + dbValue + "' is :  'MAM Validation completed' " );
				break;
			case "30":
				logger.log(LogStatus.PASS," Status Decsription of code '" + dbValue + "' is :  'Extracted MAM to EAM Outbound' " );
				break;
			case "40":
				logger.log(LogStatus.PASS," Status Decsription of code '" + dbValue + "' is :  'EAM to MAM Sync' " );
				break;
			case "60":
				logger.log(LogStatus.PASS," Status Decsription of code '" + dbValue + "' is :  'Loaded into Facets, Facets and MAM in Sync' " );
				break;
			case "61":
				logger.log(LogStatus.PASS," Status Decsription of code '" + dbValue + "' is :  'Bank Details Loaded into MAM' " );
				break;
			case "62":
				logger.log(LogStatus.PASS," Status Decsription of code '" + dbValue + "' is :  'Commissions Loaded into MAM' " );
				break;
			case "99":
				logger.log(LogStatus.PASS," Status Decsription of code '" + dbValue + "' is :  'Application Process to MAM is Completed' " );
				break;
			case "":
				logger.log(LogStatus.PASS," DB Value is Blank/wrongly populated");
			default:
				 System.out.println(" DB Value Error" );
				break;
					}
				}

	
	
	// Validating in bound file and FACETS database column values 
	private static void validateActualAndExpectedValues(String key,String flatFileValue,String dbValue,SoftAssert softAssertion) {
		String strFlatFileDate = "";
		String strdbValue = "";
		String strflatFileValue = "";
		flatFileValue = flatFileValue.trim();		
		if(dbValue != null )	{
		dbValue = dbValue.trim();
		}
		if(dbValue == null)
			dbValue = "";
		switch (key){
			//	Validating APPLICANTBIRTHDATE field value in In bound file and FACETS Database
			case "APPLICANTBIRTHDATE":
				String strDate;
				if(flatFileValue != null && flatFileValue.length()>0){
					strDate = flatFileValue.substring(4) + "-"+flatFileValue.substring(0, 2) + "-"+ flatFileValue.substring(2, 4);
				}else{
					strDate = flatFileValue;
				}
				assertContainLogger(key, strDate, dbValue, softAssertion);
				//softAssertion.assertTrue(dbValue.contains(strDate), " << Field name: " + key + " | Flat file value: " + strDate + " | Database value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strDate+ "---------------Database Value: " + dbValue));
				break;
			//Validating OEC_InsertedWhen,SubmitDate field values in In bound file and FACETS Database
			case "OEC_INSERTEDWHEN":
			case "SUBMITDATE":
				if(dbValue != null && dbValue.length()>0){
					strdbValue = dbValue.substring(5,7) + dbValue.substring(8,10) + dbValue.substring(0,4); 
				}
				assertEqualLogger(key, flatFileValue, strdbValue, softAssertion);
				//softAssertion.assertEquals(flatFileValue,strdbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + strdbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + strdbValue));
				break;
			//Validating MedicarePartA,MedicarePartA field values in In bound file and FACETS Database
			case "MEDICAREPARTA":
			case "MEDICAREPARTB":
				if(flatFileValue != null && flatFileValue.length()>0){
					strFlatFileDate = "01-" + (Month.of(Integer.parseInt(flatFileValue.substring(0,2))).name().substring(0,3)) + "-"+ flatFileValue.substring(4);
				}
				if(dbValue != null && dbValue.length()>0){
					strdbValue = dbValue.substring(8,10) + "-" + (Month.of(Integer.parseInt(dbValue.substring(5,7))).name().substring(0,3)) + "-"+ dbValue.substring(2,4);
				}
				assertEqualLogger(key, strFlatFileDate, strdbValue, softAssertion);
				//softAssertion.assertEquals(strFlatFileDate,strdbValue, " << Field name: " + key + " | Flat file value: " + strflatFileValue + " | Database value: " + strdbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strFlatFileDate+ "---------------Database Value: " + strdbValue));
				break;
			//Validating SubmitTime field value in In bound file and FACETS Database				
			case "SUBMITTIME":
				/*if(flatFileValue != null && flatFileValue.length()>0)
				strFlatFileDate = flatFileValue.substring(0,19);
				if(dbValue != null && dbValue.length()>0)
				strdbValue = dbValue.substring(0,19) ;*/
				
				/*if(flatFileValue != null && flatFileValue.length()>0)
					
		
				softAssertion.assertEquals(strFlatFileDate,strdbValue, " << Field name: " + key + " | Flat file value: " + strFlatFileDate + " | Database value: " + strdbValue + " >>");
				logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strFlatFileDate+ "---------------Database Value: " + strdbValue));*/
				break;
			case "SUBSIDYPERCENTAGE":
				break;
			
			//Validating AgencyID field value in In bound file and FACETS Database				
			case "AGENCYID":
				if(flatFileValue != null && flatFileValue.length()>0){
					strflatFileValue = flatFileValue.replaceAll("[^a-zA-Z0-9]","");
				}
				assertEqualLogger(key, strflatFileValue, dbValue, softAssertion);
				//softAssertion.assertEquals(strflatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + strflatFileValue + " | Database value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strflatFileValue+ "---------------Database Value: " + dbValue));
				break;
			//Validating ApplicantSSN field value in In bound file and FACETS Database				
			case "APPLICANTSSN":
				if(flatFileValue != null && flatFileValue.length()>0)
				strflatFileValue = flatFileValue.replaceAll("[^a-zA-Z0-9]","");
				assertEqualLogger(key, strflatFileValue, dbValue, softAssertion);
				//softAssertion.assertEquals(strflatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + strflatFileValue + " | Database value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strflatFileValue+ "---------------Database Value: " + dbValue));
				break;
			//Validating PremiumWithhold field value in In bound file and FACETS Database	
			case "PREMIUMWITHHOLD":
				if (flatFileValue.equalsIgnoreCase(dbValue)){
					assertEqualLogger(key, flatFileValue, dbValue, softAssertion);
					//softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
					//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
				}else if (flatFileValue.equalsIgnoreCase("")){
					logger.log(LogStatus.PASS," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value:  "));
				}else{
					assertFailLogger(key, flatFileValue, dbValue, softAssertion);
					//softAssertion.assertTrue(false, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");			
					//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
				}
				break;
				//Validating PRIMARYCAREPHYSICIAN field value in In bound file and FACETS Database	
			case "PRIMARYCAREPHYSICIAN":
				if (flatFileValue.contains(","))
					flatFileValue = flatFileValue.replace(",", "");
				if (flatFileValue.contains("."))
					flatFileValue = flatFileValue.replace(".", "");
				if (dbValue.contains(","))
					dbValue = dbValue.replace(",", "");
				if (dbValue.contains("."))
					dbValue = dbValue.replace(".", "");
				assertContainLogger(key, flatFileValue, dbValue, softAssertion);
				//softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");			
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
			
				break;
			default:
				// Changing flat file value to "Y" instead of "Yes"
				if (flatFileValue!= null && flatFileValue.equalsIgnoreCase("Yes") ) {			
					flatFileValue="Y";			
				}			
				// Changing flat file value to "N" instead of "No"
				else if (flatFileValue!= null && flatFileValue.equalsIgnoreCase("No")) {		
					flatFileValue="N";
				}
				// Added this code based on the front end portal new requirement
				if(dbValue.equalsIgnoreCase("N") && flatFileValue.equalsIgnoreCase("")){
					dbValue="";
				}
				
				assertEqualLogger(key, flatFileValue, dbValue, softAssertion);
				//softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
				break;
				
				
		}
	
	}

	
	
	public static void assertEqualLogger(String key, String flatFileValue, String dbValue,SoftAssert softAssertion ){
		
		softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(flatFileValue.equalsIgnoreCase(dbValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		}
	}
	
	public static void assertContainLogger(String key, String flatFileValue, String dbValue,SoftAssert softAssertion ){
		
		softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(dbValue.contains(flatFileValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		}
	}
	
	public static void assertFailLogger(String key, String flatFileValue, String dbValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(false, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
	}

//To print the test case details in the logger
	public static void printTestCaseDeatilsInReport(Map<String, String> data) {		
		
		//String strSUCName= data.get("SUC Name").toString();		
		//String strTestCaseId = data.get("Test Case ID").toString();		
		//String strTestCaseName = data.get("Test Case Name").toString();		
		//String strStepNumber = data.get("Step Number").toString();
		//String strInputFileName = data.get("Input File Name").toString();
		//logger.log(LogStatus.INFO," SUC Name: '" + strSUCName + "',     Test Case ID: '" + strTestCaseId + "',     Test Case Name: '" + strTestCaseName + "',     Step Number: '" + strStepNumber + "'");
		//logger.log(LogStatus.INFO," Input File Name: " + strInputFileName);
	}
	

	//below method is to check whether the given number is numeric or not
		public static boolean isNumeric(String str) {
		    int size = str.length();
		    for (int i = 0; i < size; i++) {
		        if (!Character.isDigit(str.charAt(i))) {
		            return false;
		        }
		    }

		    return size > 0;
		} 

}
