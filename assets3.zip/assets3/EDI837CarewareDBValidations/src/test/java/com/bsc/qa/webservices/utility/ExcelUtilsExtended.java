package com.bsc.qa.webservices.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



/**
 * ExcelUtilsExtended class that gets test data from excel file to be used for
 * driving tests.
 * 
 *
 */
public class ExcelUtilsExtended {
	private static XSSFSheet excelWSheet;
	private static XSSFWorkbook excelWBook;
	public static XSSFCellStyle style;
	private static XSSFCell cell;
	private static XSSFWorkbook wbook ;
	private static XSSFSheet sheet;
	private static int flagCreateSheet = 0;
	private static XSSFCell cell1;

	public String getQueryFromMappingSheet(String nodeName,
			String mappingSheetName) {
		excelWSheet = excelWBook.getSheet(mappingSheetName);
		int totalRows = excelWSheet.getPhysicalNumberOfRows() - 1;
		if (totalRows < 2) {
			System.out.println("Sheet Empty.....!!");
		} else {
			for (int rowNo = 1; rowNo <= totalRows; rowNo++) {
				// GetCellData is not fetching correct data from ExcelUtils, because of that created new method in this ExcelUtilsExtended file
				if (nodeName.equalsIgnoreCase(ExcelUtilsExtended.getCellData(rowNo, 0)
						.trim().toString())) {
					return ExcelUtilsExtended.getCellData(rowNo, 1);
				}
			}
		}
		return null;
	}

	public ExcelUtilsExtended(String path, String sheetName ) {
        try{
        FileInputStream ExcelFile = new FileInputStream(path);
        excelWBook = new XSSFWorkbook(ExcelFile);
        excelWSheet = excelWBook.getSheet(sheetName);
        }catch(Exception e){
               e.printStackTrace();
        }
        }

	
	// GetCellData method is not fetching data from ExcelUtils class file, because of that created this new method in this ExcelUtilsExtended class file
    public static String getCellData(int rowNum, int colNum) 
    {
    	try
           {
			//Creating cell
			  cell = excelWSheet.getRow(rowNum).getCell(colNum);
			  String cellData = null;
			  //To fetch data from excel cell when cell type as String
			  if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
			        cellData = cell.getStringCellValue();
			  }
			//To fetch data from excel cell when cell type as Numeric
			  else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) 
			  {
			        cellData = String.valueOf(cell.getNumericCellValue());
			  }
			//To fetch data from excel cell when cell value as Blank
			  else if (cell.getCellType() == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK)
			  {
			        cellData = "";
			          }
			          return cellData;
			   } 
			   catch (Exception e)
			   {
			          return "";
			   }
    	}
    
     

	/**
	 * To fetch the filed name based on index value for files which doesn't have headers
	 * @param fileFieldName: Field index name
	 * @return
	 */
	public static String getDBColumnName(String fileFieldName) {
		int	totalRows = excelWSheet.getPhysicalNumberOfRows();
		if (totalRows < 2) {
				System.out.println("Sheet Empty.....!!");
				} 
		else {
					@SuppressWarnings("unused")
					int totalCols = excelWSheet.getRow(0).getPhysicalNumberOfCells()-1;
					for(int rowNo=1;rowNo<totalRows;rowNo++){
						
						if(fileFieldName.equals(getCellData(rowNo,1))){
						//	System.out.println("Mapping file values: "+getCellData(rowNo,1)+"-------"+getCellData(rowNo,2));
							return getCellData(rowNo,2);
								}
						}
				}
	return null;
	}
public static void writeResultIntoExcel(int rowNo, String claimid,String ProviderID,String SubscriberID, String fieldName, String facetsOutput, String carewareDBOutput, String status){
		
		File file = new File("test-output\\Results.xlsx");
//		try {
//			FileOutputStream excelFile1 = new FileOutputStream(file);
			try {
				flagCreateSheet ++;
				if(file.exists()==false){
				wbook = new XSSFWorkbook();
				}
				else{
					FileInputStream is = new FileInputStream(file);
					wbook = new XSSFWorkbook(is);
				}
				if((wbook.getNumberOfSheets()!=0)){
					for(int i=0;i<wbook.getNumberOfSheets();i++){
						if(wbook.getSheetName(i).equals("results sheet")){
							sheet = wbook.getSheet("results sheet");
						}
						else{
							sheet = wbook.createSheet("results sheet");
						
						}
					}
				}
				else{
					 sheet = wbook.createSheet("results sheet");
					
				}
				//if(flagCreateSheet==1){
					String[] columns ={"ClaimID","ProviderID","SubscriberID","Field Name","Edi837File Value ","CarewareDB Value","Status"};
					Font headerFont = wbook.createFont();
			        ((XSSFFont) headerFont).setBold(true);
			        headerFont.setFontHeightInPoints((short) 14);
			        headerFont.setColor(IndexedColors.BLACK.getIndex());

			        // Create a CellStyle with the font
			        XSSFCellStyle headerCellStyle = wbook.createCellStyle();
			        headerCellStyle.setFont(headerFont);

			        // Create a Row
			        XSSFRow headerRow = sheet.createRow(0);
			        // Create cells
			        for(int i = 0; i < columns.length; i++) {
			             cell1 = headerRow.createCell(i);
			            cell1.setCellValue(columns[i]);
			            cell1.setCellStyle(headerCellStyle);
			            sheet.autoSizeColumn(i);
			        }
				//}
				
		        Object[][] claimData = {{claimid,ProviderID,SubscriberID, fieldName, facetsOutput, carewareDBOutput, status}};
		 
		        //int rowCount = 0;
		         
		        for (Object[] claim :claimData) {
		            Row row = sheet.createRow(rowNo);
		             
		            int columnCount = 0;
		             
		            for (Object field : claim) {
		            	
		                Cell cell = row.createCell(columnCount);
		                columnCount++;
		                if (field instanceof String) {
		                    cell.setCellValue((String) field);
		                } else if (field instanceof Integer) {
		                    cell.setCellValue((Integer) field);
		                }
		            }
		             
		        }
		        
		        
		        
		        
		        FileOutputStream outputStream = new FileOutputStream("test-output\\Results.xlsx");
	            wbook.write(outputStream);
	            outputStream.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
	        
	         
	         
	        
	        	
	            
  		
	}
	}