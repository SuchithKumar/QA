package com.bsc.qa.webservices.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;





/**
 * Edi834Utility class that gets fields data from 834 file to be used for 834 file validation.
 * @author Automation team
 *
 */
public class Edi837Utility {

	private static int lineSegmentNumber = 0;
	private static Map<String, String> LineValuesMap=new HashMap<String,String>();
	/**
	 *For getting 837 file data from 834 EDI file
	 * @param strCompleteFilePath: 834 file path
	 * @param strInputFileName: 834 file name
	 * @return
	 * @throws Exception: To capture the exception
	 */
	public LinkedHashMap<String, LinkedHashMap<String, String>> get837FileData(
			String strCompleteFilePath, String strInputFileName,Map<String, String> data)
			throws Exception {
	
		String strFileType;
		String primaryKey;
		LinkedHashMap<String, LinkedHashMap<String, String>> flatFileValuesMap = null;
		LinkedHashMap<String, LinkedHashMap<String, String>> claimValuesMap = null;
		LinkedHashMap<String, LinkedHashMap<String, String>> providerMap = null;
		LinkedHashMap<String, LinkedHashMap<String, String>> SubclaimMap = null;
		LinkedHashMap<String, String> singleRecordMap = null;
		strCompleteFilePath = strInputFileName;
		String strOtherQueries = data.get("PCP_QUERY");
		int Dependent=0;
		
		
		String strInputExactFileName = strInputFileName.substring(strInputFileName.lastIndexOf("\\") + 1);
		// To get 834 file type
		
		
		
		strFileType = fileType837(strInputExactFileName);
		// To get 837 file type
		flatFileValuesMap = new LinkedHashMap<String, LinkedHashMap<String, String>>();
		claimValuesMap=new LinkedHashMap<String, LinkedHashMap<String, String>>();
		providerMap=new LinkedHashMap<String, LinkedHashMap<String, String>>();
		SubclaimMap=new LinkedHashMap<String, LinkedHashMap<String, String>>();
		
		
	
			// For capturing all PROVIDER  numbers from 837 file
			List<String> rowsListPANumbers = parse837FileForPatientAccNumbers(strInputFileName);
			// Looping through all PROVIDER  numbers for validation
			for (String strPANumber : rowsListPANumbers) {
				  int lineSegmentNumber = 0;
			
				singleRecordMap = new LinkedHashMap<String, String>();
				
				primaryKey = strPANumber.trim().toLowerCase();
				// For retrieving PROVIDER  number specific data from 837 file
				List<String> rowsList = parse837File(strInputFileName, 
						primaryKey.toUpperCase());
				int intSubscriber = 0;
				String line1 = "";
				List<String> rowsList1=new ArrayList<String>();
				//To retrive number of claims id's in ST to SE segment
				for (int j = 0; j < rowsList.size(); j++) {
					if (rowsList.get(j).startsWith("CLM*"))
		        	{
						line1=rowsList.get(j).toString().toLowerCase();
		        		//Adding claim account number to the list
		        		rowsList1.add(line1.split("\\*")[1].replace("~", ""));
		        	}
				}
				
				//singleRecordMap.put("Patient Acc Number", strPANumber.trim().toLowerCase());
				System.out.println(" Provider id used while storing flat file data: " + strPANumber.trim().toLowerCase());
                 int address=0;
                 int address1=0;
				

				// Looping through all claim number records to retrieve required values	
				List<String>claimNumbers=rowsList1;
				for (String strClaim : claimNumbers) {
				for (int i = 0; i < rowsList.size(); i++) {
					
						
					// looping the Subscriber segement				
					if (rowsList.get(i).startsWith("SBR*S")) {
						for(int k=i;k<rowsList.size();k++){
							//storing field value to validate subscriber address
							if (rowsList.get(k).startsWith("N3*")) {
								if(address1==0){
								line1 = rowsList.get(k).toString().toLowerCase();

								line1 = line1.replace("~", "");
								String adress2=line1.split("\\*")[1].substring(0).replace("~", "");
								String adressvalue=adress2.trim();
								System.out.println(adressvalue);
								try{singleRecordMap.put("SUBSCRIBER_ADDRESS", adressvalue);
								address1=address1+1;
								}
								catch(Exception e){
									System.out.println("Data not present for validation");
								}
								}
							
							}
							//storing field values to validate subscriber first name,last name,cin
							if(rowsList.get(k).startsWith("NM1*IL*"))
							{
								
								if(intSubscriber == 0){
									line1 = rowsList.get(k).toString().toLowerCase();
									line1 = line1.replace("~", "");
									//strDependent = strSSNNNumber;
									
								       try{
										singleRecordMap.put("SUBSCRIBER_LASTNAME",line1.split("\\*")[3]);
										singleRecordMap.put("SUBSCRIBER_FIRSTNAME",line1.split("\\*")[4]);
										singleRecordMap.put("SUBSCRIBER_CIN",line1.split("\\*")[9]);
										intSubscriber = intSubscriber + 1;
									}
									
									catch(Exception e){
										System.out.println("Data not present for validation");
									}
								       
								}
								
							}
							// storing field values to validate subscriber address like city,state,zipcode
							
							if (rowsList.get(k).startsWith("N4*")){
								if(address == 0){
								line1 = rowsList.get(k).toString().toLowerCase();
								line1 = line1.replace("~", "");
								try{
									singleRecordMap.put("SUBSCRIBER_CITY", line1.split("\\*")[1]);
									singleRecordMap.put("SUBSCRIBER_STATE", line1.split("\\*")[2]);
									singleRecordMap.put("SUBSCRIBER_ZIPCODE", line1.split("\\*")[3].replace("~", ""));
									address = address + 1;
								}
								catch(Exception e){
									System.out.println("Data not present for validation");
								}
								}
							}
							//storing field values to validate subscriber date of birth and sex
							if (rowsList.get(k).startsWith("DMG*D8*")){
								line1 = rowsList.get(k).toString().toLowerCase();
								line1 = line1.replace("~", "");
								try{
									singleRecordMap.put("SUBSCRIBER_DOB", line1.split("\\*")[2]);
									singleRecordMap.put("SUBSCRIBER_SEX", line1.split("\\*")[3]);
									
									
								}
								catch(Exception e){
									System.out.println("Data not present for validation");
								}
								
							}
							//storing field values to validate claim id and claim amount
							if (rowsList.get(k).startsWith("CLM*")){
								line1 = rowsList.get(k).toString().toLowerCase();
								line1 = line1.replace("~", "");
								try{
									singleRecordMap.put("CLM01", line1.split("\\*")[1]);
									singleRecordMap.put("CLAIM_AMOUNT", line1.split("\\*")[2]);
									
									
								}
								catch(Exception e){
									System.out.println("Data not present for validation");
								}
								
							}
							//storing field values to validate contract code and contract amount
							if (rowsList.get(k).startsWith("CN1*")){
								line1 = rowsList.get(k).toString().toLowerCase();
								line1 = line1.replace("~", "");
								try{
									singleRecordMap.put("CONTRACT_CODE", line1.split("\\*")[1]);
									singleRecordMap.put("CONTRACT_AMOUNT", line1.split("\\*")[2]);
									
									
								}
								catch(Exception e){
									System.out.println("Data not present for validation");
								}
								
							}
							//storing field values to validate county code
							if (rowsList.get(k).startsWith("NTE*")){
								line1 = rowsList.get(k).toString().toLowerCase();
								line1 = line1.replace("~", "");
								try{
									singleRecordMap.put("COUNTY_CD", line1.split("\\*")[2]);
									
									
									
								}
								catch(Exception e){
									System.out.println("Data not present for validation");
								}
								
							}
							//storing field values to validate certification indicator
							if (rowsList.get(k).startsWith("OI*")){
								line1 = rowsList.get(k).toString().toLowerCase();
								line1 = line1.replace("~", "");
								try{
									singleRecordMap.put("CERTIFICATION_INDICATOR", line1.split("\\*")[3]);
									
									
									
								}
								catch(Exception e){
									System.out.println("Data not present for validation");
								}
								
							}
							
							if (rowsList.get(k).startsWith("DTP*573*")) {
								//SubclaimMap.put(strClaim, value)
								i=k;
								break;
								
							}
							
						}
						

					}
					else if(rowsList.get(i).startsWith("LX*")){
						lineSegmentNumber = lineSegmentNumber + 1;
						lineItemValidation(rowsList,i,singleRecordMap,lineSegmentNumber);
						
					
					}
					//storing field values to validate provider information
					else if (rowsList.get(i).startsWith("NM1*85")){
						String line=rowsList.get(i).toString().toLowerCase();
						String line2=rowsList.get(i+1).toString().toLowerCase();
						String line3=rowsList.get(i+2).toString().toLowerCase();
						String line4=rowsList.get(i+3).toString().toLowerCase();
						singleRecordMap.put("PROVIDER_LASTNAME", line.split("\\*")[3]);
						singleRecordMap.put("PROVIDER_ID", line.split("\\*")[9].replace("~", ""));
						singleRecordMap.put("PROVIDER_TAXID", line4.split("\\*")[2].replace("~", ""));
						singleRecordMap.put("PROVIDER_ADDRESS", line2.split("\\*")[1].replace("~", ""));
						singleRecordMap.put("PROVIDER_CITYNAME", line3.split("\\*")[1]);
						singleRecordMap.put("PROVIDER_STATENAME", line3.split("\\*")[2]);
						singleRecordMap.put("PROVIDER_POSTALCODE", line3.split("\\*")[3].replace("~", ""));
						providerMap.put(strClaim, singleRecordMap);
					}
					
//					}
					 // Storing field values to validate subscriber's Address
					
					claimValuesMap.put(strClaim, singleRecordMap);
					//lineSegmentNumber=0;
					
				}
				break;
				}
				
				//flatFileValuesMap.put(primaryKey, singleRecordMap);
			}	
		
		
		// LinkedHashMap<String, SortedMap<String, String>> with 837 file values claim as the key
		return claimValuesMap;
	}
private static void lineItemValidation(List<String>rowsList, int lineNumber,Map<String, String> singleRecordMap, int lineSegmentNumber) throws Exception{
		
		int lineItemEndLineNumber=0,lineItemStartLineNumber;
		int intCDMLTODT = 0;
		
		lineItemStartLineNumber = lineNumber;
		//To check line item start or end
		for(int intICounter = lineNumber+1;intICounter<rowsList.size();intICounter++){
			
			if(rowsList.get(intICounter).startsWith("LX") || rowsList.get(intICounter).startsWith("SE")){
				lineItemEndLineNumber = intICounter-1;
				break;
			}
			
		}
		
		for (int intJCounter = lineItemStartLineNumber; intJCounter<=lineItemEndLineNumber; intJCounter++){
			
			// To retrieve line item From date of service
			if(rowsList.get(intJCounter).startsWith("DTP*472")){
				String lineVal1=rowsList.get(intJCounter).toString();
				singleRecordMap.put("SERVICE_DATE" + lineSegmentNumber , lineVal1.split("\\*")[3].replace("~", ""));
			}
			
			//To retrieve To date of service
			else if(rowsList.get(intJCounter).startsWith("DTP*573")){
				intCDMLTODT = intCDMLTODT + 1;
				String lineVal1=rowsList.get(intJCounter).toString();
				singleRecordMap.put("ADJUDICATION_DATE" + lineSegmentNumber , lineVal1.split("\\*")[3].replace("~", ""));
			}
			else if(rowsList.get(intJCounter).startsWith("REF*")){
				intCDMLTODT = intCDMLTODT + 1;
				String lineVal1=rowsList.get(intJCounter).toString();
				//singleRecordMap.put("REFERENCE_ID_QUALIFIER" + lineSegmentNumber , lineVal1.split("\\*")[1].replace("~", ""));
				singleRecordMap.put("LineItem_ControlNumber" + lineSegmentNumber , lineVal1.split("\\*")[2].replace("~", ""));
			}
			
			// To retrieve Procedure code details
			else if(rowsList.get(intJCounter).startsWith("SV1")){
				String lineVal1=rowsList.get(intJCounter).toString();
				if(lineVal1.split("\\*")[1].contains(":")){
					singleRecordMap.put("PROCEDURE_CODE" + lineSegmentNumber, lineVal1.split("\\*")[1].split(":")[1].replace("~", ""));
				}
				else if(lineVal1.split("\\*")[1].contains(">")){
					singleRecordMap.put("IPCD_ID_" + lineSegmentNumber, lineVal1.split("\\*")[1].split(">")[1].replace("~", ""));
				}
				//else
					//logger.log(LogStatus.FAIL, "Invalid character present in the line starts with 'SV1' in Claim segment details ");
			}
			
			
		
			
		}
		//if to date is not present then assigning from date as to date
		if(intCDMLTODT==0){
			singleRecordMap.put("CDML_TO_DT_" + lineSegmentNumber , singleRecordMap.get("CDML_FROM_DT_" + lineSegmentNumber));
		}

		
	}

	


/**
 * Changing 837 EDI file format when it is having one line
 * @param strFlatFileCompletePath: 837 file complete path
 * @throws Exception: To capture exception
 */
public void fileFormatChange834(String strFlatFileCompletePath) throws Exception
{	
	FileWriter fileWriter = null;
	FileReader fileReader  = null;
	BufferedReader bufferedReader = null;
	
	try{
		File inputFile = new File(strFlatFileCompletePath);
		String strLines = "";
		String line = "";
		//Checking for the file existence
		if (!inputFile.exists()) { 
			  throw new IllegalStateException("File not found: " + strFlatFileCompletePath);
		  } 
		else 
		{
			fileReader =  new FileReader(inputFile);
			bufferedReader =        new BufferedReader(fileReader);
			int intICounter = 0;
			//Reading each line from the file
			while((line = bufferedReader.readLine())!=null)
			{
				strLines = strLines + line;
				intICounter += 1;
				//Checking for single line 834 file
				if(intICounter > 1)
				{
					bufferedReader.close();
					return;
				}
			}
		
			byte [] strBytes = strLines.getBytes();
			String strAllLines = new String (strBytes,StandardCharsets.UTF_8);
			//Replacing "~" symbol with "~\r\n"
			String strFormatLines = strAllLines.replaceAll("~", "~\r\n");
			fileWriter = new FileWriter(strFlatFileCompletePath);
			//Writing the data once again into the file after changes
			fileWriter.write(strFormatLines);
		  }
		
	}
	//For capturing exception
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try{
			//Closing all opened file objects
			fileReader.close();
			fileWriter.close();
			bufferedReader.close();
		}
		catch(Exception ex)
		{
			//ex.printStackTrace();
		}
	}
}

/**
 * @param testFlatFileCompletePath: File complete path
 * @param strCINNNumber: To capture specific subscriber section
 * @param strFileName: 837 file type
 * @return: List of subscriber lines
 * @throws Exception" To capture the exception
 */
public  List<String> parse837File(String testFlatFileCompletePath,String strPatAccNumber) throws Exception {
	
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 //For checking file existence
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
		  		
				 
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader = new BufferedReader(fileReader);
						boolean flag=false;
						// Reading each line in the file 
				        while((line = bufferedReader.readLine()) != null) {
				        	//Checking for the patient Account  Number
				        	if(line.contains(strPatAccNumber) && line.contains("SE*")){
				        		 flag=true;
				        	}
			        	//Checking for the starting line for each claim section
				        	if(line.startsWith("ST")){
			        		if(flag){
				        			break;
				        		}else{
				        			//To clear the records if it is not matches to the provided patient account number
				        			rowsList.clear();
				        		}
				        	}
				        	//Adding lines to the records list
				        	rowsList.add(line);
				       		}   
				  
				  
			

  	}
	 //To close the bufferedReader object
	 if(bufferedReader!=null)
		 bufferedReader.close();

	return rowsList;
}


/**
 * To capture patient account  Numbers from 837 file
 * @param testFlatFileCompletePath: 837 File complete path
 * @param strFileName: 837 file type
 * @return: List of p Numbers
 * @throws Exception: Throwing exception
 */
public  List<String> parse837FileForPatientAccNumbers(String strFileName) {
	
	 File inputFile = new File(strFileName);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	try {
	//Checking for the file existence
	 if (!inputFile.exists())
	 { 
		  throw new IllegalStateException("File not found: " + strFileName);
	  } else {
		  		
		  		//To capture patient Account Numbers from 837 file
				  
						FileReader fileReader =  new FileReader(strFileName);
						bufferedReader = new BufferedReader(fileReader);
						//Looping through all lined for checking CINN Number line
				        while((line = bufferedReader.readLine()) != null)
				        {
				        	if(line.startsWith("ST*837*"))
				        	{
				        		//Adding patient account number to the list
				        		rowsList.add(line.split("\\*")[2].replace("~", ""));
				        	}
				
				 

  	}
				        
	  
	 //To close the bufferReader object
	if(bufferedReader != null)
		bufferedReader.close();

	  }
	 
	}
	//To capture and print the exception
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//For returning list of CINN numbers 
 	return rowsList;
}
public String fileType837(String strFileName){
	if(strFileName.contains("\\")){
		strFileName = strFileName.substring(strFileName.lastIndexOf("\\") + 1);
		//System.out.println("file name is"+ strFileName);
	}
	//Checking for the expected file name
	if(strFileName.contains(".enc"))
		return "BSCP_837P_MCAL_06042019LS07 LACARE";
	else if(strFileName.contains("834"))
		return "IRT_EDI834_CalPERS_New Enrollment";
	else if(strFileName.startsWith("eEnrollment_benefit_"))
		return "eEnrollment_benefit_focus";
	else if(strFileName.startsWith("eExchange_benefit_"))
		return "eExchange_benefit_focus";
	else 
		System.out.println("This file name is invalid: " + strFileName );
		return null;
}





//below method is to handle the index out of bound exception
public String  partialStringRetrieval(String strKeyName,String line,int indexValue, int intStartPos, int intEndingPos){
       
	if(!(intStartPos == 0 && intEndingPos == 0)){
		 try{
             String strValue = line.split("\\*")[indexValue].substring(intStartPos,intEndingPos).replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    return strValue;
             }
             
       }
       catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
    	   return "";
       }
	}
	else{
      
		 try{
             String strValue = line.split("\\*")[indexValue].replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    
                    return strValue;
             }
             
       }
       catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
             return "";
       }
	}
	return "";
       
}



public static  List<SortedMap<String,String>> parseFileWithOutHeaderByDelimeter(String delimeter,String testFlatFileCompletePath,String fieldColumnMappingFilePath,String mappingSheetName) throws IOException{
	
	 //String testFlatFileCompletePath="\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\SUC automation\\Required Documents\\12. SUC546265-DRX To MAM\\MAPDP_Complete_2018_20180401.bsc180401111900.txt";
	 File inputFile = new File(testFlatFileCompletePath);
	 List<SortedMap<String,String>> listOfRows=new ArrayList<SortedMap<String,String>>();
	 String line=null;
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
						System.out.println("Starting of File Reading . . . . . .  . . . . ");
						//src/test/resources/TestData.xlsx
					//	new ExcelUtils("C:\\Users\\bgujja01\\bqsa32\\workspace\\Care1stMMInboundAndOutboundFileValidation\\src\\test\\resources\\FileFieldAndTableColumnMapping.xlsx","SUC580263");
						new ExcelUtilsExtended(fieldColumnMappingFilePath,mappingSheetName);

						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						@SuppressWarnings("resource")
						BufferedReader bufferedReader =        new BufferedReader(fileReader);
				        while((line = bufferedReader.readLine()) != null) {
			                String[] columnsArray = line.split(delimeter);
				        	  
			                SortedMap<String,String> rowMap=new TreeMap<String,String>();
							int columnLength=columnsArray.length;
							for(int i=0;i<columnLength;i++){
								String fileFieldName=String.valueOf(i);
							//	System.out.println("excel Value:"+ExcelUtils.getDBColumnName(fileFieldName)+" | "+columnsArray[i]);
								String columnNameKey=ExcelUtilsExtended.getDBColumnName(fileFieldName);
								if(columnNameKey!=null){
								rowMap.put(columnNameKey.toLowerCase(),columnsArray[i].toLowerCase());	//System.out.println(rowNo+"  columnlength::"+columnLength+" index: "+i+"  "+rowsList.get(rowNo)[i]);
								}
							}
							listOfRows.add(rowMap);
			                     		}   
						
				    
 	}
	return listOfRows;
}
public SortedMap<String,SortedMap<String,String>> sortedMapMergingRough(SortedMap<String,SortedMap<String,String>> map1,SortedMap<String,SortedMap<String,String>> map2){
	SortedMap<String,SortedMap<String,String>> map3Return = new TreeMap<String,SortedMap<String,String>>();
	SortedMap<String,String> tempMap1 = new TreeMap<String, String>();
	SortedMap<String,String> tempMap2 = new TreeMap<String, String>();
	SortedMap<String,String> tempMapMerged = new TreeMap<String, String>();
	String tempMapKey1 = null;
	String tempMapKey2 = null;
	Boolean blnFlag = false;
	
	for(Entry<String,SortedMap<String,String>> mapEntry1 : map1.entrySet()){
		tempMap1 = mapEntry1.getValue();
		tempMapKey1 = mapEntry1.getKey();
		for(Entry<String,SortedMap<String,String>> mapEntry2 : map2.entrySet()){
			tempMap2 = mapEntry2.getValue();
			tempMapKey2 = mapEntry1.getKey();
			if(tempMapKey1.equalsIgnoreCase(tempMapKey2)){
				tempMapMerged.putAll(tempMap1);
				tempMapMerged.putAll(tempMap2);
				map3Return.put(tempMapKey1, tempMapMerged);
				blnFlag = true;
			}
		}
	}
	
	if(!blnFlag && map1.size()!=0){
		map3Return.putAll(map1);
	}
	
	else if(!blnFlag && (map2.size()!=0)){
		map3Return.putAll(map2);
	}
	
	return map3Return;
	
}

// Function for merging of all the query maps into a single map
public SortedMap<String,SortedMap<String,String>> sortedMapMerging(SortedMap<String,SortedMap<String,String>> map1,SortedMap<String,SortedMap<String,String>> map2){
    SortedMap<String,SortedMap<String,String>> map3Return = new TreeMap<String,SortedMap<String,String>>();
    SortedMap<String,String> tempMap1 = new TreeMap<String, String>();
    SortedMap<String,String> tempMap2 = new TreeMap<String, String>();
    String tempMapKey1 = null;
    
    for(Entry<String,SortedMap<String,String>> mapEntry1 : map1.entrySet()){
    	tempMap1 = mapEntry1.getValue();
        tempMapKey1 = mapEntry1.getKey();
        if(map2.containsKey(tempMapKey1)){
        	SortedMap<String,String> tempMapMerged = new TreeMap<String, String>();
            tempMap2 = map2.get(tempMapKey1);
            tempMapMerged.putAll(tempMap1);
            tempMapMerged.putAll(tempMap2);
            map3Return.put(tempMapKey1, tempMapMerged);
         }
         else{
        	map3Return.put(tempMapKey1, tempMap1);
         }
    }
    
    for(Entry<String,SortedMap<String,String>> mapEntry2 : map2.entrySet()){
    	tempMap1 = mapEntry2.getValue();
        tempMapKey1 = mapEntry2.getKey();
        if(!map1.containsKey(tempMapKey1)){
        	map3Return.put(tempMapKey1, tempMap1);
        }  
    }
    
    return map3Return;
}


	
}
