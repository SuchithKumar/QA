package com.bsc.qa.webservices.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.factory.ReportFactory;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.DBUtilsTemp;
import com.bsc.qa.webservices.utility.Edi837Utility;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import com.relevantcodes.extentreports.LogStatus;

public class EDI837Careware extends BaseTest implements IHookable {
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	int rowno=0;
	
	public EDI837Careware(String inputFileName) {
		this.inputFileName = inputFileName;
	}
	
	// ************************************** TEST
	// METHODS************************

	// Main test method to validate 837 file against FACETS database.
	@Test()
	private void test837FileValidation() {
		LinkedHashMap<String, LinkedHashMap<String, String>> flatFileValuesMap = null;
		int ProviderCount=0;
		int SubscriberCount=0;
		int ClaimCount=0;
		int FieldCount=0;
		

		String strCompleteFilePath = System.getenv("INPUT_837_PATH");
		//Creating Edi837Utility class object
		Edi837Utility edi837Utility = new Edi837Utility();
		
		Map<String, String> data = null;
		try{
			data = getData("test837FileValidation");
		} 
		catch (Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		try {
			
			flatFileValuesMap = edi837Utility.get837FileData(
					strCompleteFilePath, inputFileName,data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Retrieve's all primary keys into flatfilevaluemap
		Set<String> keys = flatFileValuesMap.keySet();
		ClaimCount=keys.size();
		
		
		String  inClauseStringBuilderstr = "";
        int intICounter = 0;
        List<String> strKeysList = new ArrayList<String>();
        
        //Loop used to get the subscribers data to pass it is input to the query
        for (String key : keys) {
            intICounter++;
            inClauseStringBuilderstr = inClauseStringBuilderstr + "'" + key + "',";
            //Storing 1000 subscribers data in a list variable
            if(intICounter >=1000){
                //Removing extra ',' at the end of the map
                inClauseStringBuilderstr = inClauseStringBuilderstr.substring(0, (inClauseStringBuilderstr.length()-1));
                //Adding the 1000 subscribers data to list
                strKeysList.add(inClauseStringBuilderstr);
                intICounter = 0;
                inClauseStringBuilderstr = "";
                            
            }
		
        //Storing last subscribers data which are less than 1000
            else if((intICounter < 1000) && (intICounter !=0)){
            //Removing extra ',' at the end of the map
            inClauseStringBuilderstr = inClauseStringBuilderstr.substring(0, (inClauseStringBuilderstr.length()-1));
            strKeysList.add(inClauseStringBuilderstr);
            inClauseStringBuilderstr = "";
		}
		
        }

		
		/*Map<String, String> data = null;
		try {
			data = getData("test837FileValidation");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		String strQuery = "";
		String strQuery1 = "";
		String query1=" ";
		
		
		String	strFileType = edi837Utility.fileType837(inputFileName);
		
		//Loop used to get 1000 subscribers data and store the same in main SortedMap
        for(String strKeySet : strKeysList ){
        	
        	if (strFileType.contains("LACARE")|| strFileType.contains("LACARE")){																										 
//            	if(strFileType.contains("834") || strFileType.contains("834_IN_")){
            		//Creating where clause statement for each 1000 subscribers data
    	        	strQuery = strQuery + data.get("PRIMARY_KEY") + " in (" + strKeySet + ")" + " Or ";
    	        	System.out.println("query is..."+strQuery);
    	        	//If(strQuery1.contentEquals(cs))
    	        	strQuery1 = strQuery1+ data.get("PRIMARY_KEY1") + " in (" + strKeySet + ")" + " Or ";
    	        	System.out.println("query is..."+strQuery1);
    	        	
    	        	 //query1=query1+data.get("Cinn_query")+" "+ data.get("PRIMARY_KEY") + " in (" + strKeySet + ")";
    	        	//System.out.println("query for CINN..."+query1);
    	       }
     
        }

        strQuery = strQuery.substring(0, strQuery.length()-4).trim();
        strQuery1 = strQuery1.substring(0, strQuery1.length()-4).trim();
        System.out.println(strQuery1);
        SortedMap<String, SortedMap<String, String>> ProvMap = null;
        SortedMap<String, SortedMap<String, String>> SubMap = null;
        SortedMap<String, SortedMap<String, String>> ClaimMap = null;
        SortedMap<String, SortedMap<String, String>> LineMap = null;
        //Object[][] sqldata;
        String strActualQuery = ""; 
        String ProvQuery=data.get("PROV_QUERY") + "  " + strQuery.toString().toUpperCase();
        String claimQuery1=data.get("CLAIM_QUERY") + "  " + strQuery1.toString().toUpperCase();
        System.out.println(ProvQuery);
        System.out.println(claimQuery1);
        //String[] values={"SVD03_2","SVD02"};
      
      //Replaces 'in clause' string in the query with all subscriber ids in comma separated format
       // ProvMap = new DBUtils().getMultiRowsFromPreparedQuery(
                //"oracleDB", data.get("PROV_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
        ProvMap =new DBUtilsTemp().getResultSetAsSortedMap(
                         "oracleDB", data.get("PROV_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
        SubMap = new DBUtilsTemp().getResultSetAsSortedMap(
                "oracleDB", data.get("SUBS_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
        ClaimMap=new DBUtils().getResultSetAsSortedMap(
               "oracleDB", data.get("CLAIM_QUERY") + "  " + strQuery1.toString().toUpperCase(), data.get("PRIMARY_KEY1"));
        //ClaimMap=new DBUtilsTemp().getMultiRowsFromPreparedQuery(
                //"oracleDB", data.get("CLAIM_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
         //new DBUtilsTemp().
       // sqldata  = new DBUtils().getTableArray("oracleDB", claimQuery1);
    	
        strActualQuery = data.get("PROV_QUERY") + "  " + strQuery.toString().toUpperCase();
    	ProvMap=edi837Utility.sortedMapMerging(ProvMap, ClaimMap);
    	ProvMap=edi837Utility.sortedMapMerging(ProvMap, SubMap);
    	
    	
    	
    	//strActualQuery=strActualQuery+data.get("CONDITION1");
 
        
        Set<String> primaryKeySet = flatFileValuesMap.keySet();
     

		
		//Below section will loop on each primaryKey in the "flatfilevaluemap"
		for (String primaryKey: primaryKeySet) {
			int LineCount=0;
			
			//capture single subscriber id from flatfilevaluemap
			//SortedMap<String, String> ProvFileMap = providerMap.get(primaryKey);
			LinkedHashMap<String, String> rowMap = flatFileValuesMap.get(primaryKey);
			SortedMap<String, String> Sub1map = ProvMap.get(primaryKey);
			String Providerid=Sub1map.get("provider_id");
			String Subscriberid=Sub1map.get("subscriber_cin");
			
			
			//To get the report for each subscriber in the XMLs
			//Parameters: to display report header in the HTML
			
			reportInit("Provider Validations ", ": Provider ID:" +Providerid);
			ProviderCount++ ;
			
			logger.log(LogStatus.INFO, "Starting  test837FileValidation ");
			logger.log(LogStatus.INFO, "Provider Count:1 "  );
		    logger.log(LogStatus.INFO, "File Path: " + inputFileName);
		    logger.log(LogStatus.INFO, "Query used to fecth database data: " + strActualQuery );
		    logger.log(LogStatus.INFO, "Provider id used for validation: " + Providerid );
		   logger.log(LogStatus.INFO, "Provider validations started: "  );
		   
		
			
			try{
				Set<String> columnSet = rowMap.keySet();
				 FieldCount=columnSet.size();
					
					for (String columnKey : rowMap.keySet()) {
						String fileValue;
						
						String dbValue = "";
						rowno++;
						
						//Retrieving value from flat file for each of the keys 
						if(columnKey.contains("PROVIDER_LASTNAME") || columnKey.contains("PROVIDER_ID") || columnKey.contains("PROVIDER_TAXID") || columnKey.contains("PROVIDER_ADDRESS") || columnKey.contains("PROVIDER_CITYNAME") || columnKey.contains("PROVIDER_STATENAME")|| columnKey.contains("PROVIDER_POSTALCODE")){
							
							fileValue = rowMap.get(columnKey);
							 
							//String dbValue = "";
							//Retrieving value from database for each of the keys				
							dbValue = ProvMap.get(primaryKey).get(columnKey.toLowerCase());
							
							//System.out.println(columnKey);
							
							if(fileValue.equalsIgnoreCase(dbValue)){
								String status="PASS";
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Actual (837 Output File) value: " + fileValue + " | Expected (Careware DB): " + dbValue + " >>");
								ExcelUtilsExtended.writeResultIntoExcel(rowno,primaryKey,Providerid,Subscriberid, columnKey, fileValue, dbValue,status);
							}
							else{
								String status1="FAIL";
								logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Actual (837 Output File) value: " + fileValue + " | Expected (careware DB): " + dbValue + " >>");
								ExcelUtilsExtended.writeResultIntoExcel(rowno,primaryKey,Providerid,Subscriberid, columnKey, fileValue, dbValue,status1);
							}
							//System.out.println(columnKey + ": " + fileValue + " | " + dbValue);
							//ReportFactory.closeReport();
						
						}
						
						//ReportFactory.closeReport();
						
							
							
							//softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " not found");
							
						
						else if(columnKey.contains("SUBSCRIBER_ADDRESS") || columnKey.contains("SUBSCRIBER_LASTNAME") || columnKey.contains("SUBSCRIBER_FIRSTNAME") || columnKey.contains("SUBSCRIBER_CIN") || columnKey.contains("SUBSCRIBER_CITY") || columnKey.contains("SUBSCRIBER_STATE")|| columnKey.contains("SUBSCRIBER_ZIPCODE") || columnKey.contains("SUBSCRIBER_SEX") || columnKey.contains("SUBSCRIBER_DOB") || columnKey.contains("CLM01") || columnKey.contains("CLAIM_AMOUNT") || columnKey.contains("CONTRACT_CODE") || columnKey.contains("CONTRACT_AMOUNT") || columnKey.contains("COUNTY_CD") || columnKey.contains("CERTIFICATION_INDICATOR"))  
					{
							if(columnKey.contains("SUBSCRIBER_LASTNAME")){
								SubscriberCount++;	
							reportInit("Subscriber + Claim validations  ", ": Provider ID:" +Providerid +";"+": Subscriber ID:" +Subscriberid+";"+": Claim ID:" +primaryKey);
							logger.log(LogStatus.INFO, "Starting  test837FileValidation ");
						
						logger.log(LogStatus.INFO, "Subscriber Count:1 " );
						logger.log(LogStatus.INFO, "Claims Count:1 " );
						logger.log(LogStatus.INFO, "File Path: " + inputFileName);
						logger.log(LogStatus.INFO, "Provider ID used for validation: " + Providerid );
						
						//logger.log(LogStatus.INFO, "Query used to fecth database data: " + strActualQuery );
						logger.log(LogStatus.INFO, "Subscriber ID used for validation: " + Subscriberid );
						logger.log(LogStatus.INFO, "Claim ID used for validation is: " + primaryKey.toUpperCase());
						logger.log(LogStatus.INFO, "Subscriber validations started: " );
						
						
						
						}
							
						fileValue = rowMap.get(columnKey);
						//String dbValue = "";
						//Retrieving value from database for each of the keys				
						dbValue = ProvMap.get(primaryKey).get(columnKey.toLowerCase());
						if(columnKey.contains("SUBSCRIBER_ADDRESS")){
							System.out.println("valueis"+dbValue);
						}
						//System.out.println(columnKey);
						
						
						//Comparing source and target values to report in the logger
						if(fileValue.equalsIgnoreCase(dbValue)){
							String status="PASS";
							logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Actual (837 Output File) value: " + fileValue + " | Expected (Careware DB): " + dbValue + " >>");
							ExcelUtilsExtended.writeResultIntoExcel(rowno,primaryKey,Providerid,Subscriberid, columnKey, fileValue, dbValue,status );
						}
						else{
							
							String status1="FAIL";
							logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Actual (837 Output File) value: " + fileValue + " | Expected (careware DB): " + dbValue + " >>");
							ExcelUtilsExtended.writeResultIntoExcel(rowno,primaryKey,Providerid,Subscriberid, columnKey, fileValue, dbValue,status1);
						}
						//System.out.println(columnKey + ": " + fileValue + " | " + dbValue);
						
					
						if(columnKey.contains("CLM01")){
							logger.log(LogStatus.INFO, "Claim validations started: " );
							String Linequery =data.get("LINE_QUERY") + "  " + data.get("PRIMARY_KEY1") + "  " + " = '" + primaryKey + "'";
							System.out.println(Linequery);
							LineMap=new DBUtilsTemp().getMultiRowsFromPreparedQuery(
					                "oracleDB", Linequery, data.get("PRIMARY_KEY1"));
						}
					
						//softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " not found");
					}
					else {
						if(columnKey.contains("PROCEDURE_CODE")){
							
							logger.log(LogStatus.INFO, "Line"+LineCount +"validations started: " );
							LineCount++;
						}
						
						fileValue = rowMap.get(columnKey);
						//String dbValue = "";
						//Retrieving value from database for each of the keys				
						dbValue = LineMap.get(primaryKey).get(columnKey.toLowerCase());
						//System.out.println(columnKey);
						
						
						//Comparing source and target values to report in the logger
						if(fileValue.equalsIgnoreCase(dbValue)){
							String status="PASS";
							logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Actual (837 Output File) value: " + fileValue + " | Expected (Careware DB): " + dbValue + " >>");
							ExcelUtilsExtended.writeResultIntoExcel(rowno,primaryKey,Providerid,Subscriberid, columnKey, fileValue, dbValue,status);
						}
						else{
							String status1="FAIL";
							logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Actual (837 Output File) value: " + fileValue + " | Expected (careware DB): " + dbValue + " >>");
							ExcelUtilsExtended.writeResultIntoExcel(rowno,primaryKey,Providerid,Subscriberid, columnKey, fileValue, dbValue,status1);
						}
						//System.out.println(columnKey + ": " + fileValue + " | " + dbValue);
						
						}
					//softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " not found");
					}
					
					}
					
				
				
				//Reporting subscriber ID in HTML report when it is not loaded into FACETS
				catch(Exception e){
					logger.log(LogStatus.FAIL," This claim with patient Acc Number  (" + primaryKey + ") is NOT loaded into Careware");
					e.printStackTrace();
					
					softAssert.assertFalse(true, "This claim with patient Acc Number  (" + primaryKey + ") is NOT loaded into Careware");
			}
		}
			
		reportInit("837FileValidation ", "Record Counts:" );
		logger.log(LogStatus.INFO, "Total Providers Record Counts present in 837PLACARE output file:"+" "+ProviderCount );
		logger.log(LogStatus.INFO, "Total Subscribers Record Counts present in 837PLACARE output file:"+" "+SubscriberCount );
		logger.log(LogStatus.INFO, "Total Claim Record Counts present in 837PLACARE output file :"+" "+ClaimCount );
		logger.log(LogStatus.INFO, "Number of fields validated in one ST to SE Segment :"+FieldCount );	
		}

		
		/*The below lines are currently not being used since the report as not being generated in the expected format. Additional fields are still being added to the 834 validations.
		 * 
		 * MapDifference<String, SortedMap<String, String>> diff = getMapDiff(flatFileValuesMap, sql1Map);
		softAssert.assertTrue(diff.areEqual());*/

	

	
	/**
	 * //To run test method, this method will initiate the HTML report
	 * 
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {

		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();

	}

	private Map<String, String> getData(String testMethodName) throws Exception {
		Map<String, String> dataMap = new HashMap<String, String>();
		// assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, testMethodName);

		return dataMap;

	}

}
