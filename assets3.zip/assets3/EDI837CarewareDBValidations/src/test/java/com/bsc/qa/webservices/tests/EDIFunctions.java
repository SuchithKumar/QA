package com.bsc.qa.webservices.tests;

public class EDIFunctions {

}
