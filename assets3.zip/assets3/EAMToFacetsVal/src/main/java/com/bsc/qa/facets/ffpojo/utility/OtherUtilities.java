package com.bsc.qa.facets.ffpojo.utility;

import java.time.Month;
import java.util.Map;
import org.testng.asserts.SoftAssert;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
/*import java.lang.Object;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import org.testng.annotations.Test;*/

public class OtherUtilities extends BaseTest{
	// Validating in bound file and FACETS database column values
	public static void validate(Map<String, String> sourceDataMap,	Map<String, String> queryDataMap,SoftAssert softAssertion) {
		//SoftAssert softAssertion= new SoftAssert();
		for(String key:queryDataMap.keySet()){			
			
			
			if(sourceDataMap.containsKey(key)){ 
				
								
				
				OtherUtilities.validateActualAndExpectedValues(key,sourceDataMap.get(key),queryDataMap.get(key),softAssertion);
				
			}else{
				 softAssertion.assertTrue(sourceDataMap.containsKey(key), "Element " + key + " is not present" );
				 logger.log(LogStatus.INFO, key+" is not present Input File");
			}			
		}		
	}


	
	
	// Validating in bound file and FACETS database column values 
	private static void validateActualAndExpectedValues(String key,String dbvalue1,String dbValue,SoftAssert softAssertion) {
		String strFlatFileDate = "";
		String strdbValue = "";
		String strflatFileValue = "";
		if(dbvalue1 != null )	{
			dbvalue1 = dbvalue1.trim();
			}
			if(dbvalue1 == null)
				dbvalue1 = "";	
		if(dbValue != null )	{
		dbValue = dbValue.trim();
		}
		if(dbValue == null)
			dbValue = "";
		switch (key){
			//	Validating MEMBERBIRTHDATE field value in In bound file and FACETS Database
			case "MEMBERBIRTHDATE":
				String strDate;
				if(dbvalue1 != null && dbvalue1.length()>0){
					strDate = dbvalue1.substring(0,10);
				}else{
					strDate = dbvalue1;
				}
				assertContainLogger(key, strDate, dbValue, softAssertion);
				//softAssertion.assertTrue(dbValue.contains(strDate), " << Field name: " + key + " | MAM db value: " + strDate + " | Facets db value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strDate+ "---------------Facets db value: " + dbValue));
				break;
			case "EFFECTIVEDATE":
				String effDate;
				if(dbvalue1 != null && dbvalue1.length()>0){
					effDate = dbvalue1.substring(0,8);
				}else{
					effDate = dbvalue1;
				}
				assertContainLogger(key, effDate, dbValue, softAssertion);
				//softAssertion.assertTrue(dbValue.contains(strDate), " << Field name: " + key + " | MAM db value: " + strDate + " | Facets db value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strDate+ "---------------Facets db value: " + dbValue));
				break;
			//Validating OEC_InsertedWhen,SubmitDate field values in In bound file and FACETS Database
			case "OEC_INSERTEDWHEN":
			case "SUBMITDATE":
				if(dbValue != null && dbValue.length()>0){
					strdbValue = dbValue.substring(5,7) + dbValue.substring(8,10) + dbValue.substring(0,4); 
				}
				assertEqualLogger(key, dbvalue1, strdbValue, softAssertion);
				//softAssertion.assertEquals(flatFileValue,strdbValue, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + strdbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Facets db value: " + strdbValue));
				break;
			//Validating MedicarePartA,MedicarePartA field values in In bound file and FACETS Database
			case "MEDICAREPARTA":
			case "MEDICAREPARTB":
				if(dbvalue1 != null && dbvalue1.length()>0){
					strFlatFileDate = "01-" + (Month.of(Integer.parseInt(dbvalue1.substring(0,2))).name().substring(0,3)) + "-"+ dbvalue1.substring(4);
				}
				if(dbValue != null && dbValue.length()>0){
					strdbValue = dbValue.substring(8,10) + "-" + (Month.of(Integer.parseInt(dbValue.substring(5,7))).name().substring(0,3)) + "-"+ dbValue.substring(2,4);
				}
				assertEqualLogger(key, strFlatFileDate, strdbValue, softAssertion);
				//softAssertion.assertEquals(strFlatFileDate,strdbValue, " << Field name: " + key + " | MAM db value: " + strflatFileValue + " | Facets db value: " + strdbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strFlatFileDate+ "---------------Facets db value: " + strdbValue));
				break;
			//Validating SubmitTime field value in In bound file and FACETS Database				
			case "SUBMITTIME":
				/*if(flatFileValue != null && flatFileValue.length()>0)
				strFlatFileDate = flatFileValue.substring(0,19);
				if(dbValue != null && dbValue.length()>0)
				strdbValue = dbValue.substring(0,19) ;*/
				
				/*if(flatFileValue != null && flatFileValue.length()>0)
					
		
				softAssertion.assertEquals(strFlatFileDate,strdbValue, " << Field name: " + key + " | MAM db value: " + strFlatFileDate + " | Facets db value: " + strdbValue + " >>");
				logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strFlatFileDate+ "---------------Facets db value: " + strdbValue));*/
				break;
			case "SUBSIDYPERCENTAGE":
				break;
			
			//Validating AgencyID field value in In bound file and FACETS Database				
			case "AGENCYID":
				if(dbvalue1 != null && dbvalue1.length()>0){
					strflatFileValue = dbvalue1.replaceAll("[^a-zA-Z0-9]","");
				}
				assertEqualLogger(key, strflatFileValue, dbValue, softAssertion);
				//softAssertion.assertEquals(strflatFileValue,dbValue, " << Field name: " + key + " | MAM db value: " + strflatFileValue + " | Facets db value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strflatFileValue+ "---------------Facets db value: " + dbValue));
				break;
			//Validating ApplicantSSN field value in In bound file and FACETS Database				
			case "APPLICANTSSN":
				if(dbvalue1 != null && dbvalue1.length()>0)
				strflatFileValue = dbvalue1.replaceAll("[^a-zA-Z0-9]","");
				assertEqualLogger(key, strflatFileValue, dbValue, softAssertion);
				//softAssertion.assertEquals(strflatFileValue,dbValue, " << Field name: " + key + " | MAM db value: " + strflatFileValue + " | Facets db value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strflatFileValue+ "---------------Facets db value: " + dbValue));
				break;
			//Validating PremiumWithhold field value in In bound file and FACETS Database	
			case "PREMIUMWITHHOLD":
				if (dbvalue1.equalsIgnoreCase(dbValue)){
					assertEqualLogger(key, dbvalue1, dbValue, softAssertion);
					//softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
					//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Facets db value: " + dbValue));
				}else if (dbvalue1.equalsIgnoreCase("")){
					logger.log(LogStatus.PASS," Key Name: " + key + " Inbound File Value: " +(dbvalue1+ "---------------Facets db value:  "));
				}else{
					assertFailLogger(key, dbvalue1, dbValue, softAssertion);
					//softAssertion.assertTrue(false, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");			
					//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Facets db value: " + dbValue));
				}
				break;
				//Validating PRIMARYCAREPHYSICIAN field value in In bound file and FACETS Database	
			case "PRIMARYCAREPHYSICIAN":
				if (dbvalue1.contains(","))
					dbvalue1 = dbvalue1.replace(",", "");
				if (dbvalue1.contains("."))
					dbvalue1 = dbvalue1.replace(".", "");
				if (dbValue.contains(","))
					dbValue = dbValue.replace(",", "");
				if (dbValue.contains("."))
					dbValue = dbValue.replace(".", "");
				assertContainLogger(key, dbvalue1, dbValue, softAssertion);
				//softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");			
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Facets db value: " + dbValue));
			
				break;
			default:
				// Changing flat file value to "Y" instead of "Yes"
				if (dbvalue1!= null && dbvalue1.equalsIgnoreCase("Yes") ) {			
					dbvalue1="Y";			
				}			
				// Changing flat file value to "N" instead of "No"
				else if (dbvalue1!= null && dbvalue1.equalsIgnoreCase("No")) {		
					dbvalue1="N";
				}
				// Added this code based on the front end portal new requirement
				if(dbValue.equalsIgnoreCase("N") && dbvalue1.equalsIgnoreCase("")){
					dbValue="";
				}
				
				assertEqualLogger(key, dbvalue1, dbValue, softAssertion);
				//softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
				break;
				
				
		}
	
	}

	
	
	public static void assertEqualLogger(String key, String flatFileValue, String dbValue,SoftAssert softAssertion ){
		
		softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
		if(flatFileValue.equalsIgnoreCase(dbValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
		}
	}
	
	public static void assertContainLogger(String key, String flatFileValue, String dbValue,SoftAssert softAssertion ){
		
		softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
		if(dbValue.contains(flatFileValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
		}
	}
	
	public static void assertFailLogger(String key, String flatFileValue, String dbValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(false, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
		
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | MAM db value: " + flatFileValue + " | Facets db value: " + dbValue + " >>");
	}

//To print the test case details in the logger
	public static void printTestCaseDeatilsInReport(Map<String, String> data) {		
		
		String strSUCName= data.get("SUC Name").toString();		
		String strTestCaseId = data.get("Test Case ID").toString();		
		String strTestCaseName = data.get("Test Case Name").toString();		
		String strStepNumber = data.get("Step Number").toString();
		//String strInputFileName = data.get("Input File Name").toString();
		logger.log(LogStatus.INFO," SUC Name: " + strSUCName + ", Test Case ID: " + strTestCaseId + ", Test Case Name: " + strTestCaseName + ", Step Number:" + strStepNumber);
		//logger.log(LogStatus.INFO," Input File Name: " + strInputFileName);
	}
	


	
	
	//below method is to check whether the given number is numeric or not
		public static boolean isNumeric(String str) {
		    int size = str.length();
		    for (int i = 0; i < size; i++) {
		        if (!Character.isDigit(str.charAt(i))) {
		            return false;
		        }
		    }

		    return size > 0;
		} 

}
