package com.bsc.qa.facets.tests;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.relevantcodes.extentreports.LogStatus;

public class BscaEAMtoFacetsTest extends BaseTest implements IHookable{
	public static String filePath;
    private static String sheetName;
	private static DBUtils objDBUtility;//Mandatory declaration 
	public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
	private static Path path;
	private static Path inputDataPath;
	private static String resultsDestinationFolderPath;
	private static	Map<String,String>sourceDataMap=new HashMap<String,String>();
	private static	Map<String,String>queryDataMap=new HashMap<String,String>();
	private static	List<Map<String,String>>listOfRecords=new ArrayList<Map<String,String>>();
	
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","ResultsDestinationFolderPath"}) //Note parrams order	
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String ResultsDestinationFolderPath){    //Args order matters should match to params order
		filePath=TestDataSheetLocation;
		System.out.println("TestDate Loc:"+TestDataSheetLocation);
		
		path = Paths.get("target\\Results\\"+timestamp);
		//public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
		 if(!Files.exists(path))
		{
		try {
			Files.createDirectories(path);
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
		
		
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		sheetName=NameOfTestDataSheet;		
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
			 
		
	}

	//************************************** TEST METHODS************************
		
	// Validating in bound file and FACETS database column values in SUC546265-DRX To MAM
	@Test(dataProvider = "masterDataProvider")
	private static void EAMtoFacetsValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			OtherUtilities.printTestCaseDeatilsInReport(data);
			
			//Retrieving data from test data sheet and storing data in variables
			String parameter1= data.get("Query parameter1").toString();
			logger.log(LogStatus.INFO, " Validating HICN number is: " + parameter1);			
								
			// Retrieving query from test data sheet and replacing parameter value with HICN number
			String queryFromDataSheet = data.get("SqlQuery").toString();
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim());
			System.out.println("Source Query: "+SQLQuery);
		
			listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
			sourceDataMap=listOfRecords.get(0);//First element of list
			
						
			// Retrieving query from test data sheet and replacing parameter value with HICN number
			String queryFromDataSheet1 = data.get("SqlQuery1").toString();
			String	SQLQuery1=queryFromDataSheet1.replace( "Parameter1",parameter1.trim());
			System.out.println("Target Query: "+SQLQuery1);
		
			listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery1);//queryDataMap
			queryDataMap=listOfRecords.get(0);//First element of list
			
			System.out.println("Source Map:"+sourceDataMap);
			System.out.println("Query Dat map: "+queryDataMap);
			
			//Validating source map and target map using soft assertion
			OtherUtilities.validate(sourceDataMap,queryDataMap,softAssertion);
			 } catch (Exception e){
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					logger.log(LogStatus.INFO," Test Case Failed due to Exception.....!!");
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
				
	}
	
//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{
		
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, sheetName);
		  Object[][] testDataArray= 	  ExcelUtils.getTableArray(filePath, sheetName);
		  List<Object> list=new ArrayList<Object>();
		  
		  int noOfTestCases=0;
		 String runMode="Y";
		  for(int row=0;row<=testDataArray.length-1;row++){
			  
			if(method.getName().equalsIgnoreCase(testDataArray[row][2].toString())&& runMode.equalsIgnoreCase(testDataArray[row][10].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++){
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);
				//data[row][0]=rowDataMap;
				
			}
		}
		  
		  Object[][] data = new Object[noOfTestCases][1];
		  for(int row=0;row<list.size();row++){
			  data[row][0]=list.get(row);
		  }
		//data = new Object[][] { { list.get(0) },{ list.get(1) },{ list.get(2) }  };
		//System.out.println("Balu data:"+data[2][0]);
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		ReportFactory.closeReport();
	}
	
	@AfterMethod
	public void afterMethod() throws IOException{
		inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		/*File srcDir = new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory*/
	}
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
			try {
			
			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
	//-----			TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files
			
			
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	  }
	
	  
}
