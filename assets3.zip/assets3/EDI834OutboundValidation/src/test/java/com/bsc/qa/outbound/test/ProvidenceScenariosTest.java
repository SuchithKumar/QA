package com.bsc.qa.outbound.test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.bqsa.AutomationStringUtilities;
import com.bsc.qa.outbound.db.DatabaseQueries;
import com.bsc.qa.outbound.pojo.Connection;
import com.bsc.qa.outbound.pojo.DatabaseData;
import com.bsc.qa.outbound.pojo.EDIFields;
import com.bsc.qa.outbound.pojo.HeaderFields;
import com.bsc.qa.outbound.report.factory.BaseTest;
import com.bsc.qa.outbound.util.FileParse;
import com.bsc.qa.outbound.util.HibernateUtil;
import com.relevantcodes.extentreports.LogStatus;

public class ProvidenceScenariosTest extends BaseTest implements IHookable {

	List<EDIFields> family;
	HeaderFields header;
	String filename;
	int stcount, secount;
	Map<String, Boolean> tpa, ipa;
	Connection conn = new Connection();
	SessionFactory factory;
	Session session;
	EDIFields filedata;
	DatabaseData dbdata;
	List<DatabaseData> dblist;
	String generationDate;

	@BeforeSuite
	public void beforeSuite() {
		String oracleUser = System.getenv("FACETS_USER");
		String oraclePassword = System.getenv("FACETS_PASSWORD");
		String oracleServer = System.getenv("FACETS_SERVER");
		String oraclePort = System.getenv("FACETS_PORT");
		String oracleDB = System.getenv("FACETS_DB");
		String oracleUrl = "jdbc:oracle:thin:@" + oracleServer + ":"
				+ oraclePort + ":" + oracleDB;
		// conn.setUsername(AutomationStringUtilities.decryptValue(oracleUser));
		// conn.setPassword(AutomationStringUtilities.decryptValue(oraclePassword));
		conn.setUrl(oracleUrl);
		conn.setUsername(oracleUser);
		conn.setPassword(oraclePassword);
		factory = HibernateUtil.createSessionFactory(conn);
		session = factory.openSession();
	}

	@AfterSuite
	public void closeConnection() {
		if (session != null) {
			session.close();
			factory.close();
			System.out.println("DB Connection Succesfully closed!");
		}
	}

	@BeforeTest
	public void getData() {
		FileParse parse = new FileParse();
		family = parse.getMemberFamily();
		System.out.println("family list" + family.size());
		header = parse.getHeader();
		filename = parse.inputFile.getName();
		DatabaseQueries queries = new DatabaseQueries();
		dblist = queries.getDatabaseData(family, session);
		generationDate = "20"
				+ new SimpleDateFormat("yyMMdd").format(new Date(Integer
						.parseInt(header.getIsa09().substring(0, 2)), (Integer
						.parseInt(header.getIsa09().substring(2, 4)) - 1),
						Integer.parseInt(header.getIsa09().substring(4, 6))));
		System.out.println("Date  " + generationDate);
		System.out.println(filename);
		tpa = parse.tpamap;
		ipa = parse.ipamap;
		// System.out.println("Database new value----"+dblist.get(0).getCSPI_EFF_DT());
	}

	// TC230
	//Validation of Eligibilty Effective Date with Class Plan Effective Date
	/**
	 * Test Class to validate Eligibilty Effective Date with Class Plan Effective Date
	 * @param fileObject
	 * @param databaseObject
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "effectiveDate")
	public void testEffectiveDate(EDIFields file, DatabaseData data, String ssn,
			String email) {
		boolean status = false;
		
		if (file.getDtp03_2().equalsIgnoreCase(data.getCSPI_EFF_DT())) {
			status = true;
			
		}
		assertTrue(status);
	}
	
	@DataProvider
	public Object[][] effectiveDate() {
		Object[][] object = new Object[family.size()][4];
		for (int i = 0; i < family.size(); i++) {
			object[i][0] = family.get(i);
			object[i][1] = dblist.get(i);
			object[i][2] = family.get(i).getNm109_1();
			object[i][3] = family.get(i).getEmail();
		}
		return object;
	}

	// TC226
	//Validation of ISA and GS Segments
	@Test
	public void testISA_GSSegements() {
		boolean status = false;
		if (header.getIsa01().trim().equalsIgnoreCase("00")
				&& header.getIsa02().trim().equalsIgnoreCase("")
				&& header.getIsa03().trim().equalsIgnoreCase("00")
				&& header.getIsa04().trim().equalsIgnoreCase("")
				&& header.getIsa05().trim().equalsIgnoreCase("30")
				&& header.getIsa06().trim().equalsIgnoreCase("940360524")
				&& header.getIsa07().trim().equalsIgnoreCase("ZZ")
				&& header.getIsa08().trim().equalsIgnoreCase("TPROV")
				&& header.getIsa11().trim().equalsIgnoreCase("^")
				&& header.getIsa12().trim().equalsIgnoreCase("00501")
				&& header.getIsa13().trim()
						.equalsIgnoreCase(header.getIea02().trim())
				&& header.getIsa14().trim().equalsIgnoreCase("0")
				&& header.getIsa15().trim().equalsIgnoreCase("T")
				&& header.getIsa16().trim().equalsIgnoreCase(":")
				&& header.getGs01().trim().equalsIgnoreCase("BE")
				&& header.getGs02().trim().equalsIgnoreCase("1582")
				&& header.getGs03().trim()
						.equalsIgnoreCase(header.getIsa08().trim())
				&& header.getGs04().trim()
						.equalsIgnoreCase("20" + header.getIsa09().trim())
				&& header.getGs05().trim()
						.equalsIgnoreCase(header.getIsa10().trim())
				&& header.getGs06().trim()
						.equalsIgnoreCase(header.getIsa13().trim())
				&& header.getGs07().trim().equalsIgnoreCase("X")
				&& header.getGs08().trim().equalsIgnoreCase("005010X220A1")) {
			status = true;
		}

		
		assertTrue(status);
	}

	
	// TC222
	//Verification of Payer Name
	@Test
	public void testPayerName() {
		String file=header.getN102_2();
		String data="BLUE SHIELD OF CA";
		
		assertEquals(file, data, "Payer Name: File Value: "
				+ file + " Default Value: " + data);
	}


	// Sponsor name
	// TC223
	@Test
	public void testSponsorName() {
		String file=header.getN102_1();
		String data=dblist.get(0).getGRGR_NAME();
		
		assertEquals(file, data, "Sponsor Name: File Value: "
				+ file + " Default Value: " + data);
	}

	

	// DTP*007
	// TC224
	//Verification of Segment Date
	@Test
	public void testSegementDate() {
		String file=header.getDtp03_1();
		String data=generationDate;
		
		assertEquals(file, data,"Segment Date: File Value: "
				+ file + "Generation Date: " + data);
	}
	
	

	// IPA-TPA
	// TC225
	/**
	 * Test Class to validate TPA/IPA Segments
	 * @param fileObject
	 * @param databaseObject
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "tpa_ipa")
	public void testTPA_IPA(EDIFields file, DatabaseData data, String ssn,
			String email) {
		boolean status = true;
		if (tpa.containsKey(file.getNm109_1())) {
			status = false;
			

		} 
			
		if (ipa.containsKey(file.getNm109_1())) {
			status = false;
			
		} 
			
		assertTrue(status);
		
	}
	
	@DataProvider
	public Object[][] tpa_ipa() {
		Object[][] object = new Object[family.size()][4];
		for (int i = 0; i < family.size(); i++) {
			object[i][0] = family.get(i);
			object[i][1] = dblist.get(i);
			object[i][2] = family.get(i).getNm109_1();
			object[i][3] = family.get(i).getEmail();
		}
		return object;
	}

	// planid
	// TC228
	//Validation of Plan ID
	/**
	 * Test Class to validate Plan ID
	 * @param planIDFileValue
	 * @param planIDDBValue
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "planid")
	public void testPlanID(String file, String data, String ssn, String email) {
		
		assertEquals(file, data,"Plan ID: Actual <b>" + file
				+ "</b> | Expected- <b>" + data + "</b>");
	}
	
	@DataProvider
	public Object[][] planid() {
		Object[][] object = new Object[family.size()][4];
		for (int i = 0; i < family.size(); i++) {
			object[i][0] = family.get(i).getHd04();
			object[i][1] = dblist.get(i).getCSPI_ID();
			object[i][2] = family.get(i).getNm109_1();
			object[i][3] = family.get(i).getEmail();
		}
		return object;
	}

	// alpha prefix + Facets subscriber ID
	// TC229
	//Validation of REF02 (CSPI_ITS_PREFIX + SBSB_ID) Segment
	/**
	 * Test Class to validate REF02 (CSPI_ITS_PREFIX + SBSB_ID) Segment
	 * @param ref02SegmentValue
	 * @param dbValue
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "ref02")
	public void testRef02Segment(String file, String db, String ssn, String email) {
		
		assertEquals(file, db,"REF02: Actual <b>" + file
				+ "</b> | Expected- <b>" + db + "</b>");
	}
	
	@DataProvider
	public Object[][] ref02() {
		Object[][] object = new Object[family.size()][4];
		for (int j = 0; j < family.size(); j++) {
			object[j][3] = family.get(j).getEmail();

			object[j][0] = family.get(j).getRef02_4();
			object[j][1] = dblist.get(j).getCSPI_ITS_PREFIX()
					+ dblist.get(j).getSBSB_ID();
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	// Class_ID
	// TC227
	//Validation of Class ID
	/**
	 * Test Class to validate Class ID
	 * @param classIdFileValue
	 * @param classIdDbValue
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "classID")
	public void testClassID(String file, String db, String ssn, String email) {
		
		assertEquals(file, db,"Class ID: Actual <b>" + file
				+ "</b> | Expected- <b>" + db + "</b>");
	}
	
	@DataProvider
	public Object[][] classID() {
		Object[][] object = new Object[family.size()][4];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getRef02_3();
			object[j][1] = dblist.get(j).getCSCS_ID();
			object[j][2] = family.get(j).getRef02_1();
			object[j][3] = family.get(j).getEmail();
		}
		return object;
	}

	
	// TC221
	// Validation of Plan Information (HD Segment)
	/**
	 * Test Class to Validate Plan Information
	 * @param fileObject
	 * @param databaseObject
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "hdSegment")
	public void testPlanInformation(EDIFields file, DatabaseData db, String ssn, String email) {
		String cat;
		boolean status = false;
		if (db.getCSPD_CAT().equalsIgnoreCase("M"))
			cat = "HLT";
		else if (db.getCSPD_CAT().equalsIgnoreCase("D")
				|| db.getCSPD_CAT().equalsIgnoreCase("E")
				|| db.getCSPD_CAT().equalsIgnoreCase("F")
				|| db.getCSPD_CAT().equalsIgnoreCase("G"))
			cat = "DEN";
		else if (db.getCSPD_CAT().equalsIgnoreCase("V")
				|| db.getCSPD_CAT().equalsIgnoreCase("X"))
			cat = "VIS";
		else if (db.getCSPD_CAT().equalsIgnoreCase("L")
				|| db.getCSPD_CAT().equalsIgnoreCase("P")
				|| db.getCSPD_CAT().equalsIgnoreCase("S")
				|| db.getCSPD_CAT().equalsIgnoreCase("T")
				|| db.getCSPD_CAT().equalsIgnoreCase("C"))
			cat = "LIF";
		else if (db.getCSPD_CAT().equalsIgnoreCase("R"))
			cat = "PDG";
		else
			cat = " ";
		System.out.println("Category " + cat + " " + ssn);
		System.out.println(file.getHd05());
		if (file.getHd01().equalsIgnoreCase("030")
				&& file.getHd03().equalsIgnoreCase(cat)
				&& file.getHd04().equalsIgnoreCase(db.getCSPI_ID())
				&& file.getHd05().equalsIgnoreCase(file.getHd05())) {
			status = true;
		}
		
		// try {
		assertTrue(status);
		// } catch (Error e) {
		// logger.log(LogStatus.FAIL, " Not" +e.getMessage());
		//
		// }

	}
	
	@DataProvider
	public Object[][] hdSegment() {
		Object[][] object = new Object[family.size()][4];
		for (int j = 0; j < family.size(); j++) {
			object[j][0] = family.get(j);

			object[j][1] = dblist.get(j);
			object[j][2] = family.get(j).getNm109_1();
			object[j][3] = family.get(j).getEmail();
		}
		return object;
	}
	/**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		 reportInit(testResult.getTestContext().getName(),
		 testResult.getName());
		softAssert = new SoftAssert();
		 logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}
}
