package com.bsc.qa.outbound.test;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.outbound.db.DatabaseQueries;
import com.bsc.qa.outbound.pojo.Connection;
import com.bsc.qa.outbound.pojo.DatabaseData;
import com.bsc.qa.outbound.pojo.EDIFields;
import com.bsc.qa.outbound.pojo.HeaderFields;
import com.bsc.qa.outbound.report.factory.BaseTest;
import com.bsc.qa.outbound.util.FileParse;
import com.bsc.qa.outbound.util.HibernateUtil;
import com.relevantcodes.extentreports.LogStatus;

public class SilverSneakersTest extends BaseTest implements IHookable {
	List<EDIFields> termedmemberlist = new ArrayList<EDIFields>();
	List<DatabaseData> termedmemberdblist = new ArrayList<DatabaseData>();
	List<EDIFields> family, mapdFamily, medssupFamily;
	HeaderFields header;
	String filename;

	Connection conn = new Connection();
	SessionFactory factory;
	Session session;
	EDIFields filedata;
	List<DatabaseData> dblist;
	List<String> rowsList;

	@BeforeSuite
	public void beforeSuite() {
		String oracleUser = System.getenv("FACETS_USER");
		String oraclePassword = System.getenv("FACETS_PASSWORD");
		String oracleServer = System.getenv("FACETS_SERVER");
		String oraclePort = System.getenv("FACETS_PORT");
		String oracleDB = System.getenv("FACETS_DB");
		String oracleUrl = "jdbc:oracle:thin:@" + oracleServer + ":"
				+ oraclePort + ":" + oracleDB;
		System.out.println("Inside Test Suite");
		// conn.setUsername(AutomationStringUtilities.decryptValue(oracleUser));
		// conn.setPassword(AutomationStringUtilities.decryptValue(oraclePassword));
		conn.setUrl(oracleUrl);
		conn.setUsername(oracleUser);
		conn.setPassword(oraclePassword);
		factory = HibernateUtil.createSessionFactory(conn);
		session = factory.openSession();
	}

	@AfterSuite
	public void closeConnection() {
		if (session != null) {
			session.close();
			factory.close();
			System.out.println("DB Connection Succesfully closed!");
		}
	}

	@BeforeTest
	public void getData() throws IOException {
		FileParse parse = new FileParse();
		family = parse.getMemberFamily();
		mapdFamily = parse.getMADPMemberFamily();
		medssupFamily = parse.getMedssupMemberFamily();
		header = parse.getHeader();
		rowsList = parse.parseFile();

		filename = parse.inputFile.getAbsolutePath();
		DatabaseQueries queries = new DatabaseQueries();
		// dblist = queries.getDatabaseData(family, session);

		// System.out.println("dblist size------"+dblist.size());
	}

	@Test()
	public void benefitPlanCodeTest() {
		boolean status = true;
		// System.out.println("ssn "+ssn);
		reportInit("EUP_Regression Test_834_Benefit Plan Code_TC105  ::", "");

		// status = true;
		logger.log(LogStatus.INFO, "Starting Test: ");
		logger.log(LogStatus.INFO, "File Path: " + filename);
		logger.log(LogStatus.PASS, "MAPD Member Information ");

		for (int i = 0; i < mapdFamily.size(); i++) {

			logger.log(LogStatus.PASS, "Group Id : "
					+ mapdFamily.get(i).getRef02_2());
			logger.log(LogStatus.PASS, "Member ID : "
					+ mapdFamily.get(i).getRef02_4() + " | Member Suffix : "
					+ mapdFamily.get(i).getRef02_1().substring(10));
			logger.log(LogStatus.PASS, "Last Name : "
					+ mapdFamily.get(i).getNm103_1() + " | First Name : "
					+ mapdFamily.get(i).getNm104_1());
			logger.log(LogStatus.PASS, "Effective Date : "
					+ mapdFamily.get(i).getDtp03_2() + " | Termination Date: "
					+ mapdFamily.get(i).getDtp03_3());

			logger.log(LogStatus.PASS, "");
		}

		// status = true;

		assertTrue(status);
	}

	/*
	 * @DataProvider public Object[][] benifitPlanCode() throws ParseException {
	 * Object[][] object = new Object[mapdFamily.size()][3];
	 * 
	 * for (int j = 0; j < mapdFamily.size(); j++) { object[j][2] =
	 * family.get(j).getEmail(); object[j][0] = family.get(j); //object[j][1] =
	 * dblist.get(j); object[j][1] = family.get(j).getRef02_4();
	 * 
	 * } return object; }
	 */

	@Test()
	public void benefitPlanCodeMedssupTest() {
		boolean status = true;
		// System.out.println("ssn "+ssn);
		reportInit("EUP_Regression Test_834_Benefit Plan Code_TC105  ::", "");

		// status = true;
		logger.log(LogStatus.INFO, "Starting Test: ");
		logger.log(LogStatus.INFO, "File Path: " + filename);
		logger.log(LogStatus.PASS, "Medssup Member Information ");

		for (int i = 0; i < medssupFamily.size(); i++) {

			logger.log(LogStatus.PASS, "Group Id : "
					+ medssupFamily.get(i).getRef02_2());
			logger.log(LogStatus.PASS, "Member ID : "
					+ medssupFamily.get(i).getRef02_4() + " | Member Suffix : "
					+ medssupFamily.get(i).getRef02_1().substring(10));
			logger.log(LogStatus.PASS, "Last Name : "
					+ medssupFamily.get(i).getNm103_1() + " | First Name : "
					+ medssupFamily.get(i).getNm104_1());
			logger.log(LogStatus.PASS, "Effective Date : "
					+ mapdFamily.get(i).getDtp03_2() + " | Termination Date: "
					+ mapdFamily.get(i).getDtp03_3());

			logger.log(LogStatus.PASS, "");
		}

		// status = true;

		assertTrue(status);
	}

	/*
	 * @DataProvider public Object[][] benifitPlanCodeMedssup() throws
	 * ParseException { Object[][] object = new Object[medssupFamily.size()][3];
	 * 
	 * for (int j = 0; j < medssupFamily.size(); j++) { object[j][2] =
	 * family.get(j).getEmail(); object[j][0] = family.get(j); //object[j][1] =
	 * dblist.get(j); object[j][1] = family.get(j).getRef02_4();
	 * 
	 * } return object; }
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		// reportInit(testResult.getTestContext().getName(),
		// testResult.getName());
		softAssert = new SoftAssert();
		// logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}
}
