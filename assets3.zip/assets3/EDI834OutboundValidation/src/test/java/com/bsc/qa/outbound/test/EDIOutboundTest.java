package com.bsc.qa.outbound.test;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.outbound.db.DatabaseQueries;
import com.bsc.qa.outbound.pojo.Connection;
import com.bsc.qa.outbound.pojo.DatabaseData;
import com.bsc.qa.outbound.pojo.EDIFields;
import com.bsc.qa.outbound.pojo.HeaderFields;
import com.bsc.qa.outbound.report.factory.GenericBaseTest;
import com.bsc.qa.outbound.util.FileParse;
import com.bsc.qa.outbound.util.HibernateUtil;
import com.relevantcodes.extentreports.LogStatus;

public class EDIOutboundTest extends GenericBaseTest implements IHookable {
	List<EDIFields> family;
	HeaderFields header;
	String filename;
	int stcount, secount, sbsb_count, dep_count;
	boolean tpa, ipa;
	Connection conn = new Connection();
	SessionFactory factory;
	Session session;
	String file_type;
	List<DatabaseData> dblist;
	List<String> rowsList;

	@BeforeSuite
	public void beforeSuite() {
		String oracleUser = System.getenv("FACETS_USER");
		String oraclePassword = System.getenv("FACETS_PASSWORD");
		String oracleServer = System.getenv("FACETS_SERVER");
		String oraclePort = System.getenv("FACETS_PORT");
		String oracleDB = System.getenv("FACETS_DB");
		String oracleUrl = "jdbc:oracle:thin:@" + oracleServer + ":"
				+ oraclePort + ":" + oracleDB;
		//conn.setUsername(AutomationStringUtilities.decryptValue(oracleUser));
		//conn.setPassword(AutomationStringUtilities.decryptValue(oraclePassword));
		conn.setUrl(oracleUrl);
		conn.setUsername(oracleUser);
	   conn.setPassword(oraclePassword);
				

		factory = HibernateUtil.createSessionFactory(conn);
		session = factory.openSession();
	}

	@BeforeTest
	public void getData() throws IOException {
		FileParse parse = new FileParse();
		family = parse.getMemberFamily();
		header = parse.getHeader();
		filename = parse.inputFile.getAbsolutePath();
		DatabaseQueries queries = new DatabaseQueries();
		sbsb_count = parse.getSubscriberCount();
		dep_count = parse.getDependentCount();
		dblist = queries.getDatabaseData(family, session);
		rowsList = parse.parseFile();
		file_type = parse.getFileType();
		System.out.println(file_type + " File bhvchs");
	}

	@AfterTest
	public void afterTest() {
		System.out.println("Term Date" + dblist.get(0).getMEPE_TERM_DT());
		session.clear();
		session.close();
	}

	// Header
	@Test
	public void testHeader() {
		boolean status = false;
		reportInit("834OutboundValidation :", "Header Validation ");
		logger.log(LogStatus.INFO, "Starting Test: ");
		logger.log(LogStatus.INFO, "File Path: " + filename);
		logger.log(LogStatus.PASS, "ISA01: Actual- <b>"
				+ header.getIsa01().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "ISA02: Actual- <b>"
				+ header.getIsa02().trim() + "</b> | Expected- <b></b>");
		logger.log(LogStatus.PASS, "ISA03: Actual- <b>"
				+ header.getIsa03().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "ISA04: Actual- <b>"
				+ header.getIsa04().trim() + "</b> | Expected- <b></b>");
		logger.log(LogStatus.PASS, "ISA05: Actual- <b>"
				+ header.getIsa05().trim() + "</b> | Expected- <b>30</b>");
		if (file_type.equalsIgnoreCase("COO"))
			logger.log(LogStatus.PASS, "Sender's Federal Tax ID: Actual- <b>"
					+ header.getIsa06().trim()
					+ "</b> | Expected- <b>CATAMARAN</b>");
		else if (file_type.equalsIgnoreCase("PROV"))
			logger.log(LogStatus.PASS, "Sender's Federal Tax ID: Actual- <b>"
					+ header.getIsa06().trim()
					+ "</b> | Expected- <b>TPROV</b>");
		logger.log(LogStatus.PASS, "ISA07: Actual- <b>"
				+ header.getIsa07().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "Reciever's Federal Tax ID: Actual- <b>"
				+ header.getIsa08().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "RUN DATE: Actual- <b>"
				+ header.getIsa09().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "RUN TIME: Actual- <b>"
				+ header.getIsa10().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "ISA11: Actual- <b>"
				+ header.getIsa11().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "ISA12: Actual- <b>"
				+ header.getIsa12().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "ISA13: Actual- <b>"
				+ header.getIsa13().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "ISA14: Actual- <b>"
				+ header.getIsa14().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "ISA15: Actual- <b>"
				+ header.getIsa15().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "ISA16: Actual- <b>"
				+ header.getIsa16().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "GS01: Actual- <b>"
				+ header.getGs01().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "GS02: Actual- <b>"
				+ header.getGs02().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "GS03: Actual- <b>"
				+ header.getGs03().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "GS04: Actual- <b>"
				+ header.getGs04().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "GS05: Actual- <b>"
				+ header.getGs05().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "GS06: Actual- <b>"
				+ header.getGs06().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "GS07: Actual- <b>"
				+ header.getGs07().trim() + "</b> | Expected- <b>00</b>");
		logger.log(LogStatus.PASS, "ST01: Actual- <b>"
				+ header.getSt01().trim() + "</b> | Expected- <b>00</b>");

	}
	
	@Test
	public void testTrailer() {
		
		reportInit("834OutboundValidation :", "Trailer Validation ");
		logger.log(LogStatus.INFO, "Starting Test: ");
		logger.log(LogStatus.INFO, "File Path: " + filename);
		logger.log(LogStatus.PASS, "SE01: Actual- <b>"
				+ header.getSe01().trim() + "</b> | Expected- <b>"+(rowsList.size()-4)+"</b>");
		logger.log(LogStatus.PASS, "SE02: Actual- <b>"
				+ header.getSe02().trim() + "</b> | Expected- <b>"+header.getSt02()+"</b>");
		logger.log(LogStatus.PASS, "GE01: Actual- <b>"
				+ header.getGe01().trim() + "</b> | Expected- <b>1</b>");
		logger.log(LogStatus.PASS, "GE02: Actual- <b>"
				+ header.getGe02().trim() + "</b> | Expected- <b>"+header.getGs06()+"</b>");
		logger.log(LogStatus.PASS, "IEA01: Actual- <b>"
				+ header.getIea01().trim() + "</b> | Expected- <b>1</b>");
		logger.log(LogStatus.PASS, "IEA02: Actual- <b>"
				+ header.getIea02().trim() + "</b> | Expected- <b>"+header.getGs06()+"</b>");
	}

	// Member Details
	/**
	 * Test Class to validate Member Details
	 * @param fileObject
	 * @param databaseObject
	 *
	 */
	@Test(dataProvider = "memberDetails")
	public void testMemberDetails(EDIFields ediFields, DatabaseData dbData) {

		boolean status = false;
		reportInit("834OutboundValidation :",
				"Subscriber SSN" + ediFields.getNm109_1());
		logger.log(LogStatus.INFO, "Starting Test: ");
		logger.log(LogStatus.INFO, "File Path: " + filename);
		logger.log(LogStatus.INFO,
				"SSN used for validation is: " + ediFields.getNm109_1());
		if (dbData.getMEME_REL().equalsIgnoreCase("M")) {
			if (ediFields.getIns01().equalsIgnoreCase("Y")) {
				logger.log(LogStatus.PASS,
						"Field name: Member Relation | Flat file value: "
								+ ediFields.getIns01() + " | Database value:"
								+ "Y");
				status = true;
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: Member Relation | Flat file value: "
								+ ediFields.getIns01() + " | Database value:"
								+ "N");
				status = false;
			}
		} else {
			if (ediFields.getIns01().equalsIgnoreCase("N")) {
				logger.log(LogStatus.PASS,
						"Field name: Member Relation | Flat file value: "
								+ ediFields.getIns01() + " | Database value:"
								+ "N");
				status = true;
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: Member Relation | Flat file value: "
								+ ediFields.getIns01() + " | Database value:"
								+ "Y");
				status = false;
			}
		}
		if (dbData.getMEME_REL().equalsIgnoreCase("M")) {
			if (ediFields.getIns02().equalsIgnoreCase("18")) {
				logger.log(LogStatus.PASS,
						"Field name: Member Relation | Flat file value: "
								+ ediFields.getIns02() + " | Database value:"
								+ "18");
				status = true;
			} else {
				logger.log(
						LogStatus.FAIL,
						"Field name: Member Relation | Flat file value Does not match with the database value");
				status = false;
			}
		} else if (dbData.getMEME_REL().equalsIgnoreCase("H")
				|| dbData.getMEME_REL().equalsIgnoreCase("W")) {
			if (ediFields.getIns02().equalsIgnoreCase("01")) {
				logger.log(LogStatus.PASS,
						"Field name: Member Relation | Flat file value: "
								+ ediFields.getIns02() + " | Database value:"
								+ "01");
			} else {
				logger.log(
						LogStatus.FAIL,
						"Field name: Member Relation | Flat file value Does not match with the database value");
			}
		} else if (dbData.getMEME_REL().equalsIgnoreCase("S")
				|| dbData.getMEME_REL().equalsIgnoreCase("D")) {
			if (ediFields.getIns02().equalsIgnoreCase("19"))
				logger.log(LogStatus.PASS,
						"Field name: Member Relation | Flat file value: "
								+ ediFields.getIns02() + " | Database value:"
								+ "19");
			else
				logger.log(
						LogStatus.FAIL,
						"Field name: Member Relation | Flat file value Does not match with the database value");

		} else {
			if (file_type.equalsIgnoreCase("PROV")) {
				if (ediFields.getIns02().equalsIgnoreCase("G8")) {
					logger.log(LogStatus.PASS,
							"Field name: Member Relation | Flat file value: "
									+ ediFields.getIns02()
									+ " | Database value:" + "G8");
					status = true;
				} else {
					logger.log(
							LogStatus.FAIL,
							"Field name: Member Relation | Flat file value Does not match with the database value");
					status = false;
				}
			} else {
				if (ediFields.getIns02().equalsIgnoreCase("23")) {
					logger.log(LogStatus.PASS,
							"Field name: Member Relation | Flat file value: "
									+ ediFields.getIns02()
									+ " | Database value:" + "23");
					status = true;
				} else {
					logger.log(
							LogStatus.FAIL,
							"Field name: Member Relation | Flat file value Does not match with the database value");
					status = false;
				}

			}
		}
		if (file_type.equalsIgnoreCase("COO")) {
			if (ediFields.getRef02_1().equalsIgnoreCase(dbData.getMEME_SSN())) {
				logger.log(LogStatus.PASS,
						"Field name: Member SSN | Flat file value: "
								+ ediFields.getRef02_1() + " | Database value:"
								+ dbData.getMEME_SSN());
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: Member SSN | Flat file value: "
								+ ediFields.getRef02_1() + " | Database value:"
								+ dbData.getMEME_SSN());
				status = false;
			}
		} else if (file_type.equalsIgnoreCase("PROV")) {
			if (ediFields.getRef02_1().equalsIgnoreCase(dbData.getSBSB_ID())) {
				logger.log(LogStatus.PASS,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_1() + " | Database value:"
								+ dbData.getSBSB_ID());
				status = true;
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_1() + " | Database value:"
								+ dbData.getSBSB_ID());
				status = false;
			}
		}
		if (ediFields.getRef02_2().equalsIgnoreCase(dbData.getGRGR_ID())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Group Id | Flat file value: "
							+ ediFields.getRef02_2() + " | Database value:"
							+ dbData.getGRGR_ID());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Group Id | Flat file value: "
							+ ediFields.getRef02_2() + " | Database value:"
							+ dbData.getGRGR_ID());
			status = false;
		}
		if (ediFields.getRef02_3().equalsIgnoreCase(dbData.getCSCS_ID())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Class Id | Flat file value: "
							+ ediFields.getRef02_3() + " | Database value:"
							+ dbData.getCSCS_ID());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Class Id | Flat file value: "
							+ ediFields.getRef02_3() + " | Database value:"
							+ dbData.getCSCS_ID());
			status = false;
		}

		if (file_type.equalsIgnoreCase("COO")) {
			if (ediFields.getRef02_4().equalsIgnoreCase(
					"OCO" + dbData.getSBSB_ID() + "0" + dbData.getMEME_SFX())) {
				logger.log(
						LogStatus.PASS,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_4() + " | Database value:"
								+ "OCO" + dbData.getSBSB_ID() + "0"
								+ dbData.getMEME_SFX());
				status = true;

			} else {
				logger.log(
						LogStatus.FAIL,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_4() + " | Database value:"
								+ "OCO" + dbData.getSBSB_ID() + "0"
								+ dbData.getMEME_SFX());
				status = false;
			}
		} else if (file_type.equalsIgnoreCase("PROV")) {
			if (ediFields.getRef02_4().equalsIgnoreCase(
					dbData.getCSPI_ITS_PREFIX() + dbData.getSBSB_ID())) {
				logger.log(
						LogStatus.PASS,
						"Field name: ITS Prefix+Subscriber Id | Flat file value: "
								+ ediFields.getRef02_4() + " | Database value:"
								+ dbData.getCSPI_ITS_PREFIX()
								+ dbData.getSBSB_ID());
				status = true;
			} else {
				logger.log(
						LogStatus.FAIL,
						"Field name: ITS Prefix+Subscriber Id | Flat file value: "
								+ ediFields.getRef02_4() + " | Database value:"
								+ dbData.getCSPI_ITS_PREFIX()
								+ dbData.getSBSB_ID());
				status = false;
			}
		} else if (file_type.equalsIgnoreCase("Silver Sneakers")) {
			if (ediFields.getRef02_4().equalsIgnoreCase(dbData.getSBSB_ID())) {
				logger.log(LogStatus.PASS,
						"Field name: ITS Prefix+Subscriber Id | Flat file value: "
								+ ediFields.getRef02_4() + " | Database value:"
								+ dbData.getSBSB_ID());
				status = true;
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: ITS Prefix+Subscriber Id | Flat file value: "
								+ ediFields.getRef02_4() + " | Database value:"
								+ dbData.getSBSB_ID());
				status = false;
			}
		} else if (file_type.equalsIgnoreCase("Savemart")) {
			if (ediFields.getRef02_4().equalsIgnoreCase(dbData.getSBSB_ID())) {
				logger.log(LogStatus.PASS,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_4() + " | Database value:"
								+ dbData.getSBSB_ID());
				status = true;
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_4() + " | Database value:"
								+ dbData.getSBSB_ID());
				status = false;
			}
		}
		if (file_type.equalsIgnoreCase("COO")) {
			if (dbData.getCSPI_ID().equalsIgnoreCase("PPOX0001")) {
				logger.log(
						LogStatus.PASS,
						"Field name: Plan Id | Flat file value: "
								+ ediFields.getRef02_5() + " | Database value:"
								+ "2331WELLCHOICE");
				status = false;
			} else if (dbData.getCSPI_ID().equalsIgnoreCase("PPOX0003")) {
				logger.log(
						LogStatus.PASS,
						"Field name: Plan Id | Flat file value: "
								+ ediFields.getRef02_5() + " | Database value:"
								+ "2331RETIREES");
				status = true;
			} else {
				logger.log(
						LogStatus.FAIL,
						"Field name: Plan Id | Flat file value: "
								+ ediFields.getRef02_5() + " | Database value:"
								+ dbData.getCSPI_ID());
				status = false;
			}
		} else if (file_type.equalsIgnoreCase("PROV")) {
			if (ediFields.getRef02_5().equalsIgnoreCase(dbData.getSGSG_ID())) {
				logger.log(LogStatus.PASS,
						"Field name: ITS Prefix+Subscriber Id | Flat file value: "
								+ ediFields.getRef02_5() + " | Database value:"
								+ dbData.getSGSG_ID());
				status = true;
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: ITS Prefix+Subscriber Id | Flat file value: "
								+ ediFields.getRef02_5() + " | Database value:"
								+ dbData.getSGSG_ID());
				status = false;
			}
		}

		else if (file_type.equalsIgnoreCase("Silver Sneakers")) {
			if (ediFields.getRef02_5().equalsIgnoreCase(dbData.getSGSG_ID())) {
				logger.log(LogStatus.PASS,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_5() + " | Database value:"
								+ dbData.getSGSG_ID());
				status = true;
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_5() + " | Database value:"
								+ dbData.getSGSG_ID());
				status = false;
			}
		} else if (file_type.equalsIgnoreCase("Savemart")) {
			if (ediFields.getRef02_5().equalsIgnoreCase(dbData.getSGSG_ID())) {
				logger.log(LogStatus.PASS,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_5() + " | Database value:"
								+ dbData.getSGSG_ID());
				status = true;
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: Subscriber Id | Flat file value: "
								+ ediFields.getRef02_5() + " | Database value:"
								+ dbData.getSGSG_ID());
				status = false;
			}
		}
		/*if (ediFields.getRef02_6().equalsIgnoreCase(dbData.getMEME_HICN())) {
			logger.log(LogStatus.PASS,
					"Field name: Health Insurance Claim Number | Flat file value: "
							+ ediFields.getRef02_6() + " | Database value:"
							+ dbData.getMEME_HICN());
			status = true;
		} else {
			logger.log(LogStatus.FAIL,
					"Field name: Health Insurance Claim Number| Flat file value: "
							+ ediFields.getRef02_6() + " | Database value:"
							+ dbData.getMEME_HICN());
			status = false;
		}*/
		
		if (file_type.equalsIgnoreCase("Silver Sneakers")) {
			if (ediFields.getRef02_6().equalsIgnoreCase(dbData.getGRGR_NAME())) {
				logger.log(LogStatus.PASS,
						"Field name: Group Name | Flat file value: "
								+ ediFields.getRef02_p5() + " | Database value:"
								+ dbData.getGRGR_NAME());
				status = true;
			} else {
				logger.log(LogStatus.FAIL,
						"Field name: Group Name | Flat file value: "
								+ ediFields.getRef02_p5
								() + " | Database value:"
								+ dbData.getGRGR_NAME());
				status = false;
			}
		}
		if (ediFields.getDtp01_1().equalsIgnoreCase(
				dbData.getSBSB_ORIG_EFF_DT())) {
			logger.log(LogStatus.PASS,
					"Field name: Subscriber Effective Date | Flat file value: "
							+ ediFields.getDtp01_1() + " | Database value:"
							+ dbData.getSBSB_ORIG_EFF_DT());
			status = true;
		} else {
			logger.log(LogStatus.FAIL,
					"Field name: Subscriber Effective Date | Flat file value: "
							+ ediFields.getDtp01_1() + " | Database value:"
							+ dbData.getSBSB_ORIG_EFF_DT());
		}
		if (ediFields.getNm103_1().equalsIgnoreCase(dbData.getMEME_LAST_NAME())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Last Name | Flat file value: "
							+ ediFields.getNm101_1() + " | Database value:"
							+ dbData.getMEME_LAST_NAME());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Last Name | Flat file value: "
							+ ediFields.getNm101_1() + " | Database value:"
							+ dbData.getMEME_LAST_NAME());
		}
		if (ediFields.getNm104_1()
				.equalsIgnoreCase(dbData.getMEME_FIRST_NAME())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Last Name | Flat file value: "
							+ ediFields.getNm104_1() + " | Database value:"
							+ dbData.getMEME_FIRST_NAME());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Last Name | Flat file value: "
							+ ediFields.getNm104_1() + " | Database value:"
							+ dbData.getMEME_FIRST_NAME());
		}
		if (ediFields.getNm109_1().equalsIgnoreCase(dbData.getMEME_SSN())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Last Name | Flat file value: "
							+ ediFields.getNm109_1() + " | Database value:"
							+ dbData.getMEME_SSN());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Phone | Flat file value: "
							+ ediFields.getNm109_1() + " | Database value:"
							+ dbData.getMEME_SSN());
		}

		if (ediFields.getPer04().equalsIgnoreCase(dbData.getSBAD_PHONE())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Phone | Flat file value: "
							+ ediFields.getPer04() + " | Database value:"
							+ dbData.getSBAD_PHONE());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Phone | Flat file value: "
							+ ediFields.getPer04() + " | Database value:"
							+ dbData.getSBAD_PHONE());
		}
		/*if (ediFields.getPer06().equalsIgnoreCase(dbData.getSBAD_FAX())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Fax | Flat file value: "
							+ ediFields.getPer06() + " | Database value:"
							+ dbData.getSBAD_FAX());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Fax | Flat file value: "
							+ ediFields.getPer06() + " | Database value:"
							+ dbData.getSBAD_FAX());
		}*/
	/*	if (ediFields.getN302_1().equalsIgnoreCase(dbData.getSBAD_ADDR1())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Address 1 | Flat file value: "
							+ ediFields.getN302_1() + " | Database value:"
							+ dbData.getSBAD_ADDR1());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Address 1 | Flat file value: "
							+ ediFields.getN302_1() + " | Database value:"
							+ dbData.getSBAD_ADDR1());
		}*/
		if (ediFields.getN402_1().equalsIgnoreCase(dbData.getSBAD_CITY())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Address 2 | Flat file value: "
							+ ediFields.getN402_1() + " | Database value:"
							+ dbData.getSBAD_CITY());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Address 2 | Flat file value: "
							+ ediFields.getN402_1() + " | Database value:"
							+ dbData.getSBAD_CITY());
		}
		if (ediFields.getN403_1().equalsIgnoreCase(dbData.getSBAD_STATE())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Address 2 | Flat file value: "
							+ ediFields.getN403_1() + " | Database value:"
							+ dbData.getSBAD_STATE());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Address 2 | Flat file value: "
							+ ediFields.getN403_1() + " | Database value:"
							+ dbData.getSBAD_STATE());
		}
		if (ediFields.getN403_1().equalsIgnoreCase(dbData.getSBAD_STATE())) {
			logger.log(
					LogStatus.PASS,
					"Field name: Address 2 | Flat file value: "
							+ ediFields.getN403_1() + " | Database value:"
							+ dbData.getSBAD_STATE());
			status = true;
		} else {
			logger.log(
					LogStatus.FAIL,
					"Field name: Address 2 | Flat file value: "
							+ ediFields.getN403_1() + " | Database value:"
							+ dbData.getSBAD_STATE());
		}

		assertTrue(status);
	}
	
	@DataProvider
	public Object[][] memberDetails() {
		Object[][] object = new Object[family.size()][2];
		for (int j = 0; j < family.size(); j++) {
			object[j][0] = family.get(j);
			object[j][1] = dblist.get(j);
		}
		return object;
	}

	/*
	 * 
	 * 
	 * // NM101_1
	 * 
	 * @Test(dataProvider = "nm101_1") public void nm101_1Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM101_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm101_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getNm101_1(); object[j][1] = "IL";
	 * object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * // NM102_1
	 * 
	 * @Test(dataProvider = "nm102_1") public void nm102_1Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM102_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm102_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getNm102_1(); object[j][1] = "1";
	 * object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * // NM103_1
	 * 
	 * @Test(dataProvider = "nm103_1") public void nm103_1Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM103_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm103_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getNm103_1(); object[j][1] =
	 * dblist.get(j).getMEME_LAST_NAME(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // NM104_1
	 * 
	 * @Test(dataProvider = "nm104_1") public void nm104_1Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM104_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm104_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getNm104_1(); object[j][1] =
	 * dblist.get(j).getMEME_FIRST_NAME(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // NM105_1
	 * 
	 * @Test(dataProvider = "nm105_1") public void nm105_1Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM105_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm105_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getNm105_1();
	 * 
	 * object[j][1] = dblist.get(j).getMEME_MID_INIT().trim(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // NM107_1
	 * 
	 * @Test(dataProvider = "nm107_1") public void nm107_1Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM107_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm107_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * 
	 * object[j][0] = family.get(j).getNm107_1(); object[j][1] =
	 * dblist.get(j).getMEME_TITLE().trim(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // NM108_1
	 * 
	 * @Test(dataProvider = "nm108_1") public void nm108_1Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM108_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm108_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getNm108_1(); object[j][1] = "34";
	 * object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * // NM109_1
	 * 
	 * @Test(dataProvider = "nm109_1") public void nm109_1Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM109_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm109_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getNm109_1(); object[j][1] =
	 * dblist.get(j).getMEME_SSN(); object[j][2] = family.get(j).getNm109_1(); }
	 * return object; }
	 * 
	 * // PER01
	 * 
	 * @Test(dataProvider = "per01") public void per01Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "PER01: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] per01() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getPer01(); object[j][1] = "IP";
	 * object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * // PER03
	 * 
	 * @Test(dataProvider = "per03") public void per03Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "PER03: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] per03() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getPer03(); object[j][1] =
	 * family.get(j).getPer03(); object[j][2] = family.get(j).getNm109_1(); }
	 * return object; }
	 * 
	 * // PER04
	 * 
	 * @Test(dataProvider = "per04") public void per04Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "PER04: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] per04() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getPer04(); if
	 * (family.get(j).getPer03().equalsIgnoreCase("TE")) object[j][1] =
	 * dblist.get(j).getSBAD_PHONE(); else if
	 * (family.get(j).getPer03().equalsIgnoreCase("EM")) object[j][1] =
	 * dblist.get(j).getSBAD_EMAIL(); else if
	 * (family.get(j).getPer03().equalsIgnoreCase("FX")) object[j][1] =
	 * dblist.get(j).getSBAD_FAX(); object[j][2] = family.get(j).getNm109_1(); }
	 * return object; }
	 * 
	 * // PER05
	 * 
	 * @Test(dataProvider = "per05") public void per05Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "PER05: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] per05() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getPer05(); object[j][1] =
	 * family.get(j).getPer05(); object[j][2] = family.get(j).getNm109_1(); }
	 * return object; }
	 * 
	 * // PER06
	 * 
	 * @Test(dataProvider = "per06") public void per06Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "PER06: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] per06() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getPer06(); if (family.get(j).getPer05() !=
	 * null) { if (family.get(j).getPer05().equalsIgnoreCase("EM")) object[j][1]
	 * = dblist.get(j).getSBAD_EMAIL(); else if
	 * (family.get(j).getPer05().equalsIgnoreCase("FX")) object[j][1] =
	 * dblist.get(j).getSBAD_FAX(); } else object[j][1] = null; object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // N301_1
	 * 
	 * @Test(dataProvider = "n301_1") public void n301_1Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N301_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n301_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN301_1(); object[j][1] =
	 * dblist.get(j).getSBAD_ADDR1(); object[j][2] = family.get(j).getNm109_1();
	 * } return object; }
	 * 
	 * // N302_1
	 * 
	 * @Test(dataProvider = "n302_1") public void n302_1Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N302_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n302_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN302_1(); if
	 * (dblist.get(j).getSBAD_ADDR2().equalsIgnoreCase(" ")) object[j][1] =
	 * null; else object[j][1] = dblist.get(j).getSBAD_ADDR2(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // N401_1
	 * 
	 * @Test(dataProvider = "n401_1") public void n401_1Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N401_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n401_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN401_1(); object[j][1] =
	 * dblist.get(j).getSBAD_CITY(); object[j][2] = family.get(j).getNm109_1();
	 * } return object; }
	 * 
	 * // N402_1
	 * 
	 * @Test(dataProvider = "n402_1") public void n402_1Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N402_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n402_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN402_1(); object[j][1] =
	 * dblist.get(j).getSBAD_STATE(); object[j][2] = family.get(j).getNm109_1();
	 * } return object; }
	 * 
	 * // N403_1
	 * 
	 * @Test(dataProvider = "n403_1") public void n403_1Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N403_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n403_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN403_1(); object[j][1] =
	 * dblist.get(j).getSBAD_ZIP(); object[j][2] = family.get(j).getNm109_1(); }
	 * return object; }
	 * 
	 * // DMG01
	 * 
	 * @Test(dataProvider = "dmg01") public void dmg01Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DMG01: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dmg01() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDmg01(); object[j][1] = "D8";
	 * object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * // DMG02
	 * 
	 * @Test(dataProvider = "dmg02") public void dmg02Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DMG02: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dmg02() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDmg02(); object[j][1] =
	 * dblist.get(j).getMEME_BIRTH_DT(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // DMG03
	 * 
	 * @Test(dataProvider = "dmg03") public void dmg03Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DMG03: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dmg03() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDmg03(); object[j][1] =
	 * dblist.get(j).getMEME_SEX(); object[j][2] = family.get(j).getNm109_1(); }
	 * return object; }
	 * 
	 * // DMG04
	 * 
	 * @Test(dataProvider = "dmg04") public void dmg04Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DMG04: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dmg04() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDmg04(); if
	 * (dblist.get(j).getMEME_MARITAL_STATUS().equalsIgnoreCase(" "))
	 * object[j][1] = null; else object[j][1] =
	 * dblist.get(j).getMEME_MARITAL_STATUS(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // NM101_2
	 * 
	 * @Test(dataProvider = "nm101_2") public void nm101_2Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM101_2: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm101_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getNm101_2(); if (family.get(j).getNm101_2()
	 * == null) object[j][1] = null; else object[j][1] = "31"; object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // NM102_2
	 * 
	 * @Test(dataProvider = "nm102_2") public void nm102_2Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "NM102_2: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] nm102_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getNm102_2(); if (family.get(j).getNm102_2()
	 * == null) object[j][1] = null; else object[j][1] = "1"; object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // N301_2
	 * 
	 * @Test(dataProvider = "n301_2") public void n301_2Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N301_2: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n301_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN301_2(); object[j][1] =
	 * dblist.get(j).getSBAD_ADDR1(); object[j][2] = family.get(j).getNm109_1();
	 * } return object; }
	 * 
	 * // N302_1
	 * 
	 * @Test(dataProvider = "n302_2") public void n302_2Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N302_1: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n302_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN302_2(); if
	 * (dblist.get(j).getSBAD_ADDR2().equalsIgnoreCase(" ")) object[j][1] =
	 * null; else object[j][1] = dblist.get(j).getSBAD_ADDR2(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // N401_2
	 * 
	 * @Test(dataProvider = "n401_2") public void n401_2Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N401_2: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n401_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN401_2(); object[j][1] =
	 * dblist.get(j).getSBAD_CITY(); object[j][2] = family.get(j).getNm109_1();
	 * } return object; }
	 * 
	 * // N402_2
	 * 
	 * @Test(dataProvider = "n402_2") public void n402_2Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N402_2: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n402_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN402_2(); object[j][1] =
	 * dblist.get(j).getSBAD_STATE(); object[j][2] = family.get(j).getNm109_1();
	 * } return object; }
	 * 
	 * // N403_2
	 * 
	 * @Test(dataProvider = "n403_2") public void n403_2Test(String file, String
	 * db, String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN "
	 * + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "N403_2: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] n403_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getN403_2(); object[j][1] =
	 * dblist.get(j).getSBAD_ZIP(); object[j][2] = family.get(j).getNm109_1(); }
	 * return object; }
	 * 
	 * // HD01
	 * 
	 * @Test(dataProvider = "hd01") public void hd01Test(String file, String db,
	 * String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN " +
	 * ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "HD01: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] hd01() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getHd01(); object[j][1] = "030";
	 * object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * // HD03
	 * 
	 * @Test(dataProvider = "hd03") public void hd03Test(String file, String db,
	 * String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN " +
	 * ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "HD03: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] hd03() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getHd03(); if
	 * (dblist.get(j).getCSPD_CAT().equalsIgnoreCase("M")) object[j][1] = "HLT";
	 * else if (dblist.get(j).getCSPD_CAT().equalsIgnoreCase("D") ||
	 * dblist.get(j).getCSPD_CAT().equalsIgnoreCase("E") ||
	 * dblist.get(j).getCSPD_CAT().equalsIgnoreCase("F") ||
	 * dblist.get(j).getCSPD_CAT().equalsIgnoreCase("G")) object[j][1] = "DEN";
	 * else if (dblist.get(j).getCSPD_CAT().equalsIgnoreCase("V") ||
	 * dblist.get(j).getCSPD_CAT().equalsIgnoreCase("X")) object[j][1] = "VIS";
	 * else if (dblist.get(j).getCSPD_CAT().equalsIgnoreCase("L") ||
	 * dblist.get(j).getCSPD_CAT().equalsIgnoreCase("P") ||
	 * dblist.get(j).getCSPD_CAT().equalsIgnoreCase("S") ||
	 * dblist.get(j).getCSPD_CAT().equalsIgnoreCase("T") ||
	 * dblist.get(j).getCSPD_CAT().equalsIgnoreCase("C")) object[j][1] = "LIF";
	 * else if (dblist.get(j).getCSPD_CAT().equalsIgnoreCase("R")) object[j][1]
	 * = "PDG";
	 * 
	 * object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * // HD04
	 * 
	 * @Test(dataProvider = "hd04") public void hd04Test(String file, String db,
	 * String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN " +
	 * ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "HD04: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] hd04() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getHd04(); if
	 * (file_type.equalsIgnoreCase("COO")) object[j][1] =
	 * dblist.get(j).getCSPI_ID() + dblist.get(j).getCSCS_ID(); else
	 * object[j][1] = dblist.get(j).getCSPI_ID(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // HD05
	 * 
	 * @Test(dataProvider = "hd05") public void hd05Test(String file, String db,
	 * String ssn) { reportInit("834OutboundValidation :", "Subscriber SSN " +
	 * ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "HD05: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] hd05() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getHd05(); object[j][1] =
	 * family.get(j).getHd05(); object[j][2] = family.get(j).getNm109_1(); }
	 * return object; }
	 * 
	 * // dtp01_2
	 * 
	 * @Test(dataProvider = "dtp01_2") public void dtp01_2Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP01_2: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dtp01_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDtp01_2(); object[j][1] = "348";
	 * object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * // dtp02_2
	 * 
	 * @Test(dataProvider = "dtp02_2") public void dtp02_2Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP02_2: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dtp02_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDtp02_2(); object[j][1] = "D8";
	 * object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * // dtp03_2
	 * 
	 * @Test(dataProvider = "dtp03_2") public void dtp03_2Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP03_2: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dtp03_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDtp03_2(); object[j][1] =
	 * dblist.get(j).getMEPE_EFF_DT(); object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // dtp01_3
	 * 
	 * @Test(dataProvider = "dtp01_3") public void dtp01_3Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP01_3: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dtp01_3() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDtp01_3(); if
	 * (file_type.equalsIgnoreCase("COO")) object[j][1] = "349"; else { if
	 * (dblist.get(j).getMEPE_TERM_DT() .equalsIgnoreCase("21991231"))
	 * object[j][1] = null; else object[j][1] = "349"; } object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // dtp02_3
	 * 
	 * @Test(dataProvider = "dtp02_3") public void dtp02_3Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP02_3: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dtp02_3() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDtp02_3(); if
	 * (file_type.equalsIgnoreCase("COO")) object[j][1] = "D8"; else { if
	 * (dblist.get(j).getMEPE_TERM_DT() .equalsIgnoreCase("21991231"))
	 * object[j][1] = null; else object[j][1] = "D8"; } object[j][2] =
	 * family.get(j).getNm109_1(); } return object; }
	 * 
	 * // dtp03_3
	 * 
	 * @Test(dataProvider = "dtp03_3") public void dtp03_3Test(String file,
	 * String db, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP03_3: Actual- <b>" + file +
	 * "</b> | Expected- <b>" + db + "</b>"); assertEquals(file, db);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] dtp03_3() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) {
	 * object[j][0] = family.get(j).getDtp03_3();
	 * 
	 * if (file_type.equalsIgnoreCase("COO")) object[j][1] =
	 * dblist.get(j).getMEPE_TERM_DT(); else { if
	 * (dblist.get(j).getMEPE_TERM_DT() .equalsIgnoreCase("21991231"))
	 * object[j][1] = null; else object[j][1] = dblist.get(j).getMEPE_TERM_DT();
	 * } object[j][2] = family.get(j).getNm109_1(); } return object; }
	 * 
	 * @Test(dataProvider = "cob01") public void cob01Test(String file, String
	 * data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * 
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COB01: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cob01() { Object[][] object = new
	 * Object[family.size()][3]; for (int i = 0; i < family.size(); i++) { if
	 * (!(family.get(i).getCob01() == null)) { object[i][0] =
	 * family.get(i).getCob01(); object[i][1] =
	 * dblist.get(i).getMECB_INSUR_ORDER(); object[i][2] =
	 * family.get(i).getNm109_1(); } else { object[i][0] = ""; object[i][1] =
	 * ""; object[i][2] = family.get(i).getNm109_1(); }
	 * 
	 * }
	 * 
	 * return object; }
	 * 
	 * @Test(dataProvider = "cob02") public void cob02Test(String file, String
	 * data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * 
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COB02: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cob02() { Object[][] object = new
	 * Object[family.size()][3]; for (int i = 0; i < family.size(); i++) { if
	 * (!(family.get(i).getCob01() == null)) { object[i][0] =
	 * family.get(i).getCob02(); object[i][1] =
	 * dblist.get(i).getMECB_POLICY_ID(); object[i][2] =
	 * family.get(i).getNm109_1(); } else { object[i][0] = ""; object[i][1] =
	 * ""; object[i][2] = family.get(i).getNm109_1(); }
	 * 
	 * }
	 * 
	 * return object; }
	 * 
	 * @Test(dataProvider = "cob03") public void cob03Test(String file, String
	 * data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * 
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COB03: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cob03() { Object[][] object = new
	 * Object[family.size()][3]; for (int i = 0; i < family.size(); i++) { if
	 * (!(family.get(i).getCob01() == null)) { object[i][0] =
	 * family.get(i).getCob03(); object[i][1] = "1"; object[i][2] =
	 * family.get(i).getNm109_1(); } else { object[i][0] = ""; object[i][1] =
	 * ""; object[i][2] = family.get(i).getNm109_1(); }
	 * 
	 * }
	 * 
	 * return object; }
	 * 
	 * @Test(dataProvider = "cob04") public void cob04Test(String file, String
	 * data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * 
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COB04: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cob04() { Object[][] object = new
	 * Object[family.size()][3]; for (int i = 0; i < family.size(); i++) { if
	 * (!(family.get(i).getCob04() == null)) { object[i][0] =
	 * family.get(i).getCob04(); if
	 * (dblist.get(i).getMECB_INSUR_TYPE().equalsIgnoreCase("C")) object[i][1] =
	 * "1"; else if (dblist.get(i).getMECB_INSUR_TYPE() .equalsIgnoreCase("D"))
	 * object[i][1] = "1"; object[i][2] = family.get(i).getNm109_1(); } else {
	 * object[i][0] = ""; object[i][1] = ""; object[i][2] =
	 * family.get(i).getNm109_1(); }
	 * 
	 * }
	 * 
	 * return object; }
	 * 
	 * @Test(dataProvider = "cobdtp01_1") public void cobdtp01_1Test(String
	 * file, String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * 
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP01: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cobdtp01_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getDtp01_4(); object[j][1] = "344"; object[j][2] =
	 * family.get(j).getNm109_1(); } else { object[j][0] = ""; object[j][1] =
	 * ""; object[j][2] = family.get(j).getNm109_1(); }
	 * 
	 * } return object; }
	 * 
	 * @Test(dataProvider = "cobdtp02_1") public void cobdtp02_1Test(String
	 * file, String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP02: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cobdtp02_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getDtp02_4(); object[j][1] = "D8"; object[j][2] =
	 * family.get(j).getNm109_1(); } else { object[j][0] = ""; object[j][1] =
	 * ""; object[j][2] = family.get(j).getNm109_1(); }
	 * 
	 * } return object; }
	 * 
	 * @Test(dataProvider = "cobdtp03_1") public void cobdtp03_1Test(String
	 * file, String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP03: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cobdtp03_1() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getDtp03_4(); object[j][1] =
	 * dblist.get(j).getMECB_EFF_DT(); object[j][2] =
	 * family.get(j).getNm109_1(); } else { object[j][0] = ""; object[j][1] =
	 * ""; object[j][2] = family.get(j).getNm109_1(); } } return object; }
	 * 
	 * @Test(dataProvider = "cobdtp01_2") public void cobdtp01_2Test(String
	 * file, String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP01: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cobdtp01_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getDtp01_5(); object[j][1] = "344"; object[j][2] =
	 * family.get(j).getNm109_1(); } else { object[j][0] = ""; object[j][1] =
	 * ""; object[j][2] = family.get(j).getNm109_1(); } } return object; }
	 * 
	 * @Test(dataProvider = "cobdtp02_2") public void cobdtp02_2Test(String
	 * file, String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP02: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cobdtp02_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getDtp02_5(); object[j][1] = "D8"; object[j][2] =
	 * family.get(j).getNm109_1(); } else { object[j][0] = ""; object[j][1] =
	 * ""; object[j][2] = family.get(j).getNm109_1(); } } return object; }
	 * 
	 * @Test(dataProvider = "cobdtp03_2") public void cobdtp03_2Test(String
	 * file, String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "DTP03: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cobdtp03_2() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getDtp03_5(); object[j][1] =
	 * dblist.get(j).getMECB_TERM_DT(); object[j][2] =
	 * family.get(j).getNm109_1(); } else { object[j][0] = ""; object[j][1] =
	 * ""; object[j][2] = family.get(j).getNm109_1(); } } return object; }
	 * 
	 * // COB Effective Date
	 * 
	 * @Test(dataProvider = "cobeffdt") public void cobeffdtTest(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COB EFFECTIVE DATE: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data); }
	 * 
	 * @DataProvider public Object[][] cobeffdt() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getDtp03_4(); object[j][1] =
	 * dblist.get(j).getMECB_EFF_DT(); object[j][2] =
	 * family.get(j).getNm109_1(); } else { object[j][0] = ""; object[j][1] =
	 * ""; object[j][2] = family.get(j).getNm109_1(); } } return object; }
	 * 
	 * // COBNM1 // cobnm101
	 * 
	 * @Test(dataProvider = "cobnm101") public void cobnm101Test(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COBNM101: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] cobnm101() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getNm102_3(); object[j][1] = "IN"; object[j][2] =
	 * family.get(j).getNm109_1(); } else { object[j][0] = ""; object[j][1] =
	 * ""; object[j][2] = family.get(j).getNm109_1(); } } return object; }
	 * 
	 * // cobnm102
	 * 
	 * @Test(dataProvider = "cobnm102") public void cobnm102Test(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COBNM102: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] cobnm102() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getNm102_3(); object[j][1] = "2"; object[j][2] =
	 * family.get(j).getNm109_1(); } else { object[j][0] = ""; object[j][1] =
	 * ""; object[j][2] = family.get(j).getNm109_1(); } } return object; }
	 * 
	 * // cobnm103
	 * 
	 * @Test(dataProvider = "cobnm103") public void cobnm103Test(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COBNM103: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] cobnm103() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getNm102_3(); object[j][1] = dblist.get(j).getMCRE_NAME();
	 * object[j][2] = family.get(j).getNm109_1(); } else { object[j][0] = "";
	 * object[j][1] = ""; object[j][2] = family.get(j).getNm109_1(); } } return
	 * object; }
	 * 
	 * // cobn3101
	 * 
	 * @Test(dataProvider = "cobn3101") public void cobn3101Test(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COBN3101: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] cobn3101() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getNm102_3(); object[j][1] = dblist.get(j).getMCRE_ADDR1();
	 * object[j][2] = family.get(j).getNm109_1(); } else { object[j][0] = "";
	 * object[j][1] = ""; object[j][2] = family.get(j).getNm109_1(); } } return
	 * object; }
	 * 
	 * // cobn3102
	 * 
	 * @Test(dataProvider = "cobn3102") public void cobn3102Test(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COBN3102: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] cobn3102() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getNm102_3(); object[j][1] = dblist.get(j).getMCRE_ADDR2();
	 * object[j][2] = family.get(j).getNm109_1(); } else { object[j][0] = "";
	 * object[j][1] = ""; object[j][2] = family.get(j).getNm109_1(); } } return
	 * object; }
	 * 
	 * // cobn4101
	 * 
	 * @Test(dataProvider = "cobn4101") public void cobn4101Test(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COBN4101: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] cobn4101() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getNm102_3(); object[j][1] = dblist.get(j).getMCRE_ADDR2();
	 * object[j][2] = family.get(j).getNm109_1(); } else { object[j][0] = "";
	 * object[j][1] = ""; object[j][2] = family.get(j).getNm109_1(); } } return
	 * object; }
	 * 
	 * // cobn4102
	 * 
	 * @Test(dataProvider = "cobn4102") public void cobn4102Test(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COBN4102: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] cobn4102() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getNm102_3(); object[j][1] = dblist.get(j).getMCRE_ADDR2();
	 * object[j][2] = family.get(j).getNm109_1(); } else { object[j][0] = "";
	 * object[j][1] = ""; object[j][2] = family.get(j).getNm109_1(); } } return
	 * object; }
	 * 
	 * // cobn4103
	 * 
	 * @Test(dataProvider = "cobn4103") public void cobn4103Test(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COBN4103: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] cobn4103() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getNm102_3(); object[j][1] = dblist.get(j).getMCRE_ADDR2();
	 * object[j][2] = family.get(j).getNm109_1(); } else { object[j][0] = "";
	 * object[j][1] = ""; object[j][2] = family.get(j).getNm109_1(); } } return
	 * object; }
	 * 
	 * // cobn4104
	 * 
	 * @Test(dataProvider = "cobn4104") public void cobn4104Test(String file,
	 * String data, String ssn) { reportInit("834OutboundValidation :",
	 * "Subscriber SSN " + ssn); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename);
	 * logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "COBN4104: Actual <b>" + file +
	 * "</b> | Expected- <b>" + data + "</b>"); assertEquals(file, data);
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] cobn4104() { Object[][] object = new
	 * Object[family.size()][3]; for (int j = 0; j < family.size(); j++) { if
	 * (!(family.get(j).getCob01() == null)) { object[j][0] =
	 * family.get(j).getNm102_3(); object[j][1] = dblist.get(j).getMCRE_ADDR2();
	 * object[j][2] = family.get(j).getNm109_1(); } else { object[j][0] = "";
	 * object[j][1] = ""; object[j][2] = family.get(j).getNm109_1(); } } return
	 * object; }
	 */@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		// reportInit(testResult.getTestContext().getName(),
		// testResult.getName());
		softAssert = new SoftAssert();
		// logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}

}
