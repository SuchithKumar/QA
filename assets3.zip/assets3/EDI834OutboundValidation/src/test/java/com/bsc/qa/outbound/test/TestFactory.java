package com.bsc.qa.outbound.test;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;

import com.bsc.qa.outbound.pojo.HeaderFields;
import com.bsc.qa.outbound.util.FileParse;

public class TestFactory {

	/**
	 * Factory method that calls the specific LOB related class based on fileType identified by the DataProvider
	 * 
	 * @param filetype
	 * @return
	 */
	@Factory(dataProvider = "data")
	public Object[] getFileType(String filetype) {
		switch (filetype) {

		case "CATAMARAN":

			return new Object[] { new CountyOrangeSceneriosTest(), new EDIOutboundTest() };
		case "TPROV":
			System.out.println("TPROV");
			return new Object[] { new ProvidenceScenariosTest(), new EDIOutboundTest()  };
		case "HEALTHWAYS":
			System.out.println("HEALTHWAYS");
			return new Object[] { new SilverSneakersTest(), new EDIOutboundTest()  };
		case "MEDIMPACT":

			return new Object[] { new EDIOutboundTest() };
		default:
			return null;
		}
	}

	/**
	 * DataProvider to identify the fileType based on the header of the file
	 * @return
	 */
	@DataProvider(name = "data")
	public Object[] fileTypeData() {
		Object[] obj = new Object[1];
		FileParse parse = new FileParse();
		HeaderFields header = parse.getHeader();
		obj[0] = header.getIsa08().trim();
		return obj;
	}

}
