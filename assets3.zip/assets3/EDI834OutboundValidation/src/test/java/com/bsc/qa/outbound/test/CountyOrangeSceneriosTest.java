package com.bsc.qa.outbound.test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.outbound.db.DatabaseQueries;
import com.bsc.qa.outbound.pojo.Connection;
import com.bsc.qa.outbound.pojo.DatabaseData;
import com.bsc.qa.outbound.pojo.EDIFields;
import com.bsc.qa.outbound.pojo.HeaderFields;
import com.bsc.qa.outbound.report.factory.BaseTest;
import com.bsc.qa.outbound.util.FileParse;
import com.bsc.qa.outbound.util.HibernateUtil;
import com.relevantcodes.extentreports.LogStatus;

public class CountyOrangeSceneriosTest extends BaseTest implements IHookable {
	List<EDIFields> termedmemberlist = new ArrayList<EDIFields>();
	List<DatabaseData> termedmemberdblist = new ArrayList<DatabaseData>();
	List<EDIFields> family;
	HeaderFields header;
	String filename;
	int stcount, secount;
	boolean tpa, ipa;
	Connection conn = new Connection();
	SessionFactory factory;
	Session session;
	EDIFields filedata;
	List<DatabaseData> dblist;
	List<String> rowsList;

	@BeforeSuite
	public void beforeSuite() {
		String oracleUser = System.getenv("FACETS_USER");
		String oraclePassword = System.getenv("FACETS_PASSWORD");
		String oracleServer = System.getenv("FACETS_SERVER");
		String oraclePort = System.getenv("FACETS_PORT");
		String oracleDB = System.getenv("FACETS_DB");
		String oracleUrl = "jdbc:oracle:thin:@" + oracleServer + ":"
				+ oraclePort + ":" + oracleDB;
		System.out.println("Inside Test Suite");
		// conn.setUsername(AutomationStringUtilities.decryptValue(oracleUser));
		// conn.setPassword(AutomationStringUtilities.decryptValue(oraclePassword));
		conn.setUrl(oracleUrl);
		conn.setUsername(oracleUser);
		conn.setPassword(oraclePassword);

		factory = HibernateUtil.createSessionFactory(conn);
		session = factory.openSession();
	}

	@AfterSuite
	public void closeConnection() {
		if (session != null) {
			session.close();
			factory.close();
			System.out.println("DB Connection Succesfully closed!");
		}
	}

	@BeforeTest
	public void getData() throws IOException {
		FileParse parse = new FileParse();
		family = parse.getMemberFamily();
		header = parse.getHeader();
		rowsList = parse.parseFile();
		stcount = parse.stcount;
		secount = parse.secount;
		filename = parse.inputFile.getAbsolutePath();
		DatabaseQueries queries = new DatabaseQueries();
		dblist = queries.getDatabaseData(family, session);
		for (int j = 0; j < family.size(); j++) {

			if (family.get(j).getDtp03_3().equalsIgnoreCase(header.getGs04())) {
				termedmemberlist.add(family.get(j));
				termedmemberdblist.add(dblist.get(j));
			}
		}

		System.out.println(filename);
	}

	// TC133 - Verify value \"CATAMARAN\" in Receiver's Federal Tax ID - ISA08
	// and GS03 segment in COO outbound file extract.
	@Test()
	public void testReceiverFederalTaxId() {
		String isaSegment = header.getIsa08().trim();
		String gsSegment = header.getGs03().trim();
		assertEquals(
				isaSegment,
				gsSegment,
				"CATAMARAN: ISA and GS segments must match: ISA: "
						+ header.getIsa08() + " GS: " + header.getGs03());
	}

	
	// TC112(Sender ID)
	@Test()
	public void testSenderId() {
		String isaSegment = header.getIsa06().trim();
		String defaultValue = "PBS2331";
		assertEquals(isaSegment, defaultValue, "Sender ID : File Value: "
				+ isaSegment + " Default Value: " + defaultValue);
	}

	// TC112(Receiver ID)
	@Test()
	public void testReceiverId() {
		String isaSegment = header.getIsa08().trim();
		String defaultValue = "CATAMARAN";
		assertEquals(isaSegment, defaultValue, "Receiver ID : File Value: "
				+ isaSegment + " Default Value: " + defaultValue);
	}

	// TC121 (SE01)
	@Test()
	public void testSE01Segment() {
		String se01 = header.getSe01().trim();
		String actualValue = Integer.toString(rowsList.size() - 4);
		assertEquals(se01, actualValue, "Segement Count : File Value: " + se01
				+ " Default Value: " + actualValue);
	}

	// TC121 (SE02)
	@Test()
	public void testSE02Segment() {
		String se02 = header.getSe02().trim();
		String st02 = header.getSt02().trim();
		assertEquals(se02, st02, "SE and ST segment should match: SE02: "
				+ se02 + " ST02: " + st02);
	}
	/**
	 * Test Class to validate Service Type Code segment 
	 * @param serviceTypeCode_fileValue
	 * @param serviceTypeCode_dbValue
	 * @param ssn
	 * @param email
	 */
	// TC124
	@Test(dataProvider = "cob041")
	public void testCOB04Segment(String file, String data, String ssn, String email) {
		assertEquals(file, data, "Service Type Code: File Value: "
				+ file + " Database Value: " + data);
	}


	

	@DataProvider
	public Object[][] cob041() {
		Object[][] object = new Object[family.size()][4];
		for (int i = 0; i < family.size(); i++) {

			if (!(family.get(i).getCob04() == null)) {
				object[i][0] = family.get(i).getCob04();
				if (dblist.get(i).getMECB_INSUR_TYPE().equalsIgnoreCase("C"))
					object[i][1] = "1";
				else if (dblist.get(i).getMECB_INSUR_TYPE()
						.equalsIgnoreCase("D"))
					object[i][1] = "1";
				object[i][2] = family.get(i).getNm109_1();
				object[i][3] = family.get(i).getEmail();
			} else {
				object[i][0] = "";
				object[i][1] = "";
				object[i][2] = family.get(i).getNm109_1();
				object[i][3] = family.get(i).getEmail();
			}

		}

		return object;
	}

	// TC115
	// Verification of Client FEIN Segment
	@Test()
	public void testClientFEIN() {
		String clientFEIN = header.getN104_1();
		String dbValue = dblist.get(0).getGRGR_EIN();
		assertEquals(clientFEIN, dbValue, "Client FEIN: File Value: "
				+ clientFEIN + " Database Value: " + dbValue);
	}

	// TC073
	// Verification of Naming Convention
	@Test
	public void testFileName() {
		assertTrue(filename.contains("CTRCOO"),"File Name: "+filename);
	}

	// TC122
	// Verification of Group Trailer Segment
	@Test()
	public void testGE02Segment() {
		String ge02 = header.getGe02();
		String gs06 = header.getGs06();
		assertEquals(ge02, gs06,
				"Group Trailer: GE and GS segments should match GE: " + ge02
						+ " GS: " + gs06);
	}

	// TC123
	// Verification of Interchange Control Trailer Segment
	@Test()
	public void testIEA02Segment() {
		String iea02 = header.getIea02();
		String isa13 = header.getIsa13();
			assertEquals(iea02, isa13,
				"Interchange Control Trailer: IEA and ISA segments should match IEA: "
						+ iea02 + " ISA: " + isa13);
	}

	// TC132
	// Verification of Unique Carrier Identifier
	@Test()
	public void testUniqueCarrier() {
		String isa06 = header.getIsa06().trim();
		String gs02 = header.getGs02().trim();
		assertEquals(
				isa06,
				gs02,
				" Unique Carrier Identifier PBS2331: ISA06 and GS02 segments should match ISA: "
						+ isa06 + " GS: " + gs02);
	}

	// TC131
	// Verification of single Transaction segment presence
	@Test
	public void testTransactionCount() {
		assertEquals(stcount, secount, "Only one Transaction segment must be present in a File");
	}

	// TC119
	// Validation of Member eligibility start date and end date
		/**
		 * Test Class to validate Member eligibility start date and end date 
		 * @param fileObject
		 * @param databaseObject
		 * @param ssn
		 * @param email
		 */
	@Test(dataProvider = "eligibilityDate")
	public void testEligibilityStartEndDate(EDIFields file, DatabaseData data,
			String ssn, String email) {
		boolean status = false;
		if (file.getDtp03_2().equalsIgnoreCase(data.getMEPE_EFF_DT())
				&& file.getDtp03_3().equalsIgnoreCase(data.getMEPE_TERM_DT()))
			status = true;

		assertTrue(status);
	}

	

	@DataProvider
	public Object[][] eligibilityDate() {
		Object[][] object = new Object[family.size()][4];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j);
			object[j][1] = dblist.get(j);
			object[j][2] = family.get(j).getNm109_1();
			object[j][3] = family.get(j).getEmail();
		}
		return object;
	}

	// TC113
	// Verification of Full Positive File
	@Test
	public void testFullPositiveFile() {
		String bgn08 = header.getBgn08();
		String defaultValue = "4";
		assertEquals(bgn08, defaultValue,
				" Full Positive File: BGN08 Segment should be 4 BGN: " + bgn08
						+ " Default Value: " + defaultValue);
	}

	// TC118
	// Validation of HD Segment
	/**
	 * Test Class to validate HD Segment 
	 * @param fileObject
	 * @param dbObject
	 * @param ssn
	 * @param email
	 */

	@Test(dataProvider = "hd")
	public void testHDSegment(EDIFields file, DatabaseData db, String ssn,
			String email) {
		String cat;
		boolean status = false;
		if (db.getCSPD_CAT().equalsIgnoreCase("M"))
			cat = "HLT";
		else if (db.getCSPD_CAT().equalsIgnoreCase("D")
				|| db.getCSPD_CAT().equalsIgnoreCase("E")
				|| db.getCSPD_CAT().equalsIgnoreCase("F")
				|| db.getCSPD_CAT().equalsIgnoreCase("G"))
			cat = "DEN";
		else if (db.getCSPD_CAT().equalsIgnoreCase("V")
				|| db.getCSPD_CAT().equalsIgnoreCase("X"))
			cat = "VIS";
		else if (db.getCSPD_CAT().equalsIgnoreCase("L")
				|| db.getCSPD_CAT().equalsIgnoreCase("P")
				|| db.getCSPD_CAT().equalsIgnoreCase("S")
				|| db.getCSPD_CAT().equalsIgnoreCase("T")
				|| db.getCSPD_CAT().equalsIgnoreCase("C"))
			cat = "LIF";
		else if (db.getCSPD_CAT().equalsIgnoreCase("R"))
			cat = "PDG";
		else
			cat = " ";

		if (file.getHd01().equalsIgnoreCase("030")
				&& file.getHd03().equalsIgnoreCase(cat)
				&& file.getHd04().equalsIgnoreCase(
						db.getCSPI_ID() + db.getCSCS_ID())
				&& file.getHd05().equalsIgnoreCase(file.getHd05())
				&& file.getDtp01_2().equalsIgnoreCase("348")
				&& file.getDtp02_2().equalsIgnoreCase("D8")
				&& file.getDtp03_2().equalsIgnoreCase(db.getMEPE_EFF_DT())
				&& file.getDtp01_3().equalsIgnoreCase("349")
				&& file.getDtp02_3().equalsIgnoreCase("D8")
				&& file.getDtp03_3().equalsIgnoreCase(db.getMEPE_TERM_DT())) {
			status = true;
		}
		assertTrue(status);

	}

	
	@DataProvider
	public Object[][] hd() {
		Object[][] object = new Object[family.size()][4];
		for (int j = 0; j < family.size(); j++) {
			object[j][0] = family.get(j);

			object[j][1] = dblist.get(j);
			object[j][2] = family.get(j).getNm109_1();
			object[j][3] = family.get(j).getEmail();
		}
		return object;
	}

	// TC129
	// Validation of REF02 (SBSB_ID + MEME_SFX) Segment in Loop 2000
	/**
	 * Test Class to validate REF02 (SBSB_ID + MEME_SFX) Segment in Loop 2000 
	 * @param ref02SegmentValue
	 * @param dbValue
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "ref02_4")
	public void testREF02Segment(String file, String data, String ssn,
			String email) {
		assertEquals(file, data," REF02 Segment: File Value: "+file+" Database Value: "+data);
	}

	
	@DataProvider
	public Object[][] ref02_4() {
		Object[][] object = new Object[family.size()][4];
		for (int j = 0; j < family.size(); j++) {
			object[j][3] = family.get(j).getEmail();

			object[j][0] = family.get(j).getRef02_4();
			object[j][1] = "OCO" + dblist.get(j).getSBSB_ID() + "0"
					+ dblist.get(j).getMEME_SFX();
			object[j][2] = family.get(j).getNm109_1();
		}
		return object;
	}

	// TC130
	// Validation of HD04 (Plan ID + Class ID) Segment
	/**
	 * Test Class to validate HD04 (Plan ID + Class ID) Segment 
	 * @param hd04SegmentValue
	 * @param dbValue
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "hd041")
	public void testHD04Segment(String file, String data, String ssn,
			String email) {
		
		assertEquals(file, data,"HD04: Actual " + file
				+ " | Expected- " + data );
	}

	
	@DataProvider
	public Object[][] hd041() {
		Object[][] object = new Object[family.size()][4];
		for (int j = 0; j < family.size(); j++) {
			object[j][3] = family.get(j).getEmail();

			object[j][0] = family.get(j).getHd04();
			object[j][1] = dblist.get(j).getCSPI_ID()
					+ dblist.get(j).getCSCS_ID();
			object[j][2] = family.get(j).getNm109_1();
		}
		return object;
	}

	// TC116
	// Validation of SSN
	/**
	 * Test Class to validate SSN 
	 * @param ssnFileValue
	 * @param ssnDBValue
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "ssn")
	public void testSSN(String file, String data, String ssn, String email) {
		
		assertEquals(file, data,"SSN: Actual " + file
				+ " | Expected- " + data + "");
	}

	
	@DataProvider
	public Object[][] ssn() {
		Object[][] object = new Object[family.size()][4];
		for (int j = 0; j < family.size(); j++) {
			object[j][3] = family.get(j).getEmail(); //
			// if (family.get(j).getIns02().equalsIgnoreCase("Y"))
			object[j][0] = family.get(j).getNm109_1();
			object[j][1] = dblist.get(j).getMEME_SSN();
			object[j][2] = family.get(j).getNm109_1();
		}
		return object;
	}

	// TC126
	// Verification of COB Segment
	/**
	 * Test Class to validate COB Segment 
	 * @param fileObject
	 * @param dbObject
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "cob")
	public void testCOB(EDIFields file, DatabaseData data, String ssn,
			String email) {
		
		boolean status = false;
		String str;
		if (data.getMECB_POLICY_ID() == null)
			str = "";
		else if (data.getMECB_POLICY_ID().equalsIgnoreCase(" "))
			str = "";
		else
			str = data.getMECB_POLICY_ID();
		System.out.println(str + " policy" + data.getMECB_POLICY_ID());
		if (!(file.getCob01() == null)) {
			if (file.getCob01().equalsIgnoreCase(data.getMECB_INSUR_ORDER())
					&& file.getCob02().equalsIgnoreCase(str)
					&& file.getCob03().equalsIgnoreCase("1")
					&& file.getCob04().equalsIgnoreCase("1")) {
				status = true;
			}
			
		} else {
			status = true;
		}
		assertTrue(status);
	}

	
	@DataProvider
	public Object[][] cob() {
		Object[][] object = new Object[family.size()][4];
		for (int i = 0; i < family.size(); i++) {
			// if (!(family.get(i).getCob01() == null)) {
			object[i][0] = family.get(i);
			object[i][1] = dblist.get(i);
			object[i][2] = family.get(i).getNm109_1();
			object[i][3] = family.get(i).getEmail();

		}

		return object;
	}

	// TC125
	// Validation of COB Effective Date
	/**
	 * 
	 * Test Class to validate COB Effective Date 
	 * @param effectiveDateFileValue
	 * @param effectiveDateDBValue
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "cobeffdt")
	public void testCOBEffectiveDate(String file, String data, String ssn,
			String email) {
		
		assertEquals(file, data,"COB EFFECTIVE DATE: Actual " + file
				+ " | Expected- " + data + "");
	}

	
	@DataProvider
	public Object[][] cobeffdt() {
		Object[][] object = new Object[family.size()][4];
		for (int j = 0; j < family.size(); j++) {
			object[j][3] = family.get(j).getEmail();
			if (!(family.get(j).getCob01() == null)) {
				object[j][0] = family.get(j).getDtp03_4();
				object[j][1] = dblist.get(j).getMECB_EFF_DT();
				object[j][2] = family.get(j).getNm109_1();
			} else {
				object[j][0] = "";
				object[j][1] = "";
				object[j][2] = family.get(j).getNm109_1();
			}
		}
		return object;
	}

	/*
	 * // Terminated Member details // TC110
	 * 
	 * @Test(dataProvider = "termedMember") public void
	 * termedMemberTest(EDIFields file, HeaderFields header, DatabaseData db,
	 * String ssn, String email) { reportInit(
	 * "EUP_Regression Test_834_Terminated Member_Orange County_TC110  ::",
	 * "STT_OB_TC31"); logger.log(LogStatus.INFO, "Starting Test: ");
	 * logger.log(LogStatus.INFO, "File Path: " + filename); logger.log(
	 * LogStatus.INFO, "Scenario: " +
	 * "Verify terminated member details are displayed in the extract for orange county Members"
	 * ); logger.log(LogStatus.INFO, "SSN used for validation is: " + ssn);
	 * logger.log(LogStatus.INFO, "Email: " + email); logger.log(LogStatus.INFO,
	 * "Termination Date: Actual <b>" + file + "</b> | Expected- <b>" +
	 * header.getGs04() + "</b>");
	 * 
	 * assertEquals(file.getDtp03_3(), header.getGs04());
	 * 
	 * }
	 * 
	 * @DataProvider public Object[][] termedMember() {
	 * System.out.println("Termed Member data provider");
	 * 
	 * Object[][] object = new Object[termedmemberlist.size()][4]; for (int j =
	 * 0; j < termedmemberlist.size(); j++) { object[j][0] =
	 * termedmemberlist.get(j); object[j][1] = header; object[j][2] =
	 * termedmemberdblist.get(j); object[j][3] =
	 * termedmemberlist.get(j).getNm109_1();
	 * 
	 * } return object; }
	 */

	// TC002
	// Verification of absence of past date loop in File
	/**
	 * 
	 * Test Class to validate absence of past date loop in File 
	 * @param termDate
	 * @param runDate
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "pastDate")
	public void testPastDateLoop(Date termDt, Date runDate, String ssn,
			String email) {
		boolean status = true;
		long difference = (termDt.getTime() - runDate.getTime()) / 86400000;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String termDate = sdf.format(termDt);

		
		if (Math.abs(difference) < 29159 && Math.abs(difference) > 90) {
			status = false;
			
		} assertTrue(status);
	}

	
	@DataProvider
	public Object[][] pastDate() throws ParseException {
		Object[][] object = new Object[family.size()][4];

		for (int j = 0; j < family.size(); j++) {
			object[j][3] = family.get(j).getEmail();

			object[j][0] = new SimpleDateFormat("yyyyMMdd").parse(family.get(j)
					.getDtp03_3());
			object[j][1] = new SimpleDateFormat("yyyyMMdd").parse(header
					.getGs04());
			object[j][2] = family.get(j).getNm109_1();

		}
		return object;
	}

	// TC110
	// Verification of Termed Members presence in the File
	/**
	 * 
	 * Test Class to validate Termed Members presence in the File 
	 * @param termDate
	 * @param runDate
	 * @param ssn
	 * @param email
	 */
	@Test(dataProvider = "termMember")
	public void testTermMember(Date termDt, Date runDate, String ssn,
			String email) {
		boolean status = false;
		long difference = (termDt.getTime() - runDate.getTime()) / 86400000;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String termDate = sdf.format(termDt);
		String runDt = sdf.format(runDate);
		

		if (Math.abs(difference) <= 90 || Math.abs(difference) > 28000) {
			status = true;
			
		} else {
			status = false;
			
		}

		assertTrue(status);
	}

	
	@DataProvider
	public Object[][] termMember() throws ParseException {
		Object[][] object = new Object[family.size()][4];

		for (int j = 0; j < family.size(); j++) {
			object[j][3] = family.get(j).getEmail();

			object[j][0] = new SimpleDateFormat("yyyyMMdd").parse(family.get(j)
					.getDtp03_3());
			object[j][1] = new SimpleDateFormat("yyyyMMdd").parse(header
					.getGs04());
			object[j][2] = family.get(j).getNm109_1();

		}
		return object;
	}

	// TC134
	// Verification of Multiple Coverage
	/**
	 * Test Class to validate Multiple Coverage
	 * @param multipleCoverageMembersList
	 */
	@Test(dataProvider = "multipleCoverage")
	public void testMultipleCoverage(List<EDIFields> ediFields) {

		
		if (!ediFields.isEmpty())
			assertTrue(true);
		else
			assertTrue(false);
	}

	
	@DataProvider
	public Object[][] multipleCoverage() {

		Set<EDIFields> multipleSSN = new HashSet<EDIFields>();
		Map<String, List<EDIFields>> ediFMap = new HashMap<String, List<EDIFields>>();
		Set<String> ssnset = new HashSet<String>();

		// Set<DatabaseData> multipleSSNDB = new HashSet<DatabaseData>();
		for (int i = 0; i < family.size(); i++) {
			int count = 0;
			for (int j = 0; j < family.size(); j++) {
				if (family.get(i).getRef02_4()
						.equalsIgnoreCase(family.get(j).getRef02_4())) {
					count++;
					if (count > 1) {
						multipleSSN.add(family.get(i));
						ssnset.add(family.get(i).getNm109_1());
						// multipleSSNDB.add(dblist.get(i));
					}
				}
			}
		}

		for (EDIFields ediFields : multipleSSN) {

			if (ediFMap.isEmpty()) {
				ediFMap.put(ediFields.getNm109_1(), new ArrayList<EDIFields>());
				ediFMap.get(ediFields.getNm109_1()).add(ediFields);
			} else if (ediFMap.containsKey(ediFields.getNm109_1())) {
				ediFMap.get(ediFields.getNm109_1()).add(ediFields);

			}
		}

		System.out.println("SSN Set Size" + ssnset.size());

		for (String string : ssnset) {
			System.out.println(string);
		}
		Object[][] object = new Object[ssnset.size()][1];
		int i = 0;
		for (String str : ssnset) {

			object[i][0] = ediFMap.get(str);

			i = i + 1;
		}
		return object;
	}

	
	/**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}
}
