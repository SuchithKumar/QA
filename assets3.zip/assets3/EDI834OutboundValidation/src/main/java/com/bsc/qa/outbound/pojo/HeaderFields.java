package com.bsc.qa.outbound.pojo;

public class HeaderFields {

	private String isa01;
	private String isa02;
	private String isa03;
	private String isa04;
	private String isa05;
	private String isa06;
	private String isa07;
	private String isa08;
	private String isa09;
	private String isa10;
	private String isa11;
	private String isa12;
	private String isa13;
	private String isa14;
	private String isa15;
	private String isa16;
	private String gs01;
	private String gs02;
	private String gs03;
	private String gs04;
	private String gs05;
	private String gs06;
	private String gs07;
	private String gs08;
	private String st01;
	private String st02;
	private String st03;
	private String bgn01;
	private String bgn02;
	private String bgn03;
	private String bgn04;
	private String bgn05;
	private String bgn06;
	private String bgn08;
	private String dtp01;
	private String dtp02;
	private String dtp03;
	private String qty01_1;
	private String qty02_1;
	private String qty01_2;
	private String qty02_2;
	private String qty01_3;
	private String qty02_3;
	private String n101_1;
	private String n102_1;
	private String n103_1;
	private String n104_1;
	private String n101_2;
	private String n102_2;
	private String n103_2;
	private String n104_2;

	private String se01;
	private String se02;
	private String ge01;
	private String ge02;
	private String iea01;
	private String iea02;
	private String dtp01_1;
	private String dtp02_1;
	private String dtp03_1;

	public String getDtp01_1() {
		return dtp01_1;
	}

	public void setDtp01_1(String dtp01_1) {
		this.dtp01_1 = dtp01_1;
	}

	public String getDtp02_1() {
		return dtp02_1;
	}

	public void setDtp02_1(String dtp02_1) {
		this.dtp02_1 = dtp02_1;
	}

	public String getDtp03_1() {
		return dtp03_1;
	}

	public void setDtp03_1(String dtp03_1) {
		this.dtp03_1 = dtp03_1;
	}

	public String getSe01() {
		return se01;
	}

	public void setSe01(String se01) {
		this.se01 = se01;
	}

	public String getSe02() {
		return se02;
	}

	public void setSe02(String se02) {
		this.se02 = se02;
	}

	public String getGe01() {
		return ge01;
	}

	public void setGe01(String ge01) {
		this.ge01 = ge01;
	}

	public String getGe02() {
		return ge02;
	}

	public void setGe02(String ge02) {
		this.ge02 = ge02;
	}

	public String getIea01() {
		return iea01;
	}

	public void setIea01(String iea01) {
		this.iea01 = iea01;
	}

	public String getIea02() {
		return iea02;
	}

	public void setIea02(String iea02) {
		this.iea02 = iea02;
	}

	public String getIsa01() {
		return isa01;
	}

	public void setIsa01(String isa01) {
		this.isa01 = isa01;
	}

	public String getIsa02() {
		return isa02;
	}

	public void setIsa02(String isa02) {
		this.isa02 = isa02;
	}

	public String getIsa03() {
		return isa03;
	}

	public void setIsa03(String isa03) {
		this.isa03 = isa03;
	}

	public String getIsa04() {
		return isa04;
	}

	public void setIsa04(String isa04) {
		this.isa04 = isa04;
	}

	public String getIsa05() {
		return isa05;
	}

	public void setIsa05(String isa05) {
		this.isa05 = isa05;
	}

	public String getIsa06() {
		return isa06;
	}

	public void setIsa06(String isa06) {
		this.isa06 = isa06;
	}

	public String getIsa07() {
		return isa07;
	}

	public void setIsa07(String isa07) {
		this.isa07 = isa07;
	}

	public String getIsa08() {
		return isa08;
	}

	public void setIsa08(String isa08) {
		this.isa08 = isa08;
	}

	public String getIsa09() {
		return isa09;
	}

	public void setIsa09(String isa09) {
		this.isa09 = isa09;
	}

	public String getIsa10() {
		return isa10;
	}

	public void setIsa10(String isa10) {
		this.isa10 = isa10;
	}

	public String getIsa11() {
		return isa11;
	}

	public void setIsa11(String isa11) {
		this.isa11 = isa11;
	}

	public String getIsa12() {
		return isa12;
	}

	public void setIsa12(String isa12) {
		this.isa12 = isa12;
	}

	public String getIsa13() {
		return isa13;
	}

	public void setIsa13(String isa13) {
		this.isa13 = isa13;
	}

	public String getIsa14() {
		return isa14;
	}

	public void setIsa14(String isa14) {
		this.isa14 = isa14;
	}

	public String getIsa15() {
		return isa15;
	}

	public void setIsa15(String isa15) {
		this.isa15 = isa15;
	}

	public String getIsa16() {
		return isa16;
	}

	public void setIsa16(String isa16) {
		this.isa16 = isa16;
	}

	public String getGs01() {
		return gs01;
	}

	public void setGs01(String gs01) {
		this.gs01 = gs01;
	}

	public String getGs02() {
		return gs02;
	}

	public void setGs02(String gs02) {
		this.gs02 = gs02;
	}

	public String getGs03() {
		return gs03;
	}

	public void setGs03(String gs03) {
		this.gs03 = gs03;
	}

	public String getGs04() {
		return gs04;
	}

	public void setGs04(String gs04) {
		this.gs04 = gs04;
	}

	public String getGs05() {
		return gs05;
	}

	public void setGs05(String gs05) {
		this.gs05 = gs05;
	}

	public String getGs06() {
		return gs06;
	}

	public void setGs06(String gs06) {
		this.gs06 = gs06;
	}

	public String getGs07() {
		return gs07;
	}

	public void setGs07(String gs07) {
		this.gs07 = gs07;
	}

	public String getGs08() {
		return gs08;
	}

	public void setGs08(String gs08) {
		this.gs08 = gs08;
	}

	public String getSt01() {
		return st01;
	}

	public void setSt01(String st01) {
		this.st01 = st01;
	}

	public String getSt02() {
		return st02;
	}

	public void setSt02(String st02) {
		this.st02 = st02;
	}

	public String getSt03() {
		return st03;
	}

	public void setSt03(String st03) {
		this.st03 = st03;
	}

	public String getBgn01() {
		return bgn01;
	}

	public void setBgn01(String bgn01) {
		this.bgn01 = bgn01;
	}

	public String getBgn02() {
		return bgn02;
	}

	public void setBgn02(String bgn02) {
		this.bgn02 = bgn02;
	}

	public String getBgn03() {
		return bgn03;
	}

	public void setBgn03(String bgn03) {
		this.bgn03 = bgn03;
	}

	public String getBgn04() {
		return bgn04;
	}

	public void setBgn04(String bgn04) {
		this.bgn04 = bgn04;
	}

	public String getBgn05() {
		return bgn05;
	}

	public void setBgn05(String bgn05) {
		this.bgn05 = bgn05;
	}

	public String getBgn06() {
		return bgn06;
	}

	public void setBgn06(String bgn06) {
		this.bgn06 = bgn06;
	}

	public String getBgn08() {
		return bgn08;
	}

	public void setBgn08(String bgn08) {
		this.bgn08 = bgn08;
	}

	public String getDtp01() {
		return dtp01;
	}

	public void setDtp01(String dtp01) {
		this.dtp01 = dtp01;
	}

	public String getDtp02() {
		return dtp02;
	}

	public void setDtp02(String dtp02) {
		this.dtp02 = dtp02;
	}

	public String getDtp03() {
		return dtp03;
	}

	public void setDtp03(String dtp03) {
		this.dtp03 = dtp03;
	}

	public String getQty01_1() {
		return qty01_1;
	}

	public void setQty01_1(String qty01_1) {
		this.qty01_1 = qty01_1;
	}

	public String getQty02_1() {
		return qty02_1;
	}

	public void setQty02_1(String qty02_1) {
		this.qty02_1 = qty02_1;
	}

	public String getQty01_2() {
		return qty01_2;
	}

	public void setQty01_2(String qty01_2) {
		this.qty01_2 = qty01_2;
	}

	public String getQty02_2() {
		return qty02_2;
	}

	public void setQty02_2(String qty02_2) {
		this.qty02_2 = qty02_2;
	}

	public String getQty01_3() {
		return qty01_3;
	}

	public void setQty01_3(String qty01_3) {
		this.qty01_3 = qty01_3;
	}

	public String getQty02_3() {
		return qty02_3;
	}

	public void setQty02_3(String qty02_3) {
		this.qty02_3 = qty02_3;
	}

	public String getN101_1() {
		return n101_1;
	}

	public void setN101_1(String n101_1) {
		this.n101_1 = n101_1;
	}

	public String getN102_1() {
		return n102_1;
	}

	public void setN102_1(String n102_1) {
		this.n102_1 = n102_1;
	}

	public String getN103_1() {
		return n103_1;
	}

	public void setN103_1(String n103_1) {
		this.n103_1 = n103_1;
	}

	public String getN104_1() {
		return n104_1;
	}

	public void setN104_1(String n104_1) {
		this.n104_1 = n104_1;
	}

	public String getN101_2() {
		return n101_2;
	}

	public void setN101_2(String n101_2) {
		this.n101_2 = n101_2;
	}

	public String getN102_2() {
		return n102_2;
	}

	public void setN102_2(String n102_2) {
		this.n102_2 = n102_2;
	}

	public String getN103_2() {
		return n103_2;
	}

	public void setN103_2(String n103_2) {
		this.n103_2 = n103_2;
	}

	public String getN104_2() {
		return n104_2;
	}

	public void setN104_2(String n104_2) {
		this.n104_2 = n104_2;
	}

}
