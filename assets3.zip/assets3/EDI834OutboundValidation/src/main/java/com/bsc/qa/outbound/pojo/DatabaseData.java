package com.bsc.qa.outbound.pojo;

public class DatabaseData {
	private String CSCS_ID;
	private String SBSB_ID;
	private String MEME_FIRST_NAME;
	private String MEME_LAST_NAME;
	private String MEME_MID_INIT;
	private String SBAD_ADDR2;
	private String SBAD_CITY;
	private String SBAD_STATE;
	private String SBAD_ZIP;
	private String MEME_TITLE;
	private String SBAD_PHONE;
	private String SBAD_EMAIL;
	private String SBAD_FAX;
	private String SBAD_TYPE_HOME;
	private String MEME_REL;
	private String SBSB_MCTR_STS;
	private String MEME_SFX;
	private String GRGR_ID;
	private String MEME_HICN;
	private String GRGR_NAME;
	private String SBSB_ORIG_EFF_DT;
	private String MEME_SSN;
	private String MEME_BIRTH_DT;
	private String MEME_SEX;
	private String MEME_MARITAL_STATUS;
	private String MEME_MCTR_LANG;
	private String SBAD_ADDR1;
	private String SGSG_ID;
	private String CSPD_CAT;
	private String MEPE_TERM_DT;
	private String MEPE_EFF_DT;
	private String GRGR_EIN;
	private String CSPI_ID;
	private String MECB_INSUR_ORDER;
	private String MECB_POLICY_ID;
	private String MECB_INSUR_TYPE;
	private String MECB_EFF_DT;
	private String MECB_TERM_DT;
	private String MCRE_NAME;
	private String MCRE_ADDR1;
	private String MCRE_ADDR2;
	private String MCRE_CITY;
	private String MCRE_STATE;
	private String MCRE_ZIP;
	private String MCRE_CTRY_CD;;
	private String CSPI_ITS_PREFIX;
	private String MEST_TYPE;
	private String CSPI_EFF_DT;

	public String getCSPI_EFF_DT() {
		return CSPI_EFF_DT;
	}

	public void setCSPI_EFF_DT(String cSPI_EFF_DT) {
		CSPI_EFF_DT = cSPI_EFF_DT;
	}

	public String getMEST_TYPE() {
		return MEST_TYPE;
	}

	public void setMEST_TYPE(String mEST_TYPE) {
		MEST_TYPE = mEST_TYPE;
	}

	public String getCSPI_ITS_PREFIX() {
		return CSPI_ITS_PREFIX;
	}

	public void setCSPI_ITS_PREFIX(String cSPI_ITS_PREFIX) {
		CSPI_ITS_PREFIX = cSPI_ITS_PREFIX;
	}

	public String getMECB_INSUR_ORDER() {
		return MECB_INSUR_ORDER;
	}

	public void setMECB_INSUR_ORDER(String mECB_INSUR_ORDER) {
		MECB_INSUR_ORDER = mECB_INSUR_ORDER;
	}

	public String getMECB_POLICY_ID() {
		return MECB_POLICY_ID;
	}

	public void setMECB_POLICY_ID(String mECB_POLICY_ID) {
		MECB_POLICY_ID = mECB_POLICY_ID;
	}

	public String getMECB_INSUR_TYPE() {
		return MECB_INSUR_TYPE;
	}

	public void setMECB_INSUR_TYPE(String mECB_INSUR_TYPE) {
		MECB_INSUR_TYPE = mECB_INSUR_TYPE;
	}

	public String getMECB_EFF_DT() {
		return MECB_EFF_DT;
	}

	public void setMECB_EFF_DT(String mECB_EFF_DT) {
		MECB_EFF_DT = mECB_EFF_DT;
	}

	public String getMECB_TERM_DT() {
		return MECB_TERM_DT;
	}

	public void setMECB_TERM_DT(String mECB_TERM_DT) {
		MECB_TERM_DT = mECB_TERM_DT;
	}

	public String getMCRE_NAME() {
		return MCRE_NAME;
	}

	public void setMCRE_NAME(String mCRE_NAME) {
		MCRE_NAME = mCRE_NAME;
	}

	public String getMCRE_ADDR1() {
		return MCRE_ADDR1;
	}

	public void setMCRE_ADDR1(String mCRE_ADDR1) {
		MCRE_ADDR1 = mCRE_ADDR1;
	}

	public String getMCRE_ADDR2() {
		return MCRE_ADDR2;
	}

	public void setMCRE_ADDR2(String mCRE_ADDR2) {
		MCRE_ADDR2 = mCRE_ADDR2;
	}

	public String getMCRE_CITY() {
		return MCRE_CITY;
	}

	public void setMCRE_CITY(String mCRE_CITY) {
		MCRE_CITY = mCRE_CITY;
	}

	public String getMCRE_STATE() {
		return MCRE_STATE;
	}

	public void setMCRE_STATE(String mCRE_STATE) {
		MCRE_STATE = mCRE_STATE;
	}

	public String getMCRE_ZIP() {
		return MCRE_ZIP;
	}

	public void setMCRE_ZIP(String mCRE_ZIP) {
		MCRE_ZIP = mCRE_ZIP;
	}

	public String getMCRE_CTRY_CD() {
		return MCRE_CTRY_CD;
	}

	public void setMCRE_CTRY_CD(String mCRE_CTRY_CD) {
		MCRE_CTRY_CD = mCRE_CTRY_CD;
	}

	public String getCSPI_ID() {
		return CSPI_ID;
	}

	public void setCSPI_ID(String cSPI_ID) {
		CSPI_ID = cSPI_ID;
	}

	public String getGRGR_EIN() {
		return GRGR_EIN;
	}

	public void setGRGR_EIN(String gRGR_EIN) {
		GRGR_EIN = gRGR_EIN;
	}

	public String getMEPE_TERM_DT() {
		return MEPE_TERM_DT;
	}

	public void setMEPE_TERM_DT(String mEPE_TERM_DT) {
		MEPE_TERM_DT = mEPE_TERM_DT;
	}

	public String getMEPE_EFF_DT() {
		return MEPE_EFF_DT;
	}

	public void setMEPE_EFF_DT(String mEPE_EFF_DT) {
		MEPE_EFF_DT = mEPE_EFF_DT;
	}

	public String getCSPD_CAT() {
		return CSPD_CAT;
	}

	public void setCSPD_CAT(String cSPD_CAT) {
		CSPD_CAT = cSPD_CAT;
	}

	public String getSBAD_FAX() {
		return SBAD_FAX;
	}

	public void setSBAD_FAX(String sBAD_FAX) {
		SBAD_FAX = sBAD_FAX;
	}

	public String getCSCS_ID() {
		return CSCS_ID;
	}

	public void setCSCS_ID(String cSCS_ID) {
		CSCS_ID = cSCS_ID;
	}

	public String getSBSB_ID() {
		return SBSB_ID;
	}

	public void setSBSB_ID(String sBSB_ID) {
		SBSB_ID = sBSB_ID;
	}

	public String getMEME_FIRST_NAME() {
		return MEME_FIRST_NAME;
	}

	public void setMEME_FIRST_NAME(String mEME_FIRST_NAME) {
		MEME_FIRST_NAME = mEME_FIRST_NAME;
	}

	public String getMEME_LAST_NAME() {
		return MEME_LAST_NAME;
	}

	public void setMEME_LAST_NAME(String mEME_LAST_NAME) {
		MEME_LAST_NAME = mEME_LAST_NAME;
	}

	public String getMEME_MID_INIT() {
		return MEME_MID_INIT;
	}

	public void setMEME_MID_INIT(String mEME_MID_INIT) {
		MEME_MID_INIT = mEME_MID_INIT;
	}

	public String getSBAD_ADDR2() {
		return SBAD_ADDR2;
	}

	public void setSBAD_ADDR2(String sBAD_ADDR2) {
		SBAD_ADDR2 = sBAD_ADDR2;
	}

	public String getSBAD_CITY() {
		return SBAD_CITY;
	}

	public void setSBAD_CITY(String sBAD_CITY) {
		SBAD_CITY = sBAD_CITY;
	}

	public String getSBAD_STATE() {
		return SBAD_STATE;
	}

	public void setSBAD_STATE(String sBAD_STATE) {
		SBAD_STATE = sBAD_STATE;
	}

	public String getSBAD_ZIP() {
		return SBAD_ZIP;
	}

	public void setSBAD_ZIP(String sBAD_ZIP) {
		SBAD_ZIP = sBAD_ZIP;
	}

	public String getMEME_TITLE() {
		return MEME_TITLE;
	}

	public void setMEME_TITLE(String mEME_TITLE) {
		MEME_TITLE = mEME_TITLE;
	}

	public String getSBAD_PHONE() {
		return SBAD_PHONE;
	}

	public void setSBAD_PHONE(String sBAD_PHONE) {
		SBAD_PHONE = sBAD_PHONE;
	}

	public String getSBAD_EMAIL() {
		return SBAD_EMAIL;
	}

	public void setSBAD_EMAIL(String sBAD_EMAIL) {
		SBAD_EMAIL = sBAD_EMAIL;
	}

	public String getSBAD_TYPE_HOME() {
		return SBAD_TYPE_HOME;
	}

	public void setSBAD_TYPE_HOME(String sBAD_TYPE_HOME) {
		SBAD_TYPE_HOME = sBAD_TYPE_HOME;
	}

	public String getMEME_REL() {
		return MEME_REL;
	}

	public void setMEME_REL(String mEME_REL) {
		MEME_REL = mEME_REL;
	}

	public String getSBSB_MCTR_STS() {
		return SBSB_MCTR_STS;
	}

	public void setSBSB_MCTR_STS(String sBSB_MCTR_STS) {
		SBSB_MCTR_STS = sBSB_MCTR_STS;
	}

	public String getMEME_SFX() {
		return MEME_SFX;
	}

	public void setMEME_SFX(String mEME_SFX) {
		MEME_SFX = mEME_SFX;
	}

	public String getGRGR_ID() {
		return GRGR_ID;
	}

	public void setGRGR_ID(String gRGR_ID) {
		GRGR_ID = gRGR_ID;
	}

	public String getMEME_HICN() {
		return MEME_HICN;
	}

	public void setMEME_HICN(String mEME_HICN) {
		MEME_HICN = mEME_HICN;
	}

	public String getGRGR_NAME() {
		return GRGR_NAME;
	}

	public void setGRGR_NAME(String gRGR_NAME) {
		GRGR_NAME = gRGR_NAME;
	}

	public String getSBSB_ORIG_EFF_DT() {
		return SBSB_ORIG_EFF_DT;
	}

	public void setSBSB_ORIG_EFF_DT(String sBSB_ORIG_EFF_DT) {
		SBSB_ORIG_EFF_DT = sBSB_ORIG_EFF_DT;
	}

	public String getMEME_SSN() {
		return MEME_SSN;
	}

	public void setMEME_SSN(String mEME_SSN) {
		MEME_SSN = mEME_SSN;
	}

	public String getMEME_BIRTH_DT() {
		return MEME_BIRTH_DT;
	}

	public void setMEME_BIRTH_DT(String mEME_BIRTH_DT) {
		MEME_BIRTH_DT = mEME_BIRTH_DT;
	}

	public String getMEME_SEX() {
		return MEME_SEX;
	}

	public void setMEME_SEX(String mEME_SEX) {
		MEME_SEX = mEME_SEX;
	}

	public String getMEME_MARITAL_STATUS() {
		return MEME_MARITAL_STATUS;
	}

	public void setMEME_MARITAL_STATUS(String mEME_MARITAL_STATUS) {
		MEME_MARITAL_STATUS = mEME_MARITAL_STATUS;
	}

	public String getMEME_MCTR_LANG() {
		return MEME_MCTR_LANG;
	}

	public void setMEME_MCTR_LANG(String mEME_MCTR_LANG) {
		MEME_MCTR_LANG = mEME_MCTR_LANG;
	}

	public String getSBAD_ADDR1() {
		return SBAD_ADDR1;
	}

	public void setSBAD_ADDR1(String sBAD_ADDR1) {
		SBAD_ADDR1 = sBAD_ADDR1;
	}

	public String getSGSG_ID() {
		return SGSG_ID;
	}

	public void setSGSG_ID(String sGSG_ID) {
		SGSG_ID = sGSG_ID;
	}

}
