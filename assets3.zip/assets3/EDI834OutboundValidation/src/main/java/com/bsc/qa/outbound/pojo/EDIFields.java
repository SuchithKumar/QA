package com.bsc.qa.outbound.pojo;

public class EDIFields {
	private String ins01;
	private String ins02;
	private String ins03;
	private String ins04;
	private String ins05;
	private String ins06;
	private String ins07;
	private String ins08;
	private String ins09;
	private String ins10;
	private String ref01_1;
	private String ref02_1;
	private String ref01_2;
	private String ref02_2;
	private String ref01_3;
	private String ref02_3;
	private String ref01_4;
	private String ref02_4;
	private String ref01_5;
	private String ref02_5;
	private String ref01_p5;
	private String ref02_p5;
	private String ref01_6;
	private String ref02_6;
	private String ref01_7;
	private String ref02_7;
	private String dtp01_1;
	private String dtp02_1;
	private String dtp03_1;
	private String nm101_1;
	private String nm102_1;
	private String nm103_1;
	private String nm104_1;
	private String nm105_1;
	private String nm106_1;
	private String nm107_1;
	private String nm108_1;
	private String nm109_1;
	private String per01;
	private String per03;
	private String per04;
	private String per05;
	private String per06;
	private String per07;
	private String per08;
	private String n301_1;
	private String n302_1;
	private String n401_1;
	private String n402_1;
	private String n403_1;
	private String n404_1;
	private String n405_1;
	private String n406_1;
	private String dmg01;
	private String dmg02;
	private String dmg03;
	private String dmg04;
	private String dmg05;
	private String dmg06;
	private String nm101_2;
	private String nm102_2;
	private String n301_2;
	private String n302_2;
	private String n401_2;
	private String n402_2;
	private String n403_2;
	private String n404_2;
	private String hd01;
	private String hd03;
	private String hd04;
	private String hd05;
	private String dtp01_2;
	private String dtp02_2;
	private String dtp03_2;
	private String dtp01_3;
	private String dtp02_3;
	private String dtp03_3;
	private String cob01;
	private String cob02;
	private String cob03;
	private String cob04;
	private String dtp01_4;
	private String dtp02_4;
	private String dtp03_4;
	private String dtp01_5;
	private String dtp02_5;
	private String dtp03_5;
	private String nm101_3;
	private String nm102_3;
	private String nm103_3;
	private String n301_3;
	private String n302_3;
	private String n401_3;
	private String n402_3;
	private String n403_3;
	private String n404_3;

	private String email;
	private String tpa01;
	private String ipa01;
	private String ref_zz01;
	private String ref_zz02;

	public String getRef_zz01() {
		return ref_zz01;
	}

	public void setRef_zz01(String ref_zz01) {
		this.ref_zz01 = ref_zz01;
	}

	public String getRef_zz02() {
		return ref_zz02;
	}

	public void setRef_zz02(String ref_zz02) {
		this.ref_zz02 = ref_zz02;
	}

	public String getTpa01() {
		return tpa01;
	}

	public void setTpa01(String tpa01) {
		this.tpa01 = tpa01;
	}

	public String getIpa01() {
		return ipa01;
	}

	public void setIpa01(String ipa01) {
		this.ipa01 = ipa01;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRef01_p5() {
		return ref01_p5;
	}

	public void setRef01_p5(String ref01_p5) {
		this.ref01_p5 = ref01_p5;
	}

	public String getRef02_p5() {
		return ref02_p5;
	}

	public void setRef02_p5(String ref02_p5) {
		this.ref02_p5 = ref02_p5;
	}

	public String getDtp03_1() {
		return dtp03_1;
	}

	public void setDtp03_1(String dtp03_1) {
		this.dtp03_1 = dtp03_1;
	}

	public String getCob01() {
		return cob01;
	}

	public void setCob01(String cob01) {
		this.cob01 = cob01;
	}

	public String getCob02() {
		return cob02;
	}

	public void setCob02(String cob02) {
		this.cob02 = cob02;
	}

	public String getCob03() {
		return cob03;
	}

	public void setCob03(String cob03) {
		this.cob03 = cob03;
	}

	public String getCob04() {
		return cob04;
	}

	public void setCob04(String cob04) {
		this.cob04 = cob04;
	}

	public String getDtp01_4() {
		return dtp01_4;
	}

	public void setDtp01_4(String dtp01_4) {
		this.dtp01_4 = dtp01_4;
	}

	public String getDtp02_4() {
		return dtp02_4;
	}

	public void setDtp02_4(String dtp02_4) {
		this.dtp02_4 = dtp02_4;
	}

	public String getDtp03_4() {
		return dtp03_4;
	}

	public void setDtp03_4(String dtp03_4) {
		this.dtp03_4 = dtp03_4;
	}

	public String getDtp01_5() {
		return dtp01_5;
	}

	public void setDtp01_5(String dtp01_5) {
		this.dtp01_5 = dtp01_5;
	}

	public String getDtp02_5() {
		return dtp02_5;
	}

	public void setDtp02_5(String dtp02_5) {
		this.dtp02_5 = dtp02_5;
	}

	public String getDtp03_5() {
		return dtp03_5;
	}

	public void setDtp03_5(String dtp03_5) {
		this.dtp03_5 = dtp03_5;
	}

	public String getNm101_3() {
		return nm101_3;
	}

	public void setNm101_3(String nm101_3) {
		this.nm101_3 = nm101_3;
	}

	public String getNm102_3() {
		return nm102_3;
	}

	public void setNm102_3(String nm102_3) {
		this.nm102_3 = nm102_3;
	}

	public String getNm103_3() {
		return nm103_3;
	}

	public void setNm103_3(String nm103_3) {
		this.nm103_3 = nm103_3;
	}

	public String getN301_3() {
		return n301_3;
	}

	public void setN301_3(String n301_3) {
		this.n301_3 = n301_3;
	}

	public String getN302_3() {
		return n302_3;
	}

	public void setN302_3(String n302_3) {
		this.n302_3 = n302_3;
	}

	public String getN401_3() {
		return n401_3;
	}

	public void setN401_3(String n401_3) {
		this.n401_3 = n401_3;
	}

	public String getN402_3() {
		return n402_3;
	}

	public void setN402_3(String n402_3) {
		this.n402_3 = n402_3;
	}

	public String getN403_3() {
		return n403_3;
	}

	public void setN403_3(String n403_3) {
		this.n403_3 = n403_3;
	}

	public String getN404_3() {
		return n404_3;
	}

	public void setN404_3(String n404_3) {
		this.n404_3 = n404_3;
	}

	public String getIns01() {
		return ins01;
	}

	public void setIns01(String ins01) {
		this.ins01 = ins01;
	}

	public String getIns02() {
		return ins02;
	}

	public void setIns02(String ins02) {
		this.ins02 = ins02;
	}

	public String getIns03() {
		return ins03;
	}

	public void setIns03(String ins03) {
		this.ins03 = ins03;
	}

	public String getIns04() {
		return ins04;
	}

	public void setIns04(String ins04) {
		this.ins04 = ins04;
	}

	public String getIns05() {
		return ins05;
	}

	public void setIns05(String ins05) {
		this.ins05 = ins05;
	}

	public String getIns06() {
		return ins06;
	}

	public void setIns06(String ins06) {
		this.ins06 = ins06;
	}

	public String getIns07() {
		return ins07;
	}

	public void setIns07(String ins07) {
		this.ins07 = ins07;
	}

	public String getIns08() {
		return ins08;
	}

	public void setIns08(String ins08) {
		this.ins08 = ins08;
	}

	public String getIns09() {
		return ins09;
	}

	public void setIns09(String ins09) {
		this.ins09 = ins09;
	}

	public String getIns10() {
		return ins10;
	}

	public void setIns10(String ins10) {
		this.ins10 = ins10;
	}

	public String getRef01_1() {
		return ref01_1;
	}

	public void setRef01_1(String ref01_1) {
		this.ref01_1 = ref01_1;
	}

	public String getRef02_1() {
		return ref02_1;
	}

	public void setRef02_1(String ref02_1) {
		this.ref02_1 = ref02_1;
	}

	public String getRef01_2() {
		return ref01_2;
	}

	public void setRef01_2(String ref01_2) {
		this.ref01_2 = ref01_2;
	}

	public String getRef02_2() {
		return ref02_2;
	}

	public void setRef02_2(String ref02_2) {
		this.ref02_2 = ref02_2;
	}

	public String getRef01_3() {
		return ref01_3;
	}

	public void setRef01_3(String ref01_3) {
		this.ref01_3 = ref01_3;
	}

	public String getRef02_3() {
		return ref02_3;
	}

	public void setRef02_3(String ref02_3) {
		this.ref02_3 = ref02_3;
	}

	public String getRef01_4() {
		return ref01_4;
	}

	public void setRef01_4(String ref01_4) {
		this.ref01_4 = ref01_4;
	}

	public String getRef02_4() {
		return ref02_4;
	}

	public void setRef02_4(String ref02_4) {
		this.ref02_4 = ref02_4;
	}

	public String getRef01_5() {
		return ref01_5;
	}

	public void setRef01_5(String ref01_5) {
		this.ref01_5 = ref01_5;
	}

	public String getRef02_5() {
		return ref02_5;
	}

	public void setRef02_5(String ref02_5) {
		this.ref02_5 = ref02_5;
	}

	public String getRef01_6() {
		return ref01_6;
	}

	public void setRef01_6(String ref01_6) {
		this.ref01_6 = ref01_6;
	}

	public String getRef02_6() {
		return ref02_6;
	}

	public void setRef02_6(String ref02_6) {
		this.ref02_6 = ref02_6;
	}

	public String getRef01_7() {
		return ref01_7;
	}

	public void setRef01_7(String ref01_7) {
		this.ref01_7 = ref01_7;
	}

	public String getRef02_7() {
		return ref02_7;
	}

	public void setRef02_7(String ref02_7) {
		this.ref02_7 = ref02_7;
	}

	public String getDtp01_1() {
		return dtp01_1;
	}

	public void setDtp01_1(String dtp01_1) {
		this.dtp01_1 = dtp01_1;
	}

	public String getDtp02_1() {
		return dtp02_1;
	}

	public void setDtp02_1(String dtp02_1) {
		this.dtp02_1 = dtp02_1;
	}

	public String getDtp01_2() {
		return dtp01_2;
	}

	public void setDtp01_2(String dtp01_2) {
		this.dtp01_2 = dtp01_2;
	}

	public String getDtp02_2() {
		return dtp02_2;
	}

	public void setDtp02_2(String dtp02_2) {
		this.dtp02_2 = dtp02_2;
	}

	public String getDtp03_2() {
		return dtp03_2;
	}

	public void setDtp03_2(String dtp03_2) {
		this.dtp03_2 = dtp03_2;
	}

	public String getDtp01_3() {
		return dtp01_3;
	}

	public void setDtp01_3(String dtp01_3) {
		this.dtp01_3 = dtp01_3;
	}

	public String getDtp02_3() {
		return dtp02_3;
	}

	public void setDtp02_3(String dtp02_3) {
		this.dtp02_3 = dtp02_3;
	}

	public String getDtp03_3() {
		return dtp03_3;
	}

	public void setDtp03_3(String dtp03_3) {
		this.dtp03_3 = dtp03_3;
	}

	public String getNm101_1() {
		return nm101_1;
	}

	public void setNm101_1(String nm101_1) {
		this.nm101_1 = nm101_1;
	}

	public String getNm102_1() {
		return nm102_1;
	}

	public void setNm102_1(String nm102_1) {
		this.nm102_1 = nm102_1;
	}

	public String getNm103_1() {
		return nm103_1;
	}

	public void setNm103_1(String nm103_1) {
		this.nm103_1 = nm103_1;
	}

	public String getNm104_1() {
		return nm104_1;
	}

	public void setNm104_1(String nm104_1) {
		this.nm104_1 = nm104_1;
	}

	public String getNm105_1() {
		return nm105_1;
	}

	public void setNm105_1(String nm105_1) {
		this.nm105_1 = nm105_1;
	}

	public String getNm106_1() {
		return nm106_1;
	}

	public void setNm106_1(String nm106_1) {
		this.nm106_1 = nm106_1;
	}

	public String getNm107_1() {
		return nm107_1;
	}

	public void setNm107_1(String nm107_1) {
		this.nm107_1 = nm107_1;
	}

	public String getNm108_1() {
		return nm108_1;
	}

	public void setNm108_1(String nm108_1) {
		this.nm108_1 = nm108_1;
	}

	public String getNm109_1() {
		return nm109_1;
	}

	public void setNm109_1(String nm109_1) {
		this.nm109_1 = nm109_1;
	}

	public String getPer01() {
		return per01;
	}

	public void setPer01(String per01) {
		this.per01 = per01;
	}

	public String getPer03() {
		return per03;
	}

	public void setPer03(String per03) {
		this.per03 = per03;
	}

	public String getPer04() {
		return per04;
	}

	public void setPer04(String per04) {
		this.per04 = per04;
	}

	public String getPer05() {
		return per05;
	}

	public void setPer05(String per05) {
		this.per05 = per05;
	}

	public String getPer06() {
		return per06;
	}

	public void setPer06(String per06) {
		this.per06 = per06;
	}

	public String getPer07() {
		return per07;
	}

	public void setPer07(String per07) {
		this.per07 = per07;
	}

	public String getPer08() {
		return per08;
	}

	public void setPer08(String per08) {
		this.per08 = per08;
	}

	public String getN301_1() {
		return n301_1;
	}

	public void setN301_1(String n301_1) {
		this.n301_1 = n301_1;
	}

	public String getN302_1() {
		return n302_1;
	}

	public void setN302_1(String n302_1) {
		this.n302_1 = n302_1;
	}

	public String getN401_1() {
		return n401_1;
	}

	public void setN401_1(String n401_1) {
		this.n401_1 = n401_1;
	}

	public String getN402_1() {
		return n402_1;
	}

	public void setN402_1(String n402_1) {
		this.n402_1 = n402_1;
	}

	public String getN403_1() {
		return n403_1;
	}

	public void setN403_1(String n403_1) {
		this.n403_1 = n403_1;
	}

	public String getN404_1() {
		return n404_1;
	}

	public void setN404_1(String n404_1) {
		this.n404_1 = n404_1;
	}

	public String getN405_1() {
		return n405_1;
	}

	public void setN405_1(String n405_1) {
		this.n405_1 = n405_1;
	}

	public String getN406_1() {
		return n406_1;
	}

	public void setN406_1(String n406_1) {
		this.n406_1 = n406_1;
	}

	public String getDmg01() {
		return dmg01;
	}

	public void setDmg01(String dmg01) {
		this.dmg01 = dmg01;
	}

	public String getDmg02() {
		return dmg02;
	}

	public void setDmg02(String dmg02) {
		this.dmg02 = dmg02;
	}

	public String getDmg03() {
		return dmg03;
	}

	public void setDmg03(String dmg03) {
		this.dmg03 = dmg03;
	}

	public String getDmg04() {
		return dmg04;
	}

	public void setDmg04(String dmg04) {
		this.dmg04 = dmg04;
	}

	public String getDmg05() {
		return dmg05;
	}

	public void setDmg05(String dmg05) {
		this.dmg05 = dmg05;
	}

	public String getDmg06() {
		return dmg06;
	}

	public void setDmg06(String dmg06) {
		this.dmg06 = dmg06;
	}

	public String getNm101_2() {
		return nm101_2;
	}

	public void setNm101_2(String nm101_2) {
		this.nm101_2 = nm101_2;
	}

	public String getNm102_2() {
		return nm102_2;
	}

	public void setNm102_2(String nm102_2) {
		this.nm102_2 = nm102_2;
	}

	public String getN301_2() {
		return n301_2;
	}

	public void setN301_2(String n301_2) {
		this.n301_2 = n301_2;
	}

	public String getN302_2() {
		return n302_2;
	}

	public void setN302_2(String n302_2) {
		this.n302_2 = n302_2;
	}

	public String getN401_2() {
		return n401_2;
	}

	public void setN401_2(String n401_2) {
		this.n401_2 = n401_2;
	}

	public String getN402_2() {
		return n402_2;
	}

	public void setN402_2(String n402_2) {
		this.n402_2 = n402_2;
	}

	public String getN403_2() {
		return n403_2;
	}

	public void setN403_2(String n403_2) {
		this.n403_2 = n403_2;
	}

	public String getN404_2() {
		return n404_2;
	}

	public void setN404_2(String n404_2) {
		this.n404_2 = n404_2;
	}

	public String getHd01() {
		return hd01;
	}

	public void setHd01(String hd01) {
		this.hd01 = hd01;
	}

	public String getHd03() {
		return hd03;
	}

	public void setHd03(String hd03) {
		this.hd03 = hd03;
	}

	public String getHd04() {
		return hd04;
	}

	public void setHd04(String hd04) {
		this.hd04 = hd04;
	}

	public String getHd05() {
		return hd05;
	}

	public void setHd05(String hd05) {
		this.hd05 = hd05;
	}

}
