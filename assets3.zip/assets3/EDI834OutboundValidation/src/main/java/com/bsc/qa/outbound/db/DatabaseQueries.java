package com.bsc.qa.outbound.db;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;

import com.bsc.qa.outbound.pojo.DatabaseData;
import com.bsc.qa.outbound.pojo.EDIFields;
import com.bsc.qa.outbound.util.FileParse;
import com.bsc.qa.outbound.util.FileUtil;

/**
 * @author jgupta03
 *
 */
//TODO: Very out of place. Possibly not straightforward to maintain. Review with BQSA support team and see if we can bring this back to using the BQSA standard - For 8/2019 - we are letting this be the way it is.
public class DatabaseQueries {
	Map<String, String> map;

	public static void main(String[] args) {
		DatabaseQueries dq = new DatabaseQueries();
		dq.getDatabaseData(null, null);

	}

	public List<DatabaseData> getDatabaseData(List<EDIFields> ediFields,
			Session session) {

		FileUtil util = new FileUtil();
		FileParse fileParse = new FileParse();
		String file_type = fileParse.getFileType();
		map = util.queriesMap();
		Query cob, demographicquery, addressquery, eligiblityquery, groupquery, itsprefixquery, mest_type, cspi_eff_dt = null;

		List<DatabaseData> dblist = new ArrayList<DatabaseData>();
		for (int i = 0; i < ediFields.size(); i++) {
			DatabaseData data = new DatabaseData();
			String meme_ssn = ediFields.get(i).getNm109_1();
			String cscs_id = ediFields.get(i).getRef02_3();
			String eff_dt = ediFields.get(i).getDtp03_2();
			List<Object[]> cspi_eff_dtlist = null;
			if (file_type.equalsIgnoreCase("COO")) {

				String sbsb_id = ediFields.get(i).getRef02_4().substring(3, 12);
				String sfx = ediFields.get(i).getRef02_4().substring(13);
				demographicquery = session
						.createSQLQuery(map.get("COOMemberDemographic"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				addressquery = session
						.createSQLQuery(map.get("COOMemberAddress"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				eligiblityquery = session
						.createSQLQuery(map.get("COOMemberEligiblity"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				groupquery = session.createSQLQuery(map.get("COOMemberGroup"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				itsprefixquery = session
						.createSQLQuery(map.get("COOITSPrefix"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				mest_type = session.createSQLQuery(map.get("COOMestType"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
			} else if (file_type.equalsIgnoreCase("Silver Sneakers")) {
				System.out.println(ediFields.get(i).getRef02_1()
						.substring(0, 9)
						+ "----" + ediFields.get(i).getRef02_4());
				String sbsb_id = ediFields.get(i).getRef02_1().substring(0, 9);
				String sfx = ediFields.get(i).getRef02_1().substring(10);
				demographicquery = session
						.createSQLQuery(map.get("COOMemberDemographic"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				addressquery = session
						.createSQLQuery(map.get("COOMemberAddress"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				eligiblityquery = session
						.createSQLQuery(map.get("COOMemberEligiblity"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				groupquery = session.createSQLQuery(map.get("COOMemberGroup"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				itsprefixquery = session
						.createSQLQuery(map.get("COOITSPrefix"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);
				mest_type = session.createSQLQuery(map.get("COOMestType"))
						.setParameter("sbsb_id", sbsb_id)
						.setParameter("sfx", sfx);

			} else {

				demographicquery = session.createSQLQuery(
						map.get("MemberDemographic")).setParameter("ssn",
						meme_ssn);
				addressquery = session.createSQLQuery(map.get("MemberAddress"))
						.setParameter("ssn", meme_ssn);
				eligiblityquery = session.createSQLQuery(
						map.get("MemberEligiblity")).setParameter("ssn",
						meme_ssn);
				groupquery = session.createSQLQuery(map.get("MemberGroup"))
						.setParameter("ssn", meme_ssn);
				itsprefixquery = session.createSQLQuery(map.get("ITSPrefix"))
						.setParameter("ssn", meme_ssn);
				mest_type = session.createSQLQuery(map.get("MestType"))
						.setParameter("ssn", meme_ssn);
				cspi_eff_dt = session.createSQLQuery(map.get("CSPIEffDate"))
						.setParameter("meme_ssn", meme_ssn)
						.setParameter("cscs_id", cscs_id)
						.setParameter("eff_dt", eff_dt);
				cspi_eff_dtlist = cspi_eff_dt.list();
			}

			List<Object[]> demographiclist = demographicquery.list();
			List<Object[]> addresslist = addressquery.list();
			List<Object[]> eligiblitylist = eligiblityquery.list();
			List<Object[]> grouplist = groupquery.list();
			List mest_typelist = mest_type.list();
			if (!file_type.equalsIgnoreCase("COO")
					&& !file_type.equalsIgnoreCase("Silver Sneakers")) {
				if (cspi_eff_dtlist.size() > 0) {
					data.setCSPI_EFF_DT((String) cspi_eff_dtlist.get(0)[1]);
				}
			}
			if (demographiclist.size() > 0) {
				data.setSBSB_ID((String) demographiclist.get(0)[0]);
				data.setMEME_FIRST_NAME((String) demographiclist.get(0)[1]);
				data.setMEME_LAST_NAME((String) demographiclist.get(0)[2]);
				data.setMEME_MID_INIT((String) demographiclist.get(0)[3]);
				data.setMEME_TITLE((String) demographiclist.get(0)[4]);
				data.setMEME_REL((String) demographiclist.get(0)[5]);
				data.setSBSB_MCTR_STS((String) demographiclist.get(0)[6]);
				data.setMEME_SFX(((BigDecimal) demographiclist.get(0)[7])
						.toPlainString());
				data.setMEME_HICN((String) demographiclist.get(0)[8]);
				data.setSBSB_ORIG_EFF_DT(new SimpleDateFormat("YYYYMMdd")
						.format((Date) demographiclist.get(0)[9]));
				data.setMEME_SSN((String) demographiclist.get(0)[10]);
				data.setMEME_BIRTH_DT(new SimpleDateFormat("YYYYMMdd")
						.format((Date) demographiclist.get(0)[11]));
				data.setMEME_SEX((String) demographiclist.get(0)[12]);
				data.setMEME_MARITAL_STATUS((String) demographiclist.get(0)[13]);
				data.setMEME_MCTR_LANG((String) demographiclist.get(0)[14]);
			}

			if (addresslist.size() > 0) {
				data.setSBAD_ADDR1((String) addresslist.get(0)[0]);
				data.setSBAD_ADDR2((String) addresslist.get(0)[1]);
				data.setSBAD_CITY((String) addresslist.get(0)[2]);
				data.setSBAD_STATE((String) addresslist.get(0)[3]);
				data.setSBAD_ZIP((String) addresslist.get(0)[4]);
				data.setSBAD_PHONE((String) addresslist.get(0)[5]);
				data.setSBAD_EMAIL((String) addresslist.get(0)[6]);
				data.setSBAD_TYPE_HOME((String) addresslist.get(0)[7]);
				data.setSBAD_FAX((String) addresslist.get(0)[8]);
			}

			if (mest_typelist.size() > 0) {
				data.setMEST_TYPE((String) mest_typelist.get(0));
			}
			if (eligiblitylist.size() > 0) {
				data.setCSCS_ID((String) eligiblitylist.get(0)[0]);
				data.setCSPD_CAT((String) eligiblitylist.get(0)[1]);
				data.setMEPE_TERM_DT((String) eligiblitylist.get(0)[2]);
				data.setMEPE_EFF_DT(new SimpleDateFormat("YYYYMMdd")
						.format((Date) eligiblitylist.get(0)[3]));
				data.setCSPI_ID((String) eligiblitylist.get(0)[4]);

				data.setCSPI_ITS_PREFIX((String) itsprefixquery.list().get(0));

				// System.out.println(eligiblitylist.get(0)[5]);
				data.setGRGR_ID((String) grouplist.get(0)[1]);

				data.setGRGR_NAME((String) grouplist.get(0)[2]);

				data.setGRGR_EIN((String) grouplist.get(0)[3]);
				data.setSGSG_ID((String) grouplist.get(0)[4]);

			}
			if (ediFields.get(i).getCob01() != null) {
				if (file_type.equalsIgnoreCase("COO")) {

					String sbsb_id = ediFields.get(i).getRef02_4()
							.substring(3, 12);
					String sfx = ediFields.get(i).getRef02_4().substring(13);
					cob = session.createSQLQuery(map.get("COOCOB"))
							.setParameter("sbsb_id", sbsb_id)
							.setParameter("sfx", sfx);
				} else {
					cob = session.createSQLQuery(map.get("COB")).setParameter(
							"ssn", meme_ssn);

				}
				List<Object[]> coblist = cob.list();

				data.setMECB_INSUR_ORDER((String) coblist.get(0)[0]);
				data.setMECB_POLICY_ID((String) coblist.get(0)[1]);
				data.setMECB_INSUR_TYPE((String) coblist.get(0)[2]);
				data.setMECB_EFF_DT(new SimpleDateFormat("YYYYMMdd")
						.format((Date) coblist.get(0)[3]));
				data.setMECB_TERM_DT(new SimpleDateFormat("YYYYMMdd")
						.format((Date) coblist.get(0)[4]));
				data.setMCRE_NAME((String) coblist.get(0)[5]);
				data.setMCRE_ADDR1((String) coblist.get(0)[6]);
				data.setMCRE_ADDR2((String) coblist.get(0)[7]);
				data.setMCRE_CITY((String) coblist.get(0)[8]);
				data.setMCRE_STATE((String) coblist.get(0)[9]);
				data.setMCRE_ZIP((String) coblist.get(0)[10]);
				data.setMCRE_CTRY_CD((String) coblist.get(0)[11]);
			}

			dblist.add(data);
		}
		return dblist;
	}
}
