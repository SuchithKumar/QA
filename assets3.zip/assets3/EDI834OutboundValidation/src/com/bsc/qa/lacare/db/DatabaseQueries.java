package com.bsc.qa.lacare.db;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.w3c.dom.ls.LSInput;

import com.bsc.qa.lacare.pojo.Connection;
import com.bsc.qa.lacare.pojo.DatabaseData;
import com.bsc.qa.lacare.pojo.EDIFields;
import com.bsc.qa.lacare.util.FileUtil;
import com.bsc.qa.lacare.util.HibernateUtil;

/**
 * @author jgupta03
 *
 */
public class DatabaseQueries {
	Map<String, String> map;
	

	
	public List<DatabaseData> getDatabaseData(List<EDIFields> ediFields, Session session) {
		
		FileUtil util = new FileUtil();
		map = util.queriesMap();
		List<DatabaseData> dblist=new ArrayList<DatabaseData>();
		for (int i = 0; i < ediFields.size(); i++) {
		DatabaseData data = new DatabaseData();
		String meme_ssn=ediFields.get(i).getRef02_1();
		Query query = session.createSQLQuery(map.get("query") + "'" + meme_ssn
				+ "'"+" order by ELIG.MEPE_TERM_DT desc");
		List<Object[]> list = query.list();
		data.setCSCS_ID((String)list.get(0)[0]);
		data.setSBSB_ID((String)list.get(0)[1]);
		data.setMEME_FIRST_NAME((String)list.get(0)[2]);
		data.setMEME_LAST_NAME((String)list.get(0)[3]);
		data.setMEME_MID_INIT((String)list.get(0)[4]);
		data.setSBAD_ADDR2((String)list.get(0)[5]);
		data.setSBAD_CITY((String)list.get(0)[6]);
		data.setSBAD_STATE((String)list.get(0)[7]);
		data.setSBAD_ZIP((String)list.get(0)[8]);
		data.setMEME_TITLE((String)list.get(0)[9]);
		data.setSBAD_PHONE((String)list.get(0)[10]);
		data.setSBAD_EMAIL((String)list.get(0)[11]);
		data.setSBAD_TYPE_HOME((String)list.get(0)[12]);
		data.setMEME_REL((String)list.get(0)[13]);
		data.setSBSB_MCTR_STS((String) list.get(0)[14]);
		data.setMEME_SFX(((BigDecimal)list.get(0)[15]).toPlainString());
		data.setGRGR_ID((String)list.get(0)[16]);
		data.setMEME_HICN((String)list.get(0)[17]);
		data.setGRGR_NAME((String)list.get(0)[18]);
		data.setSBSB_ORIG_EFF_DT(new SimpleDateFormat("YYYYMMdd").format((Date)list.get(0)[19]));
		data.setMEME_SSN((String)list.get(0)[20]);
		data.setMEME_BIRTH_DT(new SimpleDateFormat("YYYYMMdd").format((Date)list.get(0)[21]));
		data.setMEME_SEX((String)list.get(0)[22]);
		data.setMEME_MARITAL_STATUS((String)list.get(0)[23]);
		data.setMEME_MCTR_LANG((String)list.get(0)[24]);
		data.setSBAD_ADDR1((String)list.get(0)[25]);
		data.setSGSG_ID((String)list.get(0)[26]);
		data.setSBAD_FAX((String)list.get(0)[27]);
		data.setCSPD_CAT((String)list.get(0)[28]);
		data.setMEPE_TERM_DT(new SimpleDateFormat("YYYYMMdd").format((Date)list.get(0)[29]));
		data.setMEPE_EFF_DT(new SimpleDateFormat("YYYYMMdd").format((Date)list.get(0)[30]));

		dblist.add(data);
		}
		return dblist;
	}
}
