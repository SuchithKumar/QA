package com.bsc.qa.lacare.util;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bsc.qa.lacare.pojo.EDIFields;

public class XMLParsetoObject {
	List<Map<String, String>> listmap;

	public void parseFile() {
		try {

			File fXmlFile = new File(
					"\\\\bsc\\it\\VDI_Home_SAC\\plambh01\\Desktop\\CountyFamily.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			listmap = new ArrayList<Map<String, String>>();
			Map<String, String> map;

			// optional, but recommended
			// read this -
			// http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();

			System.out.println("Root element :"
					+ doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName("segment");
			NodeList elisList = nList.item(0).getChildNodes();
			System.out.println("----------------------------");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;

					// Length of child node
					NodeList eList = nList.item(temp).getChildNodes();
					map = new HashMap<String, String>();
					for (int temp1 = 0; temp1 < ((eList.getLength() - 1) / 2); temp1++) {
						Node eNode = eList.item(temp1);
						Element elElement = (Element) nNode;
						// System.out.println("Staff id : " +
						// eElement.getNodeValue());
						map.put(eElement.getElementsByTagName("element")
								.item(temp1).getAttributes().getNamedItem("Id")
								.getNodeValue(),
								eElement.getElementsByTagName("element")
										.item(temp1).getTextContent());
						System.out.println(eElement
								.getElementsByTagName("element").item(temp1)
								.getAttributes().getNamedItem("Id")
								.getNodeValue()
								+ "      "
								+ eElement.getElementsByTagName("element")
										.item(temp1).getTextContent());

					}
					listmap.add(map);
				}
			}
			for (Map<String, String> map2 : listmap) {
				System.out.println(map2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public EDIFields getParsedData() {
		parseFile();
		EDIFields fields = new EDIFields();
		fields.setIns01(listmap.get(0).get("INS01"));
		fields.setIns02(listmap.get(0).get("INS02"));
		fields.setIns03(listmap.get(0).get("INS03"));
		fields.setIns04(listmap.get(0).get("INS04"));
		fields.setIns05(listmap.get(0).get("INS05"));
		fields.setIns08(listmap.get(0).get("INS08"));
		fields.setIns10(listmap.get(0).get("INS10"));
		fields.setRef01_1(listmap.get(1).get("REF01"));
		fields.setRef02_1(listmap.get(1).get("REF02"));
		fields.setRef01_2(listmap.get(2).get("REF01"));
		fields.setRef02_2(listmap.get(2).get("REF02"));
		fields.setRef01_3(listmap.get(3).get("REF01"));
		fields.setRef02_3(listmap.get(3).get("REF02"));
		fields.setRef01_4(listmap.get(4).get("REF01"));
		fields.setRef02_4(listmap.get(4).get("REF02"));
		fields.setRef01_5(listmap.get(5).get("REF01"));
		fields.setRef02_5(listmap.get(5).get("REF02"));
		fields.setRef01_6(listmap.get(6).get("REF01"));
		fields.setRef02_6(listmap.get(6).get("REF02"));
		fields.setDtp01_1(listmap.get(7).get("DTP01"));
		fields.setDtp02_1(listmap.get(7).get("DTP02"));
		fields.setDtp03_1(listmap.get(7).get("DTP03"));
		fields.setNm101_1(listmap.get(8).get("NM101"));
		fields.setNm102_1(listmap.get(8).get("NM102"));
		fields.setNm103_1(listmap.get(8).get("NM103"));
		fields.setNm104_1(listmap.get(8).get("NM104"));
		fields.setNm105_1(listmap.get(8).get("NM105"));
		fields.setNm108_1(listmap.get(8).get("NM108"));
		fields.setNm109_1(listmap.get(8).get("NM109"));
		fields.setPer01(listmap.get(9).get("PER01"));
		fields.setPer03(listmap.get(9).get("PER03"));
		fields.setPer04(listmap.get(9).get("PER04"));
		fields.setPer05(listmap.get(9).get("PER05"));
		fields.setPer06(listmap.get(9).get("PER06"));
		fields.setN301_1(listmap.get(10).get("N301"));
		fields.setN401_1(listmap.get(11).get("N401"));
		fields.setN402_1(listmap.get(11).get("N402"));
		fields.setN403_1(listmap.get(11).get("N403"));
		fields.setDmg01(listmap.get(12).get("DMG01"));
		fields.setDmg02(listmap.get(12).get("DMG02"));
		fields.setDmg03(listmap.get(12).get("DMG03"));
		fields.setNm101_2(listmap.get(13).get("NM101"));
		fields.setNm102_2(listmap.get(13).get("NM102"));
		fields.setN301_2(listmap.get(14).get("N301"));
		fields.setN401_2(listmap.get(15).get("N401"));
		fields.setN402_2(listmap.get(15).get("N402"));
		fields.setN403_2(listmap.get(15).get("N403"));
		fields.setHd01(listmap.get(16).get("HD01"));
		fields.setHd03(listmap.get(16).get("HD03"));
		fields.setHd04(listmap.get(16).get("HD04"));
		fields.setHd05(listmap.get(16).get("HD05"));
		fields.setDtp01_2(listmap.get(17).get("DTP01"));
		fields.setDtp02_2(listmap.get(17).get("DTP02"));
		fields.setDtp03_2(listmap.get(17).get("DTP03"));
		fields.setDtp01_3(listmap.get(18).get("DTP01"));
		fields.setDtp02_3(listmap.get(18).get("DTP02"));
		fields.setDtp03_3(listmap.get(18).get("DTP03"));

		return fields;
	}

}
