package com.bsc.qa.facets.test;

import static org.testng.Assert.assertEquals;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.bqsa.AutomationStringUtilities;
import com.bsc.qa.lacare.db.DatabaseQueries;
import com.bsc.qa.lacare.pojo.Connection;
import com.bsc.qa.lacare.pojo.DatabaseData;
import com.bsc.qa.lacare.pojo.EDIFields;
import com.bsc.qa.lacare.report.factory.BaseTest;
import com.bsc.qa.lacare.util.HibernateUtil;
import com.bsc.qa.lacare.util.XMLParsetoObject;
import com.relevantcodes.extentreports.LogStatus;

public class EDIOutboundTest extends BaseTest implements IHookable {
	Connection conn = new Connection();
	SessionFactory factory;
	Session session;
	EDIFields filedata;
	DatabaseData dbdata;

	@BeforeSuite
	public void beforeSuite() {
		String oracleUser = System.getenv("ORACLE_USER");
		String oraclePassword = System.getenv("ORACLE_PASSWORD");
		String oracleServer = System.getenv("ORACLE_SERVER");
		String oraclePort = System.getenv("ORACLE_PORT");
		String oracleDB = System.getenv("ORACLE_DB");
		String oracleUrl = "jdbc:oracle:thin:@" + oracleServer + ":"
				+ oraclePort + ":" + oracleDB;
		conn.setUsername(AutomationStringUtilities.decryptValue(oracleUser));
		conn.setPassword(AutomationStringUtilities.decryptValue(oraclePassword));
		conn.setUrl(oracleUrl);
		factory = HibernateUtil.createSessionFactory(conn);
		session = factory.openSession();
	}

	@BeforeTest
	public void getData() {
		DatabaseQueries queries = new DatabaseQueries();
		XMLParsetoObject xml = new XMLParsetoObject();
		filedata = xml.getParsedData();
		// dbdata = queries.getDatabaseData(filedata.getRef02_1(), session);

	}

	@AfterTest
	public void afterTest() {
		session.clear();
		session.close();
	}

	// INS01
	@Test(dataProvider = "ins01")
	public void ins01Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ins01() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getIns01();
		if (dbdata.getMEME_REL().equalsIgnoreCase("M"))
			object[0][1] = "Y";
		else
			object[0][1] = "N";

		return object;
	}

	// INS02
	@Test(dataProvider = "ins02")
	public void ins02Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ins02() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getIns02();
		if (dbdata.getMEME_REL().equalsIgnoreCase("M"))
			object[0][1] = "18";
		else if (dbdata.getMEME_REL().equalsIgnoreCase("H")
				|| dbdata.getMEME_REL().equalsIgnoreCase("H"))
			object[0][1] = "01";
		else if (dbdata.getMEME_REL().equalsIgnoreCase("S")
				|| dbdata.getMEME_REL().equalsIgnoreCase("D"))
			object[0][1] = "19";
		else
			object[0][1] = "23";

		return object;
	}

	// INS03
	@Test(dataProvider = "ins03")
	public void ins03Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ins03() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getIns03();
		object[0][1] = "030";

		return object;
	}

	// INS04
	@Test(dataProvider = "ins04")
	public void ins04Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ins04() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getIns04();
		object[0][1] = "XN";

		return object;
	}

	// INS05
	@Test(dataProvider = "ins05")
	public void ins05Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ins05() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getIns05();
		object[0][1] = "A";

		return object;
	}

	// INS06
	/*
	 * @Test(dataProvider = "ins06") public void ins06Test(String file, String
	 * db) { if (file.equalsIgnoreCase(db)) System.out.println("Pass");
	 * assertEquals(file, db); }
	 * 
	 * @DataProvider public Object[][] ins06() { Object[][] object = new
	 * Object[1][2]; object[0][0] = filedata.getIns06(); object[0][1] = "23";
	 * 
	 * return object; }
	 * 
	 * // INS07
	 * 
	 * @Test(dataProvider = "ins07") public void ins02Test(String file, String
	 * db) { if (file.equalsIgnoreCase(db)) System.out.println("Pass");
	 * assertEquals(file, db); }
	 * 
	 * @DataProvider public Object[][] ins07() { Object[][] object = new
	 * Object[1][2]; object[0][0] = filedata.getIns07(); if
	 * (dbdata.getMEME_REL().equalsIgnoreCase("M")) object[0][1] = "18"; else if
	 * (dbdata.getMEME_REL().equalsIgnoreCase("H") ||
	 * dbdata.getMEME_REL().equalsIgnoreCase("H")) object[0][1] = "01"; else if
	 * (dbdata.getMEME_REL().equalsIgnoreCase("S") ||
	 * dbdata.getMEME_REL().equalsIgnoreCase("D")) object[0][1] = "19"; else
	 * object[0][1] = "23";
	 * 
	 * return object; }
	 */
	// INS08
	@Test(dataProvider = "ins08")
	public void ins08Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ins08() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getIns08();
		object[0][1] = dbdata.getSBSB_MCTR_STS();

		return object;
	}

	// INS09
	@Test(dataProvider = "ins09")
	public void ins09Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ins09() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getIns09();
		if (dbdata.getMEME_REL().equals("M")
				|| dbdata.getMEME_REL().equals("W")
				|| dbdata.getMEME_REL().equals("H"))
			object[0][1] = "";

		return object;
	}

	// INS10
	@Test(dataProvider = "ins10")
	public void ins10Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ins10() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getIns10();
		object[0][1] = "N";
		return object;
	}

	// Subscriber Identifier
	// ref01_1
	@Test(dataProvider = "ref01_1")
	public void ref01_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref01_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef01_1();
		object[0][1] = "0F";
		return object;
	}

	// ref02_1
	@Test(dataProvider = "ref02_1")
	public void ref02_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref02_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef02_1();
		object[0][1] = dbdata.getMEME_SSN();
		return object;
	}

	// Member Policy Number
	// ref01_2
	@Test(dataProvider = "ref01_2")
	public void ref01_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref01_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef01_2();
		object[0][1] = "1L";
		return object;
	}

	// ref02_2
	@Test(dataProvider = "ref02_2")
	public void ref02_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref02_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef02_2();
		object[0][1] = dbdata.getGRGR_ID();
		return object;
	}

	// Member Supplemental Identifier
	// ref01_2
	@Test(dataProvider = "ref01_3")
	public void ref01_3Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref01_3() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef01_3();
		object[0][1] = "17";
		return object;
	}

	// ref02_2
	@Test(dataProvider = "ref02_3")
	public void ref02_3Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref02_3() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef02_3();
		object[0][1] = dbdata.getCSCS_ID();
		return object;
	}

	// Member Supplemental Identifier
	// ref01_4
	@Test(dataProvider = "ref01_4")
	public void ref01_4Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref01_4() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef01_4();
		object[0][1] = "23";
		return object;
	}

	// ref02_4
	@Test(dataProvider = "ref02_4")
	public void ref02_4Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref02_4() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef02_4();
		object[0][1] = "OCO" + dbdata.getSBSB_ID() + "0" + dbdata.getMEME_SFX();
		return object;
	}

	// ref01_5
	@Test(dataProvider = "ref01_5")
	public void ref01_5Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref01_5() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef01_5();
		object[0][1] = "DX";
		return object;
	}

	// ref02_5
	@Test(dataProvider = "ref02_5")
	public void ref02_5Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref02_5() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef02_5();
		object[0][1] = "2331RETIREES";
		return object;
	}

	// ref01_6
	@Test(dataProvider = "ref01_6")
	public void ref01_6Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref01_6() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef01_6();
		object[0][1] = "F6";
		return object;
	}

	// ref02_6
	@Test(dataProvider = "ref02_6")
	public void ref02_6Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] ref02_6() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getRef02_6();
		object[0][1] = dbdata.getMEME_HICN();
		return object;
	}

	// dtp01_1
	@Test(dataProvider = "dtp01_1")
	public void dtp01_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dtp01_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDtp01_1();
		object[0][1] = "356";
		return object;
	}

	// dtp02_1
	@Test(dataProvider = "dtp02_1")
	public void dtp02_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dtp02_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDtp02_1();
		object[0][1] = "D8";
		return object;
	}

	// dtp03_1
	@Test(dataProvider = "dtp03_1")
	public void dtp03_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dtp03_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDtp03_1();
		object[0][1] = dbdata.getSBSB_ORIG_EFF_DT();
		return object;
	}

	// NM101_1
	@Test(dataProvider = "nm101_1")
	public void nm101_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm101_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getNm101_1();
		object[0][1] = "IL";
		return object;
	}

	// NM102_1
	@Test(dataProvider = "nm102_1")
	public void nm102_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm102_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getNm102_1();
		object[0][1] = "1";
		return object;
	}

	// NM103_1
	@Test(dataProvider = "nm103_1")
	public void nm103_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm103_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getNm103_1();
		object[0][1] = dbdata.getMEME_LAST_NAME();
		return object;
	}

	// NM104_1
	@Test(dataProvider = "nm104_1")
	public void nm104_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm104_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getNm104_1();
		object[0][1] = dbdata.getMEME_FIRST_NAME();
		return object;
	}

	// NM105_1
	@Test(dataProvider = "nm105_1")
	public void nm105_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm105_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getNm105_1();
		object[0][1] = dbdata.getMEME_MID_INIT();
		return object;
	}

	// NM107_1
	@Test(dataProvider = "nm107_1")
	public void nm107_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm107_1() {
		Object[][] object = new Object[1][2];
		if (!(filedata.getNm107_1() == null))
			object[0][0] = filedata.getNm107_1();
		else
			object[0][0] = " ";
		object[0][1] = dbdata.getMEME_TITLE();
		return object;
	}

	// NM108_1
	@Test(dataProvider = "nm108_1")
	public void nm108_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm108_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getNm108_1();
		object[0][1] = "34";
		return object;
	}

	// NM109_1
	@Test(dataProvider = "nm109_1")
	public void nm109_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm109_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getNm109_1();
		object[0][1] = dbdata.getMEME_SSN();
		return object;
	}

	// PER01
	@Test(dataProvider = "per01")
	public void per01Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] per01() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getPer01();
		object[0][1] = "IP";
		return object;
	}

	// PER03
	@Test(dataProvider = "per03")
	public void per03Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] per03() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getPer03();
		object[0][1] = filedata.getPer03();
		return object;
	}

	// PER04
	@Test(dataProvider = "per04")
	public void per04Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] per04() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getPer04();
		if (filedata.getPer03().equalsIgnoreCase("TE"))
			object[0][1] = dbdata.getSBAD_PHONE();
		else if (filedata.getPer03().equalsIgnoreCase("EM"))
			object[0][1] = dbdata.getSBAD_EMAIL();
		else if (filedata.getPer03().equalsIgnoreCase("FX"))
			object[0][1] = dbdata.getSBAD_FAX();
		return object;
	}

	// PER05
	@Test(dataProvider = "per05")
	public void per05Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] per05() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getPer05();
		object[0][1] = "EM";
		return object;
	}

	// PER06
	@Test(dataProvider = "per06")
	public void per06Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] per06() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getPer06();
		object[0][1] = dbdata.getSBAD_EMAIL();
		return object;
	}

	// N301_1
	@Test(dataProvider = "n301_1")
	public void n301_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n301_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN301_1();
		object[0][1] = dbdata.getSBAD_ADDR1();
		return object;
	}

	// N302_1
	@Test(dataProvider = "n302_1")
	public void n302_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n302_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN302_1();
		object[0][1] = dbdata.getSBAD_ADDR2();
		return object;
	}

	// N401_1
	@Test(dataProvider = "n401_1")
	public void n401_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n401_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN401_1();
		object[0][1] = dbdata.getSBAD_CITY();
		return object;
	}

	// N402_1
	@Test(dataProvider = "n402_1")
	public void n402_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n402_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN402_1();
		object[0][1] = dbdata.getSBAD_STATE();
		return object;
	}

	// N403_1
	@Test(dataProvider = "n403_1")
	public void n403_1Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n403_1() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN403_1();
		object[0][1] = dbdata.getSBAD_ZIP();
		return object;
	}

	// DMG01
	@Test(dataProvider = "dmg01")
	public void dmg01Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dmg01() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDmg01();
		object[0][1] = "D8";
		return object;
	}

	// DMG02
	@Test(dataProvider = "dmg02")
	public void dmg02Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dmg02() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDmg02();
		object[0][1] = dbdata.getMEME_BIRTH_DT();
		return object;
	}

	// DMG03
	@Test(dataProvider = "dmg03")
	public void dmg03Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dmg03() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDmg03();
		object[0][1] = dbdata.getMEME_SEX();
		return object;
	}

	// DMG04
	@Test(dataProvider = "dmg04")
	public void dmg04Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dmg04() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDmg04();
		object[0][1] = dbdata.getMEME_MARITAL_STATUS();
		return object;
	}

	// NM101_2
	@Test(dataProvider = "nm101_2")
	public void nm101_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm101_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getNm101_2();
		object[0][1] = "31";
		return object;
	}

	// NM102_2
	@Test(dataProvider = "nm102_2")
	public void nm102_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] nm102_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getNm102_2();
		object[0][1] = "1";
		return object;
	}

	// N301_2
	@Test(dataProvider = "n301_2")
	public void n301_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n301_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN301_2();
		object[0][1] = dbdata.getSBAD_ADDR1();
		return object;
	}

	// N302_1
	@Test(dataProvider = "n302_2")
	public void n302_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n302_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN302_2();
		object[0][1] = dbdata.getSBAD_ADDR2();
		return object;
	}

	// N401_2
	@Test(dataProvider = "n401_2")
	public void n401_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n401_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN401_2();
		object[0][1] = dbdata.getSBAD_CITY();
		return object;
	}

	// N402_2
	@Test(dataProvider = "n402_2")
	public void n402_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n402_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN402_2();
		object[0][1] = dbdata.getSBAD_STATE();
		return object;
	}

	// N403_2
	@Test(dataProvider = "n403_2")
	public void n403_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] n403_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN403_2();
		object[0][1] = dbdata.getSBAD_ZIP();
		return object;
	}

	// HD01
	@Test(dataProvider = "hd01")
	public void hd01Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] hd01() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getN403_2();
		object[0][1] = "030";
		return object;
	}

	// HD03
	@Test(dataProvider = "hd03")
	public void hd03Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] hd03() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getHd03();
		if (dbdata.getCSPD_CAT().equalsIgnoreCase("M"))
			object[0][1] = "HLT";
		else if (dbdata.getCSPD_CAT().equalsIgnoreCase("D")
				|| dbdata.getCSPD_CAT().equalsIgnoreCase("E")
				|| dbdata.getCSPD_CAT().equalsIgnoreCase("F")
				|| dbdata.getCSPD_CAT().equalsIgnoreCase("G"))
			object[0][1] = "DEN";
		else if (dbdata.getCSPD_CAT().equalsIgnoreCase("V")
				|| dbdata.getCSPD_CAT().equalsIgnoreCase("X"))
			object[0][1] = "VIS";
		else if (dbdata.getCSPD_CAT().equalsIgnoreCase("L")
				|| dbdata.getCSPD_CAT().equalsIgnoreCase("P")
				|| dbdata.getCSPD_CAT().equalsIgnoreCase("S")
				|| dbdata.getCSPD_CAT().equalsIgnoreCase("T")
				|| dbdata.getCSPD_CAT().equalsIgnoreCase("C"))
			object[0][1] = "LIF";
		else if (dbdata.getCSPD_CAT().equalsIgnoreCase("R"))
			object[0][1] = "PDG";

		return object;
	}

	// HD04
	@Test(dataProvider = "hd04")
	public void hd04Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] hd04() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getHd04();
		object[0][1] = "PPOX0003" + dbdata.getCSCS_ID();
		return object;
	}

	// HD05
	@Test(dataProvider = "hd05")
	public void hd05Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] hd05() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getHd05();
		object[0][1] = "EMP";
		return object;
	}

	// dtp01_2
	@Test(dataProvider = "dtp01_2")
	public void dtp01_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dtp01_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDtp01_2();
		object[0][1] = "348";
		return object;
	}

	// dtp02_2
	@Test(dataProvider = "dtp02_2")
	public void dtp02_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dtp02_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDtp02_2();
		object[0][1] = "D8";
		return object;
	}

	// dtp03_2
	@Test(dataProvider = "dtp03_2")
	public void dtp03_2Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dtp03_2() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDtp03_2();
		object[0][1] = dbdata.getMEPE_EFF_DT();
		return object;
	}

	// dtp01_3
	@Test(dataProvider = "dtp01_3")
	public void dtp01_3Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dtp01_3() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDtp01_3();
		object[0][1] = "349";
		return object;
	}

	// dtp02_2
	@Test(dataProvider = "dtp02_3")
	public void dtp02_3Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dtp02_3() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDtp02_3();
		object[0][1] = "D8";
		return object;
	}

	// dtp03_2
	@Test(dataProvider = "dtp03_3")
	public void dtp03_3Test(String file, String db) {
		if (file.equalsIgnoreCase(db))
			System.out.println("Pass");
		assertEquals(file, db);

	}

	@DataProvider
	public Object[][] dtp03_3() {
		Object[][] object = new Object[1][2];
		object[0][0] = filedata.getDtp03_3();
		object[0][1] = dbdata.getMEPE_TERM_DT();
		return object;
	}

	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}

}
