package com.bsc.qa.facets.test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.bqsa.AutomationStringUtilities;
import com.bsc.qa.lacare.db.DatabaseQueries;
import com.bsc.qa.lacare.pojo.Connection;
import com.bsc.qa.lacare.pojo.DatabaseData;
import com.bsc.qa.lacare.pojo.EDIFields;
import com.bsc.qa.lacare.pojo.HeaderFields;
import com.bsc.qa.lacare.report.factory.BaseTest;
import com.bsc.qa.lacare.util.HibernateUtil;
import com.relevantcodes.extentreports.LogStatus;

public class COOSceneriosTest extends BaseTest implements IHookable {

	List<EDIFields> family;
	HeaderFields header;
	String filename;
	int stcount, secount;

	Connection conn = new Connection();
	SessionFactory factory;
	Session session;
	EDIFields filedata;
	DatabaseData dbdata;
	List<DatabaseData> dblist;

	@BeforeSuite
	public void beforeSuite() {
		String oracleUser = System.getenv("ORACLE_USER");
		String oraclePassword = System.getenv("ORACLE_PASSWORD");
		String oracleServer = System.getenv("ORACLE_SERVER");
		String oraclePort = System.getenv("ORACLE_PORT");
		String oracleDB = System.getenv("ORACLE_DB");
		String oracleUrl = "jdbc:oracle:thin:@" + oracleServer + ":"
				+ oraclePort + ":" + oracleDB;
		conn.setUsername(AutomationStringUtilities.decryptValue(oracleUser));
		conn.setPassword(AutomationStringUtilities.decryptValue(oraclePassword));
		conn.setUrl(oracleUrl);
		
		factory = HibernateUtil.createSessionFactory(conn);
		session = factory.openSession();
	}

	@AfterSuite
	public void closeConnection() {
		if (session != null) {
			session.close();
			factory.close();
			System.out.println("DB Connection Succesfully closed!");
		}
	}

	@BeforeTest
	public void getData() {
		FileParse parse = new FileParse();
		family = parse.getMemberFamily();
		header = parse.getHeader();
		filename = parse.inputFile.getName();
		DatabaseQueries queries = new DatabaseQueries();
		dblist = queries.getDatabaseData(family, session);

		System.out.println(filename);
	}

	@Test(dataProvider = "receiverId")
	public void ReceiverIdTest(String ISA, String GS, String data) {
		assertEquals(ISA, GS, data);
	}

	@DataProvider
	public Object[][] receiverId() {
		Object[][] object = new Object[1][3];
		object[0][0] = header.getIsa08().trim();
		object[0][1] = header.getGs03().trim();
		object[0][2] = "CATAMARAN";
		return object;
	}

	@Test(dataProvider = "cob04")
	public void cob04Test(String cob04, String data, String ssn) {
		assertEquals(cob04, data);
	}

	@DataProvider
	public Object[][] cob04() {
		Object[][] object = new Object[family.size()][3];
		for (int i = 0; i < family.size(); i++) {
			if (!(family.get(i).getCob01() == null)) {
				object[i][0] = family.get(i).getCob04();
				object[i][1] = "1";
				object[i][2] = family.get(i).getNm109_1();
			} else {
				object[i][0] = "";
				object[i][1] = "";
				object[i][2] = family.get(i).getNm109_1();
			}

		}

		return object;
	}

	@Test
	public void fileNameTest() {
		assertTrue(filename.contains("TCOOM"));
	}

	@Test(dataProvider = "ge02")
	public void ge02Test(String cob04, String data) {
		assertEquals(cob04, data);
	}

	@DataProvider
	public Object[][] ge02() {
		Object[][] object = new Object[1][2];

		object[0][0] = header.getGe02();
		object[0][1] = header.getGs06();

		return object;
	}

	@Test(dataProvider = "iea02")
	public void iea02Test(String cob04, String data) {
		assertEquals(cob04, data);
	}

	@DataProvider
	public Object[][] iea02() {
		Object[][] object = new Object[1][2];

		object[0][0] = header.getIea02();
		object[0][1] = header.getIsa13();

		return object;
	}

	@Test(dataProvider = "uniquecarrier")
	public void uniqueCarrierTest(String ISA, String GS, String data) {
		assertEquals(ISA, GS, data);
	}

	@DataProvider
	public Object[][] uniquecarrier() {
		Object[][] object = new Object[1][3];
		object[0][0] = header.getIsa06().trim();
		object[0][1] = header.getGs02().trim();
		object[0][2] = "PBS2331";
		return object;
	}

	@Test
	public void transactioncountTest() {
		assertEquals(stcount, secount, 1);
	}

	@Test(dataProvider = "eligEffDate")
	public void eligEffDateTest(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] eligEffDate() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getDtp03_2();
			object[j][1] = dblist.get(j).getMEPE_EFF_DT();
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "eligTermDate")
	public void eligTermDateTest(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] eligTermDate() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getDtp03_3();
			object[j][1] = dblist.get(j).getMEPE_TERM_DT();
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "hd01")
	public void hd01Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] hd01() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getHd01();
			object[j][1] = "030";
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "hd03")
	public void hd03Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] hd03() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getHd03();
			object[j][1] = dblist.get(j).getCSPD_CAT();
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "hd04")
	public void hd04Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] hd04() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getHd04();
			object[j][1] = "PPOX0003" + dblist.get(j).getCSCS_ID();
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "hddtp01_1")
	public void hddtp01_1Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] hddtp01_1() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getDtp01_2();
			object[j][1] = "348";
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "hddtp02_1")
	public void hddtp02_1Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] hddtp02_1() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getDtp02_2();
			object[j][1] = "D8";
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "hddtp03_1")
	public void hddtp03_1Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] hddtp03_1() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getDtp03_2();
			object[j][1] = dblist.get(j).getMEPE_EFF_DT();
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "hddtp01_2")
	public void hddtp01_2Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] hddtp01_2() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getDtp01_3();
			object[j][1] = "349";
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "hddtp02_2")
	public void hddtp02_2Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] hddtp02_2() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getDtp02_3();
			object[j][1] = "D8";
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}

	@Test(dataProvider = "hddtp03_2")
	public void hddtp03_2Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] hddtp03_2() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getDtp03_3();
			object[j][1] = dblist.get(j).getMEPE_TERM_DT();
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}
	
	@Test(dataProvider = "ref02_4")
	public void ref02_4Test(String file, String db, String ssn) {
		assertEquals(file, db);
	}

	@DataProvider
	public Object[][] ref02_4() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getRef02_4();
			object[j][1] = "OCO"+dblist.get(j).getSBSB_ID()+"0"+dblist.get(j).getMEME_SFX();
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}
	
	@Test(dataProvider = "ssn")
	public void ssnTest(String file, String db, String ssn) {
		assertEquals(file, db);
	}
	
	@DataProvider
	public Object[][] ssn() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {
			//if(family.get(j).getIns02().equalsIgnoreCase("Y"))
			object[j][0] = family.get(j).getRef02_1();
			object[j][1] = dblist.get(j).getMEME_SSN();
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}
	/*@Test(dataProvider = "cobeffdt")
	public void cobeffdtTest(String file, String db, String ssn) {

	}

	@DataProvider
	public Object[][] cobeffdt() {
		Object[][] object = new Object[family.size()][3];
		for (int j = 0; j < family.size(); j++) {

			object[j][0] = family.get(j).getDtp03_4();
			
			object[j][2] = family.get(j).getRef02_1();
		}
		return object;
	}*/
	
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}
}
