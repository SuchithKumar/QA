package com.bsc.qa.facets.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bsc.qa.lacare.pojo.EDIFields;
import com.bsc.qa.lacare.pojo.HeaderFields;

public class FileParse {

	List<String> rowsList;
	public File inputFile;
	public int stcount = 0, secount = 0;

	public static void main(String[] args) {

		FileParse parse = new FileParse();
		List<EDIFields> memberlist = parse.getMemberFamily();
		for (EDIFields ediFields : memberlist) {
			System.out.println(ediFields.getNm109_1());
		}
	}

	public List<String> parseFile() throws IOException {
		inputFile = new File(
				"\\\\bsc\\it\\VDI_Home_SAC\\plambh01\\Desktop\\Sample_COO.txt");
		String line = null;
		BufferedReader bufferedReader = null;
		rowsList = new ArrayList<String>();

		FileReader fileReader = new FileReader(inputFile);
		bufferedReader = new BufferedReader(fileReader);
		boolean flag = false;
		// Reading each line in the file
		while ((line = bufferedReader.readLine()) != null) {
			rowsList.add(line);
		}
		if (bufferedReader != null)
			bufferedReader.close();
		return rowsList;
	}

	public HeaderFields getHeader() {
		HeaderFields header = new HeaderFields();
		for (String row : rowsList) {
			if (row.startsWith("ISA*")) {
				header.setIsa01(row.split("\\*")[1].replace("~", ""));
				header.setIsa02(row.split("\\*")[2].replace("~", ""));
				header.setIsa03(row.split("\\*")[3].replace("~", ""));
				header.setIsa04(row.split("\\*")[4].replace("~", ""));
				header.setIsa05(row.split("\\*")[5].replace("~", ""));
				header.setIsa06(row.split("\\*")[6].replace("~", ""));
				header.setIsa07(row.split("\\*")[7].replace("~", ""));
				header.setIsa08(row.split("\\*")[8].replace("~", ""));
				header.setIsa09(row.split("\\*")[9].replace("~", ""));
				header.setIsa10(row.split("\\*")[10].replace("~", ""));
				header.setIsa11(row.split("\\*")[11].replace("~", ""));
				header.setIsa12(row.split("\\*")[12].replace("~", ""));
				header.setIsa13(row.split("\\*")[13].replace("~", ""));
				header.setIsa14(row.split("\\*")[14].replace("~", ""));
				header.setIsa15(row.split("\\*")[15].replace("~", ""));
				header.setIsa16(row.split("\\*")[16].replace("~", ""));

			} else if (row.startsWith("ST*")) {
				header.setSt01(row.split("\\*")[1].replace("~", ""));
				header.setSt02(row.split("\\*")[2].replace("~", ""));
				header.setSt03(row.split("\\*")[3].replace("~", ""));
				stcount++;
			}

			else if (row.startsWith("GS*")) {
				header.setGs01(row.split("\\*")[1].replace("~", ""));
				header.setGs02(row.split("\\*")[2].replace("~", ""));
				header.setGs03(row.split("\\*")[3].replace("~", ""));
				header.setGs04(row.split("\\*")[4].replace("~", ""));
				header.setGs05(row.split("\\*")[5].replace("~", ""));
				header.setGs06(row.split("\\*")[6].replace("~", ""));
				header.setGs07(row.split("\\*")[7].replace("~", ""));
				header.setGs08(row.split("\\*")[8].replace("~", ""));
			} else if (row.startsWith("SE*")) {
				header.setSe01(row.split("\\*")[1].replace("~", ""));
				header.setSe02(row.split("\\*")[2].replace("~", ""));
				secount++;
			} else if (row.startsWith("GE*")) {
				header.setGe01(row.split("\\*")[1].replace("~", ""));
				header.setGe02(row.split("\\*")[2].replace("~", ""));
			} else if (row.startsWith("IEA*")) {
				header.setIea01(row.split("\\*")[1].replace("~", ""));
				header.setIea02(row.split("\\*")[2].replace("~", ""));
			}

		}
		return header;
	}

	public List<EDIFields> getMemberFamily() {
		Map<String, String> data = new HashMap<String, String>();
		EDIFields fields = null;
		List<EDIFields> memberlist = new ArrayList<EDIFields>();
		try {
			parseFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (String row : rowsList) {
			if (row.startsWith("INS*")) {
				String[] str;
				if (!(fields == null))
					memberlist.add(fields);
				str = row.split("\\*");
				fields = new EDIFields();
				fields.setIns01(str[1]);

			} else if (row.startsWith("REF*0F")) {
				fields.setRef01_1(row.split("\\*")[1].replace("~", ""));
				fields.setRef02_1(row.split("\\*")[2].replace("~", ""));

			} else if (row.startsWith("REF*1L")) {
				fields.setRef01_2(row.split("\\*")[1].replace("~", ""));
				fields.setRef02_2(row.split("\\*")[2].replace("~", ""));

			} else if (row.startsWith("REF*17")) {
				fields.setRef01_3(row.split("\\*")[1].replace("~", ""));
				fields.setRef02_3(row.split("\\*")[2].replace("~", ""));

			} else if (row.startsWith("REF*23")) {
				fields.setRef01_4(row.split("\\*")[1].replace("~", ""));
				fields.setRef02_4(row.split("\\*")[2].replace("~", ""));

			} else if (row.startsWith("REF*DX")) {
				fields.setRef01_5(row.split("\\*")[1].replace("~", ""));
				fields.setRef02_5(row.split("\\*")[2].replace("~", ""));

			} else if (row.startsWith("REF*F6")) {
				fields.setRef01_6(row.split("\\*")[1].replace("~", ""));
				fields.setRef02_6(row.split("\\*")[2].replace("~", ""));

			} else if (row.startsWith("DTP*356")) {
				fields.setDtp01_1(row.split("\\*")[1].replace("~", ""));
				fields.setDtp02_1(row.split("\\*")[2].replace("~", ""));
				fields.setDtp03_1(row.split("\\*")[3].replace("~", ""));

			} else if (row.startsWith("NM1*IL*1")) {
				String[] str = row.split("\\*");
				fields.setNm101_1(row.split("\\*")[1]);
				fields.setNm102_1(row.split("\\*")[2]);
				fields.setNm103_1(row.split("\\*")[3]);
				fields.setNm104_1(row.split("\\*")[4].replace("~", ""));

				// fields.setNm105_1(row.split("\\*")[5].replace("~", ""));
				// fields.setNm106_1(row.split("\\*")[6].replace("~", ""));
				// fields.setNm107_1(row.split("\\*")[7].replace("~", ""));
				// fields.setNm108_1(row.split("\\*")[8].replace("~", ""));
				if (str.length == 10)
					fields.setNm109_1(row.split("\\*")[9].replace("~", ""));

			} else if (row.startsWith("PER*IP")) {
				fields.setPer01(row.split("\\*")[1].replace("~", ""));
				fields.setPer03(row.split("\\*")[2].replace("~", ""));
				fields.setPer04(row.split("\\*")[3].replace("~", ""));
				fields.setPer05(row.split("\\*")[4].replace("~", ""));
				// fields.setPer06(row.split("\\*")[5].replace("~", ""));
				// fields.setPer07(row.split("\\*")[7].replace("~", ""));
				// fields.setPer08(row.split("\\*")[8].replace("~", ""));

			} else if (row.startsWith("N3*")) {
				fields.setN301_1(row.split("\\*")[1].replace("~", ""));

				fields.setN301_2(row.split("\\*")[1].replace("~", ""));
				if (row.split("\\*").length > 2) {
					fields.setN302_1(row.split("\\*")[2].replace("~", ""));
					fields.setN302_2(row.split("\\*")[2].replace("~", ""));
				}

			} else if (row.startsWith("N4*")) {
				fields.setN401_1(row.split("\\*")[1].replace("~", ""));
				fields.setN402_1(row.split("\\*")[2].replace("~", ""));
				fields.setN403_1(row.split("\\*")[3].replace("~", ""));
				fields.setN401_2(row.split("\\*")[1].replace("~", ""));
				fields.setN402_2(row.split("\\*")[2].replace("~", ""));
				fields.setN403_2(row.split("\\*")[3].replace("~", ""));
				if (row.split("\\*").length > 4) {
					fields.setN404_1(row.split("\\*")[4].replace("~", ""));
					fields.setN404_2(row.split("\\*")[4].replace("~", ""));
				}
			} else if (row.startsWith("DMG*D8")) {
				fields.setDmg01(row.split("\\*")[1].replace("~", ""));
				fields.setDmg02(row.split("\\*")[2].replace("~", ""));
				fields.setDmg03(row.split("\\*")[3].replace("~", ""));
				if (row.split("\\*").length > 4)
					fields.setDmg04(row.split("\\*")[4].replace("~", ""));
			} else if (row.startsWith("HD*030")) {
				fields.setHd01(row.split("\\*")[1].replace("~", ""));
				fields.setHd03(row.split("\\*")[3].replace("~", ""));
				fields.setHd04(row.split("\\*")[4].replace("~", ""));
				if (row.split("\\*").length > 5)
					fields.setHd05(row.split("\\*")[5].replace("~", ""));
			} else if (row.startsWith("DTP*348")) {
				fields.setDtp01_2(row.split("\\*")[1].replace("~", ""));
				fields.setDtp02_2(row.split("\\*")[2].replace("~", ""));
				fields.setDtp03_2(row.split("\\*")[3].replace("~", ""));
			} else if (row.startsWith("DTP*349")) {
				fields.setDtp01_3(row.split("\\*")[1].replace("~", ""));
				fields.setDtp02_3(row.split("\\*")[2].replace("~", ""));
				fields.setDtp03_3(row.split("\\*")[3].replace("~", ""));
			} else if (row.startsWith("COB*")) {
				fields.setCob01(row.split("\\*")[1].replace("~", ""));
				fields.setCob02(row.split("\\*")[2].replace("~", ""));
				fields.setCob03(row.split("\\*")[3].replace("~", ""));
				fields.setCob04(row.split("\\*")[4].replace("~", ""));
			} else if (row.startsWith("DTP*344")) {
				fields.setDtp01_4(row.split("\\*")[1].replace("~", ""));
				fields.setDtp02_4(row.split("\\*")[2].replace("~", ""));
				fields.setDtp03_4(row.split("\\*")[3].replace("~", ""));
			} else if (row.startsWith("DTP*345")) {
				fields.setDtp01_5(row.split("\\*")[1].replace("~", ""));
				fields.setDtp02_5(row.split("\\*")[2].replace("~", ""));
				fields.setDtp03_5(row.split("\\*")[3].replace("~", ""));
			} else if (row.startsWith("NM1*IN")) {
				fields.setNm101_3(row.split("\\*")[1].replace("~", ""));
				fields.setNm102_3(row.split("\\*")[2].replace("~", ""));
				fields.setNm103_3(row.split("\\*")[3].replace("~", ""));
			} else if (row.startsWith("N3*") && fields.getCob01() != null) {
				fields.setN301_3(row.split("\\*")[1].replace("~", ""));
				fields.setN302_3(row.split("\\*")[2].replace("~", ""));
			} else if (row.startsWith("N3*") && fields.getCob01() != null) {
				fields.setN401_3(row.split("\\*")[1].replace("~", ""));
				fields.setN402_3(row.split("\\*")[2].replace("~", ""));
				fields.setN402_3(row.split("\\*")[3].replace("~", ""));
				fields.setN404_3(row.split("\\*")[4].replace("~", ""));
			}

		}

		return memberlist;

	}

}
