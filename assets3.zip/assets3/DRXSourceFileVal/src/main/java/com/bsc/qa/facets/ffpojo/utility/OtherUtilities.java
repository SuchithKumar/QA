package com.bsc.qa.facets.ffpojo.utility;

import java.time.Month;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

public class OtherUtilities extends BaseTest{
	// Validating in bound file and FACETS database column values
	public static void validate(Map<String, String> flatFileValuesMap,	Map<String, String> excelDataMap,SoftAssert softAssertion) {
		//SoftAssert softAssertion= new SoftAssert();
		new ExcelUtils("src/test/resources/SourceFileAndDataSheetColumnMapping.xlsx","DRXColumnNamesMapping");//Excel setup
		for(String key_datasheet:excelDataMap.keySet()){			
				
			switch (key_datasheet){  
				case "TESTCASEID":
				case "TESTCASENAME":
				case "TESTMETHOD":
				case "EXECUTIONFLAG":
				case "SOURCEFILENAME":
				case "EXECUTIONSTATUS":
				case "DESTINATIONRXFIRSTLOGINUSERNAME":
				case "DESTINATIONRXFIRSTLOGINPASSWORD":
				case "DESTINATIONRXSECONDLOGINUSERNAME":
				case "DESTINATIONRXSECONDLOGINPASSWORD":
					break;
				default:
					/*//calling method to get the field name corresponding column name
					String fileColumnName=ExcelUtils.getFieldNameCorrespondingColumnName(key_datasheet);
					if(fileColumnName!=null){
						if(flatFileValuesMap.containsKey(fileColumnName)){
							OtherUtilities.validateActualAndExpectedValues(key_datasheet,flatFileValuesMap.get(fileColumnName),excelDataMap.get(key_datasheet),softAssertion);
							System.out.println(" Key Name: " + key_datasheet + ", Flat File Acctual Value: " + flatFileValuesMap.get(fileColumnName) + ", Data Sheet Expected Value: " + excelDataMap.get(key_datasheet));
						}else{
							 softAssertion.assertTrue(flatFileValuesMap.containsKey(key_datasheet), "Element " + key_datasheet + " is not present" );
							 logger.log(LogStatus.INFO, key_datasheet+" is not present Input File");
						}	
					}
					break;*/
					
					//calling method to get the field name corresponding column name
					List<String> fileColumnName=ExcelUtils.getFieldNameCorrespondingColumnNames(key_datasheet);
					if(fileColumnName.size()>0){
						for(int intCounter = 0; intCounter<fileColumnName.size();intCounter++){
								if(flatFileValuesMap.containsKey(fileColumnName.get(intCounter))){
									if(fileColumnName.get(intCounter).equalsIgnoreCase("PremiumDirectPay")){
										if(flatFileValuesMap.get("PremiumDeducted".toUpperCase()).equalsIgnoreCase("Yes")){
											//OtherUtilities.validateActualAndExpectedValues(key_datasheet,flatFileValuesMap.get(fileColumnName.get(intCounter)),"No",softAssertion);
											softAssertion.assertEquals(flatFileValuesMap.get(fileColumnName.get(intCounter)).toString().toUpperCase(),"NO", " << Field name: " + key_datasheet + " | DRX Flat file value: " + flatFileValuesMap.get(fileColumnName.get(intCounter)) + " | Emrollment front end value: " + "NO" + " >>");
											logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValuesMap.get(fileColumnName.get(intCounter))+ "---------------Enrollment front end Value: " + "NO"));
										}
										else{
											softAssertion.assertEquals(flatFileValuesMap.get(fileColumnName.get(intCounter)).toString().toUpperCase(),"YES", " << Field name: " + key_datasheet + " | DRX Flat file value: " + flatFileValuesMap.get(fileColumnName.get(intCounter)) + " | Emrollment front end value: " + "YES" + " >>");
											logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValuesMap.get(fileColumnName.get(intCounter))+ "---------------Enrollment front end Value: " + "YES"));
										}
											
									}
									else{
										OtherUtilities.validateActualAndExpectedValues(key_datasheet,flatFileValuesMap.get(fileColumnName.get(intCounter)),excelDataMap.get(key_datasheet),softAssertion);
										System.out.println(" Key Name: " + key_datasheet + ", Flat File Acctual Value: " + flatFileValuesMap.get(fileColumnName.get(intCounter)) + ", Data Sheet Expected Value: " + excelDataMap.get(key_datasheet));
									}
								}else{
									 softAssertion.assertTrue(flatFileValuesMap.containsKey(key_datasheet), "Element " + key_datasheet + " is not present" );
									 logger.log(LogStatus.INFO, key_datasheet+" is not present Input File");
								}	
						}
					}
					
				}
		
	
					
		}		
	}


	
	
	// Validating in bound file and FACETS database column values 
	private static void validateActualAndExpectedValues(String key,String flatFileValue,String testDataValue,SoftAssert softAssertion) {
		
		
		switch (key){ 
		
		case "CONTACTINFOGENDER":
			if(flatFileValue.equalsIgnoreCase("F")){
				flatFileValue = "FEMALE";
				softAssertion.assertEquals(flatFileValue.toString().toUpperCase(),testDataValue.toString().toUpperCase(), " << Field name: " + key + " | DRX Flat file value: " + flatFileValue + " | Emrollment front end value: " + testDataValue + " >>");
				logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Enrollment front end Value: " + testDataValue));
			}
			else if(flatFileValue.equalsIgnoreCase("M")){
				flatFileValue = "MALE";
				softAssertion.assertEquals(flatFileValue.toString().toUpperCase(),testDataValue.toString().toUpperCase(), " << Field name: " + key + " | DRX Flat file value: " + flatFileValue + " | Emrollment front end value: " + testDataValue + " >>");
				logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Enrollment front end Value: " + testDataValue));
			}
			else{
				softAssertion.assertTrue(false, " Please select valid gender, selected invalid gender value as " + testDataValue + " DRX Flat file value: " + flatFileValue);
				logger.log(LogStatus.FAIL," Please select valid gender, selected invalid gender value as " + testDataValue + " DRX Flat file value: " + flatFileValue);
			}
			break;
			
		case "OTHERINFOIGETMONTHLYBENEFITSFROM": 
			
			if(testDataValue.equalsIgnoreCase("Social Securit")){
				testDataValue = "Yes";
			}
			else
				testDataValue = "No";
			softAssertion.assertEquals(flatFileValue.toString().toUpperCase(),testDataValue.toString().toUpperCase(), " << Field name: " + key + " | DRX Flat file value: " + flatFileValue + " | Emrollment front end value: " + testDataValue + " >>");
			logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + testDataValue));
			break;
	
		case "BENEFITINFOMEDICALPARTBEFFECTIVEDATE": 
		case "BENEFITINFOHOSPITALPARTAEFFECTIVEDATE": 
			if(testDataValue.length()>0){
				testDataValue = testDataValue.substring(0, 2) + testDataValue.substring(6);
			}
			softAssertion.assertEquals(flatFileValue.toString().toUpperCase(),testDataValue.toString().toUpperCase(), " << Field name: " + key + " | DRX Flat file value: " + flatFileValue + " | Emrollment front end value: " + testDataValue + " >>");
			logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + testDataValue));
			break;
		case "CONTACTINFOEMERGENCYCONTACT":  
			if(testDataValue.equalsIgnoreCase("No"))
				testDataValue = "";	
			softAssertion.assertEquals(flatFileValue.toString().toUpperCase(),testDataValue.toString().toUpperCase(), " << Field name: " + key + " | DRX Flat file value: " + flatFileValue + " | Emrollment front end value: " + testDataValue + " >>");
			logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + testDataValue));
			break;
		case "CONTACTINFOMAILINGADDRESS": 
		case "BENEFITINFOMEDICAIDENROLLMENT": 
			if(testDataValue.equalsIgnoreCase("No"))
				testDataValue = "";	
			softAssertion.assertEquals(flatFileValue.toString().toUpperCase(),testDataValue.toString().toUpperCase(), " << Field name: " + key + " | DRX Flat file value: " + flatFileValue + " | Emrollment front end value: " + testDataValue + " >>");
			logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + testDataValue));
			break;
		
		case "CONTACTINFODATEOFBIRTH":
			testDataValue = testDataValue.replaceAll("/", "");
			softAssertion.assertEquals(flatFileValue.toString().toUpperCase(),testDataValue.toString().toUpperCase(), " << Field name: " + key + " | DRX Flat file value: " + flatFileValue + " | Emrollment front end value: " + testDataValue + " >>");
		default:
				softAssertion.assertEquals(flatFileValue.toString().toUpperCase(),testDataValue.toString().toUpperCase(), " << Field name: " + key + " | DRX Flat file value: " + flatFileValue + " | Emrollment front end value: " + testDataValue + " >>");
				logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + testDataValue));
				break;
		}	
		
	
	}

	


	public static void printTestCaseDeatilsInReport(Map<String, String> data) {		
		
		String strSUCName= data.get("SUC Name").toString();		
		String strTestCaseId = data.get("Test Case ID").toString();		
		String strTestCaseName = data.get("Test Case Name").toString();		
		String strStepNumber = data.get("Step Number").toString();
		//String strInputFileName = data.get("Input File Name").toString();
		logger.log(LogStatus.INFO," SUC Name: " + strSUCName + ", Test Case ID: " + strTestCaseId + ", Test Case Name: " + strTestCaseName + ", Step Number:" + strStepNumber);
		//logger.log(LogStatus.INFO," Input File Name: " + strInputFileName);
	}
	

	
	
	private static void validateActualAndExpectedValuesbackup(String key,String flatFileValue,String dbValue,SoftAssert softAssertion) {
		String strFlatFileDate = "";
		String strdbValue = "";
		String strflatFileValue = "";
		if(key.equalsIgnoreCase("APPLICANTBIRTHDATE")){			
			String strDate = flatFileValue.substring(4) + "-"+flatFileValue.substring(0, 2) + "-"+ flatFileValue.substring(2, 4);
			softAssertion.assertTrue(dbValue.contains(strDate), "Element " + key + " is ot present" );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strDate+ "---------------Database Value: " + dbValue));
		}else if (flatFileValue!= null && flatFileValue.equalsIgnoreCase("Yes") ) {			
			flatFileValue="Y";			
			softAssertion.assertEquals(flatFileValue,dbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
		}else if (dbValue == null) {			
			dbValue="";			
			softAssertion.assertEquals(flatFileValue,dbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
		}else if (flatFileValue!= null && flatFileValue.equalsIgnoreCase("No")) {		
			flatFileValue="N";		
			softAssertion.assertEquals(flatFileValue,dbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
		}else if ( key.equalsIgnoreCase("ApplicantBirthDate")) {			
			 strFlatFileDate = flatFileValue.substring(2,4) + "-"+ (Month.of(Integer.parseInt(flatFileValue.substring(0,2))).name().substring(0,3)) + "-"+ flatFileValue.substring(6);
			softAssertion.assertEquals(strFlatFileDate,dbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strFlatFileDate+ "---------------Database Value: " + dbValue));
		}else if (key.equalsIgnoreCase("OEC_InsertedWhen") || key.equalsIgnoreCase("SubmitDate")) {
			strdbValue = dbValue.substring(5,7) + dbValue.substring(8,10) + dbValue.substring(0,4); 
			softAssertion.assertEquals(flatFileValue,strdbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + strdbValue));
		}else if ( key.equalsIgnoreCase("MedicarePartA") || key.equalsIgnoreCase("MedicarePartB") ) {		
			 strFlatFileDate = "01-" + (Month.of(Integer.parseInt(flatFileValue.substring(0,2))).name().substring(0,3)) + "-"+ flatFileValue.substring(4);
			strdbValue = dbValue.substring(8,10) + "-" + (Month.of(Integer.parseInt(dbValue.substring(5,7))).name().substring(0,3)) + "-"+ dbValue.substring(2,4);
			softAssertion.assertEquals(strFlatFileDate,strdbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strFlatFileDate+ "---------------Database Value: " + strdbValue));
		}else if (key.equalsIgnoreCase("SubmitTime")) {		
			strFlatFileDate = flatFileValue.substring(0,19);
			strdbValue = dbValue.substring(0,19) ;	
			softAssertion.assertEquals(strFlatFileDate,strdbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strFlatFileDate+ "---------------Database Value: " + strdbValue));
		}else if (key.equalsIgnoreCase("AgencyID")) {		
			strflatFileValue = flatFileValue.replaceAll("[^a-zA-Z0-9]","");
			softAssertion.assertEquals(strflatFileValue,dbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strflatFileValue+ "---------------Database Value: " + dbValue));
		}else if (key.equalsIgnoreCase("ApplicantSSN")) {		
			strflatFileValue = flatFileValue.replaceAll("[^a-zA-Z0-9]","");
			softAssertion.assertEquals(strflatFileValue,dbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strflatFileValue+ "---------------Database Value: " + dbValue));
		}else if (key.equalsIgnoreCase("PremiumWithhold")) {
			if (flatFileValue.equalsIgnoreCase(dbValue)){
				softAssertion.assertEquals(flatFileValue,dbValue, "<<" + key + ">> " );
				logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
			}else if (flatFileValue==""){
				logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
			}else{
				softAssertion.assertTrue(false);			
				logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
			}			
		}
		else if(key.equalsIgnoreCase("REC_ID1")){
			softAssertion.assertTrue(dbValue.contains(flatFileValue), "Element " + key + " is ot present" );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
		}
		else if(key.equalsIgnoreCase("REC_ID2")){
			softAssertion.assertTrue(dbValue.contains(flatFileValue), "Element " + key + " is ot present" );
			logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
		}
			
		else{				
			softAssertion.assertEquals(flatFileValue,dbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
		}		
	}
	
	
	
	//below method is to check whether the given number is numeric or not
		public static boolean isNumeric(String str) {
		    int size = str.length();
		    for (int i = 0; i < size; i++) {
		        if (!Character.isDigit(str.charAt(i))) {
		            return false;
		        }
		    }

		    return size > 0;
		} 

}
