package com.bsc.qa.pdf_validator;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bqsa.qa.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

public class ReporterTest extends BaseTest implements IHookable {

	public static Process process;
	public Constants constants= new Constants();
	// This method is to retrieve the xml data using UFT script
	@BeforeClass
	public void xmlDataRetrieve() throws IOException, InterruptedException {
		System.out.println("In BeforeClass");
		Path path = Paths.get("test-output\\BSC-reports\\"+Constants.timestamp);
		if(!Files.exists(path))
		{
		Files.createDirectories(path);
		}
		ExcelUtilities.copyFile(constants.sourceDatasheet,
				constants.destinationDatasheet);		
		process = Runtime.getRuntime().exec(constants.path_BatFile);
		process.waitFor();

		
	}

	// This method is to setup the excelfile and retrieve data from Input and
	// Subscriber sheet
	@BeforeMethod
	public void Setup() throws Exception {
		if(process.exitValue()==0){
			ExcelUtilities.setUpExcel(); // Set up the Excel file
			// Below method is for retrieving the data from Input sheet.
			driverCode.retrieveInputData();
			// Below method is for retrieving the data from Subscriber sheet
			driverCode
					.retrieveDataFromSubscriberEOB_Sheet(constants.sheetName_Sub_EOB);
		}	

	}
	
	
	

	// This method is to compare the XML data with PDF data
	@Test
	public void compareXmlToPdf() throws Exception, IOException, Throwable {
		driverCode.retrieveDataFromDatasheet();

	}

	// This method is to set the results in Excel
	@AfterMethod
	public void setResults() throws Exception {
		System.out.println("In After Method");
		ExcelUtilities.writeToWorkBook();
		ExcelUtilities.copyFile(constants.sourceFile, constants.destinationFile);
		
	}

	// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ALWAYS
	// KEEP AS
	// FOOTER%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	// Required method for every test Class for reporter to operate properly
	/**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {

		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}

	// This method is to close the PDF and excel
	@AfterClass
	public void closeFiles() throws Exception {
		pdfExtractor.closefile();
		ExcelUtilities.closefile();
	}

	// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ALWAYS
	// KEEP AS
	// FOOTER%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

} // Class
