package com.bqsa.qa.base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.pdf_validator.Constants;
import com.bsc.qa.pdf_validator.ExcelUtilities;
import com.bsc.qa.pdf_validator.ExtentReportFactory;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BaseTest {

	public static ExtentTest logger;
	public ExtentReports report;

	protected String testCaseName;
	protected String testMethodName;

	protected SoftAssert softAssert = null;

	/**
	 * @return the testCaseName
	 */
	public String getTestCaseName() {
		return testCaseName;
	}

	/**
	 * @param testCaseName
	 *            the testCaseName to set
	 */
	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}

	/**
	 * @return the testMethodName
	 */
	public String getTestMethodName() {
		return testMethodName;
	}

	/**
	 * 
	 * @param testMethodName
	 */
	public void setTestMethodName(String testMethodName) {
		this.testMethodName = testMethodName;
	}

	/**
	 * @AfterMethod gets called automatically after every @Test execution. This
	 *              is framework provided method. Ensure this method exists in
	 *              every Tests class
	 * 
	 * @param result
	 */
	@AfterMethod(alwaysRun = true)
	public void takeScreenShot(ITestResult result) {

		if (result != null) {

			if (ITestResult.FAILURE == result.getStatus()) {
				try {
					logger.log(LogStatus.ERROR, result.getThrowable());
					logger.log(LogStatus.FAIL, result.getName() + "_"
							+ testCaseName + " failed");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			if (ITestResult.SUCCESS == result.getStatus()) {
				logger.log(LogStatus.PASS, result.getName()
						+ " verified successfully");
			}
			tearDown();

		}
	}

	/**
	 * @AfterClass gets called after all tests methods are done executed.
	 */
	@AfterClass(alwaysRun = true)
	public void tearDown() {

		// WebDriver driver = BrowserFactoryManager.getDriver();
		// if(driver!=null){
		// driver.quit();
		// }
	}

	/*
	 * After suite will be responsible to close the report properly at the end
	 * You an have another afterSuite as well in the derived class and this one
	 * will be called in the end making it the last method to be called in test
	 * execution.
	 */
	@AfterSuite(alwaysRun = true)
	public void afterSuite() {
		ExtentReportFactory.closeReport();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		replaceInFile();
	}

	/**
	 * replaceInFile This method is added to replace the screenshot path in
	 * final Report.html. This utility method is added to support the archive
	 * feature in Jenkins. (Note that archive of reports are stored on Master
	 * (unix)).
	 */
	public static void replaceInFile() {
		try {
			File file = new File("test-output\\BSC-reports\\"+Constants.timestamp
					+ "\\Report.html");
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line = "", oldtext = "";
			while ((line = reader.readLine()) != null) {
				oldtext += line + "\r\n";
			}
			reader.close();
			// To replace a line in a file
			String path = "'" + System.getProperty("user.dir")
					+ "\\test-output\\BSC-reports\\screenshots\\";
			String newPath = "'screenshots\\";
			String newtext = oldtext.replaceAll(Matcher.quoteReplacement(path),
					Matcher.quoteReplacement(newPath));
			FileWriter writer = new FileWriter("test-output\\BSC-reports\\"+Constants.timestamp
					+ "\\Report.html");
			writer.write(newtext);
			writer.close();
			

		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	/**
	 * Initialize extent logger and report.
	 * 
	 * @param tc
	 *            name
	 *
	 */
	/**
	 * Initialize extent logger and report based on context and method name.
	 * 
	 * @param testContextName
	 * @param testMethodName
	 */
	protected void reportInit(String testContextName, String testMethodName) {
		// String envName = System.getenv("ENVNAME");
		logger = ExtentReportFactory.getTest();
		report = ExtentReportFactory.getExtentReport();
		logger = report.startTest(testContextName + ": " + testMethodName);
	}

}
