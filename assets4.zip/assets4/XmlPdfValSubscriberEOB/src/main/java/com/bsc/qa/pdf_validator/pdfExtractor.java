package com.bsc.qa.pdf_validator;

import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageTree;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;

public class pdfExtractor extends PDFTextStripper {


	public static PDDocument document;
	public static PDFTextStripperByArea pdfTextStripperByArea;
	public static PDFTextStripper pdfTextStripper;
	public static int startpage = 1;
	public static int endpage = 1;
	public static String tableText;

	public pdfExtractor() throws IOException {
		super();

	}

	/*
	 * Below method is used to set up the PDF file to read the data
	 */
	public static void PDFSetup(String pdfPath) throws IOException {
		document = PDDocument.load(new File(pdfPath));
		pdfTextStripper = new PDFTextStripper();
	}

	/*
	 * Below method is used to validate the text from xml against the text from
	 * PDF
	 */
	public static boolean validateTextInPDF(String textFromXML)
			throws IOException {

		String wholePDFText = pdfTextStripper.getText(document);

		if (wholePDFText.contains(textFromXML)) {
			return true;
		}
		return false;

	}

	/*
	 * Below method is to close the PDF file
	 */
	public static void closefile() throws IOException {
		document.close();

	}

	public static List<String> words = new ArrayList<String>();

	/*
	 * Below method is to extract the text from PDF by coordinates
	 */
	public static String getText(int xcoordinate, int ycoordinate, int width,
			int height) throws Exception, IOException {

		pdfTextStripperByArea = new PDFTextStripperByArea();
		pdfTextStripperByArea.setSortByPosition(true);

		Rectangle rect = new Rectangle(xcoordinate, ycoordinate, width, height);

		pdfTextStripperByArea.addRegion("dynamic data1", rect);

		PDPageTree pages = document.getPages();

		PDPage page = pages.get(0);

		pdfTextStripperByArea.extractRegions(page);

		// System.out.println("Text in area:"+rect);

		System.out.println("GetText Method:::::"
				+ pdfTextStripperByArea.getTextForRegion("dynamic data1"));

		String extractedText = pdfTextStripperByArea.getTextForRegion(
				"dynamic data1").trim();

		return extractedText;

	}

	/*
	 * Below method is to validate the extracted Text from PDF against the text
	 * from XML
	 */
	public static boolean validateText(String Expected, String Actual) {

		if (Actual.equals(Expected)) {
			System.out.println("Matched!!");
			return true;
		}

		return false;

	}

	/*
	 * Below method is to fetch the data from tables
	 */
	public static boolean tablevalidation(float totalAmountBilled, String labelName,
			String tableName) {
		new ArrayList<>();
		try {

			document.getClass();
			if (!document.isEncrypted()) {
				pdfTextStripperByArea.setSortByPosition(true);

				PDFTextStripper stripper = new PDFTextStripper();

				stripper.setStartPage(startpage);
				stripper.setEndPage(endpage);

				tableText = stripper.getText(document);
				String[] PDFTextLines = tableText.split("\\r?\\n");
				System.out.println("Executing table extraction and validation");
				for (int i = 0; i < PDFTextLines.length; i++) {
					String lines = PDFTextLines[i];

					if (tableName.equals("Patient Responsibility Table")) {
						if (lines.contains("Claim Totals")) {
							String[] pdfLines = lines.split(":");
							System.out.println(pdfLines[1]);

							String totalClaims = pdfLines[1];

							String[] claimsTotal = totalClaims.split("\\s+");

							System.out.println("Thge expected value is !!!"
									+ totalAmountBilled);
							
							//Below condition is to validate the calculated amount with table data
								
								if (labelName.equals("Amount Billed")) {

									if (totalAmountBilled == Float.parseFloat(claimsTotal[1])) {
									
										System.out
												.println("The total amount from xml "
														+ totalAmountBilled
														+ " matched with "
														+ claimsTotal[1]
														+ " present in PDF");
										return true;
									}
									else{
										System.out.println("total amount is mismatched with actual total amount!!!! ");
										return false;
									}
										
								} else if (labelName.equals("Amount We Paid")) {

									if (totalAmountBilled == Float.parseFloat(claimsTotal[2])) {

										System.out
												.println("The total amount from xml "
														+ totalAmountBilled
														+ " matched with "
														+ claimsTotal[2]
														+ " present in PDF");
										return true;
									}
									else{
										System.out.println("total amount is mismatched with actual total amount!!!! ");
										return false;
									}

								} else if (labelName.equals("noncovered_chrgs")) {

									if (totalAmountBilled == Float.parseFloat(claimsTotal[3])) {

										System.out
												.println("The total amount from xml "
														+ totalAmountBilled
														+ " matched with "
														+ claimsTotal[3]
														+ " present in PDF");
										return true;
									}
									else{
										System.out.println("total amount is mismatched with actual total amount!!!! ");
										return false;
									}

								} else if (labelName.equals("deductible_amt")) {

									if (totalAmountBilled == Float.parseFloat(claimsTotal[4])) {

										System.out
												.println("The total amount from xml "
														+ totalAmountBilled
														+ " matched with "
														+ claimsTotal[4]
														+ " present in PDF");
										return true;
									}
									else{
										System.out.println("total amount is mismatched with actual total amount!!!! ");
										return false;
									}

								} else if (labelName.equals("copay_amt")) {

									if (totalAmountBilled == Float.parseFloat(claimsTotal[5])) {

										System.out
												.println("The total amount from xml "
														+ totalAmountBilled
														+ " matched with "
														+ claimsTotal[5]
														+ " present in PDF");
										return true;
									}
									else{
										System.out.println("total amount is mismatched with actual total amount!!!! ");
										return false;
									}

								}
								else
								{
									System.out.println("Label Name is mismatched!!!!");
									return false;
								}
							
						}

					}
					else{
						System.out.println("Table name is mismatched!!!!!");
						return false;
					}

				}

			}
		}

		catch (Exception e) {

			e.printStackTrace();

		}
		// return actualValue;
		return false;

	}
//below method is to compare the text
	public static boolean compareText(String expected, String Actual) {
		if (Actual.contains(expected)) {
			System.out.println("Matched!!");
			return true;
		}

		return false;
	}
}
