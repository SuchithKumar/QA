//
//
//import java.io.IOException;
//import java.lang.reflect.Method;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//
//
//import org.testng.IHookCallBack;
//import org.testng.IHookable;
//import org.testng.ITestResult;
//import org.testng.annotations.DataProvider;
//import org.testng.annotations.Parameters;
//import org.testng.annotations.Test;
//import org.testng.asserts.SoftAssert;
//
//import com.bsc.qa.facets.ffpojo.factory.BaseTest;
//import com.bsc.qa.facets.ffpojo.readers.BscAccumsToCvsReader;
//import com.bsc.qa.facets.ffpojo.utility.DBUtils;
//import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
//import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
//import com.github.ffpojo.exception.FFPojoException;
//import com.relevantcodes.extentreports.LogStatus;
//
//public class Bsca_Accums_To_CVS_Test_Template_FullFile extends BaseTest implements IHookable{
//	
//	
//	private static String strMember_ID;
//	private static int bodyRowsCount;
//	
//
//	@Test(enabled = true,priority = 2, dataProvider = "masterDataProvider")
//	
//	public void OutboundCVSHeaderReqElementsValidation(Map<String, String> data) throws FFPojoException, IOException{ 
//		
//		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//		SoftAssert softAssertion= new SoftAssert();
//		
//		BscAccumsToCvsReader ffpExtract = new BscAccumsToCvsReader(filePAth);
//
//		//READ HEADERS TO ARRAYLIST OF HASHMAP 
//		List<Map<String, String>> testHeaders = ffpExtract.getListOfHeaderValues();
//		
//	    String SQLQuery = data.get("SQL_Header").toString();
//
//          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;
//		     
//		     try { //resultSetToArrayList may result in error so it is called in try catch block 
//		    	 
//		    	 arrayOfDBHashMapVals = objDBUtility.resultSetToArrayList(SQLQuery);
//		    	 
//		    		for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
//		    			
//		    			//Gets each key name in the loop
//		    			for (String DBkey : DBmap.keySet()) { // 
//		    			
//		    				System.out.println(DBkey);
//		    			    // for each array item of flat file map  
//		    				for (Map<String, String> FFmap : testHeaders) {
//		    					
//		    					// Test if DB Key exists in FF ste of Keys 
//		    			        if (FFmap.containsKey(DBkey)) {
//
//		    			            //key exists
//		    			            System.out.println("DB Key Found in FF Map -  " + FFmap.get(DBkey));
//		    			            
//		    			            softAssertion.assertEquals((FFmap.get(DBkey).toString()).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );
//
//		    			        } else {
//		    			            //key does not exists report failure 
//		    			        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Header Element " + DBkey + " is Required" );
//		    			        	System.out.println("Acctual Value: " + (FFmap.get(DBkey).toString()).trim() + " Expected Value: " + (DBmap.get(DBkey).toString()).trim());
//		    			        }
//		    					
//		    				} // for (Map<String, String> FFmap : testHeaders) {
//		    			
//		    			}//for (String key : map.keySet()) {
//		    			
//		    			
//		    		} // for (Map<String, String> map : testHeaders) {
//		    		
//		    		//SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//		    		softAssertion.assertAll();
//		    		
//		     } catch (SQLException e) {
//					// TODO Auto-generated catch block
//		    	 System.out.println("Something went Wrong while getting you db data");
//					e.printStackTrace();
//				}
//	
//	}	
//	
//	@Test(enabled = true, priority = 3, dataProvider = "masterDataProvider")
//	public void OutboundCVSBodyReqElementsValidation(Map<String, String> data) throws FFPojoException, IOException{ 
//		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//		SoftAssert softAssertion= new SoftAssert();
//		
//		//GEt query from data sheet(map), not meme id is not updated
//		String strRawSQLQuery = data.get("SQL_Body").toString();
//		
//        //read flat file 
//		BscAccumsToCvsReader ffpExtract = new BscAccumsToCvsReader(filePAth);
//		
//		//READHEADERS FROM LIST OF HASHMAP 
//		List<Map<String, String>> arrayOfFlatFileHashMap = ffpExtract.getListOfBodyValues();
//		
//		// get the count of data rows in message body . Needed for trailer validation
//		
//		  bodyRowsCount = arrayOfFlatFileHashMap.size();
//		  // print out row count
//		  System.out.println("File message body contains "+ bodyRowsCount +" rows");
//		  
//		  // declaration of array of hash map 
//          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;
//
//		 // for each row of data in flat file output
//		 for (Map<String, String> FFmap : arrayOfFlatFileHashMap) {			
//			
//			 //Capture the unique id value of the current row first 
//			 strMember_ID = FFmap.get("MEMBER_ID");
//			 
//			 String Accum_Code = FFmap.get("ACCUMULATION_CODE");
//		        	
//			 // call to query and parse SQL output to and array of HashMap
//			 arrayOfDBHashMapVals = objDBUtility.getUniqueResultSetToArrayList(strRawSQLQuery, strMember_ID, Accum_Code);
//			 
//			 // test for records set count , number of records from db should match to number of records in file (Important to understand that record set  = 1 row of data, not map key)
//			 
//			  softAssertion.assertEquals(arrayOfFlatFileHashMap.size(), arrayOfDBHashMapVals.size(), "Recods verification, flat file records set vs database records set: "); 
//
//			   
//			 // for each row of db output 
//				for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
//					
//					//Gets each key name in DB HashMap
//					for (String DBkey : DBmap.keySet()) { // 
//					   
//						//System.out.println("@@ DB Key " + DBkey + " @@@ DB Value " + DBmap.get(DBkey).toString());
//						 printMapVals(null, DBmap, DBkey );
//					    
//							// Test if DB Key exists in FF ste of Keys 
//					        if (FFmap.containsKey(DBkey)) {
//
//					            //key exist
//					            System.out.println("DB Key Found in FF Map - " + FFmap.get(DBkey));
//					            
//					            printMapVals(FFmap, null, DBkey );
//					            
//					            softAssertion.assertEquals((FFmap.get(DBkey).toString()).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );
//
//					            
//					            System.out.println("Acctual Value: " + (FFmap.get(DBkey).toString()).trim() + " Expected Value: " + (DBmap.get(DBkey).toString()).trim());
//					        
//					        } else {
//					            //key does not exists report failure 
//					        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Body Element " + DBkey + " is Required" );
//					        }
//					
//					}//for (String key : map.keySet()) {
//					
//					
//				} // for (Map<String, String> map : arrayOfFlatFileHashMap) {
//				
//				//SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//				softAssertion.assertAll();
//
//		 }//for (Map<String, String> FFmap : arrayOfFlatFileHashMap) {	
//		
//	}
//	
//	
//	@Test(enabled = true, priority = 6, dataProvider = "masterDataProvider")
//	public void OutboundCVSFooterElementsValidation(Map<String, String> data) throws FFPojoException, IOException{ 
//		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//		SoftAssert softAssertion= new SoftAssert();
//		
//		// the name of element in the file that contains  row unique id value.
//		//final String "MEMBER_ID" = "MEMBER_ID"; //Absolutely  must match to the name from ffpojo-ifm.xml
//				
//		//Get query from data sheet(map)
//		String strRawSQLQuery = data.get("SQL_Trailer").toString();
//		
//        //read flat file 
//		BscAccumsToCvsReader ffpExtract = new BscAccumsToCvsReader(filePAth);
//		
//		//READHEADERS FROM LIST OF HASHMAP 
//		List<Map<String, String>> testTrailer = ffpExtract.getListOfTrailerValues();
//		
//		  // declaration of array of hash map 
//          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;
//
//		 // for each row of data in flat file output
//		 for (Map<String, String> FFmap : testTrailer) {			
//					        	
//			 // call to query and parse SQL output to and array of HashMap
//			 arrayOfDBHashMapVals = objDBUtility.getUniqueResultSetToArrayList(strRawSQLQuery, strMember_ID, null);
//			   
//			 // for each row of db output 
//				for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
//					
//					//Gets each key name in DB HashMap
//					for (String DBkey : DBmap.keySet()) { // 
//					   
//						//System.out.println("@@ DB Key " + DBkey + " @@@ DB Value " + DBmap.get(DBkey).toString());
//						 
//						  printMapVals(null, DBmap, DBkey );
//						
//							// Test if DB Key exists in FF ste of Keys 
//					        if (FFmap.containsKey(DBkey)) {
//					        	
//
//					        	//TOTAL RECORDS VALIDATION
//					        	if (DBkey.equals("TOTAL_RECORDS")){
//					        		
//					        			    			        		
//					        		String actualValue = FFmap.get(DBkey).toString().trim();
//					        		
//					        		//testing the lenth of TOTAL_RECORDS field
//					        		softAssertion.assertEquals(actualValue.length(), 9, " Expected lenth of TOTAL_RECORDS is 9 chars long ");
//					        		//remove zeros from 000000005 to 5
//					        		actualValue = actualValue.replaceFirst("^0+(?!$)", "");
//					        		 //note the conversion of integer value 
//					        		  softAssertion.assertEquals(actualValue.trim(), (String.valueOf(bodyRowsCount)).trim(), "<<" + DBkey + ">> " );
//
//					        	}else{ // if (DBkey.equals("TOTAL_RECORDS")){
//
//					            //key exists
//					            //System.out.println("DB Key Found in FF Map - " + FFmap.get(DBkey));
//					            
//					            printMapVals(FFmap, null, DBkey );
//					            
//					            softAssertion.assertEquals((FFmap.get(DBkey).toString()).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );
//
//					            System.out.println("Acctual Value: " + (FFmap.get(DBkey).toString()).trim() + " Expected Value: " + (DBmap.get(DBkey).toString()).trim());
//					        
//					        	}
//					            
//					        } else {
//					            //key does not exists report failure 
//					        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Body Element " + DBkey + " is Required" );
//					        }
//					
//					}//for (String key : map.keySet()) {
//					
//					
//				} // for (Map<String, String> map : testTrailer) {
//				
//				//SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//				softAssertion.assertAll();
//
//		 }//for (Map<String, String> FFmap : arrayOfFlatFileHashMap) {	
//		
//	}
//	
//
//	@Test(enabled = false, priority = 4)
//	public void OutboundCVSTrailerReqElementsValidation() throws FFPojoException, IOException{ 
//	   
//		String SQLQuery = "String ";//data.get("SQL_Trailer").toString();
//		
//		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//		SoftAssert softAssertion= new SoftAssert();
//		
//		BscAccumsToCvsReader ffpExtract = new BscAccumsToCvsReader(filePAth);
//
//		//READHEADERS FROM LIST OF HASHMAP 
//		List<Map<String, String>> testTrailers = ffpExtract.getListOfTrailerValues();
//		
//          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;
//		     
//		     try { //resultSetToArrayList may result in error so it is called in try catch block 
//		    	 
//		    	 arrayOfDBHashMapVals = objDBUtility.resultSetToArrayList(SQLQuery);
//		    	 
//		    		for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
//		    			
//		    			//Gets each key name in the loop
//		    			for (String DBkey : DBmap.keySet()) { // 
//		    				
//		    				
//		    				System.out.println(DBkey);
//		    			    // for each array item of flat file map  
//		    				for (Map<String, String> FFmap : testTrailers) {
//		    					
//		    					// Test if DB Key exists in FF ste of Keys 
//		    			        if (FFmap.containsKey(DBkey)) {
//		    			        	
//
//		    			            //key exists
//		    			            System.out.println("DB Key Found in FF Map - " + FFmap.get(DBkey));
//		    			            
//		    			            softAssertion.assertEquals((FFmap.get(DBkey).toString()).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );
//		    			            System.out.println("Acctual Value: " + (FFmap.get(DBkey).toString()).trim() + " Expected Value: " + (DBmap.get(DBkey).toString()).trim());		    			            
//		    			      
//		    			        
//		    			        } else {
//		    			            //key does not exists report failure 
//		    			        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Trailer Element " + DBkey + " is Required" );
//		    			        }
//		    					
//		    				} // for (Map<String, String> FFmap : testTrailers) {
//		    			
//		    			}//for (String key : map.keySet()) {
//		    			
//		    			
//		    		} // for (Map<String, String> map : testTrailers) {
//		    		
//		    		//SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//		    		softAssertion.assertAll();
//		    		
//		     } catch (SQLException e) {
//					// TODO Auto-generated catch block
//		    	 System.out.println("Something went Wrong while getting you db data");
//					e.printStackTrace();
//				}
//		
//	}
//		
//	
//	
//	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 3 Test Methods that should be present in every test @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 3 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//	    
//	
//    private static final String testFileFolder = "BSCA_ACCUMS_TO_CVS"; // <== Mandatory , value should change for every test file 
//	private static DBUtils objDBUtility;//Mandatory declaration 
//	private static String filePAth ;//Mandatory 
//	
//	     /**
//		 * @Override run is a hook before @Test method
//		 */
//		@Override
//		public void run(IHookCallBack callBack, ITestResult testResult) {	
//			reportInit(testResult.getTestContext().getName(), testResult.getName());
//			softAssert = new SoftAssert();
//			logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
//			callBack.runTestMethod(testResult);	
//			softAssert.assertAll();				
//		}	
//		
//		
//		/**
//		 * Load test data from excel file into the testData object array.
//		 * 
//		 */
//		 // <== Both value are defined in testing.xml file
//		@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles"}) //Note parrams order
//		@Test(priority=1) // Keep it marked as @Test to make sure this method is invoked 
//		public void loadExcelSheetData(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles){	//Args order matters should match to params order
//
//			if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
//				NameOfTestDataSheet = "Sheet1";
//			}
//			
//			// Functional call to initialize cache from data sheet 
//			ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
//		 	
//			//NOTE DB UTIL OBJECT CREATION! 
//			 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
//			 TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, testFileFolder); //second folder is file location folder 
//			 filePAth = tesFile.getCompleteTestFilePath();
//			 System.out.println(filePAth);
//		}
//		
//		@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
//		private static Object[][] getData(Method method) {
//			Object[][] data = null;
//			Map<String, String> dataMap = new HashMap<String, String>();
//
//			dataMap = ExcelUtils.getTestMethodData(method.getName());
//			data = new Object[][] { { dataMap } };
//			return data;
//		}
//
//		
//		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 3 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//}
