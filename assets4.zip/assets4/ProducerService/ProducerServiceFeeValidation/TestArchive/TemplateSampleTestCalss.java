
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.bqsa.AutomationStringUtilities;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.relevantcodes.extentreports.LogStatus;


public class TemplateSampleTestCalss extends BaseTest implements IHookable { // <== Test class must always extend BaseTest and implement IHookable! 

//	/**
//	 * Contructor used to load test data
//	 * 
//	 */
//	public TemplateSampleTestCalss() {
//	    loadTestData();
//	}	
//	
	
	
 @Test(priority = 2, dataProvider = "masterDataProvider")
 public void howToGetTestDataFromDataMap(Map<String, String> data){ // Note Map<String, String> data is coming from ==> private static Object[][] getData(Method method)
  //print a value from data sheet where test method name = howToGetTestDataFromDataMap and column name "SERHIY" 
  System.out.println("Example of Data Sheet Value Use: ");
  System.out.println(data.get("SERHIY").toString());
 } //public void howToGetTestDataFromDataMap(Map<String, String> data){
	
 
 @Parameters ({"DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port"})
 @Test(priority=1) // @Test will ensure that method is called , please note that dataProvider is not used 
 public void howToGetParametersValuesFromTestingDotXmlFile (String DB_Name, String DB_User,String DB_Pwd,String DB_Server,String DB_Port) {
  
  System.out.println("Example of Parameters Data Use: Sheet Value: ");
  // How to decrypt user id value :
  String uID = AutomationStringUtilities.decryptValue((DB_User.trim())); // <== Note that User ID value being decrypted 
 // Print Values Passed as parameters from tesing.xml file      
  System.out.println(DB_Name);
  System.out.println("Encrypted UserID : " + DB_User);
  System.out.println("Decrypted UserID : " + uID);
  System.out.println(DB_Pwd);
  System.out.println(DB_Server);
  System.out.println(DB_Port);

}	
 
 @Parameters ({"DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port"})
 @Test(priority=3)
	public void howToReadandLoopsOverDBValues(String DB_Name, String DB_User,String DB_Pwd,String DB_Server,String DB_Port) {
	 
	 System.out.println("Example of getting single DB value as Sting: ");
	 
	 String hardcodedSQLString = "select SBSB_CK, GRGR_CK, SBSB_ID, SBSB_LAST_NAME, SBSB_FIRST_NAME, SBSB_MID_INIT, SBSB_TITLE from FACETS.CMC_SBSB_SUBSC sbsb where sbsb.SBSB_ID = '905421852'";
     
 	//NOTE DB UTIL OBJECT CREATION! 
	DBUtils objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
    //Example of geting Single String Value ()
	String strResult = objDBUtility.getSingleStringFromDatabase(hardcodedSQLString);
    System.out.println("Single String from DB: "+strResult.toString());

    System.out.println("Example of getting ArrayList of HashMap values from DB DB value as Sting: ");
    
    ArrayList<Map<String, Object>> myArrayOfHashMapValuesFromDatabase;
     
     try { //resultSetToArrayList may result in error so it is called in try catch block 
    	 
    	 myArrayOfHashMapValuesFromDatabase = objDBUtility.resultSetToArrayList(hardcodedSQLString);
    	 
    	 //Iteration over Array List 
    	 
    		for (Map<String, Object> map : myArrayOfHashMapValuesFromDatabase) {
    			
    			System.out.println(map.get("SBSB_CK"));
    			System.out.println(map.get("GRGR_CK"));
    			System.out.println(map.get("SBSB_ID"));
    			System.out.println(map.get("SBSB_LAST_NAME"));
    			System.out.println(map.get("SBSB_FIRST_NAME"));
    			System.out.println(map.get("SBSB_MID_INIT"));
    			System.out.println(map.get("SBSB_MID_INIT"));  			
    			
    			
    		} // for (Map<String, String> map : testHeaders) {
    	 
		
     } catch (SQLException e) {
			// TODO Auto-generated catch block
    	 System.out.println("Something went Wrong while getting you db data");
			e.printStackTrace();
		}
         

    //Example of Getting DB Data in Array : 
     System.out.println("Example of Getting DB Data in Array:");
     
     Object[][] arrayOfDBData =  objDBUtility.getArrayOfTableData(hardcodedSQLString);

         for (int i = 0; i<arrayOfDBData.length; i++){
         
     	    for (int j = 0; j<arrayOfDBData[i].length; j++){
           
         	   System.out.println("Array item " + i + j + " : " + arrayOfDBData[i][j]);
         
             } 

        }
 
 } // public void howToReadandLoopsOverDBValues(String DB_Name, String DB_User,String DB_Pwd,String DB_Server,String DB_Port) {
 
 

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 3 Test Mathod that should be present in every test @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ DO NOT EDIT BELOW THIS LINE @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 3 Mendatory mathoda : ethods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	
	/**
	 * Load test data from excel file into the testData object array.
	 * 
	 */
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation"}) // <== Both value are defined in testing.xml file
	@Test(priority=1) // Keep it marked as @Test to make sure this method is invoked 
	public void loadExcelSheetData(String NameOfTestDataSheet, String TestDataSheetLocation ){		

		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);

	} 
	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) {
		Object[][] data = null;
		Map<String, String> dataMap = new HashMap<String, String>();

		dataMap = ExcelUtils.getTestMethodData(method.getName());
		data = new Object[][] { { dataMap } };
		return data;
	}
	
}// 
	
	
	

//} // Class Ends Here 
