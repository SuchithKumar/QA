package com.bsc.qa.facets.ffp.pojo.nameOfFileType;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscAccumsToOptumRxBody {
	
	private String DETAIL_INDICATOR;
	private String FACETS_GROUP_ID;
	private String SUBSCRIBER_ID;
	private String RELATIONSHIP_CODE;
	private String MEMBER_ESSN;
	private String MEMBER_DATE_OF_BIRTH;
	private String MEMBER_FIRST_NAME;
	private String MEMBER_LAST_NAME;
	private String GENDER;
	private String MEM_OOP_AMT;
	private String MEM_DED_AMT;
	private String FAM_OOP_AMT;
	private String FAM_DED_AMT;
	private String MEM_DED_MAX;
	private String MEM_OOP_MAX;
	private String FAM_DED_MAX;
	private String FAM_OOP_MAX;

	/**
	 * @return the DETAIL_INDICATOR
	 */
	public String getDETAIL_INDICATOR() {
		return DETAIL_INDICATOR;
	}
	/**
	 * @param DETAIL_INDICATOR the DETAIL_INDICATOR to set
	 */
	public void setDETAIL_INDICATOR(String DETAIL_INDICATOR) {
		this.DETAIL_INDICATOR = DETAIL_INDICATOR;
	}
	/**
	 * @return the FACETS_GROUP_ID
	 */
	public String getFACETS_GROUP_ID() {
		return FACETS_GROUP_ID;
	}
	/**
	 * @param FACETS_GROUP_ID the FACETS_GROUP_ID to set
	 */
	public void setFACETS_GROUP_ID(String FACETS_GROUP_ID) {
		this.FACETS_GROUP_ID = FACETS_GROUP_ID;
	}
	/**
	 * @return the SUBSCRIBER_ID
	 */
	public String getSUBSCRIBER_ID() {
		return SUBSCRIBER_ID;
	}
	/**
	 * @param SUBSCRIBER_ID the SUBSCRIBER_ID to set
	 */
	public void setSUBSCRIBER_ID(String SUBSCRIBER_ID) {
		this.SUBSCRIBER_ID = SUBSCRIBER_ID;
	}
	/**
	 * @return the RELATIONSHIP_CODE
	 */
	public String getRELATIONSHIP_CODE() {
		return RELATIONSHIP_CODE;
	}
	/**
	 * @param RELATIONSHIP_CODE the RELATIONSHIP_CODE to set
	 */
	public void setRELATIONSHIP_CODE(String RELATIONSHIP_CODE) {
		this.RELATIONSHIP_CODE = RELATIONSHIP_CODE;
	}
	/**
	 * @return the MEMBER_ESSN
	 */
	public String getMEMBER_ESSN() {
		return MEMBER_ESSN;
	}
	/**
	 * @param MEMBER_ESSN the MEMBER_ESSN to set
	 */
	public void setMEMBER_ESSN(String MEMBER_ESSN) {
		this.MEMBER_ESSN = MEMBER_ESSN;
	}
	/**
	 * @return the mEMBER_DATE_OF_BIRTH
	 */
	public String getMEMBER_DATE_OF_BIRTH() {
		return MEMBER_DATE_OF_BIRTH;
	}
	/**
	 * @param mEMBER_DATE_OF_BIRTH the mEMBER_DATE_OF_BIRTH to set
	 */
	public void setMEMBER_DATE_OF_BIRTH(String MEMBER_DATE_OF_BIRTH) {
		this.MEMBER_DATE_OF_BIRTH = MEMBER_DATE_OF_BIRTH;
	}
	/**
	 * @return the MEMBER_FIRST_NAME
	 */
	public String getMEMBER_FIRST_NAME() {
		return MEMBER_FIRST_NAME;
	}
	/**
	 * @param MEMBER_FIRST_NAME the MEMBER_FIRST_NAME to set
	 */
	public void setMEMBER_FIRST_NAME(String MEMBER_FIRST_NAME) {
		this.MEMBER_FIRST_NAME = MEMBER_FIRST_NAME;
	}
	/**
	 * @return the MEMBER_LAST_NAME
	 */
	public String getMEMBER_LAST_NAME() {
		return MEMBER_LAST_NAME;
	}
	/**
	 * @param MEMBER_LAST_NAME the MEMBER_LAST_NAME to set
	 */
	public void setMEMBER_LAST_NAME(String MEMBER_LAST_NAME) {
		this.MEMBER_LAST_NAME = MEMBER_LAST_NAME;
	}
	/**
	 * @return the GENDER
	 */
	public String getGENDER() {
		return GENDER;
	}
	/**
	 * @param GENDER the GENDER to set
	 */
	public void setGENDER(String GENDER) {
		this.GENDER = GENDER;
	}
	/**
	 * @return the MEM_OOP_AMT
	 */
	public String getMEM_OOP_AMT() {
		return MEM_OOP_AMT;
	}
	/**
	 * @param MEM_OOP_AMT the MEM_OOP_AMT to set
	 */
	public void setMEM_OOP_AMT(String MEM_OOP_AMT) {
		this.MEM_OOP_AMT = MEM_OOP_AMT;
	}
	/**
	 * @return the MEM_DED_AMT
	 */
	public String getMEM_DED_AMT() {
		return MEM_DED_AMT;
	}
	/**
	 * @param MEM_DED_AMT the MEM_DED_AMT to set
	 */
	public void setMEM_DED_AMT(String MEM_DED_AMT) {
		this.MEM_DED_AMT = MEM_DED_AMT;
	}
	/**
	 * @return the FAM_OOP_AMT
	 */
	public String getFAM_OOP_AMT() {
		return FAM_OOP_AMT;
	}
	/**
	 * @param FAM_OOP_AMT the FAM_OOP_AMT to set
	 */
	public void setFAM_OOP_AMT(String FAM_OOP_AMT) {
		this.FAM_OOP_AMT = FAM_OOP_AMT;
	}
	/**
	 * @return the FAM_DED_AMT
	 */
	public String getFAM_DED_AMT() {
		return FAM_DED_AMT;
	}
	/**
	 * @param INCOMING_ADJUSTMENT_AMOUNT the INCOMING_ADJUSTMENT_AMOUNT to set
	 */
	public void setFAM_DED_AMT(String FAM_DED_AMT) {
		this.FAM_DED_AMT = FAM_DED_AMT;
	}
	/**
	 * @return the MEM_DED_MAX
	 */
	public String getMEM_DED_MAX() {
		return MEM_DED_MAX;
	}
	/**
	 * @param MEM_DED_MAX the MEM_DED_MAX to set
	 */
	public void setMEM_DED_MAX(String MEM_DED_MAX) {
		this.MEM_DED_MAX = MEM_DED_MAX;
	}
	/**
	 * @return the MEM_OOP_MAX
	 */
	public String getMEM_OOP_MAX() {
		return MEM_OOP_MAX;
	}
	/**
	 * @param MEM_OOP_MAX the MEM_OOP_MAX to set
	 */
	public void setMEM_OOP_MAX(String MEM_OOP_MAX) {
		this.MEM_OOP_MAX = MEM_OOP_MAX;
	}
	/**
	 * @return the FAM_DED_MAX
	 */
	public String getFAM_DED_MAX() {
		return FAM_DED_MAX;
	}
	/**
	 * @param FAM_DED_MAX the FAM_DED_MAX to set
	 */
	public void setFAM_DED_MAX(String FAM_DED_MAX) {
		this.FAM_DED_MAX = FAM_DED_MAX;
	}
/**
	 * @return the FAM_OOP_MAX
			 */
			public String getFAM_OOP_MAX() {
				return FAM_OOP_MAX;
			}
			/**
			 * @param FAM_OOP_MAX the FAM_OOP_MAX to set
			 */
			public void setFAM_OOP_MAX(String FAM_OOP_MAX) {
				this.FAM_OOP_MAX = FAM_OOP_MAX;
			}
	
	
	
	////////////////////////////////////////////////////////
//	private String GROUP_ID;
//	public String getGROUP_ID() {
//		return GROUP_ID;
//	}
//	public void setGROUP_ID(String GROUP_ID) {
//		this.GROUP_ID = GROUP_ID;
//	}
//	
//
//
//
}
