package com.bsc.qa.facets.ffp.pojo.nameOfFileType;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;// <== Mandatory 

@PositionalRecord(ignorePositionNotFound=true) // <== Mandatory 

public class BscAccumsToOptumRxTrailer {
	
	private String TRAILER_INDICATOR;
	private String TOTAL_RECORDS;
	private String TOTAL_AMOUNT;
	private String FILLER;
	/**
	 * @return the TRAILER_INDICATOR
	 */
	public String getTRAILER_INDICATOR() {
		return TRAILER_INDICATOR;
	}
	/**
	 * @param TRAILER_INDICATOR the TRAILER_INDICATOR to set
	 */
	public void setTRAILER_INDICATOR(String TRAILER_INDICATOR) {
		this.TRAILER_INDICATOR = TRAILER_INDICATOR;
	}
	/**
	 * @return the TOTAL_AMOUNT
	 */
	public String getTOTAL_AMOUNT() {
		return TOTAL_AMOUNT;
	}
	/**
	 * @param CARRIER the CARRIER to set
	 */
	public void setTOTAL_AMOUNT(String TOTAL_AMOUNT) {
		this.TOTAL_AMOUNT = TOTAL_AMOUNT;
	}
	/**
	 * @return the TOTAL_RECORDS
	 */
	public String getTOTAL_RECORDS() {
		return TOTAL_RECORDS;
	}
	/**
	 * @param TOTAL_RECORDS the TOTAL_RECORDS to set
	 */
	public void setTOTAL_RECORDS(String TOTAL_RECORDS) {
		this.TOTAL_RECORDS = TOTAL_RECORDS;
	}
	/**
	 * @return the FILLER
	 */
	public String getFILLER() {
		return FILLER;
	}
	/**
	 * @param FILLER the FILLER to set
	 */
	public void setFILLER(String FILLER) {
		this.FILLER = FILLER;
	}

	

}
