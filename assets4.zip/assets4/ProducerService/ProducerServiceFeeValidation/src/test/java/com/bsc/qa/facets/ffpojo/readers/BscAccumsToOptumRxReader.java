package com.bsc.qa.facets.ffpojo.readers;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




import com.bsc.qa.facets.ffp.pojo.nameOfFileType.BscAccumsToOptumRxBody;
import com.bsc.qa.facets.ffp.pojo.nameOfFileType.BscAccumsToOptumRxHeader;
import com.bsc.qa.facets.ffp.pojo.nameOfFileType.BscAccumsToOptumRxTrailer;
import com.github.ffpojo.exception.FFPojoException;
import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.file.reader.RecordType;

public class BscAccumsToOptumRxReader {
	
	
	String testFlatFileCompletePath; // <== Path to a test file  
	
	public BscAccumsToOptumRxReader(String testFlatFileCompletePath) {
		this.testFlatFileCompletePath = testFlatFileCompletePath;
	} //public AshpAccumsToBscaReader(String testFlatFileCompletePath) {

	
	////////////////////////////////FLAT FILE HEADER TO LIST////////////////////
	public List<Map<String, String>> getListOfHeaderValues() throws IOException{
						
		List<Map<String , String>> headersList  = new ArrayList<Map<String,String>>();
		
        File inputFile = new File(testFlatFileCompletePath);
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { // if (!inputFile.exists()) { 
			
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscAccumsToOptumRxBody.class);   // <== BODY
			ffDefinition.setHeader(BscAccumsToOptumRxHeader.class);
			ffDefinition.setTrailer(BscAccumsToOptumRxTrailer.class);
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		
			for (Object record : ffReader) {
				
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.HEADER) { //<=== Headers 
					
					Map<String,String> headersMap = new HashMap<String, String>();
					
					//System.out.println("HEADER FOUND: ");
					
					BscAccumsToOptumRxHeader header = (BscAccumsToOptumRxHeader)record;
				
					headersMap.put("HEADER_INDICATOR", header.getHEADER_INDICATOR()); //<== Add 
					headersMap.put("CLIENT_NAME", header.getCLIENT_NAME()); //<== Add 
					headersMap.put("CLIENT_ID", header.getCLIENT_ID()); //<== Add 
					headersMap.put("FILE_DATE", header.getFILE_DATE()); //<== Add 
					headersMap.put("FILLER", header.getFILLER()); //<== Add 
									
					headersList.add(0,headersMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
				    			
				} //if (recordType == RecordType.HEADER)
				
			} // <== for (Object record : ffReader) {
			
			ffReader.close(); //Close Object 
		
		} // if (!inputFile.exists()) { 
	
		return headersList; // method return value 
						
	} // <==  public List<Map<String, String>> getListOfHeaderValues(){
	
	
	////////////////////////////////FLAT FILE BODY TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfBodyValues() throws IOException{
				
		List<Map<String , String>> bodyList  = new ArrayList<Map<String,String>>();
		// get file 
        File inputFile = new File(testFlatFileCompletePath);
    	//test if file exist 
		if (!inputFile.exists()) { 
			//cry if file does not exist 
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { //if (!inputFile.exists()) { 
			// do the magic if file exists 
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscAccumsToOptumRxBody.class);   // <== BODY
			ffDefinition.setHeader(BscAccumsToOptumRxHeader.class);
			ffDefinition.setTrailer(BscAccumsToOptumRxTrailer.class);
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		    int counter = 0;
		    
			for (Object record : ffReader) {
				
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.BODY) { //<=== BODY 
					
					Map<String,String> bodyMap = new HashMap<String, String>(); //<== NEW HASH MAP ON EVERY LOOP 
					
					BscAccumsToOptumRxBody body = (BscAccumsToOptumRxBody)record;
				
					bodyMap.put("DETAIL_INDICATOR", body.getDETAIL_INDICATOR()); //<== Add 
					bodyMap.put("FACETS_GROUP_ID", body.getFACETS_GROUP_ID()); //<== Add 
					bodyMap.put("SUBSCRIBER_ID", body.getSUBSCRIBER_ID()); //<== Add 
					bodyMap.put("RELATIONSHIP_CODE", body.getRELATIONSHIP_CODE()); //<== Add 
					bodyMap.put("MEMBER_ESSN", body.getMEMBER_ESSN()); //<== Add 
					bodyMap.put("MEMBER_DATE_OF_BIRTH", body.getMEMBER_DATE_OF_BIRTH()); //<== Add 
					bodyMap.put("MEMBER_FIRST_NAME", body.getMEMBER_FIRST_NAME()); //<== Add 
					bodyMap.put("MEMBER_LAST_NAME", body.getMEMBER_LAST_NAME()); //<== Add 
					bodyMap.put("GENDER", body.getGENDER()); //<== Add 
					bodyMap.put("MEM_OOP_AMT", body.getMEM_OOP_AMT()); //<== Add 
					bodyMap.put("MEM_DED_AMT", body.getMEM_DED_AMT()); //<== Add 
					bodyMap.put("FAM_OOP_AMT", body.getFAM_OOP_AMT()); //<== Add 
					bodyMap.put("FAM_DED_AMT", body.getFAM_DED_AMT()); //<== Add 
					bodyMap.put("MEM_DED_MAX", body.getMEM_DED_MAX()); //<== Add 
					bodyMap.put("MEM_OOP_MAX", body.getMEM_OOP_MAX()); //<== Add 
					bodyMap.put("FAM_DED_MAX", body.getFAM_DED_MAX()); //<== Add 
					bodyMap.put("FAM_OOP_MAX", body.getFAM_OOP_MAX()); //<== Add 

						
					bodyList.add(counter,bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
					counter++;
				    			
				}			
			 } // <== for (Object record : ffReader) {
			
			ffReader.close(); //Close Object 	
			
		} // if (!inputFile.exists()) { 
		
		return bodyList; // method return value 
	
	} // <==  public List<Map<String, String>> getListOfBodyValues(){
	
	
	////////////////////////////////FLAT TRAILER VALUES TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfTrailerValues() throws IOException{
	//return list map 	
    List<Map<String , String>> trailerList  = new ArrayList<Map<String,String>>();

    File inputFile = new File(testFlatFileCompletePath); // <== Import of file under test 

    if (!inputFile.exists()) { 
	
	   throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	
    } else { // if (!inputFile.exists()) {
    	
    	FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscAccumsToOptumRxBody.class);   // <== BODY
        ffDefinition.setHeader(BscAccumsToOptumRxHeader.class);  ffDefinition.setTrailer(BscAccumsToOptumRxTrailer.class);

        FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);

        for (Object record : ffReader) {
   	
   	      RecordType recordType = ffReader.getRecordType();
   	
   	      if (recordType == RecordType.TRAILER) { //<=== TRAILER 
   		
   		    Map<String,String> TrailerMap = new HashMap<String, String>();
   		
   		   // System.out.println("Trailer FOUND: ");
   		
   		    BscAccumsToOptumRxTrailer trailer = (BscAccumsToOptumRxTrailer)record;
   	
   		    TrailerMap.put("TRAILER_INDICATOR", trailer.getTRAILER_INDICATOR()); //<== Add 
   		    TrailerMap.put("TOTAL_RECORDS", trailer.getTOTAL_RECORDS());
   		    TrailerMap.put("TOTAL_AMOUNT", trailer.getTOTAL_AMOUNT());
   		    TrailerMap.put("FILLER", trailer.getFILLER());
   		 
   						
   		    trailerList.add(0,TrailerMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
   	    			
   	      }
   	
        } // <== for (Object record : ffReader) {

    ffReader.close(); //Close Object 
    
    } //if (!inputFile.exists()) {

	
     return trailerList; // method return value 
		
	}	// <== public List<Map<String, String>> getListOfTrailerValues(){
	
	
	
//SAMPLE to READ ALL in ONE METHOD NOT USED BY TEST < GOOD FOR DEBUGGING
public void readExtracts() throws IOException, FFPojoException {
		
		File inputFile = new File(testFlatFileCompletePath);
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		}
		
		
		FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscAccumsToOptumRxBody.class);   // <== BODY
		ffDefinition.setHeader(BscAccumsToOptumRxHeader.class); ffDefinition.setTrailer(BscAccumsToOptumRxTrailer.class);
		
		FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
	
		for (Object record : ffReader) {
			
			RecordType recordType = ffReader.getRecordType();
			
			if (recordType == RecordType.HEADER) { //<=== Headers 
				
				System.out.print("HEADER FOUND: " + record.hashCode());
				//BscAccumsToCvsHeader header = (BscAccumsToCvsHeader)record;
				//System.out.println(header.getHEADER_INDICATOR());
			
			} else if (recordType == RecordType.BODY) {
				
				//BscAccumsToDBPSHDWBody cust = (BscAccumsToDBPSHDWBody)record;
				//System.out.println(cust.getMEMBER_FIRST_NAME()+ " " + cust.getMEMBER_LAST_NAME());
			
			} else if (recordType == RecordType.TRAILER) {
				
				//System.out.println("TRAILER FOUND: ");
				//BscAccumsToCvsTrailer trailer = (BscAccumsToNavitusTrailer)record;
				//System.out.println(trailer.getTOTAL_AMOUNT());
			}
		
		
		}
		
		ffReader.close();

	}
	
	
	
	

}
