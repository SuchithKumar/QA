package com.bsc.qa.PCPNotification.XmlToPdfValidator;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.ExcelUtilities;

public class drivercode {
	public static Process process1;
	public static HashMap<String, String> map_Metadata;
	public static HashMap<String, String> map_Metadata_clone;
	public static int Input_rowsize;
	public static HashMap<String, String> map_Input;
	public static Integer pdfKeyPath = 1;
	public static boolean result_xmlData = false;
	public static String extractedText = null;
	public static String xpath_Datasheet;
	public static String Exec_No_Datasheet;
	public static String indexOfXpath;
	public static HashMap<Integer, String> collNumCellValueMap = new HashMap<Integer, String>();
	public static ConstantVariables constantVariables = new ConstantVariables();
	public static boolean result_xmlData_static;
	/*
	 * Below method retrieve the data from Subscriber EOB Sheet and put the data
	 * in map_Metadata
	 */

	@SuppressWarnings("unchecked")
	public static void retrieveDataFromMetaData_Sheet(
			String sheetName_EOB) throws Exception {
		try {
			map_Metadata = new HashMap<String, String>(); // Creating Map to fetch the coordinates based on xpath


			map_Metadata_clone = new HashMap<String, String>();// to clone the map_Metadata
														
			int rowCount_sheetName = ExcelUtilities
					.getRowCount(sheetName_EOB);// to get the row count of subscriber sheet
			
			System.out.println("The row size is "+rowCount_sheetName);
												
			/*
			 * Below loop is to put the data fetched from subscriber sheet into
			 * a Map
			 */

			for (int rowNum = 1; rowNum <= rowCount_sheetName; rowNum++) {

				String xpath_EOB = ExcelUtilities.getCellValue(
						sheetName_EOB, rowNum, constantVariables.xpath_collNum_EOB);// to get xpath from subscriber sheet
				System.out.println("The xpath in metadata sheet is "+xpath_EOB);														
				String typeOParameter = ExcelUtilities.getCellValue(
						sheetName_EOB, rowNum,
						constantVariables.typeOfParameter_collNum);// to get type of parameter from subscriber sheet
														
				String parameter1 = ExcelUtilities
						.getCellValue(sheetName_EOB, rowNum,
								constantVariables.parameter1_collNum);// to get parameter1 from subscriber sheet
													
				String parameter2 = ExcelUtilities
						.getCellValue(sheetName_EOB, rowNum,
								constantVariables.parameter2_collNum);// to get parameter2 from subscriber sheet
												
				String parameter3 = ExcelUtilities
						.getCellValue(sheetName_EOB, rowNum,
								constantVariables.parameter3_collNum);// to get parameter3 from subscriber sheet
										
				String parameter4 = ExcelUtilities
						.getCellValue(sheetName_EOB, rowNum,
								constantVariables.parameter4_collNum);// to get parameter4 from subscriber sheet
										
				String element = ExcelUtilities.getCellValue(sheetName_EOB,
						rowNum, constantVariables.element_collNum);// to get elements from subscriber sheet
					
				System.out.println("The xpath in metadatasheet is      "+xpath_EOB);

				if (xpath_EOB != null && xpath_EOB.length() != 0) // condition to check xpath value is not null in the sheet
																			

				{
					/*
					 * Below map is to fetch the type of parameter , coordinates
					 * , tablename & label name based on xpath
					 */
					map_Metadata.put(xpath_EOB.trim() + "_top",
							typeOParameter.trim());
					map_Metadata.put(xpath_EOB.trim() + "_p1",
							parameter1.trim());
					map_Metadata.put(xpath_EOB.trim() + "_p2",
							parameter2.trim());
					map_Metadata.put(xpath_EOB.trim() + "_p3",
							parameter3.trim());
					map_Metadata.put(xpath_EOB.trim() + "_p4",
							parameter4.trim());
					map_Metadata.put(xpath_EOB.trim() + "_ele",
							element.trim());

				}
			}

			map_Metadata_clone = (HashMap<String, String>) map_Metadata.clone();// cloning
																				// map_Metadata
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Below method retrieve the all the rows from Datasheet sheet and verify
	 * the xpath in the map_Metadata if the xpath is present then it will get
	 * the parameter values from map_metadata then validate the data with the
	 * PDF and post the results
	 */

	@SuppressWarnings("unchecked")
	public static void retrieveDataFromDatasheet()
			throws NumberFormatException, IOException, Exception {

		constantVariables.rowCount_sheetName_Datasheet = ExcelUtilities
				.getRowCount(constantVariables.sheetName_Datasheet); // to get the rowcount of Datasheet
														

		int prevExecno = 1; // execution flag to check the execution number is changed
					
		// Below method is for setting the PDF to read the data
		pdfExtractor.PDFSetup(map_Input.get(pdfKeyPath + "_pdf"));

		/*
		 * Below loop is for iterating through all the rows and capturing all
		 * required values from Data sheet
		 */

		for (; constantVariables.rowNum <= (constantVariables.rowCount_sheetName_Datasheet); constantVariables.rowNum++) {

			try {

				System.out.println("RowNo::::::::::::" + constantVariables.rowNum);

				xpath_Datasheet = ExcelUtilities.getCellValue(
						constantVariables.sheetName_Datasheet, constantVariables.rowNum,
						constantVariables.xpath_collNum_Datasheet); // To fetch the xpath from datasheet
														
				String expectedValue_Datasheet = ExcelUtilities.getCellValue(
						constantVariables.sheetName_Datasheet, constantVariables.rowNum,
						constantVariables.expectedValue_collNum_Datasheet);// To fetch the expected value from datasheet
								
				String Exec_No_Datasheet = ExcelUtilities.getCellValue(
						constantVariables.sheetName_Datasheet, constantVariables.rowNum,
						constantVariables.execNo_collNum_Datasheet);// To fetch the execution number from datasheet
				/*									
				indexOfXpath = ExcelUtilities.getCellValue(
						Constants.sheetName_Datasheet, Constants.rowNum,
						Constants.index_collNum_Datasheet);*/ // To fetch the index from datasheet
														
				/*
				 * Below condition is to enter inside when the xpath from Data
				 * sheet are not null and empty
				 */

				if (xpath_Datasheet != null) {
					/*
					 * Below condition is to enter inside when the execution
					 * number is changed or execution is ended
					 */
					if (prevExecno != Integer.parseInt(Exec_No_Datasheet)
							|| ExcelUtilities.isLastRow(constantVariables.rowNum,
									constantVariables.sheetName_Datasheet)) {

						constantVariables.RowNumber = constantVariables.rowNum;
						constantVariables.lastRowNumber = ExcelUtilities
								.getRowCount(constantVariables.sheetName_Datasheet);

						System.out.println("The last row number is !!!!!!"
								+ constantVariables.lastRowNumber);
						/*
						 * Below condition is to enter inside when the execution
						 * number is changed
						 */
						if (constantVariables.RowNumber != constantVariables.lastRowNumber
								&& prevExecno != Integer
										.parseInt(Exec_No_Datasheet)) {
							pdfKeyPath++;
							System.out.println("Executing 2nd PDF!!!!!!!!!");
							pdfExtractor.PDFSetup(map_Input.get(pdfKeyPath
									+ "_pdf"));
							System.out.println("The xpath of the row is !!!!"
									+ xpath_Datasheet);
							/*
							 * Below method is for executing the static data
							 * which is present Subscriber sheet
							 */

							executeCloneMapData(Exec_No_Datasheet,
									expectedValue_Datasheet);

							constantVariables.rowNum--;

							map_Metadata_clone.clear();// clearing the clone map
							map_Metadata_clone = (HashMap<String, String>) map_Metadata
									.clone();
							prevExecno = Integer.parseInt(Exec_No_Datasheet);

						} else {

							executeCloneMapData(Exec_No_Datasheet,
									expectedValue_Datasheet);

							System.out.println("Clearing clone Map!!!!");
							map_Metadata_clone.clear();
							map_Metadata_clone = (HashMap<String, String>) map_Metadata
									.clone();
						}

					} else {
						System.out.println("Execution Number Not Changed ");
						if (expectedValue_Datasheet != null
								&& (!expectedValue_Datasheet.trim().isEmpty())) {					
							executeMetadataMap(xpath_Datasheet,
									expectedValue_Datasheet);
						}
						prevExecno = Integer.parseInt(Exec_No_Datasheet);

					}
				} else {
					System.out.println("Execution Ended");
				}
			} catch (Exception e) {
				e.printStackTrace();

			}
		}

	}

	/*
	 * Below method is to validate the data present in the Data sheet against
	 * the data present in subscriber sheet and the PDF text
	 */
	private static void executeMetadataMap(String xpath_OfDatasheet,
			String expectedValue_Datasheet) throws IOException, Exception {
		try {
			/*
			 * Below condition is to enter inside if the map_metadata contains
			 * the keys
			 */
			if (map_Metadata.containsKey(xpath_OfDatasheet.trim() + "_top")) {
				
				System.out.println("type of parameter is "+map_Metadata.get(xpath_OfDatasheet.trim() + "_top"));
				/*
				 * Below condition is to enter inside if the parameter is
				 * Coordinate and to validate the data from data sheet against
				 * the data fetched from PDF using coordinates
				 */
				if (map_Metadata.get(xpath_OfDatasheet.trim() + "_top")
						.equalsIgnoreCase("Static")) {

					extractedText = pdfExtractor.getText(
							Integer.parseInt(map_Metadata.get(xpath_OfDatasheet
									.trim() + "_p1")),
							Integer.parseInt(map_Metadata.get(xpath_OfDatasheet
									.trim() + "_p2")),
							Integer.parseInt(map_Metadata.get(xpath_OfDatasheet
									.trim() + "_p3")),
							Integer.parseInt(map_Metadata.get(xpath_OfDatasheet
									.trim() + "_p4")));
					System.out.println("Extracted text is" + extractedText);

					result_xmlData = pdfExtractor.validateText(
							expectedValue_Datasheet.trim(), extractedText);
					if (result_xmlData)
					{

						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.actualValue_collNum_Datasheet,extractedText );
						
						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.result_collNum_Datasheet, "Pass");
					ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
							constantVariables.rowNum,
							constantVariables.resultDesc_collNum_Datasheet,
							"The expected value is  "+"\""+expectedValue_Datasheet.trim()+"\""+"\nThe actual value is "+ "\""+extractedText+"\"" + "\n XML Value is matched with PDF Value");
					}
					else {
						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.actualValue_collNum_Datasheet,extractedText );
						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.result_collNum_Datasheet, "Fail");
						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.resultDesc_collNum_Datasheet,
								"The expected value is  "+"\""+expectedValue_Datasheet.trim()+"\""+"\nThe actual value is "+ "\""+extractedText +"\""+ "\n XML Value is not matched with PDF Value");
					}
					/*
					 * Below condition is to enter inside if the type of
					 * parameter is Table and to validate the data from Data
					 * sheet against the data fetched from PDF
					 */

				} else if (map_Metadata.get(xpath_OfDatasheet.trim() + "_top")
						.equals("table")) {

					System.out.println("In Table validation!!!!!!!!!"
							+ xpath_OfDatasheet.trim());

					if (xpath_OfDatasheet
							.trim()
							.equals("//claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_charge_amt")) 
					{//if xpath in datasheet equls to xpath mentioned above, it will enter inside
						System.out
								.println("the xpath matches with amount billed xpath!!!");
						System.out.println("The expected value is "
								+ Float.parseFloat(expectedValue_Datasheet
										.trim()));

						

						if (Integer.parseInt(indexOfXpath) == 0) {
							constantVariables.totalAmountBilled = 0;
						}

						float expectedValue = Float.parseFloat(expectedValue_Datasheet.trim());
						constantVariables.totalAmountBilled = constantVariables.totalAmountBilled+ expectedValue;//calculating totalamount billed
						System.out
								.println("The totalAmount billed after calculation is "
										+ constantVariables.totalAmountBilled);
						result_xmlData = pdfExtractor
								.validateTextInPDF(expectedValue_Datasheet
										.trim()); //to check if the xml data is present in pdf

						
					} 
					else if (xpath_OfDatasheet
							.trim()
							.equals("//claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_provider_pmt_amt_print")) 
					{//if xpath in datasheet equls to xpath mentioned above, it will enter inside
						System.out
								.println("the xpath matches with amount we paid xpath!!!");
						System.out.println("the table name is !!!"
								+ map_Metadata.get(xpath_OfDatasheet.trim()
										+ "_p1"));
						System.out.println("the expected value si "
								+ expectedValue_Datasheet);

						if (Integer.parseInt(indexOfXpath) == 0) {
							constantVariables.totalAmountWePaid = 0;
						}

						float expectedValue = Float.parseFloat(expectedValue_Datasheet.trim());
						constantVariables.totalAmountWePaid = constantVariables.totalAmountWePaid+ expectedValue;//calculating totalamount we paid
						System.out.println("The totalAmount paid is "
								+ constantVariables.totalAmountWePaid);
						result_xmlData = pdfExtractor
								.validateTextInPDF(expectedValue_Datasheet
										.trim());//to check if the xml data is present in pdf

						
					} 
					else if (xpath_OfDatasheet
							.trim()
							.equals("//claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/additional_subscriber_service_info/noncovered_chrgs")) 
					{//if xpath in datasheet equls to xpath mentioned above, it will enter inside
						System.out
								.println("the xpath matches with non covered xpath!!!");
						System.out.println("the expected value si "
								+ expectedValue_Datasheet);
						if (Integer.parseInt(indexOfXpath) == 0) {
							constantVariables.totalNonCovered = 0;
						}

						float expectedValue = Float
								.parseFloat(expectedValue_Datasheet.trim());
						constantVariables.totalNonCovered = constantVariables.totalNonCovered+ expectedValue;//calculating total non covered
						System.out.println("The total Noncovered is"
								+ constantVariables.totalNonCovered);
						result_xmlData = pdfExtractor
								.validateTextInPDF(expectedValue_Datasheet
										.trim());

						
					} 
					else if (xpath_OfDatasheet
							.trim()
							.equals("//claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/deductible_amt")) 
					{
						System.out
								.println("the xpath matches with deductible xpath!!!");
						System.out.println("the table name is !!!"
								+ map_Metadata.get(xpath_OfDatasheet.trim()
										+ "_p1"));
						System.out.println("the expected value si "
								+ expectedValue_Datasheet);
						if (Integer.parseInt(indexOfXpath) == 0) {
							constantVariables.totalDeductibleAmount = 0;
						}
						float expectedValue = Float.parseFloat(expectedValue_Datasheet.trim());
						constantVariables.totalDeductibleAmount = constantVariables.totalDeductibleAmount+ expectedValue;//calculating total deductible amount
						System.out.println("The total deductibe is"
								+ constantVariables.totalDeductibleAmount);
						result_xmlData = pdfExtractor
								.validateTextInPDF(expectedValue_Datasheet
										.trim());

						
					} 
					else if (xpath_OfDatasheet
							.trim()
							.equals("//claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/copay_amt")) 
					{
						System.out
								.println("the xpath matches with copay xpath!!!");
						System.out.println("the table name is !!!"
								+ map_Metadata.get(xpath_OfDatasheet.trim()
										+ "_p1"));
						System.out.println("the expected value si "
								+ expectedValue_Datasheet);
						if (Integer.parseInt(indexOfXpath) == 0) {
							constantVariables.totalCopayAmount = 0;
						}
						float expectedValue = Float.parseFloat(expectedValue_Datasheet.trim());
						constantVariables.totalCopayAmount = constantVariables.totalCopayAmount+ expectedValue;//calculating total copay amount
						System.out.println("The total copay amount is "
								+ constantVariables.totalCopayAmount);
						result_xmlData = pdfExtractor
								.validateTextInPDF(expectedValue_Datasheet
										.trim());

						
					}

					if (result_xmlData)
					{
						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.actualValue_collNum_Datasheet,expectedValue_Datasheet.trim() );
						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.result_collNum_Datasheet, "Pass");
					ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
							constantVariables.rowNum,
							constantVariables.resultDesc_collNum_Datasheet,
							"The expected value   "+ "\""+expectedValue_Datasheet.trim()+"\"" + " is present in PDF ");
					}
					else {
						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.actualValue_collNum_Datasheet,"Value not found in PDF!!!" );
			
						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.result_collNum_Datasheet, "Fail");
						ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
								constantVariables.rowNum,
								constantVariables.resultDesc_collNum_Datasheet,
								"The expected value   "+ "\""+expectedValue_Datasheet.trim()+"\"" + " is not present in PDF ");
					}

				}
				/*
				 * Below conidtion is to put the result as Pass or Fail in Data
				 * sheet based on the result
				 */
				
				System.out.println("::::::::Set Results:::::::::: _"
						+ constantVariables.rowNum + "  |" + result_xmlData);

				map_Metadata_clone.remove(xpath_OfDatasheet.trim() + "_top");
				map_Metadata_clone.remove(xpath_OfDatasheet.trim() + "_p1");
				map_Metadata_clone.remove(xpath_OfDatasheet.trim() + "_p2");
				map_Metadata_clone.remove(xpath_OfDatasheet.trim() + "_p3");
				map_Metadata_clone.remove(xpath_OfDatasheet.trim() + "_p4");
				map_Metadata_clone.remove(xpath_OfDatasheet.trim() + "_ele");
				/*
				 * Below lines are to execute the data present in Data sheet
				 * when the xpath in Data sheet doesn't match with the xpath in
				 * subscriber sheet.
				 */
			} else {

				String[] expectedValueArray = expectedValue_Datasheet.trim()
						.split("\\s");

				for (String string : expectedValueArray) {
					result_xmlData = pdfExtractor.validateTextInPDF(string);

				}

				/*
				 * Below lines are to put the result in data sheet based on the
				 * result
				 */

				if (result_xmlData) {
					ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
							constantVariables.rowNum,
							constantVariables.actualValue_collNum_Datasheet,expectedValue_Datasheet.trim() );
					ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
							constantVariables.rowNum,
							constantVariables.result_collNum_Datasheet, "Pass");
					ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
							constantVariables.rowNum,
							constantVariables.resultDesc_collNum_Datasheet,
							"The XML value "+ "\""+expectedValue_Datasheet.trim()+"\""+ " is  present in PDF ");
				} else {
					ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
							constantVariables.rowNum,
							constantVariables.actualValue_collNum_Datasheet,"Value not found in PDF!!!" );
					ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
							constantVariables.rowNum,
							constantVariables.result_collNum_Datasheet, "Fail");
					ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
							constantVariables.rowNum,
							constantVariables.resultDesc_collNum_Datasheet,
							"The XML Value "+"\""+ expectedValue_Datasheet.trim()+"\""
									+ " is not present in PDF ");
				}
				System.out
						.println("::::::::Set Results for Xpath Not found:::::::::: _"
								+ constantVariables.rowNum + "  |" + result_xmlData);

			}
		} catch (Exception e) {

			e.printStackTrace();

			ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
					constantVariables.rowNum, constantVariables.result_collNum_Datasheet,
					"Fail");
			ExcelUtilities.setCellData(constantVariables.sheetName_Datasheet,
					constantVariables.rowNum, constantVariables.resultDesc_collNum_Datasheet,
					e.getMessage());

		}

	}

	/*
	 * Below method is to validate the static data which is present in the
	 * subscriber sheet and to insert the static data in Data sheet along with
	 * the result.
	 */
	private static void executeCloneMapData(String Exec_No_Datasheet,
			String expectedValue_Datasheet) throws RuntimeException,
			IOException, Exception {
		/*
		 * Below condition is to enter inside and validate the data in data
		 * sheet if it is the last row in Data sheet
		 */
		if (ExcelUtilities.isLastRow(constantVariables.rowNum,
				constantVariables.sheetName_Datasheet)
				&& expectedValue_Datasheet != null
				&& (!expectedValue_Datasheet.trim().isEmpty())) {
			System.out.println("The Xpath in clone Map is !!!!!!!"
					+ xpath_Datasheet);
			executeMetadataMap(xpath_Datasheet, expectedValue_Datasheet);

		}

		System.out.println("In clone Map!!!   row no is  " + constantVariables.rowNum);

		/*
		 * Below loop is to iterate among the keys which contains _top and
		 * extract the data from PDF using coordinates Validating the data
		 * against the static data present in the subscriber sheet
		 */
		for (String key_xpath : map_Metadata_clone.keySet()) {
			System.out.println("The keyset at row num !!!!" + constantVariables.rowNum
					+ key_xpath);

			if (key_xpath.contains("_top") && (!key_xpath.contains("/"))) {
				String key = key_xpath.trim().substring(0,
						(key_xpath.trim().length() - 4));
				System.out.println("The keys in Key map are" + key);
				/*
				 * Below method is to extract the data from PDF by sending
				 * coordinates
				 */

				if (key.equals("totalAmountBilled")) 
				{

					map_Metadata.put(key + "_ele",
							String.valueOf(constantVariables.totalAmountBilled));
					result_xmlData_static = pdfExtractor.tablevalidation(
							constantVariables.totalAmountBilled,
							map_Metadata.get(key + "_p2"),
							map_Metadata.get(key + "_p1"));//this is to validate the calculated amount with data in pdf
					
					executeResult(String.valueOf(constantVariables.totalAmountBilled),key);
					
				} 
				else if (key.equals("totalAmountWePaid")) 
				{
					map_Metadata.put(key + "_ele",
							String.valueOf(constantVariables.totalAmountWePaid));
					result_xmlData_static = pdfExtractor.tablevalidation(
							constantVariables.totalAmountWePaid,
							map_Metadata.get(key + "_p2"),
							map_Metadata.get(key + "_p1"));//this is to validate the calculated amount with data in pdf
					executeResult(String.valueOf(constantVariables.totalAmountWePaid),key);
				} 
				else if (key.equals("totalNonCovered")) 
				{

					map_Metadata.put(key + "_ele",
							String.valueOf(constantVariables.totalNonCovered));
					result_xmlData_static = pdfExtractor.tablevalidation(
							constantVariables.totalNonCovered,
							map_Metadata.get(key + "_p2"),
							map_Metadata.get(key + "_p1"));//this is to validate the calculated amount with data in pdf
					executeResult(String.valueOf(constantVariables.totalNonCovered),key);
				} 
				else if (key.equals("totalDeductibleAmount")) 
				{
					map_Metadata.put(key + "_ele",
							String.valueOf(constantVariables.totalDeductibleAmount));
					result_xmlData_static = pdfExtractor.tablevalidation(
							constantVariables.totalDeductibleAmount,
							map_Metadata.get(key + "_p2"),
							map_Metadata.get(key + "_p1"));
					executeResult(String.valueOf(constantVariables.totalDeductibleAmount),key);
				} 
				else if (key.equals("totalCopayAmount")) 
				{

					map_Metadata.put(key + "_ele",
							String.valueOf(constantVariables.totalCopayAmount));
					result_xmlData_static = pdfExtractor.tablevalidation(
							constantVariables.totalCopayAmount,
							map_Metadata.get(key + "_p2"),
							map_Metadata.get(key + "_p1"));//this is to validate the calculated amount with data in pdf
					executeResult(String.valueOf(constantVariables.totalCopayAmount),key);
				} 
				else {
					extractedText = pdfExtractor.getText(
							Integer.parseInt(map_Metadata.get(key + "_p1")),
							Integer.parseInt(map_Metadata.get(key + "_p2")),
							Integer.parseInt(map_Metadata.get(key + "_p3")),
							Integer.parseInt(map_Metadata.get(key + "_p4")));

					String[] expectedValueArray = map_Metadata
							.get(key + "_ele").trim().split("\\s");

					for (String string : expectedValueArray) {
						result_xmlData_static = pdfExtractor.compareText(string,
								extractedText.trim());
						executeResult(extractedText.trim(),key);
					}
				}
				/*
				 * Below Map is to store the column numbers and values inside
				 * the Map
				 */
			
				try {

					if (ExcelUtilities.isLastRow(constantVariables.rowNum,
							constantVariables.sheetName_Datasheet)) {

						collNumCellValueMap.put(
								constantVariables.execNo_collNum_Datasheet, String
										.valueOf(Integer
												.parseInt(Exec_No_Datasheet)));
					} else {
						collNumCellValueMap.put(
								constantVariables.execNo_collNum_Datasheet,
								String.valueOf(Integer
										.parseInt(Exec_No_Datasheet) - 1));
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				collNumCellValueMap.put(
						constantVariables.elementName_collNum_Datasheet, key);
				collNumCellValueMap.put(
						constantVariables.expectedValue_collNum_Datasheet,
						map_Metadata.get(key + "_ele"));
				
				
				
				/*
				 * Below method is to create or shift the rows in Data sheet
				 */

				ExcelUtilities.CreateRowAndCell(constantVariables.sheetName_Datasheet,
						constantVariables.rowNum, collNumCellValueMap);
				++constantVariables.rowNum;

			}

		}

		constantVariables.rowCount_sheetName_Datasheet = ExcelUtilities
				.getRowCount(constantVariables.sheetName_Datasheet);
	}
	
	

	

	private static void executeResult(String actualResult, String keyValue) {
		
		if (result_xmlData_static) {
			collNumCellValueMap.put(constantVariables.actualValue_collNum_Datasheet,
					actualResult);
			collNumCellValueMap.put(constantVariables.result_collNum_Datasheet,
					"Pass");
			collNumCellValueMap.put(
					constantVariables.resultDesc_collNum_Datasheet,
					"The Xml Value "+ "\""+map_Metadata.get(keyValue + "_ele")+"\""
							+ " is  present in PDF " );
		} else {
			collNumCellValueMap.put(constantVariables.actualValue_collNum_Datasheet,
					"Value is not found in PDF!!!");
			collNumCellValueMap.put(constantVariables.result_collNum_Datasheet,
					"Fail");
			collNumCellValueMap.put(
					constantVariables.resultDesc_collNum_Datasheet,
					"The Xml Value "+ "\""+map_Metadata.get(keyValue + "_ele")+"\""
							+ " is present in PDF " );
		}
		
	}

	/*
	 * Below method will retrieve the data from input sheet and then store the
	 * claimId in the datasheet that clainID will be using for retrieving the
	 * xml data from DB
	 */
	public static void retrieveInputData() throws Exception {
		try {

			map_Input = new HashMap<String, String>();
			int colNum_ExecNo = 0;
			int colNum_EOB = 1;
			int colNum_PdfPath = 4;
			int colNum_xmlPath = 3;
			int colNum_Id = 2;
			int row = ExcelUtilities.getRowCount(constantVariables.sheetname_Input);
			
			System.out.println("#######################   " + row
					+ "############");
			for (int row_num = 1; row_num <= row; row_num++) {
				String execNo = ExcelUtilities.getCellValue(
						constantVariables.sheetname_Input, row_num, colNum_ExecNo);
				
				String eob = ExcelUtilities.getCellValue(
						constantVariables.sheetname_Input, row_num, colNum_EOB);
				String pdfPath = ExcelUtilities.getCellValue(
				
						constantVariables.sheetname_Input, row_num, colNum_PdfPath);
				String xmlPath =  ExcelUtilities.getCellValue(
						constantVariables.sheetname_Input, row_num, colNum_xmlPath);
				String id = ExcelUtilities.getCellValue(
						constantVariables.sheetname_Input, row_num, colNum_Id);
				System.out.println("The subscriber id is "+ id);

				map_Input.put(execNo + "_pdf", pdfPath);
				map_Input.put(execNo + "_EOB", eob);
				map_Input.put(execNo + "_xml", xmlPath);
				map_Input.put(execNo + "_id", id);
				
				XMLParse.xmlSetup(map_Input.get(execNo + "_xml"));
				XMLParse.nodeExtraction(map_Input.get(execNo + "_id"),execNo,constantVariables.sheetName_Datasheet);
				
				String fileName = new File(map_Input.get(execNo + "_pdf")).getName();
				String pdfFile = fileName.substring(0, fileName.length()-4);
				
				ExcelUtilities.copyPdf(new File(map_Input.get(execNo + "_pdf")), new File("test-output\\BSC-reports\\"+constantVariables.timestamp+"\\"+pdfFile+"_"+row_num+".pdf"));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
