package com.bsc.qa.PCPNotification.XmlToPdfValidator;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ConstantVariables {
	public   String path = "src\\test\\resources\\target\\Data_Sheet.xlsx";
	public   int rowNum = 1;
	public   int lastRowNumber;
	public   int rowCount_sheetName_Datasheet;
	public   int RowNumber;
	public   int RowNumber1;
	public   int lastRowNumber1;
	public   int xpath_collNum_EOB = 1;
	public   int typeOfParameter_collNum = 2;
	public   int parameter1_collNum = 3;
	public   int parameter2_collNum = 4;
	public   int parameter3_collNum = 5;
	public   int parameter4_collNum = 6;
	public   int element_collNum = 0;
	public   int xpath_collNum_Datasheet = 2;
	public   int index_collNum_Datasheet = 4;
	public   int expectedValue_collNum_Datasheet = 3;
	public   int result_collNum_Datasheet = 5;
	public   int resultDesc_collNum_Datasheet = 6;
	public   int actualValue_collNum_Datasheet = 4;
	public   int execNo_collNum_Datasheet = 0;
	public   int elementName_collNum_Datasheet = 1;
	public   float totalAmountBilled = (float) 0.00;
	public   float totalAmountWePaid = (float) 0.00;
	public   float totalNonCovered = (float) 0.00;
	public   float totalCopayAmount = (float) 0.00;
	public   float totalDeductibleAmount = (float) 0.00;
	public   String sheetName_Datasheet = "Datasheet";
	public   String sheetname_Input = "Input";
	public   String path_BatFile = "Utilities\\UFTLaunch.bat";
	public   File sourceFile = new File(path);
	public static  String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss"));
	public   File destinationFile = Paths.get("test-output\\BSC-reports\\"+timestamp+"\\Data_Sheet_" + timestamp + ".xlsx").toFile();
	public   File sourceDatasheet = new File("src\\test\\resources\\Input\\Data_Sheet.xlsx"); 
	public   File destinationDatasheet = new File(path);
	public   File sourceHtmlReport = new File("test-output\\BSC-reports\\Report.html");  
	 
}
