package com.bsc.qa.PCPNotification.XmlToPdfValidator;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

public class EffortSavings {
	
	public String toolName;
	public String toolType;
	public String totalRecords;
	public long manualEffort;
	public String date;
	public String userName;
	
	
	public EffortSavings(String toolname,String tooltype,String totalrecords,int manualeffort,String username)
	{
		this.toolName = toolname;
		this.toolType = tooltype;
		this.totalRecords = totalrecords;
		this.manualEffort = manualeffort;
		this.userName = username;
		System.out.println("In constructor!!!");
		DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE;
		this.date = LocalDate.now().format(formatter);
	}
	
	public void updateEfforts(long executionTime) throws Exception{
		
		int colNum_SerialNo = 0;
		int colNum_ToolName = 1;
		int colNum_ToolType = 2;
		int colNum_date = 3;
		int colNum_RecordsExecuted = 4;
		int colNum_ExecTime = 5;
		int colNum_ManualEffort = 6;
		int colNum_EffortSavedsecs = 7;
		int colNum_EffortSavedmins = 8;
		int colNum_EffortSavedhrs = 9;
		int colNum_UserName = 10;
		
		long manualeffort = Long.valueOf(manualEffort);
		
		long effortSavedSecs = manualeffort-executionTime ;
		long effortSavedmins = effortSavedSecs/60;
		long effortSavedhrs = effortSavedmins/60 ;
		
		System.out.println("The effortsavedseconds are "+effortSavedSecs);
		
		ExcelUtilities.setUpExcel("\\\\bsc\\sa\\QA Test\\Infosys\\Tools effort savings capture\\Effort savings capture for java based tools .xlsx");
		
		HashMap<Integer, String> collNumCellValueMap = new HashMap<Integer, String>();
		
		int rowNumber = ExcelUtilities.getRowCount("Exec_Report");
		
		collNumCellValueMap.put(colNum_SerialNo, String.valueOf(rowNumber-3));
		
		collNumCellValueMap.put(colNum_ToolName, toolName);
		
		collNumCellValueMap.put(colNum_ToolType, toolType);
		
		collNumCellValueMap.put(colNum_date, date);
		
		collNumCellValueMap.put(colNum_RecordsExecuted, totalRecords);
		
		collNumCellValueMap.put(colNum_ExecTime, String.valueOf(executionTime));
		
		collNumCellValueMap.put(colNum_ManualEffort, String.valueOf(manualeffort));
		
		collNumCellValueMap.put(colNum_EffortSavedsecs, String.valueOf(effortSavedSecs));
		collNumCellValueMap.put(colNum_EffortSavedmins, String.valueOf(effortSavedmins));
		collNumCellValueMap.put(colNum_EffortSavedhrs, String.valueOf(effortSavedhrs));
		collNumCellValueMap.put(colNum_UserName, userName);
		
		
		
		ExcelUtilities.CreateRowAndCell("Exec_Report",
				rowNumber-1, collNumCellValueMap);
		
		ExcelUtilities.writeToWorkBook("\\\\bsc\\sa\\QA Test\\Infosys\\Tools effort savings capture\\Effort savings capture for java based tools .xlsx");
		
		ExcelUtilities.closefile();
		
		
		
	}
	

}
