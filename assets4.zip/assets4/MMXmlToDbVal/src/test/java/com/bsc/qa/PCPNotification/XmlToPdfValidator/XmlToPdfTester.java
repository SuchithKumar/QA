package com.bsc.qa.PCPNotification.XmlToPdfValidator;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.PCPNotification.XmlToPdfValidator.ExcelUtilities;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.pdfExtractor;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.ConstantVariables;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.drivercode;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.XMLParse;
import com.relevantcodes.extentreports.LogStatus;

public class XmlToPdfTester  {

	public static Process process;
	public static String xmlName;
	public static String pdfName;
	public static String xmlFilePath;
	public static String pdfFilePath;
	public static String[] pdfId;
	public static int execNo = 1;
	public long startTime;
	public EffortSavings effortSaved;
	ConstantVariables constantVariables = new ConstantVariables();
	// This method is to retrieve the xml data using UFT script
	@BeforeClass
	
	public void xmlDataRetrieve() throws IOException, InterruptedException {
		
		
		Path path = Paths.get("test-output\\BSC-reports\\"+constantVariables.timestamp);
		if(!Files.exists(path))
		{
		Files.createDirectories(path);
		}
		ExcelUtilities.copyFile(constantVariables.sourceDatasheet,
				constantVariables.destinationDatasheet);		
		
		
	}

	// This method is to setup the excelfile and retrieve data from Input and
	// Subscriber sheet
	@BeforeMethod
	@Parameters({"folderPath","targetSheetName","tagName","toolName","toolType","noofRecords","manualEffort"})
	public void Setup(String folderPath,String sheetName,String tagName,String toolName, String toolType,String noofReords,int manualEffort ) throws Exception {
			
		 
		 String userName = System.getProperty("user.name");
		 
		  effortSaved = new EffortSavings(toolName,toolType,noofReords,manualEffort,userName);
		 
		 startTime = System.currentTimeMillis();
		 
		 startTime = startTime/60;
		 
		 System.out.println("The start time is "+startTime);
		
		
			ExcelUtilities.setUpExcel(); // Set up the Excel file
			// Below method is for retrieving the data from Input sheet.
			updateInputSheet(folderPath,sheetName,tagName);//To update input sheet with pdfpath nd xmlpath
			drivercode.retrieveInputData();
			// Below method is for retrieving the data from Subscriber sheet
			drivercode
					.retrieveDataFromMetaData_Sheet("PCPNotification");

	}
	
	
	
	/*
	 * Below sheet is to update the input
	 * sheet with execNo,id,type of Eob,pdfpath and xml path
	 */
	private void updateInputSheet(String folderPath, String sheetName, String tagName) {
		
		ArrayList<String> idList = new ArrayList<String>();//To store the sub/calim id extracted from xml
		
		Map<List,String> fileMap = new HashMap<List,String>();//Map to fetch the file name
		
		int colNum_ExecNo = 0;
		int colNum_EOB = 1;
		int colNum_PdfPath = 4;
		int colNum_xmlPath = 3;
		int colNum_Id = 2;
		HashMap<Integer, String> collNumCellValueMap = new HashMap<Integer, String>();//Map to update the inputsheet in particular columns
		
		File folder = new File(folderPath);
		
		
		
		File[] files = folder.listFiles();//fetching no list of files from folder
		
		
		
		for(int fileIndex = 0;fileIndex<files.length;fileIndex++) {
			
			if(files[fileIndex].isDirectory()){
				String path = files[fileIndex].getPath();
				updateInputSheet(path,sheetName,tagName);
			}
			
			String fileName = files[fileIndex].getName();//fetching file name
			
			System.out.println("The file name is "+fileName);
			/*
			 * Below conditions  are to know the type of file 
			 */
			if(fileName.contains(".xml"))
			
			{
				
				//xmlName = files[fileIndex].getName();
				 xmlFilePath = files[fileIndex].getAbsolutePath();// extracting filepath
				System.out.println("The xml path ios "+xmlFilePath);
				
				XMLParse.xmlSetup(xmlFilePath);
				
				if(idList != null){
					idList.clear();
				}
				
				idList= XMLParse.attributeValue(tagName);//Fetching sub/claim id from sheet
				
				System.out.println("The list of subscriber id are !!!"+ idList);
				
				fileMap.put(idList, xmlFilePath);//Creating map with key as list of ids and value as xmlPath
				
			}
			else if(fileName.contains(".pdf")){
				pdfName = files[fileIndex].getName();
				
				pdfFilePath = files[fileIndex].getPath();
				System.out.println("The pdf path is "+pdfFilePath);
				String pdfFileName = pdfName.substring(0, pdfName.length()-4);
				
				System.out.println("The trimmed file name is !!!"+pdfFileName);
				
				
				pdfId = pdfFileName.split("-");
				
				System.out.println("The pdf Id is "+pdfId[1]);
				
				for ( List key : fileMap.keySet() ) {
				    if(key.contains(pdfId[1])){
				    	
				    	System.out.println("writing pdf and xml path into datasheet!!!!");
				    	collNumCellValueMap.put(colNum_ExecNo, String.valueOf(execNo));
				    	collNumCellValueMap.put(colNum_EOB, pdfId[0]);
				    	collNumCellValueMap.put(colNum_PdfPath, pdfFilePath);
				    	collNumCellValueMap.put(colNum_xmlPath, fileMap.get(key));
				    	collNumCellValueMap.put(colNum_Id, pdfId[1]);
				    
				    	ExcelUtilities.CreateRowAndCell(sheetName,
				    			execNo-1, collNumCellValueMap);
				    	
				    	++execNo;
						System.out.println("The execution number is!!!! "+execNo);
					}
				    else{
				    	System.out.println("pdf subscriber id doesn't match with xml subscriber id!!!");
				    }
		    	
				    }
				
			}
			
		}
		
		
	}

	

	// This method is to compare the XML data with PDF data
	@Test
	public void compareXmlToPdf() throws Exception, IOException, Throwable {
		drivercode.retrieveDataFromDatasheet();
		//ExcelUtilities.writeToWorkBook();
		//System.out.println("Executing the Framework!!!");

	}

	// This method is to set the results in Excel
	@AfterMethod
	public void setResults() throws Exception {
		System.out.println("In After Method");
		ExcelUtilities.writeToWorkBook();
		ExcelUtilities
				.copyFile(constantVariables.sourceFile, constantVariables.destinationFile);
		//ExcelUtilities.copyFile(Constants.sourceHtmlReport, new File("test-output\\BSC-reports\\"+Constants.timestamp+"\\Report.html"));
		ExcelUtilities.copyFile(new File("test-output\\emailable-report.html"), new File("test-output\\BSC-reports\\"+constantVariables.timestamp+"\\emailable-report.html"));
		ExcelUtilities.closefile();
		long endTime = System.currentTimeMillis();
		endTime = endTime/60; 
		System.out.println("The end time is "+endTime);
		long executionTime = endTime- startTime;
		
		effortSaved.updateEfforts(executionTime);
	}

	// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ALWAYS
	// KEEP AS
	// FOOTER%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	// Required method for every test Class for reporter to operate properly
	/**
	 * @Override run is a hook before @Test method
	 */
	

	// This method is to close the PDF and excel
	@AfterClass
	public void closeFiles() throws Exception {
		pdfExtractor.closefile();
		
		
		
		
		
	}

	// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ALWAYS
	// KEEP AS
	// FOOTER%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

} // Class
