package com.bsc.qa.webservices.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.bsc.qa.framework.utility.DBUtils;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

import org.apache.commons.lang3.StringUtils;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import com.relevantcodes.extentreports.LogStatus;

public class DBPInboundFileUtility extends BaseTest{
	/**DBPInboundFile creates text file of DBP vendor as per the mapping sheet
	 * @param: test data sheet path
	 * @return output file
	 */
 
public File createDBPInboundFile(String testDataPath){
	 File outputFile=null;
		DBUtils dbUtils = new DBUtils();
		ExcelUtilsExtended excelUtils;
		CommonInboundFileUtility inboundFileUtils= new CommonInboundFileUtility();
		Date todaysDate = new Date();
		DateFormat dateFormat_Header = new SimpleDateFormat("yyyyMMdd");;
		DateFormat dateFormat_detailRecord;
		String date_Header = dateFormat_Header.format(todaysDate);;
		String currentDate_detailRecord;
		Double totalAccumAmount = 0.00;
		Long totalRecords = 0L;
		FileWriter outputFileWriter = null;
		BufferedWriter outputFileBufferedWriter;
		String sbsb_id,mbr_sfx,benifit_year,dateOfService,networkInd,accumulatorType,accumAmount,fieldName="",outputFilePath;
		int startPosition,endPosition,defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0,fieldLength=0;
		dateFormat_detailRecord = new SimpleDateFormat("dd-MMM-YYYY");
		currentDate_detailRecord = dateFormat_detailRecord.format(todaysDate);
		
		//To create .txt output file
		String dateFormat_DBPfileNameFormat = inboundFileUtils.DBP_NAVITUSFileFormatDate();
		outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\UHCSB_ACCUMS_TO_BSCA_"+dateFormat_DBPfileNameFormat+".txt";
		outputFile = new File(outputFilePath);
		
		//Initialize writer
		 try {
			 outputFileWriter = new FileWriter(outputFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 outputFileBufferedWriter = new BufferedWriter(outputFileWriter);
		 
		 String mappingSheet = "src//test//resources//VendorAccumInboundFileCreationTest.xlsx";

	try{
		//write header
		String DBPHeader="";
		//retrieve mapping sheet
		excelUtils = new ExcelUtilsExtended(mappingSheet,"DBP_MappingSheet");
		//To iterate through header fields in the mapping sheet
		for(int mappingSheetIterator=1;mappingSheetIterator<=4;mappingSheetIterator++)
		{
			//Retrieve start and end positions of the each header field
			startPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, startPositionColumn));
			endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, endPositionColumn));
			String defaultValue = excelUtils.getCellData(mappingSheetIterator, defaultValueColumn);
			//append the header with field's default from the mapping sheet if any
			if(!defaultValue.equals(""))
				DBPHeader = DBPHeader+inboundFileUtils.addField(defaultValue,startPosition,endPosition);
			else
			{
				if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("FILE_DATE"))
				{
					dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
					date_Header = dateFormat_Header.format(todaysDate);
					DBPHeader = DBPHeader+inboundFileUtils.addField(date_Header,startPosition,endPosition);	
				}
				else
					DBPHeader = DBPHeader+StringUtils.rightPad("", fieldLength, " ");
			}
		}
		//write header to the output file
		outputFileBufferedWriter.write(DBPHeader);
		//enter new line after the header in the output file as per file layout
		outputFileBufferedWriter.newLine();

		//Write detail record
			
		//retrieve queries from queries sheet			
		 	excelUtils = new ExcelUtilsExtended(mappingSheet,"DBP_Queries");
		 //Fetch queries from the queries sheet
		 	Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
		 //Retrieve test data sheet
			 excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
		//To get subscriber count from the test data sheet
			 int testdataCount = excelUtils.getRowCount(null);
		//To iterate through each subscriber in the input data sheet
			for(int testDataSheetIterator=1;testDataSheetIterator<=testdataCount;testDataSheetIterator++)
			{
				sbsb_id=excelUtils.getCellData(testDataSheetIterator, 0);
				mbr_sfx = excelUtils.getCellData(testDataSheetIterator, 1);
				benifit_year = excelUtils.getCellData(testDataSheetIterator, 2);
				dateOfService = excelUtils.getCellData(testDataSheetIterator, 3);
				networkInd = excelUtils.getCellData(testDataSheetIterator, 4);
				accumulatorType = excelUtils.getCellData(testDataSheetIterator, 5);
				accumAmount = excelUtils.getCellData(testDataSheetIterator, 6);
			//replace the sub strings in queries with subscriber data
				Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, benifit_year, currentDate_detailRecord);
			//Retrieve subscribers details from database	
				ResultSet groupID = dbUtils.getResultSet("facets",replacedQueries.get("0"));
				ResultSet gender = dbUtils.getResultSet("facets",replacedQueries.get("1"));
				ResultSet memberLName = dbUtils.getResultSet("facets",replacedQueries.get("2"));
				ResultSet memberFName = dbUtils.getResultSet("facets",replacedQueries.get("3"));
				ResultSet member_MInitial = dbUtils.getResultSet("facets",replacedQueries.get("4"));
				ResultSet memberDOB = dbUtils.getResultSet("facets",replacedQueries.get("5"));
				ResultSet planCode = dbUtils.getResultSet("facets",replacedQueries.get("6"));
				OtherUtilities otherUtilities = new OtherUtilities();
				int subscriberCount=0;
				String detailRecord="";
			
				//In case if more than one group id exist for the same subscriber id, create record for both
				try {
					while(groupID.next() && gender.next() && memberLName.next() && memberFName.next() && member_MInitial.next() && memberDOB.next() && planCode.next())	
					{
						//To increment the count if subscriber data is present in Facets
						subscriberCount++;
						for(int mappingSheetIterator=5;mappingSheetIterator<=29;mappingSheetIterator++)
						{
						//To retrieve mapping sheet based on the vendor name present in input test data sheet
							excelUtils = new ExcelUtilsExtended(mappingSheet,"DBP_MappingSheet");
						//retrieve field names, start position and end position from mapping sheet
							startPosition=Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, startPositionColumn));
							endPosition=Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, endPositionColumn));
						if(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals(""))
						{
							//Retrieve the field name of detail record and place the value in the output file
							fieldName = excelUtils.getCellData(mappingSheetIterator,fieldNameColumn);
							switch (fieldName){
							case "GROUP_ID":
						 	detailRecord=detailRecord+inboundFileUtils.addField(groupID.getString(1),startPosition,endPosition);
						 	break;
							case "MEMBER_IDENTIFICATION_NUMBER":
							case "SUBSCRIBER_NUMBER":
						 		detailRecord=detailRecord+inboundFileUtils.addField(sbsb_id,startPosition,endPosition);
						 	break;
							case "RELATIONSHIP_CODE":
								 
							 if(mbr_sfx.equals("0")||mbr_sfx.equals("1")||mbr_sfx.equals("2")||mbr_sfx.equals("3")||mbr_sfx.equals("4")||mbr_sfx.equals("5")||mbr_sfx.equals("6")||mbr_sfx.equals("7")||mbr_sfx.equals("8")||mbr_sfx.equals("9"))
							 {
									mbr_sfx = String.format('0'+mbr_sfx);
									detailRecord=detailRecord+inboundFileUtils.addField(mbr_sfx,startPosition,endPosition);
								 }
							 else
							 detailRecord=detailRecord+mbr_sfx;
								 break;
							case "GENDER":
							 detailRecord=detailRecord+inboundFileUtils.addField(gender.getString(1),startPosition,endPosition);
							 break;
							case "MEMBER_LAST_NAME":
							 detailRecord = detailRecord+inboundFileUtils.addField(memberLName.getString(1),startPosition,endPosition);
							 break;
							case "MEMBER_FIRST_NAME":
							 detailRecord = detailRecord+inboundFileUtils.addField(memberFName.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_MIDDLE_INIT":
							 detailRecord = detailRecord+inboundFileUtils.addField(member_MInitial.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_DOB":
							 detailRecord = detailRecord+inboundFileUtils.addField(memberDOB.getString(1),startPosition,endPosition);
							 break;
							case "CLAIM_REFERENCE_NUMBER":
							 detailRecord=detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
							break;
							case "DATE_OF_SERVICE":
							 detailRecord = detailRecord+inboundFileUtils.addField(dateOfService,startPosition,endPosition);
							 break;
							case "INPATIENT_OUTPATIENT":
							 detailRecord = detailRecord+inboundFileUtils.addField("1",startPosition,endPosition);
							 break;
							case "BENEFIT_LEVEL":
							 detailRecord = detailRecord+inboundFileUtils.addField(networkInd,startPosition,endPosition);
							 break;
							case "PLAN_CODE":
							 detailRecord = detailRecord+inboundFileUtils.addField(planCode.getString(1),startPosition,endPosition);
							 break;
							case "BENEFIT_CATEGORY":
							case "POLICY_HOLDER_ID": 
							case "BILLED_AMT":
							case "ALLOWED_AMT": 
							case "NOT_COVERED_AMT":
							case "NET_AMT":
							case "FILLER":
							 detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
							break;
							case "ACCUMULATOR TYPE":
							 detailRecord = detailRecord+inboundFileUtils.addField(accumulatorType,startPosition,endPosition);
							 break;
							case "ACCUMULATOR_AMT":
							 if(accumAmount.contains("."))
								{
									accumAmount=accumAmount.replace(".", "");
									accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
								}
								else if(accumAmount.equals("0"))
								{
									accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
								}
								else
								{
									accumAmount=accumAmount+"00";
									accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
								}
							 detailRecord=detailRecord+accumAmount;
						 break;
							case "BENEFIT_YEAR":
							 detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
							break;
						}
						}
						 else
							 detailRecord = detailRecord+excelUtils.getCellData(mappingSheetIterator,defaultValueColumn);

						}
//To write detail record of subscriber in the output file
						outputFileBufferedWriter.write(detailRecord);
//To enter the next line after each subscriber detail record as per the file layout
					outputFileBufferedWriter.newLine();
					excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
					totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(testDataSheetIterator, 6));
					//To calculate total accumulator amount and total records
					totalRecords = totalRecords+1;
					detailRecord="";
					sbsb_id = excelUtils.getCellData(testDataSheetIterator, 0);
					mbr_sfx = excelUtils.getCellData(testDataSheetIterator, 1);
					accumAmount = excelUtils.getCellData(testDataSheetIterator, 6);
}
				} catch (NumberFormatException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//check the subscriber is present in facets, else report error
				if(subscriberCount==0)
				{
					System.out.println("Mandatory field is missing or incorrect test data for row number: "+testDataSheetIterator+" in test data sheet"+testDataPath);
					logger.log(LogStatus.ERROR, "Incorrect test data/Incorrect input mandatory fields: "+ sbsb_id );
					//System.out.println("fail");
				}
				else
				{
					logger.log(LogStatus.INFO, "Subscriber data inserted: "+ sbsb_id );
				}
			}
			
			//Write Trailer
			//To iterate through each trailer field
			String trailer="";
			for(int mappingSheetIterator=30;mappingSheetIterator<=34;mappingSheetIterator++)
			{
				excelUtils=new ExcelUtilsExtended(mappingSheet,"DBP_mappingSheet");
				//To retrieve start and end positions of each field
				startPosition=Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, endPositionColumn));
				//To append field values to the trailer except for the default value fields
				if(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals(""))
				{
					if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("TOTAL_RECORDS"))
					
						trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
					
					else if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("TOTAL_AMOUNT"))
					{
						DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
						String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
						if(totalAccumAmount_trailer.contains("."))
						{
							totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
						}
						trailer=trailer+String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer));		
					}
					else if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("FILLER"))
						trailer=trailer+inboundFileUtils.addField("", startPosition,endPosition);
				}
				//append default values to the trailer string
				else
					trailer=trailer+inboundFileUtils.addField(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn),startPosition,endPosition);
			}
			//write trailer to the output file
			outputFileBufferedWriter.write(trailer);
			outputFileBufferedWriter.newLine();
			//close writer
				outputFileBufferedWriter.close();
			outputFileWriter.close();	
			
			//report the total number of records and input file used
			logger.log(LogStatus.INFO, "Total number of records inserted: "+ totalRecords );
			logger.log(LogStatus.INFO, "Input data sheet used: "+ testDataPath );
			}
				
			catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return outputFile;
}


 


 public static String generateFiller(int length)
 {
 	String filler = String.format("%-" + length + "s"," ");
 	return filler;
 }
 }
 

