package com.bsc.qa.webservices.utility;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import org.apache.commons.lang3.StringUtils;


public class CommonInboundFileUtility {
	/**fetchQueriesFromQueriesSheet retrieves queries from queries sheet and returns as MAP
	 * @param queries work sheet
	 * @return Map of queries
	 */
	
	public Map<String,String> fetchQueriesFromQueriesSheet(ExcelUtilsExtended queriesSheet)
	{
		Map<String, String> table = null;
		
		int rowCount = queriesSheet.getRowCount(null);
		table = new HashMap<String, String>();
		try
		{
		for(int i=0;i<=rowCount;i++)
		{
			String key = String.valueOf(i);
			String value = queriesSheet.getCellData(i, 0);
			if(value!="")
				table.put(key,value);
			else
				throw new Exception("No query found");
		}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		
		
	}
		return table;
	}
	
	/**replaceQueries replaces sub strings in queries from queries sheet with test data
	 * @param: Map of queries,
	 * @param: subscriber ID
	 * @param: member suffix
	 * @param: benifit year
	 * @param: system date
	 * @return Map of replaced queries
	 */
	public Map<String,String> replaceQueries(Map<String,String> queries,String strSBSB_ID,String strMbr_sfx,String strBenifitYear,String strSystemdate)
	{
		Map<String, String> table = null;
		int count=queries.size();
		table = new HashMap<String, String>();
		for(int i=0;i<count;i++)
		{
			String key = String.valueOf(i);
			String value ="";
			if(queries.get(String.valueOf(i)).contains("SBSB_ID") && queries.get(String.valueOf(i)).contains("MBR_SFX") && queries.get(String.valueOf(i)).contains("YYYY") && queries.get(String.valueOf(i)).contains("sysdate"))
			{
			 value = queries.get(String.valueOf(i)).replaceAll("SBSB_ID", strSBSB_ID).replaceAll("MBR_SFX", strMbr_sfx).replaceAll("YYYY", strBenifitYear).replaceAll("sysdate", strSystemdate);
			 if(value!="")
				 table.put(key,value);
			else
				try {
					throw new Exception("No query found");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(queries.get(String.valueOf(i)).contains("SBSB_ID") && queries.get(String.valueOf(i)).contains("MBR_SFX"))
			{
			 value = queries.get(String.valueOf(i)).replaceAll("SBSB_ID", strSBSB_ID).replaceAll("MBR_SFX", strMbr_sfx);
			 if(value!="")
				 table.put(key,value);
			else
				try {
					throw new Exception("No query found");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			else if(queries.get(String.valueOf(i)).contains("SBSB_ID"))
			{
				 value = queries.get(String.valueOf(i)).replaceAll("SBSB_ID", strSBSB_ID);
				 if(value!="")
					 table.put(key,value);
				else
					try {
						throw new Exception("No query found");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else if(queries.get(String.valueOf(i)).contains("MBR_SFX"))
			{
				 value = queries.get(String.valueOf(i)).replaceAll("MBR_SFX", strMbr_sfx);
				 if(value!="")
					 table.put(key,value);
				else
					try {
						throw new Exception("No query found");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
		}
		return table;
	}
	
		
	/**
	 * addField method returns the string as per the prescribed length, if string length is lesser then the prescribed length the string is left right padded with spaces
	 *@Param: Value of the string
	 *@param: startPosition of the string
	 * @param: endPosition of the string
	 */
	  public String addField(String value,int startPosition,int endPosition)
	  {
	  		int fieldLength = endPosition-startPosition+1;
	  		String paddedValue = "";
	  		if(value.length()<fieldLength)
	  		{
	 			paddedValue = StringUtils.rightPad(value, fieldLength, " ");
	 			return paddedValue;
	  		}
	  		else
	  			return value;

	  }
	  
	  /**
			 * ASHP_OPTUMFileFormatDate method returns predefined date format of ASHP vendor
			 *
			 *
			 */
		 
		public String ASHP_OPTUMFileFormatDate()
		{
			Date todaysDate = new Date();
			DateFormat dateFormat_ASHPfileNameConvention = new SimpleDateFormat("yyyyMMddhhmmss");
			String date_filenameformat = dateFormat_ASHPfileNameConvention.format(todaysDate);
			return date_filenameformat;
		}
		
		 public String DBP_NAVITUSFileFormatDate()
		 {
			 Date todaysDate = new Date();
		 	DateFormat dateFormat_DBPfileNameConvention1 = new SimpleDateFormat("yyyyMMdd");
		 	DateFormat dateFormat_DBPfileNameConvention2 = new SimpleDateFormat("hhmmss");
		 	String date_filenameformat1 = dateFormat_DBPfileNameConvention1.format(todaysDate);
		 	String date_filenameformat2 = dateFormat_DBPfileNameConvention2.format(todaysDate);
		 	String  dateFormat_DBPfileNameFormat = date_filenameformat1+"_"+date_filenameformat2;
		 	return dateFormat_DBPfileNameFormat;
		 }
		 
	  
}
