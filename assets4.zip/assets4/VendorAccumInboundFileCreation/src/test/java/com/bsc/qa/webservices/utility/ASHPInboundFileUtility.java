package com.bsc.qa.webservices.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import org.apache.commons.lang3.StringUtils;
import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

public class ASHPInboundFileUtility extends BaseTest{
	/**ASHPInboundFile creates text file of vendors ASHP,COLLECTIVEHEALTH and NAVITUS as per the respective mapping sheets
	 * @param: test data sheet path
	 * @return output file
	 */
	
public File createASHP_NAVITUS_COLLECTIVEHEALTHInboundFile(String testDataPath)
{
		File outputFile=null;
		DBUtils dbUtils = new DBUtils();
		ExcelUtilsExtended excelUtils = null;
		OtherUtilities otherUtilities = new OtherUtilities();
		CommonInboundFileUtility inboundFileUtils = new CommonInboundFileUtility();
		Date todaysDate = new Date();
		DateFormat dateFormat_detailRecord,dateFormat_Header;
		String currentDate_detailRecord,date_Header;
		Double totalAccumAmount = 0.00;
		Long totalRecords = 0L;
		FileWriter outputFileWriter = null;
		BufferedWriter outputFileBufferedWriter;
		String outputFilePath,sbsb_id,mbr_sfx,benifit_year,dateOfService,networkInd,coPay_UserInput="",coIns_UserInput="",ded_UserInput="",memberType = null,ASHPHeader="",detailRecord="",trailer="",fieldName="",OOP_UserInput="";
		int startPosition,endPosition,defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0,testdataCount,subscriberCount=0,detailRecordLastFieldColumn=0,trailerLastFieldColumn=0,trailerFirstFieldColumn=0;
		dateFormat_detailRecord = new SimpleDateFormat("dd-MMM-YYYY");
		currentDate_detailRecord = dateFormat_detailRecord.format(todaysDate);
		String date_filenameformat = inboundFileUtils.ASHP_OPTUMFileFormatDate();
		 
		//Vendors: ASHP and NAVITUS contains similar file layout. 
		//To retrieve vendor name from input test data file
		
		if(testDataPath.contains("NAVITUS")){
			//To create .txt output file
			outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\NVTS_TO_BSCA _"+date_filenameformat+".txt";
			outputFile = new File(outputFilePath);
		}
		else if(testDataPath.contains("COLLECTIVEHEALTH"))
		{
			outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\CHLTH_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
			outputFile = new File(outputFilePath);	
		}
		else
		{
			//To create .txt output file
			outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\ASHP_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
			outputFile = new File(outputFilePath);
		}
		
		//Initialize writer
		 try {
			outputFileWriter = new FileWriter(outputFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 outputFileBufferedWriter = new BufferedWriter(outputFileWriter);
		 
		 //retrieve mapping sheet from resources folder
		 String mappingSheet = "src//test//resources//VendorAccumInboundFileCreationTest.xlsx";
		excelUtils = new ExcelUtilsExtended(mappingSheet,"ASHP_MappingSheet");
	 
		 try
		 { 
			 //Write header
			 //Retrieve field name values from mapping sheet
			for(int mappingSheetIterator=1;mappingSheetIterator<=4;mappingSheetIterator++)
			{
				//Retrieve start and end positions for each field
				startPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, endPositionColumn));
				String defaultValue = excelUtils.getCellData(mappingSheetIterator, 3);
				
				//append the header with default values in the mapping sheet
				if(!defaultValue.equals(""))
					ASHPHeader = ASHPHeader+inboundFileUtils.addField(defaultValue,startPosition,endPosition);
				else
				{
					//append header with file date field
					if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("FILE_DATE"))
					{
						dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
						date_Header = dateFormat_Header.format(todaysDate);
						ASHPHeader = ASHPHeader+inboundFileUtils.addField(date_Header,startPosition,endPosition);
					}
					else
						ASHPHeader = ASHPHeader+inboundFileUtils.addField("",startPosition,endPosition);
				}
			}
			//To write header in the output file
			outputFileBufferedWriter.write(ASHPHeader);
			//To enter the next line after the header as per the file layout
			outputFileBufferedWriter.newLine();
			
			//Write detail record
			
			//check the vendor name in the input test data filename and fetch corresponding vendor queries sheet
				excelUtils = new ExcelUtilsExtended(mappingSheet,"ASHP_Queries");
			//To fetch queries from mapping sheet
			Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
			//To retrieve test data sheet
			excelUtils =new ExcelUtilsExtended(testDataPath, "TestData");
			//To get the subscriber count in the data sheet
			testdataCount = excelUtils.getRowCount(null);
			 
			//To iterate through each subscriber in the input data sheet
			for(int testdataSheetIterator=1;testdataSheetIterator<=testdataCount;testdataSheetIterator++)
			{ 
				sbsb_id=excelUtils.getCellData(testdataSheetIterator, 0);
				mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
				benifit_year = excelUtils.getCellData(testdataSheetIterator, 2);
				dateOfService = excelUtils.getCellData(testdataSheetIterator, 3);
				networkInd = excelUtils.getCellData(testdataSheetIterator, 4);
				if(testDataPath.contains("COLLECTIVEHEALTH"))
				{
					OOP_UserInput = excelUtils.getCellData(testdataSheetIterator, 5);
					ded_UserInput = excelUtils.getCellData(testdataSheetIterator, 6);
				}
				else{
					coPay_UserInput = excelUtils.getCellData(testdataSheetIterator, 5);
					coIns_UserInput = excelUtils.getCellData(testdataSheetIterator, 6);
					ded_UserInput = excelUtils.getCellData(testdataSheetIterator, 7);
				}
				if(testDataPath.contains("NAVITUS"))
					 memberType = excelUtils.getCellData(testdataSheetIterator, 8);
				
				//replace the sub strings in queries with subscriber data 
				
				Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx,benifit_year,currentDate_detailRecord);
				
				//Retrieve subscribers details from database
				ResultSet groupID = dbUtils.getResultSet("facets", replacedQueries.get("0"));
				ResultSet relationshipCode = dbUtils.getResultSet("facets", replacedQueries.get("1"));
				ResultSet gender = dbUtils.getResultSet("facets", replacedQueries.get("2"));
				ResultSet memberLName = dbUtils.getResultSet("facets", replacedQueries.get("3"));
				ResultSet memberFName = dbUtils.getResultSet("facets", replacedQueries.get("4"));
				ResultSet member_MInitial = dbUtils.getResultSet("facets", replacedQueries.get("5"));
				ResultSet memberDOB = dbUtils.getResultSet("facets", replacedQueries.get("6"));
				ResultSet planCode = dbUtils.getResultSet("facets", replacedQueries.get("7"));
				//OtherUtilities otherUtilities = new OtherUtilities();
				
				//In case if more than one group id exist for the same subscriber id, create record for both
				while(groupID.next() && relationshipCode.next() && gender.next() && memberLName.next() && memberFName.next() && member_MInitial.next() && memberDOB.next() && planCode.next())
				{
					//To increment the count if subscriber data is present in Facets
					subscriberCount++;
					if(testDataPath.contains("ASHP") || testDataPath.contains("NAVITUS"))
						 detailRecordLastFieldColumn = 23;
					else
						detailRecordLastFieldColumn = 22;		
					for(int mappinSheetIterator=5;mappinSheetIterator<=detailRecordLastFieldColumn;mappinSheetIterator++)
					{
						//To retrieve mapping sheet based on the vendor name present in input test data sheet
						if(testDataPath.contains("ASHP") || testDataPath.contains("NAVITUS"))
							 excelUtils = new ExcelUtilsExtended(mappingSheet,"ASHP_MappingSheet");
						else
							excelUtils = new ExcelUtilsExtended(mappingSheet,"COLLECTIVEHEALTH_MappingSheet");
						//retrieve field names, start position and end position from mapping sheet
						startPosition=Integer.parseInt(excelUtils.getCellData(mappinSheetIterator, startPositionColumn));
						endPosition=Integer.parseInt(excelUtils.getCellData(mappinSheetIterator, endPositionColumn));
						if(excelUtils.getCellData(mappinSheetIterator, defaultValueColumn).equals(""))
						{
							//Retrieve the field name of detail record and place the value in the output file
							fieldName = excelUtils.getCellData(mappinSheetIterator,fieldNameColumn);
							switch (fieldName) {
							case "GROUP_ID":
								detailRecord=detailRecord+inboundFileUtils.addField(groupID.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_IDENTIFICATION_NUMBER":
								if(testDataPath.contains("NAVITUS"))
							 	{
							 		if(memberType.equals("HMO"))
							 			detailRecord=detailRecord+inboundFileUtils.addField("XEH"+sbsb_id,startPosition,endPosition);
							 		else
							 			detailRecord=detailRecord+inboundFileUtils.addField("LSK"+sbsb_id,startPosition,endPosition);
							 	}
							 	else
						 		detailRecord=detailRecord+inboundFileUtils.addField(sbsb_id,startPosition,endPosition);
							break;
							case "MEMBER_SUFFIX":
								 if(mbr_sfx.equals("0")||mbr_sfx.equals("1")||mbr_sfx.equals("2")||mbr_sfx.equals("3")||mbr_sfx.equals("4")||mbr_sfx.equals("5")||mbr_sfx.equals("6")||mbr_sfx.equals("7")||mbr_sfx.equals("8")||mbr_sfx.equals("9"))
								 {
										mbr_sfx = String.format('0'+mbr_sfx);
										detailRecord=detailRecord+inboundFileUtils.addField(mbr_sfx,startPosition,endPosition);
									 }
								 else
								 detailRecord=detailRecord+mbr_sfx;
							break;
							case "RELATIONSHIP_CODE":
								detailRecord=detailRecord+inboundFileUtils.addField(relationshipCode.getString(1),startPosition,endPosition);
							break;
							case "GENDER":
								detailRecord=detailRecord+inboundFileUtils.addField(gender.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_LAST_NAME":
								detailRecord = detailRecord+inboundFileUtils.addField(memberLName.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_FIRST_NAME":
								detailRecord = detailRecord+inboundFileUtils.addField(memberFName.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_MIDDLE_INIT":
								detailRecord = detailRecord+inboundFileUtils.addField(member_MInitial.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_DOB":
								detailRecord = detailRecord+inboundFileUtils.addField(memberDOB.getString(1),startPosition,endPosition);
							break;
							case "CLAIM_ID":
								detailRecord = detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
							break;
							case "DATE_OF_SERVICE":
								detailRecord = detailRecord+inboundFileUtils.addField(dateOfService,startPosition,endPosition);
							break;
							case "IN_OUT_OF_NETWORK_INDICATOR":
								detailRecord = detailRecord+inboundFileUtils.addField(networkInd,startPosition,endPosition);
							break;
							case "PLAN_CODE":
								detailRecord = detailRecord+inboundFileUtils.addField(planCode.getString(1),startPosition,endPosition);
							break;
							case "COPAY_AMT":
								if(coPay_UserInput.contains("."))
								{
									coPay_UserInput=coPay_UserInput.replace(".", "");
									coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
								}
								else if(coPay_UserInput.equals("0"))
								{
									coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
								}
								else
								{
									coPay_UserInput=coPay_UserInput+"00";
									coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
								}
							 detailRecord = detailRecord+coPay_UserInput;
						
							break;
							case "OOP_AMT":
								if(OOP_UserInput.contains("."))
								{
									OOP_UserInput=OOP_UserInput.replace(".", "");
									OOP_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(OOP_UserInput));
								}
								else if(OOP_UserInput.equals("0"))
								{
									OOP_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(OOP_UserInput));
								}
								else
								{
									OOP_UserInput=OOP_UserInput+"00";
									OOP_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(OOP_UserInput));
								}
							 detailRecord = detailRecord+OOP_UserInput;
						
							break;
							case "COINS_AMT":
								if(coIns_UserInput.contains("."))
								{
								 coIns_UserInput=coIns_UserInput.replace(".", "");
								 coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
								}
								else if(coIns_UserInput.equals("0"))
								{
									coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
								}
								else
								{
									coIns_UserInput=coIns_UserInput+"00";
									coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
								}
							 detailRecord = detailRecord+coIns_UserInput;
							 break;
							case "DED_AMT":
								if(ded_UserInput.contains("."))
								{
								 ded_UserInput=ded_UserInput.replace(".", "");
								 ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput)); 
								}
								else if(ded_UserInput.equals("0"))
								{
									ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
								}
								else
								{
									ded_UserInput=ded_UserInput+"00";
									ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
								}
							 detailRecord = detailRecord+ded_UserInput;
							break;
							case "FILLER":
							case "VENDOR_UNIQUE_MEMBER_ID":
								detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
							break;
							}
						}
						else
							detailRecord = detailRecord+excelUtils.getCellData(mappinSheetIterator,defaultValueColumn);		
					}
			
					//To write detail record of subscriber in the output file
					outputFileBufferedWriter.write(detailRecord);
					//To enter the next line after each subscriber detail record as per the file layout
					outputFileBufferedWriter.newLine();
				
					//To calculate total accumulator amount and total records
					excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
					if(testDataPath.contains("COLLECTIVEHEALTH"))
						totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 5))+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 6));
					else
						totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 5))+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 6))+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 7));
					totalRecords = totalRecords+1;
					detailRecord="";
					//To retrieve subscriber data from input test data sheet
					sbsb_id = excelUtils.getCellData(testdataSheetIterator, 0);
					mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
					coPay_UserInput = excelUtils.getCellData(testdataSheetIterator, 5);
					coIns_UserInput = excelUtils.getCellData(testdataSheetIterator, 6);
					ded_UserInput= excelUtils.getCellData(testdataSheetIterator, 7);
				}
				
				//check the subscriber is present in facets, else report error
				if(subscriberCount==0)
				{
					System.out.println("Mandatory field is missing or incorrect test data for row number: "+testdataSheetIterator+" in test data sheet"+testDataPath);
					logger.log(LogStatus.INFO, "Incorrect test data/Incorrect input mandatory fields: "+ sbsb_id );
					//System.out.println("fail");
				}
				else
				{
					System.out.println("Subscriber data inserted: "+ sbsb_id);
					logger.log(LogStatus.INFO, "Subscriber data inserted: "+ sbsb_id);
				}
				subscriberCount=0;
				
			}
		
		//Write Trailer
		//To iterate through each trailer field
			if(testDataPath.contains("ASHP") || testDataPath.contains("NAVITUS"))
			{
				trailerFirstFieldColumn = 24; 
				trailerLastFieldColumn = 27;
			}
			else
			{
				trailerLastFieldColumn = 26;	
				trailerFirstFieldColumn = 23;
			}
			for(int testdataSheetIterator=trailerFirstFieldColumn;testdataSheetIterator<=trailerLastFieldColumn;testdataSheetIterator++){
				if(testDataPath.contains("ASHP") || testDataPath.contains("NAVITUS")){
					 excelUtils = new ExcelUtilsExtended(mappingSheet,"ASHP_MappingSheet");}
				 else
					 excelUtils = new ExcelUtilsExtended(mappingSheet,"COLLECTIVEHEALTH_MappingSheet");
			//To retrieve start and end positions of each field
				startPosition=Integer.parseInt(excelUtils.getCellData(testdataSheetIterator, startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(testdataSheetIterator, endPositionColumn));
			//To append field values to the trailer except for the default value fields
				if(excelUtils.getCellData(testdataSheetIterator, defaultValueColumn).equals(""))
				{
					if(excelUtils.getCellData(testdataSheetIterator, fieldNameColumn).equals("TOTAL_RECORDS"))
					
						trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
					
					else if(excelUtils.getCellData(testdataSheetIterator, fieldNameColumn).equals("TOTAL_AMOUNT"))
					{
						DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
						String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
						if(totalAccumAmount_trailer.contains("."))
						{
							totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
						}
						trailer=trailer+String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer));		
					}
					else if(excelUtils.getCellData(testdataSheetIterator, fieldNameColumn).equals("FILLER"))
						trailer=trailer+inboundFileUtils.addField("", startPosition,endPosition);
				}
			//append default values to the trailer string
				else
					trailer=trailer+inboundFileUtils.addField(excelUtils.getCellData(testdataSheetIterator, defaultValueColumn),startPosition,endPosition);	
			}
			//write trailer to the output file
			outputFileBufferedWriter.write(trailer);
			//close writer
			outputFileBufferedWriter.close();
			outputFileWriter.close();
			
			
			//report the total number of records and input file used
			logger.log(LogStatus.INFO, "Total number of records inserted: "+ totalRecords );
			logger.log(LogStatus.INFO, "Input data sheet used: "+ testDataPath );
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
			return outputFile;

}

}


