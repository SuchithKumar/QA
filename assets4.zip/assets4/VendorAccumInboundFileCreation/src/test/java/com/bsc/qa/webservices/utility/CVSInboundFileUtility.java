package com.bsc.qa.webservices.utility;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;

import org.apache.commons.lang3.StringUtils;

import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


public class CVSInboundFileUtility extends BaseTest{
	/**CVSInboundFile creates text file of CVS vendor as per the mapping sheet
	 * @param: test data sheet path
	 * @return output file
	 */
	public  File createCVSInboundFile(String testDataPath){
		File outputFile=null;
		DBUtils dbUtils = new DBUtils();
		CommonInboundFileUtility inboundFileUtils = new CommonInboundFileUtility();
		ExcelUtilsExtended excelUtils;
		Date todaysDate = new Date();
		DateFormat dateFormat_Header = new SimpleDateFormat("yyyyMMdd");;
		String date_Header = dateFormat_Header.format(todaysDate);;
		Double totalAccumAmount = 0.00;
		Long totalRecords = 0L;
		FileWriter outputFileWriter = null;
		BufferedWriter outputFileBufferedWriter;
		String mappingSheet = "src//test//resources//VendorAccumInboundFileCreationTest.xlsx";
		String sbsb_id,mbr_sfx,dateOfService,coPay_UserInput,coIns_UserInput,ded_UserInput,fieldName="",outputFilePath;
		int defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0,startPosition,endPosition;
		String date_filenameformat = inboundFileUtils.DBP_NAVITUSFileFormatDate();
		
		//create output file
		outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\CVS_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
		outputFile = new File(outputFilePath);
		
		//Initialize writer
		 try {
			 outputFileWriter = new FileWriter(outputFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();}
		 outputFileBufferedWriter = new BufferedWriter(outputFileWriter);
		 
		//write header
		 String CVSHeader="";	
		try{
			//retrieve mapping sheet	
				excelUtils = new ExcelUtilsExtended(mappingSheet, "CVS_MappingSheet");
			//To iterate through each field of the header in the mapping sheet
				for(int mappingSheetIterator=1;mappingSheetIterator<=6;mappingSheetIterator++)
					{
						startPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, startPositionColumn));
						endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, endPositionColumn));
						String defaultValue = excelUtils.getCellData(mappingSheetIterator,defaultValueColumn);
						
						//append field values to the header string except for the default value fields
							if(!defaultValue.equals(""))
								CVSHeader = CVSHeader+inboundFileUtils.addField(defaultValue,startPosition,endPosition);
							else
							{
							if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("RUN_DATE") || excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("CYCLE_START_DATE") || excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("CYCLE_END_DATE"))
							{
								dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
								date_Header = dateFormat_Header.format(todaysDate);
								CVSHeader = CVSHeader+inboundFileUtils.addField(date_Header,startPosition,endPosition);
							}
							else
								CVSHeader = CVSHeader+StringUtils.rightPad("", endPosition-startPosition+1, " ");
						}
					}	
				//To write header to the output file
				outputFileBufferedWriter.write(CVSHeader);
				//To enter new file in the output file as per file layout
				outputFileBufferedWriter.newLine();
		//Write detail record
					
		//retrieve queries from queries sheet
			String detailRecord="";
			//To retrieve queries sheet		
				excelUtils = new ExcelUtilsExtended(mappingSheet,"CVS_Queries");
			//To fetch queries from queries sheet		
				Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
			//To retrieve test data sheet				 
				excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			//To get the subscriber count in the test data sheet 		
			int rowCount = excelUtils.getRowCount(null);
			//To iterate through each subscriber in the input test data sheet
				for(int testdataSheetIterator=1;testdataSheetIterator<=rowCount;testdataSheetIterator++)
				{
					//Retrieve test data from 	
						excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
						sbsb_id=excelUtils.getCellData(testdataSheetIterator, 0);
						mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
						//benifit_year = excelUtils.getCellData(testdataSheetIterator, 2);
						dateOfService = excelUtils.getCellData(testdataSheetIterator, 3);
						coPay_UserInput = excelUtils.getCellData(testdataSheetIterator, 4);
						coIns_UserInput = excelUtils.getCellData(testdataSheetIterator, 5);
						ded_UserInput = excelUtils.getCellData(testdataSheetIterator, 6);
						
					//replace sub stings in queries with test data
						Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, "", "");
						Map<String,String> memberID = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("0"));
						Map<String,String> patientLName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("1"));
						Map<String,String> patientFName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("2"));
						Map<String,String> patientDOB = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("3"));
						OtherUtilities otherUtilities = new OtherUtilities();
					//Check if the subscriber is present in Facets
						if(memberID.size()==0 || patientLName.size()==0 || patientFName.size()==0 || patientDOB.size()==0)
						{
							System.out.println("Mandatory field is missing or incorrect test data for row number: "+testdataSheetIterator+" in test data sheet"+testDataPath);
							logger.log(LogStatus.INFO, "Incorrect test data/Incorrect input mandatory fields: "+ sbsb_id );
							//System.out.println("fail");
						}
						else{
					//To iterate through each field of detail record in the mapping sheet
						for(int mappingSheetIterator=7;mappingSheetIterator<=110;mappingSheetIterator++)
						{
							//To retrieve start and end positions of each field of detail record
								excelUtils = new ExcelUtilsExtended(mappingSheet, "CVS_MappingSheet");
								startPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, startPositionColumn));
								endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, endPositionColumn));
							//Append the values to the detail record expect for the default value fields
							if(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals(""))
							{
								fieldName = excelUtils.getCellData(mappingSheetIterator, fieldNameColumn);
								switch (fieldName) {
								case "CARDHOLDER_ID":
									detailRecord = detailRecord+inboundFileUtils.addField(memberID.get("MEME_SSN"),startPosition,endPosition);
									break;
								case "PATIENT_LAST_NAME":
									detailRecord = detailRecord+inboundFileUtils.addField(patientLName.get("MEME_LAST_NAME"),startPosition,endPosition);
								break;
								case "PATIENT_FIRST_NAME":
									detailRecord = detailRecord+inboundFileUtils.addField(patientFName.get("MEME_FIRST_NAME"),startPosition,endPosition);
								break;
								case "PATIENT_BIRTH_DATE":
									detailRecord = detailRecord+inboundFileUtils.addField(patientDOB.get("DOB"),startPosition,endPosition);
								break;
								case "TRANSACTION_ID":
									detailRecord = detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(18).toString(),startPosition,endPosition);
								break;
								case "DATE_FILLED":
									detailRecord = detailRecord+inboundFileUtils.addField(dateOfService,startPosition,endPosition);
								break;
								case "FLAT_COPAY AMOUNT_PAID":
									if(coPay_UserInput.contains("."))
									{
										coPay_UserInput=coPay_UserInput.replace(".", "");
										coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
									}
									else if(coPay_UserInput.equals("0"))
									{
										coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
									}
									else
									{
										coPay_UserInput=coPay_UserInput+"00";
										coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
									}
								 detailRecord = detailRecord+coPay_UserInput;
								break;
								case "PERCENT_COPAY_AMOUNT_PAID":
									if(coIns_UserInput.contains("."))
									{
									 coIns_UserInput=coIns_UserInput.replace(".", "");
									 coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
									}
									else if(coIns_UserInput.equals("0"))
									{
										coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
									}
									else
									{
										coIns_UserInput=coIns_UserInput+"00";
										coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
									}
								 detailRecord = detailRecord+coIns_UserInput;
								break;
								case "FRONT_END_DEDUCTIBLE_AMOUNT":
									if(ded_UserInput.contains("."))
									{
									 ded_UserInput=ded_UserInput.replace(".", "");
									 ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput)); 
									}
									else if(ded_UserInput.equals("0"))
									{
										ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
									}
									else
									{
										ded_UserInput=ded_UserInput+"00";
										ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
									}
								 detailRecord = detailRecord+ded_UserInput;
								break;
								default:
									detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
								break;
								}
							}
							//append the default value from mapping sheet
								else if(excelUtils.getCellData(mappingSheetIterator,defaultValueColumn).equals("Field not used"))
									detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
								else
								detailRecord = detailRecord+inboundFileUtils.addField(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn),startPosition,endPosition);		
						}	
						//write the detail record of each subscriber
						outputFileBufferedWriter.write(detailRecord);
						//Enter new line in the output file after every detail record of the subscriber as per the file layout
						outputFileBufferedWriter.newLine();
						//To retrieve test data from test data sheet
						excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
						totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 4))+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 5))+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 6));
						totalRecords = totalRecords+1;
						logger.log(LogStatus.INFO, "Subscriber data inserted: "+ sbsb_id );
						detailRecord="";
						sbsb_id = excelUtils.getCellData(testdataSheetIterator, 0);
						mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
						coPay_UserInput = excelUtils.getCellData(testdataSheetIterator, 4);
						coIns_UserInput = excelUtils.getCellData(testdataSheetIterator, 5);
						ded_UserInput= excelUtils.getCellData(testdataSheetIterator, 6);
						}
						}
					//write Trailer
					String trailer="";
					//To iterate through trailer fields in the mapping sheet
					for(int i=111;i<=115;i++)
					{
						//Retrieve the mapping sheet
						excelUtils=new ExcelUtilsExtended(mappingSheet,"CVS_MappingSheet");
						//To retrieve the start and end positions of each trailer field
						startPosition=Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
						endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
						//append the trailer field values to the trailer string expect for default values fields
						if(excelUtils.getCellData(i, defaultValueColumn).equals(""))
						{
							if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_RECORDS"))
							
								trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
							
							else if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_AMOUNT_PAYABLE"))
							{
								DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
								String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
								if(totalAccumAmount_trailer.contains("."))
								{
									totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
								}
								trailer=trailer+String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer));		
							}
							else if(excelUtils.getCellData(i, fieldNameColumn).equals("FILLER") || excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_ADMIN_FEE_AMOUNT"))
								trailer=trailer+inboundFileUtils.addField("", startPosition,endPosition);
						}
						//append default field values to the trailer
						else
							trailer=trailer+inboundFileUtils.addField(excelUtils.getCellData(i, defaultValueColumn),startPosition,endPosition);
					}
					//write trailer
					outputFileBufferedWriter.write(trailer);
					//close writers
					outputFileBufferedWriter.close();
					outputFileWriter.close();	
					
					//report the total number of records and input file used
						logger.log(LogStatus.INFO, "Total number of records inserted: "+ totalRecords );
						logger.log(LogStatus.INFO, "Input data sheet used: "+ testDataPath );
					}
				
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return outputFile;
		}

}

