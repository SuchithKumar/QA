package com.bsc.qa.webservices.tests;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.webservices.utility.ASHPInboundFileUtility;
import com.bsc.qa.webservices.utility.CARE1STInboundFileUtility;
import com.bsc.qa.webservices.utility.CVSInboundFileUtility;
import com.bsc.qa.webservices.utility.DBPInboundFileUtility;
import com.bsc.qa.webservices.utility.ESIInboundFileUtility;
import com.bsc.qa.webservices.utility.MEDIMPACTInboundFileUtility;
import com.bsc.qa.webservices.utility.OPTUMInboundFileUtility;
import com.bsc.qa.webservices.utility.OPTUMRXInboundFileUtility;
import com.relevantcodes.extentreports.LogStatus;

public class VendorAccumInboundFileCreationTest extends BaseTest implements IHookable {
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	
	
	public VendorAccumInboundFileCreationTest(String inputFileName) {
		this.inputFileName = inputFileName;
		
	}
	// ************************************** TEST
	// METHODS************************

	// Main test method to create accumulator inbound files as per field mapping document.
	@Test()
	private void testInboundFileCreation(){
		
		File outputFile=null;
		//To check the vendor name from the input data sheet and call the utility classes of respective vendor
		 if(inputFileName.contains("MEDIMPACT"))
		{
			MEDIMPACTInboundFileUtility MEDIMPACT = new MEDIMPACTInboundFileUtility();
			reportInit("InboundFileCreation", "MEDIMPACT");
			try {
				outputFile = MEDIMPACT.MEDIMPACTInboundFile(inputFileName);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 else if(inputFileName.contains("DBP"))
		{
			DBPInboundFileUtility DBP = new DBPInboundFileUtility();
			reportInit("InboundFileCreation", "DBP");
			outputFile = DBP.createDBPInboundFile(inputFileName);
		}
		 else if(inputFileName.contains("CARE1ST"))
		{
			CARE1STInboundFileUtility CARE1ST = new CARE1STInboundFileUtility();
			reportInit("InboundFileCreation", "CARE1ST");
			outputFile = CARE1ST.createCARE1STInboundFile(inputFileName);
		}
		 else if(inputFileName.contains("CVS"))
		{
			CVSInboundFileUtility CVS = new CVSInboundFileUtility();
			reportInit("InboundFileCreation", "CVS");
			outputFile = CVS.createCVSInboundFile(inputFileName);
		}
		 else if(inputFileName.contains("ESI"))
		{
			 ESIInboundFileUtility ESI = new ESIInboundFileUtility();
			reportInit("InboundFileCreation", "ESI");
			outputFile = ESI.createESIInboundFile(inputFileName);
		}
		 else if(inputFileName.contains("ASHP") || inputFileName.contains("NAVITUS") || inputFileName.contains("COLLECTIVEHEALTH"))
		{
			ASHPInboundFileUtility ASHP = new ASHPInboundFileUtility();
			reportInit("InboundFileCreation", "ASHP/NAVISTUS/COLLECTIVEHEALTH");
			outputFile = ASHP.createASHP_NAVITUS_COLLECTIVEHEALTHInboundFile(inputFileName);
		}
		 else if(inputFileName.contains("OPTUM"))
		{
			if(inputFileName.contains("OPTUM_RX") || inputFileName.contains("OPTUMRX"))
			 {
				OPTUMRXInboundFileUtility OPTUMRX = new OPTUMRXInboundFileUtility();
				reportInit("InboundFileCreation", "OPTUM_RX");
				try {
					outputFile = OPTUMRX.createOPTUMRXInboundFile(inputFileName);
				} catch (NumberFormatException | IOException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			 }
			 else if(inputFileName.contains("OPTUM_BSOFCA") || inputFileName.contains("OPTUMBSOFCA"))
			 {
				OPTUMInboundFileUtility OPTUM_BSOFCA = new OPTUMInboundFileUtility();
				reportInit("InboundFileCreation", "OPTUM_BSOFCA");
				try {
					outputFile = OPTUM_BSOFCA.createOPTUMInboundFile(inputFileName);
				} catch (NumberFormatException | IOException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			 }
			 else
			 {
				 OPTUMInboundFileUtility OPTUM = new OPTUMInboundFileUtility();
				 reportInit("InboundFileCreation", "OPTUM");
				 try {
					outputFile = OPTUM.createOPTUMInboundFile(inputFileName);
				} catch (NumberFormatException | IOException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
		}
		 try 
		 {
			 //To check if output file is created
			if(outputFile.exists())
			{
				System.out.println("Vendor accumulator inbound file created successfully: "+outputFile.getAbsolutePath());
				logger.log(LogStatus.PASS, "Accums Inbound file created sucessfully: "+outputFile.getAbsolutePath());
			}
			else
				logger.log(LogStatus.FAIL, "Inbound file creation is not successfull");
		} 
		catch (Exception e) 
		 {
				// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	/**
	 * //To run test method, this method will initiate the HTML report
	 * 
	 * @Override run is a hook before @Test method
	 */
	
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult){
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting Test " + testResult.getName());
		callBack.runTestMethod(testResult);
		//To display the failure count in console
		softAssert.assertAll(); 
	}
	
	
	/*private Map<String, String> getData(String testMethodName) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		// assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/" + this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, testMethodName);
		return dataMap;
	}*/
}
		

