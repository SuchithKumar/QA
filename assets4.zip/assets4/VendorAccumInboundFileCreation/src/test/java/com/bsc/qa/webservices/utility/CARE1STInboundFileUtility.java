package com.bsc.qa.webservices.utility;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;



public class CARE1STInboundFileUtility extends BaseTest{
	/**CARE1STInboundFile creates text file of CARE1ST vendor as per the mapping sheets
	 * @param: test data sheet path
	 * @return output file
	 */
	
	public  File createCARE1STInboundFile(String testDataPath){
		File outputFile=null;
		DBUtils dbUtils = new DBUtils();
		OtherUtilities otherUtilities = new OtherUtilities();
		CommonInboundFileUtility inboundFileUtils = new CommonInboundFileUtility();
		ExcelUtilsExtended excelUtils;
		Date todaysDate = new Date();
		DateFormat dateFormat_Header = new SimpleDateFormat("yyyyMMdd");;
		String date_Header = dateFormat_Header.format(todaysDate);
		Double totalAccumAmount = 0.00;
		Long totalRecords = 0L;
		FileWriter outputFileWriter = null;
		BufferedWriter outputFileBufferedWriter;
		String sbsb_id,mbr_sfx,dateOfService,coPay_UserInput,coIns_UserInput,ded_UserInput,claimType,vendor,fieldName="",networkInd,outputFilePath;
		int defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0,startPosition,endPosition,subscriberCount=0;
	
		String date_filenameformat = inboundFileUtils.DBP_NAVITUSFileFormatDate();
		
		//create .txt output file
		outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\CARE1ST_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
		outputFile = new File(outputFilePath);
		
		//Initialize writer
		 try {
			outputFileWriter = new FileWriter(outputFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 outputFileBufferedWriter = new BufferedWriter(outputFileWriter);
		 
		 String detailRecord="";	
		//retrieve mapping sheet from resources folder
		String mappingSheet = "src//test//resources//VendorAccumInboundFileCreationTest.xlsx";
		try{
				//Write detail record
			
				//retrieve queries from queries sheet
					excelUtils = new ExcelUtilsExtended(mappingSheet,"CARE1ST_Queries");
					Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
							 
				//To fetch input test data sheet
					excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
				//To get the test data count in test data sheet
					int rowCount = excelUtils.getRowCount(null);
					
				//To iterate through each row in the test data sheet	
				for(int testdataSheetIterator=1;testdataSheetIterator<=rowCount;testdataSheetIterator++)
				{
					//To get test data from test data sheet and assign to variables
						excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
						sbsb_id=excelUtils.getCellData(testdataSheetIterator, 0);
						mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
						//String benifit_year = excelUtils.getCellData(testdataSheetIterator, 2);
						dateOfService = excelUtils.getCellData(testdataSheetIterator, 3);
						networkInd = excelUtils.getCellData(testdataSheetIterator, 4);
						coPay_UserInput = excelUtils.getCellData(testdataSheetIterator, 5);
						coIns_UserInput = excelUtils.getCellData(testdataSheetIterator, 6);
						ded_UserInput = excelUtils.getCellData(testdataSheetIterator, 7);
						claimType = excelUtils.getCellData(testdataSheetIterator, 8);
						vendor = excelUtils.getCellData(testdataSheetIterator, 9);	
						
					//replace sub strings in queries with test data
						Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, "", "");
					//To retrieve subscriber data from database
						ResultSet GroupID = dbUtils.getResultSet("facets",replacedQueries.get("0"));
						ResultSet memberDOB = dbUtils.getResultSet("facets",replacedQueries.get("1"));
					//In case if more than one group id exist for the same subscriber id, create record for both
						try {
							while(GroupID.next() && memberDOB.next())
							{
							subscriberCount++;
							for(int mappingSheetIterator=1;mappingSheetIterator<=30;mappingSheetIterator++)
							{
								//To retrieve start and end positions of each field in the mapping sheet
								excelUtils = new ExcelUtilsExtended(mappingSheet, "CARE1ST_MappingSheet");
								startPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, startPositionColumn));
								endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, endPositionColumn));
								//Check if the field is predefined with default value
								if(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals(""))
								{
									//To retrieve the field name from the mapping sheet and write the corresponding value in the output file
									fieldName = excelUtils.getCellData(mappingSheetIterator, fieldNameColumn);
									switch (fieldName) {
									case "Claim Number":
										detailRecord = detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
										break;
									case "Claim type/ status":
										detailRecord = detailRecord+inboundFileUtils.addField(claimType,startPosition,endPosition);
									break;
									case "Group ID":
										detailRecord = detailRecord+inboundFileUtils.addField(GroupID.getString(1),startPosition,endPosition);
									break;
									case "Subscriber ID":
										detailRecord = detailRecord+inboundFileUtils.addField(sbsb_id,startPosition,endPosition);
									break;
									case "Member Suffix":
										if(mbr_sfx.equals("0")||mbr_sfx.equals("1")||mbr_sfx.equals("2")||mbr_sfx.equals("3")||mbr_sfx.equals("4")||mbr_sfx.equals("5")||mbr_sfx.equals("6")||mbr_sfx.equals("7")||mbr_sfx.equals("8")||mbr_sfx.equals("9"))
											mbr_sfx = String.format("0000"+mbr_sfx);
										else
											mbr_sfx = "000"+mbr_sfx;
										detailRecord = detailRecord+mbr_sfx;
									break;
									case "Member date of birth":
										detailRecord = detailRecord+inboundFileUtils.addField(memberDOB.getString(1),startPosition,endPosition);
									break;
									case "Network Indicator":
										if(networkInd.equals("INN"))
											detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
										else if(networkInd.equals("OON"))
											detailRecord = detailRecord+inboundFileUtils.addField("T1",startPosition,endPosition);
									break;
									case "Procedure Code":
										detailRecord = detailRecord+inboundFileUtils.addField("09935",startPosition,endPosition);
									break;
									case "Claim Date of Service":
										detailRecord = detailRecord+inboundFileUtils.addField(dateOfService,startPosition,endPosition);
									break;
									case "Specialty Vendor Type":
										if(vendor.equals("ASHP"))
										{
											vendor="PHPASHSPECIAL";
											detailRecord = detailRecord+inboundFileUtils.addField(vendor,startPosition,endPosition);
										}
										else if(vendor.equals("Beacon"))
										{
											vendor="PHPBEACONSPEC";
											detailRecord = detailRecord+inboundFileUtils.addField(vendor,startPosition,endPosition);
										}
										else
											System.out.println("Invalid vendor user input");
									break;
									case "File Create Date":
										detailRecord = detailRecord+inboundFileUtils.addField(date_Header,startPosition,endPosition);
									break;
									case "Original Claim Number":
										detailRecord = detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
									break;
									case "EDI Tracer ID":
										detailRecord = detailRecord+inboundFileUtils.addField("E"+otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
									break;
									case "File Transmission ID":
										detailRecord = detailRecord+inboundFileUtils.addField("0664A953-3CDF-498A-B68C-2B626AD3360E".toString(),startPosition,endPosition);
									break;
									case "Co Pay Amount":
										if(coPay_UserInput.contains("."))
										{
											coPay_UserInput=coPay_UserInput.replace(".", "");
											coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
										}
										else if(coPay_UserInput.equals("0"))
										{
											coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
										}
										else
										{
											coPay_UserInput=coPay_UserInput+"00";
											coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
										}
									 detailRecord = detailRecord+coPay_UserInput;
									break;
									case "Co Insurance Amount":
										if(coIns_UserInput.contains("."))
										{
										 coIns_UserInput=coIns_UserInput.replace(".", "");
										 coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
										}
										else if(coIns_UserInput.equals("0"))
										{
											coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
										}
										else
										{
											coIns_UserInput=coIns_UserInput+"00";
											coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
										}
									 detailRecord = detailRecord+coIns_UserInput;
									break;
									case "Deductible Amount":
										if(ded_UserInput.contains("."))
										{
										 ded_UserInput=ded_UserInput.replace(".", "");
										 ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput)); 
										}
										else if(ded_UserInput.equals("0"))
										{
											ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
										}
										else
										{
											ded_UserInput=ded_UserInput+"00";
											ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
										}
									 detailRecord = detailRecord+ded_UserInput;
									break;
									default:
										detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
									break;
									}
								}
								else
									detailRecord = detailRecord+inboundFileUtils.addField(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn),startPosition,endPosition);		
							}
							//To write detail record of each subscriber in the output file
							outputFileBufferedWriter.write(detailRecord);
							//To enter the new line after every subscriber detail record as per file layout
							outputFileBufferedWriter.newLine();
							//To retrieve test data from test data sheet
								excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
								totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 5))+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 6))+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 7));
								totalRecords = totalRecords+1;
								detailRecord="";
								sbsb_id = excelUtils.getCellData(testdataSheetIterator, 0);
								mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
								vendor = excelUtils.getCellData(testdataSheetIterator, 9);
								coPay_UserInput = excelUtils.getCellData(testdataSheetIterator, 5);
								coIns_UserInput = excelUtils.getCellData(testdataSheetIterator, 6);
								ded_UserInput= excelUtils.getCellData(testdataSheetIterator, 7);
}
						} catch (NumberFormatException | SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}		
					if(subscriberCount==0)
					{
						System.out.println("Mandatory field is missing or incorrect test data for row number: "+testdataSheetIterator+" in test data sheet"+testDataPath);
						logger.log(LogStatus.ERROR, "Incorrect test data/Incorrect input mandatory fields: "+ sbsb_id );
						//System.out.println("fail");
					}
					else
					{
						System.out.println("Subscriber data inserted: "+ sbsb_id);
						logger.log(LogStatus.INFO, "Subscriber data inserted: "+ sbsb_id);
					}
				}
				outputFileBufferedWriter.close();
				outputFileWriter.close();	
				
				//report the total number of records and input file used
				logger.log(LogStatus.INFO, "Total number of records inserted: "+ totalRecords );
				logger.log(LogStatus.INFO, "Input data sheet used: "+ testDataPath );
		}
	catch (IOException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return outputFile;
}

}

