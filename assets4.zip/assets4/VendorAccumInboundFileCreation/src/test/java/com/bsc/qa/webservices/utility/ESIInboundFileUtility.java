package com.bsc.qa.webservices.utility;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;

import org.apache.commons.lang3.StringUtils;

import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


public class ESIInboundFileUtility extends BaseTest{
	/**ESIInboundFile creates text file of ESI vendor as per the mapping sheet
	 * @param: test data sheet path
	 * @return output file
	 */
	
	public  File createESIInboundFile(String testDataPath){
		File outputFile=null;
		DBUtils dbUtils = new DBUtils();
		ExcelUtilsExtended excelUtils=null;
		OtherUtilities otherUtilities = new OtherUtilities();
		CommonInboundFileUtility inboundFileUtils = new CommonInboundFileUtility();
		Date todaysDate = new Date();
		Double totalAccumAmount = 0.00;
		Long totalRecords = 0L;
		FileWriter outputFileWriter = null;
		BufferedWriter outputFileBufferedWriter;
		
		String sbsb_id,mbr_sfx,dateOfService,networkInd,accumulatorType,accumAmount,fieldName="",outputFilePath;	
		int startPositionColumn=1, endPositionColumn=2, fieldNameColumn=0,defaultValueColumn=3,startPosition,endPosition;
		
		//Create output file 
		String date_filenameformat = inboundFileUtils.ASHP_OPTUMFileFormatDate();
		outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\ESI_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
		outputFile = new File(outputFilePath);
		
		//Initialize writer
		 try {
			 outputFileWriter = new FileWriter(outputFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 outputFileBufferedWriter = new BufferedWriter(outputFileWriter);
		 
		 //Retrieve mapping sheet
		 String mappingSheet = "src//test//resources//VendorAccumInboundFileCreationTest.xlsx";
		 
		 String detailRecord="";
		try
		{
			excelUtils = new ExcelUtilsExtended(mappingSheet, "ESI_MappingSheet");
			//write header
			String header="";
			//To iterate through each field of header in mapping sheet
			for(int mappingSheetIterator=1;mappingSheetIterator<=11;mappingSheetIterator++)	
			{
				//retrieve field name vales and default values from mapping sheet and place in the output file
				startPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator,startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator,endPositionColumn));
				//append the header with default values in the mapping sheet
				if(!excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals(""))
				{
					if(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals("Field not used"))
						header = header+inboundFileUtils.addField("", startPosition, endPosition);
					else
						header = header+inboundFileUtils.addField(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn), startPosition, endPosition);
				}
				//append header with creation date field
				else if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("CREATION_DATE"))
				{
					DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
					
					 String date = dateFormat.format(todaysDate);
					 header = header+inboundFileUtils.addField(date, startPosition, endPosition);
				}
				//append header with creation time field
				else if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("CREATION_TIME"))
				{
					 DateFormat timeFormat = new SimpleDateFormat("hhmm");
					 String time = timeFormat.format(todaysDate);
					 header = header+inboundFileUtils.addField(time, startPosition, endPosition);
				}
				else
					header = header+inboundFileUtils.addField("", startPosition, endPosition);		
			}
			//write header to the output file
			outputFileBufferedWriter.write(header);
			//enter the new line in the output file as per file layout
			outputFileBufferedWriter.newLine();

	//Write detail record
	
		//fetch corresponding vendor queries sheet
		excelUtils = new ExcelUtilsExtended(mappingSheet,"ESI_Queries");
		//To fetch queries from mapping sheet
		Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
		//To retrieve test data sheet			
		 excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
		//To get the subscriber count in the data sheet 
		int rowCount = excelUtils.getRowCount(null);
		//To iterate through each subscriber in the input data sheet
		for(int testdataSheetIterator=1;testdataSheetIterator<=rowCount;testdataSheetIterator++)
		{
			excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			sbsb_id=excelUtils.getCellData(testdataSheetIterator, 0);
			mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
			//benifit_year = excelUtils.getCellData(testdataSheetIterator, 2);
			dateOfService = excelUtils.getCellData(testdataSheetIterator, 3);
			networkInd = excelUtils.getCellData(testdataSheetIterator, 4);
			accumulatorType = excelUtils.getCellData(testdataSheetIterator, 5);
			accumAmount = excelUtils.getCellData(testdataSheetIterator, 6);
			//replace the sub strings in queries with subscriber data
				Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, "","");
			//Retrieve subscribers details from database
			Map<String,String> cardholderID = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("0"));
			Map<String,String> patient_FirstName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("2"));
			Map<String,String> patient_LastName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("1"));
			Map<String,String> patient_DOB = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("3"));
			
			//check if subscriber is not present in facets
			if(cardholderID.size()==0 || patient_FirstName.size()==0 || patient_LastName.size()==0 || patient_DOB.size()==0)
			{
				System.out.println("Mandatory field is missing or incorrect test data for row number: "+testdataSheetIterator+" in test data sheet"+testDataPath);
				logger.log(LogStatus.INFO, "Incorrect test data/Incorrect input mandatory fields: "+ sbsb_id );
				//System.out.println("fail");
			}
			else{
		//To fetch mapping sheet
			excelUtils = new ExcelUtilsExtended(mappingSheet, "ESI_MappingSheet");
		//To iterate through each field of the detailed record in the mapping sheet	
			for(int mappingSheetIterator=12;mappingSheetIterator<=194;mappingSheetIterator++)
			{	
				//To get start and end position of each field of detail record in mapping sheet
				startPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator,startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator,endPositionColumn));
			
				if(!excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals("") && !excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals("Field not used"))
					detailRecord = detailRecord+inboundFileUtils.addField(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn), startPosition, endPosition);
					else if(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals("Field not used"))
				detailRecord = detailRecord+inboundFileUtils.addField("", startPosition, endPosition);
					else if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("VERSION_RELEASE_NUMBER") || excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("TRANSACTION_RESPONSE_STATUS") || excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("ACCUMULATOR_BALANCE_QUALIFIER_2") || excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("ACCUMULATOR_NETWORK_INDICATOR_2") ||excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("ACCUMULATOR_APPLIED_AMOUNT_2") || excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("ACTION_CODE_2"))
				detailRecord = detailRecord+inboundFileUtils.addField("", startPosition, endPosition);
				else
				{
				fieldName = excelUtils.getCellData(mappingSheetIterator, fieldNameColumn);
				switch(fieldName){
				
				case "DATE_OF_SERVICE":
				 detailRecord = detailRecord+inboundFileUtils.addField(dateOfService, startPosition, endPosition);
				 break;
				case "IN_NETWORK_INDICATOR":
				 detailRecord = detailRecord+inboundFileUtils.addField(networkInd, startPosition, endPosition);
				 break;
				case "CARDHOLDER_ID":
				 detailRecord = detailRecord+inboundFileUtils.addField(cardholderID.get("MEME_SSN"), startPosition, endPosition);
				 break;
				case "PATIENT_FIRST_NAME":
				 detailRecord = detailRecord+inboundFileUtils.addField(patient_FirstName.get("MEME_FIRST_NAME"), startPosition, endPosition);
				 break;
				case "PATIENT_LAST_NAME":
					 detailRecord = detailRecord+inboundFileUtils.addField(patient_LastName.get("MEME_LAST_NAME"), startPosition, endPosition);
					 break;
				case "DATE_OF_BIRTH":
				 detailRecord = detailRecord+inboundFileUtils.addField(patient_DOB.get("DOB"), startPosition, endPosition);
				 break;
				case "ACCUMULATOR_BALANCE_QUALIFIER_1":
				if(accumulatorType.equals("DED"))
					detailRecord = detailRecord+inboundFileUtils.addField("04", startPosition, endPosition);
				else if(accumulatorType.equals("OOP"))
					detailRecord = detailRecord+inboundFileUtils.addField("01", startPosition, endPosition);
				else
					System.out.println("Enter valid accumulator type in data sheet"); 
				
			break;
				case "ACCUMULATOR_NETWORK_INDICATOR_1":
				 detailRecord = detailRecord+inboundFileUtils.addField(networkInd, startPosition, endPosition);
				 break;
				case "ACCUMULATOR_APPLIED_AMOUNT_1":
			
				if(accumAmount.contains("."))
				{
					accumAmount=accumAmount.replace(".", "");
					accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
				}
				else if(accumAmount.equals("0"))
				{
					accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
				}
				else
				{
					accumAmount=accumAmount+"00";
					accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
				}
				detailRecord=detailRecord+accumAmount;
				break;
				case "ACTION_CODE_1":
				if(Double.parseDouble(accumAmount)>0)
					detailRecord = detailRecord+inboundFileUtils.addField("+",startPosition,endPosition);
				else if(Double.parseDouble(accumAmount)<0)
					detailRecord = detailRecord+inboundFileUtils.addField("-",startPosition,endPosition);	
				break;
				case "TRANSMISSION_ID":
				DateFormat dateFormat_transmissionID = new SimpleDateFormat("YYYYMMDDHHMMS");
				String date_transmissionID = dateFormat_transmissionID.format(todaysDate);
				detailRecord = detailRecord+inboundFileUtils.addField(date_transmissionID+"@"+otherUtilities.generateRandomNumber(8).toString(),startPosition,endPosition);			
			break;
				}
			}
		}	
		//To write the detail record of each subscriber in the output file
			outputFileBufferedWriter.write(detailRecord);
		//Enter the new line in the output file as per the file layout
			outputFileBufferedWriter.newLine();
			excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 6));
			totalRecords = totalRecords+1;
		detailRecord="";
		//To get test data from test data sheet
		sbsb_id = excelUtils.getCellData(testdataSheetIterator, 0);
		mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
		accumAmount = excelUtils.getCellData(testdataSheetIterator, 6);
		logger.log(LogStatus.INFO, "Subscriber data inserted: "+ sbsb_id );
			}
			
		}
		
		//Write Trailer
		String trailer="";
		//To iterate through each trailer field
		for(int mappingSheetIterator=195;mappingSheetIterator<=200;mappingSheetIterator++){
			//To retrieve start and end positions of each field
			excelUtils=new ExcelUtilsExtended(mappingSheet,"ESI_MappingSheet");
			startPosition=Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, startPositionColumn));
			endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, endPositionColumn));
			//To append field values to the trailer except for the default value fields
			if(!excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals("")){
				if(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals("Field not used"))
					trailer=trailer+inboundFileUtils.addField("",startPosition,endPosition);
				else
					trailer=trailer+inboundFileUtils.addField(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn),startPosition,endPosition);
			}
			else
			{
				if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("Record Count"))
					
					trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
				//append default values to the trailer string
				else
					trailer=trailer+inboundFileUtils.addField(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn),startPosition,endPosition);
			}
				
		}
		//write trailer to the output file
		outputFileBufferedWriter.write(trailer);
		//close writer
		outputFileBufferedWriter.close();
		outputFileWriter.close();
		
	}
		
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//report the total number of records and input file used
		logger.log(LogStatus.INFO, "Total number of records inserted: "+ totalRecords );
		logger.log(LogStatus.INFO, "Input data sheet used: "+ testDataPath );
		return outputFile;
}

}

