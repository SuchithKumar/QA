package com.bsc.qa.webservices.utility;




import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;

import org.apache.commons.lang3.StringUtils;

import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


public class OPTUMRXInboundFileUtility extends BaseTest{
	/**OPTUMRXInboundFile creates text file of OPTUMRX vendor as per the mapping sheet
	 * @param: test data sheet path
	 * @return output file
	 */
	public  File createOPTUMRXInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
		File outputFile=null;
		DBUtils dbUtils = new DBUtils();
		ExcelUtilsExtended excelUtils;
		CommonInboundFileUtility inboundFileUtils = new CommonInboundFileUtility();
		Date todaysDate = new Date();
		DateFormat dateFormat_detailRecord,dateFormat_Header;
		String currentDate_detailRecord,date_Header;
		Double totalAccumAmount = 0.00;
		Long totalRecords = 0L;
		FileWriter outputFileWriter = null;
		BufferedWriter outputFileBufferedWriter;
		String sbsb_id,mbr_sfx,benifit_year,dateOfService,coPay_UserInput,coIns_UserInput,ded_UserInput,fieldName,outputFilePath;
		int startPosition,endPosition,defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0;
		dateFormat_detailRecord = new SimpleDateFormat("dd-MMM-YYYY");
		 currentDate_detailRecord = dateFormat_detailRecord.format(todaysDate);
	
		 String date_filenameformat = inboundFileUtils.ASHP_OPTUMFileFormatDate();
		 //Retrieve mapping sheet from resource folder
		 String mappingSheet = "src//test//resources//VendorAccumInboundFileCreationTest.xlsx";
		excelUtils = new ExcelUtilsExtended(mappingSheet,"OPTUMRX_MappingSheet");
		
		//create output file
		outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\OPTUMRX_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
		outputFile = new File(outputFilePath);
	
		//Initialize writer
		 try {
			outputFileWriter = new FileWriter(outputFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 outputFileBufferedWriter = new BufferedWriter(outputFileWriter);

		 String OPTUMRXHeader = "";
		 try
		 { 
			 //Write header
			 //Retrieve field name values from mapping sheet and place the values in the output file
			for(int i=1;i<=5;i++)
			{
				//Retrieve start and end positions for each field 
				startPosition = Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
				 endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
				 
				String defaultValue = excelUtils.getCellData(i, 3);
				//append the header with default values in the mapping sheet
				if(!defaultValue.equals(""))
				{
					OPTUMRXHeader = OPTUMRXHeader+inboundFileUtils.addField(defaultValue,startPosition,endPosition);
					
				}
				else
				{
					//append header with file date field
					if(excelUtils.getCellData(i, fieldNameColumn).equals("FILE_DATE"))
					{
						dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
						date_Header = dateFormat_Header.format(todaysDate);
						OPTUMRXHeader = OPTUMRXHeader+inboundFileUtils.addField(date_Header,startPosition,endPosition);	
					}
					else
						OPTUMRXHeader = OPTUMRXHeader+inboundFileUtils.addField("",startPosition,endPosition);
				}
			}
			//To write header in the output file
			outputFileBufferedWriter.write(OPTUMRXHeader);
			//To enter the next line after the header as per the file layout
			outputFileBufferedWriter.newLine();
			
			//Write detail record
			
			//retrieve queries values from queries sheet
			excelUtils = new ExcelUtilsExtended(mappingSheet,"OPTUMRX_Queries");
			//To fetch queries from mapping sheet
			Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
			//To retrieve test data sheet		
			excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			 
			 //replace the queries with test data present in data sheet
			 int rowcount = excelUtils.getRowCount(null);
			 
			for(int testdataSheetIterator=1;testdataSheetIterator<=rowcount;testdataSheetIterator++)
			{
				sbsb_id=excelUtils.getCellData(testdataSheetIterator, 0);
				mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
				benifit_year = excelUtils.getCellData(testdataSheetIterator, 2);
				dateOfService = excelUtils.getCellData(testdataSheetIterator, 3);
				//networkInd = excelUtils.getCellData(testdataSheetIterator, 4);
				coPay_UserInput = excelUtils.getCellData(testdataSheetIterator, 5);
				coIns_UserInput = excelUtils.getCellData(testdataSheetIterator, 6);
				ded_UserInput = excelUtils.getCellData(testdataSheetIterator, 7);
				//replace the sub strings in queries with subscriber data
				Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, benifit_year, currentDate_detailRecord);
				//Retrieve subscribers details from database
				ResultSet groupID = dbUtils.getResultSet("facets", replacedQueries.get("0"));
				ResultSet relationshipCode = dbUtils.getResultSet("facets", replacedQueries.get("1"));
				ResultSet gender = dbUtils.getResultSet("facets", replacedQueries.get("2"));
				ResultSet memberLName = dbUtils.getResultSet("facets", replacedQueries.get("3"));
				ResultSet memberFName = dbUtils.getResultSet("facets", replacedQueries.get("4"));
				ResultSet member_MInitial = dbUtils.getResultSet("facets", replacedQueries.get("5"));
				ResultSet memberDOB = dbUtils.getResultSet("facets", replacedQueries.get("6"));
				ResultSet memberSSN = dbUtils.getResultSet("facets", replacedQueries.get("7"));
				ResultSet planCode = dbUtils.getResultSet("facets", replacedQueries.get("8"));
				
				OtherUtilities otherUtilities = new OtherUtilities();
				String detailRecord="";
				int resultCount=0;
				
				//In case if more than one group id exist for the same subscriber id, create record for both
				while(groupID.next() && relationshipCode.next() && gender.next() && memberLName.next() && memberFName.next() && member_MInitial.next() && memberDOB.next() && planCode.next() && memberSSN.next())
				{
					//To increment the count if subscriber data is present in Facets
					resultCount++;
					for(int maapingSheetIterator=6;maapingSheetIterator<=23;maapingSheetIterator++)
					{
						//retrieve field names, start position and end position from mapping sheet
						excelUtils= new ExcelUtilsExtended(mappingSheet,"OPTUMRX_MappingSheet");
						startPosition=Integer.parseInt(excelUtils.getCellData(maapingSheetIterator, startPositionColumn));
						endPosition=Integer.parseInt(excelUtils.getCellData(maapingSheetIterator, endPositionColumn));
						
						if(excelUtils.getCellData(maapingSheetIterator, defaultValueColumn).equals(""))
						{
							//Retrieve the field name of detail record and place the value in the output file
							fieldName = excelUtils.getCellData(maapingSheetIterator,fieldNameColumn);
						switch(fieldName){
						case "GROUP_ID":
						 	detailRecord=detailRecord+inboundFileUtils.addField(groupID.getString(1),startPosition,endPosition);
						 break;
						case "MEMBER_IDENTIFICATION_NUMBER":
						 		detailRecord=detailRecord+inboundFileUtils.addField(sbsb_id,startPosition,endPosition);
						 break;
						case "MEMBER_SUFFIX":
							 if(mbr_sfx.equals("0")||mbr_sfx.equals("1")||mbr_sfx.equals("2")||mbr_sfx.equals("3")||mbr_sfx.equals("4")||mbr_sfx.equals("5")||mbr_sfx.equals("6")||mbr_sfx.equals("7")||mbr_sfx.equals("8")||mbr_sfx.equals("9"))
							 {
									mbr_sfx = String.format('0'+mbr_sfx);
									detailRecord=detailRecord+inboundFileUtils.addField(mbr_sfx,startPosition,endPosition);
								 }
							 else
							 detailRecord=detailRecord+mbr_sfx;
						break;
						case "RELATIONSHIP_CODE":
							 detailRecord=detailRecord+inboundFileUtils.addField(relationshipCode.getString(1),startPosition,endPosition);
						break;
						case "GENDER":
							 detailRecord=detailRecord+inboundFileUtils.addField(gender.getString(1),startPosition,endPosition);
						break;
						case "VENDOR_UNIQUE_MEMBER_ID":
							 detailRecord=detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
							break;
						case "MEMBER_LAST_NAME":
							 detailRecord = detailRecord+inboundFileUtils.addField(memberLName.getString(1),startPosition,endPosition);
						break;
						case "MEMBER_FIRST_NAME":
							 detailRecord = detailRecord+inboundFileUtils.addField(memberFName.getString(1),startPosition,endPosition);
						break;
						case "MEMBER_MIDDLE_INIT":
							 detailRecord = detailRecord+inboundFileUtils.addField(member_MInitial.getString(1),startPosition,endPosition);
						break;
						case "MEMBER_DOB":
							 detailRecord = detailRecord+inboundFileUtils.addField(memberDOB.getString(1),startPosition,endPosition);
						break;
						case "CLAIM_ID":
							 detailRecord = detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
						break;
						case "DATE_OF_SERVICE":
							 detailRecord = detailRecord+inboundFileUtils.addField(dateOfService,startPosition,endPosition);
						break;
						case "MEMBER_ESSN":
							 detailRecord = detailRecord+inboundFileUtils.addField(memberSSN.getString(1),startPosition,endPosition);
						break;
						case "PLAN_CODE":
							 detailRecord = detailRecord+inboundFileUtils.addField(planCode.getString(1),startPosition,endPosition);
						break;
						case "COPAY_AMT":
							 if(coPay_UserInput.contains("."))
								{
									coPay_UserInput=coPay_UserInput.replace(".", "");
									coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
								}
								else if(coPay_UserInput.equals("0"))
								{
									coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
								}
								else
								{
									coPay_UserInput=coPay_UserInput+"00";
									coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
								}
							 detailRecord = detailRecord+coPay_UserInput;
						 break;
						case "COINS_AMT":
							 if(coIns_UserInput.contains("."))
								{
								 coIns_UserInput=coIns_UserInput.replace(".", "");
								 coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
								}
								else if(coIns_UserInput.equals("0"))
								{
									coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
								}
								else
								{
									coIns_UserInput=coIns_UserInput+"00";
									coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
								}
							 detailRecord = detailRecord+coIns_UserInput;
						 break;
						case "DED_AMT":
							 if(ded_UserInput.contains("."))
								{
								 ded_UserInput=ded_UserInput.replace(".", "");
								 ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput)); 
								}
								else if(ded_UserInput.equals("0"))
								{
									ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
								}
								else
								{
									ded_UserInput=ded_UserInput+"00";
									ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
								}
							 detailRecord = detailRecord+ded_UserInput;
						 break;
						case "FILLER":
							 detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
						break;
						}
						}
						 else
							 detailRecord = detailRecord+excelUtils.getCellData(maapingSheetIterator,defaultValueColumn);
					}
					//System.out.println(detailRecord);
					//Write detail record to the output file
					outputFileBufferedWriter.write(detailRecord);
					//Enter new line in the output file as per the file layout
					outputFileBufferedWriter.newLine();
					excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
					totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 5))+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 6))+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 7));
					totalRecords = totalRecords+1;
				detailRecord="";
				//To retrieve test data
				sbsb_id = excelUtils.getCellData(testdataSheetIterator, 0);
				mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
				coPay_UserInput = excelUtils.getCellData(testdataSheetIterator, 5);
				coIns_UserInput = excelUtils.getCellData(testdataSheetIterator, 6);
				ded_UserInput= excelUtils.getCellData(testdataSheetIterator, 7);
				}	
				//To check if subscriber is present in the Facets
				if(resultCount==0)
				{
					System.out.println("Mandatory field is missing or incorrect test data for row number: "+testdataSheetIterator+" in test data sheet"+testDataPath);
					logger.log(LogStatus.ERROR, "Incorrect test data/Incorrect input mandatory fields: "+ sbsb_id );
					//System.out.println("fail");
				}
				else
				{
					logger.log(LogStatus.INFO, "Subscriber data inserted: "+ sbsb_id );
				}	
			}
		
		//Write Trailer
			String trailer="";
			//To iterate through each trailer field in mapping sheet
			for(int i=24;i<=27;i++){
				excelUtils=new ExcelUtilsExtended(mappingSheet,"OPTUMRX_MappingSheet");
				startPosition=Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
				if(excelUtils.getCellData(i, defaultValueColumn).equals(""))
				{
					if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_RECORDS"))
					
						trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
					
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_AMOUNT"))
					{
						DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
						String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
						if(totalAccumAmount_trailer.contains("."))
						{
							totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
						}
						trailer=trailer+String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer));		
					}
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("FILLER"))
						trailer=trailer+inboundFileUtils.addField("", startPosition,endPosition);
				}
				else
					trailer=trailer+inboundFileUtils.addField(excelUtils.getCellData(i, defaultValueColumn),startPosition,endPosition);
					
			}
			//write trailer to the output file
			outputFileBufferedWriter.write(trailer);
			//close writer
			outputFileBufferedWriter.close();
			outputFileWriter.close();
			
			//report the total number of records and input file used
			logger.log(LogStatus.INFO, "Total number of records inserted: "+ totalRecords );
			logger.log(LogStatus.INFO, "Input data sheet used: "+ testDataPath );
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
			return outputFile;

}

}


