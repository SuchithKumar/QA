package com.bsc.qa.webservices.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.relevantcodes.extentreports.LogStatus;

public class OPTUMInboundFileUtility extends BaseTest
{
	/**OPTUMInboundFile creates text file of OPTUM vendor as per the mapping sheet
	 * @param: test data sheet path
	 * @return output file
	 */

public File createOPTUMInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
	File outputFile=null;
	DBUtils dbUtils = new DBUtils();
	CommonInboundFileUtility inboundFileUtils = new CommonInboundFileUtility();
	OtherUtilities otherUtilities = new OtherUtilities();
	ExcelUtilsExtended excelUtils;
	Date todaysDate = new Date();
	DateFormat dateFormat_Header;
	String date_Header;
	Double totalAccumAmount = 0.00;
	Long totalRecords = 0L;
	FileWriter outputFileWriter = null;
	BufferedWriter outputFileBufferedWriter;
	String sbsb_id,mbr_sfx,dateOfService,networkInd,accumulatorType,accumAmount,fieldName="",outputFilePath;
	int startPosition,endPosition,fieldLength,defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0;
	
	String date_filenameformat = inboundFileUtils.ASHP_OPTUMFileFormatDate();
	
	 //Retrieve mapping sheet from resources folder
	 String mappingSheet = "src//test//resources//VendorAccumInboundFileCreationTest.xlsx";
	excelUtils = new ExcelUtilsExtended(mappingSheet,"OPTUM_mappingSheet");
	
	//create output file
	//To check if test data sheet is OPTUMBSOFCA or OPTUM vendor
	if(testDataPath.contains("OPTUMBSOFCA") || testDataPath.contains("OPTUM_BSOFCA")){
	outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\OPTUM_ACCUMS_TO_BSOFCA_V3_"+date_filenameformat+".txt";
	outputFile = new File(outputFilePath);
	}
	else
	{
		outputFilePath = System.getenv("OUTPUT_VENDOR_FILEPATH")+"\\OPTUM_ACCUMS_TO_BSOFCA_V2_"+date_filenameformat+".txt";
		outputFile = new File(outputFilePath);
	}
	
	//Initialize writer
	 try {
		outputFileWriter = new FileWriter(outputFile);
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	 outputFileBufferedWriter = new BufferedWriter(outputFileWriter);
	 String OPTUMHeader = "";
	 
	//Write header
	 //Retrieve field name values from mapping sheet and place the values in the output file
	for(int mappingSheetIterator=1;mappingSheetIterator<=6;mappingSheetIterator++)
	{
		 startPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, startPositionColumn));
		 endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator, endPositionColumn));
		 fieldLength = endPosition-startPosition+1;
		String defaultValue = excelUtils.getCellData(mappingSheetIterator, 3);
		if(!defaultValue.equals(""))
		{
			OPTUMHeader = OPTUMHeader+inboundFileUtils.addField(defaultValue,startPosition,endPosition);
			
		}
		else
		{
			if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("File Date"))
			{
				dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
				date_Header = dateFormat_Header.format(todaysDate);
				OPTUMHeader = OPTUMHeader+inboundFileUtils.addField(date_Header,startPosition,endPosition);
				
			}
			else if(excelUtils.getCellData(mappingSheetIterator, fieldNameColumn).equals("Sequence Number"))
				OPTUMHeader = OPTUMHeader+StringUtils.rightPad("0", fieldLength, " ");
			else
				OPTUMHeader = OPTUMHeader+StringUtils.rightPad("", fieldLength, " ");
		}
	}
	outputFileBufferedWriter.write(OPTUMHeader);
	outputFileBufferedWriter.newLine();
	
	//Write detail record
	
	//retrieve queries from queries sheet
	
			excelUtils = new ExcelUtilsExtended(mappingSheet,"OPTUM_Queries");
			
			 Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
			 			
			 excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			//To get the subscriber count in the data sheet
			 int rowCount = excelUtils.getRowCount(null);
			 String detailRecord="";
			//To iterate through each field of the detail record in mapping sheet
			for(int testdataSheetIterator=1;testdataSheetIterator<=rowCount;testdataSheetIterator++)
			{
				//To retrieve test data sheet
				excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
				sbsb_id=excelUtils.getCellData(testdataSheetIterator, 0);
				mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
				//benifit_year = excelUtils.getCellData(testdataSheetIterator, 2);
				dateOfService = excelUtils.getCellData(testdataSheetIterator, 3);
				networkInd = excelUtils.getCellData(testdataSheetIterator, 4);
				accumulatorType = excelUtils.getCellData(testdataSheetIterator, 5);
				accumAmount = excelUtils.getCellData(testdataSheetIterator, 6);
				//String claimType = excelUtils_testDataSheet.getCellData(i, 7);
				
				//replace the sub strings in queries with subscriber data
				Map<String,String>	replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, "", "");
				//To retrieve subscriber details from database
				Map<String,String> memberNumber = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("0"));
				Map<String,String> member_FirstName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("2"));
				Map<String,String> member_LastName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("1"));
				Map<String,String> member_MiddleInitial = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("3"));;
				Map<String,String> member_DOB = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("4"));
				//To check if subscriber is not present in Facets
				if(memberNumber.size()==0 || member_FirstName.size()==0 || member_FirstName.size()==0 || member_LastName.size()==0 || member_DOB.size()==0)
				{
					System.out.println("Mandatory field is missing or incorrect test data for row number: "+testdataSheetIterator+" in test data sheet"+testDataPath);
					logger.log(LogStatus.ERROR, "Incorrect test data/Incorrect input mandatory fields: "+ sbsb_id );
					//System.out.println("fail");
				}
				else{
				excelUtils = new ExcelUtilsExtended(mappingSheet, "OPTUM_MappingSheet");
				//To iterate through each field of the detail record in mapping sheet
				for(int mappingSheetIterator=7;mappingSheetIterator<=24;mappingSheetIterator++)
				{
					//retrieve field names, start position and end position from mapping sheet
					startPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator,startPositionColumn));
					endPosition = Integer.parseInt(excelUtils.getCellData(mappingSheetIterator,endPositionColumn));
					//To append detail record string with the field values expect the default value fields
					if(excelUtils.getCellData(mappingSheetIterator, defaultValueColumn).equals(""))
					{		
						fieldName = excelUtils.getCellData(mappingSheetIterator, fieldNameColumn);
						switch (fieldName){
						case "Member Number":
							detailRecord = detailRecord+inboundFileUtils.addField(memberNumber.get("MEME_SSN"),startPosition,endPosition);
						break;
						case "Member First Name":
							detailRecord = detailRecord+inboundFileUtils.addField(member_FirstName.get("MEME_FIRST_NAME"),startPosition,endPosition);
						break;
						case "Member Last Name":
							detailRecord = detailRecord+inboundFileUtils.addField(member_LastName.get("MEME_LAST_NAME"),startPosition,endPosition);
						break;
						case "Member Middle Initial":
							detailRecord = detailRecord+inboundFileUtils.addField(member_MiddleInitial.get("MEME_MID_INIT"),startPosition,endPosition);
						break;
						case "Member DOB":
							detailRecord = detailRecord+inboundFileUtils.addField(member_DOB.get("DOB"),startPosition,endPosition);
						break;
						case "Date of Service":
							detailRecord = detailRecord+inboundFileUtils.addField(dateOfService,startPosition,endPosition);
						break;
						case "Benefit Level":
							detailRecord = detailRecord+inboundFileUtils.addField(networkInd,startPosition,endPosition);
						break;
						case "Accumulator Type":
							detailRecord = detailRecord+inboundFileUtils.addField(accumulatorType,startPosition,endPosition);
						break;
						case "Claim ID":
							detailRecord = detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(15).toString(),startPosition,endPosition);
						break;
						case "Adjustment Indicator":
							detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
						break;
						case "Level of Care":
							detailRecord = detailRecord+inboundFileUtils.addField("0",startPosition,endPosition);
						break;
						case "Multi-Customer ID":
						case "Dependent Indicator":
						case "Filler":
							detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
						break;
						case "Amount":
							if(accumAmount.contains("."))
							{
								accumAmount=accumAmount.replace(".", "");
								accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
							}
							else if(accumAmount.equals("0"))
							{
								accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
							}
							else
							{
								accumAmount=accumAmount+"00";
								accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
							}
							detailRecord=detailRecord+accumAmount;
						break;
					}
				}
				else
						detailRecord = detailRecord+inboundFileUtils.addField(excelUtils.getCellData(mappingSheetIterator,defaultValueColumn),startPosition,endPosition);
			}
				//To write detail record of subscriber in the output file
				outputFileBufferedWriter.write(detailRecord);
				//To enter the next line after each subscriber detail record as per the file layout
				outputFileBufferedWriter.newLine();
				excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
				totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(testdataSheetIterator, 6));
				totalRecords = totalRecords+1;
			detailRecord="";
			sbsb_id = excelUtils.getCellData(testdataSheetIterator, 0);
			mbr_sfx = excelUtils.getCellData(testdataSheetIterator, 1);
			accumAmount = excelUtils.getCellData(testdataSheetIterator, 6);
			logger.log(LogStatus.INFO, "Subscriber data inserted: "+ sbsb_id );
				}				
		}
			//write Trailer
			String trailer="";
			totalRecords = totalRecords+2;
			excelUtils = new ExcelUtilsExtended(mappingSheet, "OPTUM_MappingSheet");
			for(int i=25;i<=28;i++)
			{
				//To retrieve start and end positions of each field
				startPosition = Integer.parseInt(excelUtils.getCellData(i,startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(i,endPositionColumn));
				//To append field values to the trailer except for the default value fields
				if(excelUtils.getCellData(i, defaultValueColumn).equals(""))
				{	
					if(excelUtils.getCellData(i, fieldNameColumn).equals("Total Records"))
						trailer=trailer+inboundFileUtils.addField(String.format("%0"+(endPosition-startPosition+1)+"d",totalRecords), startPosition, endPosition);
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("Total Amount"))
					{
						DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
						String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
						
						if(totalAccumAmount_trailer.contains("."))
						{
							totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
						}
						trailer=trailer+inboundFileUtils.addField(String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer)),startPositionColumn, endPositionColumn);
					}
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("Filler"))
						trailer=trailer+inboundFileUtils.addField("",startPosition, endPosition);
				}
				else
					//append default values to the trailer string
					trailer=trailer+inboundFileUtils.addField(excelUtils.getCellData(i, defaultValueColumn), startPosition, endPosition);
			}
			//write trailer to the output file
			outputFileBufferedWriter.write(trailer);
			//close writer
			outputFileBufferedWriter.close();
			outputFileWriter.close();
			
			//report the total number of records and input file used
			logger.log(LogStatus.INFO, "Total number of records inserted: "+ (totalRecords-2));
			logger.log(LogStatus.INFO, "Input data sheet used: "+ testDataPath );
		return outputFile;
}
}			
	

						
		
			


		

