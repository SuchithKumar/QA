package com.bsc.qa.PCPNotification.XmlToPdfValidator;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bsc.qa.PCPNotification.XmlToPdfValidator.ExcelUtilities;

public class XMLParse  {
	
	private static DocumentBuilder dBuilder;
	private static HashMap<Integer, String> collNumCellValueMap = new HashMap<Integer, String>();
	private static Document doc;
	private static int execNo_CollNum_Datasheet = 0;
	private static int elementName_CollNum_Datasheet = 1; 
	private static int xpath_Datasheet = 2;
	private static int expectedValue_CollNum_Datasheet = 3;
	private static int rowNum_Datasheet = 0;
	public static void xmlSetup(String xmlPath) {
		File fXmlFile=new File(xmlPath);
		//ExcelUtilities.setUp();
		DocumentBuilderFactory dbFactory= DocumentBuilderFactory.newInstance();
		
		try {
			dBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			
			e.printStackTrace();
		}
		
		try {
			doc = dBuilder.parse(fXmlFile);
		} catch (SAXException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}
	public static void  nodeExtraction( String subscriberId, String execNo, String sheetName_Datasheet) {
		NodeList PagesList=doc.getElementsByTagName("*");
		
		System.out.println("xml tags are "+PagesList.getLength());
		for(int nodeNo =0;nodeNo<PagesList.getLength();nodeNo++){
		Node node = (Node)PagesList.item(nodeNo);
		
		if(node.hasAttributes())

		{
			NamedNodeMap attributesList=node.getAttributes();
			for(int attribute_Number=0;attribute_Number<attributesList.getLength();attribute_Number++){
				Attr attr=(Attr) attributesList.item(attribute_Number);
				String attributeName=attr.getNodeName();
				String attributeValue=attr.getNodeValue();
				
				//String elementType="Attribute";
				
				//ExcelUtilities.setCellData(attributeName,attributeValue,elementType,rowNo++);
				
				//System.out.println("AttributeName: "+attributeName+"  attributeValue:"+attributeValue);
				
				if(attributeValue.equals(subscriberId)){
				
						
					if(hasChildElements((Element)node)){
						getElementAtttributes((Element)node);
							getChildElements((Element)node,execNo,sheetName_Datasheet);
					   }
					}
			}	
			
		}
		
		}
		
	}
	
	private static String getXPath(Node node) {
		 Node parent = node.getParentNode();
		    if (parent == null)
		    {
		        return "";
		    }
		    return getXPath(parent) + "/" + node.getNodeName();
		
	}

	private static void getChildElements(Element nNode, String execNo, String sheetName) {
		NodeList children=nNode.getChildNodes();
		String xPath = getXPath(nNode);
		String Value = null;
		System.out.println("The xpath is "+xPath);
		for(int i=0;i<children.getLength();i++){
				Node node=(Node) children.item(i);
				
				
					if(node.getNodeType()==Node.ELEMENT_NODE){
						if(hasChildElements((Element)node)){
							
								//childCount++;
								getElementAtttributes((Element)node);
								getChildElements((Element)node,execNo,sheetName);
						   }else{ 
							 	getValuesOfElement((Element)node,execNo,sheetName);
							    }
					   }
}
		
		
	}

	

	private static void getElementAtttributes(Element node) {
		if(node.hasAttributes()){
			NamedNodeMap attributesList=node.getAttributes();
				for(int attribute_Number=0;attribute_Number<attributesList.getLength();attribute_Number++){
					Attr attr=(Attr) attributesList.item(attribute_Number);
					String attributeName=attr.getNodeName();
					String attributeValue=attr.getNodeValue();
					
					//String elementType="Attribute";
					
					String xPath = getXPath(node);
					
					System.out.println("The xpath is "+xPath);
					
					//ExcelUtilities.setCellData(attributeName,attributeValue,elementType,rowNo++);
					
					System.out.println("AttributeName: "+attributeName+"  attributeValue:"+attributeValue);
				}
		}
		
	}

	private static void getValuesOfElement(Element node, String execNo, String sheetName) {
		String elementName=node.getNodeName();
		String elementValue=node.getTextContent();
		
		String xPath = getXPath(node);
		
		System.out.println("The xpath is "+xPath);
		//String elementType="Element";
		
		//ExcelUtilities.setCellData(elementName,elementValue,elementType,rowNo++);
			System.out.println("Element:"+node.getNodeName()+
			"            |           Value:"+node.getTextContent());
			
			updateDatasheet(execNo,xPath,elementName,elementValue,sheetName);
			
	}

	private static boolean hasChildElements(Element el) {
		
		NodeList children=el.getChildNodes();
		for(int i=0;i<children.getLength();i++){
		if(children.item(i).getNodeType()==Node.ELEMENT_NODE)
			return true;
		}
	return false;
	}
	
	private static void updateDatasheet(String executionNo, String xpath,
			String element, String expectedXmlValue, 
			String dataSheetName) {
		
		
		
		
		
		if((!element.equalsIgnoreCase("insert_string"))&&(!element.equalsIgnoreCase("special_handling_code"))){
		
		collNumCellValueMap.put(execNo_CollNum_Datasheet, executionNo);//execution No Map
		
		collNumCellValueMap.put(xpath_Datasheet, xpath);//Eob Map
		
		collNumCellValueMap.put(elementName_CollNum_Datasheet, element);//Element Map
		
		collNumCellValueMap.put(expectedValue_CollNum_Datasheet, expectedXmlValue);
		
		ExcelUtilities.CreateRowAndCell(dataSheetName,
				rowNum_Datasheet, collNumCellValueMap);
		
		rowNum_Datasheet++;
		
		}
		
		//expected Value Map
		
		
		
		//Below one is to create row and columns in datasheet
		
		
	}




		}
	

