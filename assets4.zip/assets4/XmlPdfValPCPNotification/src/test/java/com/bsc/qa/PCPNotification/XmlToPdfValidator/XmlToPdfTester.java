package com.bsc.qa.PCPNotification.XmlToPdfValidator;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.ExcelUtilities;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.pdfExtractor;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.ConstantVariables;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.drivercode;
import com.bsc.qa.PCPNotification.XmlToPdfValidator.XMLParse;

import com.relevantcodes.extentreports.LogStatus;

public class XmlToPdfTester  {

	public static Process process;
	ConstantVariables constantVariables = new ConstantVariables();
	// This method is to retrieve the xml data using UFT script
	@BeforeClass
	public void xmlDataRetrieve() throws IOException, InterruptedException {
		System.out.println("In BeforeClass");
		Path path = Paths.get("test-output\\BSC-reports\\"+constantVariables.timestamp);
		if(!Files.exists(path))
		{
		Files.createDirectories(path);
		}
		ExcelUtilities.copyFile(constantVariables.sourceDatasheet,
				constantVariables.destinationDatasheet);		
		
		
	}

	// This method is to setup the excelfile and retrieve data from Input and
	// Subscriber sheet
	@BeforeMethod
	public void Setup() throws Exception {
		
			ExcelUtilities.setUpExcel(); // Set up the Excel file
			// Below method is for retrieving the data from Input sheet.
			drivercode.retrieveInputData();
			// Below method is for retrieving the data from Subscriber sheet
			drivercode
					.retrieveDataFromMetaData_Sheet("PCPNotification");
			

	}
	
	
	

	// This method is to compare the XML data with PDF data
	@Test
	public void compareXmlToPdf() throws Exception, IOException, Throwable {
		drivercode.retrieveDataFromDatasheet();
		//ExcelUtilities.writeToWorkBook();
		//System.out.println("Executing the Framework!!!");

	}

	// This method is to set the results in Excel
	@AfterMethod
	public void setResults() throws Exception {
		System.out.println("In After Method");
		ExcelUtilities.writeToWorkBook();
		ExcelUtilities.copyFile(constantVariables.sourceFile, constantVariables.destinationFile);
		
	}

	// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ALWAYS
	// KEEP AS
	// FOOTER%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	// Required method for every test Class for reporter to operate properly
	/**
	 * @Override run is a hook before @Test method
	 */
	

	// This method is to close the PDF and excel
	@AfterClass
	public void closeFiles() throws Exception {
		pdfExtractor.closefile();
		ExcelUtilities.closefile();
	}

	// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ALWAYS
	// KEEP AS
	// FOOTER%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

} // Class
