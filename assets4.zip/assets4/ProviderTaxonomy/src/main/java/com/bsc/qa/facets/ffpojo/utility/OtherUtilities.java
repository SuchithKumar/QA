package com.bsc.qa.facets.ffpojo.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

import org.apache.commons.io.FileUtils;
import org.testng.asserts.SoftAssert;

import com.bsc.bqsa.AutomationStringUtilities;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;

public class OtherUtilities extends BaseTest{
	
	public static void validate(Map<String, String> flatFileValuesMap,	Map<String, String> queryDataMap,SoftAssert softAssertion) {
		//SoftAssert softAssertion= new SoftAssert();
		for(String key:queryDataMap.keySet()){
			if(flatFileValuesMap.containsKey(key)){
				
				OtherUtilities.validateActualAndExpectedValues(key,flatFileValuesMap.get(key),queryDataMap.get(key),softAssertion);
			  System.out.println("Acctual Value: " + flatFileValuesMap.get(key) + "Expected Value: " + queryDataMap.get(key));
			}else{
				 softAssertion.assertTrue(flatFileValuesMap.containsKey(key), "Element " + key + " is not present" );
				//softAssertion.assertEquals(null,queryDataMap.get(key).toString().trim(),"<<" + key + ">> " );
				 logger.log(LogStatus.INFO, key+" is not present Input File");				 
			}
			
		}
		
		
	}


	private static void validateActualAndExpectedValues(String key,String flatFileValue,String dbValue,SoftAssert softAssertion) {
		
		
	flatFileValue = flatFileValue.trim();		
	if(dbValue != null )	{
	dbValue = dbValue.trim();
	}
	if(flatFileValue.equalsIgnoreCase("NO"))
		flatFileValue = "N";
	if(flatFileValue.equalsIgnoreCase("YES"))
					flatFileValue = "Y";
		
	switch (key){
	
	    case "APPLICANTBIRTHDATE":
					softAssertion.assertTrue(flatFileValue.contains(dbValue.substring(0, 4)), "Element " + key + " is not present" );
					logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
					break;
		case "COCI_SSN":
					softAssertion.assertTrue(flatFileValue.contains(dbValue.substring(5)), "Element " + key + " is not present" );
					logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue.substring(5)));
					break;
		case "DOLLOR_AMMOUNT": 
					String strdbValue;
					int intstrdbValue;
					if(dbValue.contains(".")){
						 //strdbValue = dbValue.replace(".", "");
						 String[] arrdbvalue = dbValue.split(".");
						 strdbValue = arrdbvalue[0] + (arrdbvalue[1] + "00".substring(0, 2));
						 strdbValue = "000000000000" + strdbValue;				
					}else{
						 strdbValue = "000000000000" + dbValue + "00";				
					}
					 intstrdbValue = strdbValue.toString().length();
					 strdbValue = strdbValue.substring(intstrdbValue - 10);
					 softAssertion.assertEquals(flatFileValue,strdbValue, "<<" + key + ">> " );
					logger.log(LogStatus.INFO," Field Name: " + key + ", Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + strdbValue));
					break;
		case "FIRST_INITIAL_OF_MIDDLE_NAME":
					softAssertion.assertTrue(flatFileValue.contains(dbValue.substring(5)), "Element " + key + " is not present" );
					logger.log(LogStatus.INFO," Field Name: " + key + ", Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
					break;
		case "COCE_TERM_DT":
					if(flatFileValue!=null&&flatFileValue.length()<1){
						flatFileValue = "99991231";
					}
					softAssertion.assertEquals(flatFileValue,dbValue, "<<" + key + ">> " );
					logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
					break;
		case "COCI_FIRST_NAME":
					if(flatFileValue != null && flatFileValue.length() > 0)
						if(flatFileValue.length() > 10){
							flatFileValue = flatFileValue.substring(0, 10);	
						}						
					softAssertion.assertTrue(dbValue.contains(flatFileValue), "Element " + key + " is not present" );	
					logger.log(LogStatus.INFO," Field Name: " + key + ", Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
					break;
		case "COCE_SUSP_PYMT_IND":
					softAssertion.assertTrue(dbValue.equalsIgnoreCase("N"), "Element " + key + " is not present" );
					logger.log(LogStatus.INFO," Field Name: " + key + ", Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
					break;			
		case "COAD_ADDR2":
					softAssertion.assertTrue(dbValue.trim().equalsIgnoreCase(flatFileValue.trim()), "Element " + key + " is not present" );
					logger.log(LogStatus.INFO," Field Name: " + key + ", Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
					break;				
		case "COCI_LST_NAME":
		case "COCI_MID_INIT":
					softAssertion.assertTrue(dbValue.contains(flatFileValue), "Element " + key + " is not present" );
					logger.log(LogStatus.INFO," Field Name: " + key + ", Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
					break;
		case "LOBD_ID":
			softAssertion.assertTrue(dbValue.contains(flatFileValue), "Element " + key + " is not present" );	
			logger.log(LogStatus.INFO," Field Name: " + key + ", Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
			break;
		case "APPLICATIONSSN":
			softAssertion.assertTrue(dbValue.equalsIgnoreCase(flatFileValue.replace("-","")), "Element " + key + " is not present" );
			logger.log(LogStatus.INFO," Field Name: " + key + ", Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
			break;
		case "SUBMITTIME":
			softAssertion.assertTrue(flatFileValue.contains(dbValue), "Element " + key + " is not present" );	
			logger.log(LogStatus.INFO," Field Name: " + key + ", Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
			break;
		default :
					if(dbValue==null){
						dbValue="";
					}
				    softAssertion.assertEquals(flatFileValue,dbValue, "<<" + key + ">> " );
					logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
					break;
			
		}
	
		
	}
	
	
	

	
	
	
	
	/// This function will display test case details mentioned in test data sheet in HTML report
	public static void printTestCaseDeatilsInReport(Map<String, String> data) {		
		
		String strSUCName= data.get("SUC Name").toString();		
		String strTestCaseId = data.get("Test Case ID").toString();		
		String strTestCaseName = data.get("Test Case Name").toString();		
		//String strInputFileName = data.get("Input File Name").toString();
		logger.log(LogStatus.INFO," SUC Name: " + strSUCName + ", Test Case ID: " + strTestCaseId + ", Test Case Name: " + strTestCaseName);
		//logger.log(LogStatus.INFO," Input File Name: " + strInputFileName);
	}
	

	// SRD interface Care 1st database record validations
	public static void SRDProducerDemographicCareDetails(Map<String, String> SourceCareMap,	List<Map<String, String>> listOfRecords,SoftAssert softAssertion){
		
		int intCare1stRecords = listOfRecords.size();
		int intCounter1 = 0,intCounter2 = 0,intCounter3 = 0;
		Map<String,String>queryCare1stDataMap=new HashMap<String,String>();//Dictionary for db query columns and values
		for (int intICounter = 0;intICounter < intCare1stRecords;intICounter++){
			queryCare1stDataMap=listOfRecords.get(intICounter);
			if(queryCare1stDataMap.get("COCE_ID").endsWith("55")){	
				queryCare1stDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceCareMap,queryCare1stDataMap,softAssertion);
				intCounter1 = intCounter1 + 1;
			}
			else if(queryCare1stDataMap.get("COCE_ID").endsWith("56") ){
				queryCare1stDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceCareMap,queryCare1stDataMap,softAssertion);
				intCounter2 = intCounter2 + 1;
			}
			else if(queryCare1stDataMap.get("COCE_ID").endsWith("57") ){
				queryCare1stDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceCareMap,queryCare1stDataMap,softAssertion);
				intCounter3 = intCounter3 + 1;
			}
			else {
				softAssertion.fail("Invalid data present in the FACETS database");
				logger.log(LogStatus.INFO,"Invalid data present in the FACETS database");
			}
				
			
			
		}
		if (intCounter1 != 1 || intCounter2 != 1 || intCounter3 != 1){
			softAssertion.fail("Care1st three records are not present in the FACETS database");
			logger.log(LogStatus.INFO,"Care1st three records are not present in the FACETS database");
		}
	}
	
	// SRD interface Care 1st database record validations
	public static void PSPProducerDemographicCareDetails(Map<String, String> SourceBscMap,	List<Map<String, String>> listOfRecords,SoftAssert softAssertion){
		
		int intCare1stRecords = listOfRecords.size();
		int intCounter1 = 0,intCounter2 = 0,intCounter3 = 0,intCounter4 = 0,intCounter5 = 0,intCounter6 = 0,intCounter7 = 0;
		int	intCounter8 = 0,intCounter9 = 0,intCounter10 = 0;
		Map<String,String>queryBscDataMap=new HashMap<String,String>();//Dictionary for db query columns and values
		for (int intICounter = 0;intICounter < intCare1stRecords;intICounter++){
			queryBscDataMap=listOfRecords.get(intICounter);
			
			if(queryBscDataMap.get("COCE_ID").endsWith("00")){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter1 = intCounter1 + 1;
			}
			else if(queryBscDataMap.get("COCE_ID").endsWith("01") ){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter2 = intCounter2 + 1;
			}
			else if(queryBscDataMap.get("COCE_ID").endsWith("02") ){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter3 = intCounter3 + 1;
			}
			else if(queryBscDataMap.get("COCE_ID").endsWith("03") ){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter4 = intCounter4 + 1;
			}
			else if(queryBscDataMap.get("COCE_ID").endsWith("04") ){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter5 = intCounter5 + 1;
			}
			else if(queryBscDataMap.get("COCE_ID").endsWith("05") ){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter6 = intCounter6 + 1;
			}
			else if(queryBscDataMap.get("COCE_ID").endsWith("06") ){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter7 = intCounter7 + 1;
			}
			else if(queryBscDataMap.get("COCE_ID").endsWith("07") ){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter8 = intCounter8 + 1;
			}
			else if(queryBscDataMap.get("COCE_ID").endsWith("08") ){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter9 = intCounter9 + 1;
			}
			else if(queryBscDataMap.get("COCE_ID").endsWith("09") ){
				queryBscDataMap.remove("COCE_ID");
				OtherUtilities.validate(SourceBscMap,queryBscDataMap,softAssertion);
				intCounter10 = intCounter10 + 1;
			}			
			else {
				softAssertion.fail("Invalid data present in the FACETS database");
				logger.log(LogStatus.INFO,"Invalid data present in the FACETS database");
			}
				
			
			
		}
		if (intCounter1 != 1 || intCounter2 != 1 || intCounter3 != 1 || intCounter4 != 1 || intCounter5 != 1|| intCounter6 != 1|| intCounter7 != 1|| intCounter8 != 1|| intCounter9 != 1|| intCounter10 != 1){
			softAssertion.fail("Care1st ten records are not present in the FACETS database");
			logger.log(LogStatus.INFO,"Care1st three records are not present in the FACETS database");
		}
	}


	public static void SRRProducerDemographicCareDetails(Map<String, String> SourceBscMap, String queryFromDataSheet,	String SALES_REP_ID,DBUtils objDBUtility,SoftAssert softAssertion) throws SQLException{
		
		 String SQLQuery=queryFromDataSheet.replace( "Parameter3",SourceBscMap.get(SALES_REP_ID).trim());//replacing query parameter in Sql query
		
		List<Map<String, String>> listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
		 
		 if(listOfRecords.size() > 0){
			softAssertion.assertTrue(true,"Tax ID (" + SourceBscMap.get("TAX_ID") + ") and Sales Rep (" + SourceBscMap.get(SALES_REP_ID) + ") relation is present in the FACETS database");
			logger.log(LogStatus.INFO,"Tax ID (" + SourceBscMap.get("TAX_ID") + ") and Sales Rep (" + SourceBscMap.get(SALES_REP_ID) + ") relation is present in the FACETS database");
		 }else{
			softAssertion.assertTrue(false,"Tax ID (" + SourceBscMap.get("TAX_ID") + ") and Sales Rep (" + SourceBscMap.get(SALES_REP_ID) + ") relation  is NOT present in the FACETS database");
			logger.log(LogStatus.INFO,"Tax ID (" + SourceBscMap.get("TAX_ID") + ") and Sales Rep (" + SourceBscMap.get(SALES_REP_ID) + ") relation is NOT present in the FACETS database");
		 }
	}

	
	public static void PSPTableValidation(String strTestCaseID,String arrSQLQuery[],DBUtils objDBUtility,SoftAssert softAssertion) throws SQLException{
		int intRecordSize = 0;
		 for(int i=2;i<9;i++){
			 List<Map<String,String>> listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[i]);//queryDataMap
			 if(i==2 || i==3){
				 intRecordSize = 1;
			 }else if(i==4 || i==6 || i==7 || i==8){
				 intRecordSize = 13;
			 }else if(i==5){
				 intRecordSize = 39;
			 }
			 if(strTestCaseID.equalsIgnoreCase("TC006") && (i==4 || i==7 || i==8 || i== 6))
				 intRecordSize = 10;	
			 else if(strTestCaseID.equalsIgnoreCase("TC006") && i==5)
				 intRecordSize = 30;
			 else if(strTestCaseID.equalsIgnoreCase("TC004") && (i==4 || i==7 || i==8 || i== 6))
				 intRecordSize = 10;
			 else if(strTestCaseID.equalsIgnoreCase("TC004") && i==5)
				 intRecordSize = 30;
			 if(listOfRecords.size() == intRecordSize ){
					softAssertion.assertTrue(true, " Records " + intRecordSize + " are present in this query " + arrSQLQuery[i] + " in the FACETS database");
					logger.log(LogStatus.INFO," Records " + intRecordSize + " are present in this query " + arrSQLQuery[i] + " in the FACETS database");
				 }else{
					softAssertion.assertTrue(false," Actual records " + listOfRecords.size() + " expected records " + intRecordSize + " records are NOT present in this query " + arrSQLQuery[i] + " in the FACETS database");
					logger.log(LogStatus.INFO," Actual records " + listOfRecords.size() + " expected records " + intRecordSize + " records are NOT present in this query " + arrSQLQuery[i] + " in the FACETS database");
			}
		 }
	}
	public static void downloadFileFromWinSCP(String strUername,String strPassword,String strServer,String strLocation, String strFilename) throws Exception {
		
		String fileName = System.getProperty("user.dir")+"\\src\\test\\resources\\WinSCP.txt";
		String line="",Command="",sAfterUser,sAfterPass,sAfterServer,sAfterFileLocation,sAfterFilename;
		
		FileReader fileReader = new FileReader(fileName);

        BufferedReader bufferedReader = new BufferedReader(fileReader);

        while((line = bufferedReader.readLine()) != null) {Command = line;}
        
        strPassword = AutomationStringUtilities.decryptValue((strPassword.trim()));
        
        sAfterUser = Command.replace("WINSCP_USER_NAME", strUername);
        sAfterPass = sAfterUser.replace("WINSCP_USER_PASS", strPassword);
        sAfterServer = sAfterPass.replace("WINSCP_SERVER", strServer);
        sAfterFileLocation = sAfterServer.replace("FILE_LOCATION", strLocation);
        sAfterFilename = sAfterFileLocation.replace("FILE_NAME", strFilename);
        
        bufferedReader.close();
        
		File file = new File(System.getProperty("user.home") + "//Desktop//command.bat");
        FileUtils.writeStringToFile(file, sAfterFilename);
        Thread.sleep(5000);
            
		//For downloading Extract file, Batch file is being used
		try {
			String[] command = {"cmd.exe", "/C","Start",System.getProperty("user.home") + "//Desktop//command.bat"};
            Process p =  Runtime.getRuntime().exec(command);
            Thread.sleep(10000);
            Runtime.getRuntime().exec("taskkill /f /im cmd.exe") ;
            logger.log(LogStatus.INFO,"Taxonomy File Extraction is completed Successfully.");
            logger.log(LogStatus.INFO,"Taxonomy File Downloaded.");
            p.destroy();
        } catch (IOException ex) {
        	ex.printStackTrace();
        	logger.log(LogStatus.FAIL, "Error downloading file from Server location or File not found !!");
        }
		
		//Following code for unzipping the file.
		Thread.sleep(10000); 
        ZipFile zipFile = new ZipFile(System.getProperty("user.home") + "//Desktop//file//"+strFilename);
        zipFile.extractAll(System.getProperty("user.home") + "//Desktop//file//");
		Thread.sleep(5000);		
		logger.log(LogStatus.INFO,"Successfully Extracted Extract file - "+strFilename);
		
	}

}


