package com.bsc.qa.facets.tests;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.relevantcodes.extentreports.LogStatus;

public class BscaProviderTaxonomyTest extends BaseTest implements IHookable{
	private static String filePath,sheetName,fileFieldAndDBColumnMappingFilePath,resultsDestinationFolderPath;
    private static String rootLocationOfInputFiles;
	private static DBUtils objDBUtility;//reference for dbUtils class
	public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
	private static Path path,inputDataPath;// input data folder path
	private static	Map<String,String>queryDataMap=new HashMap<String,String>();
	private static	Map<String,String>queryDataMapWPRA=new HashMap<String,String>();//Dictionary for db query columns and values
	private static	Map<String,String>queryDataMapWPRB=new HashMap<String,String>();
	private static	Map<String,String>queryDataMapStage=new HashMap<String,String>();
	private static	List<Map<String,String>>listOfRecords=new ArrayList<Map<String,String>>();//list or all records in flat files
	private static	List<Map<String,String>>listOfRecordsfromWPRA=new ArrayList<Map<String,String>>();
	private static	List<Map<String,String>>listOfRecordsfromWPRB=new ArrayList<Map<String,String>>();
	private static	List<Map<String,String>>listOfRecordsfromStaging=new ArrayList<Map<String,String>>();
	private static	List<Map<String,String>>listOfRecordsFromFlatFile=new ArrayList<Map<String,String>>();
	private static List<String> listFlatfileString = new ArrayList<String>();
	/*This static variables getting used through out multiple testcases*/
	private static 	String SUCName;
	static int iMatcRecCount,iMatcRecCountWPR,iMatcRecCountStage;
	static String testFlatFileCompletePath="";
	static int iRecordCountFlatfile=0;
	static int iRecordCountPIMSDB=0;
	static int iRecordCountWPRADB = 0;
	static int iRecordCountWPRBDB = 0;
	static String WPRAqueryFromDataSheet="";
	static String WPRBqueryFromDataSheet="";
	static String sExtractFileName="";
	static String sFileName=""; 
	
	//*************************************** TEST METHODS************************
	
	/**
	 * Validating - Data from PROPS tables is matching the data extracted into file.
	 * 
	 * @param data
	 *            - This is a Map of data related to testcase.
	 * 
	 * @return - void
	 */ 
	@Test(dataProvider = "masterDataProvider")
	private static void ProviderTaxonomy_TC002(Map<String, String> data) {
		
		iMatcRecCount = 0 ;
		iMatcRecCountWPR = 0;
		iMatcRecCountStage = 0;
		String sPIMSDBName="",sPIMSDBUser="",sPIMSDBPass="",sPIMSDBServer="",sPIMSDBPort="";
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			System.out.println("Starting of ProviderTaxonomy Validation..!!");
			
			SUCName=data.get("SUC Name").toString();	
			String parameter1= data.get("Query parameter1").toString();//getting query parameter form data sheet
			String sWinSCPCreds=data.get("WinSCP_Creds").toString();
			
			String sFileLocationAndName=data.get("FileLocationAndName").toString(); 
			String sFileLocation = (sFileLocationAndName.split("\\|"))[0];
			sFileName = (sFileLocationAndName.split("\\|"))[1];
			
			String WinUser = (sWinSCPCreds.split("\\|"))[0];
			String WinPass = (sWinSCPCreds.split("\\|"))[1];
			String WinServer = (sWinSCPCreds.split("\\|"))[2];
			
			sExtractFileName=data.get("Input File Name").toString();
			
			/*Downloading and Extracting files from Network location. This function downloads extract file mentioned in the testdata.xls and stores in the user machine
			which can be further read and compared against database table data*/ 
			OtherUtilities.downloadFileFromWinSCP(WinUser,WinPass,WinServer, sFileLocation, sFileName);
			
			testFlatFileCompletePath = System.getProperty("user.home") + "//Desktop//file//"+sExtractFileName;
			
			/*mapping functionality as extract file doesn't have headers, 
			As there are no headers present in the Extract file we are mapping each column with it's appropriate header name*/
			String mappingSheetName="ProviderTaxonomy";
			listOfRecordsFromFlatFile=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\|",testFlatFileCompletePath,fileFieldAndDBColumnMappingFilePath,mappingSheetName);
			
			//SqlQuery contains two queries delimited by pipe symbol. one is for PIMS to Extract file another is for Extract file to WPR Table
			//data validations
			String queryFromDataSheet = data.get("SqlQuery").toString().split("\\|")[0];
			String stagequeryFromDataSheet = data.get("SqlQuery").toString().split("\\|")[1];//getting Sql query form data sheet
			
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim());//replacing query parameter in Sql query
			
			String PIMSDB = data.get("PIMS_DB");
			
			String arrPIMSDB [] = PIMSDB.toString().split("\\|");
			
			/*The realated information needed for connecting to database is given here, all 5 fields information is needed to connect to database.*/
			if (arrPIMSDB.length==5)
			{
			sPIMSDBName = arrPIMSDB[0];
			sPIMSDBUser = arrPIMSDB[1];
			sPIMSDBPass = arrPIMSDB[2];
			sPIMSDBServer = arrPIMSDB[3];
			sPIMSDBPort = arrPIMSDB[4];
			}else{
				System.out.println("wrong number of Arguments for connecting PROPS DB !!");
				logger.log(LogStatus.FAIL, "Wrong Number of Arguments to connect to PROPS DB !!");
			}
			
			//connecting DB and executing the query on mentioned DB
			objDBUtility = new DBUtils(sPIMSDBName, sPIMSDBUser, sPIMSDBPass, sPIMSDBServer, sPIMSDBPort);
			
			listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//result set to list of dictionaries
			listOfRecordsfromStaging = objDBUtility.resultSetToDictionary(stagequeryFromDataSheet);
			
			iRecordCountFlatfile = listOfRecordsFromFlatFile.size();
			iRecordCountPIMSDB = listOfRecords.size();
			int iRecordCountStagingTable = listOfRecordsfromStaging.size();
			
			//Validating PIMS table to Extract file
			if ((iRecordCountFlatfile==iRecordCountPIMSDB))
			{
				logger.log(LogStatus.PASS,"No. of recodrs in DB PIMS - "+iRecordCountPIMSDB+", No. of recodrs in Extract file - "+iRecordCountFlatfile+" are matched.");
				System.out.println("No. of recodrs in DB PIMS - "+iRecordCountPIMSDB+",No. of recodrs in Extract file - "+iRecordCountFlatfile+", are matched.");
				
				/*field to field validation, for all the fields in the extract file to all the fields to database columns, column count validation
				PRVDR_SPEC_CD, PRVDR_TYPE_CD adn PRVDR_TAXONOMY_CD are getting validated as part of field to field validation*/
				for(int mCounter=0;mCounter<iRecordCountFlatfile;mCounter++)
				{
					Map<String, String> flatFileDataMap = listOfRecordsFromFlatFile.get(mCounter);
					
					String sfSpecCDKey = flatFileDataMap.get("PRVDR_SPEC_CD");
					String sfTypeCDKey = flatFileDataMap.get("PRVDR_TYPE_CD");
					String sfTaxCDKey = flatFileDataMap.get("PRVDR_TAXONOMY_CD");
					
					String sfWholeline = sfSpecCDKey+sfTypeCDKey+sfTaxCDKey;
					
					listFlatfileString.add(sfWholeline);
				}
							
				for(int iCounter=0;iCounter<listOfRecords.size();iCounter++)
				{
					queryDataMap=listOfRecords.get(iCounter);
					
					String sSpecCDKey = queryDataMap.get("PRVDR_SPEC_CD");
					if(sSpecCDKey == null) sSpecCDKey = "";
					
					String sTypeCDKey = queryDataMap.get("PRVDR_TYPE_CD");
					if(sTypeCDKey == null) sTypeCDKey = "";
					
					String sTaxCDKey = queryDataMap.get("PRVDR_TAXONOMY_CD");
					if(sTaxCDKey == null) sTaxCDKey = "";
						
					String sWholeLine = sSpecCDKey+sTypeCDKey+sTaxCDKey;
					
					if (listFlatfileString.contains(sWholeLine))
					{
						iMatcRecCount = iMatcRecCount+1;
					}
				}
				//fields count validation from PIMS DB and extract file, count should matched both in Extract and PIMS DB
				if(iMatcRecCount == iRecordCountPIMSDB)
				{
					logger.log(LogStatus.PASS,"DB - PIMS Table to Extract file validation is successfull !!");
					System.out.println("DB - PIMS Table to Extract file  - Verification Passed !!");
					softAssertion.assertTrue(true);
				}
				else
				{
					logger.log(LogStatus.FAIL,"DB - PIMS Table to Extract file validation is failed !!");
					System.out.println("DB - PIMS Table to Extract file  - Verification Failed !!");
					softAssertion.assertTrue(true);
				}
					
				}
				else
				{
					logger.log(LogStatus.FAIL,"DB - PIMS Table to Extract file validation is Failed !!");
					System.out.println("DB - PIMS Table to Extract file  - Verification Failed !!");
					softAssertion.assertTrue(true);
				}
				
				/*staging table validation, count validation from staging table to extract file, field to field validation,
				all the 3 columns PRVDR_SPEC_CD, PRVDR_TYPE_CD, PRVDR_TAXONOMY_CD data is getting validated.*/
			
				if (iRecordCountStagingTable==iRecordCountFlatfile)
				{
					logger.log(LogStatus.PASS,"No. of recodrs in staging table - "+iRecordCountStagingTable+", No. of recodrs in staging table - "+iRecordCountFlatfile+" are matched.");
					System.out.println("No. of recodrs in staging table -"+iRecordCountStagingTable+", No. of recodrs in staging table - "+iRecordCountFlatfile+" are matched.");
					
					for(int jCounter=0;jCounter<iRecordCountStagingTable;jCounter++)
					{
						queryDataMapStage=listOfRecordsfromStaging.get(jCounter);
						
						String sSpecCDKeyStage = queryDataMapStage.get("PRVDR_SPEC_CD");
						if(sSpecCDKeyStage == null) sSpecCDKeyStage = "";
						
						String sTypeCDKeyStage = queryDataMapStage.get("PRVDR_TYPE_CD");
						if(sTypeCDKeyStage == null) sTypeCDKeyStage = "";
						
						String sTaxCDKeyStage = queryDataMapStage.get("PRVDR_TAXONOMY_CD");
						if(sTaxCDKeyStage == null) sTaxCDKeyStage = "";
						
						String sWholeLineStage = sSpecCDKeyStage+sTypeCDKeyStage+sTaxCDKeyStage;
					
						if (listFlatfileString.contains(sWholeLineStage))
						{
							iMatcRecCountStage = iMatcRecCountStage+1;
						}
					}
					/*count validation from staging table data to extract file data*/
					if(iMatcRecCountStage == iRecordCountStagingTable)
					{
						logger.log(LogStatus.PASS,"DB - OPSFEEDS.PRVDR_TYPE_SPEC_TAXONOMY_XREF Table to Extract file validation is successfull !!");
						System.out.println("DB - OPSFEEDS.PRVDR_TYPE_SPEC_TAXONOMY_XREF Table Verification Passed !!");
						softAssertion.assertTrue(true);
					}
					else
					{
						logger.log(LogStatus.FAIL,"DB - OPSFEEDS.PRVDR_TYPE_SPEC_TAXONOMY_XREF to Extract file validation is failed !!");
						System.out.println("Provider Taxonomy  - Verification Failed for DB - Staging Table to Extract File !!");
					}
				}
				else
				{
					logger.log(LogStatus.FAIL,"No match in DB Staging Table to Extract file.");
					System.out.println("DB - Staging to Extract file  - Verification Failed !!");
					softAssertion.assertTrue(true);
				}
		}	
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Count Validation: PROPS to file 
	 * Verifies whether number of records from PROPs DB and number of records in extract File are  matching. 
	 * 
	 * @return - void
	 */ 
	@Test
	private static void ProviderTaxonomy_TC003() { 
		
		SoftAssert softAssertion= new SoftAssert();
		//Verifying the count of records from source DB to Extract file. 
		if ((iRecordCountFlatfile==iRecordCountPIMSDB))
		{
			logger.log(LogStatus.PASS,"No. of recodrs in Extract file - "+iRecordCountFlatfile+", No. of recodrs PROP DB - "+iRecordCountPIMSDB+" are matched.");
			System.out.println("No. of recodrs in Extract file - "+iRecordCountFlatfile+", No. of recodrs PROP DB - "+iRecordCountPIMSDB+" are matched.");
		}
		else{
			logger.log(LogStatus.FAIL,"No. of recodrs in Extract file - "+iRecordCountFlatfile+", No. of recodrs PROP DB - "+iRecordCountPIMSDB+" are not matched.");
			System.out.println("No. of recodrs in Extract file - "+iRecordCountFlatfile+", No. of recodrs PROP DB - "+iRecordCountPIMSDB+" are not matched.");
		}
			
		softAssertion.assertTrue(true);
	}
	
	/**
	 * File specific validations: 
	 * Validation of file naming convention , file format type(.txt)  and file delimiter is pipe (|).
	 * 
	 * @return - void
	 */
	@Test
	private static void ProviderTaxonomy_TC004() {
		
		SoftAssert softAssertion= new SoftAssert();
		
		//Verifying Extract file naming convention of the extract file which is downloaded from network location.
		if (testFlatFileCompletePath.contains("PPE_PRVDR_TAXONOMY_XREF_File.txt"))						   
			logger.log(LogStatus.PASS,"Extract file Naming convention is verification Passed., Actual : "+sExtractFileName+"Expected: PRVDR_TYPE_SPEC_TAXONOMY_XREF.txt");
		else
		 logger.log(LogStatus.FAIL,"Extract file Naming convention is verification Failed., Actual : "+sExtractFileName+"Expected: PRVDR_TYPE_SPEC_TAXONOMY_XREF.txt");
		
		// Verifying file format of the extract file, The file should be .txt format as mentioned.
		if (testFlatFileCompletePath.contains(".txt"))
			 logger.log(LogStatus.PASS,"Extract file format is .txt as expected");
			else
			 logger.log(LogStatus.FAIL,"Extract file format is not .txt");
		
		// verifying the delimiter of the file, the columns data should be separated by |(pipe) symbol. 
		if (!listOfRecordsFromFlatFile.contains("\\|"))
			logger.log(LogStatus.PASS,"Extract file contains delimiter as pipe (|)");
		else
			logger.log(LogStatus.FAIL,"Extract file doesn't contains delimiter as pipe (|)");
			
		softAssertion.assertTrue(true);
	}
	
	/**
	 * File archival validation: Taxonomy file  is present at location /lpdretl/data/arch/PPE.
	 * Archival file will be within the zip file "PPEFile_YYYYMMDD.zip"
	 * 
	 * @return - void
	 */
	@Test
	private static void ProviderTaxonomy_TC005() {
		SoftAssert softAssertion= new SoftAssert();	
		Path testFlatFolderPath = Paths.get(System.getProperty("user.home")+"//Desktop//file//");
		File exFile = new File(System.getProperty("user.home")+"//Desktop//file//");
		
		/*This is block for validating archival, the extract file should be at mentioned location and it should be inside the zip file 
		with a specific name mentioned*/ 
		if (Files.exists(testFlatFolderPath))
		{
			for (final File fileEntry : exFile.listFiles()) {
		        if (fileEntry.isDirectory()) {
		        	logger.log(LogStatus.INFO,"Contains a Directory");
		        } else if((fileEntry.getName()).equals("PPE_PRVDR_TAXONOMY_XREF_File.txt")){
		        	logger.log(LogStatus.PASS,"Verification - The file "+fileEntry.getName()+" is in "+sFileName+" file.");
		        	logger.log(LogStatus.PASS,"File Archival Validation is Completed.");
		        }
		    }
			logger.log(LogStatus.INFO,"Downloaded Extract file saved to local.");
		} else
		{
			logger.log(LogStatus.FAIL,"Downloaded Extract file not saved to local.");
		}
		
		softAssertion.assertTrue(true);
	}
	
	/**
	 * Data Validation : File to WPR table - Validate that  data loaded from file to WPR DB is matching.
	 * @param data
	 *            - This is a Map of data related to testcase.
	 * @return - void
	 */
	@Test(dataProvider = "masterDataProvider")
	private static void ProviderTaxonomy_TC008(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	
		
		String sWPRDBName="", sWPRDBUser="",sWPRDBPass="",sWPRDBServer = "",sWPRDBPort= "";
		WPRAqueryFromDataSheet = data.get("SqlQuery").toString().split("\\|")[2];
		WPRBqueryFromDataSheet = data.get("SqlQuery").toString().split("\\|")[3];
		
		String WPRDB = data.get("WPR_DB");
		
		String arrWPRDB [] = WPRDB.toString().split("\\|");
		/*All related information for connecting to WPR database is provided here, all the 5 fields are mandatory for connecting to database*/ 
		if (arrWPRDB.length==5){
			sWPRDBName = arrWPRDB[0];
			sWPRDBUser = arrWPRDB[1];
			sWPRDBPass = arrWPRDB[2];
			sWPRDBServer = arrWPRDB[3];
			sWPRDBPort = arrWPRDB[4];
			}else{
				System.out.println("wrong number of Arguments for connecting WPR DB !!");
				logger.log(LogStatus.FAIL, "Wrong Number of Arguments to connect to WPR DB !!");
			}
		
		//utility for connecting database
		objDBUtility = new DBUtils(sWPRDBName, sWPRDBUser, sWPRDBPass, sWPRDBServer, sWPRDBPort);
		
		try {
			listOfRecordsfromWPRA = objDBUtility.resultSetToDictionary(WPRAqueryFromDataSheet);
			listOfRecordsfromWPRB = objDBUtility.resultSetToDictionary(WPRBqueryFromDataSheet);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		//getting the size of records read from databases.
		iRecordCountWPRADB = listOfRecordsfromWPRA.size();
		iRecordCountWPRBDB = listOfRecordsfromWPRB.size();
		
		//validating the count of the records from WPR and extract file, validating both WPR A, WPR B
		if ((iRecordCountWPRADB==iRecordCountFlatfile)&&(iRecordCountWPRBDB==iRecordCountFlatfile))
		{
			
			for(int kCounter=0;kCounter<iRecordCountWPRADB;kCounter++)
			{
				queryDataMapWPRA=listOfRecordsfromWPRA.get(kCounter);
				queryDataMapWPRB=listOfRecordsfromWPRB.get(kCounter);
				
				
				String sSpecCDKeyWPRA = queryDataMapWPRA.get("PRVDR_SPEC_CD");
				String sSpecCDKeyWPRB = queryDataMapWPRB.get("PRVDR_SPEC_CD");
				
				if(sSpecCDKeyWPRA == null) sSpecCDKeyWPRA = "";
				if(sSpecCDKeyWPRB == null) sSpecCDKeyWPRB = "";
				
				String sTypeCDKeyWPRA = queryDataMapWPRA.get("PRVDR_TYPE_CD");
				String sTypeCDKeyWPRB = queryDataMapWPRB.get("PRVDR_TYPE_CD");
				
				if(sTypeCDKeyWPRA == null) sTypeCDKeyWPRA = "";
				if(sTypeCDKeyWPRB == null) sTypeCDKeyWPRB = "";
				
				String sTaxCDKeyWPRA = queryDataMapWPRA.get("PRVDR_TAXONOMY_CD");
				String sTaxCDKeyWPRB = queryDataMapWPRB.get("PRVDR_TAXONOMY_CD");
				
				if(sTaxCDKeyWPRA == null) sTaxCDKeyWPRA = "";
				if(sTaxCDKeyWPRB == null) sTaxCDKeyWPRB = "";
					
				String sWholeLineWPRA = sSpecCDKeyWPRA+sTypeCDKeyWPRA+sTaxCDKeyWPRA;
				String sWholeLineWPRB = sSpecCDKeyWPRB+sTypeCDKeyWPRB+sTaxCDKeyWPRB;
				
				if (listFlatfileString.contains(sWholeLineWPRA) && listFlatfileString.contains(sWholeLineWPRB))
				{
					iMatcRecCountWPR = iMatcRecCountWPR+1;
				}
			}
			if((iMatcRecCountWPR == iRecordCountWPRADB) && (iMatcRecCountWPR == iRecordCountWPRBDB))
			{
				logger.log(LogStatus.PASS,"DB - WPR_PIMS_ADMN_A Table to Extract file - Record count - validation is successfull !!");
				logger.log(LogStatus.PASS,"DB - WPR_PIMS_ADMN_B Table to Extract file - Record count - validation is successfull !!");
				System.out.println("DB - WPR Table Verification Passed !!");
				softAssertion.assertTrue(true);
			}
			else
			{
				logger.log(LogStatus.FAIL,"DB - WPR Table to Extract file validation is failed !!");
				System.out.println("Provider Taxonomy  - Verification Failed for DB - Staging Table to Extract File !!");
				//softAssertion.assertTrue(false);
			}
		}
		else
		{
			logger.log(LogStatus.FAIL,"No match in DB - WPR Table to Extract file.");
			System.out.println("DB - WPR to Extract file  - Verification Failed !!");
			softAssertion.assertTrue(true);
		}
		
		softAssertion.assertTrue(true);
	}
	
	/**
	 * Count Validation: File to WPR
	 * Verify whether number of records from extract file and new WPR table are matching.
	 * 
	 * @return - void
	 * 
	 * */
	@Test
	private static void ProviderTaxonomy_TC009() {
		SoftAssert softAssertion= new SoftAssert();	
		
		//Verifying count of records from WPR Table to Extract file
		if ((iRecordCountWPRADB==iRecordCountFlatfile)&&(iRecordCountWPRBDB==iRecordCountFlatfile))
		{
			logger.log(LogStatus.PASS,"No. of recodrs from extract file - "+iRecordCountFlatfile+", No. of recodrs from PIMS_ADMN_A in WPR DB - "+iRecordCountWPRADB+" are matched.");
			logger.log(LogStatus.PASS,"No. of recodrs from extract file - "+iRecordCountFlatfile+", No. of recodrs from PIMS_ADMN_B in WPR DB - "+iRecordCountWPRBDB+" are matched.");
			System.out.println("No. of recodrs from extract file - "+iRecordCountFlatfile+", No. of recodrs from PIMS_ADMN_A in WPR DB - "+iRecordCountWPRADB+" are matched.");
			System.out.println("No. of recodrs from extract file - "+iRecordCountFlatfile+", No. of recodrs from PIMS_ADMN_B in WPR DB - "+iRecordCountWPRBDB+" are matched.");
		}
		softAssertion.assertTrue(true);
	}
	
	//************************************** TEST METHODS************************
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","RootLocationOfFlatFiles","FileFieldAndDBColumnMappingFilePath","ResultsDestinationFolderPath"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation,String RootLocationOfFlatFiles,String FileFieldAndDBColumnMappingFilePath,String ResultsDestinationFolderPath){
		path = Paths.get("target\\Results\\"+timestamp);
		 if(!Files.exists(path)){//checking the existence of given path
			 	try {Files.createDirectories(path);//Creating directory
			 		} catch (IOException e) {	e.printStackTrace();}
		 	}
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {//Initialization of class variables NameOfTestDataSheet
			NameOfTestDataSheet = "Sheet1";
			}
		filePath=TestDataSheetLocation;//Initialization of class variables
		rootLocationOfInputFiles=RootLocationOfFlatFiles;
		sheetName=NameOfTestDataSheet;
		fileFieldAndDBColumnMappingFilePath=FileFieldAndDBColumnMappingFilePath;
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);// Functional call to initialize cache from data sheet
		//objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port);// DB UTIL OBJECT CREATION!  //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		 //filePAth = tesFile.getCompleteTestFilePath();//Below step is for getting complete path of the input file		 
	}

//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();//Creating object for softAssert
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{
		//following commented code can re used in future
		//Map<String, String> dataMap = new HashMap<String, String>();
		//dataMap = ExcelUtils.getTestMethodData(method.getName());
		//data = new Object[][] { { dataMap },{ dataMap } };
		//  Object[][] testObjArray = ExcelFunctions.getTableArray("src//test//resources//TestData.xlsx","BSCA_Care1st_MM_Test");
		//	      return (testObjArray);
		filePath = "src//test//resources//TestData.xlsx";
		sheetName = "Provider_Taxonomy";
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, sheetName);
		  Object[][] testDataArray= 	  ExcelUtils.getTableArray(filePath, sheetName);
		  List<Object> list=new ArrayList<Object>();
		  
		  int noOfTestCases=0;
		  String runMode="Yes";
		  for(int row=0;row<=testDataArray.length-1;row++){//lopping over all the rows in data sheet
			  //below condition is to check for run mode and method name
			if(method.getName().equalsIgnoreCase(testDataArray[row][3].toString())&& runMode.equalsIgnoreCase(testDataArray[row][2].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();//map for each row
				for (int col=0;col<=columnArray[0].length-1;col++){//looping over all the columns
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());//inserting the row data to map
					}
				list.add(rowDataMap); //adding the map of each row into list
				
				}
		   }
		  
		  Object[][] data = new Object[noOfTestCases][1];//creating object array
		  for(int row=0;row<list.size();row++){//looping over all the matched rows 
			  data[row][0]=list.get(row);
		  }
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		ReportFactory.closeReport();//Closing the report
	}
	
	//Below method id for storing the results into results folder in the specified path
	@AfterMethod
	public void afterMethod() throws IOException{
		inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		File srcDir = new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		
		Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
	}
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
			try {
	//-----		Path htmlReportSourcePath=Paths.get(resultsSourceFolderPath+"//test-output//emailable-report.html");//storing report source path in htmlReportSourcePath 
	//-----		Path htmlReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\emailable-report.html");//storing report source path in htmlReportDestinationPath
			
			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
	//-----			TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files
			
			
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	  }
	
}
