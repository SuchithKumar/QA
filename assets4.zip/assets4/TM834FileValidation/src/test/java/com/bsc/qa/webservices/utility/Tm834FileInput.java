package com.bsc.qa.webservices.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
//import com.bsc.qa.facets.ffpojo.factory.BaseTest;
//import com.bsc.qa.facets.ffpojo.readers.BscaCare1stMMFlatFileReader;

/*
 * 834 class that gets fields data from 834 file to be used for .834 file validation.
 * @author Automation team
 *
 */

public class Tm834FileInput {

	public static int flag = 1;
	public static int flag1 = 0;
	public static int flag2 = 1;

	/*
	 * For getting 834 file data from 834 file
	 * 
	 * @param strCompleteFilePath: 834 file path
	 * 
	 * @param strInputFileName: 834 file name
	 * 
	 * @return
	 * 
	 * @throws IOException
	 * 
	 * @throws Exception: To capture the exception
	 */

	public SortedMap<String, SortedMap<String, String>> get834FileData(
			String strCompleteFilePath, String strInputFileName,
			Map<Object, Object> mydata) throws Exception {
		String strFileType;
		String primaryKey;
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		SortedMap<String, String> singleRecordMap = null;
		strCompleteFilePath = strInputFileName;
		String strInputExactFileName = strInputFileName
				.substring(strInputFileName.lastIndexOf("\\") + 1);
		// To get 834 file type
		strFileType = fileType834(strInputExactFileName);
		flatFileValuesMap = new TreeMap<String, SortedMap<String, String>>();
		// System.out.println("---------------------"+System.getenv("CIN_COMPLETE_FILE_PATH"));

		// Checking for the 834 file type
		if (strFileType.contains("Calpers 834")) {
			// For capturing all Email numbers from 834 file
			List<String> rowsListEmail = parse834FileEmail(
					strCompleteFilePath, strFileType);

			// Looping through all email numbers for validation
			for (String strEmail : rowsListEmail) {

				if (strEmail.contains(mydata.get("Email_ID").toString()
						.toLowerCase())) {

					singleRecordMap = new TreeMap<String, String>();
					primaryKey = strEmail.trim();
					// For retrieving Email specific data from 834 file
					List<String> rowsList = parse834File(strCompleteFilePath,
							primaryKey, strFileType);
					// To retrieve first subscriber section data in "NM1*IL*"
					// segment
					int intSubscriber = 0;
					String line1 = "";
					// Email storing in a map for comparison
					singleRecordMap.put("email", strEmail.trim()
							.toLowerCase());
					System.out
							.println("Email used while storing flat file data: "
									+ strEmail.trim());

					// Looping through email records to retrieve required values

					for (int i = 0; i < rowsList.size(); i++) {
						// Storing field values to validate subscriber's First
						// name, last Name, Middle initial and SSN

						if (rowsList.get(i).startsWith("NM1*IL*")) {
							// if(intSubscriber == 0){
							line1 = rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							try {
								// singleRecordMap.put("last_name",line1.split("\\*")[3]);
								// singleRecordMap.put("first_name",line1.split("\\*")[4]);
								singleRecordMap.put("ssn",
										line1.split("\\*")[9]);
								System.out.println("Data present for SSN "
										+ singleRecordMap.get("ssn"));
								// intSubscriber = intSubscriber + 1;

							} catch (Exception e) {
								System.out
										.println("Data not present for validation");
							}
							// }
						}

						// Storing field values to validate subscriber's
						// Insurance Line Code HD03 and Plan code HD04
						if (rowsList.get(i).startsWith("HD*021")) {
							if (strFileType.equalsIgnoreCase("Calpers 834")) {
								line1 = rowsList.get(i).toString();
								line1 = line1.replace("~", "");
								try {
									singleRecordMap.put("hd03",
											line1.split("\\*")[3]);
									singleRecordMap.put("hd04",
											line1.split("\\*")[4]);
									intSubscriber = intSubscriber + 1;
									System.out.println("Data present for HD03 "
											+ singleRecordMap.get("hd03")
											+ " and HD04 "
											+ singleRecordMap.get("hd04")
											+ " validation");
								} catch (Exception e) {
									System.out
											.println("Data not present for HD03 or HD04 validation");
								}
							}

						}

						// Storing field values to validate subscriber's
						// Telephone Number
						if (rowsList.get(i).startsWith("PER*IP**TE*")) {
							if (strFileType.equalsIgnoreCase("Calpers 834")) {
								line1 = rowsList.get(i).toString();
								line1 = line1.replace("~", "");
								try {
									singleRecordMap.put("telephone", line1
											.split("\\*")[4].replace("~", ""));
									System.out
											.println("Data present for telephone "
													+ singleRecordMap
															.get("telephone"));
								} catch (Exception e) {
									System.out
											.println("Data not present for telephone validation");
								}
							}
						}

						if (rowsList.get(i).startsWith("INS*Y*")) {
							if (strFileType.equalsIgnoreCase("Calpers 834")) {
								line1 = rowsList.get(i).toString();
								line1 = line1.replace("~", "");
								try {
									singleRecordMap.put("filetype", line1
											.split("\\*")[3].replace("~", ""));
									System.out
											.println("Data present for filetype "
													+ singleRecordMap
															.get("filetype"));
								} catch (Exception e) {
									System.out
											.println("Data not present for filetype validation");
								}
							}
						}

						// Storing field values for Action code BGN08 -
						// 2(changed/updated member)
						if (rowsList.get(i).startsWith("BGN*00")) {
							if (strFileType.equalsIgnoreCase("Calpers 834")) {
								line1 = rowsList.get(i).toString();
								line1 = line1.replace("~", "");
								try {
									singleRecordMap.put("bgn08",
											line1.split("\\*")[8]);
									System.out.println("Data present for BG08 "
											+ singleRecordMap.get("bgn08"));
								} catch (Exception e) {
									System.out
											.println("Data not present for BG08 validation");
								}
							}
						}

						// Storing field values to validate subscriber's City,
						// State, residential zip
						if (rowsList.get(i).startsWith("N4*")) {
							if (strFileType.equalsIgnoreCase("Calpers 834")) {
								line1 = rowsList.get(i).toString();

								line1 = line1.replace("~", "");

								try {
									// singleRecordMap.put("city",
									// line1.split("\\*")[1]);
									// singleRecordMap.put("state",
									// line1.split("\\*")[2]);
									singleRecordMap.put("residentialzip",
											line1.split("\\*")[3]);
									System.out
											.println("Data present for residentialzip "
													+ singleRecordMap
															.get("residentialzip"));

								} catch (Exception e) {
									System.out
											.println("Data not present for validation");
								}
							}
						}

						// Storing all subscriber filed values map as a value
						// and subscriber id as key
						flatFileValuesMap.put(primaryKey, singleRecordMap);
					}
				}
			}
		}

		return flatFileValuesMap;
	}

	/**
	 * Changing 834 file format when it is having one line
	 * 
	 * @param strFlatFileCompletePath
	 *            : 834 file complete path
	 * @throws Exception
	 *             : To capture exception
	 */

	public void fileFormatChange834(String strFlatFileCompletePath)
			throws Exception {
		FileWriter fileWriter = null;
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;

		try {
			File inputFile = new File(strFlatFileCompletePath);
			String strLines = "";
			String line = "";
			// Checking for the file existence
			if (!inputFile.exists()) {
				throw new IllegalStateException("File not found: "
						+ strFlatFileCompletePath);
			} else {
				fileReader = new FileReader(inputFile);
				bufferedReader = new BufferedReader(fileReader);
				int intICounter = 0;
				// Reading each line from the file
				while ((line = bufferedReader.readLine()) != null) {
					strLines = strLines + line;
					intICounter += 1;
					// Checking for single line 834 file
					if (intICounter > 1) {
						bufferedReader.close();
						return;
					}
				}

				byte[] strBytes = strLines.getBytes();
				String strAllLines = new String(strBytes,
						StandardCharsets.UTF_8);
				// Replacing "~" symbol with "~\r\n"
				String strFormatLines = strAllLines.replaceAll("~", "~\r\n");
				fileWriter = new FileWriter(strFlatFileCompletePath);
				// Writing the data once again into the file after changes
				fileWriter.write(strFormatLines);
			}
		}

		// For capturing exception
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// Closing all opened file objects
				fileReader.close();
				fileWriter.close();
				bufferedReader.close();
			} catch (Exception ex) {
				// ex.printStackTrace();
			}
		}
	}

	/**
	 * @param testFlatFileCompletePath
	 *            : File complete path
	 * @param strEmaidId
	 *            : To capture specific subscriber section using emailID
	 * @param strFileName
	 *            : 834 file type
	 * @return: List of subscriber lines of data
	 * @throws Exception
	 *             " To capture the exception
	 */

	public List<String> parse834File(String testFlatFileCompletePath,
			String strEmaidId, String strFileName) throws Exception {
		File inputFile = new File(testFlatFileCompletePath);
		String line = null;
		BufferedReader bufferedReader = null;
		List<String> rowsList = new ArrayList<String>();
		// For checking file existence
		if (!inputFile.exists()) {
			throw new IllegalStateException("File not found: "
					+ testFlatFileCompletePath);
		} else {
			// Changing the layout when it is having in one single line
			fileFormatChange834(testFlatFileCompletePath);
			if (strFileName.contains(("Calpers 834"))) {
				FileReader fileReader = new FileReader(testFlatFileCompletePath);
				bufferedReader = new BufferedReader(fileReader);
				boolean flag = false;
				// Reading each line in the file
				while ((line = bufferedReader.readLine()) != null) {
					// Checking for the email
					if (line.contains(strEmaidId)) {
						flag = true;
					}
					// Checking for the starting line for each subscriber
					// section
					if (line.startsWith("ST")) {
						if (flag) {
							break;
						} else {
							// To clear the records if it is not matches to the
							// provided email
							rowsList.clear();
						}
					}
					// Adding lines to the records list
					rowsList.add(line);
				}
			}

			else {
				// Printing line when user has selected invalid file
				System.out
						.println("Please select valid file type to retrieve data from flat file ");
			}
		}

		// To close the bufferedReader object
		if (bufferedReader != null)
			bufferedReader.close();
		return rowsList;
	}

	/**
	 * To capture emailID from 834 file
	 * 
	 * @param testFlatFileCompletePath
	 *            : 834 File complete path
	 * @param strFileName
	 *            : 834 file type
	 * @return: emailID
	 * @throws Exception
	 *             : Throwing exception
	 */

	public List<String> parse834FileEmail(
			String testFlatFileCompletePath, String strFileName) {
		File inputFile = new File(testFlatFileCompletePath);
		String line = null;
		BufferedReader bufferedReader = null;
		List<String> rowsList = new ArrayList<String>();
		try {
			// Checking for the file existence
			if (!inputFile.exists()) {
				throw new IllegalStateException("File not found: "
						+ testFlatFileCompletePath);
			} else {
				// Changing the layout when it is not expected
				fileFormatChange834(testFlatFileCompletePath);
				// To capture Email Numbers from LACare file
				if (strFileName.contains("Calpers 834")) {
					FileReader fileReader = new FileReader(
							testFlatFileCompletePath);
					bufferedReader = new BufferedReader(fileReader);
					// Looping through all lined for checking Email Number line
					while ((line = bufferedReader.readLine()) != null) {
						if (line.contains("*EM*")) {
							line = line.replace("~", "").trim();
							// ////////Email_id goes here
							// strFileName.substring(strFileName.lastIndexOf("\\")
							// + 1);
							rowsList.add(line.substring(
									line.lastIndexOf("*") + 1).toLowerCase());

						}
					}
				}

				
				else {
					System.out
							.println("Please select valid file type to retrieve data from flat file ");
				}
			}

			// To close the bufferReader object
			if (bufferedReader != null)
				bufferedReader.close();
		}
		// To capture and print the exception
		catch (Exception e) {

			e.printStackTrace();
		}
		// For returning list of emailID
		return rowsList;
	}

	/**
	 * To find file type for 834 care1st MM
	 * 
	 * @param strFileName
	 *            : Name of the file
	 * @return: File name used for coding
	 */

	public String fileType834(String strFileName) {
		if (strFileName.contains("\\")) {
			strFileName = strFileName
					.substring(strFileName.lastIndexOf("\\") + 1);
		}
		// Checking for the expected file name
		if (strFileName.contains("CFST.D"))
			return "LACounty_Medi-Cal_Members(LACare)834";
		else if (strFileName.contains("834"))
			return "Calpers 834";
		else if (strFileName.contains("TXBMD"))
			return "TXBMD_834";
		else if (strFileName.contains("TFEPO"))
			return "TFEPO_834";
		else if (strFileName.contains("59140IFPON"))
			return "59140IFPON_834";
		else if (strFileName.contains("TPERS"))
			return "TPERS_834";
		else if (strFileName.contains("59140IFPOFF"))
			return "59140IFPOFF_834";
		else if (strFileName.contains("CTRCOO"))
			return "CTRCOO_834";
		else
			System.out.println("This file name is invalid: " + strFileName);
		return null;
	}

}
