package com.bsc.qa.webservices.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class MySQLJDBCUtility {
	public static Connection sqlConnection = null;
	

	/**
	 * Setup the database connection using the SQL JDBC driver.
	 * 
	 * @throws ClassNotFoundException
	 *
	 */

	public void setUp(Map<Object, Object> mydata) {

		
		String databaseName = System.getenv("EDIFECS_MSSQL_DB");
		String serverName = System.getenv("EDIFECS_MSSQL_SERVER");
		String portNumber = System.getenv("EDIFECS_MSSQL_PORT");
		//creating connection string url
		//jdbc:sqlserver://WSQL656H:50101;DatabaseName=EDIH05_EcActive
		String sqlDBUrl = "jdbc:sqlserver://"+serverName+":"+portNumber+";DatabaseName="+databaseName+"_"+mydata.get("TM DB Name");
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		if (sqlConnection == null && sqlDBUrl != null && !"".equals(sqlDBUrl)) {
			String sqlUser = System.getenv("EDIFECS_MSSQL_USER");
			String sqlPassword = System.getenv("EDIFECS_MSSQL_PASSWORD");
	
			
			
			try {
				sqlConnection = DriverManager
						.getConnection(sqlDBUrl,sqlUser,sqlPassword);
			} catch (SQLException ex) {
				System.out
						.println("ERROR: SQL Exception when connecting to the database: "
								+ sqlDBUrl);
				ex.printStackTrace();
			}
		}
	}
	
	/**
	 * Get resultset as a sorted map based on primary keys
	 * @param Connection connection string
	 * @param query
	 *            SQL Query
	 * @param primaryKey
	 *            Primary key
	 * @return SortedMap of result
	 */
	
	
	public static SortedMap<String, SortedMap<String, String>> getRowsdata(Connection conn, String query, String primarykey)
	        throws SQLException{
		SortedMap<String, String> row = null;
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rset.getMetaData();
		
		
		int rowCounter = 0;
		@SuppressWarnings("unused")
		int cellCounter = 0;

		SortedMap<String, SortedMap<String, String>> table = new TreeMap<String, SortedMap<String, String>>();
		try {
			rsmd = rset.getMetaData();
			String primaryKeyValue = primarykey;
			String value = null;
			String columnName = null;
			while (rset.next()) {
				
				row = new TreeMap<String, String>();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					value = rset.getString(i);
					columnName = rsmd.getColumnLabel(i);
					if (value == null) {
						value = "";
					}
					row.put(columnName.toLowerCase(), value.toLowerCase());
					cellCounter++;
				}
				table.put(primaryKeyValue, row);

				rowCounter++;
				cellCounter = 0;
			}
			//System.out.println("Keyset size: " + table.keySet().size());
			//System.out.println("Row count: " + rowCounter);
			// System.out.println("Column count: " +
			// rsmd.getColumnCount());
			// System.out.println("Cell count: " + cellCounter);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return table;
	}
	

	/**
	 * Close the database connection
	 *
	 */
	public void tearDown() {
		if (sqlConnection != null) {
			try {
				// System.out.println("Closing SQL Database Connection...");
				sqlConnection.close();
				sqlConnection = null;
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	
	
	
		
 /*public static Map<String, Map<String, String>> getRowsdata(Connection conn, String query, String primarykey)
	        throws SQLException{
	           Map<String, String> row = null;
	            Statement stmt = conn.createStatement();
	            ResultSet rset = stmt.executeQuery(query);
	            ResultSetMetaData rsmd = rset.getMetaData();
	            int columncount = rsmd.getColumnCount();
	            Map<String, Map<String, String>> queryResult = new LinkedHashMap<String, Map<String, String>>();
	            while (rset.next()) {
	            	row = new LinkedHashMap<String, String>();
	                for (int i = 1; i <= columncount; i++) {
	                    row.put(rsmd.getColumnName(i).toString(), rset.getObject(i).toString());
	                }
	                queryResult.put(primarykey, row);
	            }
	            return queryResult;
	        }*/
	
	
}