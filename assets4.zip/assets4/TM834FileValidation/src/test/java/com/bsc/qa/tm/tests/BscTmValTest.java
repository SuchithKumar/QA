package com.bsc.qa.tm.tests;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.stream.Stream;
import org.apache.commons.lang3.StringUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.Tm834FileInput;
import com.relevantcodes.extentreports.LogStatus;

public class BscTmValTest extends BaseTest implements IHookable {

	public static String sTargetFiles_dir = System.getenv("INPUT_EDI_PATH");//input file location
	public static String activeSheetName = System.getenv("ENVNAME");//input data sheet name
	private SoftAssert softAssert = null;

	@DataProvider(name = "data")//dataprovider
	public Object[][] dataSupplier(Method method) throws IOException {
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";//path of input data workbook

		Object[][] columnArray = ExcelUtils.getColumnArray(xlsPath,
				activeSheetName);//returns worksheet column

		Object[][] testDataArray = ExcelUtils.getTableArray(xlsPath,
				activeSheetName);//returns worksheet data
		List<Object> list = new ArrayList<Object>();

		int noOfTestCases = 0;
		// String runMode = "Yes";
		for (int row = 0; row < testDataArray.length; row++) {
			//checking for the test method with the data sheet test method name
			if (method.getName().equalsIgnoreCase(
					testDataArray[row][1].toString())) {
				noOfTestCases++;

				System.out.println("TestCase Name From Data Sheet:::"
						+ testDataArray[row][0].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col = 0; col <= columnArray[0].length - 1; col++) {
					//storing the worksheet data in rowDataMap
					rowDataMap.put(columnArray[0][col].toString(),
							testDataArray[row][col].toString());
					rowDataMap.put("rowNum", String.valueOf(row));

				}
				
				list.add(rowDataMap);//adding the data to list

			}

		}

		Object[][] data = new Object[noOfTestCases][1];
		for (int row = 0; row < list.size(); row++) {
			data[row][0] = list.get(row);
		}

		return data;

	}

	@Test(dataProvider = "data")//testMethod
	public void test834TmDbValidation(Map<Object, Object> mydata){
		System.out
				.println("-------------test834IncorrectProductID Test case started ----------------");
		
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "", strCompletePath = "", strl = "";
		Tm834FileInput edi = new Tm834FileInput(); // object creation of 834 flat file utility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					strl = dfile.toString();
					strFileName = strl.substring(strl.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {
							
							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							
							/*
							 * For getting 834 file data from 834 file
							 * 
							 * @param sTargetFiles_dir: 834 file path
							 * 
							 * @param strCompletePath: 834 file name
							 * 
							 * @param mydata: input data sheet object[][]
							 * 
							 * @return flatFileValuesMap: map with email as key and flat file values
							 */
							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// If test email is present in 834 flatFileValuesMap
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {
								
								//iterating over test email present in 834 flatFileValuesMap
								for (String primaryKey : flatFileValuesMap
										.keySet()) {

									//storing the data corresponding to the test email in rowMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// changing the file name as in TM GBDREPO
									// db to fetch the query
									String sfileName = strFileName.replace(
											".834", "%");

									System.out.println(rowMap.get("email"));
									System.out.println(rowMap.get("ssn"));
									System.out.println(sfileName);

									SortedMap<String, SortedMap<String, String>> sqlMap = null;

									/*
									 * For getting SQL query
									 * 
									 * @param rowMap: SSN
									 * 
									 * @param mydata: email id from worksheet
									 * 
									 * @param strFileName: 834 file name
									 * 
									 * @return strActualQuery: String query used for fetching the TM database result
									 */
									String strActualQuery = actualQuery(rowMap,
											mydata, strFileName);
									
									System.out.println(strActualQuery);
									
									try {
										/*
										 * For retrieving database result in map
										 * 
										 * @param mssql: Type of database connection
										 * 
										 * @param strActualQuery: SQL query
										 * 
										 * @param Email: Gives the value present under Email column in database table, used as primarykey for the map
										 * 
										 * @return sqlMap: Map with query results
										 */
										sqlMap = new DBUtils()
												.getResultSetAsSortedMap(
														"mssql",
														strActualQuery, "Email");
									} catch (Exception e) {
										logger.log(
												LogStatus.WARNING,
												"Database issue, please re-check the environment details: "
														+ System.getenv("MSSQL_SERVER")
														+ "|"
														+ System.getenv("MSSQL_DB"));
									}

									System.out.println("sqlMap1 " + sqlMap);

									

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);
									logger.log(LogStatus.INFO,
											"Query used to fetch database data : "
													+ strActualQuery);
									
									//if no data is found from the query
									if (sqlMap.size() == 0) {
										logger.log(
												LogStatus.WARNING,
												"Query fetched zero results from database, please re-check the database environment details: "
														+ System.getenv("MSSQL_SERVER")
														+ "|"
														+ System.getenv("MSSQL_DB")
														+ "_"
														+ mydata.get("TM DB Name"));
									} else {

										logger.log(
												LogStatus.INFO,
												"<<  Query fetched results from database: "
														+ System.getenv("MSSQL_DB")
														+ "  >>");
									}

									logger.log(LogStatus.INFO,
											"<<  Email used for validation is: "
													+ primaryKey.toUpperCase()
													+ "  >>");

									// Performing TM database validations
									try {

										if (sqlMap.size() > 0) {

											// Gives FileName
											String fileName = sqlMap
													.get(primaryKey)
													.get("filename").trim();

											logger.log(
													LogStatus.INFO,
													"<<  Input(834) file used for validation is: "
															+ fileName
																	.toUpperCase()
															+ "  >>");
											// Gives Validation Status
											String currentValidationStatus = sqlMap
													.get(primaryKey)
													.get("currentvalidationstatus")
													.trim()
													.replace("{br}", " ")
													.replace("{tab}", " ");
											// Gives Active status
											String currentActivityStatus = sqlMap
													.get(primaryKey)
													.get("currentactivitystatus")
													.trim()
													.replace("{br}", " ")
													.replace("{tab}", " ");
											// Gives cause of error
											String bizerrorMessage = sqlMap
													.get(primaryKey)
													.get("bizerrormessage")
													.trim()
													.replace("{br}", " ")
													.replace("{tab}", " ");
											// Trading Partner name
											String senderName = sqlMap
													.get(primaryKey)
													.get("sendername").trim()
													.replace("{br}", " ");
											// Gives information about the error
											String techErrorMessage = sqlMap
													.get(primaryKey)
													.get("techerrormessage")
													.trim()
													.replace("{br}", " ")
													.replace("{tab}", " ");
											// Gives the status Either Warning
											// or Normal
											// String errorSeverity = sqlMap
											// .get(primaryKey)
											// .get("errorseverity")
											// .trim();

											
											softAssert.assertTrue(currentValidationStatus.equalsIgnoreCase("accepted"), "Input File is Rejected in TM");
											
											logger.log(
													LogStatus.INFO,
													" << Current Validation Status: "
															+ currentValidationStatus
																	.toUpperCase()
															+ " >>");
											
											

											if (currentActivityStatus != null) {

												logger.log(
														LogStatus.INFO,
														" << Current Activity Status: "
																+ currentActivityStatus
																+ " >>");
											}

											// Checking Residential Zip code
											// presence in input 834 file
											if (rowMap
													.containsKey("residentialzip")) {

											} else {
												rowMap.put("residentialzip",
														null);

											}
											// Checking Telephone presence in
											// input 834 file
											if (rowMap.containsKey("telephone")) {

											} else {
												rowMap.put("telephone", null);

											}

											for (String columnKey : rowMap
													.keySet()) {

												// Retrieving value from flat
												// file for each
												// of the keys

												String fileValue = rowMap
														.get(columnKey);
												String dbValue = "";

												// Retrieving value from
												// database for each
												// of the keys
												dbValue = sqlMap
														.get(primaryKey).get(
																columnKey);

												System.out
														.println("Keys and values for comparison: "

																+ columnKey
																+ "|"
																+ fileValue
																+ "|" + dbValue);

												// New or change file
												if (columnKey
														.contains("filetype"
																.toLowerCase())) {
													if (fileValue
															.equalsIgnoreCase("021")) {
														logger.log(
																LogStatus.INFO,
																"<<   New enroll file   >>");

													} else {
														logger.log(
																LogStatus.INFO,
																"<<  Change file  >>");
													}
												}

												// BGN08 File Type
												if (columnKey.contains("bgn08"
														.toLowerCase())) {
													if (fileValue
															.equalsIgnoreCase("2")) {
														logger.log(
																LogStatus.INFO,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Input file) value: "
																		+ fileValue
																		+ " >>");

													} // If Full File
													else if (fileValue
															.equalsIgnoreCase("4")) {
														logger.log(
																LogStatus.INFO,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Input file) value: "
																		+ fileValue

																		+ " >>");
													}

													else {
														logger.log(
																LogStatus.ERROR,
																" << No record are found regarding BGN08 >>");
													}

												}

												// HD03 code
												if (columnKey.contains("hd03"
														.toLowerCase())) {
													if (fileValue
															.equalsIgnoreCase("AG")) {
														logger.log(
																LogStatus.INFO,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Input file) value: "
																		+ fileValue
																		+ " >>");
													}

												}

												// HD04 plan code
												if (columnKey.contains("hd04"
														.toLowerCase())) {
													if (fileValue
															.equalsIgnoreCase("30000009")) {
														// boolean
														// hasNonAlpha =
														// !StringUtils.isAlphanumeric(fileValue);
														logger.log(
																LogStatus.ERROR,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Input file) value: "
																		+ fileValue
																		+ " >>");

													}
												}

												// HD04 is empty
												if (columnKey.contains("hd04"
														.toLowerCase())) {
													if (fileValue.isEmpty()) {
														// boolean hasNonAlpha =
														// !StringUtils.isAlphanumeric(fileValue);
														logger.log(
																LogStatus.ERROR,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Input file) value: "
																		+ "No plan code in 834 input file"
																		+ " >>");

													}
												}

												// Email verification
												if (columnKey.contains("email"
														.toLowerCase())) {

													if (fileValue.length() > 50) {
														logger.log(
																LogStatus.ERROR,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Input file) value: "
																		+ fileValue
																		+ " | Expected (TM DB) Value: "
																		+ dbValue
																		// +
																		// " | Email is more than 50 characters"
																		+ " >>");
													}

												}
												// SSN verification
												if (columnKey.contains("ssn"
														.toLowerCase())) {
													if (dbValue
															.equalsIgnoreCase(fileValue)
															&& fileValue
																	.startsWith("000")) {
														logger.log(
																LogStatus.ERROR,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Input file) value: "
																		+ fileValue
																		+ " | Expected (TM DB) Value: "
																		+ dbValue
																		// +
																		// " | Invalid SSN in 834 input file (SSN with 9 digits and starts with 3 0's) "
																		+ " >>");
													}

												}
												// ResidentialZip
												// verification
												if (columnKey
														.contains("residentialzip"
																.toLowerCase())) {
													try {
														if (fileValue
																.equalsIgnoreCase(null)) {
															logger.log(
																	LogStatus.ERROR,
																	" << Field name: "
																			+ columnKey
																			+ " | Actual (834 Input file) value: "
																			+ fileValue
																			+ " | Zipcode is null "
																			+ " >>");
														}

														else if (fileValue
																.endsWith("0000")
																|| fileValue
																		.endsWith("9999"))
														// && fileValue
														// .length() == 9)
														{

															logger.log(
																	LogStatus.ERROR,
																	" << Field name: "
																			+ columnKey
																			+ " | Actual (834 Input file) value: "
																			+ fileValue
																			+ " | Expected (TM DB) Value: "
																			+ dbValue
																			+ " | Last 4 digits are '0000' or '9999' for 9 digits US Zip Code"
																			+ " | Trading Partner: "
																			+ senderName
																					.toUpperCase()
																			+ " >>");

														}

													}

													catch (Exception e) {

														// logger.log(
														// LogStatus.INFO,
														// "No residential zip code in 834 input file");

													}
												}

												// Telephone Verification
												if (columnKey
														.contains("telephone"
																.toLowerCase())) {
													try {
														if (fileValue.length() > 10) {
															logger.log(
																	LogStatus.ERROR,
																	" << Field name: "
																			+ columnKey
																			+ " | Actual (834 Input file) value: "
																			+ fileValue
																			// +
																			// " | Expected (TM DB) Value: "
																			// +
																			// dbValue
																			// +
																			// " | Phone numbers truncated to 10 digits "
																			+ " >>");
														}

													}

													catch (Exception e) {

														
														System.out
																.println("No telephone in 834 input file");

													}

												}

											}
											if (bizerrorMessage != null) {

												logger.log(
														LogStatus.ERROR,
														" << Bizerror Message: "
																+ bizerrorMessage
																+ " >>");
											}
											if (techErrorMessage != null) {

												logger.log(
														LogStatus.ERROR,
														" << Tech Error Message: "
																+ techErrorMessage
																+ " >>");
											}

										}

									}

									catch (Exception e) {
										logger.log(LogStatus.FAIL,
												"Test script Failed due to Exception.....!! Data value in DB is "
														+ e.getMessage());

									}
								}

							}

						} else {// counter increment to check if email is not
							// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
				// for respective scenarios
				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				logger.log(
						LogStatus.WARNING,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}
	}

	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {

		Map map = (Map) callBack.getParameters()[0];
		String testCaseName = "TestcaseName: " + map.get("Test_Name");
		// reportInit(testResult.getTestContext().getName(),
		// testResult.getName(),testCaseName);

		reportInit(testResult.getTestContext().getName(), testCaseName,
				testResult.getMethod().getMethodName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);

		/*
		 * reportInit(testResult.getTestContext().getName(),
		 * testResult.getTestName()); softAssert = new SoftAssert();
		 * logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		 * callBack.runTestMethod(testResult);
		 */
		softAssert.assertAll();
	}

	// loading Queries from excel file
	public String actualQuery(Map<String, String> rowMap,
			Map<Object, Object> mydata, String strFileName) {
		String strQuery = "", line1 = "", line2 = "", line3 = "";
		if (mydata.get("TM DB Name").toString().equalsIgnoreCase("GBDREPO")) {
			String sfileName = strFileName.replace(".834", "%");
			strQuery = mydata.get("TM database query").toString();
			line1 = StringUtils.replace(strQuery, "FILE_NAME_placeholder%",
					sfileName);
			line2 = StringUtils.replace(line1, "SSN_placeholder",
					rowMap.get("ssn"));
			line3 = StringUtils.replace(line2, "EMAIL_placeholder",
					mydata.get("Email_ID").toString().toLowerCase());
			return line3;

			/*
			 * data .get("SQL_TEMPLATE") + "'" + sfileName + "'" +
			 * data.get("SSN") + "'" + rowMap.get("ssn") + "'" + "and" + "'" +
			 * rowMap.get("email_id") + "'" + data.get("ORDERBY");
			 */
		} else if (mydata.get("TM DB Name").toString()
				.equalsIgnoreCase("EcActive")) {
			strQuery = mydata.get("TM database query").toString();
			line1 = StringUtils.replace(strQuery, "FILE_NAME", strFileName);
			line2 = StringUtils.replace(line1, "SSN_placeholder",
					rowMap.get("ssn"));
			line3 = StringUtils.replace(line2, "EMAIL_placeholder",
					mydata.get("Email_ID").toString().toLowerCase());
			return line3;

		} else
			return null;
	}
}