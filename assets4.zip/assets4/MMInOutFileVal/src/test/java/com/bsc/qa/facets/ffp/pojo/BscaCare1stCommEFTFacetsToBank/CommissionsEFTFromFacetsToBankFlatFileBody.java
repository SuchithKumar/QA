package com.bsc.qa.facets.ffp.pojo.BscaCare1stCommEFTFacetsToBank;


import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE

public class CommissionsEFTFromFacetsToBankFlatFileBody {
			 
	

	private String Transit_Route_Number;
	private String  Transit_Route_Check_Digit;
	private String Individual_Account_Number ;
	private String Dollar_Amount;
	private String Individual_Identification_Number ;
	private String Receiving_Company_Name_ID_number;
	private String First_Initial_Of_First_Name;
	private String First_Initial_Of_Middle_Name;
	public String getTransit_Route_Number() {
		return Transit_Route_Number;
	}
	public void setTransit_Route_Number(String transit_Route_Number) {
		Transit_Route_Number = transit_Route_Number;
	}
	public String getTransit_Route_Check_Digit() { 
		return Transit_Route_Check_Digit;
	}
	public void setTransit_Route_Check_Digit(String transit_Route_Check_Digit) {
		Transit_Route_Check_Digit = transit_Route_Check_Digit;
	}
	public String getIndividual_Account_Number() {
		return Individual_Account_Number;
	}
	public void setIndividual_Account_Number(String individual_Account_Number) {
		Individual_Account_Number = individual_Account_Number;
	}
	public String getDollar_Amount() {
		return Dollar_Amount;
	}
	public void setDollar_Amount(String dollar_Amount) {
		Dollar_Amount = dollar_Amount;
	}
	public String getIndividual_Identification_Number() {
		return Individual_Identification_Number;
	}
	public void setIndividual_Identification_Number(
			String individual_Identification_Number) {
		Individual_Identification_Number = individual_Identification_Number;
	}
	public String getReceiving_Company_Name_ID_number() {
		return Receiving_Company_Name_ID_number;
	}
	public void setReceiving_Company_Name_ID_number(
			String receiving_Company_Name_ID_number) {
		Receiving_Company_Name_ID_number = receiving_Company_Name_ID_number;
	}
	public String getFirst_Initial_Of_First_Name() {
		return First_Initial_Of_First_Name;
	}
	public void setFirst_Initial_Of_First_Name(String first_Initial_Of_First_Name) {
		First_Initial_Of_First_Name = first_Initial_Of_First_Name;
	}
	public String getFirst_Initial_Of_Middle_Name() {
		return First_Initial_Of_Middle_Name;
	}
	public void setFirst_Initial_Of_Middle_Name(String first_Initial_Of_Middle_Name) {
		First_Initial_Of_Middle_Name = first_Initial_Of_Middle_Name;
	}
	
	
	
	
	
	
}
