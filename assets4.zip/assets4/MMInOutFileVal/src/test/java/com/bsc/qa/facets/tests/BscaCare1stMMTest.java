package com.bsc.qa.facets.tests;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffp.pojo.BscaCare1stCommEFTFacetsToBank.CommissionsEFTFromFacetsToBankFlatFileBody;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.readers.BscaCare1stMMFlatFileReader;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.relevantcodes.extentreports.LogStatus;
public class BscaCare1stMMTest extends BaseTest implements IHookable{
	private static BscaCare1stMMFlatFileReader ffpExtract;
    private static String filePath,sheetName,fileFieldAndDBColumnMappingFilePath,resultsDestinationFolderPath;
    private static String rootLocationOfInputFiles;
	private static DBUtils objDBUtility;//reference for dbUtils class
	public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
	private static Path path,inputDataPath;// input data folder path
	private static Map<String, String> flatFileValuesMap=new HashMap<String,String>();// Dictionary for Flat files fields and values
	private static	Map<String,String>queryDataMap=new HashMap<String,String>();//Dictionary for db query columns and values
	private static	List<Map<String,String>>listOfRecords=new ArrayList<Map<String,String>>();//list or all records in flat files
	private static 	String SUCName;
	
	
	//************************************** TEST METHODS************************
	@Test(dataProvider = "masterDataProvider")
	private static void COBFileValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			String reportFilePath="";
			String inputFileName=data.get("Input File Name").toString().trim();
			SUCName=data.get("SUC Name").toString();	
			String inputParameter1= data.get("Query parameter1").toString().trim();
			String inputParameter2= data.get("Query parameter2").toString().trim();
			String testCaseId=data.get("Test Case ID").toString().trim();	
			String queryFromDataSheet = data.get("SqlQuery").toString();//getiing sql query from data sheet
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",inputParameter1.trim

());//replacing query parameter in Sql query		
			
			String inputFilePath=rootLocationOfInputFiles+"\\"+SUCName+"\\"+inputFileName.split(";")[0];
			if(inputFileName.split(";").length>1){
				 reportFilePath=rootLocationOfInputFiles+"\\"+SUCName+"\\"+inputFileName.split(";")[1];	
			}
			
			
			if(testCaseId.equals("COB_TC001")){
				String primaryKey="DTL"+inputParameter1;
				
				String line=TestFileUtil.parseCOBFile(inputFilePath,primaryKey);
				String contractId=line.substring(33,38);

				listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery.split(";")

[0]);//queryDataMap
				String contractId_DB=listOfRecords.get(0).get("CONTR_ID");//First element of list
				
				softAssertion.assertEquals(contractId, contractId_DB,"File value:"+contractId+"DB value:"+contractId_DB);
				logger.log(LogStatus.INFO, "FileValue:"+contractId+"|dbValue:"+contractId_DB+"|Validation:"+contractId.equalsIgnoreCase(contractId_DB));
				//System.out.println("contractId_DB:"+contractId_DB+"|filecontractId:"+contractId);
				
				//Report data and data base data validation....!!			

	
				
				String line_Report=TestFileUtil.parseCOBFile(reportFilePath,inputParameter1);
				String subscriberId_report=line_Report.split(",")[0];
				
				listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery.split(";")[1]);//queryDataMap
				String subscriberId_DB=listOfRecords.get(0).get("SBSB_ID");//First element of list
				softAssertion.assertEquals(subscriberId_report, subscriberId_DB,"Report value:"+subscriberId_report+"DB value:"+subscriberId_DB);
				logger.log(LogStatus.INFO, "Report Value:"+subscriberId_report+"|DB Value:"+subscriberId_DB+"|Validation :"+subscriberId_report.equalsIgnoreCase(subscriberId_DB));
				
				
				
			}else if(testCaseId.equals("COB_TC002")){
				List<String>list=TestFileUtil.parseCOBFileForAllRows(inputFilePath,"PRM"+inputParameter1);
				int Count=0;
				//for(String str:list){		if(str.startsWith("PRM")){flag_File=true;	}				}
				//if(flag_File&&flag_DB){softAssertion.assertTrue(true);logger.log(LogStatus.INFO, "PRM record is present in DB");
				//}else{softAssertion.assertTrue(false);logger.log(LogStatus.INFO, "PRM Record is not present in DB");}
				listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery.split(";")

[0]);//queryDataMap
				for(Map<String,String> rowMap:listOfRecords){
					if("PRM".equals(rowMap.get("REC_TYP_CD"))){
						 Count++;
					}
				}
				softAssertion.assertEquals(Count, list.size(),"PRM Records in File:"+list.size()+"|PRM Records in DB:"+Count);
				logger.log(LogStatus.INFO, "PRM Records in File:"+list.size()+"|PRM Records in DB:"+Count+"|Validation:"+(Count== list.size()));
			}else if(testCaseId.equals("COB_TC003")){
				List<String>list=TestFileUtil.parseCOBFileForAllRows(inputFilePath,"SUP"+inputParameter1);
				int Count=0;
				//for(String str:list){		if(str.startsWith("PRM")){flag_File=true;	}				}
				//if(flag_File&&flag_DB){softAssertion.assertTrue(true);logger.log(LogStatus.INFO, "PRM record is present in DB");
				//}else{softAssertion.assertTrue(false);logger.log(LogStatus.INFO, "PRM Record is not present in DB");}
				listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery.split(";")[0]);//queryDataMap
				for(Map<String,String> rowMap:listOfRecords){
					if("SUP".equals(rowMap.get("REC_TYP_CD"))){
						 Count++;
					}
				}
				softAssertion.assertEquals(Count, list.size(),"SUP Records in File:"+list.size()+"|SUP Records in DB:"+Count);
				logger.log(LogStatus.INFO, "SUP Records in File:"+list.size()+"|SUP Records in DB:"+Count+"|Validation:"+(Count==list.size()));
			}else if(testCaseId.equals("COB_TC004")){
				String HICN=inputParameter1;
				String recordType=inputParameter2;
				String line=TestFileUtil.parseCOBFile(inputFilePath,recordType+HICN);
				String termDate=line.substring(289,297);
				listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery.split(";")[0]);//queryDataMap
				String termDate_DB=listOfRecords.get(0).get("TERM_DT");//First element of list
				softAssertion.assertEquals(termDate, termDate_DB);
				logger.log(LogStatus.INFO, "FileValue:"+termDate+"|dbValue:"+termDate_DB+"|Validation:"+termDate.equalsIgnoreCase(termDate_DB));
				//System.out.println("contractId_DB:"+contractId_DB+"|file contractId:"+contractId);
				
			}else if(testCaseId.equals("COB_TC005")||testCaseId.equals("COB_TC006")||testCaseId.equals("COB_TC007")){
				String MSPCode=inputParameter2;
				Boolean flag=false,flag_report=false;
				String MSPCode_DB="",MSPCode_Report="";
				List<String>list=TestFileUtil.parseCOBFileForAllRows(inputFilePath,inputParameter1);
				for(String line:list){
					
					if((line.startsWith("PRM")||line.startsWith("SUP"))&&MSPCode.equals(line.substring(110,111))){
						listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery.split(";")[0]);//queryDataMap
						for(Map<String,String> map:listOfRecords){
							if(MSPCode.equals(map.get("MSP_RSN_CD"))){
								MSPCode_DB=map.get("MSP_RSN_CD");
								flag=true;
							}
						}
					}
				}
				
				softAssertion.assertTrue(flag,"Input MSP Code:"+MSPCode+"|MSPCode_DB:"+MSPCode_DB);
				logger.log(LogStatus.INFO, "Input MSP Code:"+MSPCode+"| MSPCode_DB:"+MSPCode_DB+"|Validation:"+MSPCode.equalsIgnoreCase(MSPCode_DB));
				//Report data and data base data validation....!!			

	
				List<String>lines_Report=TestFileUtil.parseCOBFileForAllRows(reportFilePath,inputParameter1);
				for(String line:lines_Report){
					if(MSPCode.equals(line.split(",")[9])){
						MSPCode_Report=line.split(",")[9];
						flag_report=true;
					}
				}
				softAssertion.assertTrue(flag_report,"Input MSPCode:"+MSPCode+"|MSPCode_DB:"+MSPCode_Report);
				logger.log(LogStatus.INFO, "Input MSPCode:"+MSPCode+"|MSPCode_Report:"+MSPCode_Report+"|Validation:"+MSPCode.equalsIgnoreCase(MSPCode_Report));
			}else if(testCaseId.equals("COB_TC008")){
				String HICN=inputParameter1;
				Boolean flag_report=false;
				Integer dtlRecords=0,prmRecords=0,supRecords=0;
				List<String> lines=TestFileUtil.parseCOBFileForAllRows(inputFilePath,HICN);
				for(String line:lines){
					if(line.startsWith("DTL")){dtlRecords++;
					}else if(line.startsWith("PRM")){
						prmRecords++;
					}else if(line.startsWith("SUP")){
						supRecords++;
					}
				}
				
				if(dtlRecords>0&&prmRecords==0&&supRecords==0){
					softAssertion.assertTrue(true,"Only DTL records present in the input file for the HICN:"+HICN);
					logger.log(LogStatus.INFO, "Validation for Only DTL records present in the input file for the HICN:"+HICN +"----"+true);
				}else{
					softAssertion.assertTrue(false,"Other than DTL records present in the input file for the HICN:"+HICN);
					logger.log(LogStatus.INFO, "Other than DTL records present in the input file for the HICN:"+HICN +"----"+false);
				}
				List<String>lines_Report=TestFileUtil.parseCOBFileForAllRows(reportFilePath,inputParameter1);
				for(String line:lines_Report){
					
					if("DTL only".equals(line.split(",")[38].trim())){
						flag_report=true;
						System.out.println("MSP Code-Report:"+line.split(",")[38]);
					}
				}
				softAssertion.assertTrue(flag_report, "Validation for Only DTL records in Report for the HICN:"+HICN+" is"+flag_report);
				logger.log(LogStatus.INFO, "Validation for Only DTL records in Report for the HICN:"+HICN+"----"+flag_report);
				//System.out.println("contractId_DB:"+contractId_DB+"|file contractId:"+contractId);
				
			}else if(testCaseId.equals("COB_TC009")){
				String HICN=inputParameter1;
				String recordType=inputParameter2.split(";")[0];
				String inputModifiedField=inputParameter2.split(";")[1].trim();
				String modifiedFiledValue="";
				String  line=TestFileUtil.parseCOBFile(inputFilePath,recordType+HICN);
				switch(inputModifiedField){
				case "MSP_RSN_CD":modifiedFiledValue=line.substring(110,111).trim();break;
				case "Record Type":modifiedFiledValue=line.substring(0,3).trim();break;
				case "HICN":modifiedFiledValue=line.substring(3,15).trim();break;
				case "DOB":modifiedFiledValue=line.substring(24,32).trim();break;
				case "SEQ_NBR":modifiedFiledValue=line.substring(102,105).trim();break;
			/*	case "":modifiedFiledValue=line.substring(,).trim();break;
				case "":modifiedFiledValue=line.substring(,).trim();break;
				case "":modifiedFiledValue=line.substring(,).trim();break;
				case "":modifiedFiledValue=line.substring(,).trim();break;
				case "":modifiedFiledValue=line.substring(,).trim();break;*/
				

				
				}
				String finalQuery=SQLQuery.split(";")[0].trim().replaceAll("ColumnName", inputModifiedField);
				
				listOfRecords = objDBUtility.resultSetToDictionary(finalQuery);//queryDataMap
				String modifieldFieldValue_DB=listOfRecords.get(0).get(inputModifiedField);//First element of list
				
				softAssertion.assertEquals(modifieldFieldValue_DB, modifiedFiledValue,"DB Value:"+modifieldFieldValue_DB+"| Input file value:"+modifiedFiledValue);
				logger.log(LogStatus.INFO, "DB Value:"+modifieldFieldValue_DB+"| Input file value:"+modifiedFiledValue+"|Validation :"+modifieldFieldValue_DB.equalsIgnoreCase(modifiedFiledValue));
				
				
				
				String finalQuery_HST=SQLQuery.split(";")[1].trim().replaceAll("Parameter1", HICN).replaceAll("ColumnName", inputModifiedField);
				listOfRecords = objDBUtility.resultSetToDictionary(finalQuery_HST);//queryDataMap
				String modifieldFieldValue_HST=listOfRecords.get(0).get(inputModifiedField);//First element of list
				if(modifieldFieldValue_DB.equalsIgnoreCase(modifieldFieldValue_HST)){
					softAssertion.fail("Custom Table Value:"+modifieldFieldValue_DB+"|History Table Value:"+modifieldFieldValue_HST);
					logger.log(LogStatus.INFO, "Custom Table Value:"+modifieldFieldValue_DB+"|History Table Value:"+modifieldFieldValue_HST+"|Validation:"+modifieldFieldValue_DB.equalsIgnoreCase(modifieldFieldValue_HST));
				}else{
					softAssertion.assertTrue(true,"Custom Table Value:"+modifieldFieldValue_DB+"|History Table Value:"+modifieldFieldValue_HST);
					logger.log(LogStatus.INFO, "Custom Table Value:"+modifieldFieldValue_DB+"|History Table Value:"+modifieldFieldValue_HST+"|Validation:"+modifieldFieldValue_DB.equalsIgnoreCase(modifieldFieldValue_HST));
				}
				
			}else if(testCaseId.equals("COB_TC010")){
				String HICN=inputParameter1;
				String recordType=inputParameter2;
				String insurersName="";
				List<String> lines=TestFileUtil.parseCOBFileForAllRows(inputFilePath,HICN);
				for(String line:lines){
					if(line.startsWith("SUP")||line.startsWith("PRM")){
						 insurersName=line.substring(112,144).trim();		
					}
				}
				String quer=SQLQuery.split(";")[0].trim().replaceAll("InsurerName", insurersName);
				listOfRecords = objDBUtility.resultSetToDictionary(quer);//queryDataMap
				String carierId_XwalkTable=listOfRecords.get(0).get("TGT_CARR_ID");//First element of list
				String query_Custom=SQLQuery.split(";")[1].trim().replaceAll("Parameter1", HICN).replaceAll("Parameter2", recordType);
				listOfRecords = objDBUtility.resultSetToDictionary(query_Custom);//queryDataMap
				String carrierId_CustomTable=listOfRecords.get(0).get("FACETS_COB_CARR_ID");//First element of list
				softAssertion.assertEquals(carierId_XwalkTable, carrierId_CustomTable,"Xwalk Table Value:"+carierId_XwalkTable+"| Custom Table value:"+carrierId_CustomTable);
				logger.log(LogStatus.INFO, "Xwalk Table Value:"+carierId_XwalkTable+"| Custom Table  value:"+carrierId_CustomTable+"|Validation:"+carierId_XwalkTable.equalsIgnoreCase(carrierId_CustomTable));
				
			}
			 } catch (Exception e) {
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
				
	}
	
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void ProducerDempgraphic(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();
		try {
			OtherUtilities.printTestCaseDeatilsInReport(data);
		
			String parameter1= data.get("Query parameter1").toString();//getting query parameter form data sheet
			String parameter2= data.get("Query parameter2").toString();
			String queryFromDataSheet = data.get("SqlQuery").toString();//getiing sql query from data sheet
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim()).replace( "Parameter2",parameter2.trim());//replacing query parameter in Sql query
			String inputFileName=data.get("Input File Name").toString();// getting input file name
			String strTestCaseID= data.get("Test Case ID").toString();
			String arrSQLQuery [] = SQLQuery.split(";");
			
			SUCName=data.get("SUC Name").toString();//getting suc name from data sheet
			String mappingSheetName="";
			for(String fileName:inputFileName.split(";")){//looping over array of input filenames array and checking for the file name and assigning values to mapping sheet name to identify sheet in file field and db column mapping excel file
				if(fileName!=null&&fileName.length()>0){
						 if("ICM_to_Facets_Producer_Super_Producer_Relationship_ChangeFile".equalsIgnoreCase(fileName.substring(0,fileName.lastIndexOf("_")))){
								mappingSheetName="PSPR";
							}
						else if("ICM_to_Facets_Producer_Super_Producer_ChangeFile".equalsIgnoreCase(fileName.substring(0,fileName.lastIndexOf("_")))){
							mappingSheetName="PSP";
						}else if("ICM_to_Facets_SalesRep_Relationship_FullFile".equalsIgnoreCase(fileName.substring(0,fileName.lastIndexOf("_")))){
							mappingSheetName="SRR";
						}else if("ICM_to_Facets_SalesRepDemographic_FullFile".equalsIgnoreCase(fileName.substring(0,fileName.lastIndexOf("_")))){
							mappingSheetName="SRD";
						}
			
						 List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\|",rootLocationOfInputFiles+"\\"+SUCName+"\\"+inputFileName,fileFieldAndDBColumnMappingFilePath,mappingSheetName);
						 //PSPR file validation with BSCA N record
						 if ( strTestCaseID.equalsIgnoreCase("TC046") ){
							 List<Map<String,String>> SourceBscMap=TestFileUtil.getMultiRowMapWithTwoColumnValues("TAX_ID",parameter1,"CARE1STINDICATOR","N",rowsList);
							 int intSourceBscMapCount = SourceBscMap.size();
							 for(int i = 0;i<intSourceBscMapCount;i++){
								 Map<String,String>map=	SourceBscMap.get(i);//get first record in dictionary
								 SQLQuery=queryFromDataSheet.replace( "Parameter9","0"+(i+5));//replacing query parameter in Sql query
								 SQLQuery=SQLQuery.replace( "Parameter8",map.get("SUPER_PRODUCER_TAX_ID").trim());//replacing query parameter in Sql query
								 SQLQuery=SQLQuery.replace( "Parameter1",map.get("TAX_ID").trim());//replacing query parameter in Sql query
								 List<Map<String, String>> listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
								 if(listOfRecords.size() > 0){
									softAssertion.assertTrue(true,"Tax ID (" + map.get("TAX_ID") + ") and Sales Rep (" + map.get("SUPER_PRODUCER_TAX_ID") + ") relation is present in the FACETS database");
									logger.log(LogStatus.INFO,"Tax ID (" + map.get("TAX_ID") + ") and Sales Rep (" + map.get("SUPER_PRODUCER_TAX_ID") + ") relation is present in the FACETS database");
								 }else{
									softAssertion.assertTrue(false,"Tax ID (" + map.get("TAX_ID") + ") and Sales Rep (" + map.get("SUPER_PRODUCER_TAX_ID") + ") relation  is NOT present in the FACETS database");
									logger.log(LogStatus.INFO,"Tax ID (" + map.get("TAX_ID") + ") and Sales Rep (" + map.get("SUPER_PRODUCER_TAX_ID") + ") relation is NOT present in the FACETS database");
								 }
							 }
							 
						 }
						 ////PSPR file validation with Care 1st Y  record
						 if ( strTestCaseID.equalsIgnoreCase("TC047") ){
							 Map<String,String> SourceCareMap=TestFileUtil.getRowMapWithTwoColumnValues("TAX_ID",parameter1,"CARE1STINDICATOR","Y",rowsList);
								 SQLQuery=SQLQuery.replace( "Parameter8",SourceCareMap.get("SUPER_PRODUCER_TAX_ID").trim());//replacing query parameter in Sql query
								 SQLQuery=SQLQuery.replace( "Parameter1",SourceCareMap.get("TAX_ID").trim());//replacing query parameter in Sql query
								 List<Map<String, String>> listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
								 if(listOfRecords.size() > 0){
									softAssertion.assertTrue(true," Producer Tax ID (" + SourceCareMap.get("TAX_ID") + ") and Super producer Sales Rep ID (" + SourceCareMap.get("SUPER_PRODUCER_TAX_ID") + ") relation is present in the FACETS database");
									logger.log(LogStatus.INFO," ProducerTax ID (" + SourceCareMap.get("TAX_ID") + ") and Super producer Sales Rep ID (" + SourceCareMap.get("SUPER_PRODUCER_TAX_ID") + ") relation is present in the FACETS database");
								 }else{
									softAssertion.assertTrue(false," Producer Tax ID (" + SourceCareMap.get("TAX_ID") + ") and Super producer Sales Rep ID (" + SourceCareMap.get("SUPER_PRODUCER_TAX_ID") + ") relation  is NOT present in the FACETS database");
									logger.log(LogStatus.INFO," Producer Tax ID (" + SourceCareMap.get("TAX_ID") + ") and Super producer Sales Rep ID (" + SourceCareMap.get("SUPER_PRODUCER_TAX_ID") + ") relation is NOT present in the FACETS database");
								 }
						
						 }
						 //SRR file validation with care1st Y record
						 if ( strTestCaseID.equalsIgnoreCase("TC044") ){
								Map<String,String>SourceCareMap=TestFileUtil.getRowMapWithTwoColumnValues("TAX_ID",parameter1,"CARE1STINDICATOR","Y",rowsList);
								SQLQuery=queryFromDataSheet.replace( "Parameter3",SourceCareMap.get("SALES_REP_ID4").trim());//replacing query parameter in Sql query
								SQLQuery=SQLQuery.replace( "Parameter1",parameter1);//replacing query parameter in Sql query
								listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
								if(listOfRecords.size() > 0){
									softAssertion.assertTrue(true,"Tax ID (" + SourceCareMap.get("TAX_ID") + ") and Sales Rep (" + SourceCareMap.get("SALES_REP_ID4") + ") relation is present in the FACETS database");
									logger.log(LogStatus.INFO,"Tax ID (" + SourceCareMap.get("TAX_ID") + ") and Sales Rep (" + SourceCareMap.get("SALES_REP_ID4") + ") relation is present in the FACETS database");
								}else{
									softAssertion.assertTrue(false,"Tax ID (" + SourceCareMap.get("TAX_ID") + ") and Sales Rep (" + SourceCareMap.get("SALES_REP_ID4") + ") relation  is NOT present in the FACETS database");
									logger.log(LogStatus.INFO,"Tax ID (" + SourceCareMap.get("TAX_ID") + ") and Sales Rep (" + SourceCareMap.get("SALES_REP_ID4") + ") relation is NOT present in the FACETS database");
								}
						 }
						//SRR file validation with BSCA N record
						 if ( strTestCaseID.equalsIgnoreCase("TC045") ){
							 Map<String,String>SourceBscMap=TestFileUtil.getRowMapWithTwoColumnValues("TAX_ID",parameter1,"CARE1STINDICATOR","N",rowsList);
							 if(SourceBscMap.get("SALES_REP_ID1")!="" && SourceBscMap.get("SALES_REP_ID1").length() > 0)
							 OtherUtilities.SRRProducerDemographicCareDetails(SourceBscMap,arrSQLQuery[0],"SALES_REP_ID1",objDBUtility,softAssertion);
							 if(SourceBscMap.get("SALES_REP_ID2")!="" && SourceBscMap.get("SALES_REP_ID2").length() > 0)
							 OtherUtilities.SRRProducerDemographicCareDetails(SourceBscMap,arrSQLQuery[1],"SALES_REP_ID2",objDBUtility,softAssertion);
							 if(SourceBscMap.get("SALES_REP_ID3")!="" && SourceBscMap.get("SALES_REP_ID3").length() > 0)
							 OtherUtilities.SRRProducerDemographicCareDetails(SourceBscMap,arrSQLQuery[2],"SALES_REP_ID3",objDBUtility,softAssertion);
							 if(SourceBscMap.get("SALES_REP_ID4")!="" && SourceBscMap.get("SALES_REP_ID4").length() > 0)
							 OtherUtilities.SRRProducerDemographicCareDetails(SourceBscMap,arrSQLQuery[3],"SALES_REP_ID4",objDBUtility,softAssertion);
						 }
						

						 if ( strTestCaseID.equalsIgnoreCase("TC002") ){
							 Map<String,String>SourceBscMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","N",rowsList);
							 for(Map.Entry<String,String >child:SourceBscMap.entrySet()){// looping through all rows in map
								flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map
							 }
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[0]);//queryDataMap
							 OtherUtilities.PSPProducerDemographicCareDetails(SourceBscMap,listOfRecords,softAssertion);
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[1]);//queryDataMap
							 Map<String,String>SourceCareMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","Y",rowsList);
							 OtherUtilities.SRDProducerDemographicCareDetails(SourceCareMap,listOfRecords,softAssertion);
							 OtherUtilities.PSPTableValidation(strTestCaseID,arrSQLQuery,objDBUtility,softAssertion);
						 }
						 if ( strTestCaseID.equalsIgnoreCase("TC008")){
							 Map<String,String>SourceBscMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","N",rowsList);
							 for(Map.Entry<String,String >child:SourceBscMap.entrySet()){// looping through all rows in map
								flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map
							 }
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[0]);//queryDataMap
							 OtherUtilities.PSPProducerDemographicCareDetails(SourceBscMap,listOfRecords,softAssertion);
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[1]);//queryDataMap
							 if(listOfRecords.size() == 3){
									softAssertion.assertTrue(true," Care 1st records (55,56,57) are present in the FACETS database");
									logger.log(LogStatus.INFO," Care 1st records (55,56,57) are present in the FACETS database");
								}else{
									softAssertion.assertTrue(false," Care 1st records (55,56,57) are not present in the FACETS database");
									logger.log(LogStatus.INFO," Care 1st records (55,56,57) are not present in the FACETS database");
							 }
							 OtherUtilities.PSPTableValidation(strTestCaseID,arrSQLQuery,objDBUtility,softAssertion);
						 }

						 if ( strTestCaseID.equalsIgnoreCase("TC003") || strTestCaseID.equalsIgnoreCase("TC007") || strTestCaseID.equalsIgnoreCase("TC005")){
							 
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[0]);//queryDataMap
							 if(listOfRecords.size() == 10){
									softAssertion.assertTrue(true," Care 1st records (00 to 09) for COCI_SSN (" + parameter1 + ") are present in the FACETS database");
									logger.log(LogStatus.INFO," Care 1st records (00 to 09) for COCI_SSN (" + parameter1 + ") are present in the FACETS database");
								}else{
									softAssertion.assertTrue(false," Care 1st records (00 to 09) for COCI_SSN (" + parameter1 + ") are not present in the FACETS database");
									logger.log(LogStatus.INFO," Care 1st records (00 to 09) for COCI_SSN (" + parameter1 + ") are not present in the FACETS database");
							 }
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[1]);//queryDataMap
							 Map<String,String>SourceCareMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","Y",rowsList);
							 OtherUtilities.SRDProducerDemographicCareDetails(SourceCareMap,listOfRecords,softAssertion);
							 OtherUtilities.PSPTableValidation(strTestCaseID,arrSQLQuery,objDBUtility,softAssertion);
						 }
						 if ( strTestCaseID.equalsIgnoreCase("TC004") || strTestCaseID.equalsIgnoreCase("TC006") ){
							 Map<String,String>SourceBscMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","N",rowsList);
							 for(Map.Entry<String,String >child:SourceBscMap.entrySet()){// looping through all rows in map
								flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map
							 }
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[0]);//queryDataMap
							 OtherUtilities.PSPProducerDemographicCareDetails(SourceBscMap,listOfRecords,softAssertion);
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[1]);//queryDataMap
							 if(listOfRecords.size() > 0 ){
									softAssertion.assertTrue(false," Care 1st records (55,56,57) are present in the FACETS database");
									logger.log(LogStatus.INFO," Care 1st records (55,56,57) are present in the FACETS database");
								}else{
									softAssertion.assertTrue(true," Care 1st records (55,56,57) are not present in the FACETS database");
									logger.log(LogStatus.INFO," Care 1st records (55,56,57) are not present in the FACETS database");
							 }
							 OtherUtilities.PSPTableValidation(strTestCaseID,arrSQLQuery,objDBUtility,softAssertion);
						 }
						 
						 //TC068: Verify that the interface is able to create the commission entity 00-09 for BSC and 55,56,57 for Care1st in Facets when Care1st indicator is ‘Y’ and BSC indicator as ‘N’ in input files and commission entity information is not presented in Facets
						 //TC077: Verify that the interface is able to create the commission entities 00  for BSC and 55,56,57 for Care1st   in Facets when Care1st indicator is ‘Y’ and BSC indicator as ‘N’ in input files and  Care1st commission entity information is  present in Facets  and BSC  commission entity information is   present in facets
						 if ( strTestCaseID.equalsIgnoreCase("TC068") || strTestCaseID.equalsIgnoreCase("TC077")){
							 
							 Map<String,String>SourceBscMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","N",rowsList);
							
							 for(Map.Entry<String,String >child:SourceBscMap.entrySet()){// looping through all rows in map
									flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map
									//System.out.println("Key: "+child.getKey()+" Value: "+child.getValue());	
								}
							 Map<String,String>SourceCareMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","Y",rowsList);
							 
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[0]);//queryDataMap
								queryDataMap=listOfRecords.get(0);//First element of list
								queryDataMap.remove("COCE_ID");
								OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
								 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[1]);//queryDataMap
								 
								 OtherUtilities.SRDProducerDemographicCareDetails(SourceCareMap,listOfRecords,softAssertion);
						 }
						 //Verify that the interface is able to create the commission entity 00-09  and 55,56,57 for Care1st in Facets when Care1st indicator is ‘Y’ and  no BSC indicator  in input files and commission entity information is not presented in Facets
						 if ( strTestCaseID.equalsIgnoreCase("TC069") ){
							 
							 Map<String,String>SourceBscMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","Y",rowsList);
							
							 for(Map.Entry<String,String >child:SourceBscMap.entrySet()){// looping through all rows in map
									flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map
									//System.out.println("Key: "+child.getKey()+" Value: "+child.getValue());	
								}
							 Map<String,String>SourceCareMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","Y",rowsList);
							 
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[0]);//queryDataMap
								queryDataMap=listOfRecords.get(0);//First element of list
								queryDataMap.remove("COCE_ID");
								OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
								 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[1]);//queryDataMap
								 
								 OtherUtilities.SRDProducerDemographicCareDetails(SourceCareMap,listOfRecords,softAssertion);

						 }
						 
						 //TC071: Verify that the interface is able to create the commission entity  55,56,57 for Care1st in Facets when Care1st indicator is ‘Y’ and  no BSC indicator in input files and  Care1st commission entity information is not presented in Facets  and BSC  commission entity information is  present in facets
						 //TC073: Verify that the interface is able to create the commission entity 55,56,57 for Care1st in Facets when Care1st indicator is ‘Y’ and no BSC indicator  in input files and  Care1st commission entity information is  present in Facets  and BSC  commission entity information is not   present in facets
						 if ( strTestCaseID.equalsIgnoreCase("TC071") || strTestCaseID.equalsIgnoreCase("TC073")){
							 Map<String,String>SourceCareMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","Y",rowsList);
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[0]);//queryDataMap
							 if (listOfRecords.size() !=1){
								softAssertion.fail("In FACETS database zero records or more than one record is present");
								logger.log(LogStatus.INFO,"In FACETS database zero records or more than one record is present");
							 }								
								 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[1]);//queryDataMap
								 if(SourceCareMap.size() > 0){
									 OtherUtilities.SRDProducerDemographicCareDetails(SourceCareMap,listOfRecords,softAssertion);
								 }else{
									
										softAssertion.fail("Care1st three records are  present in the FACETS database");
										logger.log(LogStatus.INFO,"Care1st three records are  present in the FACETS database");
									
								 }
						 }
						 
						//TC070: Verify that the interface is able to create the commission entity 00-09  for BSC in Facets when  no Care1st indicator  and BSC indicator as ‘N’ in input files and commission entity information is not presented in Facets
						 //TC072: Verify that the interface is able to create the commission entity 00  for BSC in Facets when no Care1st indicator  and BSC indicator as ‘N’ in input files and  Care1st commission entity information is not presented in Facets  and BSC  commission entity information is  present in facets
						 if ( strTestCaseID.equalsIgnoreCase("TC070") || strTestCaseID.equalsIgnoreCase("TC072")){
							 Map<String,String>SourceBscMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","N",rowsList);
							 for(Map.Entry<String,String >child:SourceBscMap.entrySet()){// looping through all rows in map
									flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map
								}
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[0]);//queryDataMap
								queryDataMap=listOfRecords.get(0);//First element of list
								queryDataMap.remove("COCE_ID");
								OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
								 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[1]);//queryDataMap
								 if (listOfRecords.size() >0){
									softAssertion.fail("BSCA record is not present in the test data flat file");
									logger.log(LogStatus.INFO,"BSCA record is not present in the test data flat file");
								 }
						 }
						 
						 //Verify that the interface is able to create the commission entity 00  for BSC  in Facets when no Care1st indicator  and BSC indicator as ‘N’ in input files and  Care1st commission entity information is  present in Facets  and BSC  commission entity information is not   present in facets
						 if ( strTestCaseID.equalsIgnoreCase("TC074")){
							 
							 Map<String,String>SourceBscMap=TestFileUtil.getRowMapWithTwoColumnValues("COCI_SSN",parameter1,"CARE1STINDICATOR","N",rowsList);
							
							 for(Map.Entry<String,String >child:SourceBscMap.entrySet()){// looping through all rows in map
									flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map
								}
							 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[0]);//queryDataMap
								queryDataMap=listOfRecords.get(0);//First element of list
								queryDataMap.remove("COCE_ID");
								OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
								 listOfRecords = objDBUtility.resultSetToDictionary(arrSQLQuery[1]);//queryDataMap
								 if (listOfRecords.size() <3){
									softAssertion.assertTrue(false,"Care1st three records are not present in the FACETS database");
									logger.log(LogStatus.INFO,"Care1st three records are not present in the FACETS database");
								 }
									
							
						 }
				}
			}
			
			
			 } catch (Exception e) {
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
	}
	
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void InboundAndOutboundValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			String parameter1= data.get("Query parameter1").toString();//getting query parameter form data sheet
			String parameter2= data.get("Query parameter2").toString();
			String queryFromDataSheet = data.get("SqlQuery").toString();//getiing sql query from data sheet
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim()).replace( "Parameter2",parameter2.trim());//replacing query parameter in Sql query
			listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
			queryDataMap=listOfRecords.get(0);//First element of list
			String inputFileName=data.get("Input File Name").toString();// getting input file name
			SUCName=data.get("SUC Name").toString();//getting suc name from data sheet
			System.out.println("SUCName : "+SUCName);
			String mappingSheetName="";
			for(String fileName:inputFileName.split(";")){//looping over array of input filenames array and checking for the file name and assigning values to mapping sheet name to identify sheet in file field and db column mapping excel file
				if(fileName!=null&&fileName.length()>0){
						 if("ICM_to_Facets_Producer_ChangeFile_20180514".equalsIgnoreCase(fileName.substring(0,fileName.lastIndexOf(".")))){
								mappingSheetName="PC";
							}
						else if("ICM_to_Facets_Producer_Super_Producer_Relationship_ChangeFile_20180514".equalsIgnoreCase(fileName.substring(0,fileName.lastIndexOf(".")))){
							mappingSheetName="PSP";
						}else if("ICM_to_Facets_SalesRep_Relationship_FullFile_20180514".equalsIgnoreCase(fileName.substring(0,fileName.lastIndexOf(".")))){
							mappingSheetName="SRR";
						}else if("ICM_to_Facets_SalesRepDemographic_FullFile".equalsIgnoreCase(fileName.substring(0,fileName.lastIndexOf("_")))){
							mappingSheetName="SRD";System.out.println("Input File Name in Else if block: "+fileName.substring(0,fileName.lastIndexOf("_")));
						}
			//OUTBoundFileName need to replace with original name			else if("OUTBoundFileName".equalsIgnoreCase(fileName.substring(0,fileName.lastIndexOf(".")))){
							//mappingSheetName="CCE_Outbound";				}
						 // calling method to retrieve rows in file 
						 List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\|",rootLocationOfInputFiles+"\\"+SUCName+"\\"+fileName,fileFieldAndDBColumnMappingFilePath,mappingSheetName);	
						Map<String,String>map=	rowsList.get(0);//get first record in dictionary
						for(Map.Entry<String,String >child:map.entrySet()){// looping through all rows in map
							flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map
							System.out.println("Key: "+child.getKey()+" Value: "+child.getValue());	
						}
				}
			}
			System.out.println("-------------------Flat File Data:---------------------------------");
			System.out.println(flatFileValuesMap);
			/*Map<String,String>sourceRowMap=TestFileUtil.getRowMap(primaryKeyColumnName,parameter1,rowsList);*/
			//calling validate method to validate two dictionary and print results
			OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
			 } catch (Exception e) {
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
	}
	
	
	// This test will perform all validation in "Commissions EFT From Facets To Bank" SUC
	@Test(dataProvider = "masterDataProvider")
	private static void CommissionsEFTFromFacetsToBank(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			// Placing all required test data values in the html report
			OtherUtilities.printTestCaseDeatilsInReport(data);
			// Retrieving test data values and storing in the variables
			String strBatchRun=data.get("BatchRun Completed").toString().toUpperCase();
			String inputFileName=data.get("Input File Name").toString();
			 SUCName=data.get("SUC Name").toString();			
			String parameter1= data.get("Query parameter1").toString();//getting query parameter form data sheet
			String parameter2= data.get("Query parameter2").toString();
			String queryFromDataSheet = data.get("SqlQuery").toString();//getiing sql query from data sheet
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim()).replace( "Parameter2",parameter2.trim());//replacing query parameter in Sql query
			String strTestCaseID = data.get("Test Case ID").toString();
			Map<String,String> flatFileValuesMap=new HashMap<String,String>();
			String[] arrStrInputFileName = inputFileName.split(";");
			// Checking ";" in the query column in test data sheet
			if(SQLQuery.contains(";")){
				String[] arrStrQueries = SQLQuery.split(";");
				//Validating this test case "TC007_BRD612183_SUC586425_DFUNC_Commissions EFT Facets to Bank_Payment Method"
				if (strTestCaseID.equalsIgnoreCase("TC007")){
					listOfRecords = objDBUtility.resultSetToDictionary(arrStrQueries[0]);
					if(listOfRecords.size()>1 || listOfRecords.size()<1){//check for more than one record
						logger.log(LogStatus.INFO,"More or less records present in the database");
						softAssertion.assertTrue(false, "More or less records present in the database" );
					}
					else{					
						queryDataMap=listOfRecords.get(0);//First element of list
						flatFileValuesMap.put("COCE_PAY_CO_METH", "E");
						OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
					}
					/*List<Map<String,String>>listOfRecords2=new ArrayList<Map<String,String>>();
					listOfRecords2 = objDBUtility.resultSetToDictionary(arrStrQueries[1]);
					if(listOfRecords.size()>1 || listOfRecords.size()<1){//check for more than one record
						logger.log(LogStatus.INFO,"More or less records present in the database");
						softAssertion.assertTrue(false, "More or less records present in the database" );
					}
					else{					
						queryDataMap=listOfRecords2.get(0);//First element of list			
						flatFileValuesMap.put("CKCK_CURR_STS", "E3");
						OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
					}*/
				}
			else{
					
					
					//Validating initial two interfaces
					if (strBatchRun.equalsIgnoreCase("First Interface")){					
						listOfRecords = objDBUtility.resultSetToDictionary(arrStrQueries[0]);//queryDataMap
						if(listOfRecords.size()>1 || listOfRecords.size()<1){//check for more than one record
							logger.log(LogStatus.INFO,"More or less records present in the database");
							softAssertion.assertTrue(false, "More or less records present in the database" );
						}
						else{					
							queryDataMap=listOfRecords.get(0);//First element of list
							String fileName = arrStrInputFileName[0];
							String mappingSheetName;
							if(fileName!=null&&fileName.length()>0){
								 
								mappingSheetName="CommissionsEFTFromFacetsToBank";
								List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\,",rootLocationOfInputFiles+"\\"+SUCName+"\\"+fileName,fileFieldAndDBColumnMappingFilePath,mappingSheetName);
								String strPrimaruKeyValueInMockUpFile = queryDataMap.get("COCA_PYMT_DESC");
								Map<String,String>map=TestFileUtil.getRowMap("COCA_PYMT_DESC",strPrimaruKeyValueInMockUpFile,rowsList);							
								for(Map.Entry<String,String >child:map.entrySet()){// looping through all rows in map
									flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map	
								}
								OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
							}
							else{
								logger.log(LogStatus.INFO,"Invalid file name: " + fileName);
								softAssertion.assertTrue(false, "Invalid file name" );						
							}
						}
					}
					//Validating 2nd interface
					else if(strBatchRun.equalsIgnoreCase("Second Interface")){
						listOfRecords = objDBUtility.resultSetToDictionary(arrStrQueries[1]);//queryDataMap
						if(listOfRecords.size()>1 || listOfRecords.size()>1){//check for more or less records in the database
							softAssertion.assertTrue(false, "More or less records present in the database" );
						}
						else{
						queryDataMap=listOfRecords.get(0);
						softAssertion.assertTrue(true, "Data is present in the database and test case is passed" );
						}
						
					}
					//Validating 3rd interface
					else if(strBatchRun.equalsIgnoreCase("Third Interface")){		
						inputFileName = rootLocationOfInputFiles+"\\"+SUCName+"\\"+arrStrInputFileName[1];
						ffpExtract = new BscaCare1stMMFlatFileReader(inputFileName);//this will set up the FileReader of ffpojo library
						List<Map<String , String>> listOfBodyMap  = new ArrayList<Map<String,String>>();
						Map<String,List<Object>> recordsMap=new HashMap<String,List<Object>>();
						FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(CommissionsEFTFromFacetsToBankFlatFileBody.class);   // <== BODY
						
						recordsMap=ffpExtract.getFlatFileData(ffDefinition);
						// Retrieving all flat file values and storing into a map
						for(Object record:recordsMap.get("Body")){
							CommissionsEFTFromFacetsToBankFlatFileBody body = (CommissionsEFTFromFacetsToBankFlatFileBody)record;
							Map<String,String> bodyMap=new HashMap<String,String>();						
							bodyMap.put("Transit_Route_Number".toUpperCase(), body.getTransit_Route_Number().toUpperCase()); //<== Add 
							bodyMap.put("Transit_Route_Check_Digit".toUpperCase(), body.getTransit_Route_Check_Digit().toUpperCase()); //<== Add 
							bodyMap.put("Individual_Account_Number".toUpperCase(), body.getIndividual_Account_Number()); //<== Add 
							bodyMap.put("Dollar_Amount".toUpperCase(), body.getDollar_Amount()); //<== Add 
							bodyMap.put("Indiv_Identification_Number".toUpperCase(), body.getIndividual_Identification_Number()); //<== Add 
							bodyMap.put("Company_Name_ID_number".toUpperCase(), body.getReceiving_Company_Name_ID_number().toUpperCase()); //<== Add 
							bodyMap.put("First_Initial_Of_First_Name".toUpperCase(), body.getFirst_Initial_Of_First_Name()); //<== Add 
							bodyMap.put("First_Initial_Of_Middle_Name".toUpperCase(), body.getFirst_Initial_Of_Middle_Name()); //<== Add
							listOfBodyMap.add(bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
						}			
						System.out.println("Flat file list map: " + listOfBodyMap);														
						String primaryKeyColumnName="Indiv_Identification_Number".toUpperCase();					
						flatFileValuesMap=TestFileUtil.getRowMap(primaryKeyColumnName,parameter1,listOfBodyMap);										
						listOfRecords = objDBUtility.resultSetToDictionary(arrStrQueries[2]);//queryDataMap			
						if(listOfRecords.size()>1 || listOfRecords.size()<1){//check for more than one record
							logger.log(LogStatus.INFO,"More or less records present in database");
							softAssertion.assertTrue(false, "More or less records present in database" );
						}
						else{				 
						queryDataMap=listOfRecords.get(0);				
						OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
						}   
					}
					else{
						logger.log(LogStatus.INFO,"Invalid BatchRun Completed " + strBatchRun + " column value in test data sheet");
						softAssertion.assertTrue(false, "Invalid 'BatchRun Completed' column value in test data sheet" );
					}
				}
			}
					
			else{
				logger.log(LogStatus.INFO,"Invalid query data in test data sheet");
				softAssertion.assertTrue(false, "Invalid query data in test data sheet" );
			}
			 } catch (Exception e) {
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
	}
	

	
	// This test will perform all validation in "Commissions EFT From Facets To Bank" SUC
	@Test(dataProvider = "masterDataProvider")
	private static void CommissionsPaymentAndCheckStatus(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			// Placing all required test data values in the html report
			OtherUtilities.printTestCaseDeatilsInReport(data);
			// Retrieving test data values and storing in the variables
			String inputFileName=data.get("Input File Name").toString();
			 SUCName=data.get("SUC Name").toString();			
			String parameter1= data.get("Query parameter1").toString();//getting query parameter form data sheet
			String parameter2= data.get("Query parameter2").toString();
			String queryFromDataSheet = data.get("SqlQuery").toString();//getiing sql query from data sheet
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim()).replace( "Parameter2",parameter2.trim());//replacing query parameter in Sql query
			String strTestCaseID = data.get("Test Case ID").toString();
			Map<String,String> flatFileValuesMap=new HashMap<String,String>();
			String[] arrStrInputFileName = inputFileName.split(";");
			String mappingSheetName;
			
			if(strTestCaseID.equalsIgnoreCase("TC021") ||strTestCaseID.equalsIgnoreCase("TC019") ||strTestCaseID.equalsIgnoreCase("TC012") ||strTestCaseID.equalsIgnoreCase("TC005")){
				
				
				listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
				if(listOfRecords.size()>0){//check for more than one record
					logger.log(LogStatus.INFO,"Record is not processed in the FACETS database");
					softAssertion.assertTrue(true, "Record is not processed in the FACETS database" );
				}else{
					logger.log(LogStatus.INFO,"Record is are processed in the FACETS database");
					softAssertion.assertTrue(true, "Record is are processed in the FACETS database" );
				}
				
				String fileName = arrStrInputFileName[0];
				String fileName2 = arrStrInputFileName[1];
				if(fileName!=null&&fileName.length()>0 && fileName2!=null&&fileName2.length()>0){
					 
					mappingSheetName="CommissionsPaymentsCheques";
					List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\,",rootLocationOfInputFiles+"\\"+SUCName+"\\"+fileName,fileFieldAndDBColumnMappingFilePath,mappingSheetName);
					String strPrimaruKeyValueInMockUpFile = parameter1;
					Map<String,String>map=TestFileUtil.getRowMap("COCI_SSN",strPrimaruKeyValueInMockUpFile,rowsList);							
					for(Map.Entry<String,String >child:map.entrySet()){// looping through all rows in map
						flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map	
					}
					
					mappingSheetName="CommissionsPaymentsCheckErr";
					List<Map<String,String>>listOfRecords=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\,",rootLocationOfInputFiles+"\\"+SUCName+"\\"+fileName2,fileFieldAndDBColumnMappingFilePath,mappingSheetName);
					//String strPrimaruKeyValueInMockUpFile = parameter1;
					Map<String,String>map2=TestFileUtil.getRowMap("COCI_SSN",strPrimaruKeyValueInMockUpFile,listOfRecords);							
					for(Map.Entry<String,String >child:map2.entrySet()){// looping through all rows in map
						queryDataMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map	
					}
					if(strTestCaseID.equalsIgnoreCase("TC021")){
						flatFileValuesMap.put("ERR_MSG", "Care1st Broker does not have EFT payment mode setup".toUpperCase());
					}
					if(strTestCaseID.equalsIgnoreCase("TC012")){
						flatFileValuesMap.put("ERR_MSG", "No COCE_ID found in Facets for COCI_ID".toUpperCase());  //"Missing COCE_ID"
					}
					if(strTestCaseID.equalsIgnoreCase("TC005")){
						flatFileValuesMap.put("ERR_MSG", "LOBD_ID is not available in Facets".toUpperCase()); 
					}
					
					else{
						flatFileValuesMap.put("ERR_MSG", "");
						queryDataMap.put("ERR_MSG", "");
					}
						
					flatFileValuesMap.put("FILE_NAME", fileName.toUpperCase());
					
					OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
				}
				else{
					logger.log(LogStatus.INFO,"Invalid file name,file name1 - " + fileName + " file name 2 - " + fileName2);
					softAssertion.assertTrue(false, "Invalid file name,file name1 - " + fileName + " file name 2 - " + fileName2);						
				}
			}
			else{
				
				listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
				if(listOfRecords.size()>1 || listOfRecords.size()<1){//check for more than one record
					logger.log(LogStatus.INFO,"More or less records present in the database");
					softAssertion.assertTrue(false, "More or less records present in the database" );
				}
				else{					
					queryDataMap=listOfRecords.get(0);//First element of list
					String fileName = arrStrInputFileName[0];
					
					if(fileName!=null&&fileName.length()>0){
						 
						mappingSheetName="CommissionsPaymentsCheques";
						List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\,",rootLocationOfInputFiles+"\\"+SUCName+"\\"+fileName,fileFieldAndDBColumnMappingFilePath,mappingSheetName);
						String strPrimaruKeyValueInMockUpFile = parameter1;
						Map<String,String>map=TestFileUtil.getRowMap("COCI_SSN",strPrimaruKeyValueInMockUpFile,rowsList);							
						for(Map.Entry<String,String >child:map.entrySet()){// looping through all rows in map
							flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map	
						}
						OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
					}
					else{
						logger.log(LogStatus.INFO,"Invalid file name: " + fileName);
						softAssertion.assertTrue(false, "Invalid file name -" + fileName);						
					}
				}

			}
					
				
			
	
			 } catch (Exception e) {
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
	}
	
	
	
	
	// This test will perform all validation in "Commissions EFT From Facets To Bank" SUC
	// This method will validate 167 fields in EAM to MAM interface
	@Test(dataProvider = "masterDataProvider")
	private static void MAMToEAMInterface(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			// Placing all required test data values in the html report
			OtherUtilities.printTestCaseDeatilsInReport(data);
			
			// Retrieving test data values and storing in the variables
			String inputFileName=data.get("Input File Name").toString();
			 SUCName=data.get("SUC Name").toString();			
			String parameter1= data.get("Query parameter1").toString();//getting query parameter form data sheet
			logger.log(LogStatus.INFO," Selected confirmation number for this record is: " + parameter1);
			String parameter2= data.get("Query parameter2").toString();
			String queryFromDataSheet = data.get("SqlQuery").toString();//getiing sql query from data sheet
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim()).replace( "Parameter2",parameter2.trim());//replacing query parameter in Sql query
			Map<String,String> flatFileValuesMap=new HashMap<String,String>();
			//String[] arrStrInputFileName = inputFileName.split(";");
			String[] arrStrQueries = SQLQuery.split(";");
					
					
									
						listOfRecords = objDBUtility.resultSetToDictionary(arrStrQueries[0]);//queryDataMap
						if(listOfRecords.size()<1 || listOfRecords.size()<1){//check for more than one record
							logger.log(LogStatus.INFO," Record is not present in the FACETS database");
							softAssertion.assertTrue(false, " Record is not present in the FACETS database" );
						}
						else{					
							queryDataMap=listOfRecords.get(0);//First element of list
							String fileName = inputFileName;
							
							if(fileName!=null&&fileName.length()>0){
								 
								
								//List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\,",rootLocationOfInputFiles+"\\"+SUCName+"\\"+fileName,fileFieldAndDBColumnMappingFilePath,mappingSheetName);
								List<Map<String,String>>rowsList = TestFileUtil.parseFileWithDelimeter(rootLocationOfInputFiles+"\\"+SUCName+"\\"+fileName);
								Map<String,String>map=TestFileUtil.getRowMap("CONFIRMATIONNUMBER",parameter1,rowsList);							
								for(Map.Entry<String,String >child:map.entrySet()){// looping through all rows in map
									flatFileValuesMap.put(child.getKey(), child.getValue());//inserting the data into flatfile values map	
								}
								System.out.println(" flat file :" + flatFileValuesMap );
								System.out.println( " query map: " + queryDataMap);
								OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
							}
							else{
								logger.log(LogStatus.INFO,"Invalid file name: " + fileName);
								softAssertion.assertTrue(false, "Invalid file name" + fileName );						
							}
						}
						listOfRecords = objDBUtility.resultSetToDictionary(arrStrQueries[1]);//queryDataMap
						if(listOfRecords.size()>0){//check for more than one record
							logger.log(LogStatus.INFO," Status 30 Record is  present in the FACETS database");
							softAssertion.assertTrue(true, " Status 30 Record is  present in the FACETS database");
						}else{
							logger.log(LogStatus.INFO," Status 30 Record is NOT present in the FACETS database");
							softAssertion.assertTrue(false, " Status 30 Record is NOT present in the FACETS database");
						}
					
		
			 } catch (Exception e) {
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
	}
	

	
	//New Testcase
	
		@Test(dataProvider = "masterDataProvider")
		private static void RefIDNotPresentValidation(Map<String, String> data) {
			SoftAssert softAssertion= new SoftAssert();	 
			try {
				System.out.println("Starting of RefIDNotPresentValidation..!! ");
				SUCName=data.get("SUC Name").toString();	
				String parameter1= data.get("Query parameter1").toString();//getting query parameter form data sheet
				String queryFromDataSheet = data.get("SqlQuery").toString();//getting Sql query form data sheet
				String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim());//replacing query parameter in Sql query
				listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//result set to list of dictionaries
				queryDataMap=listOfRecords.get(0);//First element of list
				String testFlatFileCompletePath = "C:\\Users\\bgujja01\\Desktop\\0409Daily Extracts\\Daily Extracts";
				for(Map<String,String>rowMap:listOfRecords){
					if(rowMap.containsKey("UMUM_REF_ID")){//checking for key in map
						String sKey = rowMap.get("UMUM_REF_ID");
					
					softAssertion.assertTrue(TestFileUtil.CheckRefIDNotPresent(sKey, testFlatFileCompletePath));
				}
				
				softAssertion.assertAll();//log all the assert into report
				}
			}catch(Exception e){
				softAssertion.assertAll();//log all the assert into report
			}
			}
		
		
		
		
	// this test method is for PEAF Scrubber 
	@Test(dataProvider = "masterDataProvider")
	private static void ScrubberFieldsValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			SUCName=data.get("SUC Name").toString();
			// Placing all required test data values in the html report
			OtherUtilities.printTestCaseDeatilsInReport(data);
			String parameter1= data.get("Query parameter1").toString();//getting query parameter form data sheet
			String queryFromDataSheet = data.get("SqlQuery").toString();//getting Sql query form data sheet
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim());//replacing query parameter in Sql query
			logger.log(LogStatus.INFO," Entered HICN number for this record is: " + parameter1);
			listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//result set to list of dictionaries
			//queryDataMap=listOfRecords.get(0);//First element of list
			
			String batchRunCompleted=data.get("BatchRun Completed");//getting the status of batch run ,Yes for completed and No for not completed
			for(Map<String,String>rowMap:listOfRecords){//Looping over list of dictionary records
				System.out.println("Query data map::" +rowMap);
				if("No".equalsIgnoreCase(batchRunCompleted)){//checking for batch run status 
						if(rowMap.containsKey("MEMI_TXN_CD")){//checking for key in map
							if("PP".equals(rowMap.get("MEMI_TXN_CD"))){ //checking for PP in that column
								softAssertion.assertEquals(rowMap.get("MEMI_INTF_STS"),"01","MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD"));//here validationn happens
								logger.log(LogStatus.INFO,"MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD")+" Expected Value: " +("01"+ "---------------Database Value: " + rowMap.get("MEMI_INTF_STS")));// and results will be looged in report.html file
								//System.out.println("Acctual Value: " + rowMap.get("MEMI_INTF_STS")+ "Expected Value: " + 01);
							}
							else if("NA".equals(rowMap.get("MEMI_TXN_CD"))){//checking for NA in that column
								softAssertion.assertEquals( rowMap.get("MEMI_INTF_STS"),"01","MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD"));
								logger.log(LogStatus.INFO,"MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD")+" Expected Value: " +("01"+ "---------------Database Value: " + rowMap.get("MEMI_INTF_STS")));
							   }
							else if("RP".equals(rowMap.get("MEMI_TXN_CD"))){//checking for RP in that column
								softAssertion.assertEquals( rowMap.get("MEMI_INTF_STS"),"01","MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD"));
								logger.log(LogStatus.INFO,"MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD")+" Expected Value: " +("01"+ "---------------Database Value: " + rowMap.get("MEMI_INTF_STS")));
							   }
						   }
					}
				else if("Yes".equalsIgnoreCase(batchRunCompleted)){//checking for batch run status
						if(rowMap.containsKey("MEMI_TXN_CD")){//checking for key in map
							if("PP".equals(rowMap.get("MEMI_TXN_CD"))){//checking for PP in that column
								softAssertion.assertEquals( rowMap.get("MEMI_INTF_STS"),"03","MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD"));
								logger.log(LogStatus.INFO, "MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD")+" Expected Value: " +("03"+ "---------------Database Value: " + rowMap.get("MEMI_INTF_STS")));
							   }
							else if("NA".equals(rowMap.get("MEMI_TXN_CD"))){//checking for NA in that column
								softAssertion.assertEquals( rowMap.get("MEMI_INTF_STS"),"01","MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD"));
								logger.log(LogStatus.INFO,"MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD")+" Expected Value: " +("01"+ "---------------Database Value: " + rowMap.get("MEMI_INTF_STS")));
							   }
							else if("RP".equals(rowMap.get("MEMI_TXN_CD"))){//checking for RP in that column
								softAssertion.assertEquals( rowMap.get("MEMI_INTF_STS"),"01","MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD"));
								logger.log(LogStatus.INFO,"MEMI_TXN_CD:"+rowMap.get("MEMI_TXN_CD")+" Expected Value: " +("01"+ "---------------Database Value: " + rowMap.get("MEMI_INTF_STS")));
							   }
						   }
				}else{
					softAssertion.assertTrue(false);
					logger.log(LogStatus.INFO, "Test step failed..! Batch Run Details not available");
				}
				
				
			  }
			//softAssertion.assertAll();//log all the assert into report
			
		}catch(Exception e){
		e.printStackTrace();
		}finally{
			softAssertion.assertAll();//log all the assert into report
		}
		}
	//************************************** TEST METHODS************************
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles","FileFieldAndDBColumnMappingFilePath","ResultsDestinationFolderPath"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles,String FileFieldAndDBColumnMappingFilePath,String ResultsDestinationFolderPath){
	//public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles,String FileFieldAndDBColumnMappingFilePath){	//Args order matters should match to params order
	
		path = Paths.get("target\\Results\\"+timestamp);
		 if(!Files.exists(path)){//checking the existence of given path
			 	try {Files.createDirectories(path);//Creating directory
			 		} catch (IOException e) {	e.printStackTrace();}
		 	}
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {//Initialization of class variables NameOfTestDataSheet
			NameOfTestDataSheet = "Sheet1";
			}
		filePath=TestDataSheetLocation;//Initialization of class variables
		rootLocationOfInputFiles=RootLocationOfFlatFiles;
		sheetName=NameOfTestDataSheet;
		fileFieldAndDBColumnMappingFilePath=FileFieldAndDBColumnMappingFilePath;
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);// Functional call to initialize cache from data sheet
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port);		// DB UTIL OBJECT CREATION!  //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		 //filePAth = tesFile.getCompleteTestFilePath();//Below step is for getting complete path of the input file		 
	}

//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		@SuppressWarnings("unchecked")
		Map<String,String> map=(Map<String,String>) callBack.getParameters()[0];
		String testCaseName="Test Case ID:"+map.get("Test Case ID")+",Field:"+map.get("Query parameter1");
		reportInit(testResult.getTestContext().getName(), testResult.getName(),testCaseName);
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();//Creating object for softAssert
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{
		//Map<String, String> dataMap = new HashMap<String, String>();
		//dataMap = ExcelUtils.getTestMethodData(method.getName());
		//data = new Object[][] { { dataMap },{ dataMap } };
		//  Object[][] testObjArray = ExcelFunctions.getTableArray("src//test//resources//TestData.xlsx","BSCA_Care1st_MM_Test");
		//	      return (testObjArray);
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, sheetName);
		  Object[][] testDataArray= 	  ExcelUtils.getTableArray(filePath, sheetName);
		  List<Object> list=new ArrayList<Object>();
		  
		  int noOfTestCases=0;
		  String runMode="Yes";
		  for(int row=0;row<=testDataArray.length-1;row++){//lopping over all the rows in data sheet
			  //below condition is to check for run mode and method name
			if(method.getName().equalsIgnoreCase(testDataArray[row][3].toString())&& runMode.equalsIgnoreCase(testDataArray[row][2].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();//map for each row
				for (int col=0;col<=columnArray[0].length-1;col++){//looping over all the columns
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());//inserting the row data to map
					}
				list.add(rowDataMap); //adding the map of each row into list
				//data[row][0]=rowDataMap;
				
				}
		   }
		  
		  Object[][] data = new Object[noOfTestCases][1];//creating object array
		  for(int row=0;row<list.size();row++){//looping over all the matched rows 
			  data[row][0]=list.get(row);
		  }
		//data = new Object[][] { { list.get(0) },{ list.get(1) },{ list.get(2) }  };
		//System.out.println("Balu data:"+data[2][0]);
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		ReportFactory.closeReport();//Closing the report
	}
	//Below method id for storing the results into results folder in the specified path
	
	@AfterMethod
	public void afterMethod() throws IOException{
		inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		 new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		
		/*Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
*/	}
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
			try {
	//-----		Path htmlReportSourcePath=Paths.get(resultsSourceFolderPath+"//test-output//emailable-report.html");//storing report source path in htmlReportSourcePath 
	//-----		Path htmlReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\emailable-report.html");//storing report source path in htmlReportDestinationPath
			
			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
	//-----			TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files
			
			
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	  }
	
}
