package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMCOBFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMCOBFileBody {
	private String Facets_Member_ID;
	private String Date_of_Birth;
	private String RRB_HIC_Number;
	private String File_Creation_Date;
	private String Occurrence_Number;
	private String	MSP_Code;
	private String Insurers_Name;
	private String Effective_Date;
	private String Termination_Date;
	private String Subscriber_1st_Name;
	private String Subscriber_Last_Name;
	private String Record_Type ;
	private String Member_SSN;
	private String Gender_Code;
	public String getFacets_Member_ID() {
		return Facets_Member_ID;
	}
	public void setFacets_Member_ID(String facets_Member_ID) {
		Facets_Member_ID = facets_Member_ID;
	}
	public String getDate_of_Birth() {
		return Date_of_Birth;
	}
	public void setDate_of_Birth(String date_of_Birth) {
		Date_of_Birth = date_of_Birth;
	}
	public String getRRB_HIC_Number() {
		return RRB_HIC_Number;
	}
	public void setRRB_HIC_Number(String rRB_HIC_Number) {
		RRB_HIC_Number = rRB_HIC_Number;
	}
	public String getFile_Creation_Date() {
		return File_Creation_Date;
	}
	public void setFile_Creation_Date(String file_Creation_Date) {
		File_Creation_Date = file_Creation_Date;
	}
	public String getOccurrence_Number() {
		return Occurrence_Number;
	}
	public void setOccurrence_Number(String occurrence_Number) {
		Occurrence_Number = occurrence_Number;
	}
	public String getMSP_Code() {
		return MSP_Code;
	}
	public void setMSP_Code(String mSP_Code) {
		MSP_Code = mSP_Code;
	}
	public String getInsurers_Name() {
		return Insurers_Name;
	}
	public void setInsurers_Name(String insurers_Name) {
		Insurers_Name = insurers_Name;
	}
	public String getEffective_Date() {
		return Effective_Date;
	}
	public void setEffective_Date(String effective_Date) {
		Effective_Date = effective_Date;
	}
	public String getTermination_Date() {
		return Termination_Date;
	}
	public void setTermination_Date(String termination_Date) {
		Termination_Date = termination_Date;
	}
	public String getSubscriber_1st_Name() {
		return Subscriber_1st_Name;
	}
	public void setSubscriber_1st_Name(String subscriber_1st_Name) {
		Subscriber_1st_Name = subscriber_1st_Name;
	}
	public String getSubscriber_Last_Name() {
		return Subscriber_Last_Name;
	}
	public void setSubscriber_Last_Name(String subscriber_Last_Name) {
		Subscriber_Last_Name = subscriber_Last_Name;
	}
	public String getRecord_Type() {
		return Record_Type;
	}
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	public String getMember_SSN() {
		return Member_SSN;
	}
	public void setMember_SSN(String member_SSN) {
		Member_SSN = member_SSN;
	}
	public String getGender_Code() {
		return Gender_Code;
	}
	public void setGender_Code(String gender_Code) {
		Gender_Code = gender_Code;
	}
	
	

}
