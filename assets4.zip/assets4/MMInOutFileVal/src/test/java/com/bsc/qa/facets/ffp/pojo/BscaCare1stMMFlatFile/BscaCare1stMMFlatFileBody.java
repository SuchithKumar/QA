package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileBody {

	
	private String Record_Type_Body;
	private String  Contract_Number_Body;
	private String PBP_Number ;
	private String HIC_Number;
	private String Premium_Adjustment_Period_Start_Date ;
	private String Premium_Adjustment_Period_End_Date;
	private String Number_of_Months_in_Premium_Adjustment_Period;
	private String LEP_Amount;
	
	
	
	public String getRecord_Type_Body() {
		return Record_Type_Body;
	}
	public void setRecord_Type_Body(String record_Type_Body) {
		Record_Type_Body = record_Type_Body;
	}
	public String getContract_Number_Body() {
		return Contract_Number_Body;
	}
	public void setContract_Number_Body(String contract_Number_Body) {
		Contract_Number_Body = contract_Number_Body;
	}
	public String getPBP_Number() {
		return PBP_Number;
	}
	public void setPBP_Number(String pBP_Number) {
		PBP_Number = pBP_Number;
	}
	public String getHIC_Number() {
		return HIC_Number;
	}
	public void setHIC_Number(String hIC_Number) {
		HIC_Number = hIC_Number;
	}
	public String getPremium_Adjustment_Period_Start_Date() {
		return Premium_Adjustment_Period_Start_Date;
	}
	public void setPremium_Adjustment_Period_Start_Date(
			String premium_Adjustment_Period_Start_Date) {
		Premium_Adjustment_Period_Start_Date = premium_Adjustment_Period_Start_Date;
	}
	public String getPremium_Adjustment_Period_End_Date() {
		return Premium_Adjustment_Period_End_Date;
	}
	public void setPremium_Adjustment_Period_End_Date(
			String premium_Adjustment_Period_End_Date) {
		Premium_Adjustment_Period_End_Date = premium_Adjustment_Period_End_Date;
	}
	public String getNumber_of_Months_in_Premium_Adjustment_Period() {
		return Number_of_Months_in_Premium_Adjustment_Period;
	}
	public void setNumber_of_Months_in_Premium_Adjustment_Period(
			String number_of_Months_in_Premium_Adjustment_Period) {
		Number_of_Months_in_Premium_Adjustment_Period = number_of_Months_in_Premium_Adjustment_Period;
	}
	public String getLEP_Amount() {
		return LEP_Amount;
	}
	public void setLEP_Amount(String lEP_Amount) {
		LEP_Amount = lEP_Amount;
	}
	
	
	
}
