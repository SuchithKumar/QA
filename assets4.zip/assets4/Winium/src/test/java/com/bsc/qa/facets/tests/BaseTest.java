/**
 * @author gholla01
 * @category base class for test
 * BaseTest
 * This class provides factory methods to close and flush reports. Might be used to extend default behaviors for tests here 
 */
package com.bsc.qa.facets.tests;

import java.io.File;
import java.lang.reflect.Method;
import java.util.regex.Matcher;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.winium.WiniumDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.factory.ApplicationFactoryManager;
import com.bsc.qa.facets.factory.ReportFactory;
import com.bsc.qa.facets.utility.ExcelUtils;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.io.*;
/*
 * This is a base Test class. All testng tests needs to inherited from
 * this class. It contains common reporting infrastructure
 * @author gholla01
 */
public class BaseTest  {
	
	public ExtentTest logger;
	public ExtentReports report;
	
	protected String testCaseName;
	protected String testMethodName;	
	protected String application;
	protected String environment;
	protected String url;
	protected String winDriver;	
	protected String driverString;	
	protected SoftAssert softAssert = null;
	
	protected static Object[][] testDataArray = null;
	
	/**
	 * @return the testCaseName
	 */ 
	public String getTestCaseName() {
		return testCaseName;
	}

	/**
	 * @param testCaseName the testCaseName to set
	 */	
	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}
	
	/**
	 * @return the testMethodName
	 */
	public String getTestMethodName() {
		return testMethodName;
	}

	/**
	 * 
	 * @param testMethodName
	 */
	public void setTestMethodName(String testMethodName) {
		this.testMethodName = testMethodName;
	}

	@AfterMethod
	public void afterMethod(Method caller) {
		ReportFactory.closeTest(caller.getName());
	}
		
	/**
	 * @AfterMethod gets called automatically after every @Test execution.
	 * This is framework provided method. Ensure this method exists in every Tests class
	 * 
	 * @param result
	 */
	@AfterMethod
	public void takeScreenShot(ITestResult result) {
		
		// Here will compare if test is failing then only it will enter into if condition
		TakesScreenshot ts = null;
		File source = null;
		String screen_shot_path = null;
		String image = null;		
		if(ITestResult.FAILURE==result.getStatus())
		{			
			try 
			{
				WiniumDriver driver =  ApplicationFactoryManager.getDriver();
				// Create reference of Takes Screenshot
				ts=(TakesScreenshot)driver;
				
				
				 
				// Call method to capture screenshot
				source=ts.getScreenshotAs(OutputType.FILE);
				 
				// Copy files to specific location here it will save all screenshot in our project home directory and
				// result.getName() will return name of test case so that screenshot name will be same
				//System.out.println("TESTCASENAME:"+testCaseName);
				screen_shot_path = System.getProperty("user.dir") +"\\test-output\\BSC-reports\\screenshots\\"+result.getName()+"_"+System.currentTimeMillis();
				
				FileUtils.copyFile(source, new File(screen_shot_path+".png"));
							 
				System.out.println("Screenshot taken");
				System.setProperty("org.uncommons.reportng.escape-output", "false");

				image = logger.addScreenCapture(screen_shot_path + ".png");
				logger.log(LogStatus.ERROR,result.getThrowable());
				logger.log(LogStatus.FAIL, result.getName() + "_" + testCaseName + " failed",image);				
			} 
			catch (Exception e)
			{
				e.printStackTrace();				
			} 
		}
		if(ITestResult.SUCCESS==result.getStatus()){
			logger.log(LogStatus.PASS, result.getName() +" verified successfully");			
		}
		tearDown();
	}
		
	/**
	 * @AfterClass gets called after all tests methods are done executed. 
	 */
	@AfterClass(alwaysRun=true)
	public void tearDown(){	
		WiniumDriver driver =  ApplicationFactoryManager.getDriver();
		if(driver!=null){
			driver.quit();
		}
	}
		
	/*
	 * After suite will be responsible to close the report properly at the end
	 * You an have another afterSuite as well in the derived class and this one
	 * will be called in the end making it the last method to be called in test execution.
	 */
	@AfterSuite(alwaysRun=true)
	public void afterSuite() {
		ReportFactory.closeReport();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
		replaceInFile();	
	}
	

	/**
	 * Initialize extent logger and report.
	 * 
	 * @param tc name
	 *
	 */
	protected void reportInit(String testContextName, String applicationName, String testCaseName, String testMethodName) {
		String envName = System.getenv("ENVNAME");
		logger = ReportFactory.getTest();
		report = ReportFactory.getExtentReport();
		report.addSystemInfo("Application", applicationName);				
		logger = report.startTest(testContextName + ":" + testMethodName + "--------->PARAMETERS: " + testCaseName );
		if(testContextName.toLowerCase().contains("smoke")){			
			logger.assignCategory("Smoke-"+envName);	
		}else if(testContextName.toLowerCase().contains("reg")){
			logger.assignCategory("Regression-"+envName);
		}else if(testContextName.toLowerCase().contains("func")){
			logger.assignCategory("Functional-"+envName);
		}else{
			logger.assignCategory("Automation-"+envName);	
		}
	}

	/**
	* Load test data from excel file into the testData object array.
	* 
	*/	
	public static void loadTestdata(String sourceFile) {
        String sheetName = System.getenv("ENVNAME");
        if (sheetName == null || "".equals(sheetName)) {
             sheetName = "Sheet1";
        }
        testDataArray = ExcelUtils.getTableArray(sourceFile, sheetName);     
   }
	
  /**
   * replaceInFile
   * This method is added to replace the screenshot path in final Report.html. This utility method is added to support the
   * archive feature in Jenkins. (Note that archive of reports are stored on Master (unix)). 	
   */
  public static void replaceInFile()
  {
	  try{
		  File file = new File("test-output\\BSC-reports\\"+"Report.html");
	      BufferedReader reader = new BufferedReader(new FileReader(file));
	      String line = "", oldtext = "";
	      while((line = reader.readLine()) != null)
	      {
	    	  oldtext += line + "\r\n";
	      }
	      reader.close();
	      //To replace a line in a file
	      String path = "'"+System.getProperty("user.dir") +"\\test-output\\BSC-reports\\screenshots\\";
	      System.out.println(path);
	      String newPath = "'screenshots\\";
	      String newtext = oldtext.replaceAll(Matcher.quoteReplacement(path),  Matcher.quoteReplacement(newPath));
	      FileWriter writer = new FileWriter("test-output\\BSC-reports\\"+"Report.html");
	      writer.write(newtext);writer.close();
	  }catch (IOException ioe){
		  ioe.printStackTrace();
	  }
  }

}