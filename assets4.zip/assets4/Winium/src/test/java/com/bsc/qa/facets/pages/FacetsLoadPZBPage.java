/**
 * @author gholla01
 * @pageObject FacetsLoadPZB
 * Factory pattern - Page object implementation is used to define web elements and success and failure scenarios.
 */
package com.bsc.qa.facets.pages;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.winium.WiniumDriver;

import com.bsc.qa.facets.factory.ApplicationFactoryManager;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * @author gholla01
 * @category PageObject 
 * @class CalcDemoPage
 * This pageobject class is used to define the elements of Calculator page.
 * Define and group your repeatable and actionable test executions into methods.
 * Define success and failure criteria here.
 */
public class FacetsLoadPZBPage extends BasePage {
	/*
	 * Use @FindAll annotation when you have more than one option for the same element.
	 * This is particularly helpful when name or CSS works sometimes and sometimes xpath 
	 * Also, in general this is best practice for fail over.
	 * 
	 * Returns a List of WebElements.
	 */

	@FindBy(how=How.NAME,using="Facets")	
	@CacheLookup
	WebElement FacetsWindow;
		
	@FindBy(how=How.NAME,using="Application")
	@CacheLookup
	List<WebElement> menuBar;	
	
	
	@FindBy(how=How.NAME,using="File")
	@CacheLookup
	WebElement fileMenu;
	
	@FindBy(how=How.NAME,using="Window")
	@CacheLookup
	WebElement windowMenu;
	
	@FindBy(how=How.NAME,using="Help")
	@CacheLookup
	WebElement helpMenu;
	
	@FindBy(how=How.ID,using="28684")
	@CacheLookup
	WebElement openDatabaseFileMenuItem;
	
	@FindBy(how=How.NAME,using="facets.pzb")
	@CacheLookup
	WebElement facetsN51PZBFileItem;
	
	@FindBy(how=How.ID,using="1")
	@CacheLookup
	WebElement openFile;
	
	@FindBy(how=How.ID,using="103")
	@CacheLookup
	WebElement usernameTextBox;
	
	@FindBy(how=How.ID,using="104")
	@CacheLookup
	WebElement passwordTextBox;
	
	@FindBy(how=How.NAME,using="OK")
	@CacheLookup
	WebElement okButton;
	
	@FindBy(how=How.ID,using="2525")
	@CacheLookup
	WebElement applicationPane;
	
	@FindBy(how=How.NAME,using="Subscriber/Family")
	@CacheLookup
	WebElement subscriberFamilyLink;
	
	/**
	 * Worker method to perform actual execution on the Page to 
	 * do an addition
	 * 	 
	 */
	public void loadPZB(ExtentTest logger){
		logger.log(LogStatus.INFO, "Click File Menu");
		WiniumDriver driver = ApplicationFactoryManager.getDriver();
		RemoteWebElement facetsWindow=(RemoteWebElement) driver.findElement(By.name("Facets"));
		RemoteWebElement maximizeFacets=(RemoteWebElement) driver.findElement(By.name("Maximize"));
		RemoteWebElement fileMenu=(RemoteWebElement) driver.findElement(By.name("File"));
		
		maximizeFacets.click();
		fileMenu.click();
		RemoteWebElement openDatabaseMenuItem=(RemoteWebElement) fileMenu.findElement(By.name("Open Database"));
		sleepForMins(2);
		openDatabaseMenuItem.click();
		sleepForMins(6);			
		logger.log(LogStatus.INFO, "select Facets N51 PZB");
		facetsN51PZBFileItem.click();	
		sleepForMins(2);		
		logger.log(LogStatus.INFO, "Click on open");
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.name("facets.pzb"))).doubleClick().perform();
		sleepForMins(2);	
		usernameTextBox.sendKeys("jdilag01");
		passwordTextBox.sendKeys("Auto_mation777");
		okButton.click();
		//applicationPane.findElement(By.name("Subscriber/Member             ")).click();
		//action.moveToElement(driver.findElement(By.name("Subscriber/Member             "))).doubleClick().perform();
		String altF12 = Keys.chord(Keys.ALT,Keys.F12);
		driver.findElement(By.name("Tasks")).sendKeys(altF12);
		facetsWindow.sendKeys(altF12);
		
	}
	
	public void sleepForMins(int timeInSeconds){
		try{
			Thread.sleep(timeInSeconds*1000);			
		}catch(Exception e){
			
		}
	}


	/**
	 * Get testcase name
	 * @return testcase name as string
	 */
	public String getTestCaseName(){
		return testCaseName;
	}

}
