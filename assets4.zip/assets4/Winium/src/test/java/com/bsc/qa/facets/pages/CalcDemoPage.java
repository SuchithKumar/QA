/**
 * @author gholla01
 * @pageObject LoginPlanSummaryPO
 * Factory pattern - Page object implementation is used to define web elements and success and failure scenarios.
 */
package com.bsc.qa.facets.pages;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.winium.WiniumDriver;

import com.bsc.qa.facets.factory.ApplicationFactoryManager;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * @author gholla01
 * @category PageObject 
 * @class CalcDemoPage
 * This pageobject class is used to define the elements of Calculator page.
 * Define and group your repeatable and actionable test executions into methods.
 * Define success and failure criteria here.
 */
public class CalcDemoPage extends BasePage {
	/*
	 * Use @FindAll annotation when you have more than one option for the same element.
	 * This is particularly helpful when name or CSS works sometimes and sometimes xpath 
	 * Also, in general this is best practice for fail over.
	 * 
	 * Returns a List of WebElements.
	 */

	@FindBy(how=How.CLASS_NAME,using="CalcFrame")	
	@CacheLookup
	WebElement calcFrame;
		
	@FindBy(how=How.ID,using="MenuBar")
	@CacheLookup
	List<WebElement> menuBar;	
	
	
	@FindBy(how=How.NAME,using="View")
	@CacheLookup
	WebElement viewMenu;
	
	@FindBy(how=How.ID,using="132")
	@CacheLookup
	WebElement numberTwo;
	
	@FindBy(how=How.ID,using="93")
	@CacheLookup
	WebElement plusButton;
	
	@FindBy(how=How.ID,using="134")
	@CacheLookup
	WebElement numberFour;
	
	@FindBy(how=How.ID,using="121")
	@CacheLookup
	WebElement equalsButton;
	
	@FindBy(how=How.ID,using="150")
	@CacheLookup
	WebElement resultText;
	
	@FindBy(how=How.NAME,using="Scientific")
	@CacheLookup
	WebElement scientificMode;
	
	/**
	 * Worker method to perform actual execution on the Page to 
	 * do an addition
	 * 	 
	 */
	public void performAddition(ExtentTest logger){
		logger.log(LogStatus.INFO, "Click view Menu");
		WiniumDriver driver = ApplicationFactoryManager.getDriver();
		RemoteWebElement calcFrame=(RemoteWebElement) driver.findElement(By.className("CalcFrame"));
		RemoteWebElement menu=(RemoteWebElement) calcFrame.findElement(By.id("MenuBar"));
		RemoteWebElement viewMenu=(RemoteWebElement) menu.findElement(By.name("View"));
		
		try{
		//viewMenu.click();
		//sleepForMins(2);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	  //  viewMenu.findElement(By.id("304")).click();
		
		logger.log(LogStatus.INFO, "Click on number two");
		calcFrame.findElement(By.id("132")).click();
		sleepForMins(2);
		logger.log(LogStatus.INFO, "Click on plus Button");
		calcFrame.findElement(By.id("93")).click();
		sleepForMins(2);
		
		logger.log(LogStatus.INFO, "Click on number four");
		calcFrame.findElement(By.id("134")).click();
		sleepForMins(2);
	
		logger.log(LogStatus.INFO, "Click on equals Button");
		calcFrame.findElement(By.id("121")).click();
		
		sleepForMins(2);
	
	}
	
	public void sleepForMins(int timeInSeconds){
		try{
			Thread.sleep(timeInSeconds*1000);			
		}catch(Exception e){
			
		}
	}


	/**
	 * Get testcase name
	 * @return testcase name as string
	 */
	public String getTestCaseName(){
		return testCaseName;
	}

}
