package com.bsc.qa.facets.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.winium.WiniumDriver;

public class BasePage {

	protected WiniumDriver winDriver;
	protected String testCaseName;
	private String application;

	public BasePage() {
		super();
	}

	/**
	 * Initialize the parameters for the page
	 *
	 * @param winDriver
	 * @param application
	 * @param testCaseName
	 */
	public void setPage(WiniumDriver driver, String application, String testCaseName) {
		this.winDriver = driver;	
		this.application = application;
		this.testCaseName= testCaseName;	
	}

	/**
	 * ListElement Method is framework provided method
	 * It is used to return the valid element in the list 
	 * 
	 * @param lstElmt
	 * @return list element of type WebElement
	 */
	public WebElement listElement(List<WebElement> lstElmt) {
		for (WebElement lctr : lstElmt) {
			try{
				if(lctr.isDisplayed())
					return lctr;
			}catch(Exception e){				
				continue;
			}
		}
		return null;
	}

	/**
	 * Get Application name
	 * @return application name as string
	 */
	public String getApplication() {
		return application;
	}


}