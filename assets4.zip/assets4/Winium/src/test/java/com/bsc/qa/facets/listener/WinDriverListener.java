/**
 * @author gholla01
 */
package com.bsc.qa.facets.listener;
import java.io.IOException;

import org.openqa.selenium.winium.WiniumDriver;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

import com.bsc.qa.facets.factory.ApplicationFactory;
import com.bsc.qa.facets.factory.ApplicationFactoryManager;

/**
 *@author gholla01
 *WinDriverListener class ensures driver is set in the ApplicationFactoryManager before invocation of a test Method
 */
public class WinDriverListener implements IInvokedMethodListener {
    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
        if (method.isTestMethod()) {
            String applicationPath = method.getTestMethod().getXmlTest().getLocalParameters().get("Application_");
            String sdriver  = method.getTestMethod().getXmlTest().getLocalParameters().get("Driver_");           
            
    		WiniumDriver driver;
			try {
				driver = ApplicationFactory.startApplication(applicationPath,sdriver);			
				ApplicationFactoryManager.setWebDriver(driver);
			} catch (IOException e) {
				System.out.println("Problem while starting the WinDriver, Please contact your administrator!");
				e.printStackTrace();
			}
        }
    }
 
    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
        if (method.isTestMethod()) {        	
            /*
             * Future implementation if required. For now, we dont need to do anything in afterInvocation.
             */
        }
    }
}
