/**
 * @class ApplicationFactoryManager
 * @author gholla01
 *  Manager class uses a concept in java called ThreadLocal variables.
 *  Useful in ensuring executions are thread safe
 */
package com.bsc.qa.facets.factory;
import org.openqa.selenium.winium.WiniumDriver;
/**
 *@author gholla01
 *ApplicationFactoryManager - Introduced this class to ensure winiumdriver doesn't overlap
 *ThreadLocal provides thread-local variables to ensure thread safe executions.
 *NOTE: Please do not use global static variable across the class for driver. Use getDriver and setWebDriver functions to 
 *ensure thread safe parallelism.
 */
public class ApplicationFactoryManager {
	 private static ThreadLocal<WiniumDriver> winiumDriver = new ThreadLocal<WiniumDriver>();
	 
	 public static WiniumDriver getDriver() {
	        return winiumDriver.get();
	 }
	 
	 public static void setWebDriver(WiniumDriver driver) {
		 winiumDriver.set(driver);
	 }

}
