package com.bsc.qa.facets.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * DBUtils encapsulates methods required to get data from an Oracle database
 * 
 * @author gholla01
 */
public class DBUtils {

	private static Connection connection;
	private static Statement statement;
	private static ResultSet resultSet;

	/**
	 * Setup the database connection using the oracle JDBC driver.
	 * 
	 */
	public static void setUp() {
		String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
		String DB_NAME = System.getenv("WPR_NAME");
		String DB_USERNAME = System.getenv("WPR_USER");
		String DB_PASSWORD = System.getenv("WPR_PASSWORD");
		String DB_SERVER = System.getenv("WPR_SERVER");
		String databaseURL = "jdbc:oracle:thin:" + DB_USERNAME + "/"
				+ DB_PASSWORD + "@" + DB_SERVER + ":1521:" + DB_NAME;

		try {
			Class.forName(DB_DRIVER);
			System.out.println("Connecting to Database...");
			connection = DriverManager.getConnection(databaseURL);
			if (connection != null) {
				System.out.println("Connected to the Database...");
			}
		} catch (SQLException ex) {
			System.out.println("ERROR: SQL Exception when connecting to database");
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			System.out.println("ERROR: JDBC Driver Class Not Found when connecting to database");
			ex.printStackTrace();
		}
	}

	/**
	 * Close the database connection 
	 * 
	 */
	public static void tearDown() {
		if (connection != null) {
			try {
				System.out.println("Closing Database Connection...");
				connection.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * 
	 * @param query
	 * @return two dimentional object array with data returned by executing the query
	 */
	public static Object[][] getTableArray(String query) {
		String[][] tableArray = null;
		int totalCols = 0;
		int totalRows = 0;
		int ci = 0;
		int cj = 0;
		setUp();
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(query);
			resultSet.last();
			totalRows = resultSet.getRow();
			ResultSetMetaData rsmd = resultSet.getMetaData();
			totalCols = rsmd.getColumnCount();
			tableArray = new String[totalRows][totalCols];

			while (resultSet.next()) {
				int i = 1;
				while (i <= totalCols) {
					tableArray[ci][cj] = resultSet.getString(i++);
					cj++;
				}
				ci++;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		tearDown();
		return tableArray;
	}
}