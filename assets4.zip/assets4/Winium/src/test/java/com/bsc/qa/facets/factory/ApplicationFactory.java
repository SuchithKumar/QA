/**
 * @author gholla01
 */
package com.bsc.qa.facets.factory;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
import org.openqa.selenium.winium.WiniumDriverService;
	
/**
 * @author gholla01
 * @category Helper
 * This class is used to instantiate the windows application in runtime. 
 * Note: DO NOT CODE webDriver code directly in the testcase or in page objects. 
 */
public class ApplicationFactory {		
	/**
	 * Factory method to create an instance of the application web winiumDriver

	 * @param applicationPath
	 * @param sdriver
	 * @return WiniumDriver object
	 */
	public static WiniumDriver startApplication(String applicationPath,String sdriver) throws IOException
	{
		WiniumDriver winDriver =null;
		WiniumDriverService service =null;
		DesktopOptions options =null;
		
		options = new DesktopOptions();
		options.setApplicationPath(applicationPath);
		File driverPath = new File(sdriver);
		service = new WiniumDriverService.Builder().usingDriverExecutable(driverPath).usingPort(9999).withVerbose(true).withSilent(false).buildDesktopService();
		service.start();
	//	DesiredCapabilities desiredCapabilities = (DesiredCapabilities)options.toCapabilities();
		winDriver = new WiniumDriver(service,options);
		return winDriver;	
	}	
}
