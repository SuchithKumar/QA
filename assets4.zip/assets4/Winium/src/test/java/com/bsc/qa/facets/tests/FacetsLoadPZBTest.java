/**
 * @author gholla01
 * @category testcase
 * @uses pageobject FacetsLoadPZBPage
 * Note: Some testcases pass and some fail. They are intentional to show case the framework capabilities.
 */
package com.bsc.qa.facets.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.winium.WiniumDriver;
import org.testng.Assert;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;
import com.bsc.qa.facets.factory.ApplicationFactory;
import com.bsc.qa.facets.factory.ApplicationFactoryManager;
import com.bsc.qa.facets.pages.FacetsLoadPZBPage;
//=======================================================
//ADD IMPORTS FOR ALL PAGES TO BE TESTED HERE
//=======================================================
//=======================================================
import com.bsc.qa.facets.utility.ExcelUtils;


public class FacetsLoadPZBTest extends BaseTest implements IHookable 
{
	//=======================================================
	//			INSTANTIATE PAGES TO BE TESTED
	//=======================================================
	private FacetsLoadPZBPage facetsLoadPZBPage;
	
    public FacetsLoadPZBTest() {
       // loadTestdata("src/test/resources/LoginPlanSummaryTestData.xlsx");
    }

	//===========================================================================================
	//			KEEP EVERYTHING BETWEEN THIS POINT AND THE ACTUAL TEST CASES UNCHANGED
	//===========================================================================================
    /**
     * DataProvider for returning the specific test data based on test method name
     * 
     * @param method
     * @return
     *
    @DataProvider(name="masterDataProvider")
    private static Object[][] getData(Method method) {
         Object[][] data = null;
         Map<String, String> dataMap = new HashMap<String, String>();
        
         for (int i=1; i<testDataArray.length; i++) {
              if (testDataArray[i][1].equals(method.getName())) {
                   for (int j=0; j< testDataArray[0].length; j++) {
                        dataMap.put(testDataArray[0][j].toString(), testDataArray[i][j].toString());
                   }
                   data = new Object[][] {{dataMap}};
                   break;
              }
         }
         return data;
    }*/

	/**
	 * setUp is a @BeforeMethod executed before execution of a @Test 
	 * 
	 * @param browser_
	 * @param driver_
	 * @param env_
	 * @param url_
	 */
	@BeforeMethod
	@Parameters({ "Application_","Driver_"})	
	//public void setUp(@Optional("browser") String browser_, @Optional("winDriver") String driver_, @Optional("env") String env_, @Optional("url") String url_) {
	public void setUp(@Optional("application") String Application_, @Optional("winDriver") String Driver_) {
		application = Application_;
		winDriver = Driver_;
	}

	/**
	 * Run when the test method runs
	 */
	protected void initBrowser(String testCaseName, String testMethodName) {
		WiniumDriver driver =  ApplicationFactoryManager.getDriver();		
		facetsLoadPZBPage = PageFactory.initElements(driver, FacetsLoadPZBPage.class);
		facetsLoadPZBPage.setPage(driver, application, testCaseName);	
	}	
	
	/**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		initBrowser(testResult.getTestName(), testResult.getMethod().getMethodName());
		//reportInit(testResult.getTestContext().getName(), application, callBack.getParameters()[0].toString(), testResult.getMethod().getMethodName());
		reportInit(testResult.getTestContext().getName(), application, "Demo","Demo");
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}		

	//===========================================================================================
	//      				ADD ALL TEST CASES AFTER THIS POINT
	//===========================================================================================

	/**
	 * Test member portal login check for member name
	 */
	@Test(priority=1, groups="CalcDemo")
	public void invokeCalcAndTriggerDemo() {
		facetsLoadPZBPage.loadPZB(logger);
		Assert.assertTrue(true);
	}

}