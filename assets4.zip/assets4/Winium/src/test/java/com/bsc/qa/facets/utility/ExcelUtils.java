/*************************************************************************************************************
 * 
 * 	program name:	ExcelUtils.java
 * 	author		:	Rolando Tan (rtan01)
 * 	date		:	10/24/2016
 * 
 * 	description	:	This class retrieves test case data from a datasheet.
 * 				:	The data retrieved from the datasheet is held in a public collection (hashmap)
 * History		:	
 * 					2/23/2017 - Aditya Inapurapu: 
 * 								Added to branch and edited to confirm to coding and documentation standards 
 * 								Moved ExcelUtils methods to this class 
 * 								Renamed this class TestDataSheetReader to ExcelUtils
 ***************************************************************************************************************/

package com.bsc.qa.facets.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * ExcelUtils class that gets test data from excel file to be used for driving tests.
 * 
 *
 */
public class ExcelUtils
{
	private static XSSFSheet excelWSheet;
	private static XSSFWorkbook excelWBook;
	private static XSSFCell cell;
	
	public HashMap<String, String> testData = new HashMap<String, String>();	
	private boolean found = false;

	/**
	 * @return the found
	 */
	protected boolean isFound() {
		return found;
	}

	/**
	 * @param found the found to set
	 */
	protected void setFound(boolean found) {
		this.found = found;
	}


	/**
	 * Default constructor
	 */
	public ExcelUtils() {
		
	}
	
	/**
	 * Constructor to load with logger
	 * 
	 * @param path
	 * @param sheetName
	 * @param testCaseId
	 * @param logger
	 */
	public ExcelUtils(String path, String sheetName, String testCaseId, ExtentTest logger) 
	{
		try 
		{
			logger.log(LogStatus.INFO, "Accessing Data Dictionary.");			
			
			try
			{
				logger.log(LogStatus.INFO, "Environment: " + sheetName);			
				logger.log(LogStatus.INFO, "Data File: " + path);				
				FileInputStream ExcelFile = new FileInputStream(path);
				excelWBook = new XSSFWorkbook(ExcelFile);
				excelWSheet = excelWBook.getSheet(sheetName);
				
				getTestCaseData(testCaseId,logger);
			}
			catch (FileNotFoundException e) 
			{
				logger.log(LogStatus.ERROR, "FileNotFoundException encountered");	
				e.printStackTrace();
			} 
			catch (IOException e) 
			{
				logger.log(LogStatus.ERROR, "IOException encountered");			
				e.printStackTrace();
			}			
		} 
		catch (Exception e)
		{
			logger.log(LogStatus.ERROR, "Exception thrown from ExcelUtils constructor");			
			e.printStackTrace();			
		}
	}

	/**
	 * Assemble the test case's populated data fields from the data spreadsheet 
	 * 
	 * @param testCaseID
	 * @param logger
	 */
	public void getTestCaseData(String testCaseID, ExtentTest logger) 
	{
		String key;
		String value;
		int colCt = 0;
		try 
		{
			testData.clear();
			colCt = getColumnCount(logger);
			logger.log(LogStatus.INFO, "Columns count = " + colCt);
			logger.log(LogStatus.INFO, "Searching for test case in datasheet");	
			
			for (int rowNum = 0; !(getCellData(rowNum, 0, logger) == null || getCellData(rowNum, 0,logger).isEmpty()); rowNum++)
			{
				logger.log(LogStatus.INFO, "Checking row #" + rowNum);				
				if (getCellData(rowNum, 0,logger).equals(testCaseID))
				{
					found = true;
					logger.log(LogStatus.INFO, "Test case found in datasheet");		
					logger.log(LogStatus.INFO, "Data dictionary values:");		
					
					for (int colNum = 0; colNum < colCt; colNum++)
					{
						value = getCellData(rowNum, colNum,logger);
						if (value != null && !value.isEmpty())							
						{
							key = getCellData(0, colNum,logger);								
							testData.put(key, value);

							if (!"".equals(value))
								logger.log(LogStatus.INFO, "     " + key + " = " + value);
						}
					}
				}				
			}
			if (testData.size() == 0)
			{
				logger.log(LogStatus.INFO, "Test data not found in datasheet");				
			}
		} 
		catch (Exception e)
		{
			logger.log(LogStatus.ERROR, "Exception thrown from ExcelUtils.getTestCaseData(" +  testCaseID + ")");	
			e.printStackTrace();
		}
	}
		
	/**
	 * Returns a count of the number of columns
	 * 
	 * @param logger
	 * @return column count as an integer
	 */
	public static int getColumnCount(ExtentTest logger)  
	{
		int rowNum = 0;
		int colNum = 0;
		int colCt = 0;
		try 
		{
			while (getCellData(rowNum, colNum,logger) == null || getCellData(rowNum, colNum,logger).isEmpty())
			{
				colCt++;
				colNum++;
			}
		} 
		catch (Exception e)
		{
			logger.log(LogStatus.ERROR, "Exception thrown from ExcelUtils.countDataColumns()");			
			e.printStackTrace();
		}
		return colCt;
	}

	/**
	 * Returns the cell value as a String
	 * 
	 * @param rowNum
	 * @param colNum
	 * @param logger
	 * @return cell value as a string
	 */
	public static String getCellData(int rowNum, int colNum, ExtentTest logger) 
	{
		try
		{
			cell = excelWSheet.getRow(rowNum).getCell(colNum);
			String cellData = null;
			if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
				cellData = cell.getStringCellValue();
			}
			else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) 
			{
				cellData = String.valueOf(cell.getNumericCellValue());
			}
			else if (cell.getCellType() == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK)
			{
				cellData = "";
			}
			return cellData;
		} 
		catch (Exception e)
		{
			logger.log(LogStatus.ERROR, "Exception encountered in ExcelUtils.getCellData(" + rowNum + "," + colNum + ")");			
			return "";
		}
	}

	/**
	 * WIP by @ainapu01 
	 * Experimental method. Get data from database if excel sheet is blank
	 * 
	 * @param filePath
	 * @param sheetName
	 * @return
	 */
	public static Object[][] getTestData(String filePath, String sheetName) {   
		String[][] tabArray = null;
		int startRow = 1;
		int startCol = 0;
		int ci=0;
		int cj=0;
		int totalRows = 0;
		int totalCols = 0;
		
		try {
			FileInputStream excelFile = new FileInputStream(filePath);
			excelWBook = new XSSFWorkbook(excelFile);
			excelWSheet = excelWBook.getSheet(sheetName);
			totalRows = excelWSheet.getPhysicalNumberOfRows()-1;
			if (totalRows < 2) {
				System.out.println("Sheet Empty: " + sheetName);
			} else {
				totalCols = excelWSheet.getRow(0).getPhysicalNumberOfCells()-1;

				tabArray=new String[totalRows][totalCols+1];
				for (int i=startRow;i<=totalRows;i++, ci++) {           	   
					for (int j=startCol;j<=totalCols;j++, cj++){
						if(getCellData(i,j)!=""){
							tabArray[ci][cj]=getCellData(i,j);	
						}
					}
				}
			}
		}catch (FileNotFoundException e){
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}catch (IOException e){
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		return(tabArray);
	}

	/**
	 * Get Excel data as an array
	 * 
	 * @param filePath
	 * @param sheetName
	 * @return
	 */
	public static Object[][] getTableArray(String filePath, String sheetName) {   
		String[][] tableArray = null;
		//int startRow = 1;
		int startRow = 0;				//include the header row
		int startCol = 0;
		int ci,cj;
		int totalRows;
		int totalCols;
	
		try {
			FileInputStream excelFile = new FileInputStream(filePath);			
			excelWBook = new XSSFWorkbook(excelFile);
			excelWSheet = excelWBook.getSheet(sheetName);
			totalRows = excelWSheet.getPhysicalNumberOfRows();			
			
			totalCols = excelWSheet.getRow(0).getPhysicalNumberOfCells()-1;
			tableArray=new String[totalRows][totalCols+1];
			ci=0;
			//for (int i=startRow;i<=totalRows;i++, ci++) {
			for (int i=startRow;i<=totalRows-1;i++, ci++) {           	 //need to subtract 1 because now header row is included in count 
				cj=0;
				for (int j=startCol;j<=totalCols;j++, cj++){
					//System.out.println(ci+":"+cj+"->"+i+":"+j);
					if(getCellData(i,j).trim()!=""){
						tableArray[ci][cj]=getCellData(i,j);
					}
				}
			}
		}catch (FileNotFoundException e){
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}catch (IOException e){
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		return(tableArray);
	}


//	/**
//	 * Get cell value as a string
//	 * 
//	 * @param rowNum
//	 * @param colNum
//	 * @return cellData as a String
//	 */
//	public static String getCellData(int rowNum, int colNum) {
//		String cellData = null;
//		try{
//			cell = excelWSheet.getRow(rowNum).getCell(colNum);
//			if(cell!=null){
//				int dataType = cell.getCellType();
//				if  (dataType == 3) {
//					return "";
//				}else{
//					cellData = cell.getStringCellValue();
//				}
//			}
//		}catch (Exception e){
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//		}
//		return cellData;
//	}

	/**
	 * Returns the cell value as a String
	 * 
	 * @param rowNum
	 * @param colNum
	 * @return cell value as a string
	 */
	public static String getCellData(int rowNum, int colNum) 
	{
		try
		{
			cell = excelWSheet.getRow(rowNum).getCell(colNum);
			String cellData = null;
			if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
				cellData = cell.getStringCellValue();
			}
			else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) 
			{
				cellData = String.valueOf(cell.getNumericCellValue());
			}
			else if (cell.getCellType() == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK)
			{
				cellData = "";
			}
			return cellData;
		} 
		catch (Exception e)
		{
			//System.out.println(e.getMessage());
			//e.printStackTrace();
			return "";
		}
	}	
}