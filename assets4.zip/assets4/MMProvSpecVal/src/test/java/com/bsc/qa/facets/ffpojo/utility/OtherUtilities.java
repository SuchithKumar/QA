package com.bsc.qa.facets.ffpojo.utility;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.sf.cglib.core.EmitUtils;

import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.tests.BaseTest;
//import com.bsc.qa.facets.ffpojo.factory.BaseTest;
//import com.bsc.qa.facets.tests.BscaCare1stMMTest;
import com.relevantcodes.extentreports.LogStatus;

public class OtherUtilities extends BaseTest{
	//static Map<String,Boolean>map=new HashMap<String,Boolean>();
		public static String validateTransformationRule(String fieldName,String fieldValue,String dependantField) {
		StringBuilder inputString=new StringBuilder(fieldValue);
		String returnString=new String();//creating object for return string
		List listArray;
		Boolean flag=false;
		String optionalField="optional";
		String errorCode="";
		//list for storing all the required fields
		List requiredFieldsList=Arrays.asList("ProviderBoardCertificationResponseCode","StateLicenseNumber","ProviderLastName","SiteZipCode","SiteState","SiteCity","UsageIndicator","ProviderGroupName","SiteFacilityType","SiteContactPhoneNumber","SiteAddressLine1");
		if(requiredFieldsList.contains(fieldName)){//checking whether the field is present in the required fields list or not
			optionalField="required";
		}
		switch(fieldName)//switch case validation of individual elements based on the element name
		{
		  
		  case "UsageIndicator": 	if(inputString.toString()!=null&&inputString.toString().length()>0){
										  if(inputString.toString().length()==1){
											  if(inputString.toString().equals("T")||inputString.toString().equals("P")){
												  flag=true;break;
											  }else{ errorCode="0002_03";break;}
										  }else{errorCode="0002_02";break;}
									  }else{errorCode="0002_01";break;}
		  
		  case "MentalHealthProviderAreaofExpertise":
				listArray=Arrays.asList( "C","A","G","S");
				int length=inputString.toString().length();
				boolean flagValue=true;
				for(int i=0;i<length;i++){
					if(!listArray.contains(String.valueOf(inputString.toString().charAt(i)))){
						errorCode="0220_03";
						flagValue=false;
						break;
					}
				}
				if(flagValue){
					flag=true;	
				}
				
				/*if(listArray.contains(inputString.toString()))flag=true;
				else{errorCode="0220_03";}*/
				break;//appending the modified string 
		  case "GroupContractEffectiveDate_NR":if(inputString.toString().replaceAll("\\s", "").length()!=0){flag=true;
		  		
		  						}break;
		  
		  case "GroupContractExpirationDate_NR":if(!inputString.toString().contains("-")||isNumeric(returnString.toString())){flag=true;
	  		
	  						}break;
		  case "BHTIndicator":	if(inputString.toString().equalsIgnoreCase("null")||inputString.toString().length()==0||inputString.toString().equalsIgnoreCase("1")||inputString.toString().equalsIgnoreCase("2")||inputString.toString().equalsIgnoreCase("3")){//checking for length,double quotes,spaces and for numeric data
				flag=true;}	else{errorCode="0211_03";}  break;
		  case "ProviderGroupName":	if(inputString.toString()!=null&&inputString.toString().length()>0){
						  					if(inputString.toString().length()<=60){
							  						if(!inputString.toString().contains("\"")){
							  							flag=true;
							  						}else{errorCode="0003_04";}
						  						
						  					}else{errorCode="0003_02";}
		  									
		  							}else{
		  								errorCode="0003_01";
		  							}
									  String str=inputString.toString().replaceAll("\"","");//replacing double quotes in string
									  inputString.setLength(0);//clearing the string
									  inputString.append(str);//appending the modified string 
			  						  break;
		  case "SiteFacilityType":  listArray=Arrays.asList("10", "17", "25", "26", "27", "28", "29", "30", "31","32", "33", "34","38","3P");
			  						if(inputString.toString()!=null&&inputString.toString().length()>0){//checking for length or double quotes or spaces or numeric data
			  								if(listArray.contains(inputString.toString())){
			  									flag=true;
			  								}else{errorCode="0014_03";}
			  							
			  						}else{errorCode="0014_01";}
			  						//String str1=inputString.toString().replaceAll("\"","");//replacing double quotes in string
									  //inputString.setLength(0);//clearing the string
									  //inputString.append(str1);//appending the modified string 
						  			break;
		  case "SiteContactPhoneNumber":if(inputString.toString()!=null&&inputString.toString().length()>0)flag=true;	//checking for null and length
		  								else{errorCode="0028_01";}
									  if(inputString.toString().length()>13){//checking for length,double quotes,spaces and for numeric data
										  String string=inputString.toString().substring(0,13);
										  inputString.setLength(0);//clearing the string
										  inputString.append(string);//appending the modified string 
									  }
										break;
		  case "SiteAddressLine1": 	if(inputString.toString()!=null&&inputString.toString().length()>0){
			  			if(inputString.toString().length()<=55){
			  				if(!inputString.toString().contains("\""))flag=true;	//checking for null and length
			  				else{errorCode="0108_04";}
			  			}else{errorCode="0108_02";}
		  								}else{errorCode="0108_01";}
									  String str2=inputString.toString().replaceAll("\"","");//replacing double quotes in string
									  inputString.setLength(0);//clearing the string
									  inputString.append(str2);//appending the modified string 
		  							break;
		  case "SiteContactEmail":if(isValidEmail(inputString.toString())||inputString.toString().length()==0)flag=true;
		  							else{errorCode="0029_03";}break;
		  case "SiteCity":          if(inputString.toString()!=null&&inputString.toString().length()>0){
									  if(inputString.toString().length()<=30)flag=true;
									  	//checking for null and length
								  	}else{errorCode="0110_01";}break;
		  case "SiteState": 		if(inputString.toString()!=null&&inputString.toString().length()>0){
									  if(inputString.toString().length()<=2)flag=true;
									  else{errorCode="0111_02";}	//checking for null and length
		  							}else{errorCode="0111_01";}break;
		  case "Site ZipCode":	    if(inputString.toString()!=null&&inputString.toString().length()>0){
										  if(inputString.toString().length()<=15)flag=true;	//checking for null and length
										  else{errorCode="0112_02";}
									  }else{errorCode="0112_01";}break;
		  case "ProviderLastName" :	if(inputString.toString()!=null&&inputString.toString().length()>0){
										  if(!inputString.toString().contains("\""))flag=true;
										  else{errorCode="0202_04";}
									  }else{errorCode="0202_01";}
									  String str3=inputString.toString().replaceAll("\"","");//replacing double quotes in string
									  if(inputString.toString().length()>60){
										  str3.substring(0,60);
									  }
									  inputString.setLength(0);//clearing the string
									  inputString.append(str3);break;//appending the modified string 
		  case "StateLicenseNumber" :	//checking for null and length
			  						if(inputString.toString()!=null&&inputString.toString().length()>0)flag=true;
			  						else{errorCode="0216_01";}
			  						if(inputString.toString().length()>20){
			  							String str4=inputString.toString().substring(0,20);
										  inputString.setLength(0);//clearing the string
										  inputString.append(str4);
			  						}			  						  
		  								break;	
		  case "ProviderBoardCertificationResponseCode" :	//checking for null and length
			  						if(inputString.toString().length()==0||inputString.toString().equals("Y")||inputString.toString().equals("N"))flag=true;
			  						else {errorCode="0295_03";}
		  							if(inputString.toString()!=null&&inputString.toString().length()>0){
		  								String str5=String.valueOf(inputString.toString().charAt(0));//checking for length or double quotes or spaces or numeric data
										  inputString.setLength(0);//clearing the string
										  inputString.append(str5); 
		  							}break;//appending the modified string 
			  						
		  
		  case "ProviderGroupDBAName":flag=true;
			  if(inputString.toString().length()>50){
			  String subStr=inputString.toString().substring(0,50);//checking for length or double quotes or spaces or numeric data
			  inputString.setLength(0);//clearing the string
			  inputString.append(subStr);
			  	//checking for null and length
		  }break;
		  case "GroupNPI":			//inputString.toString().trim().replaceAll("\\s", "");//checking for length or double quotes or spaces or numeric data
			  						if(inputString.toString().length()==10){flag=true;}
			  						else{errorCode="0005_02";}//checking for null and length
								  	if(inputString.toString().length()>10){						 
									  String str06=inputString.toString().trim().substring(0,11);
									  inputString.setLength(0);//clearing the string
									  inputString.append(str06);}break;//appending the modified string 
		  case "GroupTaxIDNumber":   if(inputString.toString().length()==9||inputString.toString().length()==0){flag=true;}
		  							 else{errorCode="0006_02";}break;//checking for length or double quotes or spaces or numeric data
		  								//String str6=inputString.toString().trim().replaceAll("\\s", "");
										  //inputString.setLength(0);//clearing the string
										  //inputString.append(str6);break;//appending the modified string 
		  case "GroupTaxonomyCode":  						
		  if(inputString.toString().length()>=10||inputString.toString().length()==0){
				if(inputString.toString().length()==0){flag=true;}
				else{
				if("X".equalsIgnoreCase(String.valueOf(inputString.toString().charAt(9)))){
					flag=true;//checking for length or double quotes or spaces or numeric data
				}else{errorCode="0010_02";}}
		}else{errorCode="0010_02";}							
		  if(inputString.toString().length()>10){						//checking for length or double quotes or spaces or numeric data 
									  String str_6=inputString.toString().trim().substring(0,10);
									  inputString.setLength(0);//clearing the string
									  inputString.append(str_6);}break;//appending the modified string 
		  case "SiteName":           if(inputString.toString().length()<=60){
			  								if(!inputString.toString().contains("\"")){flag=true;}//checking for length or double quotes or spaces or numeric data
			  								else{errorCode="0011_04";}							
								  		}else{errorCode="0011_02";	}
									  String str7=inputString.toString().trim().replaceAll("\"", "");//replacing double quotes in string
									  inputString.setLength(0);//clearing the string
									  inputString.append(str7);break;//appending the modified string 
		  
		  case "SiteNPI":			 if(inputString.toString().length()==10||inputString.toString().length()==0){flag=true;}
									  else{errorCode="0012_02";}
									  break;//checking for length,double quotes,spaces and for numeric data
																  //String str8=inputString.toString().trim().replaceAll("\\s", "");//checking for length or double quotes or spaces or numeric data
																//  inputString.setLength(0);//clearing the string
																  //inputString.append(str8);break;		//appending the modified string 
		  case "SiteTaxIDNumber":	 if(inputString.toString().length()==9||inputString.toString().length()==0){flag=true;} 
		  								else{errorCode="0013_02";}break;
									//  String str9=inputString.toString().trim().replaceAll("\\s", "");//checking for length or double quotes or spaces or numeric data
									  //inputString.setLength(0);//clearing the string
									  //inputString.append(str9);break;	//appending the modified string 
		  case "SiteInstitutionalFacilityType":
			  							listArray=Arrays.asList("11","12", "13",  "14", "18", "21", "22", "23", "28", "32", "33", "34", "41","43", "65", "66", "71", "72", "73", "74", "75", "76", "77", "78",  "79","81", "82", "83", "84", "85", "86", "89","3P");
		  								if(listArray.contains(inputString.toString())||inputString.toString().length()==0){flag=true;}
		  								else{errorCode="0015_03";}
		  								String str10=inputString.toString().trim().replaceAll("\\s", "");//checking for length or double quotes or spaces or numeric data
		  								inputString.setLength(0);//clearing the string
		  								inputString.append(str10);break;//appending the modified string 
		  case "SiteCountyCode":
			  						listArray=Arrays.asList("1","2","3","4","5","6","7","8","9","01", "02", "03","04", "05", "06", "07", "08","09", "10", "11", "12", "13","14","15","16", "17", "18", "19","20", "21", "22","23", "24", "25","26","27", "28", "29", "30","31","32", "33", "34", "35", "36", "37", "38", "39", "40","41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51","52", "53","54", "55","56", "57", "58", "99");
		  							 if(listArray.contains(inputString.toString())||inputString.toString().length()==0){flag=true;}//checking for length or double quotes or spaces or numeric data
		  							 else{errorCode="0016_03";}
		  							 String str11=inputString.toString().trim().replaceAll("\\s", "");
									  inputString.setLength(0);//clearing the string
									  inputString.append(str11);break;//appending the modified string 
		  case "LicensedBedCount":listArray=Arrays.asList("27","28","31","32","38");//Site Fac Type valid values
		  							/*if((listArray.contains(dependantField)&&isNumeric(inputString.toString()))||inputString.toString().length()==0){//if site fac type value is in above array
			  									flag=true;
		  							}else{errorCode="0017_03";
			  								if(!isNumeric(inputString.toString())){
				  				 				String str_LBC="";
												  inputString.setLength(0);//clearing the string
												  inputString.append(str_LBC);
				  				 					}
		  							  }*/
		  							if(listArray.contains(dependantField)){
		  								if(isNumeric(inputString.toString())||inputString.toString().length()==0){
		  									flag=true;
		  								}else{errorCode="0017_03";}
		  							}else{
		  								flag=true;
		  								if(!isNumeric(inputString.toString())){
			  				 				String str_LBC="";
											  inputString.setLength(0);//clearing the string
											  inputString.append(str_LBC);
			  				 					}
		  							}
		  				 			
		  				 			break;
		  case "AvailableBedCount": listArray=Arrays.asList("27","28");//checking for length or double quotes or spaces or numeric data
									  /*if((listArray.contains(dependantField)&&isNumeric(inputString.toString()))||inputString.toString().length()==0){
											flag=true;
										}
								    else{errorCode="0018_03";if(!isNumeric(inputString.toString())){
		  				 				String str_ABC="";
										  inputString.setLength(0);//clearing the string
										  inputString.append(str_ABC);
		  				 			}}*/
								  if(listArray.contains(dependantField)){
										if(isNumeric(inputString.toString())||inputString.toString().length()==0){
											flag=true;
										}else{errorCode="0018_03";}
									}else{
										flag=true;
										if(!isNumeric(inputString.toString())){
							 				String str_ABC="";
											  inputString.setLength(0);//clearing the string
											  inputString.append(str_ABC);
							 					}
									}
								    break;
		  case "StaffedBedCount":if((inputString.toString()!=" "&&isNumeric(inputString.toString()))||inputString.toString().length()==0)flag=true;else{errorCode="0019_03";
								  if(!isNumeric(inputString.toString())){
						 				String str_SBC="";
										  inputString.setLength(0);//clearing the string
										  inputString.append(str_SBC);
						 			}}break;//inputString.toString()!=" "
		  case "SiteMediCalmembersMaxAcceptableCount":if(isNumeric(inputString.toString())||inputString.toString().length()==0)flag=true;else{errorCode="0021_03";
		  if(!isNumeric(inputString.toString())){
				String str_SBC="";
				  inputString.setLength(0);//clearing the string
				  inputString.append(str_SBC);
			}}break;
		  case "SiteMediCalmembersCurrentAssignedTotalCount":if(isNumeric(inputString.toString())||inputString.toString().length()==0)flag=true;else{errorCode="0022_03";
		  if(!isNumeric(inputString.toString())){
				String str_SBC="";
				  inputString.setLength(0);//clearing the string
				  inputString.append(str_SBC);
			}}break;
		  
		  case "TeachingFacilityIndicator":if(inputString.toString().equals("0")||inputString.toString().equals("1")||inputString.toString().length()==0)flag=true;
		  								else{errorCode="0020_03";}break;
								    // String str12=inputString.toString().trim().replaceAll("\\s", "");//checking for length or double quotes or spaces or numeric data
									  //inputString.setLength(0);//clearing the string
									  //inputString.append(str12);break;//appending the modified string 
		  case "TertiaryIndicator":listArray=Arrays.asList("Y","N","U");//checking for length or double quotes or spaces or numeric data
		  							if(inputString.toString().length()==0|| listArray.contains(inputString.toString()))flag=true;
		  							else {errorCode="0024_03";}
		  							break;//appending the modified string 
		  case "TypeofService":listArray=Arrays.asList("ASC","FSC", "RHE", "RHC", "UCC", "OTO", "GAH", "IHC", "IRB", "OTI");
									if(inputString.toString().length()==3||inputString.toString().length()==0){
										if(inputString.toString().length()==3){
											if(listArray.contains(inputString.toString())){flag=true;}
											else{errorCode="0025_03";}
										}else{flag=true;}
									}else{errorCode="0025_02";}
									break;//appending the modified string 
		  case "OtherTypeofService":if(inputString.toString().length()<=30)flag=true;break;//checking for length or double quotes or spaces or numeric data
		  case "SiteContactEmail_NR":  if(inputString.toString().length()<=256)flag=true;//checking for length or double quotes or spaces or numeric data
								  String str15=inputString.toString().trim().replaceAll("\\s", "");
									  inputString.setLength(0);//clearing the string
									  inputString.append(str15);break;//appending the modified string 
		  case "EnglishspokenAtSite":listArray=Arrays.asList("Y","N");
		  					        if(listArray.contains(inputString.toString())||inputString.toString().length()==0)flag=true;
		  					        else{errorCode="0031_03";}
		  					        String str16=inputString.toString().trim().replaceAll("\\s", "");
									  inputString.setLength(0);//clearing the string
									  inputString.append(str16);break;//appending the modified string 
		 case "ProximitytoPublicTransportationIndicator":listArray=Arrays.asList("U", "1S", "1T", "1U",  "1V");
												if(listArray.contains(inputString.toString())||inputString.toString().length()==0)flag=true;
												else{errorCode="0101_03";}
												break;
		  case "TDDIndicator":listArray=Arrays.asList("Y","N","U");
									if(inputString.toString().length()<=1){
										if( listArray.contains(inputString.toString())||inputString.toString().length()==0){flag=true;}
										else{errorCode="0102_03";}
									}else{errorCode="0102_02";}
									break;//appending the modified string 
		  case "LaboratoryServicesIndicator":
									listArray=Arrays.asList("Y","N","U");
									if(inputString.toString().length()<=1){
										if(listArray.contains(inputString.toString())||inputString.toString().length()==0)flag=true;
										else{errorCode="0103_03";}
									}else{errorCode="0103_02";}
									break;//appending the modified string 
		  case "XRaysIndicator":
									listArray=Arrays.asList("Y","N","U");
									if(inputString.toString().length()<=1){
										if(listArray.contains(inputString.toString())||inputString.toString().length()==0)flag=true;
										else{errorCode="0104_03";}
									}else{errorCode="0104_02";}
									break;//appending the modified string 
		  case "SiteGenderRestrictionCode":listArray=Arrays.asList("F","M");
									if( listArray.contains(inputString.toString())||inputString.toString().length()==0)flag=true;
									else{errorCode="0105_03";}
									break;//appending the modified string 
		  case "SiteAddressLine2": if(inputString.toString()!=null&&inputString.toString().length()>=0&&inputString.toString().length()<=55)flag=true;
		  							else{errorCode="0109_02";}break;	//checking for null and length
		  case "SiteTaxonomyCode": if(inputString.toString().length()>=10&&"X".equalsIgnoreCase(String.valueOf(inputString.toString().charAt(9))))flag=true;
		  							else{errorCode="0113_02";}
								  if(inputString.toString().length()>10){						//checking for length or double quotes or spaces or numeric data 
									  String string6=inputString.toString().trim().substring(0,10);
									  inputString.setLength(0);//clearing the string
									  inputString.append(string6);}break;//appending the modified string 

		  case "ProviderGroupSiteNetworkRoleCode1":if(inputString.toString().equals("3E")||inputString.toString().equals("3G")||inputString.toString().length()==0)flag=true;
		  								else{errorCode="0114_03";}
									 break;//appending the modified string 
		  case "ProviderGroupSiteNetworkRoleCode2":if(inputString.toString().equals("3E")||inputString.toString().equals("3G")||inputString.toString().length()==0)flag=true;
		  							else{errorCode="0115_03";} break;//appending the modified string 
		  case "FacilityOwnerName1":if(inputString.toString()!=null&&inputString.toString().length()>=0&&inputString.toString().length()<=60){
										  if(!inputString.toString().contains("\""))flag=true;
										  else{errorCode="0119_04";}
									  }else{errorCode="0119_02";}
									  String str23=inputString.toString().replaceAll("\"","");//replacing double quotes in string
									  inputString.setLength(0);//clearing the string
									  inputString.append(str23);//appending the modified string 
										  break;						  
		  
		  case "CBASProvider":     if(inputString.toString().length()<=60)flag=true;break;//checking for length or double quotes or spaces or numeric data
		  case "ProviderFirstName":if(inputString.toString().length()>35)errorCode="0203_02";
		  							else{flag=true;}
									 break;//appending the modified string 
		  case "ProviderMiddleName" :if(inputString.toString().length()<=25)flag=true;break;	//checking for  length
		  case "ProviderSuffix" : if(inputString.toString().length()<=10)flag=true;break;	//checking for  length
		  case "ProviderNPI":	  if(inputString.toString()!=null&&inputString.toString().length()<=80)flag=true;	//checking for null and length
								  if(inputString.toString().length()>10){						 	//checking for  length
									  String str_06=inputString.toString().trim().substring(0,10);
									  inputString.setLength(0);//clearing the string
									  inputString.append(str_06);}break;//appending the modified string 
		  case "ProviderGender":listArray=Arrays.asList("F","M","U");
									if(inputString.toString().length()<=1){
										if(listArray.contains(inputString.toString())||inputString.toString().length()==0)flag=true;
										else{errorCode="0208_03";}
									}else{errorCode="0208_02";}
									
									break;//appending the modified string 
		  case "IHSSIndicator":   if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;
		  							else{errorCode="0210_03";}
									  break;//appending the modified string 
		  case "TelehealthIndicator":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;
		  							else{errorCode="0212_03";}
									  break;//appending the modified string 
		  case "MediCalmembersProviderMaxAcceptableCount1":if(isNumeric(inputString.toString()))flag=true;else{errorCode="0214_03";
		  if(!isNumeric(inputString.toString())){
				String str_LBC="";
				  inputString.setLength(0);//clearing the string
				  inputString.append(str_LBC);
			}}break;//checking for length or double quotes or spaces or numeric data
		  case "MediCalmembersProviderCurrentAssignedTotalCount1":if(isNumeric(inputString.toString()))flag=true;
		  													else{errorCode="0215_03";
		  if(!isNumeric(inputString.toString())){
 				String str_LBC="";
				  inputString.setLength(0);//clearing the string
				  inputString.append(str_LBC);
 			}}break;
		  case "LicensureType":       listArray=Arrays.asList("MFT","CSW","NRS", "NPA",  "PCC", "PSY", "SUD", "MD", "OTH");
									  if(inputString.toString().trim().length()<=3){
										  if( listArray.contains(inputString.toString())||inputString.toString().length()==0)flag=true;
										  else{errorCode="0217_03";}
									  }else{errorCode="0217_02";}
									  break;//appending the modified string 
		  
		  case "LicensingState_NR":if(inputString.toString().length()==2)flag=true;//checking for length or double quotes or spaces or numeric data
									  String str29=inputString.toString().trim().replaceAll("\"", "");//replacing double quotes in string
									  inputString.setLength(0);//clearing the string
									  inputString.append(str29);break;//appending the modified string 
		  case "ProviderEmail":		if(inputString.toString().length()<=60){
											if(isValidEmail(inputString.toString())||inputString.toString().length()==0){
												flag=true;									 //checking for length or double quotes or spaces or numeric data
											} else{errorCode="0223_03";}
									  }else{errorCode="0223_02";}
									 						
									  if(inputString.toString().length()>60){
									  String str30=inputString.toString().substring(0,60);//replacing double quotes in string
									  inputString.setLength(0);//clearing the string
									  inputString.append(str30);//appending the modified string 
									  }break;
		
		//  case "Affiliated1NPIType":if(inputString.toString()!=null&&inputString.toString().length()>0)flag=true;break;	//checking for null and length
		//  case "Affiliated2NPIType":if(inputString.toString()!=null&&inputString.toString().length()>0)flag=true;break;	//checking for null and length
		//  case "Affiliated3NPIType":if(inputString.toString()!=null&&inputString.toString().length()>0)flag=true;break;	//checking for null and length
		//  case "Affiliated4NPIType":if(inputString.toString()!=null&&inputString.toString().length()>0)flag=true;break;	//checking for null and length
		  case "AcademicDegreeDescription":if(dependantField!=null&&dependantField.length()>0){
										  if(inputString.toString()!=null&&inputString.toString().length()>0)flag=true;
											else{errorCode="0269_01";}	//checking for null and length
		  									}else{flag=true;}break;
		  						
		  case "SiteAgeRangeMinimum": 	if(inputString.toString()!=" "&&inputString.toString().length()<20)flag=true;
		  								else{errorCode="0106_03";
		  								if(!isNumeric(inputString.toString())){
							 				String str_SBC="";
											  inputString.setLength(0);//clearing the string
											  inputString.append(str_SBC);
							 			}}break;
		  case "PrimaryCarePhysicianID": 	if("3E".equalsIgnoreCase(dependantField)){
										  if(inputString.toString()!=null&&inputString.toString().length()>0){
											  if(inputString.toString().length()<=10)flag=true;
											  else{errorCode="0222_02";}
										  }else{errorCode="0222_01";}
									  }else{
										  if(inputString.toString().length()<=10)flag=true;
										  else{errorCode="0222_02";}
									  }break;
			  									
		  case "AcademicDegreeCode": 	
									 listArray=Arrays.asList( "2.1","2.2","2.3","2.4","2.5","2.6","2.7","3.1","3.2","4.1","4.2","4.3","4.4","4.5");
										if(listArray.contains(inputString.toString())||inputString.toString().length()==0)flag=true;
										else{errorCode="0268_03";}
										break;//appending the modified string 
				// below validations are for validating the input string for Y r N and for length 
		  case "EnglishSpokenbyProvider": 	if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;
		  								else{errorCode="0270_03";}break;
		  case "PractitionerProviderGroupNetworkRoleCode1":if(inputString.toString().equals("3E")||inputString.toString().equals("3G")||inputString.toString().length()==0)flag=true;else{errorCode="0293_03";}break;
		  case "PractitionerProviderGroupNetworkRoleCode2":if(inputString.toString().equals("3E")||inputString.toString().equals("3G")||inputString.toString().length()==0)flag=true;else{errorCode="0294_03";}break;
		  case "ProviderLocationID": 	if(inputString.toString().length()<=10)flag=true;else{errorCode="0297_02";}break;
		  case "ProviderPanelStatus": 	if(inputString.toString().equals("R")||inputString.toString().equals("F")||inputString.toString().length()==0)flag=true;else{errorCode="0337_03";}break;
		  case "PublishProviderEmail":if(dependantField!=null&&dependantField.length()>0){
			  							if(inputString.toString().equals("Y")||inputString.toString().equals("N"))flag=true;
			  							else{errorCode="0342_02";}
			  							}else{flag=true;}break;
		  case "LanguageInterpreterServices":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0343_03";}break;
		  case "ProvCompleteCulturalCompTrng":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0344_03";}break;
		  case "ProvAccessSkillMedIntOnSite":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0345_03";}break;
		  case "LangInterpreterNonEngLanguages":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0346_03";}break;
		  case "SpecExpPhyDisability":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0347_03";}break;
		  case "SpecExpChronicIllness":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0348_03";}break;
		  case "SpecExpHIVAIDS":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0349_03";}break;
		  case "SpecExpSeriousMentalIllness":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0350_03";}break;
		  case "SPECEXP_HOMELESSNESS":if(inputString.toString().length()==1)flag=true;else{errorCode="0351_03";}break;
		  case "SpecExpDeafnessHardHearing":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0352_03";}break;
		  case "SpecExpBlindnessVisualImpair":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0353_03";}break;
		  case "SpecExpCooccuringDisorders":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0354_03";}break;
		  case "AccessibilityParking":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0356_03";}break;
		  case "AccessibilityExteriorBuilding":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0357_03";}break;
		  case "AccessibilityInteriorBuilding":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0358_03";}break;	
		  case "AccessibilityExamRoom":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0359_03";}break;
		  case "AccessibilityRestroom":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0360_03";}break;
		  case "AccessibilityExamTableScale":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0361_03";}break;
		  case "AccessibilityWheelChair":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0362_03";}break;
		  case "AccessibilityMedicalEquipment":if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;else{errorCode="0363_03";}break;
		  case "SiteAgeRangeMaximum": 	if(inputString.toString()!=" "&&inputString.toString().length()<20)flag=true;
		  								else{errorCode="0107_03";
		  								 if(!isNumeric(inputString.toString())){
								 				String str_SBC="";
												  inputString.setLength(0);//clearing the string
												  inputString.append(str_SBC);
								 			}}break;
		  case "ProviderPrimaryTaxonomy":if(inputString.toString().length()>=10||inputString.toString().length()==0){
					  							if(inputString.toString().length()==0){flag=true;}
					  							else{
					  							if("X".equalsIgnoreCase(String.valueOf(inputString.toString().charAt(9)))){
					  								flag=true;//checking for length or double quotes or spaces or numeric data
					  							}else{errorCode="0290_02";}}
		  								}else{errorCode="0290_02";}
									  	if(inputString.toString().length()>10){						 
										String string_6=inputString.toString().trim().substring(0,10);
									  inputString.setLength(0);//clearing the string
									  inputString.append(string_6);}break;//appending the modified string 
		  
		//  case "NPIofSupervisingPhysician":if(isNumeric(inputString.toString()))flag=true;break;//checking for length or double quotes or spaces or numeric data
		  case "ProfessionalPatientAcceptanceIndicator":if(dependantField.equalsIgnoreCase("3E")){
			  if(inputString.toString()!=null&&inputString.toString().length()>0&&(inputString.toString().equals("P7")||inputString.toString().equals("P8")))flag=true;
			  else{errorCode="0303_01";}
		  }else{if(inputString.toString()==" "){errorCode="0303_01";}
		  else{flag=true;}	
		  		}break;
			  					
		  case "OSHPDID":listArray=Arrays.asList("27","28");//checking for length or double quotes or spaces or numeric data
		  if(!listArray.contains(dependantField)){
			  if(inputString.toString().length()>0){
				  errorCode="0023_01";
			  }else{flag=true;}
			  }else{flag=true;}
									 /* if(listArray.contains(dependantField)){
										  if(inputString.toString()!=null&&inputString.toString().length()>0){
											flag=true;}
										  else{errorCode="0023_01";}
										}else{flag=true;}*/
								    
									  				break;
		  
		  case "Specialty1":
			  		if(!"3G".equalsIgnoreCase(dependantField)){
			  			flag=true;
				  					//if(inputString.toString()!=null&&inputString.toString().length()>0)flag=true;
				  					//else{errorCode="0304_01";}
			  				}else{
			  					if(inputString.toString()!=null&&inputString.toString().length()>0){
			  						errorCode="0304_01";
			  					}else{
			  						flag=true;
			  					}
			  				}
		  					break;
		  case "SiteDEANumber": /*if("3P".equalsIgnoreCase(dependantField)&&inputString.toString()!=null&&inputString.toString().length()>0){ 
			  flag=true; }else{errorCode="0116_01";}break;*/
			  if("3P".equalsIgnoreCase(dependantField)){
				  if(inputString.toString()!=null&&inputString.toString().length()>0){flag=true;}
				  else{errorCode="0116_01";}
			  }else{flag=true;}
				  break;
		  case "BoardType":/*if("Y".equalsIgnoreCase(dependantField)&&inputString.toString()!=null&&inputString.toString().length()>0){ flag=true; }else{errorCode="0219_01";}break;*/
			  if("Y".equalsIgnoreCase(dependantField)){
				  if(inputString.toString()!=null&&inputString.toString().length()>0){ flag=true; }
				  else{errorCode="0219_01";}
			  }else{flag=true;}break;
		  case "PublishSiteEmail":if(dependantField!=null&&dependantField.length()>0){
			  					if(inputString.toString().equals("Y")||inputString.toString().equals("N")||inputString.toString().length()==0)flag=true;
		  						else{errorCode="0341_02";}}else{flag=true;}
		  							break;//appending the modified string 
										
	
		  default: flag=true;
		  					//System.out.println("Default:"+fieldName+"| value:"+inputString.toString());
		  					break;
		}
		returnString=inputString.toString()+";"+flag+";"+optionalField+";"+errorCode;
		return returnString;
	}
		public static boolean isValidEmail(String emailId) {
			String emailPattern="(^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[_A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,4})$)";
			Matcher m=Pattern.compile(emailPattern).matcher(emailId);
			if(m.find()){
				return true;
			}
			return false;
		}
		
		public static boolean isValidEmail1(String emailId) {
			//dboenzi@shammaseye.com
			if(emailId.contains("@")){
				if(emailId.substring(emailId.indexOf("@")).contains(".")){
					String subStr=emailId.substring(emailId.indexOf('@')+1,emailId.lastIndexOf("."));	
					if(subStr.contains(".")){
						return false;
					}else{
						String pattern="[^A-Za-z0-9]+";
						Matcher m=Pattern.compile(pattern).matcher(subStr);
						if(m.find()){
							return false;
						}else{
							String subString=emailId.substring(emailId.lastIndexOf(".")+1);
							if(Pattern.compile(pattern).matcher(subString).find()){
								return false;
							}else{
								return true;
							}
						}
					}
				}else{
					return false;
				}
				
			
				
		}else{
			return false;
		}	
		
	}
	//below method is to check whether the given number is numeric or not
	public static boolean isNumeric(String str) {
	    int size = str.length();
	    for (int i = 0; i < size; i++) {
	        if (!Character.isDigit(str.charAt(i))) {
	            return false;
	        }
	    }

	    return size > 0;
	}//below method is to replace the string with given character
	public static String replaceStringWith(StringBuilder inputString,String ch){
		return inputString.toString().replaceAll(ch, "");
		}//below method is to replace the given character with space
	public static String removeSpaces(StringBuilder inputString,String ch){
		return inputString.toString().replaceAll(ch, "");
		}//below method is to remove sapces before and after string
	public static String removeTrailingAndLeadingSpaces(StringBuilder inputString,String ch){
		return inputString.toString().trim();
		}//below method is to check for th null or blank
	public static boolean isNullOrBlank(String param) { 
			
		    return param == null || param.trim().length() == 0;
		    
		}//below method is to check given string is null or not
	public static boolean isNull(StringBuilder inputString){
			if(inputString==null){				return true;		}
			else if(inputString!=null&&inputString.length()<1){return true;		}
			return false;
		}
	//below method is to check the length of the string
	public static boolean checkLength(StringBuilder inputString,int length){
		return inputString.length()<=length;//checks for length of string
		}
	
	//This is used to print the test case details in extents reports file
	public static void printTestCaseDeatilsInReport(Map<String, String> data) {		
		String strSUCName= data.get("SUC Name").toString();		//Name of the SUC
		String strTestCaseId = data.get("Test Case ID").toString();		//test case id
		String strTestCaseName = data.get("Test Case Name").toString();		//test case name
		String strStepNumber = data.get("Step Number").toString();//step number
		String fieldName=data.get("Query parameter1").toString();//filed name that we are validating
		//String strInputFileName = data.get("Input File Name").toString();
		logger.log(LogStatus.INFO," SUC Name: " + strSUCName + ", Test Case ID: " + strTestCaseId + ", Field Name: " + fieldName + ", Test Case Name: " + strTestCaseName + ", Step Number:" + strStepNumber);
		//logger.log(LogStatus.INFO," Input File Name: " + strInputFileName);
	}
	
	//This method validates error codes generated for the invalid data fields
	public static void validateErrorCodes(List<String> errorCodesList,Map<String,String> fileErrorDataMap, Map<String, String> dbErrorDataMap,String columnName_parameter1,
			SoftAssert softAssertion) {
		for(String key:fileErrorDataMap.keySet()){//loop through the failed fields list of primary key
			if(dbErrorDataMap.containsKey(key)){//check for the primary in dbErrorDatamap
				
				Boolean flag=true;
				String[] errorCodesArray= dbErrorDataMap.get(key).split(";");
				
				for(String errorCode:errorCodesArray){
					if(errorCode.contains(fileErrorDataMap.get(key))){//check for the error presence in the error codes list
						//validation pass and print the related information in report
	//System.out.println("FieldName:"+columnName_parameter1+"|GRP_NPI:"+key+"| Error Code:" + dbErrorDataMap.get(key) + " is validated successfully");
						softAssertion.assertTrue(true,"FieldName:"+columnName_parameter1+"|GRP_NPI:"+key+"|File Error Code:" + fileErrorDataMap.get(key) + "|DBErrorCode:"+errorCode+" is validated successfully" );
						 logger.log(LogStatus.INFO, "FieldName:"+columnName_parameter1+"|GRP_NPI:"+key+"|File Error Code:" + fileErrorDataMap.get(key) + "|DBErrorCode:"+errorCode+" is validated successfully" );
					flag=false;
					}
				}
				
				/*if(errorCodesList.contains(dbErrorDataMap.get(key))){//check for the error presence in the error codes list
					//validation pass and print the related information in report
//System.out.println("FieldName:"+columnName_parameter1+"|GRP_NPI:"+key+"| Error Code:" + dbErrorDataMap.get(key) + " is validated successfully");
					softAssertion.assertTrue(true,"FieldName:"+columnName_parameter1+"|GRP_NPI:"+key+"| Erro Code:" + dbErrorDataMap.get(key) + " is validated successfully" );
					 logger.log(LogStatus.INFO, "GRP_NPI:"+key+"| Erro Code:" + dbErrorDataMap.get(key)+" is validated successfully");
				}*/
				
				if(flag){
					
						//validation failed and print the error information in report
						//System.out.println("Error Code:" + fileErrorDataMap.get(key) + " is not present in Database for GRP_NPI:" +key);
						softAssertion.assertTrue(false,"Error Code:" + fileErrorDataMap.get(key) + " is not present in Database for GRP_NPI:" +key+"|DBcode:"+dbErrorDataMap.get(key));
						 logger.log(LogStatus.INFO,"Error Code:" + fileErrorDataMap.get(key) + " is not present in Database for GRP_NPI:" +key+"|DBcode:"+dbErrorDataMap.get(key));	
				
				}
			}else{
				softAssertion.assertTrue(false,"Error Code:" + fileErrorDataMap.get(key) + " is not present in Database for GRP_NPI:" +key);
				 logger.log(LogStatus.INFO,"Error Code:" + fileErrorDataMap.get(key) + " is not present in Database for GRP_NPI:" +key);	
		
			}
		}
	}
	//below method is to validate source and target map data
	public static void validate(Map<String, String> flatFileDataMap,	Map<String, String> dbDataMap,String columnName_parameter1, SoftAssert softAssertion) {
			//SoftAssert softAssertion= new SoftAssert();
		
			for(String key:flatFileDataMap.keySet()){			
				if(dbDataMap.containsKey(key)){
					OtherUtilities.validateActualAndExpectedValues(key,flatFileDataMap.get(key),dbDataMap.get(key),columnName_parameter1,softAssertion);
					//System.out.println("GRP_NPI: " + key + ", file Value: " + flatFileDataMap.get(key) + ", database Value: " + dbDataMap.get(key)+"| validation success");
				}/*else{
					 softAssertion.assertTrue(false,"FieldName:"+columnName_parameter1+"| file value:"+flatFileDataMap.get(key)+" is not present in database for GRP_NPI:"+ key );
					// logger.log(LogStatus.INFO,"file value:"+flatFileDataMap.get(key)+"is not present database for GRP_NPI:"+ key);
				}*/			
			}		
		}
	private static void validateActualAndExpectedValues(String key,String flatFileValue,String dbValue,String columnName_parameter1, SoftAssert softAssertion) {
		if(dbValue==null){
			dbValue="";
		}
		List<String> fieldsList=Arrays.asList("GRP_CONTR_EFF_DT","GRP_CONTR_TERM_DT","SITE_CONTR_EFF_DT","SITE_CONTR_EXPIR_DT","PROV_AFFIL_EFF_DT","PROV_AFFIL_TERM_DT");
		if(isNumeric(flatFileValue)&&flatFileValue.length()>1){//check the field for Number data and blank or not
			flatFileValue=flatFileValue.replaceAll("^0+", "");//replacing first leading zeros in integer data
		}
		if(isNumeric(dbValue)&&dbValue.length()>1){//check the field for Number data and blank or not
			dbValue=dbValue.replaceAll("^0+", "");//replacing first leading zeros in integer data
		}
		
		
		/*if("SITE_PROX_FOR_PUBLIC_TRANSPORT".equalsIgnoreCase(columnName_parameter1)){
				 while(flatFileValue.length()<2){
					 flatFileValue=flatFileValue.concat(" ");
				 }
			
			
		}else if("SITE_TDD_IND".equalsIgnoreCase(columnName_parameter1)){
			while(flatFileValue.length()<7){flatFileValue=flatFileValue.concat(" ");}
		}else if("SITE_LAB_SRVCS_IND".equalsIgnoreCase(columnName_parameter1)){
			while(flatFileValue.length()<7){
				 flatFileValue=flatFileValue.concat(" ");
			 }
		}else if("SITE_XRAY_IND".equalsIgnoreCase(columnName_parameter1)){
			while(flatFileValue.length()<7){
				 flatFileValue=flatFileValue.concat(" ");
			 }
		}else if(fieldsList.contains(columnName_parameter1.toString().trim())){
			if(dbValue.length()>=8){
				dbValue=dbValue.replaceAll("-", "").substring(0,8);
			}
			flatFileValue=flatFileValue.replaceAll("\\s", "").toString();			
		}else{
			flatFileValue=flatFileValue.trim().toString();
			dbValue=dbValue.trim().toString();
		}else if("GRP_CONTR_TERM_DT".equalsIgnoreCase(columnName_parameter1)){
			dbValue=dbValue.substring(0,9).replaceAll("-", "");
		}*/
			
		switch(columnName_parameter1){
		case "SITE_FAC_TYP_CD":if(flatFileValue.length()!=0)while(flatFileValue.length()<2){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_TCH_FAC_IND1":while(flatFileValue.length()<1){flatFileValue=flatFileValue;}break;
		case "SITE_ENGL_SPKN_IND1":while(flatFileValue.length()<1){flatFileValue=flatFileValue.concat(" ");}break;
		case "HDCP_ACSBL_IND1":while(flatFileValue.length()<1){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_PROX_TO_PUB_TRNSPRT_CD":if(flatFileValue.length()!=0)while(flatFileValue.length()<2){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_TDD_IND":if(flatFileValue.length()!=0)while(flatFileValue.length()<7){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_LAB_SRVCS_IND":if(flatFileValue.length()!=0)while(flatFileValue.length()<7){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_XRAY_IND":  if(flatFileValue.length()!=0)while(flatFileValue.length()<7){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_1_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_2_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_3_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_4_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_5_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_6_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_7_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_8_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_9_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_10_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_11_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_12_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_13_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_14_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_15_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_16_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_17_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_18_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_19_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_OWNR_20_PCT":if(flatFileValue.length()!=0)while(flatFileValue.length()<3){flatFileValue=flatFileValue.concat(" ");}break;
		case "SITE_CBAS_IND_1":if(flatFileValue.length()!=0)while(flatFileValue.length()<1){flatFileValue=flatFileValue.concat(" ");}break;
		case "PROV_IHSS_IND_1":if(flatFileValue.length()!=0)while(flatFileValue.length()<1){flatFileValue=flatFileValue.concat(" ");}break;
		case "PROV_TLH_IND_1":if(flatFileValue.length()!=0)while(flatFileValue.length()<1){flatFileValue=flatFileValue.concat(" ");}break;
		case "PROV_LIC_ST_NM":if(flatFileValue.length()!=0)while(flatFileValue.length()<2){flatFileValue=flatFileValue.concat(" ");}break;
		case "PROV_ENGL_SPKN_IND1":if(flatFileValue.length()!=0)while(flatFileValue.length()<1){flatFileValue=flatFileValue.concat(" ");}break;
		case "GRP_CONTR_TERM_DT_Remove":flatFileValue="";break;
		case "SITE_SUN_SCHED_STRT_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_SUN_SCHED_END_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_MON_SCHED_STRT_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_MON_SCHED_END_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_TUE_SCHED_STRT_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_TUE_SCHED_END_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_WED_SCHED_STRT_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_WED_SCHED_END_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_THU_SCHED_STRT_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_THU_SCHED_END_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_FRI_SCHED_STRT_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_FRI_SCHED_END_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_SAT_SCHED_STRT_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_SAT_SCHED_END_TM":if(flatFileValue.length()>9)flatFileValue=flatFileValue.substring(0,9);break;
		case "SITE_WEB_URL_ADDR":if(flatFileValue.length()>50)flatFileValue=flatFileValue.substring(0,50);
								else{flatFileValue=flatFileValue.trim();
								dbValue=dbValue.trim();
									/*if(flatFileValue.endsWith(" ")){
										flatFileValue=flatFileValue.trim();System.out.println("Hi");
										}else{System.out.println("hello");}*/
									}break;		default:if(fieldsList.contains(columnName_parameter1.toString().trim())){
						if(dbValue.length()>=8){
							dbValue=dbValue.replaceAll("-", "").substring(0,8);
						}
						flatFileValue=flatFileValue.replaceAll("\\s", "").toString();			
				}else{
					flatFileValue=flatFileValue.trim().toString();
					dbValue=dbValue.trim().toString();
				}break;
			
			
		}
		
		
		//System.out.println("field Value:"+flatFileValue.trim()+"| db Value"+dbValue.trim()+" for field: "+columnName_parameter1+"|GRP_NPI:"+key);
		softAssertion.assertEquals(flatFileValue,dbValue, "FieldName:"+columnName_parameter1+"|GRP_NPI:" + key + "| file value: "+flatFileValue+"|database value:"+dbValue );
		logger.log(LogStatus.INFO, "FieldName:"+columnName_parameter1+"| GRP_NPI:" + key + "| file value: "+flatFileValue+"|database value:"+dbValue );
}
}
