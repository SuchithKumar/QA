package com.bsc.qa.facets.ffpojo.utility;
/**
 * Serhiy Malyy 
 * Class allows to locate most recent file in folder by last date/time modified
 * It enables file-based test to run and select files under test from folder and eliminates the need to hardcode file name
 * 
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.bsc.qa.facets.tests.BscaCare1stMMTest;
public class TestFileUtil {
	String FlatFileRootDirectory;
	String InterfaceSpecoficFolder; 
	//constructor for initializing file root directory and specific folder
	public TestFileUtil(String flatFileRootDirectory,String interfaceSpecoficFolder) {
		FlatFileRootDirectory = flatFileRootDirectory;
		InterfaceSpecoficFolder = interfaceSpecoficFolder;
	}
	public static  void parseFile(String delimeter,String testFlatFileCompletePath, String ColumnName_parameter1, String fileFieldAndDBColumnMappingFilePath, String mappingSheetName) throws IOException{
		 File inputFile = new File(testFlatFileCompletePath);//inbound file path
		 String line=null;//line declaration
		 List<String[]> rowsList=new ArrayList<String[]>();//list for all the rows in file
	 	 if (!inputFile.exists()) { 
	 		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
		  } else {
	//		  System.out.println("Starting of File Reading . . . . . .  . . . . ");
				FileReader fileReader =  new FileReader(testFlatFileCompletePath);
				if(BscaCare1stMMTest.errorCodesList.size()==0){
					new ExcelUtils(fileFieldAndDBColumnMappingFilePath,"ErrorCodes");//Excel setup
					BscaCare1stMMTest.errorCodesList=ExcelUtils.getErrorCodesList();//getting error codes list
				}
				new ExcelUtils(fileFieldAndDBColumnMappingFilePath,mappingSheetName);//Excel setup
				//calling method to get the field name corresponding column name
				String fieldNameCorrespondingColumnName=ExcelUtils.getFieldNameCorrespondingColumnName(ColumnName_parameter1);
	//			System.out.println("fieldNameCorrespondingColumnName:"+fieldNameCorrespondingColumnName);
				
				int count=0;
				BufferedReader bufferedReader = new BufferedReader(fileReader);//creating Buffer reader object
		        while((line = bufferedReader.readLine()) != null) {//looping through all the lines
	              String[] columnsArray = line.split(delimeter,369);//spliting the lines using the delimeter
		        	 // List columnsArray = line.split(delimeter);//spliting the lines using the delimeter
				if(count>5)break;
	                //System.out.println("Number of pipes"+(line.length()-line.replaceAll("\\|", "").length()));
	                rowsList.add(columnsArray);}   //adding all teh columns in to list object
		        String[] columns=rowsList.get(0);//getting the first record in the list
		        int headerColumnsLength=columns.length;// column length
		        int numberOfRows=rowsList.size();
				int fieldIndex=0;
				for(int i=0;i<headerColumnsLength;i++){//looping through all the columns
					//System.out.println("fieldNameCorrespondingColumnName:"+fieldNameCorrespondingColumnName);
					if(columns[i].equalsIgnoreCase(fieldNameCorrespondingColumnName.trim())){//findign the index of the column passed from datasheet
						fieldIndex=i;
						break;
					}
				}
			//	System.out.println("index:"+fieldIndex+"|fieldName:"+fieldNameCorrespondingColumnName);
		       for(int rowNo=1;rowNo<numberOfRows;rowNo++){//looping through all the rows in file
					//int columnLength=rowsList.get(rowNo).length;
		    	 //  System.out.println("RowArraySize:"+rowsList.get(rowNo).length);
		    	   
		    	   for(int i=0;i<headerColumnsLength-1;i++){//rowsList.get(rowNo).length
		    		  // System.out.println("Index:"+i+"|value:"+row	List.get(rowNo)[i]);
		    	   }
		    	   
		    	   String fieldValue=rowsList.get(rowNo)[fieldIndex];//getting the field value in the particular index
		    	  /* for(Integer index:compositekeyFileds){
		    		   keyBuilder.append(rowsList.get(rowNo)[index]);
		    	   }*/
		    	   //below step is to validate the transformation logic
		    	   String dependantField="";
		    	  if("SITE_LIC_BED_CNT".equalsIgnoreCase(ColumnName_parameter1)){
		    		   dependantField=rowsList.get(rowNo)[13];  
		    	  }else if("SITE_AVAIL_BED_CNT".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[13];  
		    	  }else if("SITE_OSHPD_ID".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[13];  
		    	  }else if("SITE_DEA_NBR".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[13];  
		    	  }else if("PROV_BRD_TYP_CD".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[294];  
		    	  }else if("PCP_ID".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[292]; 
		    	  }else if("PROV_ACDM_DEGR_DESC".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[267]; 
		    	  }else if("PTNT_ACPT_IND".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[292]; 
		    	  }else if("PROV_TYP_CD".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[113]; 
		    	  }else if("PUBL_SITE_EMAIL_ADDR".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[28]; 
		    	  }else if("PUBL_PROV_EMAIL_ADDR_TXT".equalsIgnoreCase(ColumnName_parameter1)){
		    		  dependantField=rowsList.get(rowNo)[222]; 
		    	  }
		    	  
		    	  String fieldName="";
		    	   if("ProvSpecMappingSheet_VSP".equalsIgnoreCase(mappingSheetName)){
		    		    fieldName=ExcelUtils.getFieldNameCorrespondingHeader(fieldNameCorrespondingColumnName);   
		    	   }else{fieldName=fieldNameCorrespondingColumnName;}
		    	   
		    	   //System.out.println("fieldName for corresponding header:"+fieldName);
		    	   if(fieldValue.length()>1){
		    		   fieldValue=fieldValue.trim();
		    	   }
		    	   String returnString=OtherUtilities.validateTransformationRule(fieldName, fieldValue,dependantField);
		    //	   System.out.println(fieldName+"|NPI:"+rowsList.get(rowNo)[4]+"|"+fieldValue+"|size:"+fieldValue.length()+"| "+returnString.toString());
		  // System.out.println("Field :"+fieldValue+" | validation :"+returnString.split(";")[1]+" | "+returnString.split(";")[2]);
		    	   //checking for null value and Required field	
		    	   //System.out.println("fieldNamee:"+fieldNameCorrespondingColumnName+"|returnString:"+returnString);
		    	   		if(returnString.split(";")[2]!=null&&returnString.split(";")[2].equals("required")){
		    	   			
		    	   			if(returnString.split(";")[1].equalsIgnoreCase("true")){
		    //	   		System.out.println(fieldNameCorrespondingColumnName+"--validation Pass NPI:"+rowsList.get(rowNo)[4]+" |inputString:"+returnString.split(";")[0]);
		    	   				BscaCare1stMMTest.fileValidDataMap.put(rowsList.get(rowNo)[4], returnString.split(";")[0]);
		    	   				
		    	   			}else{
		    	   				
		    	   				System.out.println(fieldNameCorrespondingColumnName+"--validation Failed NPI:"+rowsList.get(rowNo)[4]+" |inputString:"+returnString.split(";")[0]);
		    	   				
		    	   				//BscaCare1stMMTest.fileErrorDataList.add(rowsList.get(rowNo)[4]);
		    	   				BscaCare1stMMTest.fileErrorDataMap.put(rowsList.get(rowNo)[4], returnString.split(";")[3]);
		    	   			}//checking for null value and Optional field
		    	   		}else if(returnString.split(";")[2]!=null&&returnString.split(";")[2].equals("optional")){
		    	   			if(returnString.split(";")[1].equalsIgnoreCase("true")){
		    	   				
		    	   				BscaCare1stMMTest.fileValidDataMap.put(rowsList.get(rowNo)[4], returnString.split(";")[0]);
		    	   			}else{
		    	   				System.out.println(fieldNameCorrespondingColumnName+"--validation Failed NPI:"+rowsList.get(rowNo)[4]+" |inputString:"+returnString.split(";")[0]);
		    	   			//	BscaCare1stMMTest.fileErrorDataList.add(rowsList.get(rowNo)[4]);
		    	   				BscaCare1stMMTest.fileErrorDataMap.put(rowsList.get(rowNo)[4], returnString.split(";")[3]);
		    	   				BscaCare1stMMTest.fileValidDataMap.put(rowsList.get(rowNo)[4], returnString.split(";")[0]);
		    	   			
		    	   			}
		    	   		}
					
		       	}		
	    	}
	 	
}
	public static File lastFileModified(String dir) {
	    File fl = new File(dir);//creating file
	    File[] files = fl.listFiles(new FileFilter() {//getting list of file in the given directory          
	        public boolean accept(File file) {
	            return file.isFile();
	        }
	    });
	    long lastMod = Long.MIN_VALUE;
	    File choice = null;
	    for (File file : files) {
	        if (file.lastModified() > lastMod) {
	            choice = file;
	            lastMod = file.lastModified();//last modified
	        }
	    }
	    return choice; //lastFileModified
	}
	
	public File getTestFile(){
		//getting complete path.
		String completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		
		System.out.println("Test file root directory is:" + FlatFileRootDirectory);
		System.out.println("Test file spefic directory is:" + InterfaceSpecoficFolder);
		
		File objFile = lastFileModified (completePath);
		
		return objFile;
	
	}
	
	public String getCompleteTestFilePath(){
		
		String completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		
		System.out.println("Complete path to test file is:"+ completePath);
		
		File objFile = lastFileModified (completePath);
		
		String obsPath = objFile.getAbsolutePath();	
		
		System.out.println("----------------------test File Info -------------------------------------");
		System.out.println(" ");
		System.out.println("Absolute file under test is :"+ obsPath);
		System.out.println(" ");
		System.out.println("----------------------test File Info -------------------------------------");
		return obsPath;
	
				
		
	}

	public static void copyFile(Path htmlSourcePath, Path htmlReportDestinationPath) throws IOException {
		Files.copy(htmlSourcePath, htmlReportDestinationPath,StandardCopyOption.REPLACE_EXISTING);	
		
		
	}
	
	


}
