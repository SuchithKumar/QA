package com.bsc.qa.facets.tests;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
public class BscaCare1stMMTest extends BaseTest implements IHookable{
	//below field declarations are for filepath,sheetname,fileFileds and dbcolumn mapping file path and input files location and resultsFolderpath
	private static String filePath,sheetName,fileFieldAndDBColumnMappingFilePath,resultsDestinationFolderPath,resultsSourceFolderPath,rootLocationOfInputFiles;
	private static DBUtils objDBUtility;//reference for dbUtils class
	public 	static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
	private static Path path,inputDataPath;// input data folder path
	public static Map<String,String>dbValidDataMap,dbErrorDataMap;//map for storing db data for valid and unvalid field values
	public static Map<String,String>fileValidDataMap=new HashMap<String,String>();//map for storing file data for valid field values
	public static Map<String,String>fileErrorDataMap=new HashMap<String,String>();//map for storing file data for valid field values
	public static List<String>errorCodesList=new ArrayList<String>();//list for storing errorCodeslist
	public static List<String>fileErrorDataList=new ArrayList<String>();//list for storing fileErrorData
	public static int failCount;//failed fields count
	public static String SUCName,testCaseName;
	
	//************************************** TEST METHODS************************
	@Test(dataProvider = "masterDataProvider")
	private static void ProvSpecFileAndDatabaseValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			testCaseName=data.get("Test Case ID"); 
			OtherUtilities.printTestCaseDeatilsInReport(data);
			String inputFileName=data.get("Input File Name").toString();//getting input file name from data sheet
			 SUCName=data.get("SUC Name").toString();//getting suc name from data sheet
			 String fileType=data.get("Input File Type").toString();
			 String mappingSheetName="";
			 if("VSP File".equalsIgnoreCase(fileType.toString().trim())){
				  mappingSheetName="ProvSpecMappingSheet_VSP";//sheet name for field names and db table column names mapping	 
			 }else{
				  mappingSheetName="ProvSpecMappingSheet";//sheet name for field names and db table column names mapping
			 }
			String queryFromDataSheet = data.get("SqlQuery").toString();//getting SQL query from data sheet
			String ColumnName_parameter1= data.get("Query parameter1").toString().trim();//getting query parameter from data sheet
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",ColumnName_parameter1.trim());//Replacing the query parameter
			
			dbValidDataMap = objDBUtility.resultSetToMap(SQLQuery.split(";")[0]);//calling method to get the resultset in map
			dbErrorDataMap = objDBUtility.resultSetToErrorDataMap(SQLQuery.split(";")[1]);
			//System.out.println("dbValidDataMap: "+dbValidDataMap);
			//System.out.println("dbErrorDataMap:"+dbErrorDataMap);
			for(String fileName:inputFileName.split(";")){//looping over array of input filenames array and checking for the file name and assigning values to mapping sheet name to identify sheet in file field and db column mapping excel file
				if(fileName!=null&&fileName.length()>0){	//checking the fileName length
					//This will store the data into** BscaCare1stMMTest.fileValidDataMap,BscaCare1stMMTest.fileErrorDataList **
				TestFileUtil.parseFile("\\|",rootLocationOfInputFiles+"\\"+SUCName+"\\"+fileName,ColumnName_parameter1,fileFieldAndDBColumnMappingFilePath,mappingSheetName);
				}
			}
		//	System.out.println("fileValidDataMap:"+fileValidDataMap);
			OtherUtilities.validate(fileValidDataMap,dbValidDataMap,ColumnName_parameter1,softAssertion);//calling validate method to validate fileData map and dbdatamap for valid data
			//System.out.println("fileErrorDataMap:"+fileErrorDataMap);
			//System.out.println("dbErrorDataMap:"+dbErrorDataMap);
			
			OtherUtilities.validateErrorCodes(errorCodesList,fileErrorDataMap,dbErrorDataMap,ColumnName_parameter1,softAssertion);//calling validate method to validate fileErrorData map and dbErrorDataMap for unvalid data
		} catch (Exception e) {
					System.out.println("Test Case Failed due to Exception.....!!");
					//Below assert condition is to fail the test case when exception occured
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here to record all the failed assertions and report 
				}
	}
	
//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		Map map=(Map) callBack.getParameters()[0];
		String testCaseName="Test Case ID:"+map.get("Test Case ID")+",Field:"+map.get("Query parameter1");
		reportInit(testResult.getTestContext().getName(), testResult.getName(),testCaseName);
		
		System.out.println("Test Case ID:"+map.get("Test Case ID")+",Field:"+map.get("Query parameter1"));
		//System.out.println("RUN Parameter:"+callBack.getParameters()[0]);
		//reportInit(testResult.getTestContext().getName(),);  Test Case ID
		softAssert = new SoftAssert();
	//	logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, sheetName);//calling the method to get all column elements in array
		  Object[][] testDataArray= 	  ExcelUtils.getTableArray(filePath, sheetName);//calling this method to get all the data in the data sheet in object array 
		  List<Object> list=new ArrayList<Object>();//list to store the executable rows in the test data sheet
		  int noOfTestCases=0;String runMode="Yes";//declaration and initialization of runMode flag
		  for(int row=0;row<=testDataArray.length-1;row++){//loop through the data in test data sheet
			  //below checking the method name with the keyword name in test data sheet
			  if(method.getName().equalsIgnoreCase(testDataArray[row][2].toString())&& runMode.equalsIgnoreCase(testDataArray[row][11].toString())){
				noOfTestCases++;//icrementing the number when ever the testcase in datasheet having Runmode as Yes and keyword and method name
				Map<String, String> rowDataMap = new HashMap<String, String>();//map to handle row data in datasheet
				for (int col=0;col<=columnArray[0].length-1;col++){//iterate through all columns and rows
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);//adding into list
				//data[row][0]=rowDataMap;
			}
		}
		  
		  Object[][] data = new Object[noOfTestCases][1];//creating object array and populating data
		  for(int row=0;row<list.size();row++){
			  data[row][0]=list.get(row);
		  }
		//data = new Object[][] { { list.get(0) },{ list.get(1) },{ list.get(2) }  };
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		ReportFactory.closeReport();
	}
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles", "FileFieldAndDBColumnMappingFilePath","ResultsDestinationFolderPath"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles,String FileFieldAndDBColumnMappingFilePath,String ResultsDestinationFolderPath){    //Args order matters should match to params order


	//public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName,String FileFieldAndDBColumnMappingFilePath){	//Args order matters should match to params order
		//path of results folder created before executing the test
		 path = Paths.get("target\\Results\\"+timestamp);
		//checking for the existance of path
		 if(!Files.exists(path))
		{
		try {
			Files.createDirectories(path);//creating directory
		} catch (IOException e) {
			e.printStackTrace();//printing teh exception content here
		}
		}
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {//assigning the test sheet name
			NameOfTestDataSheet = "Sheet1";
		}
		filePath=TestDataSheetLocation;//asilgning the testDatasheetlocation from testNG.xml
		sheetName=NameOfTestDataSheet;//asilgning the NameOfTestDataSheet from testNG.xml
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		rootLocationOfInputFiles=RootLocationOfFlatFiles;//asilgning the RootLocationOfFlatFiles from testNG.xml
		fileFieldAndDBColumnMappingFilePath=FileFieldAndDBColumnMappingFilePath;//asilgning the FileFieldAndDBColumnMappingFilePath from testNG.xml
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);//setup Cachemanager
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		//Below step is for setting up the path of the input file

	}
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	@AfterMethod
	public void afterMethod() throws IOException{
		
		inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		File srcDir = new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		
		Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
		fileErrorDataList.clear();
		fileValidDataMap.clear();
		errorCodesList.clear();
		fileErrorDataMap.clear();
	}
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
			try {
	//-----		Path htmlReportSourcePath=Paths.get(resultsSourceFolderPath+"//test-output//emailable-report.html");//storing report source path in htmlReportSourcePath 
	//-----		Path htmlReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\emailable-report.html");//storing report source path in htmlReportDestinationPath
				
			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("test-output\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
	//-----			TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files
			
			
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	  }
	
}
