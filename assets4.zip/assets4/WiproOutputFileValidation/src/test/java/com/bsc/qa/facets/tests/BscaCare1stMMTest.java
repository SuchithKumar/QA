package com.bsc.qa.facets.tests;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.utility.ExcelUtilsExtended;
import com.bsc.qa.facets.ffpojo.utility.XMLParse;
import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable {
	
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	private XMLParse xMLParse = null;
	 
	public BscaCare1stMMTest(String inputFileName) {
		this.inputFileName = inputFileName;
	}
	
	SoftAssert softAssertion = new SoftAssert();//ignore
	public com.bsc.qa.framework.utility.DBUtils objDBUtility;

	//To validate XML fields with database values for ID Cards
private void testdbvalues_welcomekit(String strSubscriberList) throws IOException{
		
	
			BufferedReader bufferedReader = null;
			String line=null;
			System.out.println("$$$$$$ "+strSubscriberList);
			String[] subscriber_list=strSubscriberList.split("\\|");
			System.out.println("---- "+subscriber_list[1]+"------");
			File cinn_file=new File(System.getenv("CIN_COMPLETE_FILE_PATH_WKIT"));//+"\\file3.csv");
			//String testFlatFileCompletePath="//bsc/it/VDI_Home_SAC/rbhima01/Desktop/CINN_FILE/file2.txt";
			FileReader fileReader =  new FileReader(cinn_file);
			bufferedReader = new BufferedReader(fileReader);
			String[] cinn_file_content=null;
			
			// Reading each line in the file 
			reportInit("XmlToDbValidation_Subscriber", "SubscriberID in Welcomekit XML validation");
			logger.log(LogStatus.INFO, "Starting test testXMLToDBValidation_Welcomekit");
			//logger.log(LogStatus.INFO, "cinn file pathcinn file path is "+System.getenv("CIN_COMPLETE_FILE_PATH_IDcards"));
			logger.log(LogStatus.INFO, "cinn file path is "+System.getenv("CIN_COMPLETE_FILE_PATH_WKIT"));
			// \\ainf423s\\QES_Automation\\BSCPHP\\VALIDATIONS\\ID_card_CIN_capture\\CINs.csv" );
			while((line = bufferedReader.readLine())!=null) {
	        	//Checking for the CINN Number
	        	 cinn_file_content=line.split("-");
	        	System.out.println("cinn code is "+cinn_file_content[1]);
	        	String sheetName="Mappingsheet_Welcomekit";
	        	String[][] dbValue=null;
	        	String flag="No";
	        	if(cinn_file_content[1].equalsIgnoreCase("N"))
	        	{
	        		for(int j=1;j<subscriber_list.length;j++){
	        		
	        			if (cinn_file_content[2].equals(subscriber_list[j])){
	        				flag="Yes";
	        				break;
	        			}
	        			}
	        	    		if(flag.equalsIgnoreCase("Yes"))
	        		{
	        			System.out.println("subscriber present "+cinn_file_content[2]);
	        			logger.log(LogStatus.PASS, "Subscriber ID "+cinn_file_content[2]+" is present in Welcomekit XML -------Status:Pass");	
	        		}
	        		else{
	        			
	        					System.out.println("subscriber not present "+cinn_file_content[2]);	
	        			logger.log(LogStatus.FAIL, "Subscriber ID "+cinn_file_content[2]+" is not present in Welcomekit XML -------Status:Fail");
	        			String query = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", sheetName)
		        			.getQueryFromMappingSheet("cdm_error_query", sheetName);
	        			
		        			String SQLQuery = query.replace("UniqueId1", cinn_file_content[2]);
		        			try{
			        			dbValue =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
			        			
			        			System.out.println("***************** "+dbValue[0][0]+"*********** "+dbValue[0][1]);
			        			}
			        			catch(Exception e)
			        			{
			        				System.out.println("query is returning null");
			        			}
	        		
	        				}
	        	}   
	        	if(cinn_file_content[1].equalsIgnoreCase("X")){
	        		String flag1="No";
		        		for(int j=1;j<subscriber_list.length;j++){
		        			//	System.out.println("^^^^^^^^^^^ "+cinn_file_content[2]);
		        			if (cinn_file_content[2].equals(subscriber_list[j])){
		        				flag1="Yes";
		        				break;
		        			}
		        			}
		        	    		if(flag1.equalsIgnoreCase("Yes"))
		        		{
		        			System.out.println("subscriber present "+cinn_file_content[2]);
		        			logger.log(LogStatus.FAIL, "Subscriber ID "+cinn_file_content[2]+" is present in Welcomekit XML -------Fail");	
		        		}
		        		else{
		        			
		        					System.out.println("subscriber not present "+cinn_file_content[2]);	
		        			logger.log(LogStatus.PASS, "Subscriber ID "+cinn_file_content[2]+" is not present in Welcomekit XML -------Status:Pass");
		        		}
	        	}
						
	        }	        if(bufferedReader != null)
	    		bufferedReader.close();
	        BufferedWriter filewriter=new BufferedWriter(new FileWriter(cinn_file,false));
	        filewriter.flush();
	        filewriter.close();

	    	}
	
	@Test()
	private void testXMLToDBValidation_WelcomeKit() {
		System.out.println("&& Inside MMTest-PHP &&&");
		try {
			xMLParse = new XMLParse();
			
			//For fetching test data from test data excel file 
			Map<String, String> data = null;
			try {
				data = getData("testXMLToDBValidation_WelcomeKit");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String xmlTag=data.get("ELEMENT_TAG_NAME").toString().trim();		
			//to retrieve file path from environment variable
			File dirfolder=new File(System.getenv("INPUT_FILE_FULLPATH"));
			/*if (dirfolder.getPath().contains("QES_Automation\\BSCPHP\\VALIDATIONS"))
			{

			File[] xmlfiles=dirfolder.listFiles();
			for(File file:xmlfiles){
				
			*/	//System.out.println("&&&&&&&&&&&&&&& "+file.getPath());
			//	String xmlFilePath =file.getPath();	
		//	String xmlFilePath = inputFileName;
			//For the initial XML setup
				String xmlFilePath =inputFileName;
			xMLParse.xmlSetup(xmlFilePath,objDBUtility);
			String mappingSheetName="Mappingsheet_Welcomekit";
			//To fetch all subscribers from XML, multiple subscriber data will be retrieved with pipe (|) delimiter
			String strSubscriberList = xMLParse.UniqueDetailsExtraction(xmlTag,"subscriber","attribute");
			
			System.out.println("The subscriber id's are "+strSubscriberList);
		//	testdbvalues_welcomekit(strSubscriberList);
			//Verifying valid subscribers details from XML
			if(!strSubscriberList.equalsIgnoreCase("")) {
				
				String [] strSubscriberArray = strSubscriberList.split("\\|");
				//Iterating for all subscribers to validate XML versus Database values
				for(int intICounter = 1; intICounter< strSubscriberArray.length; intICounter++){
			
					//To skip the first report which is initialized in the run method
					if(intICounter > 1 )
					{
						
						//To get the report for each subscriber in the XML
						//Parameters: to display report header in the HTML
						reportInit("XMLToDBValidation_WelcomeKit", " Subscriber ID:" + strSubscriberArray[intICounter]);
						logger.log(LogStatus.INFO, "Starting test testXMLToDBValidation_IDcard");
					}
					
					//To log the XML file path in HTML report
					logger.log(LogStatus.INFO, "XML file path: " + xmlFilePath);
					//To log the subscriber details in HTML report
					logger.log(LogStatus.INFO, "Validating Subscriber ID: " + strSubscriberArray[intICounter]);
					System.out.println("Validating Subscriber ID: " + strSubscriberArray[intICounter]);
					xMLParse.nodeExtraction(xmlTag,mappingSheetName, strSubscriberArray[intICounter],softAssertion);
					
				}
				
			}
			
			//To report the statement when file does not have subscribers
			else {
				logger.log(LogStatus.FAIL, "Please provide valid file name and inputs to fetch subscriber data") ;
			}
			testdbvalues_welcomekit(strSubscriberList);
			
			 } catch (Exception e){
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
		
		}

	/**
	 * //To run test method, this method will initiate the HTML report
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		//To execute test method multiple times
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}

	
	/**
	 * DataProvider for returning the specific test data based on test method
	 * name
	 * 
	 * @param String: Method name
	 * @return
	 */

	private Map<String,String> getData(String method) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		//assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";
		//Fetching data from test data excel file based on method name
		System.out.println("xls path "+xlsPath);
		System.out.println("method path "+method);
		dataMap = ExcelUtils.getTestMethodData(xlsPath, method);
		System.out.println("datamap "+dataMap.keySet());
		return dataMap;
	}
}
