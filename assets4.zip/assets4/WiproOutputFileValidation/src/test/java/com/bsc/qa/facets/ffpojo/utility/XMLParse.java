
package com.bsc.qa.facets.ffpojo.utility;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.testng.asserts.SoftAssert;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.relevantcodes.extentreports.LogStatus;

public class XMLParse extends BaseTest {

	private DocumentBuilder dBuilder;
	private Document doc;

	SoftAssert softAssertion;
	static int index;
	public DBUtils objDBUtility;
	private String strUniqueData = "";
	public String dbValue;

	/**
	 * To set up the xml for Xml Parsing
	 * 
	 * @param xmlPath
	 *            - Path of the xml
	 * @param dbUtils
	 *            - Db object
	 */
	public void xmlSetup(String xmlPath, DBUtils dbUtils) {
		File fXmlFile = new File(xmlPath);// Creating file for the given path

		// creating instance for the DocumentBuilderFactory
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		try {
			// creating instance for the DocumentBuilder
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
			objDBUtility = dbUtils;

		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * To extract attribute values from Xml
	 * 
	 * @param tagName
	 *            - TagName of Attribute
	 * @return
	 */
	public ArrayList<String> attributeValue(String tagName) {

		ArrayList<String> idList = new ArrayList<String>();// List for storing
															// attributes
		// Accessing the the nodes having tagname
		NodeList PagesList = doc.getElementsByTagName(tagName);
		// Looping through the nodeslist
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);

			// checking for the attributes in node
			if (node.hasAttributes()) {
				NamedNodeMap attributesList = node.getAttributes();
				// getting all the attributes in the node
				// looping through the attributes list
				for (int attribute_Number = 0; attribute_Number < attributesList
						.getLength(); attribute_Number++) {
					// getting Attributes in the attributes list
					Attr attr = (Attr) attributesList.item(attribute_Number);

					String attributeValue = attr.getNodeValue();

					idList.add(attributeValue);
				}
			} else {
				System.out.println("The node has no attributes!!!");
			}
		}
		return idList;// retuning the attributes list
	}

	/**
	 * To extract Unique data from XML
	 * 
	 * @param tagName
	 *            : Primary parent tag name
	 * @param strUniqueTagName
	 *            : Unique tag name
	 * @return : To return all unique values with "|" this delimiter
	 * @throws SQLException
	 *             : To throw the SQLException exception
	 * @throws ParseException
	 *             : To throw the ParseException exception
	 */
	public String UniqueDetailsExtraction(String tagName,
			String strUniqueTagName, String nodeType) throws SQLException,
			ParseException {

		// To initialize the variable
		strUniqueData = "";
		// To get the elements using tagName
		NodeList PagesList = doc.getElementsByTagName(tagName);
		// Checking each parent tag sections in the XML using for loop
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);
			index = 0;
			softAssertion = softAssert;
			// To check the node when it is having child elements
			if (hasChildElements((Element) node)) {
				// To extract Unique tag data from XML
				parseChildElementsForUniqueIDs((Element) node, strUniqueTagName, nodeType);
			}
		}
		// Returning unique data with pipe (|) delimiter
		return strUniqueData;
	}

	/**
	 * To extract Unique data from XML
	 * 
	 * @param nNode
	 *            : Parent node to retrieve child nodes along with tag values
	 * @param strUniqueTagName
	 *            : Unique tag name to retrieve corresponding value
	 * @throws SQLException
	 *             : To throw the SQLException exception
	 * @throws ParseException
	 *             : To throw the ParseException exception
	 */
	private void parseChildElementsForUniqueIDs(Element nNode,
			String strUniqueTagName, String nodeType) throws SQLException,
			ParseException {

		String elementName = "";
		String elementvalue = "";
		String attributeName = "";
		String attributeValue = "";
		
		int subscriberIndex =1;

		NodeList children = nNode.getChildNodes();// get child nodes of node
		for (int i = 0; i < children.getLength(); i++) { // loop through all
															// child nodes
			Node node = (Node) children.item(i);
			if (nodeType.equals("node")) {
				if (node.getNodeType() == Node.ELEMENT_NODE) { 
					elementName = node.getNodeName().trim().toString();
					elementvalue = node.getTextContent().trim().toString();
					// Checking unique element name in the XML
					if ((elementName.equalsIgnoreCase(strUniqueTagName))) {
						// Storing Unique data into strUniqueData variable with
						// pipe (|) delimiter
						strUniqueData = strUniqueData + "|" + elementvalue;

					} else if (hasChildElements((Element) node)) {// checking
																	// for the
																	// child
																	// elements
						// calling recursive function to fetch data from child
						parseChildElementsForUniqueIDs((Element) node, strUniqueTagName, nodeType);
					}
				}
			} else if (nodeType.equals("attribute")&&subscriberIndex==1) {

				NamedNodeMap attr = nNode.getAttributes();

				int attrLength = attr.getLength();

				for (int attribute_Number = 0; attribute_Number < attrLength; attribute_Number++) {
					Attr attribute = (Attr) attr.item(attribute_Number);
					attributeName = attribute.getNodeName();
					attributeValue = attribute.getNodeValue();

					if (attributeName.equalsIgnoreCase("id")) {

						strUniqueData = strUniqueData + "|" + attributeValue;
						
						subscriberIndex++;
					}

				}

			}

		}

	}

	// Method to extract elements and attributes and its values
	/**
	 * To extract attribute, Node values from Xml
	 * 
	 * @param tagName
	 *            - The Parent tagName where the extraction of tags will begin
	 * @param mappingSheetName
	 *            - Datasheet Name where queries are available
	 * @param BillId
	 *            - Unique Transaction/claim or subscriber number from xml
	 * @param softAssert
	 *            - assertion object
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void nodeExtraction(String tagName, String mappingSheetName,
			String BillId, SoftAssert softAssert) throws SQLException,
			ParseException {

		NodeList PagesList = doc.getElementsByTagName("*");
		Node pNode = null;
		softAssertion = softAssert;

		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);
			if (node.getNodeName().equalsIgnoreCase(tagName)) {
				pNode = node;
			}

			if (node.hasAttributes()) {
				NamedNodeMap attributesList = node.getAttributes();
				for (int attribute_Number = 0; attribute_Number < attributesList.getLength(); attribute_Number++) {
					Attr attr = (Attr) attributesList.item(attribute_Number);
//					String attributeName = attr.getNodeName();
					String attributeValue = attr.getNodeValue();
					if (attributeValue.equals(BillId)) {
						// To check if the parent node is having child elements
						if (hasChildElements((Element) node)) {

							getElementAtttributes((Element) pNode, mappingSheetName);// To get attributes from
														// Xml
							getChildElements((Element) pNode, mappingSheetName,	BillId); // To get child elements of Xml
						}
					}
				}
			}
		}
	}

	/**
	 * To get attributes from Xml
	 * 
	 * @param node
	 *            - Attribute Node
	 * @param sheetName
	 *            - Datasheet name
	 * @throws SQLException
	 */
	private void getElementAtttributes(Element node, String sheetName)
			throws SQLException {
		if (node.hasAttributes()) {
			NamedNodeMap attributesList = node.getAttributes();
			for (int attribute_Number = 0; attribute_Number < attributesList.getLength(); attribute_Number++) {
//				Attr attr = (Attr) attributesList.item(attribute_Number);
//				String attributeName = attr.getNodeName();

			}
		}

	}

	/**
	 * To get Node values from xml
	 * 
	 * @param node
	 *            - Node
	 * @param sheetName
	 *            - Datasheet Name
	 * @param BillId
	 *            - Unique Id from xml
	 * @throws SQLException
	 */
	private void getValuesOfElement(Element node, String sheetName,String billId) throws SQLException {
		

		
		
		String dbValue = getElementValueFromDB(node.getNodeName().trim().toString(), sheetName, billId, "", "");

		if (dbValue == null) {

			// call validate method for validation of xml value and db value
			validataXmlAndDbValues(node.getNodeName().trim().toString(),node.getTextContent(), "[Blank]", billId, sheetName);
		}
		else if(!dbValue.equalsIgnoreCase("TagNotConsiderForValidation")){
			
			// call validate method for validation of xml value and db value
			validataXmlAndDbValues(node.getNodeName().trim().toString(),node.getTextContent(), dbValue, billId, sheetName);
		}
	}


	/** To get Data from Database
	 * @param elemetName - Tagname for which data needs to be fetched from Db
	 * @param sheetName - Datasheet name
	 * @param BillId - Unique id from Xml
	 * @param node - element Node
	 * @return
	 * @throws SQLException
	 */
	private String getElementValueFromDB(String elemetName, String sheetName,
			String billId, String uniqueID2, String uniqueID3) throws SQLException {
		
		// Fetching query for the respective element name
		String query = new ExcelUtilsExtended(
				"src/test/resources/BscaCare1stMMTest.xlsx", sheetName).getQueryFromMappingSheet(elemetName, sheetName);
		
		if(query == null){
			return "TagNotConsiderForValidation";
		}

		String[][] dbValue = null;
		if (query != null) {// check for the null values of query
			
			String SQLQuery = query.replace("UniqueId1", billId);// replacing
																// subscriber id
			SQLQuery = SQLQuery.replace("UniqueId2", uniqueID2);// replacing
			SQLQuery = SQLQuery.replace("UniqueId3", uniqueID3);// replacing

			dbValue = (String[][]) new DBUtils().getTableArray("facets",SQLQuery);

		}

		// Checking for the null value from database
		if (dbValue == null) {
			return null;
		}
		// Checking for the blank value from database
		else if (dbValue.length == 0) {
			return null;
		}
		// Returning 2D array 0,0 index value
		else {
			return dbValue[0][0];
		}
	}

	
	/** To retrieve child elements from Xml
	 * @param nNode - Parent element node
	 * @param sheetName - datasheet name
	 * @param BillId - Unique id from xml
	 * @throws SQLException
	 */
	private void getChildElements(Element nNode, String sheetName, String BillId)
			throws SQLException {
		NodeList children = nNode.getChildNodes();
		
		for (int i = 0; i < children.getLength(); i++) {
			Node node = (Node) children.item(i);

			if (node.getNodeType() == Node.ELEMENT_NODE) {
				if (hasChildElements((Element) node)) {

					
					getElementAtttributes((Element) node, sheetName);
					getChildElements((Element) node, sheetName, BillId);
				} else {
					getValuesOfElement((Element) node, sheetName, BillId);
				}
			}
		}
	}

	/** To check if the node contains child elements
	 * @param el
	 * @return
	 */
	private boolean hasChildElements(Element el) {
		// get child nodes for the given node
		NodeList children = el.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			// looping through the nodes and checking for element node
			if (children.item(i).getNodeType() == Node.ELEMENT_NODE)// chck for
																	// element
																	// node
				return true;
		}
		return false;
	}

	/**To validate Xml and Db Values
	 * @param elementName  - Xml Tag name
	 * @param xmlValue - Xml value
	 * @param dbValue - Db value
	 * @throws SQLException 
	 */
	public void validataXmlAndDbValues(String elementName, String xmlValue,	String dbValue, String billId, String sheetName) throws SQLException {
		
		String status = "Fail";
		//Normalization logics have been implemented in this switch case
		switch (elementName) {
			case "mbr_svcs_phone_no": 
				//Replacing "-" with ""
				xmlValue = xmlValue.toString().replace("-", "");
				//Adding '1' as a prefix to the existing value
				xmlValue = xmlValue.substring(1, xmlValue.length());
				break;
			//Assigning database value based on the business requirement	
			case "lob_type": 
				if(dbValue != null){
					String [] arrDBValue = dbValue.split("\\|");
					if(arrDBValue[0].equalsIgnoreCase("0016") && arrDBValue[1].equalsIgnoreCase("0170")){
						dbValue = "Medicare";
					}
					else if(arrDBValue[0].equalsIgnoreCase("0017") && arrDBValue[1].equalsIgnoreCase("0230")){
						dbValue = "CMC_SD";
					}
					else if(arrDBValue[0].equalsIgnoreCase("0017") && arrDBValue[1].equalsIgnoreCase("0190")){
						dbValue = "CMC_LA";
					}
					else if(arrDBValue[0].equalsIgnoreCase("0015") && (arrDBValue[1].equalsIgnoreCase("0140") || arrDBValue[1].equalsIgnoreCase("0150")  || arrDBValue[1].equalsIgnoreCase("0160") )){
						dbValue = "MdCal_SD";
					}
					else if(arrDBValue[0].equalsIgnoreCase("0015") && (arrDBValue[1].equalsIgnoreCase("0110") || arrDBValue[1].equalsIgnoreCase("0120")  || arrDBValue[1].equalsIgnoreCase("0130") )){
						dbValue = "MdCal_LA";
					}
				}
				break;
			case "special_handling_code":
				if(dbValue != null){
					String [] arrDBValue = dbValue.split("\\|");
					//Checking first array value as nothing and executing separate query based on the requirement
				//	if(!(arrDBValue[0].trim().equalsIgnoreCase("") || arrDBValue[0].trim().equalsIgnoreCase("EN01"))){
						
						dbValue = getElementValueFromDB("special_handling_code_input1", sheetName, arrDBValue[0].trim(), arrDBValue[1].trim(), arrDBValue[2].trim());
						if(dbValue==null){
							dbValue = "[Blank]";
					}
					
				}
				break;
			case "language_code":
				//Hard coding EN01 when database value as nothing
				if(dbValue.trim().equalsIgnoreCase("")){
					dbValue = "EN01";
				}
				break;	
		}
		
		
		// validation of the xml and db values
		softAssertion.assertEquals(xmlValue.replaceAll("\\s+", "").toUpperCase(), dbValue.replaceAll("\\s+", "").toUpperCase(), "xmlValue:" + xmlValue
						+ "| dbValue:" + dbValue);
		
		if (xmlValue.replaceAll("\\s+", "").equalsIgnoreCase(dbValue.replaceAll("\\s+", ""))) {
			status = "Pass";
			logger.log(LogStatus.PASS, " Element Name: " + elementName
					+ "<br /> xmlValue: " + xmlValue + "<br />dbValue: " + dbValue + "<br /> Status:" + status);

		} else {
			logger.log(LogStatus.FAIL, " Element Name: " + elementName
					+ "<br /> xmlValue: " + xmlValue + "<br />dbValue: " + dbValue + "<br /> Status:" + status);
		}
		// logger for showing the results in extents report html file

		System.out.println("Element Name: " + elementName
				+ "|---------- xmlValue: " + xmlValue + "----------dbValue: " + dbValue);

	}

}
