package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileBody {

	
	
	private String MEDICARE_ID;
	private String LAST_NAME;
	private String SEQ_NUMBER;
	
	private String DOB;
	/**
	 * @return the rECORD_TYPE
	 */
	
	/**
	 * @return the mEDICARE_ID
	 */
	public String getMEDICARE_ID() {
		return MEDICARE_ID;
	}
	/**
	 * @param mEDICARE_ID the mEDICARE_ID to set
	 */
	public void setMEDICARE_ID(String mEDICARE_ID) {
		MEDICARE_ID = mEDICARE_ID;
	}
	/**
	 * @return the lAST_NAME
	 */
	public String getLAST_NAME() {
		return LAST_NAME;
	}
	/**
	 * @param lAST_NAME the lAST_NAME to set
	 */
	public void setLAST_NAME(String lAST_NAME) {
		LAST_NAME = lAST_NAME;
	}
	/**
	 * @return the sEQ_NUMBER
	 */
	public String getSEQ_NUMBER() {
		return SEQ_NUMBER;
	}
	/**
	 * @param sEQ_NUMBER the sEQ_NUMBER to set
	 */
	public void setSEQ_NUMBER(String sEQ_NUMBER) {
		SEQ_NUMBER = sEQ_NUMBER;
	}

	/**
	 * @return the dOB
	 */
	public String getDOB() {
		return DOB;
	}
	/**
	 * @param dOB the dOB to set
	 */
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	
	
}
