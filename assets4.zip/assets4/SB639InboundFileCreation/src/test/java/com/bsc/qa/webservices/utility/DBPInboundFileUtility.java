package com.bsc.qa.webservices.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.bsc.qa.framework.utility.DBUtils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.ASHPInboundFileUtility;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;
import com.relevantcodes.extentreports.LogStatus;

public class DBPInboundFileUtility extends BaseTest{
	
 @SuppressWarnings("static-access")
public static File DBPInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
	 File inboundFile=null;
		DBUtils dbUtils = new DBUtils();
		ExcelUtilsExtended excelUtils;
		InboundFileUtils inboundFileUtils= new InboundFileUtils();
		Date todaysDate = new Date();
		DateFormat dateFormat_Header = new SimpleDateFormat("yyyyMMdd");;
		DateFormat dateFormat_detailRecord;
		String date_Header = dateFormat_Header.format(todaysDate);;
		String currentDate_detailRecord;
		Double totalAccumAmount = 0.00;
		Long totalRecords = 0L;
		String inboundFilePath;
		FileWriter writer;
		BufferedWriter bw;
		String mappingSheet = "src//test//resources//BscaCare1stMMTest.xlsx";
		
		String sbsb_id,mbr_sfx,benifit_year,dateOfService,networkInd,accumulatorType,accumAmount,fieldName="";
		int startPosition,endPosition,defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0,fieldLength=0;
		String DBPHeader="";
		
		
		dateFormat_detailRecord = new SimpleDateFormat("dd-MMM-YYYY");
		 currentDate_detailRecord = dateFormat_detailRecord.format(todaysDate);
		String dateFormat_DBPfileNameFormat = DBP_NAVITUSFileFormatDate();
		inboundFilePath = System.getenv("OUTPUT_FILE_PATH")+"\\UHCSB_ACCUMS_TO_BSCA_"+dateFormat_DBPfileNameFormat+".txt";
		
		inboundFile = new File(inboundFilePath);
		 writer = new FileWriter(inboundFile);
		 bw = new BufferedWriter(writer);
		 

	try{
		excelUtils = new ExcelUtilsExtended(mappingSheet,"DBP_MappingSheet");
		for(int i=1;i<=4;i++)
		{
			 startPosition = Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
			 endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
			 fieldLength = endPosition-startPosition+1;
			String defaultValue = excelUtils.getCellData(i, 3);
			if(!defaultValue.equals(""))
			{
				DBPHeader = DBPHeader+addField(defaultValue,startPosition,endPosition);
				
			}
			else
			{
				if(excelUtils.getCellData(i, fieldNameColumn).equals("FILE_DATE"))
				{
					dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
					date_Header = dateFormat_Header.format(todaysDate);
					DBPHeader = DBPHeader+addField(date_Header,startPosition,endPosition);	
				}
				else
					DBPHeader = DBPHeader+StringUtils.rightPad("", fieldLength, " ");
				
			}
		}
		bw.write(DBPHeader);
		bw.newLine();

		//Write detail record
			
		//retrieve queries from queries sheet
			
						
		 	excelUtils = new ExcelUtilsExtended(mappingSheet,"DBP_Queries");
		 	
		 	Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);

			 excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			
			int rowCount = excelUtils.getRowCount(null);
			
			for(int i=1;i<=rowCount;i++)
			{
				
				sbsb_id=excelUtils.getCellData(i, 0);
				mbr_sfx = excelUtils.getCellData(i, 1);
				benifit_year = excelUtils.getCellData(i, 2);
				dateOfService = excelUtils.getCellData(i, 3);
				networkInd = excelUtils.getCellData(i, 4);
				accumulatorType = excelUtils.getCellData(i, 5);
				accumAmount = excelUtils.getCellData(i, 6);
				
				Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, benifit_year, currentDate_detailRecord);
				
				ResultSet groupID = dbUtils.getResultSet("facets",replacedQueries.get("0"));
				ResultSet gender = dbUtils.getResultSet("facets",replacedQueries.get("1"));
				ResultSet memberLName = dbUtils.getResultSet("facets",replacedQueries.get("2"));
				ResultSet memberFName = dbUtils.getResultSet("facets",replacedQueries.get("3"));
				ResultSet member_MInitial = dbUtils.getResultSet("facets",replacedQueries.get("4"));
				ResultSet memberDOB = dbUtils.getResultSet("facets",replacedQueries.get("5"));
				ResultSet planCode = dbUtils.getResultSet("facets",replacedQueries.get("6"));
				OtherUtilities otherUtilities = new OtherUtilities();
				int resultCount=0;
				String detailRecord="";
			
				
				while(groupID.next() && gender.next() && memberLName.next() && memberFName.next() && member_MInitial.next() && memberDOB.next() && planCode.next())	
				{
					resultCount++;
					for(int j=5;j<=29;j++)
					{
					excelUtils = new ExcelUtilsExtended(mappingSheet,"DBP_MappingSheet");
					startPosition=Integer.parseInt(excelUtils.getCellData(j, startPositionColumn));
					endPosition=Integer.parseInt(excelUtils.getCellData(j, endPositionColumn));
					if(excelUtils.getCellData(j, defaultValueColumn).equals(""))
					{
						fieldName = excelUtils.getCellData(j,fieldNameColumn);
						switch (fieldName){
						case "GROUP_ID":
					 	detailRecord=detailRecord+addField(groupID.getString(1),startPosition,endPosition);
					 	break;
						case "MEMBER_IDENTIFICATION_NUMBER":
						case "SUBSCRIBER_NUMBER":
					 		detailRecord=detailRecord+addField(sbsb_id,startPosition,endPosition);
					 	break;
						case "RELATIONSHIP_CODE":
							 
						 if(mbr_sfx.equals("0")||mbr_sfx.equals("1")||mbr_sfx.equals("2")||mbr_sfx.equals("3")||mbr_sfx.equals("4")||mbr_sfx.equals("5")||mbr_sfx.equals("6")||mbr_sfx.equals("7")||mbr_sfx.equals("8")||mbr_sfx.equals("9"))
						 {
								mbr_sfx = String.format('0'+mbr_sfx);
								detailRecord=detailRecord+addField(mbr_sfx,startPosition,endPosition);
							 }
						 else
						 detailRecord=detailRecord+mbr_sfx;
							 break;
						case "GENDER":
						 detailRecord=detailRecord+addField(gender.getString(1),startPosition,endPosition);
						 break;
						case "MEMBER_LAST_NAME":
						 detailRecord = detailRecord+addField(memberLName.getString(1),startPosition,endPosition);
						 break;
						case "MEMBER_FIRST_NAME":
						 detailRecord = detailRecord+addField(memberFName.getString(1),startPosition,endPosition);
						break;
						case "MEMBER_MIDDLE_INIT":
						 detailRecord = detailRecord+addField(member_MInitial.getString(1),startPosition,endPosition);
						break;
						case "MEMBER_DOB":
						 detailRecord = detailRecord+addField(memberDOB.getString(1),startPosition,endPosition);
						 break;
						case "CLAIM_REFERENCE_NUMBER":
						 detailRecord=detailRecord+addField(otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
						break;
						case "DATE_OF_SERVICE":
						 detailRecord = detailRecord+addField(dateOfService,startPosition,endPosition);
						 break;
						case "INPATIENT_OUTPATIENT":
						 detailRecord = detailRecord+addField("1",startPosition,endPosition);
						 break;
						case "BENEFIT_LEVEL":
						 detailRecord = detailRecord+addField(networkInd,startPosition,endPosition);
						 break;
						case "PLAN_CODE":
						 detailRecord = detailRecord+addField(planCode.getString(1),startPosition,endPosition);
						 break;
						case "BENEFIT_CATEGORY":
						case "POLICY_HOLDER_ID": 
						case "BILLED_AMT":
						case "ALLOWED_AMT": 
						case "NOT_COVERED_AMT":
						case "NET_AMT":
						case "FILLER":
						 detailRecord = detailRecord+addField("",startPosition,endPosition);
						break;
						case "ACCUMULATOR TYPE":
						 detailRecord = detailRecord+addField(accumulatorType,startPosition,endPosition);
						 break;
						case "ACCUMULATOR_AMT":
						 if(accumAmount.contains("."))
							{
								accumAmount=accumAmount.replace(".", "");
								accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
							}
							else if(accumAmount.equals("0"))
							{
								accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
							}
							else
							{
								accumAmount=accumAmount+"00";
								accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
							}
						 detailRecord=detailRecord+accumAmount;
					 break;
						case "BENEFIT_YEAR":
						 detailRecord = detailRecord+addField("",startPosition,endPosition);
						break;
					}
					}
					 else
						 detailRecord = detailRecord+excelUtils.getCellData(j,defaultValueColumn);
		
					}
				bw.write(detailRecord);
				bw.newLine();
				excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
				totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(i, 6));
				totalRecords = totalRecords+1;
				detailRecord="";
				sbsb_id = excelUtils.getCellData(i, 0);
				mbr_sfx = excelUtils.getCellData(i, 1);
				accumAmount = excelUtils.getCellData(i, 6);
			}
				if(resultCount==0)
				{
					
					System.out.println("Mandatory field is missing or incorrect test data for row number: "+i+" in test data sheet"+testDataPath);
					logger.log(LogStatus.INFO, "Incorrect test data or mandatory field is missing for the Subscriber: "+ sbsb_id );
					//System.out.println("fail");
				}
				else
				{
					logger.log(LogStatus.PASS, "Successfully inserted data of subscriber: "+ sbsb_id );
				}
			}
			//write Trailer
			String trailer="";
			for(int i=30;i<=34;i++)
			{
				excelUtils=new ExcelUtilsExtended(mappingSheet,"DBP_mappingSheet");
				startPosition=Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
				if(excelUtils.getCellData(i, defaultValueColumn).equals(""))
				{
					if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_RECORDS"))
					
						trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
					
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_AMOUNT"))
					{
						DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
						String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
						if(totalAccumAmount_trailer.contains("."))
						{
							totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
						}
						trailer=trailer+String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer));		
					}
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("FILLER"))
						trailer=trailer+addField("", startPosition,endPosition);
				}
				else
					trailer=trailer+addField(excelUtils.getCellData(i, defaultValueColumn),startPosition,endPosition);
			}
			bw.write(trailer);
			bw.newLine();
			bw.close();
			writer.close();	
			}
				
			catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return inboundFile;
}


 public static String addField(String value,int startPosition,int endPosition)
 {
 		int fieldLength = endPosition-startPosition+1;
 		String paddedValue = "";
 		if(value.length()<fieldLength)
 		{
			paddedValue = StringUtils.rightPad(value, fieldLength, " ");
			return paddedValue;
 		}
 		else
 			return value;

 }

 public static String DBP_NAVITUSFileFormatDate()
 {
	 Date todaysDate = new Date();
 	DateFormat dateFormat_DBPfileNameConvention1 = new SimpleDateFormat("yyyyMMdd");
 	DateFormat dateFormat_DBPfileNameConvention2 = new SimpleDateFormat("hhmmss");
 	String date_filenameformat1 = dateFormat_DBPfileNameConvention1.format(todaysDate);
 	String date_filenameformat2 = dateFormat_DBPfileNameConvention2.format(todaysDate);
 	String  dateFormat_DBPfileNameFormat = date_filenameformat1+"_"+date_filenameformat2;
 	return dateFormat_DBPfileNameFormat;
 }
 
 public static String generateFiller(int length)
 {
 	String filler = String.format("%-" + length + "s"," ");
 	return filler;
 }
 }
 

