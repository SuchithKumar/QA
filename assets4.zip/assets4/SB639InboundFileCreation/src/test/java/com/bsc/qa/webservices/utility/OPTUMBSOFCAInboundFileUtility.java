package com.bsc.qa.webservices.utility;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import com.bsc.qa.framework.base.BaseTest;



public class OPTUMBSOFCAInboundFileUtility extends BaseTest
{
@SuppressWarnings("static-access")
public File OPTUMBSOFCAInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
	OPTUMInboundFileUtility OPTUMBSOFCA = new OPTUMInboundFileUtility();
	File inboundFile = OPTUMBSOFCA.OPTUMInboundFile(testDataPath);
	return inboundFile;	
	
}
}