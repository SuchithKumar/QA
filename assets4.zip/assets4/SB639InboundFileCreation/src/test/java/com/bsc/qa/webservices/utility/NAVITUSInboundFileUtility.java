package com.bsc.qa.webservices.utility;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import com.bsc.qa.framework.base.BaseTest;



public class NAVITUSInboundFileUtility extends BaseTest
{
@SuppressWarnings("static-access")
public File NAVITUSInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
	ASHPInboundFileUtility NAVITUS = new ASHPInboundFileUtility();
	File inboundFile = NAVITUS.ASHPInboundFile(testDataPath);
	return inboundFile;	
	
}
}