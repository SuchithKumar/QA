package com.bsc.qa.webservices.utility;




import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import au.com.bytecode.opencsv.bean.MappingStrategy;

import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;

import org.apache.commons.lang3.StringUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


public class COLLECTIVEHEALTHInboundFileUtility extends BaseTest{
	/**

	 * @return 
	 * @return 
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws NumberFormatException 
	 */
	@SuppressWarnings({ "static-access" })
	public  File COLLECTIVEHEALTHInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
		File inboundFile=null;
		DBUtils dbUtils = new DBUtils();
		ExcelUtilsExtended excelUtils;
		InboundFileUtils inboundFileutils = new InboundFileUtils();
		Date todaysDate = new Date();
		DateFormat dateFormat_detailRecord,dateFormat_Header;
		String currentDate_detailRecord,date_Header;
		Double totalAccumAmount = 0.00;
		Long totalRecords = 0L;
		String inboundFilePath;
		FileWriter writer;
		BufferedWriter bw;
		
		String mappingSheet = "src//test//resources//BscaCare1stMMTest.xlsx";
		String sbsb_id,mbr_sfx,benifit_year,dateOfService,networkInd,coPay_UserInput,coIns_UserInput,ded_UserInput,fieldName="";
		int startPosition,endPosition,fieldLength;
		dateFormat_detailRecord = new SimpleDateFormat("dd-MMM-YYYY");
		 currentDate_detailRecord = dateFormat_detailRecord.format(todaysDate);
	
		 String date_filenameformat = ASHP_OPTUMFileFormatDate();
		
		excelUtils = new ExcelUtilsExtended(mappingSheet,"COLLECTIVEHEALTH_MappingSheet");
		//create output file
		
	
			inboundFilePath = System.getenv("OUTPUT_FILE_PATH")+"\\CHLTH_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
			inboundFile = new File(inboundFilePath);
	
		//Initialize writer
		 writer = new FileWriter(inboundFile);
		 bw = new BufferedWriter(writer);
		 int rowCount = excelUtils.getRowCount(null);
		 int defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0;
		 String COLLECTIVEHEALTHHEADER = "";
		 try
		 { 
			 //Write header
			 //Retrieve field name values from mapping sheet and place the values in the output file
			for(int i=1;i<=4;i++)
			{
				 startPosition = Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
				 endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
				 fieldLength = endPosition-startPosition+1;
				String defaultValue = excelUtils.getCellData(i, defaultValueColumn);
				if(!defaultValue.equals(""))
				{
					COLLECTIVEHEALTHHEADER = COLLECTIVEHEALTHHEADER+addField(defaultValue,startPosition,endPosition);
					
				}
				else
				{
					if(excelUtils.getCellData(i, fieldNameColumn).equals("FILE_DATE"))
					{
						dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
						date_Header = dateFormat_Header.format(todaysDate);
						COLLECTIVEHEALTHHEADER = COLLECTIVEHEALTHHEADER+addField(date_Header,startPosition,endPosition);
						
					}
					else
						COLLECTIVEHEALTHHEADER = COLLECTIVEHEALTHHEADER+addField("",startPosition,endPosition);
					
				}
			}
			bw.write(COLLECTIVEHEALTHHEADER);
			
			bw.newLine();
			
			//Write detail record
			
			//retrieve queries values from queries sheet
			excelUtils = new ExcelUtilsExtended(mappingSheet,"COLLECTIVEHEALTH_Queries");
			
			Map<String,String> queries = inboundFileutils.fetchQueriesFromQueriesSheet(excelUtils);
					
			 			
			 excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			 
			 //replace the queries with test data present in data sheet
			 int rowcount = excelUtils.getRowCount(null);
			 
			for(int i=1;i<=rowcount;i++)
			{
				sbsb_id=excelUtils.getCellData(i, 0);
				mbr_sfx = excelUtils.getCellData(i, 1);
				benifit_year = excelUtils.getCellData(i, 2);
				dateOfService = excelUtils.getCellData(i, 3);
				networkInd = excelUtils.getCellData(i, 4);
				coPay_UserInput = excelUtils.getCellData(i, 5);
				coIns_UserInput = excelUtils.getCellData(i, 6);
				ded_UserInput = excelUtils.getCellData(i, 7);
				
				Map<String,String> replacedQueries = inboundFileutils.replaceQueries(queries, sbsb_id, mbr_sfx, benifit_year, currentDate_detailRecord);
			
			
				ResultSet groupID = dbUtils.getResultSet("facets", replacedQueries.get("0"));
				ResultSet relationshipCode = dbUtils.getResultSet("facets", replacedQueries.get("1"));
				ResultSet gender = dbUtils.getResultSet("facets", replacedQueries.get("2"));
				ResultSet memberLName = dbUtils.getResultSet("facets", replacedQueries.get("3"));
				ResultSet memberFName = dbUtils.getResultSet("facets", replacedQueries.get("4"));
				ResultSet member_MInitial = dbUtils.getResultSet("facets", replacedQueries.get("5"));
				ResultSet memberDOB = dbUtils.getResultSet("facets", replacedQueries.get("6"));
				ResultSet planCode = dbUtils.getResultSet("facets", replacedQueries.get("7"));
				OtherUtilities otherUtilities = new OtherUtilities();
				String detailRecord="";
				int resultCount=0;
				
				//Place the values in the output file
				while(groupID.next() && relationshipCode.next() && gender.next() && memberLName.next() && memberFName.next() && member_MInitial.next() && memberDOB.next() && planCode.next())
				{
					resultCount++;
					for(int j=5;j<=22;j++)
					{
						
						//retrieve field names, start position and end position from mapping sheet
						excelUtils = new ExcelUtilsExtended(mappingSheet,"COLLECTIVEHEALTH_MappingSheet");
						startPosition=Integer.parseInt(excelUtils.getCellData(j, startPositionColumn));
						endPosition=Integer.parseInt(excelUtils.getCellData(j, endPositionColumn));
						
						if(excelUtils.getCellData(j, defaultValueColumn).equals(""))
						{
							fieldName = excelUtils.getCellData(j, fieldNameColumn);
							switch (fieldName) {
							case "GROUP_ID":
							detailRecord=detailRecord+addField(groupID.getString(1),startPosition,endPosition);
								break;
							case "MEMBER_IDENTIFICATION_NUMBER":
								detailRecord=detailRecord+addField(sbsb_id,startPosition,endPosition);
							break;
							case "MEMBER_SUFFIX":
								if(mbr_sfx.equals("0")||mbr_sfx.equals("1")||mbr_sfx.equals("2")||mbr_sfx.equals("3")||mbr_sfx.equals("4")||mbr_sfx.equals("5")||mbr_sfx.equals("6")||mbr_sfx.equals("7")||mbr_sfx.equals("8")||mbr_sfx.equals("9"))
								 {
										mbr_sfx = String.format('0'+mbr_sfx);
										detailRecord=detailRecord+addField(mbr_sfx,startPosition,endPosition);
									 }
								 else
								 detailRecord=detailRecord+mbr_sfx;
								break;
							case "RELATIONSHIP_CODE":
								 detailRecord=detailRecord+addField(relationshipCode.getString(1),startPosition,endPosition);
								break;
							case "GENDER":
								detailRecord=detailRecord+addField(gender.getString(1),startPosition,endPosition);
							break;
							case "VENDOR_UNIQUE_MEMBER_ID":
							 detailRecord=detailRecord+addField("",startPosition,endPosition);
							break;
							case "MEMBER_LAST_NAME":
							 detailRecord = detailRecord+addField(memberLName.getString(1),startPosition,endPosition);
							 break;
							case "MEMBER_FIRST_NAME":
							 detailRecord = detailRecord+addField(memberFName.getString(1),startPosition,endPosition);
							 break;
							case "MEMBER_MIDDLE_INIT":
							 detailRecord = detailRecord+addField(member_MInitial.getString(1),startPosition,endPosition);
							 break;
							case "MEMBER_DOB":
							 detailRecord = detailRecord+addField(memberDOB.getString(1),startPosition,endPosition);
							 break;
							case "CLAIM_ID":
							 detailRecord = detailRecord+addField(otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
							break;
							case "DATE_OF_SERVICE":
							 detailRecord = detailRecord+addField(dateOfService,startPosition,endPosition);
							break;
							case "IN_OUT_OF_NETWORK_INDICATOR":
							 detailRecord = detailRecord+addField(networkInd,startPosition,endPosition);
							break;
							case "PLAN_CODE":
							 detailRecord = detailRecord+addField(planCode.getString(1),startPosition,endPosition);
							break;
							case "OOP_AMT":
							 if(coPay_UserInput.contains("."))
								{
									coPay_UserInput=coPay_UserInput.replace(".", "");
									coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
								}
								else if(coPay_UserInput.equals("0"))
								{
									coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
								}
								else
								{
									coPay_UserInput=coPay_UserInput+"00";
									coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
								}
							 detailRecord = detailRecord+coPay_UserInput;
							 break;
						 
							case "COINS_AMT":
						 
							 if(coIns_UserInput.contains("."))
								{
								 coIns_UserInput=coIns_UserInput.replace(".", "");
								 coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
								}
								else if(coIns_UserInput.equals("0"))
								{
									coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
								}
								else
								{
									coIns_UserInput=coIns_UserInput+"00";
									coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
								}
							 detailRecord = detailRecord+coIns_UserInput;
						 break;
							case "DED_AMT":
						 
							 if(ded_UserInput.contains("."))
								{
								 ded_UserInput=ded_UserInput.replace(".", "");
								 ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput)); 
								}
								else if(ded_UserInput.equals("0"))
								{
									ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
								}
								else
								{
									ded_UserInput=ded_UserInput+"00";
									ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
								}
							 detailRecord = detailRecord+ded_UserInput;
						 break;
						case "FILLER":
							 detailRecord = detailRecord+addField("",startPosition,endPosition);
						break;
							}
						}
						else
							 detailRecord = detailRecord+excelUtils.getCellData(j,defaultValueColumn);
					}
					//System.out.println(detailRecord);
					bw.write(detailRecord);
					bw.newLine();
					excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
					totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(i, 5))+Double.parseDouble(excelUtils.getCellData(i, 6));
					totalRecords = totalRecords+1;
				detailRecord="";
				sbsb_id = excelUtils.getCellData(i, 0);
				mbr_sfx = excelUtils.getCellData(i, 1);
				coPay_UserInput = excelUtils.getCellData(i, 5);
				ded_UserInput= excelUtils.getCellData(i, 6);
				}	
				if(resultCount==0)
				{
					System.out.println("Mandatory field is missing or incorrect test data for row number: "+i+" in test data sheet"+testDataPath);
					logger.log(LogStatus.INFO, "Incorrect test data or mandatory field is missing for the Subscriber: "+ sbsb_id );
					//System.out.println("fail");
				}
				else
				{
					logger.log(LogStatus.PASS, "Successfully inserted data of subscriber: "+ sbsb_id );
				}	
			}
		
		//Write Trailer
			String trailer="";
			for(int i=23;i<=26;i++){
				excelUtils=new ExcelUtilsExtended(mappingSheet,"COLLECTIVEHEALTH_mappingSheet");
				startPosition=Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
				if(excelUtils.getCellData(i, defaultValueColumn).equals(""))
				{
					if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_RECORDS"))
					
						trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
					
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_AMOUNT"))
					{
						DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
						String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
						if(totalAccumAmount_trailer.contains("."))
						{
							totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
						}
						trailer=trailer+String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer));		
					}
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("FILLER"))
						trailer=trailer+addField("", startPosition,endPosition);
				}
				else
					trailer=trailer+addField(excelUtils.getCellData(i, defaultValueColumn),startPosition,endPosition);
					
			}
			bw.write(trailer);
			
			bw.close();
			writer.close();
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
			return inboundFile;

}

	/**
	 * addField method returns the string as per the prescribed length, if string length is lesser then the prescribed length the string is left right padded with spaces
	 *@Param: Value of the string
	 *@param: startPosition of the string
	 * @param: endPosition of the string
	 */
	  public String addField(String value,int startPosition,int endPosition)
	  {
	  		int fieldLength = endPosition-startPosition+1;
	  		String paddedValue = "";
	  		if(value.length()<fieldLength)
	  		{
	 			paddedValue = StringUtils.rightPad(value, fieldLength, " ");
	 			return paddedValue;
	  		}
	  		else
	  			return value;

	  }
	  
	  /**
		 * ASHP_OPTUMFileFormatDate method returns predefined date format of ASHP vendor
		 *
		 *
		 */
	 
	public static String ASHP_OPTUMFileFormatDate()
	{
		Date todaysDate = new Date();
		DateFormat dateFormat_ASHPfileNameConvention = new SimpleDateFormat("yyyyMMddhhmmss");
		String date_filenameformat = dateFormat_ASHPfileNameConvention.format(todaysDate);
		return date_filenameformat;
	}
					



}


