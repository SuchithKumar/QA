package com.bsc.qa.webservices.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import oracle.net.ns.NetOutputStream;

import org.apache.commons.lang3.StringUtils;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.relevantcodes.extentreports.LogStatus;

public class OPTUMInboundFileUtility extends BaseTest
{

@SuppressWarnings("static-access")
public File OPTUMInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
	File inboundFile=null;
	DBUtils dbUtils = new DBUtils();
	InboundFileUtils inboundFileUtils = new InboundFileUtils();
	OtherUtilities otherUtilities = new OtherUtilities();
	ExcelUtilsExtended excelUtils;
	Date todaysDate = new Date();
	DateFormat dateFormat_detailRecord,dateFormat_Header;
	String currentDate_detailRecord,date_Header;
	Double totalAccumAmount = 0.00;
	Long totalRecords = 0L;
	String inboundFilePath;
	FileWriter writer;
	BufferedWriter bw;

	String mappingSheet = "src//test//resources//BscaCare1stMMTest.xlsx";
	String sbsb_id,mbr_sfx,benifit_year,dateOfService,networkInd,accumulatorType,accumAmount,fieldName="";
	int startPosition,endPosition,fieldLength;
	
	String date_filenameformat = OtherUtilities.ASHP_OPTUMFileFormatDate();
	
	excelUtils = new ExcelUtilsExtended(mappingSheet,"OPTUM_mappingSheet");
	//create output file
	if(testDataPath.contains("OPTUMBSOFCA") || testDataPath.contains("OPTUM_BSOFCA")){
	inboundFilePath = System.getenv("OUTPUT_FILE_PATH")+"\\OPTUM_ACCUMS_TO_BSOFCA_V3_"+date_filenameformat+".txt";
	inboundFile = new File(inboundFilePath);
	}
	else
	{
		inboundFilePath = System.getenv("OUTPUT_FILE_PATH")+"\\OPTUM_ACCUMS_TO_BSOFCA_V2_"+date_filenameformat+".txt";
		inboundFile = new File(inboundFilePath);
		}
	
		
	//Initialize writer
	 writer = new FileWriter(inboundFile);
	 bw = new BufferedWriter(writer);
	 int rowCount = excelUtils.getRowCount(null);
	 int defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0;
	 String OPTUMHeader = "";
	 
	//Write header
	 //Retrieve field name values from mapping sheet and place the values in the output file
	for(int i=1;i<=6;i++)
	{
		 startPosition = Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
		 endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
		 fieldLength = endPosition-startPosition+1;
		String defaultValue = excelUtils.getCellData(i, 3);
		if(!defaultValue.equals(""))
		{
			OPTUMHeader = OPTUMHeader+otherUtilities.addField(defaultValue,startPosition,endPosition);
			
		}
		else
		{
			if(excelUtils.getCellData(i, fieldNameColumn).equals("File Date"))
			{
				dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
				date_Header = dateFormat_Header.format(todaysDate);
				OPTUMHeader = OPTUMHeader+otherUtilities.addField(date_Header,startPosition,endPosition);
				
			}
			else if(excelUtils.getCellData(i, fieldNameColumn).equals("Sequence Number"))
				OPTUMHeader = OPTUMHeader+StringUtils.rightPad("0", fieldLength, " ");
			else
				OPTUMHeader = OPTUMHeader+StringUtils.rightPad("", fieldLength, " ");
		}
	}
	bw.write(OPTUMHeader);
	bw.newLine();
	
	//Write detail record
	
	//retrieve queries from queries sheet
	
			excelUtils = new ExcelUtilsExtended(mappingSheet,"OPTUM_Queries");
			
			 Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
			 			
			 excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			 
			 rowCount = excelUtils.getRowCount(null);
			 String detailRecord="";
			
			for(int i=1;i<=rowCount;i++)
			{
				excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
				sbsb_id=excelUtils.getCellData(i, 0);
				mbr_sfx = excelUtils.getCellData(i, 1);
				benifit_year = excelUtils.getCellData(i, 2);
				dateOfService = excelUtils.getCellData(i, 3);
				networkInd = excelUtils.getCellData(i, 4);
				accumulatorType = excelUtils.getCellData(i, 5);
				accumAmount = excelUtils.getCellData(i, 6);
				//String claimType = excelUtils_testDataSheet.getCellData(i, 7);
				
				Map<String,String>	replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, "", "");
				
				Map<String,String> memberNumber = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("0"));
				
				Map<String,String> member_FirstName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("2"));

				Map<String,String> member_LastName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("1"));
				
				Map<String,String> member_MiddleInitial = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("3"));;
				
				Map<String,String> member_DOB = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("4"));
				
				if(memberNumber.size()==0 || member_FirstName.size()==0 || member_FirstName.size()==0 || member_LastName.size()==0 || member_DOB.size()==0)
				{
					System.out.println("Mandatory field is missing or incorrect test data for row number: "+i+" in test data sheet"+testDataPath);
					logger.log(LogStatus.INFO, "Incorrect test data or mandatory field is missing for the Subscriber: "+ sbsb_id );
					//System.out.println("fail");
				}
				else{
				excelUtils = new ExcelUtilsExtended(mappingSheet, "OPTUM_MappingSheet");
				
				for(int j=7;j<=24;j++)
				{
					startPosition = Integer.parseInt(excelUtils.getCellData(j,startPositionColumn));
					endPosition = Integer.parseInt(excelUtils.getCellData(j,endPositionColumn));
					if(excelUtils.getCellData(j, defaultValueColumn).equals(""))
					{		
						fieldName = excelUtils.getCellData(j, fieldNameColumn);
						switch (fieldName){
						case "Member Number":
							detailRecord = detailRecord+otherUtilities.addField(memberNumber.get("MEME_SSN"),startPosition,endPosition);
						break;
						case "Member First Name":
							detailRecord = detailRecord+otherUtilities.addField(member_FirstName.get("MEME_FIRST_NAME"),startPosition,endPosition);
						break;
						case "Member Last Name":
							detailRecord = detailRecord+otherUtilities.addField(member_LastName.get("MEME_LAST_NAME"),startPosition,endPosition);
						break;
						case "Member Middle Initial":
							detailRecord = detailRecord+otherUtilities.addField(member_MiddleInitial.get("MEME_MID_INIT"),startPosition,endPosition);
						break;
						case "Member DOB":
							detailRecord = detailRecord+otherUtilities.addField(member_DOB.get("DOB"),startPosition,endPosition);
						break;
						case "Date of Service":
							detailRecord = detailRecord+otherUtilities.addField(dateOfService,startPosition,endPosition);
						break;
						case "Benefit Level":
							detailRecord = detailRecord+otherUtilities.addField(networkInd,startPosition,endPosition);
						break;
						case "Accumulator Type":
							detailRecord = detailRecord+otherUtilities.addField(accumulatorType,startPosition,endPosition);
						break;
						case "Claim ID":
							detailRecord = detailRecord+otherUtilities.addField(otherUtilities.generateRandomNumber(15).toString(),startPosition,endPosition);
						break;
						case "Adjustment Indicator":
							detailRecord = detailRecord+otherUtilities.addField("",startPosition,endPosition);
						break;
						case "Level of Care":
							detailRecord = detailRecord+otherUtilities.addField("0",startPosition,endPosition);
						break;
						case "Multi-Customer ID":
						case "Dependent Indicator":
						case "Filler":
							detailRecord = detailRecord+otherUtilities.addField("",startPosition,endPosition);
						break;
						case "Amount":
							if(accumAmount.contains("."))
							{
								accumAmount=accumAmount.replace(".", "");
								accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
							}
							else if(accumAmount.equals("0"))
							{
								accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
							}
							else
							{
								accumAmount=accumAmount+"00";
								accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
							}
							detailRecord=detailRecord+accumAmount;
						break;
					}
				}
				else
						detailRecord = detailRecord+otherUtilities.addField(excelUtils.getCellData(j,defaultValueColumn),startPosition,endPosition);
			}
				bw.write(detailRecord);
				bw.newLine();
				excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
				totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(i, 6));
				totalRecords = totalRecords+1;
			detailRecord="";
			sbsb_id = excelUtils.getCellData(i, 0);
			mbr_sfx = excelUtils.getCellData(i, 1);
			accumAmount = excelUtils.getCellData(i, 6);
			logger.log(LogStatus.PASS, "Successfully inserted data of subscriber: "+ sbsb_id );
				}				
}
			
			//write Trailer
			String trailer="";
			totalRecords = totalRecords+2;
			excelUtils = new ExcelUtilsExtended(mappingSheet, "OPTUM_MappingSheet");
			for(int i=25;i<=28;i++)
			{
				startPosition = Integer.parseInt(excelUtils.getCellData(i,startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(i,endPositionColumn));
				
				if(excelUtils.getCellData(i, defaultValueColumn).equals(""))
				{	
					if(excelUtils.getCellData(i, fieldNameColumn).equals("Total Records"))
						trailer=trailer+otherUtilities.addField(String.format("%0"+(endPosition-startPosition+1)+"d",totalRecords), startPosition, endPosition);
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("Total Amount"))
					{
						DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
						String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
						
						if(totalAccumAmount_trailer.contains("."))
						{
							totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
						}
						trailer=trailer+otherUtilities.addField(String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer)),startPositionColumn, endPositionColumn);
					}
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("Filler"))
						trailer=trailer+otherUtilities.addField("",startPosition, endPosition);
				}
				else
					trailer=trailer+otherUtilities.addField(excelUtils.getCellData(i, defaultValueColumn), startPosition, endPosition);
			}
			bw.write(trailer);
			bw.close();
			writer.close();
		return inboundFile;
}
}			
	

						
		
			


		

