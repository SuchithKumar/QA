package com.bsc.qa.webservices.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.util.*;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import java.util.List;
import java.util.Map;

import au.com.bytecode.opencsv.bean.MappingStrategy;

import com.bsc.qa.framework.utility.DBUtils;

import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;

import org.apache.commons.lang3.StringUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


public class MEDIMPACTInboundFileUtility extends BaseTest{
	
	@SuppressWarnings({ "static-access" })
	public  File MEDIMPACTInboundFile(String testDataPath) throws IOException{
		ExcelUtilsExtended excelUtils;
		InboundFileUtils fileUtils = new InboundFileUtils();
		File inboundFile=null;
		DBUtils dbUtils = new DBUtils();
		Date todaysDate = new Date();
		DateFormat dateFormat_detailRecord,dateFormat_Header;
		String currentDate_detailRecord,date_Header;
		Double totalAccumAmount = 0.00;
		Long totalRecords = 0L;
		String inboundFilePath;
		FileWriter writer = null;
		BufferedWriter bw;
		String sbsb_id = null,mbr_sfx = null,benifit_year = null,dateOfService,networkInd,OOP_UserInput,ded_UserInput;
		int startPosition,endPosition;
		int defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0,resultCount=0;;
		dateFormat_detailRecord = new SimpleDateFormat("dd-MMM-YYYY");
		currentDate_detailRecord = dateFormat_detailRecord.format(todaysDate);
		String MEDIMPACTHeader = "", detailRecord="",trailer="",fieldName="";
		String date_filenameformat = ASHP_OPTUMFileFormatDate();
	
		//create output file
		InboundFileUtils inboundFileUtils = new InboundFileUtils();
		inboundFilePath = System.getenv("OUTPUT_FILE_PATH")+"\\MEDIMPACT_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
		inboundFile = new File(inboundFilePath);
		
		//Retrieve mapping sheet from resources folder
		String mappingSheetPath = "src//test//resources//BscaCare1stMMTest.xlsx";
		
		//Initialize writer
		 try {
			writer = new FileWriter(inboundFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		bw = new BufferedWriter(writer);
		 
		 
		 try{
		 
			 //Write header
			 //Retrieve field name values from mapping sheet and place the values in the output file
			 excelUtils = new ExcelUtilsExtended(mappingSheetPath,"MEDIMPACT_MappingSheet");
			for(int i=1;i<=8;i++)
			{
				 startPosition = Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
				 endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
				 
				String defaultValue = excelUtils.getCellData(i, 3);
				if(!defaultValue.equals(""))
					MEDIMPACTHeader = MEDIMPACTHeader+fileUtils.addField(defaultValue,startPosition,endPosition);
				else
				{
					fieldName = excelUtils.getCellData(i, fieldNameColumn);
					switch (fieldName) {
					case "TRANSACTION_SET_CONTROL_NUMBER": case "DATE":
						dateFormat_Header = new SimpleDateFormat("YYYYMMDD");
						date_Header = dateFormat_Header.format(todaysDate);
						MEDIMPACTHeader = MEDIMPACTHeader+fileUtils.addField(date_Header,startPosition,endPosition);
					break;
					case "TIME":
						DateFormat timeFormat = new SimpleDateFormat("hhmmss");
						 String time = timeFormat.format(todaysDate);
						 MEDIMPACTHeader = MEDIMPACTHeader+OtherUtilities.addField(time, startPosition, endPosition);
						 break;
					default:
						MEDIMPACTHeader = MEDIMPACTHeader+fileUtils.addField("",startPosition,endPosition);
						break;
					}
				}
			}

		bw.write(MEDIMPACTHeader);
		bw.newLine();
		//Write detail record
			
		//retrieve queries from queries sheet and replace with test data
			
			excelUtils =new ExcelUtilsExtended(mappingSheetPath, "MEDIMPACT_Queries");
			
			Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
			
			excelUtils =new ExcelUtilsExtended(testDataPath, "TestData");
			int rowCount = excelUtils.getRowCount(null);
		
			for(int i=1;i<=rowCount;i++)
			{
				sbsb_id = excelUtils.getCellData(i, 0);
				mbr_sfx = excelUtils.getCellData(i, 1);
				benifit_year = excelUtils.getCellData(i, 2);
				dateOfService = excelUtils.getCellData(i, 3);
				networkInd = excelUtils.getCellData(i, 4);
				OOP_UserInput = excelUtils.getCellData(i, 5);
				ded_UserInput = excelUtils.getCellData(i, 6);
				
				Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx,benifit_year,currentDate_detailRecord);
				
				ResultSet classID = dbUtils.getResultSet("facets", replacedQueries.get("0"));
				ResultSet relationshipCode = dbUtils.getResultSet("facets", replacedQueries.get("1"));
				ResultSet gender = dbUtils.getResultSet("facets", replacedQueries.get("2"));
				ResultSet memberLName = dbUtils.getResultSet("facets", replacedQueries.get("3"));
				ResultSet memberFName = dbUtils.getResultSet("facets", replacedQueries.get("4"));
				ResultSet member_MInitial = dbUtils.getResultSet("facets", replacedQueries.get("5"));
				ResultSet memberDOB = dbUtils.getResultSet("facets", replacedQueries.get("6"));
				ResultSet planCode = dbUtils.getResultSet("facets", replacedQueries.get("7"));
				
				//Place the values in the output file
				
				while(classID.next() && relationshipCode.next() && gender.next() && memberLName.next() && memberFName.next() && member_MInitial.next() && memberDOB.next() && planCode.next())
				{
					resultCount++;
					for(int j=9;j<=25;j++)
					{
						//retrieve field names, start position and end position from mapping sheet
						excelUtils = new ExcelUtilsExtended(mappingSheetPath,"MEDIMPACT_MappingSheet");
						startPosition=Integer.parseInt(excelUtils.getCellData(j, startPositionColumn));
						endPosition=Integer.parseInt(excelUtils.getCellData(j, endPositionColumn));
						
						if(excelUtils.getCellData(j, defaultValueColumn).equals(""))
						{
							fieldName = excelUtils.getCellData(j,fieldNameColumn);
							switch (fieldName) {
							case "CLASS_ID":
								detailRecord=detailRecord+fileUtils.addField(classID.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_IDENTIFICATION_NUMBER":
								detailRecord=detailRecord+fileUtils.addField(sbsb_id,startPosition,endPosition);
							break;
							case "MEMBER_SUFFIX":
								 if(mbr_sfx.equals("0")||mbr_sfx.equals("1")||mbr_sfx.equals("2")||mbr_sfx.equals("3")||mbr_sfx.equals("4")||mbr_sfx.equals("5")||mbr_sfx.equals("6")||mbr_sfx.equals("7")||mbr_sfx.equals("8")||mbr_sfx.equals("9"))
								 {
										mbr_sfx = String.format('0'+mbr_sfx);
										detailRecord=detailRecord+fileUtils.addField(mbr_sfx,startPosition,endPosition);
									 }
								 else
								 detailRecord=detailRecord+mbr_sfx;
							break;
							case "RELATIONSHIP_CODE":
								detailRecord=detailRecord+fileUtils.addField(relationshipCode.getString(1),startPosition,endPosition);
							break;
							case "GENDER":
								detailRecord=detailRecord+fileUtils.addField(gender.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_LAST_NAME":
								detailRecord = detailRecord+fileUtils.addField(memberLName.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_FIRST_NAME":
								detailRecord = detailRecord+fileUtils.addField(memberFName.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_MIDDLE_INIT":
								detailRecord = detailRecord+fileUtils.addField(member_MInitial.getString(1),startPosition,endPosition);
							break;
							case "MEMBER_DOB":
								detailRecord = detailRecord+fileUtils.addField(memberDOB.getString(1),startPosition,endPosition);
							break;
							case "CLAIM_ID":
								detailRecord = detailRecord+fileUtils.addField("",startPosition,endPosition);
							break;
							case "DATE_OF_SERVICE":
								detailRecord = detailRecord+fileUtils.addField(dateOfService,startPosition,endPosition);
							break;
							case "PLAN_CODE":
								detailRecord = detailRecord+fileUtils.addField(planCode.getString(1),startPosition,endPosition);
							break;
							case "OOP_AMT":
								if(OOP_UserInput.contains("."))
								{
								 OOP_UserInput=OOP_UserInput.replace(".", "");
								 OOP_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(OOP_UserInput));	
								}
								else if(OOP_UserInput.equals("0"))
								{
									OOP_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(OOP_UserInput));
									
								}
								else
								{
									OOP_UserInput=OOP_UserInput+"00";
									OOP_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(OOP_UserInput));
									
								}
							 detailRecord = detailRecord+OOP_UserInput;
							 break;
							case "DED_AMT":
								if(ded_UserInput.contains("."))
								{
								 ded_UserInput=ded_UserInput.replace(".", "");
								 ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput)); 
								}
								else if(ded_UserInput.equals("0"))
								{
									ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
								}
								else
								{
									ded_UserInput=ded_UserInput+"00";
									ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
								}
							 detailRecord = detailRecord+ded_UserInput;
							break;
							case "TRANSMITTAL_NUMBER":
								detailRecord = detailRecord+fileUtils.addField(networkInd,startPosition,endPosition);
							break;
							default:
								detailRecord = detailRecord+fileUtils.addField("",startPosition,endPosition);
								break;
							}
							} 
					}
					//write the detail record of the subscriber to the output file
					bw.write(detailRecord);
					bw.newLine();
					excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
					totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(i, 5))+Double.parseDouble(excelUtils.getCellData(i, 6));
					totalRecords = totalRecords+1;
					detailRecord="";
					sbsb_id = excelUtils.getCellData(i, 0);
					mbr_sfx = excelUtils.getCellData(i, 1);
					OOP_UserInput = excelUtils.getCellData(i, 5);
					//coIns_UserInput = excelUtils.getCellData(i, 6);
					ded_UserInput= excelUtils.getCellData(i, 6);
				}	
				if(resultCount==0)
				{
					System.out.println("Mandatory field is missing or incorrect test data for row number: "+i+" in test data sheet"+testDataPath);
					logger.log(LogStatus.INFO, "Incorrect test data or mandatory field is missing for the Subscriber: "+ sbsb_id );
					//System.out.println("fail");
				}
				else
				{
					logger.log(LogStatus.PASS, "Successfully inserted data of subscriber: "+ sbsb_id );
				}
			}
	
	
		//Write Trailer
			totalRecords = totalRecords+2;
		
			for(int i=26;i<=28;i++){
				excelUtils = new ExcelUtilsExtended(mappingSheetPath,"MEDIMPACT_MappingSheet");
				startPosition=Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
				if(excelUtils.getCellData(i, defaultValueColumn).equals(""))
				{
					if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_RECORDS"))
					{
						trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
					}
					else if(excelUtils.getCellData(i, fieldNameColumn).equals("PAID_AMOUNT"))
					{
						DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
						String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
						if(totalAccumAmount_trailer.contains("."))
						{
							totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
							totalAccumAmount_trailer = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer)); 
						}
						else if(totalAccumAmount_trailer.equals("0"))
						{
							totalAccumAmount_trailer = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer));
						}
						else
						{
							totalAccumAmount_trailer=totalAccumAmount_trailer+"00";
							totalAccumAmount_trailer = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer));
						}
						trailer = trailer+totalAccumAmount_trailer;
					}
				else
				{
					dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
					trailer=trailer+fileUtils.addField(dateFormat_Header.format(todaysDate),startPosition,endPosition);
				}
				}			
			}
			bw.write(trailer);	
			bw.close();
			writer.close();
			}

		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }	
			
	return inboundFile;
}


	
	  /**
		 * ASHP_OPTUMFileFormatDate method returns predefined date format of ASHP vendor
		 *
		 *
		 */ 
	public static String ASHP_OPTUMFileFormatDate()
	{
		Date todaysDate = new Date();
		DateFormat dateFormat_ASHPfileNameConvention = new SimpleDateFormat("yyyyMMddhhmmss");
		String date_filenameformat = dateFormat_ASHPfileNameConvention.format(todaysDate);
		return date_filenameformat;
	}
	
}


