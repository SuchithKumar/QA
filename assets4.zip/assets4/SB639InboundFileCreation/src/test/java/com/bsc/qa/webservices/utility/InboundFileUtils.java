package com.bsc.qa.webservices.utility;




import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import au.com.bytecode.opencsv.bean.MappingStrategy;

import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;

import org.apache.commons.lang3.StringUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


public class InboundFileUtils {
	
	
	@SuppressWarnings("static-access")
	public Map<String,String> fetchQueriesFromQueriesSheet(ExcelUtilsExtended queriesSheet)
	{
		Map<String, String> table = null;
		
		int rowCount = queriesSheet.getRowCount(null);
		table = new HashMap<String, String>();
		try
		{
		for(int i=0;i<=rowCount;i++)
		{
			String key = String.valueOf(i);
			String value = queriesSheet.getCellData(i, 0);
			if(value!="")
				table.put(key,value);
			else
				throw new Exception("No query found");
		}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		
		
	}
		return table;
	}
	
	public Map<String,String> replaceQueries(Map<String,String> queries,String value1,String value2,String value3,String value4)
	{
		Map<String, String> table = null;
		int count=queries.size();
		table = new HashMap<String, String>();
		for(int i=0;i<count;i++)
		{
			String key = String.valueOf(i);
			String value ="";
			if(queries.get(String.valueOf(i)).contains("SBSB_ID") && queries.get(String.valueOf(i)).contains("MBR_SFX") && queries.get(String.valueOf(i)).contains("YYYY") && queries.get(String.valueOf(i)).contains("sysdate"))
			{
			 value = queries.get(String.valueOf(i)).replaceAll("SBSB_ID", value1).replaceAll("MBR_SFX", value2).replaceAll("YYYY", value3).replaceAll("sysdate", value4);
			 if(value!="")
				 table.put(key,value);
			else
				try {
					throw new Exception("No query found");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(queries.get(String.valueOf(i)).contains("SBSB_ID") && queries.get(String.valueOf(i)).contains("MBR_SFX"))
			{
			 value = queries.get(String.valueOf(i)).replaceAll("SBSB_ID", value1).replaceAll("MBR_SFX", value2);
			 if(value!="")
				 table.put(key,value);
			else
				try {
					throw new Exception("No query found");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			else if(queries.get(String.valueOf(i)).contains("SBSB_ID"))
			{
				 value = queries.get(String.valueOf(i)).replaceAll("SBSB_ID", value1);
				 if(value!="")
					 table.put(key,value);
				else
					try {
						throw new Exception("No query found");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else if(queries.get(String.valueOf(i)).contains("MBR_SFX"))
			{
				 value = queries.get(String.valueOf(i)).replaceAll("MBR_SFX", value2);
				 if(value!="")
					 table.put(key,value);
				else
					try {
						throw new Exception("No query found");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
		}
		return table;
	}
	
	public Map<String,String> fetchTestData(ExcelUtilsExtended testDataSheet)
	{
		Map<String, String> table = null;
		
		int rowCount = testDataSheet.getRowCount(null);
		table = new HashMap<String, String>();
		try
		{
		for(int i=1;i<=rowCount;i++)
		{
			String key = String.valueOf(i);
			String value = testDataSheet.getCellData(i, 0);
			if(value!="")
				table.put(key,value);
			else
				throw new Exception("No query found");
		}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
	}
		return table;
	}
	
	/**
	 * addField method returns the string as per the prescribed length, if string length is lesser then the prescribed length the string is left right padded with spaces
	 *@Param: Value of the string
	 *@param: startPosition of the string
	 * @param: endPosition of the string
	 */
	  public String addField(String value,int startPosition,int endPosition)
	  {
	  		int fieldLength = endPosition-startPosition+1;
	  		String paddedValue = "";
	  		if(value.length()<fieldLength)
	  		{
	 			paddedValue = StringUtils.rightPad(value, fieldLength, " ");
	 			return paddedValue;
	  		}
	  		else
	  			return value;

	  }
	  
}
