package com.bsc.qa.webservices.utility;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;










import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import com.bsc.qa.webservices.utility.DBPInboundFileUtility;

import org.apache.commons.lang3.StringUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.jna.platform.win32.OaIdl.MEMBERID;


public class CVSInboundFileUtility extends BaseTest{
	/**

	 * @return 
	 * @return 
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws NumberFormatException 
	 */
	@SuppressWarnings({ "static-access" })
	public  File CVSInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
		File inboundFile=null;
		DBUtils dbUtils = new DBUtils();
		InboundFileUtils inboundFileUtils = new InboundFileUtils();
		ExcelUtilsExtended excelUtils;
		Date todaysDate = new Date();
		DateFormat dateFormat_Header = new SimpleDateFormat("yyyyMMdd");;
		DateFormat dateFormat_detailRecord;
		String date_Header = dateFormat_Header.format(todaysDate);;
		String currentDate_detailRecord;
		 Double totalAccumAmount = 0.00;
		 Long totalRecords = 0L;
		String inboundFilePath;
		FileWriter writer;
		BufferedWriter bw;
		
		String mappingSheet = "src//test//resources//BscaCare1stMMTest.xlsx";
		String sbsb_id,mbr_sfx,benifit_year,dateOfService,coPay_UserInput,coIns_UserInput,ded_UserInput,fieldName="";
		 int defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0,startPosition,endPosition,fieldLength;
		 dateFormat_detailRecord = new SimpleDateFormat("dd-MMM-YYYY");
		 currentDate_detailRecord = dateFormat_detailRecord.format(todaysDate);
		 DBPInboundFileUtility DBPUtil = new DBPInboundFileUtility();
		 String date_filenameformat = DBPUtil.DBP_NAVITUSFileFormatDate();
		
		
		 inboundFilePath = System.getenv("OUTPUT_FILE_PATH")+"\\CVS_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
		inboundFile = new File(inboundFilePath);
		 writer = new FileWriter(inboundFile);
		 bw = new BufferedWriter(writer);
		 String CVSHeader="";	
				try{
					excelUtils = new ExcelUtilsExtended(mappingSheet, "CVS_MappingSheet");
					for(int i=1;i<=6;i++)
					{
						 startPosition = Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
						 endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
						 fieldLength = endPosition-startPosition+1;
						String defaultValue = excelUtils.getCellData(i,defaultValueColumn);
						if(!defaultValue.equals(""))
						{
							CVSHeader = CVSHeader+inboundFileUtils.addField(defaultValue,startPosition,endPosition);
							
						}
						else
						{
							if(excelUtils.getCellData(i, fieldNameColumn).equals("RUN_DATE") || excelUtils.getCellData(i, fieldNameColumn).equals("CYCLE_START_DATE") || excelUtils.getCellData(i, fieldNameColumn).equals("CYCLE_END_DATE"))
							{
								dateFormat_Header = new SimpleDateFormat("ddMMYYYY");
								date_Header = dateFormat_Header.format(todaysDate);
								CVSHeader = CVSHeader+inboundFileUtils.addField(date_Header,startPosition,endPosition);
								
							}
							else
								CVSHeader = CVSHeader+StringUtils.rightPad("", fieldLength, " ");
							
						}
					}	
					bw.write(CVSHeader);
					bw.newLine();
					//Write detail record
					
					//retrieve queries from queries sheet
					String detailRecord="";
					
					excelUtils = new ExcelUtilsExtended(mappingSheet,"CVS_Queries");
					
					Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
							 
					excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
					
					int rowCount = excelUtils.getRowCount(null);
					
					for(int i=1;i<=rowCount;i++)
					{
						excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
						sbsb_id=excelUtils.getCellData(i, 0);
						mbr_sfx = excelUtils.getCellData(i, 1);
						benifit_year = excelUtils.getCellData(i, 2);
						dateOfService = excelUtils.getCellData(i, 3);
						coPay_UserInput = excelUtils.getCellData(i, 4);
						coIns_UserInput = excelUtils.getCellData(i, 5);
						ded_UserInput = excelUtils.getCellData(i, 6);
						
						//replace queries with test data sub strings
						Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, "", "");
						Map<String,String> memberID = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("0"));
						Map<String,String> patientLName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("1"));
						Map<String,String> patientFName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("2"));
						Map<String,String> patientDOB = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("3"));
						OtherUtilities otherUtilities = new OtherUtilities();
						
						if(memberID.size()==0 || patientLName.size()==0 || patientFName.size()==0 || patientDOB.size()==0)
						{
							System.out.println("Mandatory field is missing or incorrect test data for row number: "+i+" in test data sheet"+testDataPath);
							logger.log(LogStatus.INFO, "Incorrect test data or mandatory field is missing for the Subscriber: "+ sbsb_id );
							//System.out.println("fail");
						}
						else{
						for(int j=7;j<=110;j++)
						{
							excelUtils = new ExcelUtilsExtended(mappingSheet, "CVS_MappingSheet");
							startPosition = Integer.parseInt(excelUtils.getCellData(j, startPositionColumn));
							endPosition = Integer.parseInt(excelUtils.getCellData(j, endPositionColumn));
							
							if(excelUtils.getCellData(j, defaultValueColumn).equals(""))
							{
								fieldName = excelUtils.getCellData(j, fieldNameColumn);
								switch (fieldName) {
								case "CARDHOLDER_ID":
									detailRecord = detailRecord+inboundFileUtils.addField(memberID.get("MEME_SSN"),startPosition,endPosition);
									break;
								case "PATIENT_LAST_NAME":
									detailRecord = detailRecord+inboundFileUtils.addField(patientLName.get("MEME_LAST_NAME"),startPosition,endPosition);
								break;
								case "PATIENT_FIRST_NAME":
									detailRecord = detailRecord+inboundFileUtils.addField(patientFName.get("MEME_FIRST_NAME"),startPosition,endPosition);
								break;
								case "PATIENT_BIRTH_DATE":
									detailRecord = detailRecord+inboundFileUtils.addField(patientDOB.get("DOB"),startPosition,endPosition);
								break;
								case "TRANSACTION_ID":
									detailRecord = detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(18).toString(),startPosition,endPosition);
								break;
								case "DATE_FILLED":
									detailRecord = detailRecord+inboundFileUtils.addField(dateOfService,startPosition,endPosition);
								break;
								case "FLAT_COPAY AMOUNT_PAID":
									if(coPay_UserInput.contains("."))
									{
										coPay_UserInput=coPay_UserInput.replace(".", "");
										coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
									}
									else if(coPay_UserInput.equals("0"))
									{
										coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
									}
									else
									{
										coPay_UserInput=coPay_UserInput+"00";
										coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
									}
								 detailRecord = detailRecord+coPay_UserInput;
								break;
								case "PERCENT_COPAY_AMOUNT_PAID":
									if(coIns_UserInput.contains("."))
									{
									 coIns_UserInput=coIns_UserInput.replace(".", "");
									 coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
									}
									else if(coIns_UserInput.equals("0"))
									{
										coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
									}
									else
									{
										coIns_UserInput=coIns_UserInput+"00";
										coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
									}
								 detailRecord = detailRecord+coIns_UserInput;
								break;
								case "FRONT_END_DEDUCTIBLE_AMOUNT":
									if(ded_UserInput.contains("."))
									{
									 ded_UserInput=ded_UserInput.replace(".", "");
									 ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput)); 
									}
									else if(ded_UserInput.equals("0"))
									{
										ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
									}
									else
									{
										ded_UserInput=ded_UserInput+"00";
										ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
									}
								 detailRecord = detailRecord+ded_UserInput;
								break;
								default:
									detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
								break;
								}
							}
							
							else if(excelUtils.getCellData(j,defaultValueColumn).equals("Field not used"))
									 detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
							else
									detailRecord = detailRecord+inboundFileUtils.addField(excelUtils.getCellData(j, defaultValueColumn),startPosition,endPosition);		
						}	
						bw.write(detailRecord);
						bw.newLine();
						excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
						totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(i, 4))+Double.parseDouble(excelUtils.getCellData(i, 5))+Double.parseDouble(excelUtils.getCellData(i, 6));
						totalRecords = totalRecords+1;
						logger.log(LogStatus.PASS, "Successfully inserted data of subscriber: "+ sbsb_id );
						detailRecord="";
						sbsb_id = excelUtils.getCellData(i, 0);
						mbr_sfx = excelUtils.getCellData(i, 1);
						coPay_UserInput = excelUtils.getCellData(i, 4);
						coIns_UserInput = excelUtils.getCellData(i, 5);
						ded_UserInput= excelUtils.getCellData(i, 6);
						}
						}
					//write Trailer
					String trailer="";
					for(int i=111;i<=115;i++)
					{
						excelUtils=new ExcelUtilsExtended(mappingSheet,"CVS_MappingSheet");
						startPosition=Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
						endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
						if(excelUtils.getCellData(i, defaultValueColumn).equals(""))
						{
							if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_RECORDS"))
							
								trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
							
							else if(excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_AMOUNT_PAYABLE"))
							{
								DecimalFormat totalAmountFormat = new DecimalFormat("0.00");
								String totalAccumAmount_trailer = totalAmountFormat.format(totalAccumAmount);
								if(totalAccumAmount_trailer.contains("."))
								{
									totalAccumAmount_trailer=totalAccumAmount_trailer.replace(".", "");
								}
								trailer=trailer+String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(totalAccumAmount_trailer));		
							}
							else if(excelUtils.getCellData(i, fieldNameColumn).equals("FILLER") || excelUtils.getCellData(i, fieldNameColumn).equals("TOTAL_ADMIN_FEE_AMOUNT"))
								trailer=trailer+inboundFileUtils.addField("", startPosition,endPosition);
						}
						else
							trailer=trailer+inboundFileUtils.addField(excelUtils.getCellData(i, defaultValueColumn),startPosition,endPosition);
					}
					bw.write(trailer);
					bw.close();
					writer.close();	
					}
				
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return inboundFile;
}

	
				

public static String generateFiller(int length)
{
	String filler = String.format("%-" + length + "s"," ");
	return filler;
}

}

