package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileBody {

	
	private String HICN;
	private String FIRST_NAME;
	private String LAST_NAME;
	private String MID_INIT;
	private String TRANS_RPLY_CD;
	private String TRANS_TYP_CD;
	public String getHICN() {
		return HICN;
	}
	public void setHICN(String hICN) {
		HICN = hICN;
	}
	public String getFIRST_NAME() {
		return FIRST_NAME;
	}
	public void setFIRST_NAME(String fIRST_NAME) {
		FIRST_NAME = fIRST_NAME;
	}
	public String getLAST_NAME() {
		return LAST_NAME;
	}
	public void setLAST_NAME(String lAST_NAME) {
		LAST_NAME = lAST_NAME;
	}
	public String getMID_INIT() {
		return MID_INIT;
	}
	public void setMID_INIT(String mID_INIT) {
		MID_INIT = mID_INIT;
	}
	public String getTRANS_RPLY_CD() {
		return TRANS_RPLY_CD;
	}
	public void setTRANS_RPLY_CD(String tRANS_RPLY_CD) {
		TRANS_RPLY_CD = tRANS_RPLY_CD;
	}
	public String getTRANS_TYP_CD() {
		return TRANS_TYP_CD;
	}
	public void setTRANS_TYP_CD(String tRANS_TYP_CD) {
		TRANS_TYP_CD = tRANS_TYP_CD;
	}
	
	
	
	
	
	
}
