package com.bsc.qa.webservices.tests;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.test_factory.BscaCare1stMMTestFactory;
import com.bsc.qa.webservices.utility.ASHPInboundFileUtility;
import com.bsc.qa.webservices.utility.CARE1STInboundFileUtility;
import com.bsc.qa.webservices.utility.COLLECTIVEHEALTHInboundFileUtility;
import com.bsc.qa.webservices.utility.CVSInboundFileUtility;
import com.bsc.qa.webservices.utility.DBPInboundFileUtility;
import com.bsc.qa.webservices.utility.ESIInboundFileUtility;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import com.bsc.qa.webservices.utility.MEDIMPACTInboundFileUtility;
import com.bsc.qa.webservices.utility.NAVITUSInboundFileUtility;
import com.bsc.qa.webservices.utility.OPTUMBSOFCAInboundFileUtility;
import com.bsc.qa.webservices.utility.OPTUMInboundFileUtility;
import com.bsc.qa.webservices.utility.OPTUMRXInboundFileUtility;
import com.github.ffpojo.exception.FFPojoException;
import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable {
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	
	
	public BscaCare1stMMTest(String inputFileName) {
		this.inputFileName = inputFileName;
		
	}
	// ************************************** TEST
	// METHODS************************

	@SuppressWarnings({ "deprecation", "static-access" })
	// Main test method to create Inbound files as per field mapping document.
	@Test()
	private void testInboundFileCreation() throws IOException, NumberFormatException, SQLException {
		
		File file=null;
		 if(inputFileName.contains("MEDIMPACT"))
		{
			MEDIMPACTInboundFileUtility MEDIMPACT = new MEDIMPACTInboundFileUtility();
		reportInit("InboundFileCreation", "MEDIMPACT");
		 file = MEDIMPACT.MEDIMPACTInboundFile(inputFileName);
		}
		 else if(inputFileName.contains("DBP"))
			{
				DBPInboundFileUtility DBP = new DBPInboundFileUtility();
			reportInit("InboundFileCreation", "DBP");
			 file = DBP.DBPInboundFile(inputFileName);
			}
		 else if(inputFileName.contains("CARE1ST"))
			{
				CARE1STInboundFileUtility CARE1ST = new CARE1STInboundFileUtility();
			reportInit("InboundFileCreation", "DBP");
			 file = CARE1ST.CARE1STInboundFile(inputFileName);
			}
		 else if(inputFileName.contains("CVS"))
			{
			CVSInboundFileUtility CVS = new CVSInboundFileUtility();
			reportInit("InboundFileCreation", "CVS");
			 file = CVS.CVSInboundFile(inputFileName);
			}
		 else if(inputFileName.contains("ESI"))
			{
			 ESIInboundFileUtility ESI = new ESIInboundFileUtility();
			reportInit("InboundFileCreation", "ESI");
			 file = ESI.ESIInboundFile(inputFileName);
			}
		 else if(inputFileName.contains("ASHP"))
			{
			 ASHPInboundFileUtility ASHP = new ASHPInboundFileUtility();
			reportInit("InboundFileCreation", "ASHP");
			 file = ASHP.ASHPInboundFile(inputFileName);
			}
		 else if(inputFileName.contains("NAVITUS"))
			{
			 NAVITUSInboundFileUtility NAVITUS = new NAVITUSInboundFileUtility();
			reportInit("InboundFileCreation", "NAVITUS");
			 file = NAVITUS.NAVITUSInboundFile(inputFileName);
			}
		 else if(inputFileName.contains("COLLECTIVEHEALTH"))
		{
			 COLLECTIVEHEALTHInboundFileUtility COLLECTIVEHEALTH = new COLLECTIVEHEALTHInboundFileUtility();
		reportInit("InboundFileCreation", "COLLECTIVEHEALTH");
		 file = COLLECTIVEHEALTH.COLLECTIVEHEALTHInboundFile(inputFileName);
		}
		 else if(inputFileName.contains("OPTUM"))
			{
			 if(inputFileName.contains("OPTUM_RX") || inputFileName.contains("OPTUMRX"))
			 {
				 OPTUMRXInboundFileUtility OPTUMRX = new OPTUMRXInboundFileUtility();
				reportInit("InboundFileCreation", "OPTUM_RX");
				 file = OPTUMRX.OPTUMRXInboundFile(inputFileName); 
			 }
			 else if(inputFileName.contains("OPTUM_BSOFCA") || inputFileName.contains("OPTUMBSOFCA"))
			 {
				 OPTUMBSOFCAInboundFileUtility OPTUM_BSOFCA = new OPTUMBSOFCAInboundFileUtility();
				reportInit("InboundFileCreation", "OPTUM_BSOFCA");
				 file = OPTUM_BSOFCA.OPTUMBSOFCAInboundFile(inputFileName); 
			 }
			 else
			 {
			 OPTUMInboundFileUtility OPTUM = new OPTUMInboundFileUtility();
			 reportInit("InboundFileCreation", "OPTUM");
			 file = OPTUM.OPTUMInboundFile(inputFileName);
			 }
			}
		 try {
				if(file.exists())
					logger.log(LogStatus.INFO, "Inbound file created sucessfully");
				else
					logger.log(LogStatus.INFO, "Inbound file creation is not successfull");
			} 
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
	}
	
	/**
	 * //To run test method, this method will initiate the HTML report
	 * 
	 * @Override run is a hook before @Test method
	 */
	
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult){
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting Test " + testResult.getName());
		callBack.runTestMethod(testResult);
		//To display the failure count in console
		softAssert.assertAll(); 
	}
	
	private Map<String, String> getData(String testMethodName) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		// assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/" + this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, testMethodName);
		return dataMap;
	}
}
		

