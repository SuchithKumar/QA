package com.bsc.qa.webservices.utility;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;










import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import com.bsc.qa.webservices.utility.DBPInboundFileUtility;

import org.apache.commons.lang3.StringUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.jna.platform.win32.OaIdl.MEMBERID;


public class CARE1STInboundFileUtility extends BaseTest{
	/**

	 * @return 
	 * @return 
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws NumberFormatException 
	 */
	@SuppressWarnings({ "static-access" })
	public  File CARE1STInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
		File inboundFile=null;
		DBUtils dbUtils = new DBUtils();
		InboundFileUtils inboundFileUtils = new InboundFileUtils();
		ExcelUtilsExtended excelUtils;
		Date todaysDate = new Date();
		DateFormat dateFormat_Header = new SimpleDateFormat("yyyyMMdd");;
		DateFormat dateFormat_detailRecord;
		String date_Header = dateFormat_Header.format(todaysDate);
		 Double totalAccumAmount = 0.00;
		 Long totalRecords = 0L;
		String inboundFilePath;
		FileWriter writer;
		BufferedWriter bw;
		
		String mappingSheet = "src//test//resources//BscaCare1stMMTest.xlsx";
		String sbsb_id,mbr_sfx,benifit_year,dateOfService,coPay_UserInput,coIns_UserInput,ded_UserInput,claimType,vendor,fieldName="",networkInd;
		 int defaultValueColumn=3, startPositionColumn=1,endPositionColumn=2,fieldNameColumn=0,startPosition,endPosition;
		 dateFormat_detailRecord = new SimpleDateFormat("dd-MMM-YYYY");
		 DBPInboundFileUtility DBPUtil = new DBPInboundFileUtility();
		 String date_filenameformat = DBPUtil.DBP_NAVITUSFileFormatDate();
		
		//create output file
		 inboundFilePath = System.getenv("OUTPUT_FILE_PATH")+"\\CARE1ST_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
		inboundFile = new File(inboundFilePath);
		 writer = new FileWriter(inboundFile);
		 bw = new BufferedWriter(writer);
		 String detailRecord="";	
				try{
					excelUtils = new ExcelUtilsExtended(mappingSheet, "CARE1ST_MappingSheet");
					//Write detail record
					
					//retrieve queries from queries sheet
					excelUtils = new ExcelUtilsExtended(mappingSheet,"CARE1ST_Queries");
					
					Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
							 
					excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
					
					int rowCount = excelUtils.getRowCount(null);
					
					for(int i=1;i<=rowCount;i++)
					{
						excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
						sbsb_id=excelUtils.getCellData(i, 0);
						mbr_sfx = excelUtils.getCellData(i, 1);
						benifit_year = excelUtils.getCellData(i, 2);
						dateOfService = excelUtils.getCellData(i, 3);
						networkInd = excelUtils.getCellData(i, 4);
						coPay_UserInput = excelUtils.getCellData(i, 5);
						coIns_UserInput = excelUtils.getCellData(i, 6);
						ded_UserInput = excelUtils.getCellData(i, 7);
						claimType = excelUtils.getCellData(i, 8);
						vendor = excelUtils.getCellData(i, 9);
						
						//replace queries with test data sub strings
						Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, "", "");
						
						ResultSet GroupID = dbUtils.getResultSet("facets",replacedQueries.get("0"));
						ResultSet memberDOB = dbUtils.getResultSet("facets",replacedQueries.get("1"));
						
						OtherUtilities otherUtilities = new OtherUtilities();
						
						while(GroupID.next() && memberDOB.next()){
						
						for(int j=1;j<=30;j++)
						{
							excelUtils = new ExcelUtilsExtended(mappingSheet, "CARE1ST_MappingSheet");
							startPosition = Integer.parseInt(excelUtils.getCellData(j, startPositionColumn));
							endPosition = Integer.parseInt(excelUtils.getCellData(j, endPositionColumn));
							
							if(excelUtils.getCellData(j, defaultValueColumn).equals(""))
							{
								fieldName = excelUtils.getCellData(j, fieldNameColumn);
								switch (fieldName) {
								case "Claim Number":
									detailRecord = detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
									break;
								case "Claim type/ status":
									detailRecord = detailRecord+inboundFileUtils.addField(claimType,startPosition,endPosition);
								break;
								case "Group ID":
									detailRecord = detailRecord+inboundFileUtils.addField(GroupID.getString(1),startPosition,endPosition);
								break;
								case "Subscriber ID":
									detailRecord = detailRecord+inboundFileUtils.addField(sbsb_id,startPosition,endPosition);
								break;
								case "Member Suffix":
									if(mbr_sfx.equals("0")||mbr_sfx.equals("1")||mbr_sfx.equals("2")||mbr_sfx.equals("3")||mbr_sfx.equals("4")||mbr_sfx.equals("5")||mbr_sfx.equals("6")||mbr_sfx.equals("7")||mbr_sfx.equals("8")||mbr_sfx.equals("9"))
										mbr_sfx = String.format("0000"+mbr_sfx);
									else
										mbr_sfx = "000"+mbr_sfx;
									detailRecord = detailRecord+mbr_sfx;
								break;
								case "Member date of birth":
									detailRecord = detailRecord+inboundFileUtils.addField(memberDOB.getString(1),startPosition,endPosition);
								break;
								case "Network Indicator":
									if(networkInd.equals("INN"))
										detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
									else if(networkInd.equals("OON"))
										detailRecord = detailRecord+inboundFileUtils.addField("T1",startPosition,endPosition);
								break;
								case "Procedure Code":
									detailRecord = detailRecord+inboundFileUtils.addField("09935",startPosition,endPosition);
								break;
								case "Claim Date of Service":
									detailRecord = detailRecord+inboundFileUtils.addField(dateOfService,startPosition,endPosition);
								break;
								case "Specialty Vendor Type":
									if(vendor.equals("ASHP"))
									{
										vendor="PHPASHSPECIAL";
										detailRecord = detailRecord+inboundFileUtils.addField(vendor,startPosition,endPosition);
									}
									else if(vendor.equals("Beacon"))
									{
										vendor="PHPBEACONSPEC";
										detailRecord = detailRecord+inboundFileUtils.addField(vendor,startPosition,endPosition);
									}
									else
										System.out.println("Invalid vendor user input");
								break;
								case "File Create Date":
									detailRecord = detailRecord+inboundFileUtils.addField(date_Header,startPosition,endPosition);
								break;
								case "Original Claim Number":
									detailRecord = detailRecord+inboundFileUtils.addField(otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
								break;
								case "EDI Tracer ID":
									detailRecord = detailRecord+inboundFileUtils.addField("E"+otherUtilities.generateRandomNumber(12).toString(),startPosition,endPosition);
								break;
								case "File Transmission ID":
									detailRecord = detailRecord+inboundFileUtils.addField("0664A953-3CDF-498A-B68C-2B626AD3360E".toString(),startPosition,endPosition);
								break;
								case "Co Pay Amount":
									if(coPay_UserInput.contains("."))
									{
										coPay_UserInput=coPay_UserInput.replace(".", "");
										coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
									}
									else if(coPay_UserInput.equals("0"))
									{
										coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
									}
									else
									{
										coPay_UserInput=coPay_UserInput+"00";
										coPay_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coPay_UserInput));
									}
								 detailRecord = detailRecord+coPay_UserInput;
								break;
								case "Co Insurance Amount":
									if(coIns_UserInput.contains("."))
									{
									 coIns_UserInput=coIns_UserInput.replace(".", "");
									 coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
									}
									else if(coIns_UserInput.equals("0"))
									{
										coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
									}
									else
									{
										coIns_UserInput=coIns_UserInput+"00";
										coIns_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(coIns_UserInput));
									}
								 detailRecord = detailRecord+coIns_UserInput;
								break;
								case "Deductible Amount":
									if(ded_UserInput.contains("."))
									{
									 ded_UserInput=ded_UserInput.replace(".", "");
									 ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput)); 
									}
									else if(ded_UserInput.equals("0"))
									{
										ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
									}
									else
									{
										ded_UserInput=ded_UserInput+"00";
										ded_UserInput = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(ded_UserInput));
									}
								 detailRecord = detailRecord+ded_UserInput;
								break;
								default:
									detailRecord = detailRecord+inboundFileUtils.addField("",startPosition,endPosition);
								break;
								}
							}
							else
									detailRecord = detailRecord+inboundFileUtils.addField(excelUtils.getCellData(j, defaultValueColumn),startPosition,endPosition);		
						}
						
						bw.write(detailRecord);
						bw.newLine();
						excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
						totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(i, 5))+Double.parseDouble(excelUtils.getCellData(i, 6))+Double.parseDouble(excelUtils.getCellData(i, 7));
						totalRecords = totalRecords+1;
						logger.log(LogStatus.PASS, "Successfully inserted data of subscriber: "+ sbsb_id );
						detailRecord="";
						sbsb_id = excelUtils.getCellData(i, 0);
						mbr_sfx = excelUtils.getCellData(i, 1);
						vendor = excelUtils.getCellData(i, 9);
						coPay_UserInput = excelUtils.getCellData(i, 5);
						coIns_UserInput = excelUtils.getCellData(i, 6);
						ded_UserInput= excelUtils.getCellData(i, 7);
						}
						}
				
					bw.close();
					writer.close();	
	}
			
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return inboundFile;
}

}

