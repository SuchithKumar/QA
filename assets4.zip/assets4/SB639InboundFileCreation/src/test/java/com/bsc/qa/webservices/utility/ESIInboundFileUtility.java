package com.bsc.qa.webservices.utility;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;












import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.OtherUtilities;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import com.bsc.qa.webservices.utility.DBPInboundFileUtility;

import net.sourceforge.htmlunit.corejs.javascript.ast.CatchClause;

import org.apache.commons.lang3.StringUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


public class ESIInboundFileUtility extends BaseTest{
	/**

	 * @return 
	 * @return 
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws NumberFormatException 
	 */
	@SuppressWarnings({ "static-access" })
	public  File ESIInboundFile(String testDataPath) throws IOException, NumberFormatException, SQLException {
		File inboundFile=null;
		DBUtils dbUtils = new DBUtils();
		ExcelUtilsExtended excelUtils;
		InboundFileUtils inboundFileUtils = new InboundFileUtils();
		Date todaysDate = new Date();
		DateFormat dateFormat_Header = new SimpleDateFormat("yyyyMMdd");;
		DateFormat dateFormat_detailRecord;
		String date_Header = dateFormat_Header.format(todaysDate);;
		String currentDate_detailRecord;
		 Double totalAccumAmount = 0.00;
		 Long totalRecords = 0L;
		String inboundFilePath;
		FileWriter writer;
		BufferedWriter bw;
		
		String mappingSheet = "src//test//resources//BscaCare1stMMTest.xlsx";
		String sbsb_id,mbr_sfx,benifit_year,dateOfService,networkInd,accumulatorType,accumAmount,fieldName="";	
		int startPositionColumn=1, endPositionColumn=2, fieldNameColumn=0,defaultValueColumn=3,startPosition,endPosition;
		
		
		//Create inbound file 
		ASHPInboundFileUtility ASHPUtil = new ASHPInboundFileUtility();
		String date_filenameformat = ASHPUtil.ASHP_OPTUMFileFormatDate();
		inboundFilePath = System.getenv("OUTPUT_FILE_PATH")+"\\ESI_ACCUMS_TO_BSCA_"+date_filenameformat+".txt";
		//Initialize writer
		inboundFile = new File(inboundFilePath);
		 writer = new FileWriter(inboundFile);
		 bw = new BufferedWriter(writer);
		 
		 String detailRecord="";
		 
		try
		{
			excelUtils = new ExcelUtilsExtended(mappingSheet, "ESI_MappingSheet");
			//write header
			String header="";
			for(int i=1;i<=11;i++)
				
			{
				//retrieve field name vales and default values from mapping sheet and place in the output file
				startPosition = Integer.parseInt(excelUtils.getCellData(i,startPositionColumn));
				endPosition = Integer.parseInt(excelUtils.getCellData(i,endPositionColumn));
				if(!excelUtils.getCellData(i, defaultValueColumn).equals(""))
				{
					if(excelUtils.getCellData(i, defaultValueColumn).equals("Field not used"))
						header = header+OtherUtilities.addField("", startPosition, endPosition);
					else
						header = header+OtherUtilities.addField(excelUtils.getCellData(i, defaultValueColumn), startPosition, endPosition);
				}
				else if(excelUtils.getCellData(i, fieldNameColumn).equals("CREATION_DATE"))
				{
					DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
					
					 String date = dateFormat.format(todaysDate);
					 header = header+OtherUtilities.addField(date, startPosition, endPosition);
				}
				else if(excelUtils.getCellData(i, fieldNameColumn).equals("CREATION_TIME"))
				{
					 DateFormat timeFormat = new SimpleDateFormat("hhmm");
					 String time = timeFormat.format(todaysDate);
					 header = header+OtherUtilities.addField(time, startPosition, endPosition);
				}
				else
					header = header+OtherUtilities.addField("", startPosition, endPosition);		
			}
			bw.write(header);
			bw.newLine();

		//Write detail record
		//retrieve queries from queries sheet
		
		excelUtils = new ExcelUtilsExtended(mappingSheet,"ESI_Queries");
		
		Map<String,String> queries = inboundFileUtils.fetchQueriesFromQueriesSheet(excelUtils);
		 			
		 excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
		 
		int rowCount = excelUtils.getRowCount(null);
		
		for(int i=1;i<=rowCount;i++)
		{
			excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			sbsb_id=excelUtils.getCellData(i, 0);
			mbr_sfx = excelUtils.getCellData(i, 1);
			benifit_year = excelUtils.getCellData(i, 2);
			dateOfService = excelUtils.getCellData(i, 3);
			networkInd = excelUtils.getCellData(i, 4);
			accumulatorType = excelUtils.getCellData(i, 5);
			accumAmount = excelUtils.getCellData(i, 6);
			
			Map<String,String> replacedQueries = inboundFileUtils.replaceQueries(queries, sbsb_id, mbr_sfx, "","");
			Map<String,String> cardholderID = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("0"));
			Map<String,String> patient_FirstName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("2"));
			Map<String,String> patient_LastName = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("1"));
			Map<String,String> patient_DOB = dbUtils.getOneRowResultSetAsMap("facets",replacedQueries.get("3"));
			
			if(cardholderID.size()==0 || patient_FirstName.size()==0 || patient_LastName.size()==0 || patient_DOB.size()==0)
			{
				System.out.println("Mandatory field is missing or incorrect test data for row number: "+i+" in test data sheet"+testDataPath);
				logger.log(LogStatus.INFO, "Incorrect test data or mandatory field is missing for the Subscriber: "+ sbsb_id );
				//System.out.println("fail");
			}
			else{
			excelUtils = new ExcelUtilsExtended(mappingSheet, "ESI_MappingSheet");
			for(int j=12;j<=194;j++)
			{	
			startPosition = Integer.parseInt(excelUtils.getCellData(j,startPositionColumn));
			endPosition = Integer.parseInt(excelUtils.getCellData(j,endPositionColumn));
			
			if(!excelUtils.getCellData(j, defaultValueColumn).equals("") && !excelUtils.getCellData(j, defaultValueColumn).equals("Field not used"))
				detailRecord = detailRecord+OtherUtilities.addField(excelUtils.getCellData(j, defaultValueColumn), startPosition, endPosition);
			else if(excelUtils.getCellData(j, defaultValueColumn).equals("Field not used"))
				detailRecord = detailRecord+OtherUtilities.addField("", startPosition, endPosition);
			else if(excelUtils.getCellData(j, fieldNameColumn).equals("VERSION_RELEASE_NUMBER") || excelUtils.getCellData(j, fieldNameColumn).equals("TRANSACTION_RESPONSE_STATUS") || excelUtils.getCellData(j, fieldNameColumn).equals("ACCUMULATOR_BALANCE_QUALIFIER_2") || excelUtils.getCellData(j, fieldNameColumn).equals("ACCUMULATOR_NETWORK_INDICATOR_2") ||excelUtils.getCellData(j, fieldNameColumn).equals("ACCUMULATOR_APPLIED_AMOUNT_2") || excelUtils.getCellData(j, fieldNameColumn).equals("ACTION_CODE_2"))
				detailRecord = detailRecord+OtherUtilities.addField("", startPosition, endPosition);
			else
			{
				fieldName = excelUtils.getCellData(j, fieldNameColumn);
				switch(fieldName){
				
				case "DATE_OF_SERVICE":
				 detailRecord = detailRecord+OtherUtilities.addField(dateOfService, startPosition, endPosition);
				 break;
				case "IN_NETWORK_INDICATOR":
				 detailRecord = detailRecord+OtherUtilities.addField(networkInd, startPosition, endPosition);
				 break;
				case "CARDHOLDER_ID":
				 detailRecord = detailRecord+OtherUtilities.addField(cardholderID.get("MEME_SSN"), startPosition, endPosition);
				 break;
				case "PATIENT_FIRST_NAME":
				 detailRecord = detailRecord+OtherUtilities.addField(patient_FirstName.get("MEME_FIRST_NAME"), startPosition, endPosition);
				 break;
				case "PATIENT_LAST_NAME":
					 detailRecord = detailRecord+OtherUtilities.addField(patient_LastName.get("MEME_LAST_NAME"), startPosition, endPosition);
					 break;
				case "DATE_OF_BIRTH":
				 detailRecord = detailRecord+OtherUtilities.addField(patient_DOB.get("DOB"), startPosition, endPosition);
				 break;
				case "ACCUMULATOR_BALANCE_QUALIFIER_1":
				if(accumulatorType.equals("DED"))
					detailRecord = detailRecord+OtherUtilities.addField("04", startPosition, endPosition);
				else if(accumulatorType.equals("OOP"))
					detailRecord = detailRecord+OtherUtilities.addField("01", startPosition, endPosition);
				else
					System.out.println("Enter valid accumulator type in data sheet"); 
				
			break;
				case "ACCUMULATOR_NETWORK_INDICATOR_1":
				 detailRecord = detailRecord+OtherUtilities.addField(networkInd, startPosition, endPosition);
				 break;
				case "ACCUMULATOR_APPLIED_AMOUNT_1":
			
				if(accumAmount.contains("."))
				{
					accumAmount=accumAmount.replace(".", "");
					accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
				}
				else if(accumAmount.equals("0"))
				{
					accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
				}
				else
				{
					accumAmount=accumAmount+"00";
					accumAmount = String.format("%0"+(endPosition-startPosition+1)+"d",Integer.parseInt(accumAmount));
				}
				detailRecord=detailRecord+accumAmount;
				break;
				case "ACTION_CODE_1":
				if(Double.parseDouble(accumAmount)>0)
					detailRecord = detailRecord+OtherUtilities.addField("+",startPosition,endPosition);
				else if(Double.parseDouble(accumAmount)<0)
					detailRecord = detailRecord+OtherUtilities.addField("-",startPosition,endPosition);	
				break;
				case "TRANSMISSION_ID":
				DateFormat dateFormat_transmissionID = new SimpleDateFormat("YYYYMMDDHHMMS");
				String date_transmissionID = dateFormat_transmissionID.format(todaysDate);
				detailRecord = detailRecord+OtherUtilities.addField(date_transmissionID+"@"+OtherUtilities.generateRandomNumber(8).toString(),startPosition,endPosition);			
			break;
				}
			}
		}	
			bw.write(detailRecord);
			bw.newLine();
			excelUtils = new ExcelUtilsExtended(testDataPath,"TestData");
			totalAccumAmount = totalAccumAmount+Double.parseDouble(excelUtils.getCellData(i, 6));
			totalRecords = totalRecords+1;
		detailRecord="";
		sbsb_id = excelUtils.getCellData(i, 0);
		mbr_sfx = excelUtils.getCellData(i, 1);
		accumAmount = excelUtils.getCellData(i, 6);
		logger.log(LogStatus.PASS, "Successfully inserted data of subscriber: "+ sbsb_id );
			}
			
		}
		
		//Write Trailer
		String trailer="";
		for(int i=195;i<=200;i++){
			
			excelUtils=new ExcelUtilsExtended(mappingSheet,"ESI_MappingSheet");
			startPosition=Integer.parseInt(excelUtils.getCellData(i, startPositionColumn));
			endPosition = Integer.parseInt(excelUtils.getCellData(i, endPositionColumn));
			if(!excelUtils.getCellData(i, defaultValueColumn).equals("")){
				if(excelUtils.getCellData(i, defaultValueColumn).equals("Field not used"))
					trailer=trailer+OtherUtilities.addField("",startPosition,endPosition);
				else
					trailer=trailer+OtherUtilities.addField(excelUtils.getCellData(i, defaultValueColumn),startPosition,endPosition);
			}
			else
			{
				if(excelUtils.getCellData(i, fieldNameColumn).equals("Record Count"))
					
					trailer=trailer+StringUtils.leftPad(totalRecords.toString(), endPosition-startPosition+1, "0");
				else
					trailer=trailer+OtherUtilities.addField(excelUtils.getCellData(i, defaultValueColumn),startPosition,endPosition);
			}
				
		}
		bw.write(trailer);
		bw.close();
		writer.close();
		
	}
		
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
			return inboundFile;
}

}

