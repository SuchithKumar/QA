package com.bsc.qa.facets.tests;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.netezza_util.NetezzaUtils;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.utility.DBUtilsExtended;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtilsExtended;
import com.gargoylesoftware.htmlunit.util.StringUtils;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable{

	public String strFilePath = "";
	public String claim_ID = "" ;
	public String[][] dbValue_Facets = null;
	public String[][] dbValue_Bor = null;
	public String[][] dbValue_Careware = null;
//	public String sheetName = "uat2";
	public String[][] edata = null;	
	
	//************************************** TEST METHOD************************	

	
	/*
	 * This method inputTextFile() is used to fetch the input text file 
	 which contains claim id's and sends each claim_id which has to be validated under various fields with databases
	 */
	
	@Test()
	public void testinputTextFile()throws IOException{
		String fieldName = "";
		String facets_query = "";
		String bor_query = "";
		String careware_query = "";
		try{
		String xlsPath = "src//test//resources//Test Data//"
				+ this.getClass().getSimpleName() + ".xlsx";
		edata = ExcelUtilsExtended.edataSupplier(xlsPath,
				System.getenv("ENVNAME"));
		strFilePath = System.getenv("INPUT_FILE_FULLPATH");
		System.out.println("File Path where claim_id's are present is"+strFilePath);
		File file = new File (strFilePath);
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line ;
		while ((line = br.readLine())!=null){
			claim_ID = line;
			System.out.println("Validating Claim ID :"+claim_ID);
			reportInit("Validating Claim ID","" +claim_ID);
			int rowCount = edata.length;
			int colCount  = edata[0].length;
			for (int i= 1 ; i < rowCount; i++) {
				for (int j=0; j < colCount; j++) {
					 fieldName = edata[i][0];
					 facets_query=edata[i][1];
					 bor_query = edata[i][2];
					 careware_query = edata[i][3];
				}
				getClaimIDValidated(claim_ID, fieldName, facets_query, bor_query, careware_query);
			
			}
		}
		br.close();
		}
		catch(Exception e){
			System.out.println("Test script Failed due to Exception.....!!");
			logger.log(LogStatus.FAIL, "Test script Failed due to Exception.....!!" + e.getMessage() );
			softAssert.fail("Test script Failed due to Exception.....!!", e.getCause());
			e.printStackTrace();
		}
		finally{
			softAssert.assertAll();	//<== absolutely must be here
		}
	}


	
	
	/*
	 * This method is used to fetch queries from the datasheet with respect to the three databases
	 	and retrieve the values from the databases.
	 */
	public void getClaimIDValidated(String claim_id,String fieldname, String facetsQuery, String borQuery, String carewareQuery){

		facetsQuery = facetsQuery.replace("claim_id", claim_id);
		borQuery = borQuery.replace("claim_id", claim_id);
		carewareQuery = carewareQuery.replace("claim_id", claim_id);
		if(facetsQuery==null||borQuery==null||carewareQuery==null){
			System.out.println("Query is not present for the field :"+fieldname);
		}
		else{
			dbValue_Facets = (String[][]) new DBUtilsExtended().getFacetsTableArray(facetsQuery);
			//System.out.println("facets db value is"+dbValue_Facets);
			new NetezzaUtils();
			dbValue_Bor = (String[][]) NetezzaUtils.getTableArray(borQuery);
			//System.out.println("bor db value is"+dbValue_Bor);
			dbValue_Careware = (String[][]) new DBUtilsExtended().getOracleTableArray(carewareQuery);
			//System.out.println("careware db value is"+dbValue_Careware);
		}
	
				
		compareFileToDatabases(claim_id,fieldname,dbValue_Facets, dbValue_Bor, dbValue_Careware);
					
				
		
		
	}
	
	public void compareFileToDatabases (String claim_id, String fieldName, String[][] facets_output, String[][] bor_output, String[][] careware_output){
		String strFacets = "";
		String strBor = "";
		String strCareware = "";
		
		
		strFacets = Arrays.deepToString(facets_output);
		strFacets = strFacets.replace("[","");
		strFacets = strFacets.replace("]", "");
		strFacets = strFacets.trim();
		System.out.println(strFacets.length());
		if(strFacets.equals("null")){
			strFacets = strFacets.replace("null", "[Blank]");
			
		}
		if (strFacets.length()==0){
			strFacets = "[Blank]";
		}
		System.out.println(strFacets);
		
		
		strBor = Arrays.deepToString(bor_output);
		strBor = strBor.replace("[","");
		strBor = strBor.replace("]", "");
		strBor = strBor.trim();
		System.out.println(strBor.length());
		if(strBor.equals("null")){
			strBor = strBor.replace("null", "[Blank]");
			
		}

		if(strBor.length()==0){
			strBor = "[Blank]";
		}
		System.out.println(strBor);
		
		
		
		strCareware = Arrays.deepToString(careware_output);
		strCareware = strCareware.replace("[","");
		strCareware = strCareware.replace("]", "");
		strCareware	 = strCareware.trim();	
		System.out.println(strCareware.length());
		if(strCareware.equals("null")){
			strCareware = strCareware.replace("null", "[Blank]");
		}
		if(strCareware.length()==0){
			strCareware = "[Blank]";
		}
		System.out.println(strCareware);
		
		if(strFacets.equals(strBor)){
			if(strBor.equals(strCareware)){
				String Status = "Pass";
				System.out.println("claim_id : "+claim_id+"|------|fieldName : "+fieldName+"|------|FacetsDB_Output : "+strFacets+
						"|------|BorDB_Output : "+strBor+"|------|CarewareDB_Output : "+strCareware+"|------|Status : "+Status );
				logger.log(LogStatus.PASS, "claim_id : "+claim_id+"|------|fieldName : "+fieldName+"|------|FacetsDB_Output : "+strFacets+
						"|------|BorDB_Output : "+strBor+"|------|CarewareDB_Output : "+strCareware+"|------|Status : "+Status);
			
			}
			else{
				String Status = "Fail";
				System.out.println("claim_id : "+claim_id+"|------|fieldName : "+fieldName+"|------|FacetsDB_Output : "+strFacets+
						"|------|BorDB_Output : "+strBor+"|------|CarewareDB_Output : "+strCareware+"|------|Status : "+Status );
				logger.log(LogStatus.FAIL, "claim_id : "+claim_id+"|------|fieldName : "+fieldName+"|------|FacetsDB_Output : "+strFacets+
						"|------|BorDB_Output : "+strBor+"|------|CarewareDB_Output : "+strCareware+"|------|Status : "+Status);
			}
		
		}
		else{
			String Status = "Fail";
			System.out.println("claim_id : "+claim_id+"|------|fieldName : "+fieldName+"|------|FacetsDB_Output : "+strFacets+
					"|------|BorDB_Output : "+strBor+"|------|CarewareDB_Output : "+strCareware+"|------|Status : "+Status );
			logger.log(LogStatus.FAIL, "claim_id : "+claim_id+"|------|fieldName : "+fieldName+"|------|FacetsDB_Output : "+strFacets+
					"|------|BorDB_Output : "+strBor+"|------|CarewareDB_Output : "+strCareware+"|------|Status : "+Status);
		
		}
	}
	
	
	
	
	
	
	
	


     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		
		//reportInit(testResult.getTestContext().getName(), testResult.getName() );
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}
}
	

