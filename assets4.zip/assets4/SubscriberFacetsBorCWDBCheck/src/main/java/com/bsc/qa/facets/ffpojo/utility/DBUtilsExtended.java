package com.bsc.qa.facets.ffpojo.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.json.JSONArray;
import org.json.JSONObject;


//import com.bsc.qa.framework.utility.JSONUtils;
import org.netezza.datasource.NzDatasource;
/**
 * DBUtilsExtended encapsulates methods required to get data from  database
 *
 */

public class DBUtilsExtended {
	
	private Connection facetsConnection = null;
	private Connection oracleConnection = null;
	//private Connection netezzaConnection = null;
	//private Connection connection = null;

	

	
	public void setUpDBConnection() {
		
		String facetsDB = System.getenv("FACETS_DB");
		//String netezzaDB = System.getenv("NETEZZA_DB");
		String oracleDB = System.getenv("ORACLE_DB");

		if (facetsConnection == null && facetsDB != null
				&& !"".equals(facetsDB)) {
			String facetsUser = System.getenv("FACETS_USER");
			String facetsPassword = System.getenv("FACETS_PASSWORD");
			String facetsServer = System.getenv("FACETS_SERVER");
			String facetsPort = System.getenv("FACETS_PORT");
			String facetsConnectionString = "jdbc:oracle:thin:"
					+ facetsUser.trim() + "/" + facetsPassword.trim() + "@"
					+ facetsServer.trim() + ":" + facetsPort.trim() + "/"
					+ facetsDB.trim();
			try {
				facetsConnection = DriverManager
						.getConnection(facetsConnectionString);
			} catch (SQLException ex) {
				System.out
						.println("ERROR: SQL Exception when connecting to the database: "
								+ facetsDB);
				ex.printStackTrace();
			}
		}

		if (oracleConnection == null && oracleDB != null && !"".equals(oracleDB)) {
			String oracleUser = System.getenv("ORACLE_USER");
			String oraclePassword = System.getenv("ORACLE_PASSWORD");
			String oracleServer = System.getenv("ORACLE_SERVER");
			String oraclePort = System.getenv("ORACLE_PORT");
			String oracleConnectionString = "jdbc:oracle:thin:"
					+ oracleUser.trim() + "/" + oraclePassword.trim() + "@"
					+ oracleServer.trim() + ":" + oraclePort.trim() + ":"
					+ oracleDB.trim();
			try {
				oracleConnection = DriverManager
						.getConnection(oracleConnectionString);
			} catch (SQLException ex) {
				System.out
						.println("ERROR: SQL Exception when connecting to the database: "
								+ oracleDB);
				ex.printStackTrace();
			}
		}
		
	
	}			
	
	
	
	/**
	 * Close the database connection
	 *
	 */
	public void tearDownDBConnection() {
		if (facetsConnection != null) {
			try {
				// System.out.println("Closing Facets Database Connection...");
				facetsConnection.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		
		if (oracleConnection != null) {
			try {
				// System.out.println("Closing ORACLE Database Connection...");
				oracleConnection.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}
	
	/**
	 * Get Facets table data as an array object
	 *
	 * @param query
	 *            SQL query
	 * @return Facets table array
	 */
	public Object[][] getFacetsTableArray(String query) {
		return getTableArray("facets", query);
	}
	
	/**
	 * Get ORACLE table data as an array object
	 *
	 * @param query
	 *            SQL Query
	 * @return Oracle table array
	 */
	public Object[][] getOracleTableArray(String query) {
		return getTableArray("oracle", query);
	}
	
	
	/**
	 * Get Table data as an array object
	 *
	 * @param dbSource
	 *            Database source
	 * @param query
	 *            SQL query
	 * @return table data as array
	 */
	public Object[][] getTableArray(String dbSource, String query) {
		String[][] tableArray = null;
		int totalCols = 0;
		int totalRows = 0;
		int ci = 0;
		int cj = 0;
		Statement statement = null;
		ResultSet resultSet;
		setUpDBConnection();
		try {
			if ("facets".equals(dbSource)) {
				statement = facetsConnection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
			} 
			if("oracle".equals(dbSource)) {
				statement = oracleConnection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
			}

			resultSet = statement.executeQuery(query);
			resultSet.last();
			totalRows = resultSet.getRow();
			ResultSetMetaData rsmd = resultSet.getMetaData();
			totalCols = rsmd.getColumnCount();
			tableArray = new String[totalRows][totalCols];
			resultSet.beforeFirst();

			while (resultSet.next()) {
				int i = 1;
				cj = 0;
				while (i <= totalCols) {
					// System.out.println(resultSet.getString(i) + " i=" + i);
					tableArray[ci][cj] = resultSet.getString(i++);
					cj++;
				}
				ci++;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		tearDownDBConnection();
		return tableArray;
	}
	
	
	


	/**
	 * Execute a query and get a ResultSet
	 *
	 * @param dbSource
	 *            Database source
	 * @param query
	 *            SQL Query
	 * @return resultSet
	 */
	public ResultSet getResultSet(String dbSource, String query) {
		Statement statement = null;
		ResultSet resultSet = null;
		setUpDBConnection();
		try {
			if ("facets".equals(dbSource)) {
				statement = facetsConnection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
			}  
			if("oracle".equals(dbSource)){
				statement = oracleConnection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
			}

			resultSet = statement.executeQuery(query);
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return resultSet;
	}



	/**
	 * Get column data as array object
	 *
	 * @param query
	 *            SQL query
	 * @return Facets table column array
	 */
	public Object[][] getFacetsColumnArray(String query) {
		return getColumnArray("facets", query);
	}
	
	/**
	 * Get column data as array object
	 *
	 * @param query
	 *            SQL query
	 * @return Oracle table column array
	 */
	public Object[][] getOracleColumnArray(String query) {
		return getColumnArray("oracle", query);
	}
	
	/**
	 * Get column headers from resultset
	 *
	 * @param dbSource
	 *            Database source
	 * @param query
	 *            SQL query
	 * @return Table column array
	 */
	public Object[][] getColumnArray(String dbSource, String query) {
		String[][] tableArray = null;
		int totalCols = 0;
		int totalRows = 0;
		Statement statement = null;
		ResultSet resultSet;
		setUpDBConnection();
		System.out.println("Debug Query: -------");
		System.out.println(query);
		try {
			if ("facets".equals(dbSource)) {
				statement = facetsConnection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
			}  
			if("oracle".equals(dbSource)){
				statement = oracleConnection.createStatement(
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
			}

			resultSet = statement.executeQuery(query);
			resultSet.last();
			totalRows = resultSet.getRow();
			ResultSetMetaData rsmd = resultSet.getMetaData();
			totalCols = rsmd.getColumnCount();
			tableArray = new String[totalRows][totalCols];
			resultSet.beforeFirst();

			int i = 0;
			while (resultSet.next()) {
				i = 0;
				while (i < totalCols) {
					tableArray[0][i++] = rsmd.getColumnName(i);
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		tearDownDBConnection();
		return tableArray;
	}

}