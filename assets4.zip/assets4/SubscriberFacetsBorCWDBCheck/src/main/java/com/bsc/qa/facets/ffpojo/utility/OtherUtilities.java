package com.bsc.qa.facets.ffpojo.utility;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.time.Month;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
//import com.bsc.qa.facets.tests.Date;
//import com.bsc.qa.facets.tests.SimpleDateFormat;
import com.relevantcodes.extentreports.LogStatus;

import java.text.SimpleDateFormat;
import java.util.Date;


public class OtherUtilities extends BaseTest{
	// Validating in bound file and FACETS database column values
	public static void validate(Map<String, String> flatFileValuesMap,	Map<String, String> queryDataMap,SoftAssert softAssertion) throws Exception {
		//SoftAssert softAssertion= new SoftAssert();
		for(String key:flatFileValuesMap.keySet()){
			if(queryDataMap.containsKey(key)){
				OtherUtilities.validateActualAndExpectedValues(key,flatFileValuesMap.get(key),queryDataMap.get(key),softAssertion);
				System.out.println(" FieldName: " + key + ", FileValue: " + flatFileValuesMap.get(key) + ", DBValue: " + queryDataMap.get(key));
			}else{
				 softAssertion.assertTrue(queryDataMap.containsKey(key), "Element " + key + " is not present in Database" );
				 logger.log(LogStatus.FAIL, key+" column is not present Database");
			}	
		}
		
		
	
	}

	
	
	// Validating in bound file and FACETS database column values 
	private static void validateActualAndExpectedValues(String key,String fileValue,String dbValue,SoftAssert softAssertion) throws Exception {
		
		String fileModifiedValue = fileValue;
		String dbModifiedValue = dbValue;
		if(fileValue != null){
			fileModifiedValue = fileValue.trim().toUpperCase();
			
			//Replacing null values with [Blank] for user understanding
			if(fileValue.toString().trim().equalsIgnoreCase(""))
				fileValue = "[Blank]";
		}
		else
		{
			fileModifiedValue = "NULL";
		}
	
		
		if(dbValue != null){
			dbModifiedValue = dbValue.trim().toUpperCase();
			
			
			if(dbValue.toString().trim().equalsIgnoreCase(""))
				dbValue = "[Blank]";
		}
		else
		{
			dbModifiedValue = "NULL";
		}
		
		//To validate CDML_CHG_AMT field
		if(key.equalsIgnoreCase("CDML_CHG_AMT")){
			
		/*	//float dbValueFloat = new Float(dbValue);
			double dbValueDouble = new Double(dbValue);
			DecimalFormat df = new DecimalFormat("###.##");
			//String dbValueFloatefwef = df.format(dbValueDouble);
			double dbValueFloatefwef = (Math.round(dbValueDouble*100.00)/100.00);*/
			
			//System.out.println(" DB float value:" + (dbValueFloatefwef) );
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			
		}
		if(key.equalsIgnoreCase("CLCL_TOT_CHG")){
			
			if(fileValue.indexOf(".") > -1)
			{
				if(dbValue.indexOf(".")==-1)
				{
					dbModifiedValue = dbModifiedValue + ".00";
				}
			}
			/*//float dbValueFloat = new Float(dbValue);
			long dbValueDouble = new Long(dbValue);
			DecimalFormat df = new DecimalFormat("###.##");
			//String dbValueFloatefwef = df.format(dbValueDouble);
			double dbValueFloatefwef = (Math.round(dbValueDouble*100.00)/100.00);*/
			
			//System.out.println(" DB float value:" + (dbValueFloatefwef) );
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			
		}
		//Error need to handle this with equal logic
		else if (key.contains("IPCD_ID")){
			assertContainLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			
		}
		//To validate PRPR_NAME field
		else if(key.equalsIgnoreCase("PRPR_NAME")){
			// AS of now we are ignored this filed validation	
			
			/*dbModifiedValue= dbModifiedValue.replace(",", "");
			dbModifiedValue= dbModifiedValue.replace(".", "");
			fileModifiedValue= fileModifiedValue.replace(",", "");
			fileModifiedValue= fileModifiedValue.replace(".", "");
			
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);*/
			
		}
		//To validate CLCL_RECD_DT field
		else if(key.equalsIgnoreCase("CLCL_RECD_DT")){
			
			fileModifiedValue = dateAddSub(fileValue,-1);
			if(fileModifiedValue == null)
			{
				fileModifiedValue = "NULL";
			}
				

			
			if(fileModifiedValue.equalsIgnoreCase(dbModifiedValue)){
				 assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			}
			else{
				assertEqualLogger(key,fileValue,dbValue,fileValue,dbValue,softAssertion);
			}

				
		}
		//To validate SBSB_ID field
		else if(key.equalsIgnoreCase("SBSB_ID")){
			
		
			if(fileModifiedValue != null)
			{
				fileModifiedValue = fileModifiedValue.substring(0, 9);
			}
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);	
				
		}

		else{
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
		}
			
				
	
	}

	
	public static String dateAddSub(String strDate, int intDays) throws Exception{
		
		//Specifying date format that matches the given date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar c = Calendar.getInstance();
		try{
		   //Setting the date to the given date
		   c.setTime(sdf.parse(strDate));
		}catch(ParseException e){
			//e.printStackTrace();
			return null;
		 }
		   
		//Number of Days to add
		c.add(Calendar.DAY_OF_MONTH, intDays);  
		//Date after adding the days to the given date
		return sdf.format(c.getTime());
	}


	public static void printTestCaseDeatilsInReport(Map<String, String> data) {		
		
		String strSUCName= data.get("SUCName").toString();		
		String strTestCaseId = data.get("TestCaseID").toString();		
		String strTestCaseName = data.get("TestCaseName").toString();		
		String strStepNumber = data.get("StepNumber").toString();
		//String strInputFileName = data.get("Input File Name").toString();
		logger.log(LogStatus.INFO," SUC Name: " + strSUCName + ", Test Case ID: " + strTestCaseId + ", Test Case Name: " + strTestCaseName + ", Step Number:" + strStepNumber);
		//logger.log(LogStatus.INFO," Input File Name: " + strInputFileName);
	}
	
	
	
	public static void assertEqualLogger(String key, String flatFileValue, String dbValue,String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(flatFileValue.equalsIgnoreCase(dbValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " <br> Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}
	}
	
	public static void assertContainLogger(String key, String flatFileValue, String dbValue, String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(dbValue.contains(flatFileValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}
	}
	
	public static void assertFailLogger(String key, String flatFileValue, String dbValue, String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(false, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
	}




	
	
	//below method is to check whether the given number is numeric or not
		public static boolean isNumeric(String str) {
		    int size = str.length();
		    for (int i = 0; i < size; i++) {
		        if (!Character.isDigit(str.charAt(i))) {
		            return false;
		        }
		    }

		    return size > 0;
		} 

}
