package com.bsc.qa.facets.ffpojo.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;








//import com.bsc.qa.framework.utility.DBUtils;
//import com.bsc.qa.facets.utility.ExcelUtilsExtended;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;



/**
 * ExcelUtils class that gets test data from excel file to be used for driving tests.
 * 
 *
 */
public class ExcelUtilsExtended
{
	private static XSSFSheet excelWSheet;
	private static XSSFWorkbook excelWBook;
	public static XSSFCellStyle style;
	private static XSSFCell cell;

	/**
	 *  ExcelutilsExtended Constructor accepts two parameters : excel sheet path and sheet name
	 */
	public ExcelUtilsExtended(String path, String sheetName ) {
        try{
        FileInputStream ExcelFile = new FileInputStream(path);
        excelWBook = new XSSFWorkbook(ExcelFile);
        excelWSheet = excelWBook.getSheet(sheetName);
        }catch(Exception e){
               e.printStackTrace();
        }
        }

	
	/**GetCellData method is used fetch the data from each cell with respect to row number and column number*/
    public static String getCellData(int rowNum, int colNum) 
    {
    	try
           {
			//Creating cell
			  cell = excelWSheet.getRow(rowNum).getCell(colNum);
			  String cellData = null;
			  //To fetch data from excel cell when cell type as String
			  if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
			        cellData = cell.getStringCellValue();
			 
			  }
			//To fetch data from excel cell when cell type as Numeric
			  else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) 
			  {
			        cellData = String.valueOf(cell.getNumericCellValue());
			  }
			//To fetch data from excel cell when cell value as Blank
			  else if (cell.getCellType() == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK)
			  {
			        cellData = "";
			          }
			          return cellData;
			   } 
			   catch (Exception e)
			   {
			          return "";
			   }
    	}
    /**
     * read the excel sheet and store the entire data into a String Array
     * This method takes two parameters
     * -filePath - excel sheet file path
     * -sheetName - name of the sheet to fetch queries 
     */
	public static String[][] edataSupplier(String filePath, String sheetName) {
		String[][] arrayExcelData = null;
		FileInputStream excelFile = null;
		try {
			excelFile = new FileInputStream(filePath);
		} catch (FileNotFoundException e) {
			System.out.println("Could not read the Excel sheet: " + sheetName);
		}
		try {
			excelWBook = new XSSFWorkbook(excelFile);
		} catch (IOException e) {
			System.out.println("Could not read the Excel sheet: " + sheetName);
		}
		excelWSheet = excelWBook.getSheet(sheetName);
		if (excelWSheet == null) {
			excelWSheet = excelWBook.getSheet(sheetName);
		}
		int totalNoOfRows = excelWSheet.getLastRowNum();// count sheet number of Rows
		int totalNoOfCols = excelWSheet.getRow(0).getLastCellNum();// get last ColNum
		arrayExcelData = new String[totalNoOfRows+1][totalNoOfCols];
		
		for (int i= 0 ; i <= totalNoOfRows; i++) {

			for (int j=0; j < totalNoOfCols; j++) {
				arrayExcelData[i][j] = excelWSheet.getRow(i).getCell(j).toString();
			}

		} 
		return arrayExcelData;
	}

	
	
	
	
	/**
	 * Get columns names array
	 * 
	 * @param filePath	Excel file path
	 * @param sheetName	Excel sheet name
	 * @return	Object array of column names
	 */
	public static Object[][] getColumnArray(String filePath, String sheetName) {   
		String[][] columnArray = null;
		int ci;
		int totalRows;
		int totalCols;
	
		try {
			FileInputStream excelFile = new FileInputStream(filePath);			
			excelWBook = new XSSFWorkbook(excelFile);
			excelWSheet = excelWBook.getSheet(sheetName);
			if (excelWSheet == null) {
				excelWSheet = excelWBook.getSheet("Sheet1");
			}
			totalRows = excelWSheet.getPhysicalNumberOfRows()-1;
			totalCols = excelWSheet.getRow(0).getPhysicalNumberOfCells()-1;
			columnArray=new String[totalRows][totalCols+1];
			ci=0;

			for (int j=0;j<=totalCols;j++){
				if(getCellData(ci,j).trim()!=""){
					columnArray[ci][j]=getCellData(ci,j);
				}
			}
		}catch (FileNotFoundException e){
			System.out.println("Could not read the Excel sheet: " + sheetName);
		}catch (IOException e){
			System.out.println("Could not read the Excel sheet: " + sheetName);
		}
		return(columnArray);
	}
	
	/**
	 * Get Excel data as an array
	 * 
	 * @param filePath	Excel file path
	 * @param sheetName	Excel sheet name
	 * @return	Object array of data in the table
	 */
	public static Object[][] getTableArray(String filePath, String sheetName) {   
		String[][] tableArray = null;
		int startRow = 1;
		int startCol = 0;
		int ci,cj;
		int totalRows;
		int totalCols;
	
		try {
			FileInputStream excelFile = new FileInputStream(filePath);			
			excelWBook = new XSSFWorkbook(excelFile);
			excelWSheet = excelWBook.getSheet(sheetName);
			if (excelWSheet == null) {
				excelWSheet = excelWBook.getSheet("Sheet1");
			}
			totalRows = excelWSheet.getPhysicalNumberOfRows()-1;
			totalCols = excelWSheet.getRow(0).getPhysicalNumberOfCells()-1;
			tableArray=new String[totalRows][totalCols+1];
			ci=0;
			for (int i=startRow;i<=totalRows;i++, ci++) {           	   
				cj=0;
				for (int j=startCol;j<=totalCols;j++, cj++){
					//System.out.println(ci+":"+cj+"->"+i+":"+j);
					if(getCellData(i,j) != null && getCellData(i,j).trim()!=""){
						tableArray[ci][cj]=getCellData(i,j);
					}
					else {
						tableArray[ci][cj]="";
					}
				}
			}
		}catch (FileNotFoundException e){
			System.out.println("Could not read the Excel sheet");
		}catch (IOException e){
			System.out.println("Could not read the Excel sheet");
		}
		return(tableArray);
	}

}


