package com.bsc.qa.facets.ffp.pojo.BscShdwAccumsToAshp;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true)

public class BscShdwAccumsToAshpHeader {
	
	
	private String Record_Type;
	private String Filler_Unused1;
	private String Company_Name;
	private String Creation_Date;
	private String Filler_Unused2;
	private String Frequency;
	private String Company_Control_Code;
	private String Filler;
	
	/**
	 * @return the record_Type
	 */
	public String getRecord_Type() {
		return Record_Type;
	}
	/**
	 * @param record_Type the record_Type to set
	 */
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	/**
	 * @return the filler_Unused1
	 */
	public String getFiller_Unused1() {
		return Filler_Unused1;
	}
	/**
	 * @param filler_Unused1 the filler_Unused1 to set
	 */
	public void setFiller_Unused1(String filler_Unused1) {
		Filler_Unused1 = filler_Unused1;
	}
	/**
	 * @return the company_Name
	 */
	public String getCompany_Name() {
		return Company_Name;
	}
	/**
	 * @param company_Name the company_Name to set
	 */
	public void setCompany_Name(String company_Name) {
		Company_Name = company_Name;
	}
	/**
	 * @return the creation_Date
	 */
	public String getCreation_Date() {
		return Creation_Date;
	}
	/**
	 * @param creation_Date the creation_Date to set
	 */
	public void setCreation_Date(String creation_Date) {
		Creation_Date = creation_Date;
	}
	/**
	 * @return the filler_Unused2
	 */
	public String getFiller_Unused2() {
		return Filler_Unused2;
	}
	/**
	 * @param filler_Unused2 the filler_Unused2 to set
	 */
	public void setFiller_Unused2(String filler_Unused2) {
		Filler_Unused2 = filler_Unused2;
	}
	/**
	 * @return the frequency
	 */
	public String getFrequency() {
		return Frequency;
	}
	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(String frequency) {
		Frequency = frequency;
	}
	/**
	 * @return the company_Control_Code
	 */
	public String getCompany_Control_Code() {
		return Company_Control_Code;
	}
	/**
	 * @param company_Control_Code the company_Control_Code to set
	 */
	public void setCompany_Control_Code(String company_Control_Code) {
		Company_Control_Code = company_Control_Code;
	}
	/**
	 * @return the filler
	 */
	public String getFiller() {
		return Filler;
	}
	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		Filler = filler;
		
	}
	
}
		
		
	
	
	
	