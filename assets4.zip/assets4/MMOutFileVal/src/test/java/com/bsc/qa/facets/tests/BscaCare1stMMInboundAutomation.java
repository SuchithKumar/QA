package com.bsc.qa.facets.tests;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.utility.ExcelFunctions;
import com.relevantcodes.extentreports.LogStatus;
public class BscaCare1stMMInboundAutomation extends BaseTest implements IHookable{

	  @BeforeMethod
	 
	  public void beforeMethod() throws Exception {
	 
		 System.out.println("Before Method"); 
	 
	  }	
	 
	  @Test(dataProvider = "Authentication")
	 
	  public void f(String sUserName, String sPassword) {
	 
		    System.out.println("success");
	 
	  }
	 
	
	  @DataProvider
	 
	  public Object[][] Authentication() throws Exception{
	 
		  
		  Object[][] testObjArray = ExcelFunctions.getTableArray("src//test//resources//TestData.xlsx","BSCA_Care1st_MM_Test");
		  
	         return (testObjArray);
		  
		  
		  // Setting up the Test Data Excel file
	 
		 	
	 
			}
	  @Override
		public void run(IHookCallBack callBack, ITestResult testResult) {	
			reportInit(testResult.getTestContext().getName(), testResult.getName());
			softAssert = new SoftAssert();
			logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
			callBack.runTestMethod(testResult);	
			softAssert.assertAll();				
		}	
		
  
}
