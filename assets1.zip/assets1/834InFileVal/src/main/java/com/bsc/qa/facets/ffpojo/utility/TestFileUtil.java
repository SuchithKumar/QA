package com.bsc.qa.facets.ffpojo.utility;

/**
 * Serhiy Malyy 
 * Class allows to locate most recent file in folder by last date/time modified
 * It enables file-based test to run and select files under test from folder and eliminates the need to hardcode file name
 * 
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

public class TestFileUtil {

	String FlatFileRootDirectory;
	String InterfaceSpecoficFolder; 
	
	
	public TestFileUtil(String flatFileRootDirectory,String interfaceSpecoficFolder) {
		
		FlatFileRootDirectory = flatFileRootDirectory;
		InterfaceSpecoficFolder = interfaceSpecoficFolder;
	}

	public static File lastFileModified(String dir) {
	    File fl = new File(dir);
	    File[] files = fl.listFiles(new FileFilter() {          
	        public boolean accept(File file) {
	            return file.isFile();
	        }
	    });
	    long lastMod = Long.MIN_VALUE;
	    File choice = null;
	    for (File file : files) {
	        if (file.lastModified() > lastMod) {
	            choice = file;
	            lastMod = file.lastModified();
	        }
	    }
	    return choice; //lastFileModified
	}
	
	public File getTestFile(){
		
		String completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		
		System.out.println("Test file root directory is:" + FlatFileRootDirectory);
		System.out.println("Test file spefic directory is:" + InterfaceSpecoficFolder);
		
		File objFile = lastFileModified (completePath);
		
		return objFile;
	
	}
	
	public String getCompleteTestFilePath(){
		
		String completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		
		System.out.println("Complete path to test file is:"+ completePath);
		
		File objFile = lastFileModified (completePath);
		
		String obsPath = objFile.getAbsolutePath();	
		
		System.out.println("----------------------test File Info -------------------------------------");
		System.out.println(" ");
		System.out.println("Absolute file under test is :"+ obsPath);
		System.out.println(" ");
		System.out.println("----------------------test File Info -------------------------------------");
		return obsPath;
	
				
		
	}

	public static void copyFile(Path htmlSourcePath, Path htmlReportDestinationPath) throws IOException {
		Files.copy(htmlSourcePath, htmlReportDestinationPath,StandardCopyOption.REPLACE_EXISTING);	
		
		
	}


/**
 * @param strFlatFileCompletePath; 834 file complete path
 * @throws Exception
 */
public static void fileFormatChange834(String strFlatFileCompletePath) throws Exception
{	
	FileWriter fileWriter = null;
	FileReader fileReader  = null;
	BufferedReader bufferedReader = null;
	
	try{
		File inputFile = new File(strFlatFileCompletePath);
		String strLines = "";
		String line = "";
		//Checking for the file existence
		if (!inputFile.exists()) { 
			  throw new IllegalStateException("File not found: " + strFlatFileCompletePath);
		  } 
		else 
		{
			fileReader =  new FileReader(inputFile);
			bufferedReader =        new BufferedReader(fileReader);
			int intICounter = 0;
			while((line = bufferedReader.readLine())!=null)
			{
				strLines = strLines + line;
				intICounter += 1;
				//Checking for single line 834 file
				if(intICounter > 1)
				{
					bufferedReader.close();
					return;
				}
			}
		
			byte [] strBytes = strLines.getBytes();
			String strAllLines = new String (strBytes,StandardCharsets.UTF_8);
			//Replacing "~" symbol with "~\r\n"
			String strFormatLines = strAllLines.replaceAll("~", "~\r\n");
			fileWriter = new FileWriter(strFlatFileCompletePath);
			//Writing the data once again into the file after changes
			fileWriter.write(strFormatLines);
		  }
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try{
			fileReader.close();
			fileWriter.close();
			bufferedReader.close();
		}
		catch(Exception ex)
		{
			//ex.printStackTrace();
		}
	}
}

/**
 * @param testFlatFileCompletePath: File complete path
 * @param strCINNNumber: To capture specific subscriber section
 * @param strFileName: 834 file type
 * @return: List of subscriber lines
 * @throws Exception
 */
public static  List<String> parse834File(String testFlatFileCompletePath,String strCINNNumber, String strFileName) throws Exception{
	
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
		  		//Changing the layout when it is not expected
		  		fileFormatChange834(testFlatFileCompletePath);
				  if(strFileName.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834"))
				  {
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader = new BufferedReader(fileReader);
						boolean flag=false;
				        while((line = bufferedReader.readLine()) != null) {
				        	//Checking for the CINN Number
				        	if(line.contains(strCINNNumber)){
				        		flag=true;
				        	}
				        	//Checking for the starting line for each subscriber section
				        	if(line.startsWith("ST")){
				        		if(flag){
				        			break;
				        		}else{
				        			rowsList.clear();
				        		}
				        	}
				        	rowsList.add(line);
				       		}   
				  }
				  //To capture DHCS file specific subscriber lines
				  else if(strFileName.contains("DHCS"))
				  {
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader =  new BufferedReader(fileReader);
						boolean flag=false;
				        while((line = bufferedReader.readLine()) != null) {
				        	//Checking for the CINN Number
				        	if(line.contains(strCINNNumber)){
				        		flag=true;
				        	}
				        	//Checking for the starting line for each subscriber section
				        	if(line.startsWith("INS*Y*18*")){
				        		if(flag){
				        			break;
				        		}else{
				        			rowsList.clear();
				        		}
				        	}
				        	rowsList.add(line);
				       		}  
				  }
				  else
				  {
					  System.out.println("Please select valid file type to retrieve data from flat file ");
				  }

  	}
	 if(bufferedReader!=null)
		 bufferedReader.close();
	return rowsList;
}


/**
 * To capture CINN Numbers from 834 file
 * @param testFlatFileCompletePath: 834 File complete path
 * @param strFileName: 834 file type
 * @return: List of CINN Numbers
 * @throws Exception: Throwing exception
 */
public static  List<String> parse834FileForCINNNumbers(String testFlatFileCompletePath, String strFileName) throws Exception{
	
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
		  		//Changing the layout when it is not expected
		  		fileFormatChange834(testFlatFileCompletePath);
		  		//To capture CINN Numbers from LACare file
				  if(strFileName.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834"))
				  {
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader = new BufferedReader(fileReader);
						//Looping through all lined for checking CINN Number line
				        while((line = bufferedReader.readLine()) != null) {
				        	if(line.startsWith("NM1*IL*1*")){
				        		rowsList.add(line.split("\\*")[9].replace("~", ""));
				        	}
				       	}   
				  }
				//To capture CINN Numbers from DHCS file
				  else if(strFileName.contains("DHCS"))
				  {
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader = new BufferedReader(fileReader);
						//Looping through all lined for checking CINN Number line
				        while((line = bufferedReader.readLine()) != null) {
				        	if(line.startsWith("REF*0F*")){
				        		rowsList.add(line.split("\\*")[2].replace("~", ""));
				        	}
				       	}  
				  }
				  else
				  {
					  System.out.println("Please select valid file type to retrieve data from flat file ");
				  }

  	}

	if(bufferedReader != null)
		bufferedReader.close();

	return rowsList;
}


/**
 * To find file type for 834 care1st MM
 * @param strFileName: Name of the file
 * @return: File name used for coding
 */
public static String fileType834(String strFileName)
{	
	//Checking for the expected file name
	if(strFileName.contains("CFST.D"))
		return "LACounty_Medi-Cal_Members(LACare)834";
	else if(strFileName.contains("DHCS834-DA-") && strFileName.contains("Care1st-SanDiego"))
		return "SDCounty_Medi-Cal_Members(DHCS)834";
	else if(strFileName.contains("DHCS834-DA-") && strFileName.contains("C1CMC-LosAngeles"))
		return "LACounty_Cal-MediConnect_Members(DHCS)834";
	else if(strFileName.contains("DHCS834-DA-") && strFileName.contains("C1CMC-SanDiego"))
		return "SDCounty_Cal-MediConnect_Members(DHCS)834";
	else if(strFileName.contains("Monthly_Salesforce_PCP_Assign"))
		return "Monthly_Salesforce_PCP_Assign";
	else if(strFileName.contains("P.RH0148.DTRRD.D"))
		return "TRR";
	else if(strFileName.startsWith("T_"))
		return "HCO";
	else
		System.out.println("This file name is invalid: " + strFileName );
		return null;
}


public static void createFolder(String strFolderPath) throws Exception
{
	Path folderPath = Paths.get(strFolderPath);
	if(!Files.exists(folderPath))
	{
		Files.createDirectories(folderPath);
	}
}


}
