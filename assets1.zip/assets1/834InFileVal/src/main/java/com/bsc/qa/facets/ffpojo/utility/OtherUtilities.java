package com.bsc.qa.facets.ffpojo.utility;


import java.util.Map;
import org.testng.asserts.SoftAssert;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.relevantcodes.extentreports.LogStatus;



public class OtherUtilities extends BaseTest{
	
	/**
	 * Validating flat file values against database values
	 * @param flatFileValuesMap: Flat file field value map
	 * @param queryDataMap: Database fields map
	 * @param softAssertion: For comparison
	 * @throws Exception: To capture the exception
	 */
	public static void validate(Map<String, String> flatFileValuesMap,	Map<String, String> queryDataMap,SoftAssert softAssertion) throws Exception {
		//Looping through all Flat file fields for comparison
		for(String key:flatFileValuesMap.keySet()){
			//Checking for key existence in database query map
			if(queryDataMap.containsKey(key)){
				OtherUtilities.validateActualAndExpectedValues(key,flatFileValuesMap.get(key),queryDataMap.get(key),softAssertion);
				//System.out.println(" FieldName: " + key + ", FileValue: " + flatFileValuesMap.get(key) + ", DBValue: " + queryDataMap.get(key));
			}else{
				 softAssertion.assertTrue(queryDataMap.containsKey(key), "Element " + key + " is not present in Database" );
				 logger.log(LogStatus.FAIL, key+" column is not present Database");
			}	
		}
		
		
	
	}

	
	
	/**
	 * // Validating flat file values against database values
	 * @param key: Field name for reporting
	 * @param fileValue: Flat file value
	 * @param dbValue: Database value
	 * @param softAssertion: For comparison
	 * @throws Exception: To capture the exception
	 */
	private static void validateActualAndExpectedValues(String key,String fileValue,String dbValue,SoftAssert softAssertion) throws Exception {
		
		String fileModifiedValue = fileValue.trim().toUpperCase();
		String dbModifiedValue = dbValue.trim().toUpperCase();
		
		//Replacing null values with [Blank] for user understanding
		if(fileValue.toString().trim().equalsIgnoreCase(""))
			fileValue = "[Blank]";
		if(dbValue.toString().trim().equalsIgnoreCase(""))
			dbValue = "[Blank]";

		//To validate MECD_MCTR_AIDC1 field
		else if(key.equalsIgnoreCase("MECD_MCTR_AIDC1")){
			
			fileModifiedValue = ("0000" + fileValue).substring(("0000" + fileValue).length() - 4);
			
			if(fileModifiedValue.equalsIgnoreCase(dbModifiedValue)){
				 assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			}
			else{
				assertEqualLogger(key,fileValue,dbValue,fileValue,dbValue,softAssertion);
			}
				
		} 
		//To validate ADDRESS1 and ADDRESS2 fields
		else if(key.equalsIgnoreCase("ADDRESS1") || key.equalsIgnoreCase("ADDRESS2")){
			
			
			if(fileModifiedValue.contains(dbModifiedValue)){
				assertContainLogger(key,dbModifiedValue,fileModifiedValue,fileValue,dbValue,softAssertion);
			}
			
				
		}
		//For comparing remaining all field values
		else{
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
		}
			
				
	
	}

	
	


	
	
	
	/**
	 * To compare two values with assertEquals method
	 * @param key: Field name for reporting
	 * @param flatFileValue: Modified flat file value
	 * @param dbValue: Modified database value
	 * @param flatFileOriginalalue: Flat file original value
	 * @param dbOriginalValue: Database original value
	 * @param softAssertion: For comparison
	 */
	public static void assertEqualLogger(String key, String flatFileValue, String dbValue,String flatFileOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		//Comparing source and target values to report in the logger
		if(flatFileValue.equalsIgnoreCase(dbValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}
	}
	
	/**
	 * To compare two values with assertEquals method
	 * @param key: Field name for reporting
	 * @param flatFileValue: Modified flat file value
	 * @param dbValue: Modified database value
	 * @param flatFileOriginalalue: Flat file original value
	 * @param dbOriginalValue: Database original value
	 * @param softAssertion: For comparison
	 */
	public static void assertContainLogger(String key, String flatFileValue, String dbValue, String flatFileOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		//Comparing source and target values to report in the logger
		if(dbValue.contains(flatFileValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}
	}
	
	/**
	 * To compare two values with assertEquals method
	 * @param key: Field name for reporting
	 * @param flatFileValue: Modified flat file value
	 * @param dbValue: Modified database value
	 * @param flatFileOriginalalue: Flat file original value
	 * @param dbOriginalValue: Database original value
	 * @param softAssertion: For comparison
	 */
	public static void assertFailLogger(String key, String flatFileValue, String dbValue, String flatFileOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(false, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		
		logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileOriginalalue + " | Database value: " + dbOriginalValue + " >>");
	}


}
