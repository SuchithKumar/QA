package com.bsc.qa.facets.tests;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable{
	
	
	//************************************** TEST METHODS************************	

	// Main test method to validate 834 file against FACETS database.
	@Test(dataProvider = "masterDataProvider")
	private void test834FileValidation(Map<String, String> data) {
		try {
			Map<String, String> flatFileValuesMap=new HashMap<String,String>();
			Map<String,String> queryDataMap = new HashMap <String,String>();
			
			//Creating DBUtils object for accessing resultSetToDictionaryMultiKeyValues method
			DBUtils dbUtils = new DBUtils(System.getenv("FACETS_DB"),System.getenv("FACETS_USER"),System.getenv("FACETS_PASSWORD"),System.getenv("FACETS_SERVER"),System.getenv("FACETS_PORT"));
			
			//Retrieving test data value from test data sheet			
			String strCompleteFilePath = System.getenv("STT_FILENAME");
			logger.log(LogStatus.INFO,  " Validating file path: " + strCompleteFilePath);
			String strInputFileName=strCompleteFilePath.substring(strCompleteFilePath.lastIndexOf("//")+2);
			String strFileType,parameter1;
			System.out.println("Test data value:" + data.get("CINNNUmber"));
			
			//Capturing queries details from test data sheet
			String queryFromDataSheet = data.get("SqlQueries").toString();
			//String strOtherQueries = data.get("OtherQueries").toString();;
			
			//To get 834 file type
			strFileType = TestFileUtil.fileType834(strInputFileName);
			
			//Checking for the 834 file type
			if(strFileType.contains("834"))
			{
				//For capturing CINN numbers from 834 file
				List<String>rowsListCINNNumbers=TestFileUtil.parse834FileForCINNNumbers(strCompleteFilePath,strFileType);
				//Looping through all CINN numbers for validation
				for(String strCINNNumber: rowsListCINNNumbers){
					parameter1 = strCINNNumber.trim();
					reportInit("InboundFileTesting", "test834FileValidation, CINN Number:" + parameter1);
					//For retrieving CINN number specific data from 834 file
					List<String>rowsList=TestFileUtil.parse834File(strCompleteFilePath,parameter1,strFileType);
					int intSubscriber = 0;
					String line1 = "";
					flatFileValuesMap.clear();
					
					//Displaying test data mandatory values in the logger
					logger.log(LogStatus.INFO,  " CINN Number: " + parameter1);
					logger.log(LogStatus.INFO,  " Validating file name: " + strInputFileName);
					
					
					//Looping through all CINN number records to retrieve required values
					for(int i=0;i<rowsList.size();i++){
						// To validate subscriber's First name, last Name and Middle Initial
						if(rowsList.get(i).startsWith("NM1*IL*")){
							if(intSubscriber == 0){
								line1=rowsList.get(i).toString();
								line1 = line1.replace("~", "");
								flatFileValuesMap.put("LAST_NAME", line1.split("\\*")[3]);
								flatFileValuesMap.put("FIRST_NAME", line1.split("\\*")[4]);
								//flatFileValuesMap.put("MIDINIT", line1.split("\\*")[5].replace("~", ""));						
								intSubscriber = intSubscriber + 1;
							}
							
						}
						
						// To validate subscriber's Telephone Number
						if(rowsList.get(i).startsWith("PER*IP*")){			
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							flatFileValuesMap.put("TELEPHONE", line1.split("\\*")[4].replace("~", ""));	
						}
				
						// To validate subscriber's Address
						if(rowsList.get(i).startsWith("N3*")){			
							line1=rowsList.get(i).toString();
						
							line1 = line1.replace("~", "");
							flatFileValuesMap.put("ADDRESS1", line1.split("\\*")[1].substring(0).replace("~", ""));					
							//String strAddress = line1.split("\\*")[1];
							flatFileValuesMap.put("ADDRESS2", line1.split("\\*")[1].substring(0).replace("~", ""));
						}
			
						
						// To validate subscriber's City, State, Zipcode
						if(rowsList.get(i).startsWith("N4*")){			
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							flatFileValuesMap.put("CITY", line1.split("\\*")[1]);
							flatFileValuesMap.put("STATE", line1.split("\\*")[2]);
							flatFileValuesMap.put("ZIPCODE", line1.split("\\*")[3].replace("~", ""));
						}
						
						// To validate subscriber's DOB and Gender
						if(rowsList.get(i).startsWith("DMG*")){			
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							flatFileValuesMap.put("DOB", line1.split("\\*")[2]);
							flatFileValuesMap.put("SEX", line1.split("\\*")[3].replace("~", ""));
						}
			
						// To validate subscriber's AID Code for LACare
						if(rowsList.get(i).startsWith("HD*021*")){	
							if(strFileType.equalsIgnoreCase("LACare"))
							{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MECD_MCTR_AIDC1", line1.split("\\*")[4].substring(0,2).replace("~", ""));
							}
						}
					
						
						// To validate subscriber's AID Code for LACare-SD
						if(rowsList.get(i).startsWith("REF*3H*")){	
							if(strFileType.equalsIgnoreCase("LACareSD"))
							{
								line1=rowsList.get(i).toString();
								line1 = line1.replace("~", "");					
								flatFileValuesMap.put("MECD_MCTR_AIDC2", line1.split("\\*")[2].substring(3,5).replace("~", ""));
							}
						}
						// To validate subscriber's AID Code for LACare-SD
						if(rowsList.get(i).startsWith("REF*CE*")){	
							if(strFileType.equalsIgnoreCase("LACareSD"))
							{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MECD_MCTR_AIDC3", line1.split("\\*")[2].substring(0,3).replace("~", ""));
							}
						}
						
						// To validate subscriber's AID Code for DHCS
						if(rowsList.get(i).startsWith("REF*3H*")){
							if(strFileType.equalsIgnoreCase("CMCLA") || strFileType.equalsIgnoreCase("CMCSD"))
							{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MECD_MCTR_AIDC4", line1.split("\\*")[3].replace("~", ""));
							}
						}
						
						// To validate subscriber's AID Code for DHCS
						if(rowsList.get(i).startsWith("REF*CE*")){
							if(strFileType.equalsIgnoreCase("CMCLA") || strFileType.equalsIgnoreCase("CMCSD"))
							{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MECD_MCTR_AIDC5", line1.split("\\*")[2].replace("~", ""));
							}
						}
						
						
						// To validate Family Link id for LACare
						if(rowsList.get(i).startsWith("REF*3H*")){			
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MEME_FAM_LINK_ID", line1.split("\\*")[2].replace("~", ""));			
						}
						
						// To validate Family Link id for DHCS
						/*if(rowsList.get(i).startsWith("REF*3H*")){			
							String line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MEME_FAM_LINK_ID", line1.split("\\*")[4].substring(0,7).replace("~", ""));			
						}*/
						
						// To validate Subscriber's Effective Date				
						/*if(rowsList.get(i).startsWith("DTP*303")){			
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("SubEffDate", line1.split("\\*")[3].replace("~", ""));			
						}*/
						// To validate PCP information for LACare
						//This filed validation is still in progress
						/*if(rowsList.get(i).startsWith("PER*IC*")){
							if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834"))
							{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							String strPCPInput = line1.split("\\*")[4].substring(15, 27).trim();
							Map<String,String> flatFileDBDataMap = new HashMap <String,String>();
							strOtherQueries = strOtherQueries.replaceAll("Parameter1", strPCPInput);
							
							flatFileDBDataMap = dbUtils.resultSetToDictionary(strOtherQueries);//
							
							
							flatFileValuesMap.put("PRPR_ID", flatFileDBDataMap.get("PRPR_ID"));
							}
						}*/
						
						
					}	
						
					
					
					//Replacing Parameter1 data with CINN Number
					String	SqlQueries=queryFromDataSheet.replace( "Parameter1",parameter1.trim());
					logger.log(LogStatus.INFO,  " Queries used to retrive data from database: " + SqlQueries);
					//To retrieve query data from database
					List<Map<String,String>> listQueryDataMap = dbUtils.resultSetToDictionary(SqlQueries);//queryDataMap
					
					//Checking for the data in database
					if(listQueryDataMap.size() > 0){
						//Storing 1st record values for comparison
						queryDataMap = listQueryDataMap.get(0);
					}
					//Logging statement when data is not present in database
					else{
						logger.log(LogStatus.FAIL, "Data is NOT present in the database for this CINN Number:" + parameter1);
					}
					
					//Comparing source and target values with soft assertion logic
					OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssert);
				}
			}
			
		
			 } catch (Exception e) {
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssert.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssert.assertAll();	//<== absolutely must be here
				}
				
	}


	/**
	 * //To run test method, this method will initiate the HTML report
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		//To execute test method multiple times
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
				
	}	
	
	/**
	 * DataProvider for returning the specific test data based on test method name
	 * 
	 * @param method
	 * @return
	 */
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private  Object[][] getData(Method method) throws Exception{
		Object[][] data = null;
		Map<String, String> dataMap = new HashMap<String, String>();
		//assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, method.getName());
		//storing required environment related test data into a data object
		data = new Object[][] { { dataMap } };

		return data;
		
	}


}
