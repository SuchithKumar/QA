package com.bsc.qa.facets.ffpojo.utility;

/**
 * Serhiy Malyy 
 * Class allows to locate most recent file in folder by last date/time modified
 * It enables file-based test to run and select files under test from folder and eliminates the need to hardcode file name
 * 
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.relevantcodes.extentreports.LogStatus;

public class TestFileUtil {

	String FlatFileRootDirectory;
	String InterfaceSpecoficFolder; 
	
	
	public TestFileUtil(String flatFileRootDirectory,String interfaceSpecoficFolder) {
		
		FlatFileRootDirectory = flatFileRootDirectory;
		InterfaceSpecoficFolder = interfaceSpecoficFolder;
	}

	public static File lastFileModified(String dir) {
	    File fl = new File(dir);
	    File[] files = fl.listFiles(new FileFilter() {          
	        public boolean accept(File file) {
	            return file.isFile();
	        }
	    });
	    long lastMod = Long.MIN_VALUE;
	    File choice = null;
	    for (File file : files) {
	        if (file.lastModified() > lastMod) {
	            choice = file;
	            lastMod = file.lastModified();
	        }
	    }
	    return choice; //lastFileModified
	}
	
	public File getTestFile(){
		
		String completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		
		System.out.println("Test file root directory is:" + FlatFileRootDirectory);
		System.out.println("Test file spefic directory is:" + InterfaceSpecoficFolder);
		
		File objFile = lastFileModified (completePath);
		
		return objFile;
	
	}
	
	public String getCompleteTestFilePath(){
		
		String completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		
		System.out.println("Complete path to test file is:"+ completePath);
		
		File objFile = lastFileModified (completePath);
		
		String obsPath = objFile.getAbsolutePath();	
		
		System.out.println("----------------------test File Info -------------------------------------");
		System.out.println(" ");
		System.out.println("Absolute file under test is :"+ obsPath);
		System.out.println(" ");
		System.out.println("----------------------test File Info -------------------------------------");
		return obsPath;
	
				
		
	}

	public static void copyFile(Path htmlSourcePath, Path htmlReportDestinationPath) throws IOException {
		Files.copy(htmlSourcePath, htmlReportDestinationPath,StandardCopyOption.REPLACE_EXISTING);	
		
		
	}

public static  List<Map<String,String>> parseFileWithDelimeter(String testFlatFileCompletePath) throws IOException{
	
			 //String testFlatFileCompletePath="\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\SUC automation\\Required Documents\\12. SUC546265-DRX To MAM\\MAPDP_Complete_2018_20180401.bsc180401111900.txt";
			 File inputFile = new File(testFlatFileCompletePath);
			 List<Map<String,String>> listOfRows=new ArrayList<Map<String,String>>();
			 String line=null;
			 String cvsSplitBy = "\t";
			 List<String[]> rowsList=new ArrayList<String[]>();
		 	 if (!inputFile.exists()) { 
		 		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			  } else {
								System.out.println("Starting of File Reading . . . . . .  . . . . ");
								FileReader fileReader =  new FileReader(testFlatFileCompletePath);
								BufferedReader bufferedReader =        new BufferedReader(fileReader);
									
						        while((line = bufferedReader.readLine()) != null) {
					                String[] columnsArray = line.split(cvsSplitBy);
					                rowsList.add(columnsArray);
						       		}   
						       //  Map map=new HashMap();
						       String[] columns=rowsList.get(0);
						       int numberOfRows=rowsList.size();
						      //  int columnLength=rowsList.get(0).length;
								
						      for(int rowNo=1;rowNo<numberOfRows;rowNo++){
									Map<String,String> rowMap=new HashMap<String,String>();
									int columnLength=rowsList.get(rowNo).length-1;
									//System.out.println("rowNo:"+rowNo);
									int TotalColumnLength = columns.length;
									String str="";
									for(int i=0;i<TotalColumnLength-1;i++){
										
										
										if(i>columnLength){
											//System.out.println("if i:"+i+"| currennt row:"+rowsList.get(rowNo).length);
											 str="";
										}else{
											//System.out.println("else i:"+i+"| currennt row:"+rowsList.get(rowNo).length);
											 str=rowsList.get(rowNo)[i];		
										}
										
										rowMap.put(columns[i].toUpperCase(), str);	//System.out.println(rowNo+"  columnlength::"+columnLength+" index: "+i+"  "+rowsList.get(rowNo)[i]);
									}
									listOfRows.add(rowMap);
							}
		    	}
		 	return listOfRows;
}

public static  Map<String,String> getRowMap(String primaryKeyColumnName, String primaryKeyValue, List<Map<String, String>> rowsList) {

		for(Map<String,String> map:rowsList){
			if(primaryKeyValue.equals(map.get(primaryKeyColumnName))){
				return map;
				}
			}
	return null;
}


//To retrieve single rows with matching two key value
public static  Map<String,String> getRowMapWithTwoColumnValues(String primaryKeyColumnName, String primaryKeyValue,String secondaryKeyColumnName,String secondaryKeyValue, List<Map<String, String>> rowsList) {
       Map<String,String> map =new HashMap<String,String>();
       for(Map<String,String> rowMap:rowsList){
              if(primaryKeyValue.equals(rowMap.get(primaryKeyColumnName)) && secondaryKeyValue.equals(rowMap.get(secondaryKeyColumnName))){
                     return rowMap;
                     }
              }
return map;
}

// To retrieve multiple rows with matching key value
public static List< Map<String,String>> getMultiRowMap(String primaryKeyColumnName, String primaryKeyValue, List<Map<String, String>> rowsList) {

       List<Map<String,String>>listOfRecords=new ArrayList<Map<String,String>>();//list or all records in flat files
       for(Map<String,String> map:rowsList){
              if(primaryKeyValue.equals(map.get(primaryKeyColumnName))){
                     listOfRecords.add(map);
                     
                     }
              }
       return listOfRecords;

}
public static  List<String> parse837FileBackup(String testFlatFileCompletePath,String claimId) throws IOException{
	
	 File inputFile = new File(testFlatFileCompletePath);
	 List<Map<String,String>> listOfRows=new ArrayList<Map<String,String>>();
	 String line=null;
	 List<String> rowsList=new ArrayList<String>();
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
						System.out.println("Starting of File Reading . . . . . .  . . . . ");
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						BufferedReader bufferedReader =        new BufferedReader(fileReader);
						boolean flag=false;
				        while((line = bufferedReader.readLine()) != null) {
				        	System.out.println("Line:"+line);
				        	if(line.contains(claimId)){
				        		flag=true;
				        	}
				        	if(line.startsWith("ST")){
				        		if(flag){
				        			break;
				        		}else{
				        			rowsList.clear();
				        		}
				        	}
				        	rowsList.add(line);
				       		}   
   	}
	return rowsList;
}



public static  List<String> parse837File(String testFlatFileCompletePath,String claimId) throws IOException{
	
	 List<Map<String,String>> listOfRows=new ArrayList<Map<String,String>>();
	 String line=null;
	 List<String> rowsList=new ArrayList<String>();
	if(testFlatFileCompletePath.substring(testFlatFileCompletePath.length()-4, testFlatFileCompletePath.length()).equalsIgnoreCase(".837") || testFlatFileCompletePath.substring(testFlatFileCompletePath.length()-4, testFlatFileCompletePath.length()).equalsIgnoreCase(".txt"))
	{
		
		 File inputFile = new File(testFlatFileCompletePath);

		 if (!inputFile.exists()) { 
			  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
		  } else {
							System.out.println("Starting of File Reading . . . . . .  . . . . ");
							FileReader fileReader =  new FileReader(testFlatFileCompletePath);
							BufferedReader bufferedReader =        new BufferedReader(fileReader);
							boolean flag=false;
					        while((line = bufferedReader.readLine()) != null) {
					        	System.out.println("Line:"+line);
					        	if(line.contains(claimId)){
					        		flag=true;
					        	}
					        	if(line.startsWith("ST")){
					        		if(flag){
					        			break;
					        		}else{
					        			rowsList.clear();
					        		}
					        	}
					        	rowsList.add(line);
					       		}   
	  	}
		
	}
	
	else if(testFlatFileCompletePath.substring(testFlatFileCompletePath.length()-4, testFlatFileCompletePath.length()).equalsIgnoreCase(".Dat"))
	{
		
	}
	else
	{
		System.out.println("Error: Please enter valid file format in test data sheet ");
		//logger.log(LogStatus.FAIL, "Please enter valid file format in test data sheet ");
	}

	return rowsList;
}

}
