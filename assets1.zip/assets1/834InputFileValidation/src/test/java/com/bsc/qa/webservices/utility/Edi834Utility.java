package com.bsc.qa.webservices.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody;
//import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.readers.BscaCare1stMMFlatFileReader;
import com.bsc.qa.framework.utility.DBUtils;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;




/*
 * Edi834Utility class that gets fields data from 834 file to be used for 834 file validation.
 * @author Automation team
 *
 */

public class Edi834Utility{
	public static BscaCare1stMMFlatFileReader ffpExtract;
	public static int flag=1;
	public static int flag1=0;
	public static int flag2=1;
	public static int flag3=1;
	public static int flag4=1;
	public static int flag6=1;
	
	/*
	 *For getting 834 file data from 834 EDI file
	 * @param strCompleteFilePath: 834 file path
	 * @param strInputFileName: 834 file name
	 * @return
	 * @throws IOException 
	 * @throws Exception: To capture the exception
	 */
	
	public SortedMap<String, SortedMap<String, String>> get834FileData(String strCompleteFilePath, String strInputFileName,Map<String, String> data) throws Exception{
		String strFileType;
		String primaryKey;
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		SortedMap<String, String> singleRecordMap = null;
		String strFileFieldAndTableColumnMapping = "src//test//resources//FileFieldAndTableColumnMapping.xlsx";
		strCompleteFilePath = strInputFileName;
		String strOtherQueries = data.get("PCP_QUERY");
		String strSpecialIndicatorValidationQuery;
		 SortedMap<String, SortedMap<String, String>> sql1MapSpecialIndicatorValidation = null;
		 boolean blnSpecialIndDeathDateFiledValidation;
		 boolean blnDeathDateFlag = false;
		 String strDeathDate = "";
		
		String strInputExactFileName = strInputFileName.substring(strInputFileName.lastIndexOf("\\") + 1);
		// To get 834 file type
		strFileType = fileType834(strInputExactFileName);
		flatFileValuesMap = new TreeMap<String, SortedMap<String, String>>();
		
		// Checking for the 834 file type
		if (strFileType.contains("834")){
			// For capturing all CINN numbers from 834 file
			List<String> rowsListCINNNumbers = parse834FileForCINNNumbers(strCompleteFilePath, strFileType);
			
		//ID Cards changes
		//Write Content

			// Looping through all CINN numbers for validation
			for (String strCINNNumber : rowsListCINNNumbers){
				singleRecordMap = new TreeMap<String, String>();
				primaryKey = strCINNNumber.trim().toLowerCase();
				//For retrieving CINN number specific data from 834 file
				List<String> rowsList = parse834File(strCompleteFilePath, 
				primaryKey.toUpperCase(), strFileType);
				//To retrieve first subscriber section data in "NM1*IL*" segment
				int intSubscriber = 0;
				String line1 = "";
				String line2 = "";
				
				//CINN number storing in a map for comparison
				singleRecordMap.put("meme_medcd_no", strCINNNumber.trim().toLowerCase());
				
				strSpecialIndicatorValidationQuery = data.get("SPECIALINDICATORVALIDATION").replace("Parameter1", strCINNNumber.toUpperCase().trim()) ;
				sql1MapSpecialIndicatorValidation = new DBUtils().getResultSetAsSortedMap("facets",strSpecialIndicatorValidationQuery.toString().toUpperCase(), "CIN");
				blnSpecialIndDeathDateFiledValidation = false;
				if(sql1MapSpecialIndicatorValidation.containsKey((strCINNNumber.trim().toLowerCase()))){
					String dta_fld_txt = sql1MapSpecialIndicatorValidation.get(strCINNNumber.trim().toLowerCase()).get("DTA_FLD_1_TXT".toLowerCase());
					String strSpecial1 []= dta_fld_txt.split("@pSBSB_FAM_UPDATE_CD=".toLowerCase());
					String strSpecial2 [] = strSpecial1[1].split(",@pSBSB_ID=".toLowerCase());
					String strSpecialMain = strSpecial2[0].toString().replace("\"", "");
					if(strSpecialMain.equalsIgnoreCase("up")){
						blnSpecialIndDeathDateFiledValidation = true;
					}
				}
				else{
					System.out.println("We won't be able to find scenario type (New Enrollment or Update)");
				}
				
				blnDeathDateFlag = false;
				boolean blnDeathDateFirstSegemntFlag = false;
				//Looping through all CINN number records to retrieve required values				
				for (int i = 0; i < rowsList.size(); i++){
					
					//Storing field values to validate subscriber's "Death date_402" field
					if(rowsList.get(i).startsWith("DTP*357*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							try{
								 strDeathDate = line1.split("\\*")[3].replace("~", "");
								 strDeathDate = strDeathDate.toString().trim();
								 break;
								 
							}
							catch (Exception e){
								strDeathDate = "";
								break;
							}
						}
					}
					
					// Storing field values to validate subscriber's "Death date_402" field
					if(!blnDeathDateFirstSegemntFlag){
						if(rowsList.get(i).startsWith("REF*17*")){	
							blnDeathDateFirstSegemntFlag = true;
							if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
								|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
								line1=rowsList.get(i).toString();
								line1 = line1.replace("~", "");	
								try{
									strDeathDate = line1.split("\\*")[2].split(";")[1];
									strDeathDate = strDeathDate.toString().trim();
									break;
								}
								catch(Exception e){
									strDeathDate = "";
									break;
								}
							}
						}
					}
				}
				
				if(!strDeathDate.equalsIgnoreCase("")){
					 blnDeathDateFlag = true;
				 }
				
				
					
				//To implement Eligibility Validations
				String line3 = "";
				String line4 = "";
				String strAidCode ="";
				String hcpStatusCode = "";
				String eligibilityDate = "";
				String hcpCode = "";
				String strTempAidCode ="";	
				String hcpTempStatusCode ="";
				String hcpTempCode = "";
				
				
				// To Validate ELIGIBILITY Scenarios for LACare file
				if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						
					flag=1;
					flag1=0;
					flag2=1;
					
						for(int k = rowsList.size()-1;k>=0;k--){
							if(rowsList.size()>0){
								if(rowsList.get(k).startsWith("COB*")){
									line1 = rowsList.get(k).toString().toLowerCase();
									line1 = line1.replace("~", "");
									hcpCode = line1.split("\\*")[2];
								}
								if(rowsList.get(k).startsWith("HD*")){
										strAidCode=rowsList.get(k).toString().split("\\*")[4].substring(19,21);
										hcpStatusCode=rowsList.get(k).toString().split("\\*")[4].substring(14,16);
										line3=rowsList.get(k+1).toString();
										hcpCode = line1.split("\\*")[2];
										
							// To Validate ELIGIBILITY Scenarios for one HD loop
									if(flag==1){
										strTempAidCode=rowsList.get(k).toString().split("\\*")[4].substring(19,21);
										hcpTempStatusCode=rowsList.get(k).toString().split("\\*")[4].substring(14,16);
										line3=rowsList.get(k+1).toString();
										eligibilityDate = line3.split("\\*")[3].substring(0,8);
										hcpTempCode = line1.split("\\*")[2];
										
										if(strTempAidCode.isEmpty() && hcpTempStatusCode.equalsIgnoreCase("00")){
											singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
											singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
											singleRecordMap.put("CSPI_ID".toLowerCase(), strTempAidCode);
											singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strTempAidCode);
											
										}
										if(hcpTempStatusCode.equalsIgnoreCase("00")){
											singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
											singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
											singleRecordMap.put("CSPI_ID".toLowerCase(), strTempAidCode);
											singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strTempAidCode);
										}
										if(!strTempAidCode.isEmpty() && hcpTempStatusCode.equalsIgnoreCase("01")){
											singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
											singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "SL");
											singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strTempAidCode);
											singleRecordMap.put("CSPI_ID".toLowerCase(), strTempAidCode);
										}
									}
									flag++;
									
				// To Validate ELIGIBILITY Scenarios for more than one HD loop
				if(rowsList.size()>1){
					if(flag>1){
						
				// To validate ELIGIBILITY - NEW-ENROLLMENT scenario
						try{
							if(hcpTempStatusCode.equalsIgnoreCase(hcpStatusCode)&&
								hcpStatusCode.equalsIgnoreCase("01")
								&& strTempAidCode.equalsIgnoreCase(strAidCode)
								&& hcpTempCode.equalsIgnoreCase(hcpCode)){
								if(flag2==1){
									try{
										String sub_effective_date;
										sub_effective_date = line3.split("\\*")[3].substring(0,8);
										singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),sub_effective_date);
										singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "SL");
										singleRecordMap.put("mecd_mctr_aidc1", "00" + strAidCode);
										singleRecordMap.put("CSPI_ID".toLowerCase(), strAidCode);
									}
									catch(Exception e){
										System.out.println("Subscriber's Effective Date, void indicator and eligibility type is not as required");
									}
								}
								flag2++;
							}
						}
						catch (Exception e){
							System.out.println("Subscriber's HCP Code, Effective Date, void indicator and eligibility type is not as required");
						}
					
						
				// To validate ELIGIBILITY - DISENROLLMENT scenario 
						try{
							if(strTempAidCode.equals(strAidCode)&&
								!hcpTempStatusCode.equalsIgnoreCase(hcpStatusCode)
								&& hcpStatusCode.equalsIgnoreCase("00") 
								|| hcpStatusCode.equalsIgnoreCase(" ")){
								line1=rowsList.get(k).toString();
								line3=rowsList.get(k+1).toString();
								line4=rowsList.get(k+2).toString();
								eligibilityDate = line3.split("\\*")[3].substring(0,8);
								singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
								singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
								singleRecordMap.put("CSPI_ID".toLowerCase(), strAidCode);
								singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00"+ strAidCode);
							break;
							}
							
						//To validate the TM scenarios	when flatFile sub_eff_date is after the DB sub_eff_date
							//(In this case we are giving a warning as the tool will handle the 13 months prior date from current month's date)
							
							if(strTempAidCode.equals(strAidCode)&&
								hcpTempStatusCode.equalsIgnoreCase(hcpStatusCode)
								&& !hcpTempCode.equalsIgnoreCase(hcpCode)){
								if(flag6==1){
									String currentEligibDate;
									currentEligibDate =line3.split("\\*")[3].substring(0,8);
									singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),currentEligibDate);
									singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
									singleRecordMap.put("CSPI_ID".toLowerCase(), strAidCode);
									singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strAidCode);
								}
								flag6++;
							}
							else{
								singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
								singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "SL");
								singleRecordMap.put("CSPI_ID".toLowerCase(), strAidCode);
								singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strAidCode);
							}
						} 
						catch(Exception e){
							System.out.println("Subscriber's HCP COde, Effective Date, void indicator and eligibility type is not as required");
						}
				
						
				// To validate ELIGIBILITY - CHANGE scenario
					try{
						if(!strTempAidCode.equals(strAidCode)
							&& hcpStatusCode.equalsIgnoreCase("01") &&
							hcpStatusCode.equalsIgnoreCase("01")){
							line1=rowsList.get(k).toString();
							line3=rowsList.get(k+1).toString();
							line4=rowsList.get(k+2).toString();
							eligibilityDate = line3.split("\\*")[3].substring(0,8);
							singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
							singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "CH");
							singleRecordMap.put("CSPI_ID".toLowerCase(), strAidCode);
							if (!line4.isEmpty()&&line4.contains("COB")){
								hcpCode = line4.split("\\*")[2];
							}
							else{
								System.out.println("COB details are not present in the file");
							}
							break;
						}
						
					} 
					catch(Exception e){
						System.out.println("Subscriber's HCP Code, Effective Date, void indicator and eligibility type is not as required");
					}
						
				
				// To validate ELIGIBILITY - REINSTATE scenario
					try{
						if(!hcpTempStatusCode.equalsIgnoreCase(hcpStatusCode)&&
							hcpStatusCode.equalsIgnoreCase("01")){
							line1=rowsList.get(k).toString();
							line3=rowsList.get(k+1).toString();
							line4=rowsList.get(k+2).toString();
							eligibilityDate = line3.split("\\*")[3].substring(0,8);
							singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
							singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "RI");
							singleRecordMap.put("cspi_id".toLowerCase(), strAidCode);
							singleRecordMap.put("mecd_mctr_aidc1", "00" + strAidCode);
							break;
						}
					}
					catch (Exception e){
						System.out.println("Subscriber's HCP Code, Effective Date, void indicator and eligibility type is not as required");
					}
			}
			flag++;
		}
	}
}
}
}

				
		// To Validate ELIGIBILITY Scenarios for LACare-SD, CMC-SD and CMC-LA files
				if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")
					|| strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") 
					|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
					
					flag2=1;
					flag=1;
					flag1=0;
					flag6=1;
					
					for(int k = rowsList.size()-1;k>=0;k--){
						if(rowsList.size()>0){
							if(rowsList.get(k).startsWith("REF*RB*")){
								line1 = rowsList.get(k).toString().toLowerCase();
								line1 = line1.replace("~", "");
								strAidCode=line1.split("\\*")[2].substring(0,2);
							}
							if(rowsList.get(k).startsWith("HD*")){
								line2 = rowsList.get(k).toString().toLowerCase();
								line2 = line2.replace("~", "");
								line3=rowsList.get(k+1).toString();
								strAidCode=line1.split("\\*")[2].substring(0,2);
								hcpStatusCode=partialStringRetrievalUsingFieldIndex("hcpStatusCode", line2, 4, "\\;", 1);
								hcpCode = partialStringRetrievalUsingFieldIndex("hcpCode", line2, 4, "\\;", 0);
								
								
					// To Validate ELIGIBILITY Scenarios for one HD loop	
								if(flag==1){
									strTempAidCode=line1.split("\\*")[2].substring(0,2);
									hcpTempStatusCode=partialStringRetrievalUsingFieldIndex("hcpTempStatusCode", line2, 4, "\\;", 1);
									line3=rowsList.get(k+1).toString();
									eligibilityDate = line3.split("\\*")[3].substring(0,8);
									hcpTempCode = partialStringRetrievalUsingFieldIndex("hcpTempCode", line2, 4, "\\;", 0);
									
									try{
										if(strTempAidCode.isEmpty() && hcpTempStatusCode.equalsIgnoreCase("00")){
											singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
											singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
											singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strTempAidCode);
											if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
												singleRecordMap.put("CSPI_ID".toLowerCase(), strTempAidCode);
											}
											else if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
												singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0001");
											}
											else if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
												singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0002");
											}
										}
										if(hcpTempStatusCode.equalsIgnoreCase("00")){
											singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
											singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
											singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strTempAidCode);
											if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
												singleRecordMap.put("CSPI_ID".toLowerCase(), strTempAidCode);
											}
											else if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
												singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0001");
											}
											else if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
												singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0002");
											}
										}
										if(!strTempAidCode.isEmpty() && hcpTempStatusCode.equalsIgnoreCase("01")){
											singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
											singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "SL");
											singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strTempAidCode);
											if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
												singleRecordMap.put("CSPI_ID".toLowerCase(), strTempAidCode);
											}
											else if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
												singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0001");
											}
											else if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
												singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0002");
											}
										}
									}
									catch (Exception e){
										System.out.println("Subscriber's HCP Code, Effective Date, void indicator and eligibility type is not as required");
									}
								}
								flag++;								
				
				// To Validate ELIGIBILITY Scenarios for more than one HD loop
				if(rowsList.size()>1){	
					if(flag>1){
						
				// To validate ELIGIBILITY - NEW-ENROLLMENT scenario
						try{
							if(hcpTempStatusCode.equalsIgnoreCase(hcpStatusCode)&&
								hcpStatusCode.equalsIgnoreCase("01")
								&& strTempAidCode.equalsIgnoreCase(strAidCode)
								&& hcpTempCode.equalsIgnoreCase(hcpCode)){	
								
					//******************************************************************
								if(flag2==1){
									try{
										String sub_effective_date;
										sub_effective_date = line3.split("\\*")[3].substring(0,8);
										singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),sub_effective_date);
										singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "SL");
										singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strTempAidCode);
										if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
											singleRecordMap.put("CSPI_ID".toLowerCase(), strTempAidCode);
										}
										else if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
											singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0001");
										}
										else if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
											singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0002");
										}
									}
									catch(Exception e){
										System.out.println("Subscriber's Effective Date, void indicator and eligibility type is not as required");
									}
								}
								flag2++;
							}
						}
						catch (Exception e){
							System.out.println("Subscriber's HCP Code, Effective Date, void indicator and eligibility type is not as required");
						}
					
			// To validate ELIGIBILITY - DISENROLLMENT scenario 
					try{
						if(strTempAidCode.equals(strAidCode)&&
							!hcpTempStatusCode.equalsIgnoreCase(hcpStatusCode)
							&& hcpStatusCode.equalsIgnoreCase("00")
							|| hcpStatusCode.equalsIgnoreCase(" ")){
							line1=rowsList.get(k).toString();
							line3=rowsList.get(k+1).toString();
							line4=rowsList.get(k+2).toString();
							eligibilityDate = line3.split("\\*")[3].substring(0,8);
							
							singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
							singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
							singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strAidCode);
						
							if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), strAidCode);
							}
							else if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0001");
							}
							else if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0002");
							}
						break;
						}						
						
				//To validate the TM scenarios	when flatFile sub_eff_date is after the DB sub_eff_date
				//(In this case we are giving a warning as the tool will handle the 13 months prior date from current month's date)
						if(strTempAidCode.equals(strAidCode)&&
							hcpTempStatusCode.equalsIgnoreCase(hcpStatusCode)
							&& !hcpTempCode.equalsIgnoreCase(hcpCode)){
							if(flag6==1){
								String currentEligibDate;
								currentEligibDate = line3.split("\\*")[3].substring(0,8);
								if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
									if(!hcpCode.equalsIgnoreCase("167")){
										singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),currentEligibDate);
										singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
										singleRecordMap.put("CSPI_ID".toLowerCase(), strAidCode);
										singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strAidCode);
									}
								}
								else if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
									if(!hcpCode.equalsIgnoreCase("817")){
										singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),currentEligibDate);
										singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
										singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0001");
										singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strAidCode);
									}
								}
								else if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
									if(!hcpCode.equalsIgnoreCase("803")){
										singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),currentEligibDate);
										singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
										singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0002");
										singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strAidCode);
									}
								}
							}
							flag6++;
						}
						else{
							singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
							singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "SL");
							singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strAidCode);
							if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), strAidCode);
							}
							else if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0001");
							}
							else if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0002");
							}
						}
					} 
					catch(Exception e){
						System.out.println("Subscriber's HCP COde, Effective Date, void indicator and eligibility type is not as required");
					}
					
			// To validate ELIGIBILITY - CHANGE scenario
					try{
						if(!strTempAidCode.equals(strAidCode)
							&& hcpStatusCode.equalsIgnoreCase("01") && 
							hcpStatusCode.equalsIgnoreCase("01")){
							line1=rowsList.get(k).toString();
							line3=rowsList.get(k+1).toString();
							line4=rowsList.get(k+2).toString();
							eligibilityDate = line3.split("\\*")[3].substring(0,8);
							
							singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
							singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "CH");
							singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strTempAidCode);
							if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), strTempAidCode);
							}
							else if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0001");
							}
							else if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0002");
							}
							break;
						}
					} 
					catch(Exception e){
						System.out.println("Subscriber's HCP Code, Effective Date, void indicator and eligibility type is not as required");
					}
		
			
				// To validate ELIGIBILITY - REINSTATE scenario
					try{
						if(!hcpTempStatusCode.equalsIgnoreCase(hcpStatusCode)&&
							hcpStatusCode.equalsIgnoreCase("01")){
							line1=rowsList.get(k).toString();
							line3=rowsList.get(k+1).toString();
							line4=rowsList.get(k+2).toString();
							eligibilityDate = line3.split("\\*")[3].substring(0,8);
							
							singleRecordMap.put("SBEL_EFF_DT".toLowerCase(),eligibilityDate);
							singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "RI");
							singleRecordMap.put("MECD_MCTR_AIDC1".toLowerCase(), "00" + strTempAidCode);
							if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), strTempAidCode);
							}
							else if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0001");
							}
							else if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
								singleRecordMap.put("CSPI_ID".toLowerCase(), "CMCM0002");
							}
							break;
						}
					}
					catch (Exception e){
						System.out.println("Subscriber's HCP Code, Effective Date, void indicator and eligibility type is not as required");
					}
			}
			flag++;
		}
	}
}
}
}			
				
			blnDeathDateFirstSegemntFlag = false;
				
			//Displaying test data mandatory values in the logger
			//Looping through all CINN number records to retrieve required values				
			for (int i = 0; i < rowsList.size(); i++){
				//Storing field values to validate subscriber's First name, last Name and Middle initial				
				if(rowsList.get(i).startsWith("NM1*IL*")){
					if(intSubscriber == 0){
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("last_name",line1.split("\\*")[3]);
							singleRecordMap.put("first_name",line1.split("\\*")[4]);
							intSubscriber = intSubscriber + 1;
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
			

				//  Storing field values to validate subscriber's Telephone Number
				if (rowsList.get(i).startsWith("PER*IP*")){
					line1 = rowsList.get(i).toString().toLowerCase();
					line1 = line1.replace("~", "");
					try{
						singleRecordMap.put("telephone",line1.split("\\*")[4].replace("~", ""));
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}

				//  Storing field values to validate subscriber's Address
				if (rowsList.get(i).startsWith("N3*")){
					line1 = rowsList.get(i).toString().toLowerCase();
					line1 = line1.replace("~", "");	
					try{singleRecordMap.put("address1", line1.split("\\*")[1].substring(0).replace("~", ""));
					}
					catch(Exception e){
						System.out.println("Data not present for validation for homeless member");
					}
					
					//To validate the address field for Homeless member
					try{
						if((line1.split("\\*")[1].substring(0).replace("~", "")).contains("homeless")){
							singleRecordMap.put("address1", "UNK");
							singleRecordMap.put("adresss2", "[Blank]");
							singleRecordMap.put("address3","Homeless");
						}
					}
					catch(Exception e){
						System.out.println("Not a Homeless memeber");
					}
					
					//To validate the address field for P.O. Box
					String address2 = "";
					String address3 = "";
					String newString = "";
					String address1 = "";
					try{
						line1.split("\\*")[1].substring(0).replace("~", "").indexOf("APT");
						address2 = line1.split("\\*")[1].substring(0).replace("~", "").substring(line1.split("\\*")[1].substring(0).replace("~", "").indexOf("APT"));
						newString = line1.split("\\*")[1].substring(0).replace("~", "").replaceAll(address2, "");
						newString.indexOf("P.O.");
						address1 = newString.substring(newString.indexOf("P.O."));
						address3 = newString.replaceAll(address1, "");
						singleRecordMap.put("address2",address2);
						singleRecordMap.put("address3",address3);
						singleRecordMap.put("address1",address1);
					}
					catch(Exception e){
						System.out.println("P.O. Box not present in address");
					}
				}

				//  Storing field values to validate subscriber's DOB and Gender
				if (rowsList.get(i).startsWith("DMG*")){
					line1 = rowsList.get(i).toString().toLowerCase();
					line1 = line1.replace("~", "");
					try{
						singleRecordMap.put("dob",line1.split("\\*")[2]);
						singleRecordMap.put("sex",line1.split("\\*")[3].replace("~", ""));
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
				
			//  Storing field values to validate subscriber's City for LACare
				if (rowsList.get(i).startsWith("N4*")) {
					if (strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("city", line1.split("\\*")[1]);
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
			//  Storing field values to validate subscriber's City for LACare-SD
				if (rowsList.get(i).startsWith("N4*")) {
					if (strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("city", line1.split("\\*")[1].substring(0,2).replace("~", ""));
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
			//  Storing field values to validate subscriber's City, State, ZipCode
				if (rowsList.get(i).startsWith("N4*")){
					line1 = rowsList.get(i).toString().toLowerCase();
					line1 = line1.replace("~", "");
					try{
						singleRecordMap.put("city", line1.split("\\*")[1]);
						singleRecordMap.put("state", line1.split("\\*")[2]);
						singleRecordMap.put("zipcode", line1.split("\\*")[3].replace("~", ""));
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
				
			//  Storing field values to validate subscriber's HICN
				if(rowsList.get(i).startsWith("REF*F6")){
					if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
							line1 = rowsList.get(i).toString().toLowerCase();
							line1 = line1.replace("~", "");
							try{
								singleRecordMap.put("MEME_HICN".toLowerCase(), line1.split("\\*")[2]);
							}
							catch(Exception e){
									System.out.println("Data not present for validation");
							}
					}
				}
				
			//  Storing field values to validate subscriber's MEMD_EVENT_CD - HICN
				if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
					|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
					try{	
						singleRecordMap.put("HICN_MEMD_EVENT_CD".toLowerCase(), "HICN");
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
				
			//  Storing field values to validate subscriber's MEMD_EVENT_CD - PBP
				if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
					|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
					try{	
						singleRecordMap.put("PBP_MEMD_EVENT_CD".toLowerCase(), "PBP");
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
			
			//  Storing field values to validate subscriber's MEMD_EVENT_CD - PBP (lA)
				if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
					try{	
						singleRecordMap.put("MEMD_MCTR_PBP".toLowerCase(), "002");
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
			
			//  Storing field values to validate subscriber's MEMD_EVENT_CD - PBP (SD)
				if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
					try{	
						singleRecordMap.put("MEMD_MCTR_PBP".toLowerCase(), "001");
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
				 
			//  Storing field values to validate subscriber's MEMD_EVENT_CD - PARTD
				if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
					|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
					try{	
						singleRecordMap.put("PRTD_MEMD_EVENT_CD".toLowerCase(), "PRTD");
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
			
				//  Storing field values to validate subscriber's MEMD_EVENT_CD - SCCC
				if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
					|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
					try{	
						singleRecordMap.put("SCCC_MEMD_EVENT_CD".toLowerCase(), "SCCC");
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
				
			//  Storing field values to validate subscriber's MEMD_MCTR_MCST and MEMD_MCTR_MCCT - SCCC (LA)
				if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
					try{	
						singleRecordMap.put("SCCC_MEMD_MCTR_MCST".toLowerCase(), "05");
						singleRecordMap.put("SCCC_MEMD_MCTR_MCCT".toLowerCase(), "210");
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
						
			//  Storing field values to validate subscriber's MEMD_MCTR_MCST and MEMD_MCTR_MCCT - SCCC (SD)
				if(strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
					try{	
						singleRecordMap.put("SCCC_MEMD_MCTR_MCST".toLowerCase(), "05");
						singleRecordMap.put("SCCC_MEMD_MCTR_MCCT".toLowerCase(), "470");
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
				
			//  Storing field values to validate VOID INDICATOR for NEW-ENROLLMENT Scenarios
				singleRecordMap.put("SBEL_VOID_IND".toLowerCase(), "N");
			
			// Storing field values to validate Family Link id for LACare
				if (rowsList.get(i).startsWith("REF*3H*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						try{
							String strValue = partialStringRetrieval("MEME_FAM_LINK_ID".toLowerCase(),line1,2,0,0);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("MEME_FAM_LINK_ID".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
				// Storing field values to validate Family Link id for LACare-SD, LACounty_Cal-MediConnect_Members(DHCS)834, SDCounty_Cal-MediConnect_Members(DHCS)834
				if (rowsList.get(i).startsWith("REF*3H*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") || strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("MEME_FAM_LINK_ID".toLowerCase(), line1, 2, "\\;", 2);
							if(!(strValue.equalsIgnoreCase(""))){
								strValue=strValue.substring(0,7);
								singleRecordMap.put("MEME_FAM_LINK_ID".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
				// Storing field values to validate subscriber's Language
				if(rowsList.get(i).startsWith("LUI*")){
					line1=rowsList.get(i).toString();
					line1 = line1.replace("~", "");	
					try{
						//String languageFileVal = line1.split("\\*")[2];
						//languageFileVal = languageFileVal.toUpperCase();
						//singleRecordMap.put("MEME_MCTR_LANG".toLowerCase(), languageFileVal);
						singleRecordMap.put("MEME_MCTR_LANG".toLowerCase(), line1.split("\\*")[2]);
						
						/*HashMap<String, String> language = new HashMap<String, String>();
		
						// Adding elements to HashMap
						language.put("SPA", "SP01");
						language.put("CAN", "CA01");
						language.put("JPN", "JA01");
						language.put("KOR", "KO01");
						language.put("TAG", "TG01");
						language.put("ENG", "EN01");
						language.put("MAN", "MN01");
						language.put("ARM", "AM01");
						language.put("TUR", "TU01");
						language.put("HEB", "HE01");
						language.put("FRE", "FR01");
						language.put("RUS", "RU01");
						language.put("POR", "PR01");
						language.put("ITA", "IT01");
						language.put("ARA", "AR01");
						language.put("THA", "TH01");
						language.put("VIE", "VI01");
						language.put("SMO", "SM01");
						language.put("LAO", "LO01");
						language.put("POL", "PO01");
						
						if(language.containsKey(languageFileVal)){
							singleRecordMap.put("MEME_MCTR_LANG".toLowerCase(), language.get(languageFileVal));
						}
						else{
							singleRecordMap.put("MEME_MCTR_LANG".toLowerCase(), "[Blank]");
						}
		*/				/*List<String> langList = new ArrayList<String>(language.keySet());					
										
						for (int m=0;m<langList.size();m++){
							if(langList.get(m).equalsIgnoreCase(singleRecordMap.put("MEME_MCTR_LANG".toLowerCase(), languageFileVal))){
								System.out.println("print encoded value " +language.get(langList.get(m)));
							}
							singleRecordMap.put("MEME_MCTR_LANG".toLowerCase(), language.get(langList.get(m)));
						}*/
					}
					catch(Exception e){
						System.out.println("Incorrect Language data in file");
					}
				}
				
			// Storing field values to validate subscriber's ETHNICITY
				if(rowsList.get(i).startsWith("DMG*")){
					line1=rowsList.get(i).toString();					
					line1 = line1.replace("~", "");
					try{
						if(line1.split("\\*")[5].length()>6){
						singleRecordMap.put("MEME_MCTR_ETHN_NVL".toLowerCase(),line1.split("\\*")[5].substring(5,11).replace("~", ""));
						}
					}
					catch(Exception e){
						System.out.println("Incorrect Ethnicity data in file");
					}
				}
				
				
				//***********Storing field values to validate subscriber's Special Indicator Fields in LACare************

				//Storing field values to validate subscriber's "CCS GHPP indicator_401" field
				if(!blnSpecialIndDeathDateFiledValidation){
					
		
				if(rowsList.get(i).startsWith("REF*ZZ*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							singleRecordMap.put("CCS GHPP indicator_401".toLowerCase(), line1.split("\\*")[2].replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				}

				if((blnSpecialIndDeathDateFiledValidation && blnDeathDateFlag)
					|| (!blnSpecialIndDeathDateFiledValidation)){
					//Storing field values to validate subscriber's "Death date_402" field
					if(rowsList.get(i).startsWith("DTP*357*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							try{
								singleRecordMap.put("Death date_402".toLowerCase(), line1.split("\\*")[3].replace("~", ""));
							}
							catch (Exception e){
								System.out.println("Death Date_402 not present");
							}
						}
					}
				}
				
				
				if(!blnSpecialIndDeathDateFiledValidation){
				// Storing field values to validate subscriber's "Primary Aid Code_403" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("Primary Aid Code_403".toLowerCase(),line1,4,0,2);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Primary Aid Code_403".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				

				// Storing field values to validate subscriber's "Primary ESC_404" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							String strValue = partialStringRetrieval("Primary ESC_404".toLowerCase(),line1,4,2,5);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Primary ESC_404".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}
				

				// Storing field values to validate subscriber's "Special Aid Code1_405" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("Special Aid Code1_405".toLowerCase(),line1,4,5,7);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Special Aid Code1_405".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}	
					}
				}	
				

				// Storing field values to validate subscriber's "Special Aid Code2_406" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("Special Aid Code2_406".toLowerCase(),line1,4,7,9);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Special Aid Code2_406".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}	
				

				// Storing field values to validate subscriber's "Special Aid Code3_407" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							String strValue = partialStringRetrieval("Special Aid Code3_407".toLowerCase(),line1,4,9,11);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Special Aid Code3_407".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}

				// Storing field values to validate subscriber's "OHC Code_408" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("OHC Code_408".toLowerCase(),line1,4,11,12);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("OHC Code_408".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}

				// Storing field values to validate subscriber's "HCP Status_410" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("HCP Status_410".toLowerCase(),line1,4,14,16);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("HCP Status_410".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Primary County_411" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("Primary County_411".toLowerCase(),line1,4,21,23);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Primary County_411".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}

				// Storing field values to validate subscriber's "MEDICARE Part D_412" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("Medicare Part D_412".toLowerCase(),line1,4,23,24);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Medicare Part D_412".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Federal Contract Number_413" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("Federal Contract Number_413".toLowerCase(),line1,4,24,29);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Federal Contract Number_413".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Carrier Code_414" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("Carrier Code_414".toLowerCase(),line1,4,29,33);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Carrier Code_414".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}

				// Storing field values to validate subscriber's "Policy Start Date_415" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("Policy Start Date_415".toLowerCase(),line1,4,33,41);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Policy Start Date_415".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}

				// Storing field values to validate subscriber's "ETO Transaction Code Qualifier Code_416" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("ETO Transaction Code Qualifier Code_416".toLowerCase(),line1,4,41,43);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("ETO Transaction Code Qualifier Code_416".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}

				// Storing field values to validate subscriber's "BAS Indicator_417" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("CBAS Indicator_417".toLowerCase(),line1,4,43,44);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("CBAS Indicator_417".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "MEDI-CAL Participation Indicator_418" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("Medi-Cal Participation Indicator_418".toLowerCase(),line1,4,44,45);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Medi-Cal Participation Indicator_418".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}

				// Storing field values to validate subscriber's "CCI Opt out Indicator_419" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("CCI Opt out Indicator_419".toLowerCase(),line1,4,45,46);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("CCI Opt out Indicator_419".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}				
				}

				// Storing field values to validate subscriber's "ESRD Indicator_420" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("CESRD Indicator_420".toLowerCase(),line1,4,46,47);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("ESRD Indicator_420".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}

				// Storing field values to validate subscriber's "Part D LIS Indicator_421" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("Part D LIS Indicator_421".toLowerCase(),line1,4,47,48);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Part D LIS Indicator_421".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}	
				}

				// Storing field values to validate subscriber's "CCI Exclusion Indicator_422" field
				if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("CCI Exclusion Indicator_422".toLowerCase(),line1,4,48,49);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("CCI Exclusion Indicator_422".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Nursing Facility Resident_423" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("Nursing Facility Resident_423".toLowerCase(),line1,4,49,50);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Nursing Facility Resident_423".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}	

				// Storing field values to validate subscriber's "SI-NSI indicator_424" field
				if(rowsList.get(i).startsWith("REF*XX1*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("SI-NSI indicator_424".toLowerCase(),line1,2,2,3);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("SI-NSI indicator_424".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "HCBS HIGH indicator_425" field
				if(rowsList.get(i).startsWith("REF*XX1*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("HCBS HIGH indicator_425".toLowerCase(),line1,2,3,4);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("HCBS HIGH indicator_425".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Sub-plan Indicator_426" field
				if(rowsList.get(i).startsWith("REF*XX1*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");					
						String strValue = partialStringRetrieval("Subplan Indicator_426".toLowerCase(),line1,2,0,2);
						if(!(strValue.equalsIgnoreCase(""))){
							singleRecordMap.put("Subplan Indicator_426".toLowerCase(),strValue);
						}
					}	
				}

				// Storing field values to validate subscriber's "Part D LIS Reassignee Indicator_427" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrieval("Part D LIS Reassignee Indicator_427".toLowerCase(),line1,4,47,48);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Part D LIS Reassignee Indicator_427".toLowerCase(),strValue);
							}
						}	
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "MEDS ID_428" field
				if(rowsList.get(i).startsWith("REF*0F*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							singleRecordMap.put("MEDS ID_428".toLowerCase(), line1.split("\\*")[2].replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Prior MEDS ID_429" field
				if(rowsList.get(i).startsWith("REF*Q4*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							singleRecordMap.put("Prior MEDS ID_429".toLowerCase(), line1.split("\\*")[2].substring(0,9).replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Family Budget Unit & Person Number_430" field
				if(rowsList.get(i).startsWith("REF*1L*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							String strValue = partialStringRetrieval("Family Budget Unit & Person Number_430".toLowerCase(),line1,2,11,14);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Family Budget Unit & Person Number_430".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				//From 431 to 436 it is not applicable for LACare			

				// Storing field values to validate subscriber's "Last Premium paid date_438" field
				if(rowsList.get(i).startsWith("DTP*543*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
						singleRecordMap.put("Last Premium paid date_438".toLowerCase(), line1.split("\\*")[2].replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "SOC Amount_439" field
				if(rowsList.get(i).startsWith("AMT*C1*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("SOC Amount_439".toLowerCase(), line1.split("\\*")[2].replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Institutional Indicator_441" field
				if(rowsList.get(i).startsWith("REF*XXI*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("Institutional Indicator_441",line1,2,0,5);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Institutional Indicator_441".toLowerCase(),strValue);
							}
						}	
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Restriction_442" field
				if(rowsList.get(i).startsWith("HD*01*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("Restriction_442",line1,2,16,19);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Restriction_442".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "MEDS Renewal Date_443" field
				if(rowsList.get(i).startsWith("DTP*03*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							singleRecordMap.put("MEDS Renewal Date_443".toLowerCase(), line1.split("\\*")[3].replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				/*// Storing field values to validate subscriber's "Card Issue Date_444" field
				-- We are not validating this fields because as discussed with functional team this field is not present in Special Indicator Custom Table Mapping sheet--
				if(rowsList.get(i).startsWith("DTP*473*")){	
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							singleRecordMap.put("Card Issue Date_444".toLowerCase(), line1.split("\\*")[3].replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}*/
								
				//***********Storing field values too validate Special Indicator Fields in DHCS************

				// Storing field values to validate subscriber's "CCS GHPP indicator_401" field
				if(rowsList.get(i).startsWith("REF*6O*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("CCS GHPP indicator_401".toLowerCase(), line1.split("\\*")[2].split(";")[0]);
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
			}

				if((blnSpecialIndDeathDateFiledValidation && blnDeathDateFlag)
					|| (!blnSpecialIndDeathDateFiledValidation)){
				// Storing field values to validate subscriber's "Death date_402" field
					if(!blnDeathDateFirstSegemntFlag){
						if(rowsList.get(i).startsWith("REF*17*")){	
							blnDeathDateFirstSegemntFlag = true;
							if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
									|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
								line1=rowsList.get(i).toString();
								line1 = line1.replace("~", "");	
								try{ 			
									String strValue = partialStringRetrievalUsingFieldIndex("Death date_402".toLowerCase(), line1,2,"\\;",1);
									if(!(strValue.equalsIgnoreCase(""))){
										singleRecordMap.put("Death date_402".toLowerCase(),strValue);
									}
								}
								catch(Exception e){
									System.out.println("Data not present for validation");
								}
							}
						}
					}
				}

				
				if(!blnSpecialIndDeathDateFiledValidation){
				// Storing field values to validate subscriber's "Primary Aid Code_403" field
				if(rowsList.get(i).startsWith("REF*CE*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Primary Aid Code_403", line1, 2, "\\;", 0);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Primary Aid Code_403".toLowerCase(),strValue);
							}
						}	
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Primary ESC_404" field
				if(rowsList.get(i).startsWith("REF*CE*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Primary ESC_404", line1, 2, "\\;", 1);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Primary ESC_404".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Special Aid Code1_405" field
				if(rowsList.get(i).startsWith("REF*CE*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Special Aid Code1_405", line1, 2, "\\;", 2);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Special Aid Code1_405".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Special Aid Code2_406" field
				if(rowsList.get(i).startsWith("REF*CE*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Special Aid Code2_406", line1, 2, "\\;", 4);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Special Aid Code2_406".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Special Aid Code3_407" field
				if(rowsList.get(i).startsWith("REF*CE*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Special Aid Code3_407", line1, 2, "\\;", 6);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Special Aid Code3_407".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "OHC Code_408" field
				if(rowsList.get(i).startsWith("REF*17*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("OHC Code_408", line1, 2, "\\;", 0);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("OHC Code_408".toLowerCase(),strValue);
							}
						}	
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "HCP Status_410" field
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("HCP Status_410".toLowerCase(),line1,4,4,6);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("HCP Status_410".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Primary County_411" field
				if(rowsList.get(i).startsWith("N4*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							singleRecordMap.put("Primary County_411".toLowerCase(), line1.split("\\*")[6].substring(0,2).replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "MEDICARE Part D_412" field
				if(rowsList.get(i).startsWith("REF*9V")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");					
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Medicare Part D_412", line1, 2, "\\;", 2);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Medicare Part D_412".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Federal Contract Number_413" field
				if(rowsList.get(i).startsWith("REF*DX*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("Federal Contract Number_413".toLowerCase(),line1,2,0,1);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Federal Contract Number_413".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Carrier Code_414" field
				if(rowsList.get(i).startsWith("REF*DX*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Carrier Code_414", line1, 2, "\\;", 1);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Carrier Code_414".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Policy Start Date_415" field
				if(rowsList.get(i).startsWith("REF*DX*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Policy Start Date_415", line1, 2, "\\;", 2);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Policy Start Date_415".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "ETO Transaction Code Qualifier Code_416" field -- This field is NA --
				if(rowsList.get(i).startsWith("HD*021*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrieval("ETO Transaction Code Qualifier Code_416".toLowerCase(),line1,4,41,43);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("ETO Transaction Code Qualifier Code_416".toLowerCase(),strValue);
							}	
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "BAS Indicator_417" field
				if(rowsList.get(i).startsWith("REF*17**")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("CBAS Indicator_417", line1, 2, "\\;", 1);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("CBAS Indicator_417".toLowerCase(),strValue);
							}	
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "MEDI-CAL Participation Indicator_418" field
				if((rowsList.get(i).startsWith("REF*17*N*")) 
					|| (rowsList.get(i).startsWith("REF*17*N*"))){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Medi-Cal Participation Indicator_418", line1, 2, "\\;", 2);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Medi-Cal Participation Indicator_418".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "CCI Opt out Indicator_419" field
				if(rowsList.get(i).startsWith("REF*17*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("CCI Opt out Indicator_419", line1, 2, "\\;", 3);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("CCI Opt out Indicator_419".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}


				// Storing field values to validate subscriber's "ESRD Indicator_420" field
				if(rowsList.get(i).startsWith("REF*17*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("ESRD Indicator_420", line1, 2, "\\;", 4);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("ESRD Indicator_420".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Part D LIS Indicator_421" field
				if(rowsList.get(i).startsWith("REF*17*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Part D LIS Indicator_421", line1, 2, "\\;", 5);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Part D LIS Indicator_421".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "CCI Exclusion Indicator_422" field
				if(rowsList.get(i).startsWith("REF*17*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("CCI Exclusion Indicator_422", line1, 2, "\\;", 6);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("CCI Exclusion Indicator_422".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Nursing Facility Resident_423" field
				if(rowsList.get(i).startsWith("REF*17*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Nursing Facility Resident_423", line1, 2, "\\;", 7);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Nursing Facility Resident_423".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "SI-NSI indicator_424" field
				if(rowsList.get(i).startsWith("REF*17*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("SI-NSI indicator_424", line1, 2, "\\;", 8);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("SI-NSI indicator_424".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "HCBS HIGH indicator_425" field
				if(rowsList.get(i).startsWith("REF*17*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("HCBS HIGH indicator_425", line1, 2, "\\;", 9);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("HCBS HIGH indicator_425".toLowerCase(),strValue);
							}
						}	
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Sub-plan Indicator_426" field
				if(rowsList.get(i).startsWith("REF*17*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Subplan Indicator_426", line1, 2, "\\;", 11);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Subplan Indicator_426".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Part D LIS Reassignee Indicator_427" field
				if(rowsList.get(i).startsWith("REF*17*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Part D LIS Reassignee Indicator_427", line1, 2, "\\;", 5);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Part D LIS Reassignee Indicator_427".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "MEDS ID_428" field
				if(rowsList.get(i).startsWith("REF*1L*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							singleRecordMap.put("MEDS ID_428".toLowerCase(), line1.split("\\*")[2].replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Prior MEDS ID_429" field
				if(rowsList.get(i).startsWith("REF*Q4*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
						|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Prior MEDS ID_429", line1, 2, "\\;", 0);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Prior MEDS ID_429".toLowerCase(),strValue);
							}			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Family Budget Unit & Person Number_430" field
				if(rowsList.get(i).startsWith("REF*3H*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Family Budget Unit & Person Number_430".toLowerCase(),line1,2,"\\;",2);
							strValue = strValue.substring(strValue.length()-3);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Family Budget Unit & Person Number_430".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Residence Address Flag_431" field
				if(rowsList.get(i).startsWith("REF*6O*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Residence Address Flag_431".toLowerCase(),line1,2,"\\;",1);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Residence Address Flag_431".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Residence Address Indicator_432" field
				if(rowsList.get(i).startsWith("REF*6O*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Residence Address Indicator_432".toLowerCase(),line1,2,"\\;",2);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Residence Address Indicator_432".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Mailing Address Flag_433" field
				if(rowsList.get(i).startsWith("REF*6O*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Mailing Address Flag_433".toLowerCase(),line1,2,"\\;",3);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Mailing Address Flag_433".toLowerCase(),strValue);
							}	
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Residence Zip Delivery Code_434" field
				if(rowsList.get(i).startsWith("REF*6O*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Residence Zip Delivery Code_434".toLowerCase(),line1,2,"\\;",4);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Residence Zip Delivery Code_434".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Mailing Zip delivery code_435" field
				if(rowsList.get(i).startsWith("REF*6O*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Mailing Zip delivery code_435".toLowerCase(),line1,2,"\\;",5);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Mailing Zip delivery code_435".toLowerCase(),strValue);
							}	
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Personal ID Number_436" field
				if(rowsList.get(i).startsWith("REF*ABB*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							singleRecordMap.put("Personal ID Number_436".toLowerCase(), line1.split("\\*")[2].replace("~", ""));			
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Values to validate subscriber's Maintenance Effective_437 and Last Premium paid date_438 fields is not applicable			

				// Storing field values to validate subscriber's "SOC Amount_439" field
				if(rowsList.get(i).startsWith("AMT*R*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
						singleRecordMap.put("SOC Amount_439".toLowerCase(), line1.split("\\*")[2].replace("~", ""));			
					}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "SOC certification day_440" field
				if(rowsList.get(i).startsWith("REF*ZZ*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("SOC certification day_440".toLowerCase(),line1,2,"\\;",1);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("SOC certification day_440".toLowerCase(),strValue);
							}	
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Storing field values to validate subscriber's "Institutional Indicator_441" field
				if(rowsList.get(i).startsWith("REF*17*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Institutional Indicator_441".toLowerCase(),line1,2,"\\;",10);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Institutional Indicator_441".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				// Values to validate subscriber's "Restriction_442" field is not applicable				

				// Storing field values to validate subscriber's "MEDS Renewal Date_443" field
				if(rowsList.get(i).startsWith("REF*17*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");		
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("MEDS Renewal Date_443".toLowerCase(), line1,2,"\\;",2);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("MEDS Renewal Date_443".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}

				/*// Storing field values to validate subscriber's "Card Issue Date_444" field
			    -- We are not validating this fields because as discussed with functional team this field is not present in Special Indicator Custom Table Mapping sheet--
				if(rowsList.get(i).startsWith("REF*23*")){
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
							|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							String strValue = partialStringRetrievalUsingFieldIndex("Card Issue Date_444".toLowerCase(), line1,2,"\\;",1);
							if(!(strValue.equalsIgnoreCase(""))){
								singleRecordMap.put("Card Issue Date_444".toLowerCase(),strValue);
							}
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}*/
			}
				
				// Storing field values to validate PCP information for LACare
				if(rowsList.get(i).startsWith("PER*IC*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("PRPR_ID".toLowerCase(),line1.split("\\*")[4].substring(15,29).replace("~", ""));
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
				// Storing field values to validate PCP information for LACare-SD, CMCLA and CMCSD
				if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
					|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
					try{
						singleRecordMap.put("PRPR_ID".toLowerCase(),"[Blank]");
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
			}
			
			//Storing all subscriber filed values map as a value and subscriber id as key
			flatFileValuesMap.put(primaryKey, singleRecordMap);
		}
	}
					
		else if(strFileType.contains("TRR"))
		{
			List<SortedMap<String , String>> listOfBodyMap  = new ArrayList<SortedMap<String,String>>();
			SortedMap<String,List<Object>> recordsMap=new TreeMap<String,List<Object>>();
			try {
				ffpExtract = new BscaCare1stMMFlatFileReader(strCompleteFilePath); //this will set up the FileReader of ffpojo library
				FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody.class);   // <== BODY
				recordsMap=ffpExtract.getFlatFileData(ffDefinition);
				for(Object record:recordsMap.get("Body")){
					BscaCare1stMMFlatFileBody body = (BscaCare1stMMFlatFileBody)record;
					SortedMap<String,String> bodyMap=new TreeMap<String,String>();
					bodyMap.put("HICN".toLowerCase(), body.getHICN().toLowerCase()); 
					bodyMap.put("FIRST_NAME".toLowerCase(), body.getFIRST_NAME().toLowerCase()); 
					bodyMap.put("LAST_NAME".toLowerCase(), body.getLAST_NAME().toLowerCase()); 
					bodyMap.put("MID_INIT".toLowerCase(), body.getMID_INIT().toLowerCase()); 
					bodyMap.put("TRANS_RPLY_CD_1".toLowerCase(), body.getTRANS_RPLY_CD().toLowerCase()); 
					bodyMap.put("TRANS_TYP_CD".toLowerCase(), body.getTRANS_TYP_CD().toLowerCase()); 
					bodyMap.put("TERM_DATE".toLowerCase(), body.getTERM_DATE().toLowerCase()); 
					listOfBodyMap.add(bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
				}
						
				String strPrimaryKey = "";
				for(SortedMap<String,String> trrMap :  listOfBodyMap){
					strPrimaryKey = trrMap.get("hicn");
					trrMap.remove("hicn");
					
					if(!flatFileValuesMap.containsKey(strPrimaryKey)){
						//Storing all subscriber filed values map as a value and subscriber id as key
						flatFileValuesMap.put(strPrimaryKey, trrMap);
					}
					else{
						//Adding this key value for handling 2nd row in TRR file
						flatFileValuesMap.get(strPrimaryKey).put("TRANS_RPLY_CD_2".toLowerCase(), trrMap.get("TRANS_RPLY_CD_1".toLowerCase()));
					}
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		
		else if(strFileType.contains("HCO"))
		{		
			List<SortedMap<String,String>>rowsList=	parseFileWithOutHeaderByDelimeter("\\t",strCompleteFilePath,strFileFieldAndTableColumnMapping,"HCO");
			String strPrimaryKey = "";
			for(SortedMap<String,String> hcoMap :  rowsList){
				strPrimaryKey = hcoMap.get("cinnnumber");
				hcoMap.remove("cinnnumber");
				//Storing all subscriber filed values map as a value and subscriber id as key
				flatFileValuesMap.put(strPrimaryKey, hcoMap);
			}
		}
		
		else if(strFileType.contains("Salesforce_PCP_Assign")){
			List<SortedMap<String,String>>rowsList=	parseFileWithOutHeaderByDelimeter("\\|",strCompleteFilePath,strFileFieldAndTableColumnMapping,"SalesForce");
			List<SortedMap<String,String>>rowsListSF = new ArrayList<SortedMap<String,String>>();
			for(SortedMap<String,String> map: rowsList){
				SortedMap<String,String> rowsListMap = new TreeMap<String,String>();
				for(String key: map.keySet()){
					rowsListMap.put(key, map.get(key).replaceAll("\"", ""));
				}
				rowsListSF.add(rowsListMap);
			}
			
			String  strPrimaryKey = "";
			for(SortedMap<String,String> sfMap :  rowsListSF){
				strPrimaryKey = sfMap.get("cin");
				sfMap.remove("cin");
				//Storing all subscriber filed values map as a value and subscriber id as key
				flatFileValuesMap.put(strPrimaryKey, sfMap);
			}
		}
		// Returning SortedMap<String, SortedMap<String, String>> with 834 file values
		return flatFileValuesMap;
	}


/**
 * Changing 834 EDI file format when it is having one line
 * @param strFlatFileCompletePath: 834 file complete path
 * @throws Exception: To capture exception
 */
	
public void fileFormatChange834(String strFlatFileCompletePath) throws Exception
{	
	FileWriter fileWriter = null;
	FileReader fileReader  = null;
	BufferedReader bufferedReader = null;
	
	try{
		File inputFile = new File(strFlatFileCompletePath);
		String strLines = "";
		String line = "";
		//Checking for the file existence
		if(!inputFile.exists()){ 
			throw new IllegalStateException("File not found: " + strFlatFileCompletePath);
		} 
		else{
			fileReader =  new FileReader(inputFile);
			bufferedReader =        new BufferedReader(fileReader);
			int intICounter = 0;
			//Reading each line from the file
			while((line = bufferedReader.readLine())!=null){
				strLines = strLines + line;
				intICounter += 1;
				//Checking for single line 834 file
				if(intICounter > 1){
					bufferedReader.close();
					return;
				}
			}
		
			byte [] strBytes = strLines.getBytes();
			String strAllLines = new String (strBytes,StandardCharsets.UTF_8);
			//Replacing "~" symbol with "~\r\n"
			String strFormatLines = strAllLines.replaceAll("~", "~\r\n");
			fileWriter = new FileWriter(strFlatFileCompletePath);
			//Writing the data once again into the file after changes
			fileWriter.write(strFormatLines);
		  }
	}
	
	//For capturing exception
	catch(Exception e){
		e.printStackTrace();
	}
	finally{
		try{
			//Closing all opened file objects
			fileReader.close();
			fileWriter.close();
			bufferedReader.close();
		}
		catch(Exception ex){
			//ex.printStackTrace();
		}
	}
}

/**
 * @param testFlatFileCompletePath: File complete path
 * @param strCINNNumber: To capture specific subscriber section
 * @param strFileName: 834 file type
 * @return: List of subscriber lines
 * @throws Exception" To capture the exception
 */

public  List<String> parse834File(String testFlatFileCompletePath,String strCINNNumber, String strFileName) throws Exception{
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 //For checking file existence
	 if(!inputFile.exists()){ 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } 
	 else{
		 //Changing the layout when it is having in one single line
		  fileFormatChange834(testFlatFileCompletePath);
		  if(strFileName.contains(("LACare"))){
			  FileReader fileReader =  new FileReader(testFlatFileCompletePath);
			  bufferedReader = new BufferedReader(fileReader);
			  boolean flag=false;
			  //Reading each line in the file 
		      while((line = bufferedReader.readLine()) != null) {
		    	  //Checking for the CINN Number
				 if(line.contains(strCINNNumber)){
				       flag=true;
				  }
				  //Checking for the starting line for each subscriber section
				  if(line.startsWith("ST")){
					  if(flag){
						  break;
				       }else{
				    	   //To clear the records if it is not matches to the provided CINN number
				           rowsList.clear();
				        }
				   }
				   //Adding lines to the records list
				   	rowsList.add(line);
				  }   
		      }
		  
				  //To capture DHCS file specific subscriber lines
				  else if(strFileName.contains("DHCS")){
					  FileReader fileReader =  new FileReader(testFlatFileCompletePath);
					  bufferedReader =  new BufferedReader(fileReader);
					  boolean flag=false;
					  //Reading each line in the file 
				      while((line = bufferedReader.readLine()) != null){
				      //Checking for the CINN Number
				    	  if(line.contains(strCINNNumber)){
				    		  flag=true;
				          }
				          //Checking for the starting line for each subscriber section
				          if(line.startsWith("INS*Y*18*")){
				        	  if(flag){
				        		  break;
				        	  }else{
				        		  //To clear the records if it is not matches to the provided CINN number
				        		  rowsList.clear();
				        	   }
				        	}
				        	//Adding lines to the records list
				        	rowsList.add(line);
				       	}  
				  }
				  else{
					  //Printing line when user has selected invalid file
					  System.out.println("Please select valid file type to retrieve data from flat file ");
				  }
  		}
	 
	 //To close the bufferedReader object
	 if(bufferedReader!=null)
		 bufferedReader.close();
	 	return rowsList;
}


/**
 * To capture CINN Numbers from 834 file
 * @param testFlatFileCompletePath: 834 File complete path
 * @param strFileName: 834 file type
 * @return: List of CINN Numbers
 * @throws Exception: Throwing exception
 */

public  List<String> parse834FileForCINNNumbers(String testFlatFileCompletePath, String strFileName){
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 try{
	    //Checking for the file existence
	    if(!inputFile.exists()){ 
	    	throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	    } 
	    else{
	    	//Changing the layout when it is not expected
		    fileFormatChange834(testFlatFileCompletePath);
		    //To capture CINN Numbers from LACare file
		    if(strFileName.contains("LACare")){
		    	FileReader fileReader =  new FileReader(testFlatFileCompletePath);
				bufferedReader = new BufferedReader(fileReader);
				//Looping through all lined for checking CINN Number line
				while((line = bufferedReader.readLine()) != null){
					if(line.startsWith("NM1*IL*1*")){
						//Adding CINN number to the list
				     	rowsList.add(line.split("\\*")[9].replace("~", ""));
					}
				}   
		    }
		    
			//To capture CINN Numbers from DHCS file
		    else if(strFileName.contains("DHCS")){
		    	FileReader fileReader =  new FileReader(testFlatFileCompletePath);
				bufferedReader = new BufferedReader(fileReader);
				//Looping through all lined for checking CINN Number line
				while((line = bufferedReader.readLine()) != null){
					if(line.startsWith("REF*0F*")){
						//Adding CINN number to the list
				        rowsList.add(line.split("\\*")[2].replace("~", ""));
				     }
				}  
		    }
		    else{
		    	System.out.println("Please select valid file type to retrieve data from flat file ");
			}
	 }
	    
	 //To close the bufferReader object
	 if(bufferedReader != null)
		bufferedReader.close();
}
	//To capture and print the exception
	catch (Exception e){
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//For returning list of CINN numbers 
	return rowsList;
}


/**
 * To find file type for 834 care1st MM
 * @param strFileName: Name of the file
 * @return: File name used for coding
 */

public String fileType834(String strFileName){
	if(strFileName.contains("\\")){
		strFileName = strFileName.substring(strFileName.lastIndexOf("\\") + 1);
	}
	//Checking for the expected file name
	if(strFileName.contains("CFST.D"))
		return "LACounty_Medi-Cal_Members(LACare)834";
	else if(strFileName.contains("DHCS834-DA-") && strFileName.contains("Care1st-SanDiego"))
		return "SDCounty_Medi-Cal_Members(DHCS)834";
	else if(strFileName.contains("DHCS834-DA-") && strFileName.contains("C1CMC-LosAngeles"))
		return "LACounty_Cal-MediConnect_Members(DHCS)834";
	else if(strFileName.contains("DHCS834-DA-") && strFileName.contains("C1CMC-SanDiego"))
		return "SDCounty_Cal-MediConnect_Members(DHCS)834";
	else if(strFileName.contains("Monthly_Salesforce_PCP_Assign"))
		return "Monthly_Salesforce_PCP_Assign";
	else if(strFileName.contains(".DTRRD.D"))
		return "TRR";
	else if(strFileName.startsWith("T_"))
		return "HCO";
	else
		System.out.println("This file name is invalid: " + strFileName );
		return null;
}

//below method is to handle the index out of bound exception
public String  partialStringRetrieval(String strKeyName,String line,int indexValue, int intStartPos, int intEndingPos){
	if(!(intStartPos == 0 && intEndingPos == 0)){
		 try{
             String strValue = line.split("\\*")[indexValue].substring(intStartPos,intEndingPos).replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    return strValue;
             }
		 }
		 catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
			return "";
		 }
	}
	else{
		 try{
             String strValue = line.split("\\*")[indexValue].replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
            	 return strValue;
             }
		 }
         catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
            return "";
       }
	}
	return "";
}

//below method is to handle the index out of bound exception
public String  partialStringRetrievalUsingFieldIndex(String strKeyName,String line,int indexLineValue,  String strDelimeter, int indexFieldValue){
		 try{
				line = line.replace("~", "").trim();
				   String strValue = line.split("\\*")[indexLineValue].split(strDelimeter)[indexFieldValue].replace("~", "").trim();
				   if(!(strValue.equalsIgnoreCase(""))){
				  return strValue;
           }
		 }
		 catch(Exception e){
          // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
			return "";
		 }
	
	return "";
}


public static  List<SortedMap<String,String>> parseFileWithOutHeaderByDelimeter(String delimeter,String testFlatFileCompletePath,String fieldColumnMappingFilePath,String mappingSheetName) throws IOException{
	 File inputFile = new File(testFlatFileCompletePath);
	 List<SortedMap<String,String>> listOfRows=new ArrayList<SortedMap<String,String>>();
	 String line=null;
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  }
	 else{
		 System.out.println("Starting of File Reading . . . . . .  . . . . ");
		 new ExcelUtilsExtended(fieldColumnMappingFilePath,mappingSheetName);
		 FileReader fileReader =  new FileReader(testFlatFileCompletePath);
		 @SuppressWarnings("resource")
	     BufferedReader bufferedReader = new BufferedReader(fileReader);
		 while((line = bufferedReader.readLine()) != null){
			 String[] columnsArray = line.split(delimeter);
			 SortedMap<String,String> rowMap=new TreeMap<String,String>();
			 int columnLength=columnsArray.length;
			 for(int i=0;i<columnLength;i++){
				 String fileFieldName=String.valueOf(i);
			     String columnNameKey=ExcelUtilsExtended.getDBColumnName(fileFieldName);
				 if(columnNameKey!=null){
					 rowMap.put(columnNameKey.toLowerCase(),columnsArray[i].toLowerCase());	//System.out.println(rowNo+"  columnlength::"+columnLength+" index: "+i+"  "+rowsList.get(rowNo)[i]);
				 }
			 }
		 listOfRows.add(rowMap);
		 }   	    
 	}
	return listOfRows;
}


public SortedMap<String,SortedMap<String,String>> sortedMapMergingRough(SortedMap<String,SortedMap<String,String>> map1,SortedMap<String,SortedMap<String,String>> map2){
	SortedMap<String,SortedMap<String,String>> map3Return = new TreeMap<String,SortedMap<String,String>>();
	SortedMap<String,String> tempMap1 = new TreeMap<String, String>();
	SortedMap<String,String> tempMap2 = new TreeMap<String, String>();
	SortedMap<String,String> tempMapMerged = new TreeMap<String, String>();
	String tempMapKey1 = null;
	String tempMapKey2 = null;
	Boolean blnFlag = false;
	
	for(Entry<String,SortedMap<String,String>> mapEntry1 : map1.entrySet()){
		tempMap1 = mapEntry1.getValue();
		tempMapKey1 = mapEntry1.getKey();
		for(Entry<String,SortedMap<String,String>> mapEntry2 : map2.entrySet()){
			tempMap2 = mapEntry2.getValue();
			tempMapKey2 = mapEntry1.getKey();
			if(tempMapKey1.equalsIgnoreCase(tempMapKey2)){
				tempMapMerged.putAll(tempMap1);
				tempMapMerged.putAll(tempMap2);
				map3Return.put(tempMapKey1, tempMapMerged);
				blnFlag = true;
			}
		}
	}
	
	if(!blnFlag && map1.size()!=0){
		map3Return.putAll(map1);
	}
	
	else if(!blnFlag && (map2.size()!=0)){
		map3Return.putAll(map2);
	}
	
	return map3Return;
	
}

// Function for merging of all the query maps into a single map
public SortedMap<String,SortedMap<String,String>> sortedMapMerging(SortedMap<String,SortedMap<String,String>> map1,SortedMap<String,SortedMap<String,String>> map2){
    SortedMap<String,SortedMap<String,String>> map3Return = new TreeMap<String,SortedMap<String,String>>();
    SortedMap<String,String> tempMap1 = new TreeMap<String, String>();
    SortedMap<String,String> tempMap2 = new TreeMap<String, String>();
    String tempMapKey1 = null;
    
    for(Entry<String,SortedMap<String,String>> mapEntry1 : map1.entrySet()){
    	tempMap1 = mapEntry1.getValue();
        tempMapKey1 = mapEntry1.getKey();
        if(map2.containsKey(tempMapKey1)){
        	SortedMap<String,String> tempMapMerged = new TreeMap<String, String>();
            tempMap2 = map2.get(tempMapKey1);
            tempMapMerged.putAll(tempMap1);
            tempMapMerged.putAll(tempMap2);
            map3Return.put(tempMapKey1, tempMapMerged);
         }
         else{
        	map3Return.put(tempMapKey1, tempMap1);
         }
    }
    
    for(Entry<String,SortedMap<String,String>> mapEntry2 : map2.entrySet()){
    	tempMap1 = mapEntry2.getValue();
        tempMapKey1 = mapEntry2.getKey();
        if(!map1.containsKey(tempMapKey1)){
        	map3Return.put(tempMapKey1, tempMap1);
        }  
    }
    
    return map3Return;
}

//Function to get Special Indicator data from database
public SortedMap<String, SortedMap<String, String>>  getSpecialIndicatorData(Set<String> strPrimaryKeySet, String strQuery, String strColumn1,String strColumn2,String strColumn3){
	SortedMap<String,String> strMap = new TreeMap<String,String>();
    SortedMap<String, SortedMap<String, String>> strMapReturn = new TreeMap<String, SortedMap<String, String>>();
    List<Map<String, Object>> specialIndicatorResultSet1 = null;
    String strQueryPrimaryKey = null;
    for(String strPrimaryKey: strPrimaryKeySet){
    	strQueryPrimaryKey = strQuery.replace("Parameter1", strPrimaryKey.toUpperCase());
        specialIndicatorResultSet1 = new DBUtils().getResultSetAsMapList("facets", strQueryPrimaryKey);
        strMap = resultSetToDictionarySpecificColumns(specialIndicatorResultSet1, strColumn1, strColumn2, strColumn3);
        strMapReturn.put(strPrimaryKey, strMap);
    }
    return strMapReturn;
}


public  SortedMap<String,String> resultSetToDictionarySpecificColumns(List<Map<String,Object>> queryResultList, String strColumn1,String strColumn2,String strColumn3){
	SortedMap<String,String> strMap = new TreeMap<String,String>();
	String strTempColumn1 = "";
	String strTempColumn2 = "";
	String strTempColumn3 = "";
	for(int intICounter=0;intICounter<queryResultList.size();intICounter++){
		if(queryResultList.get(intICounter).get(strColumn3)!=null){
			strTempColumn3 =  queryResultList.get(intICounter).get(strColumn3).toString();
		}
		else{
			strTempColumn3 = "[Blank]";
		}
		strTempColumn1 = queryResultList.get(intICounter).get(strColumn1).toString().toLowerCase();
		strTempColumn2 = queryResultList.get(intICounter).get(strColumn2).toString().toLowerCase();	
		strMap.put( strTempColumn1 + "_" +  strTempColumn2,strTempColumn3 );
	}
	return strMap;
	}
}
