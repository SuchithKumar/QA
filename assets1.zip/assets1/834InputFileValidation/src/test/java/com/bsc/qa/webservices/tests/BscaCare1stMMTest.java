package com.bsc.qa.webservices.tests;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.Edi834Utility;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;
import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable {
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	
	public BscaCare1stMMTest(String inputFileName) {
		this.inputFileName = inputFileName;
	}
	// ************************************** TEST
	// METHODS************************
 
	@SuppressWarnings("deprecation")
	// Main test method to validate 834 file against FACETS database.
	@Test()
	private void test834FileValidation() throws IOException {
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;

		// Retrieving test data value from test data sheet
		String strCompleteFilePath = System.getenv("INPUT_EDI_PATH");
		//File cinn_file=new File(System.getenv("CIN_COMPLETE_FILE_PATH")+"\\file2.txt");
		
		//Creating Edi834Utility class object
		Edi834Utility edi834Utility = new Edi834Utility();
		
		Map<String, String> data = null;
		try{
			data = getData("test834FileValidation");
		} 
		catch (Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try{
			flatFileValuesMap = edi834Utility.get834FileData(
			strCompleteFilePath, inputFileName,data);
		} 
		catch (Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Retrieve's all primary keys into flatFileValuesMap
		Set<String> keys = flatFileValuesMap.keySet();
		String  inClauseStringBuilderstr = "";
        int intICounter = 0;
        List<String> strKeysList = new ArrayList<String>();
        List<String> strKeysList_cinn = new ArrayList<String>();
        
        //Loop used to get the subscribers data to pass it is input to the query
        for(String key:keys){
        	strKeysList_cinn.add(key);
        }
        
        for(String key : keys){
            intICounter++;
            inClauseStringBuilderstr = inClauseStringBuilderstr + "'" + key + "',";
            
            //Storing 1000 subscribers data in a list variable
            if(intICounter >=1000){
                //Removing extra ',' at the end of the map
                inClauseStringBuilderstr = inClauseStringBuilderstr.substring(0, (inClauseStringBuilderstr.length()-1));
                //Adding the 1000 subscribers data to list
                strKeysList.add(inClauseStringBuilderstr);
                strKeysList_cinn.add(key);
                intICounter = 0;
                inClauseStringBuilderstr = "";
            }
		}
        
        //Storing last subscribers data which are less than 1000
		if((intICounter < 1000) && (intICounter !=0)){
            //Removing extra ',' at the end of the map
            inClauseStringBuilderstr = inClauseStringBuilderstr.substring(0, (inClauseStringBuilderstr.length()-1));
            strKeysList.add(inClauseStringBuilderstr);
            inClauseStringBuilderstr = "";
		}

		StringBuilder strMeetQuery = new StringBuilder();
		for (String key : keys){
			  strMeetQuery = strMeetQuery.append(data.get("MEET_QUERY").replace("Parameter1", key.toUpperCase()) + " UNION ");
		}
		
		strMeetQuery.delete(strMeetQuery.lastIndexOf("UNION"), strMeetQuery.length());
		String strQuery = "      ";
		String query1=" ";
		
		//To get 834 file type
		String	strFileType = edi834Utility.fileType834(inputFileName);
		
		//Loop used to get 1000 subscribers data and store the same in main SortedMap
        for(String strKeySet : strKeysList ){
        	if(strFileType.contains("834") || strFileType.contains("HCO")){
        		//Creating where clause statement for each 1000 subscribers data
	        	strQuery = strQuery + data.get("PRIMARY_KEY") + " in (" + strKeySet + ")" + " Or ";
	        	query1=query1+data.get("Cinn_query")+ " in (" + strKeySet + ")";
	        }
	        else if(strFileType.contains("Salesforce_PCP_Assign") ){
	        	//Creating where clause statement for each 1000 subscribers data
	        	strQuery = strQuery + data.get("PRIMARY_KEY") + " in (" + strKeySet + ")" + " Or ";
	        }
	        else if( strFileType.contains("TRR")){
	        	//Creating where clause statement for each 1000 subscribers data
	        	strQuery = strQuery + data.get("PRIMARY_KEY3") + " in (" + strKeySet + ")" + " Or ";
	        }
        }
        
        strQuery = strQuery.substring(0, strQuery.length()-4).trim();
        
        // Query from data sheet columns are stored in the following maps
        SortedMap<String, SortedMap<String, String>> sql1Map = null;
        SortedMap<String, SortedMap<String, String>> prprIdMap = null;
        SortedMap<String, SortedMap<String, String>> spclIndicMap = null;
        SortedMap<String, SortedMap<String, String>> spclIndcDateMap = null;
        SortedMap<String, SortedMap<String, String>> hicnEventMap = null;
        SortedMap<String, SortedMap<String, String>> pbpEventMap = null;
        SortedMap<String, SortedMap<String, String>> partDEventMap = null;
        SortedMap<String, SortedMap<String, String>> scccEventMap = null;
        SortedMap<String, SortedMap<String, String>> eligibilityTermMap = null;
        SortedMap<String, SortedMap<String, String>> eligibilityReinstMap = null;
        SortedMap<String, SortedMap<String, String>> eligibilityChangeMap = null;
        SortedMap<String, SortedMap<String, String>> meetMap = null;
        SortedMap<String, SortedMap<String, String>> sql1Map_cinn = null;
        SortedMap<String, SortedMap<String,String>> sql1HCOMap = new TreeMap<String,SortedMap<String,String>>();
        SortedMap<String, SortedMap<String,String>> sql1SFMap = new TreeMap<String,SortedMap<String,String>>();
        
        String strActualQuery = "";
        
        // Start validation for file type "834"
        if(strFileType.contains("834")){
        	
        //PrintStream fileStream = new PrintStream(new File(System.getenv("CIN_COMPLETE_FILE_PATH"))+"\\file1.txt");
	    //Replaces 'in clause' string in the query with all subscriber Id's in comma separated format
	    
        	
        String strTempParameter = strQuery.toString().toUpperCase();
        sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("SQL_TEMPLATE").replaceAll("Parameter1", strTempParameter), data.get("PRIMARY_KEY"));
        strActualQuery =  data.get("SQL_TEMPLATE").replaceAll("Parameter1", strTempParameter) ;
        	   
	    hicnEventMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("HICN_EVENT_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    pbpEventMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("PBP_EVENT_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    partDEventMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("PARTD_EVENT_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    scccEventMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("SCCC_EVENT_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    eligibilityTermMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("ELIGIBILITY_QUERY1") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    eligibilityReinstMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("ELIGIBILITY_QUERY2") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    eligibilityChangeMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("ELIGIBILITY_QUERY3") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    prprIdMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("PRPRID_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    spclIndicMap  = edi834Utility.getSpecialIndicatorData(keys, data.get("SPECIALINDICATOR_QUERY") ,"DTA_ELEM_BUS_NM", "CUSTM_DTA_ELEM_KEY","CUSTM_DTA_ELEM_VAL_TXT");
	    spclIndcDateMap  = edi834Utility.getSpecialIndicatorData(keys, data.get("SPECIALINDICATORDATE_QUERY") ,"DTA_ELEM_BUS_NM", "CUSTM_DTA_ELEM_KEY","CUSTM_DTA_ELEM_VAL_DT");
		
	    meetMap = new DBUtils().getResultSetAsSortedMap("facets", strMeetQuery.toString().toUpperCase() ,data.get("PRIMARY_KEY4"));
	   
		
		//Putting all the maps data into the main map - sqlMap
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, eligibilityTermMap);
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, eligibilityReinstMap);
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, prprIdMap);
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, spclIndicMap);
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, spclIndcDateMap);
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, eligibilityChangeMap);
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, hicnEventMap);
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, pbpEventMap);
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, partDEventMap);
		sql1Map = edi834Utility.sortedMapMerging(sql1Map, scccEventMap);
		
        sql1Map_cinn = new DBUtils().getResultSetAsSortedMap("facets",query1.toString().toUpperCase(), data.get("PRIMARY_KEY"));
        String[] cinn_no=null;
       	File cinn_file_idcards=new File(System.getenv("CIN_COMPLETE_FILE_PATH_IDcards"));
       	File cinn_file_welcomekit=new File(System.getenv("CIN_COMPLETE_FILE_PATH_WKIT"));
       	
       	for(int c=0;c<=strKeysList_cinn.size()-1;c++){
        	try{
	        	if(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meme_medcd_no").equals(null)){
	        	}
		       	else{
		       		if(!cinn_file_idcards.exists()){
		       			cinn_file_idcards.createNewFile();
	       			}
	       			if(!cinn_file_welcomekit.exists()){
	       				cinn_file_welcomekit.createNewFile();
	       			}
	       		BufferedWriter filewriter=new BufferedWriter(new FileWriter(cinn_file_idcards,true));
	       		BufferedWriter filewriter1=new BufferedWriter(new FileWriter(cinn_file_welcomekit,true));
	       			
	       		filewriter.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meme_medcd_no"));
	       		filewriter.append("-");
	       		filewriter.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meia_req_type"));
	       		filewriter.append("-");
	       		filewriter.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("sbsb_id"));
	       		filewriter.newLine();
	       		filewriter.close();
	       		filewriter1.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meme_medcd_no"));
	       		filewriter1.append("-");
	       		filewriter1.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meia_req_type"));
	       		filewriter1.append("-");
	       		filewriter1.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("sbsb_id"));
	       		filewriter1.newLine();
	       		filewriter1.close();
	       		}
	        }
	        catch(NullPointerException e){
	        	System.out.println("null value");
	        }
       	}
    }
        
        else if(strFileType.contains("Salesforce_PCP_Assign")){
        	//Replaces 'in clause' string in the query with all subscriber ids in comma separated format
            sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("SalesForceFileQueries") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
            sql1SFMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("SQL_TEMPLATE").replaceAll("Parameter1", strQuery.toString().toUpperCase()), data.get("PRIMARY_KEY"));
            strActualQuery = data.get("SalesForceFileQueries") + "  " + strQuery.toString().toUpperCase();
            //strActualQuery = data.get("HCOFileQueries") + "  " + strQuery.toString().toUpperCase();
        }
        
        else if(strFileType.contains("HCO")){
        	//Replaces 'in clause' string in the query with all subscriber ids in comma separated format
            sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("HCOFileQueries") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
            sql1HCOMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("SQL_TEMPLATE").replaceAll("Parameter1", strQuery.toString().toUpperCase()), data.get("PRIMARY_KEY"));
            strActualQuery = data.get("HCOFileQueries") + "  " + strQuery.toString().toUpperCase();
        }
        else if(strFileType.contains("TRR")){
        	//Replaces 'in clause' string in the query with all subscriber ids in comma separated format
        	String strParameter1 = strQuery.toString().toUpperCase();
            sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("TRRFileQueries").replaceAll("Parameter1", strParameter1), data.get("PRIMARY_KEY2"));
            strActualQuery =  data.get("TRRFileQueries").replaceAll("Parameter1", strParameter1) ;
        }
        else{
        	System.out.println("Please provide valid file");
        }
        
        Set<String> primaryKeySet = flatFileValuesMap.keySet();
        int intJCounter = 1;
    	String teleScenMapping = "";
    	
		//TODO: Temporary workaround to validate - if data in file is in DB then pass. Must remove this and uncomment the MapDifference code below when all data elements are accounted for.
		//Below section will loop on each primaryKey in the "flatfilevaluesMap"
		for (String primaryKey: primaryKeySet){
			
			//capture single subscriber id from flatfilevaluesMap
			SortedMap<String, String> rowMap = flatFileValuesMap.get(primaryKey);
			
			//capture telephone from rowMap
			String telephone = rowMap.get("telephone");
			
			//To display telephone to scenario mapping
			//try{
				if(strFileType.contains("834")){
						if(telephone!=null){
							teleScenMapping = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", "MappingSheet")
							.getQueryFromMappingSheet(telephone, "MappingSheet");
						}
						else{
							teleScenMapping = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", "MappingSheet")
							.getQueryFromMappingSheet("99999999999", "MappingSheet");
						}
						
						
					//To get the report for each subscriber in the XML
					//Parameters: to display report header in the HTML
				
					if(teleScenMapping != null){
						reportInit (teleScenMapping  , " Subscriber ID: " + primaryKey.toUpperCase());
						logger.log(LogStatus.INFO, "Starting Test - test834FileValidation ");
						teleScenMapping=teleScenMapping.replaceAll("\"", "");
					}
					else{
						reportInit("834FileToDbValidation ", ": Subscriber ID: " +primaryKey.toUpperCase());
						logger.log(LogStatus.INFO, "Starting Test - test834FileValidation ");
					}
				}
				intJCounter++;
			
				if(strFileType.contains("HCO") || strFileType.contains("TRR") || strFileType.contains("Salesforce_PCP_Assign")){
					reportInit("834FileToDbValidation ", ": Subscriber ID: " +primaryKey.toUpperCase());
					logger.log(LogStatus.INFO, "Starting Test - test834FileValidation ");
				}
			
			logger.log(LogStatus.INFO, "File Path: " + inputFileName);
			logger.log(LogStatus.INFO, "Query used to fetch database data : " + strActualQuery );
			logger.log(LogStatus.INFO, "Subscriber used for validation is: " + primaryKey.toUpperCase());
			logger.log(LogStatus.INFO, "Field Name: Actual | Expected");
			
			String[] strArrayModified = new String[2];
	        SortedMap<String, String> strPrimaryDbMap = new TreeMap<String,String>();
	        SortedMap<String, String> strPrimaryMeetMap = new TreeMap<String,String>();
	        
	        if(strFileType.contains("834")){
		        if(sql1Map.containsKey(primaryKey)){
		        	strPrimaryDbMap = sql1Map.get(primaryKey); //Check this map for FACETS DB validations
		        }
		        
		        String strPrimaryMeetKey = "";
		        
		        if(meetMap.size()>0){
		        	for(Entry<String,SortedMap<String, String>> entryMap : meetMap.entrySet()){
		        		strPrimaryMeetKey = entryMap.getKey();
				        if(strPrimaryMeetKey.contains(primaryKey)){
				        	strPrimaryMeetMap = entryMap.getValue(); //Check this map for MEET validations
				        }
				    }
		        }
	        }
	        
	        //Checking for the Termination scenario in TRR file
			if(strFileType.equalsIgnoreCase("TRR"))
				{
				if(rowMap.get("trans_rply_cd_1").equalsIgnoreCase("014") && rowMap.get("trans_typ_cd").equalsIgnoreCase("51")){
				//if(teleScenMapping.equalsIgnoreCase("TC005_Verify subscriber is Termed with TRR file")){
					rowMap.put("sbel_elig_type_trr", "TM");
				}
				else{
					rowMap.remove("term_date");
				}
			}
	        
	        //Performing MEET and FACETS database validations
			try{
				//Checking if data is present in MEET with respective error
				if((strPrimaryMeetMap.size()>0) && (strFileType.contains("834"))){
					logger.log(LogStatus.WARNING, "Data is present in MEET for this CINN Number: " + primaryKey.toUpperCase() + " with Error Value as: " + strPrimaryMeetMap.get("error_value") + " and Error Description as: " + strPrimaryMeetMap.get("error_description") + ".");
				}
				
				/*//Checking if data is not present in Facets DB but present in MEET with respective error
				else if((strPrimaryDbMap.isEmpty() && strPrimaryMeetMap.size()>0) && (strFileType.contains("834"))){
					logger.log(LogStatus.WARNING, "Data is NOT present in Facets database but present in MEET for this CINN Number: " + primaryKey.toUpperCase() + " with Error Value as: " + strPrimaryMeetMap.get("error_value") + " and Error Description as: " + strPrimaryMeetMap.get("error_description") + ".");
				}*/
				
				//Checking if data is not present in Facets DB as well as in MEET DB
				else if(strPrimaryDbMap.isEmpty() && strPrimaryMeetMap.isEmpty()
					&& (strFileType.contains("834"))){
					if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
						|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
													
						if(teleScenMapping.equalsIgnoreCase("TC0053_Verify that the subscriber is erred in MEET with Multiple Subscriber Id found for the same CIN in Facets when Group Id, CIN, DOB Matches with more than one record in Facets") 
							|| teleScenMapping.equalsIgnoreCase("TC0033_Verify enrolling a newborn under mother with blank aid code") 
							|| teleScenMapping.equalsIgnoreCase("TC0011_Verify Out of state members PCP ")
							|| teleScenMapping.equalsIgnoreCase("TC0015_Verify Invalid aid code")
							|| teleScenMapping.equalsIgnoreCase("TC0016_Verify Invalid county code")
							|| teleScenMapping.equalsIgnoreCase("TC0023_Verify enrolling a member without an residential address")
							|| teleScenMapping.equalsIgnoreCase("TC0025_Verify terming a member with no HCP status code when member is not available in facets")
							|| teleScenMapping.equalsIgnoreCase("TC0026_Verify add/change/term a member that does not exist in Facets and has blank HCP code")
							|| teleScenMapping.equalsIgnoreCase("TC0030_Verify new add sent with only termination do not load into Facets")){
							
							
							logger.log(LogStatus.PASS, "Data is NOT present in Facets and MEET database for this CINN Number: " + primaryKey.toUpperCase()  + ". Please check MMS logs for more details");
						}					
						else{
							logger.log(LogStatus.FAIL, "Data is NOT present in Facets and MEET database for this CINN Number: " + primaryKey.toUpperCase()  + ". Please check MMS logs for more details");
						}
					}
					else if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")
						|| strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
						
						if(teleScenMapping.equalsIgnoreCase("TC040_Verify enrolling a newborn under mother with blank aid code")
							|| teleScenMapping.equalsIgnoreCase("TC018_Verify Out of state members PCP")
							|| teleScenMapping.equalsIgnoreCase("TC022_Verify Invalid aid code")
							|| teleScenMapping.equalsIgnoreCase("TC023_Verify Invalid county code")
							|| teleScenMapping.equalsIgnoreCase("TC030_Verify enrolling a member without an residential address")
							|| teleScenMapping.equalsIgnoreCase("TC032_Verify terming a member with no HCP status code when member is not available in facets")
							|| teleScenMapping.equalsIgnoreCase("TC033_Verify add/change/term a member that does not exist in Facets and has blank HCP code")
							|| teleScenMapping.equalsIgnoreCase("TC037_Verify new add sent with only termination do not load into Facets")){
							logger.log(LogStatus.PASS, "Data is NOT present in Facets and MEET database for this CINN Number: " + primaryKey.toUpperCase()  + ". Please check MMS logs for more details");
						}
						else{
							logger.log(LogStatus.FAIL, "Data is NOT present in Facets and MEET database for this CINN Number: " + primaryKey.toUpperCase()  + ". Please check MMS logs for more details");
						}
					}
				}
				
				//Checking if data is present in Facets DB and not present in MEET then start with the validations
				else if (sql1Map.size()>0){
					/*if(!teleScenMapping.equalsIgnoreCase("TC001_Verify subscriber is pended in MEET with TRR Validation Fail in MEET when loaded with 834 and HCO files - No TRR")){
					*/
					//Retrieving value from database for each of the keys				
					SortedMap<String,String> strSubscriberID = sql1Map.get(primaryKey);
									
					//Below section will loop on each key in the flatfilevaluesMap
					for (String columnKey : rowMap.keySet()){
						//Retrieving value from flat file for each of the keys 
						String fileValue = rowMap.get(columnKey);
						String dbValue = "";
						//Retrieving value from database for each of the keys				
						dbValue = sql1Map.get(primaryKey).get(columnKey);
						strArrayModified = funcSourceTargetTransformationLogic(columnKey,fileValue,dbValue,strFileType);
						fileValue = strArrayModified[0];
						dbValue = strArrayModified[1];
						
						//Comparing source and target values to report in the logger
						
						if(columnKey.contains("ADDRESS1".toLowerCase()) || columnKey.contains("ADDRESS2".toLowerCase()) || columnKey.contains("CITY".toLowerCase())){
							if(dbValue.equalsIgnoreCase(fileValue)){
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							else{
								logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							softAssert.assertTrue(fileValue.contains(dbValue),  primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
						}
						
						
						else if(columnKey.contains("sccc_memd_mctr_mcct")){
							if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")){
								if(dbValue.equalsIgnoreCase("200") || dbValue.equalsIgnoreCase("210")){
									if(fileValue.equalsIgnoreCase("210")){
										logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + dbValue + " | Database value: " + dbValue + " >>");
									}
								}
								else{
									logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
								}
							}	
						}
												
						else if(columnKey.contains("prpr_id")){
							if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
								/*if(fileValue.equalsIgnoreCase("[Blank]") 
										|| dbValue.equalsIgnoreCase("[Blank]")){
									if(!dbValue.equalsIgnoreCase("[Blank]")){
										logger.log(LogStatus.PASS, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " | "
										+ " | Due to limited provider data in H70, the provider crosswalk value is not matching the provider selected on the subscriber. This validation is being passed.");
										softAssert.assertTrue(true, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									}
									else{
										logger.log(LogStatus.PASS, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
										softAssert.assertTrue(false, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									}
									logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
								}
								else{
									logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
								}*/
								
								
								String getPcpQuery = "SELECT PRPR_ID FROM PFI.PFI_LACARE_XWALK where LACARE_ID = '" + fileValue.trim() + "'";
								Map<String,String> prprMap = new HashMap <String,String>();
								try{
									prprMap = new DBUtils().getOneRowResultSetAsMap("facets", getPcpQuery);
									String fileModifiedValue;
									fileModifiedValue = prprMap.get("PRPR_ID");
									if(fileModifiedValue == null){
										fileModifiedValue = "[Blank]";
									}
									if(fileModifiedValue.equalsIgnoreCase(dbValue)){
										logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileModifiedValue + " | Database value: " + dbValue + " >>");
									}
									else
									{
										logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileModifiedValue + " | Database value: " + dbValue + " >>");
										
									}
									softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
									if(dbValue.equalsIgnoreCase("[Blank]") && fileModifiedValue.equalsIgnoreCase("[Blank]")){
										logger.log(LogStatus.PASS, " << Field name: " + columnKey + " | Flat file value: " + fileModifiedValue + " | Database value: " + dbValue + " >>");
									}
									if(dbValue.equalsIgnoreCase("[Blank]") && fileValue.equalsIgnoreCase("[Blank]")){
										logger.log(LogStatus.PASS, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									}
								}		
								catch(Exception e){
									System.out.println("PRPR ID is not present in database");
								}
							}
							else if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") 
								|| strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834")
								|| strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
								if(fileValue.equalsIgnoreCase("[Blank]")){
									if(!dbValue.isEmpty()){
										logger.log(LogStatus.PASS, "Auto PCP: " + dbValue + " is assigned for this subscriber: " + primaryKey.toUpperCase());
									}
								}
								else{
									logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
								}
							}
							else if(strFileType.contains("HCO")){if(fileValue.equalsIgnoreCase("[Blank]")){
								if(!dbValue.equalsIgnoreCase("[Blank]")){
									logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									softAssert.assertTrue(true, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
								}
								else{
									logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									softAssert.assertTrue(false, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
								}
								System.out.println(columnKey + ": " + fileValue + " | " + dbValue);
							}
						
						else{
							if(fileValue.equalsIgnoreCase(dbValue)){
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							else{
								logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
						}
							}
						}
						
						else if(columnKey.contains("MEDS Renewal Date_443".toLowerCase())
							|| columnKey.contains("Death date_402".toLowerCase())
							|| columnKey.contains("Policy Start Date_415".toLowerCase()) 
							|| columnKey.contains("SOC certification day_440".toLowerCase())){
							if(dbValue.contains(fileValue)){
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							else
							{
								logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							softAssert.assertTrue(dbValue.contains(fileValue),  primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
						}
						
						
						else if(columnKey.equalsIgnoreCase("sbel_eff_dt")){
							String typeFileVal;
							String effDateFileVal1;
							String effDateDbVal1;
							
							typeFileVal = rowMap.get("SBEL_ELIG_TYPE".toLowerCase());
							effDateFileVal1 = rowMap.get("SBEL_EFF_DT".toLowerCase());
							effDateDbVal1 = sql1Map.get(primaryKey).get("SBEL_EFF_DT".toLowerCase());
							
							//***************To convert SBEL effective date in String format to date format*********
							try{
								SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
								Date effDateFileVal = sdf.parse(effDateFileVal1.substring(0, 4) + "-" + effDateFileVal1.substring(5, 6) + "-" +effDateFileVal1.substring(7));
								Date effDateDbVal = sdf.parse(effDateDbVal1.substring(0, 4) +  "-" + effDateDbVal1.substring(5, 6) +  "-" + effDateDbVal1.substring(7));
							
							//***************Comparing SBEL effective dates in FLATFILE and DB**********************
								if(typeFileVal.equalsIgnoreCase("SL")){
									if(effDateFileVal.compareTo(effDateDbVal) > 0){ //Date1 is after Date2
										//logger.log(LogStatus.PASS, "Minimum HD Loop coverage date in the file is: " + effDateFileVal1 + " and in Db is: " + effDateDbVal1 + ". Please validate manually in Facets for the correct dates.");
							         }
									else if(effDateFileVal.compareTo(effDateDbVal) < 0){ //Date1 is before Date2
										logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Flat file value: " + effDateFileVal1 + " | Database value: " + effDateDbVal1 + " >>");
									}
									else if(effDateFileVal.compareTo(effDateDbVal) == 0){ //Date1 is equal to Date2
										logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + effDateFileVal1 + " | Database value: " + effDateDbVal1 + " >>");
									}
								}
								else if(typeFileVal.equalsIgnoreCase("TM") || 
									typeFileVal.equalsIgnoreCase("RI") || 
									typeFileVal.equalsIgnoreCase("CH")){
									if(effDateFileVal1.equalsIgnoreCase(effDateDbVal1)){
										logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + effDateFileVal1 + " | Database value: " + effDateDbVal1 + " >>");
									}
									else{
										logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Flat file value: " + effDateFileVal1 + " | Database value: " + effDateDbVal1 + " >>");
									}
								}
							}
							catch(ParseException e){
								System.out.println("Not a valid date format");
							}
						}
						
						
						else if (columnKey.equalsIgnoreCase("SBEL_ELIG_TYPE".toLowerCase())){
							
							String effDateFileTempVal1;
							String effDateDbTempVal1;
							effDateFileTempVal1 = rowMap.get("SBEL_EFF_DT".toLowerCase());
							effDateDbTempVal1 = sql1Map.get(primaryKey).get("SBEL_EFF_DT".toLowerCase());
							
							try{
								SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
								Date effDateFileValue = sdf.parse(effDateFileTempVal1.substring(0, 4) + "-" + effDateFileTempVal1.substring(5, 6) + "-" +effDateFileTempVal1.substring(7));
								Date effDateDbValue = sdf.parse(effDateDbTempVal1.substring(0, 4) +  "-" + effDateDbTempVal1.substring(5, 6) +  "-" + effDateDbTempVal1.substring(7));
							
								if(fileValue.equalsIgnoreCase("SL")){
									if(effDateFileValue.compareTo(effDateDbValue) > 0){ //Date1 is after Date2
										logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + dbValue + " | Database value: " + dbValue + " >>");
							         }
									else if(effDateFileValue.compareTo(effDateDbValue) < 0){ //Date1 is before Date2
										if(fileValue.equalsIgnoreCase(dbValue)){
											logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
										}
										else{
											logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
										}
									}
									else if(effDateFileValue.compareTo(effDateDbValue) == 0){ //Date1 is equal to Date2
										if(fileValue.equalsIgnoreCase(dbValue)){
											logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
										}
										else{
											logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
										}
									}
								}
								else if(fileValue.equalsIgnoreCase("TM") || 
										fileValue.equalsIgnoreCase("RI") || 
										fileValue.equalsIgnoreCase("CH")){
									if(effDateFileTempVal1.equalsIgnoreCase(effDateDbTempVal1) && fileValue.equalsIgnoreCase(dbValue)){
										logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									}
									else{
										logger.log(LogStatus.FAIL," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									}
								}
							}
							catch(ParseException e){
								System.out.println("Not a valid date format");
							}
						}
						
						
					else if(columnKey.equalsIgnoreCase("MECD_MCTR_AIDC1".toLowerCase())){
						if(!(fileValue.equalsIgnoreCase(dbValue))){
							String cspiIdFileVal;
							String cspiIdDbVal;
							cspiIdFileVal = rowMap.get("cspi_id");
							cspiIdDbVal = sql1Map.get(primaryKey).get("cspi_id");
							
							if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
								String strQuery1 = "SELECT * FROM CU_CARE1ST_MCAL_CLS_PLN_XREF where lob_id='19' and  capitn_aid_cd= '" + cspiIdFileVal.toUpperCase() + "'";
								Map<String,String> planId = new HashMap<String,String>();
								try{
									planId = new DBUtils().getOneRowResultSetAsMap("facets", strQuery1);
									String fileModifiedValue = planId.get("FACETS_PLN_ID");
									if(fileModifiedValue == null){
										fileModifiedValue = "[Blank]";
									}
									if(fileModifiedValue.equalsIgnoreCase(cspiIdDbVal)){
										logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
										softAssert.assertTrue(true, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									}
									else{
										logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
										softAssert.assertTrue(false, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									}
								}
								catch(Exception e){
									System.out.println("CSPI ID is not present in database");
								}
							}
							 
							else if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
								String strQuery1 = "SELECT * FROM CU_CARE1ST_MCAL_CLS_PLN_XREF where lob_id='37' and  capitn_aid_cd= '" + cspiIdFileVal.toUpperCase() + "'";
								Map<String,String> planId = new HashMap<String,String>();
								try{
									planId = new DBUtils().getOneRowResultSetAsMap("facets", strQuery1);
								    String fileModifiedValue = planId.get("FACETS_PLN_ID");
									if(fileModifiedValue == null){
										fileModifiedValue = "[Blank]";
									}
									if(fileModifiedValue.equalsIgnoreCase(cspiIdDbVal)){
										logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
										softAssert.assertTrue(true, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									}
									else{
										logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
										softAssert.assertTrue(false, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									}
								}
								catch(Exception e){
									System.out.println("CSPI ID is not present in database");
								}
					 		}
						}
						else{
							logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							softAssert.assertTrue(true, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
						}
					}
						
						else if (columnKey.equalsIgnoreCase("sbel_void_ind")){
							if(dbValue.equalsIgnoreCase("N")){
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							else{
								logger.log(LogStatus.FAIL, "Subscriber is voided");
							}
							softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
						}
						else{
							if(fileValue.equalsIgnoreCase(dbValue)){
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							else{
								logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
						}
						
						
					}
				/*}
				else{
					logger.log(LogStatus.WARNING,"Subscriber is loaded into Facets, we cannot see this subscriber in MEET with the error, as this is not EBR error.");
				}*/
			}
				
				else{
					if(strFileType.contains("HCO") && sql1HCOMap.containsKey(primaryKey)){
						logger.log(LogStatus.FAIL," This Subscriber id (" + primaryKey.toUpperCase() + ") is loaded into FACETS successfully, but HCO file PCP (" + flatFileValuesMap.get(primaryKey).get("prpr_id") + ") is NOT assigned and PCP got assigned through Auto PCP process");
					}
					else if(strFileType.contains("Salesforce_PCP_Assign") && sql1SFMap.containsKey(primaryKey)){
						logger.log(LogStatus.FAIL," This Subscriber id (" + primaryKey.toUpperCase() + ") is loaded into FACETS successfully, but HCO file PCP (" + flatFileValuesMap.get(primaryKey).get("prpr_id") + ") is NOT assigned and PCP got assigned through Auto PCP process");
					}
					else
					{
						logger.log(LogStatus.FAIL,"Data is NOT present in Facets and MEET database for this CINN Number: " + primaryKey.toUpperCase()  + ". Please check MMS logs for more details");
					}
				}
			}
					
			//Reporting subscriber ID in HTML report when it is not loaded into FACETS
			catch(Exception e){
				if(strFileType.contains("HCO") && sql1HCOMap.containsKey(primaryKey)){
					logger.log(LogStatus.FAIL," This Subscriber id (" + primaryKey.toUpperCase() + ") is loaded into FACETS successfully, but HCO file PCP (" + flatFileValuesMap.get(primaryKey).get("prpr_id") + ") is NOT assigned and PCP got assigned through Auto PCP process");
				}
				else if(strFileType.contains("Salesforce_PCP_Assign") && sql1SFMap.containsKey(primaryKey)){
					logger.log(LogStatus.FAIL," This Subscriber id (" + primaryKey.toUpperCase() + ") is loaded into FACETS successfully, but HCO file PCP (" + flatFileValuesMap.get(primaryKey).get("prpr_id") + ") is NOT assigned and PCP got assigned through Auto PCP process");
				}
				else{
					logger.log(LogStatus.FAIL," Data is NOT present in Facets and MEET database for this CINN Number: " + primaryKey.toUpperCase()  + ". Please check MMS logs for more details");
				}
			}
		}
	}
	
	private  String [] funcSourceTargetTransformationLogic(String key,String fileValue,String dbValue, String strFileType) throws Exception{
		String fileModifiedValue,dbModifiedValue;
		String [] strReturn = new String[2];
		
		if(fileValue == null){
			fileValue = "[Blank]";
			fileModifiedValue = fileValue;
		}
		else{
			fileModifiedValue = fileValue;
		}
		
		if(dbValue == null){
			dbValue = "[Blank]";
			dbModifiedValue = dbValue;
		}
		else{
			dbModifiedValue = dbValue;
		}
		
		//Replacing null values with [Blank] for user understanding
		if(fileValue.toString().trim().equalsIgnoreCase(""))
			fileValue = "[Blank]";
		if(dbValue.toString().trim().equalsIgnoreCase(""))
			dbValue = "[Blank]";
		if(fileValue.equalsIgnoreCase(";")|| fileValue.equalsIgnoreCase(";;"))
			fileValue = "[Blank]";
		fileModifiedValue = fileValue.trim().toUpperCase();
		dbModifiedValue = dbValue.trim().toUpperCase();
		
		
		//To validate Primary County Code field field
		if(key.equalsIgnoreCase("Primary County_411")){					
			if(fileModifiedValue.contains(dbModifiedValue)){
				if(dbModifiedValue.equals("19") || dbModifiedValue.equals("37"));{
				}
			}
			else{
				System.out.println("Invalid County Code");
			}
		}
		
		 //To validate ETHNICITY field
		 if(key.equalsIgnoreCase("MEME_MCTR_ETHN_NVL")){
			 String strQuery = "Select distinct FACETS_ETHNIC_CD from CU_ETHNIC_MAP_XREF where EDI_ETHNIC_CD = '" + fileValue + "'";
			 Map<String,String> ethinicity = new HashMap<String,String>();
			 ethinicity = new DBUtils().getOneRowResultSetAsMap("facets", strQuery);
			 fileModifiedValue = ethinicity.get("FACETS_ETHNIC_CD");
			 if(fileModifiedValue == null){
				 fileModifiedValue = "[Blank]";
			 }
		} 
		 
		//To validate LANGUAGE field
		 if(key.equalsIgnoreCase("MEME_MCTR_LANG")){
			 String strQuery = "select * FROM CU_LANG_MAP_XREF where EDI_LANG_CD = '" + fileValue + "'";
			 Map<String,String> language = new HashMap<String,String>();
			 language = new DBUtils().getOneRowResultSetAsMap("facets", strQuery);
			 fileModifiedValue = language.get("FACETS_LANG_CD");
			 if(fileModifiedValue == null){
				 fileModifiedValue = "[Blank]";
			 }
		} 
		 
		 //To validate PlanID field
		 if(key.equalsIgnoreCase("CSPI_ID")){
			 if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
			     String strQuery = "SELECT * FROM CU_CARE1ST_MCAL_CLS_PLN_XREF where lob_id='19' and  capitn_aid_cd= '" + fileValue.toUpperCase() + "'";
				 Map<String,String> planId = new HashMap<String,String>();
				 try{
					 planId = new DBUtils().getOneRowResultSetAsMap("facets", strQuery);
					 fileModifiedValue = planId.get("FACETS_PLN_ID");
					 if(fileModifiedValue == null){
						 fileModifiedValue = "[Blank]";
					 }
				 }
				 catch(Exception e){
					 System.out.println("Invalid CSPI ID");
				 }
			 }
				 
		 	 if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834")){
		 		 String strQuery = "SELECT * FROM CU_CARE1ST_MCAL_CLS_PLN_XREF where lob_id='37' and  capitn_aid_cd= '" + fileValue.toUpperCase() + "'";
				 Map<String,String> planId = new HashMap<String,String>();
				 try{
					 planId = new DBUtils().getOneRowResultSetAsMap("facets", strQuery);
					 fileModifiedValue = planId.get("FACETS_PLN_ID");
					 if(fileModifiedValue == null){
						 fileModifiedValue = "[Blank]";
					 }
				 }
				 catch(Exception e){
					System.out.println("Invalid CSPI ID");
				}
		 	}
		 	 
		 	
		 }
	 
		 
		strReturn[0] = fileModifiedValue;
		strReturn[1] = 	dbModifiedValue;
		return strReturn;
	}

		
	//TODO: Replace valueExistsInDb with this logic whenever all data elements on the file and DB are accounted for
	/**
	 * Perform a difference between actual VS expected
	 * @param flatFileValuesMap
	 * @param sql1Map
	 * @return map difference as a sorted map of sorted maps
	 */
	
	@SuppressWarnings("unused")
	private MapDifference<String, SortedMap<String, String>> getMapDiff(
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap,
		SortedMap<String, SortedMap<String, String>> sql1Map) {
		MapDifference<String, SortedMap<String, String>> diff = Maps.difference(flatFileValuesMap, sql1Map);

		Set<String> keysOnlyInActual = diff.entriesOnlyOnLeft().keySet();
		Set<String> keysOnlyInExpected = diff.entriesOnlyOnRight().keySet();
		
		if (!keysOnlyInActual.isEmpty()) {
			System.out.println("Keys only in actual: ");
			for (String key : keysOnlyInActual){
				System.out.println(key);
			}
		}

		if (!keysOnlyInExpected.isEmpty()){
			System.out.println("Keys only in expected: ");
			for (String key : keysOnlyInExpected){
				System.out.println(key);
			}
		}

		if (!diff.areEqual()){
			Set<String> entriesDifferingKeySet = diff.entriesDiffering().keySet();
			Map<String, ValueDifference<SortedMap<String, String>>> entriesDifferring = diff.entriesDiffering();
			ValueDifference<SortedMap<String, String>> valuesDifference = null;
			System.out.println("Entries differring");
			System.out.println("------------------");
			for (String key : entriesDifferingKeySet){
				System.out.println("key = " + key);
				valuesDifference = entriesDifferring.get(key);
				System.out.println("ACTUAL: \t" + valuesDifference.leftValue());
				System.out.println("EXPECTED: \t" + valuesDifference.rightValue());
				System.out.println("\t\tActual \t\t|\t\t Expected");
				logger.log(LogStatus.INFO, "\t\tActual \t\t|\t\t Expected values for CINN number: " + key);
				
				//Developer needs to ensure that both the file map and database maps have the SAME number AND order of Key values.
				//If this is not done, additional logic will be requried to handle the comparison.
				for (String diffKey : valuesDifference.leftValue().keySet()){
					String left = valuesDifference.leftValue().get(diffKey);
					String right = valuesDifference.rightValue().get(diffKey);
					if (!(left == null && right == null) && !left.equals(right)){
						System.out.println(diffKey + ": " + left + " | " + right);
						logger.log(LogStatus.FAIL, diffKey + ": " + left + " | " + right);
					}
					else{
						logger.log(LogStatus.PASS, diffKey + ": " + left + " | " + right);
					}
				}
				System.out.println("\n");
			}
		}
		return diff;
	}

	/**
	 * //To run test method, this method will initiate the HTML report
	 * 
	 * @Override run is a hook before @Test method
	 */
	
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult){
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting Test " + testResult.getName());
		callBack.runTestMethod(testResult);
		//To display the failure count in console
		softAssert.assertAll(); 
	}

	private Map<String, String> getData(String testMethodName) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		// assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/" + this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, testMethodName);
		return dataMap;
	}
}
	