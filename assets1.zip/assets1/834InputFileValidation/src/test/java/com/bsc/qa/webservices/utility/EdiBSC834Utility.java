package com.bsc.qa.webservices.utility;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody;
//import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.readers.BscaCare1stMMFlatFileReader;
import com.bsc.qa.framework.utility.DBUtils;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.relevantcodes.extentreports.LogStatus;


public class EdiBSC834Utility {
	public static BscaCare1stMMFlatFileReader ffpExtract;
	public static int flag = 1;
	public static int count=0;
	public static int flag1=0;
	public static int intdependentCounter=0;
	
	
	/*
	 *For getting 834 file data from 834 EDI file
	 * @param strCompleteFilePath: 834 file path
	 * @param strInputFileName: 834 file name
	 * @return
	 * @throws IOException 
	 * @throws Exception: To capture the exception
	 */
	
	public LinkedHashMap<String, SortedMap<String, String>> get834FileData(String strCompleteFilePath, String strInputFileName,Map<String, String> data) throws Exception{
		String strFileType;
		String primaryKey;
		LinkedHashMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		SortedMap<String, String> singleRecordMap = null;
		String strFileFieldAndTableColumnMapping = "src//test//resources//FileFieldAndTableColumnMapping.xlsx";
		strCompleteFilePath = strInputFileName;
		String strOtherQueries = data.get("PCP_QUERY");
		int Dependent=0;
		
		String strInputExactFileName = strInputFileName.substring(strInputFileName.lastIndexOf("\\") + 1);
		// To get 834 file type
		strFileType = fileType834(strInputExactFileName);
		flatFileValuesMap = new LinkedHashMap<String, SortedMap<String, String>>();
		//System.out.println("---------------------"+System.getenv("CIN_COMPLETE_FILE_PATH"));
		
		// Checking for the 834 file type
		if (strFileType.contains("834")|| strFileType.contains("834_IN_") || strFileType.contains("benefit_focus")){
			// For capturing all CINN numbers from 834 file
			List<String> rowsListSSNNumbers = parse834FileForCINNNumbers(strCompleteFilePath, strFileType);
			//List<String>DependentSSNNumbers= rowsList1;
			
		//ID Cards changes
		//Write Content

			// Looping through all SSN numbers for validation
			for (String strSSNNNumber : rowsListSSNNumbers){
				singleRecordMap = new TreeMap<String, String>();
				
				//singleRecordMap1 = new TreeMap<String, String>();
				primaryKey = strSSNNNumber.trim().toLowerCase();
				//For retrieving SSN number specific data from 834 file
				List<String> rowsList = parse834File(strCompleteFilePath, 
				primaryKey.toUpperCase(), strFileType);
				//To retrieve first subscriber section data in "NM1*IL*" segment
				int intSubscriber = 0;
				int intaddress=0;
			
				String line1 = "";
				//SSN number storing in a map for comparison
				//singleRecordMap.put("SSN_Number", strSSNNNumber.trim().toLowerCase());
				System.out.println("SSN Number used while storing flat file data: " + strSSNNNumber.trim().toLowerCase());
				
				//To implement Eligibility Validations
				String line3 = "";
				String line4 = "";
				String strAidCode ="";
				String hcpStatusCode = "";
				String eligibilityDate = "";
				String hcpCode = "";
				//int dependedntCounter=0;
							
				String strDependent="";
		//Looping through all SSN number records to retrieve required values				
			for (int i = 0; i < rowsList.size(); i++){
				
				//Storing field values to validate subscriber's First name, last Name and Middle initial
				
					
				if(rowsList.get(i).startsWith("NM1*IL*"))
				{
					
					if(intSubscriber == 0){
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						//strDependent = strSSNNNumber;
						
					       try{
							singleRecordMap.put("last_name",line1.split("\\*")[3]);
							singleRecordMap.put("first_name",line1.split("\\*")[4]);
							intSubscriber = intSubscriber + 1;
						}
						
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					       
					}
					
				}
				
				if (rowsList.get(i).startsWith("DMG*"))
				{
					//int count =0;
					//count++;
					//if(count==1){
					line1 = rowsList.get(i).toString().toLowerCase();
					line1 = line1.replace("~", "");
					
					try{
						singleRecordMap.put("dob" ,line1.split("\\*")[2]);
						singleRecordMap.put("sex",line1.split("\\*")[3].replace("~", ""));
					}
					
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
					}
				/*SortedMap<String, SortedMap<String, String>> sql1Map = null;
				String strQuery = "      ";
				String query1=" ";
				sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("SQL_TEMPLATE") + "  " + strQuery.toString().toUpperCase()+")", data.get("PRIMARY_KEY"));*/
				//  Storing field values to validate subscriber's Telephone Number
				
				if (rowsList.get(i).startsWith("PER*IP*")){
					line1 = rowsList.get(i).toString().toLowerCase();
					line1 = line1.replace("~", "");
					try{
						singleRecordMap.put("email",line1.split("\\*")[4].replace("~", ""));
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
					/*sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("SQL_TEMPLATE") + "  " + strQuery.toString().toUpperCase()+")", data.get("PRIMARY_KEY"));
					
					if(sql1Map.containsKey("telephone")){
						
						
					}*/
				}

				//  Storing field values to validate subscriber's Address
				if (rowsList.get(i).startsWith("N3*")){
					if((strFileType.equalsIgnoreCase("IRT_EDI834_CalPERS_New Enrollment"))){
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");	
//						line1.split("\\*")[1].substring(0).replace(",", "");
						System.out.println("the value is "+line1);
						try{singleRecordMap.put("address", line1.split("\\*")[1].substring(0).replace("~", ""));
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
					
					else if((strFileType.equalsIgnoreCase("eEnrollment_benefit_focus")|| strFileType.equalsIgnoreCase("eExchange_benefit_focus"))){
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");	
						line1.split("\\*")[1].substring(0);
						System.out.println("the value is "+line1);
						try{singleRecordMap.put("address", line1.split("\\*")[1].substring(0));
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
					
//					line1 = rowsList.get(k).toString().toLowerCase();
//					line1 = line1.replace("~", "");	
//					add condition here
//					line1=line1.replace(",", "");
//					//line1.split("\\*")[1].substring(4).replace(",", " ");
//					System.out.println("the value is line749"+line1);
//					try{singleRecordMap.put("address", line1.split("\\*")[1].substring(0).replace("~", ""));
//					}
//					catch(Exception e){
//						System.out.println("Data not present for validation for homeless member");
//					}
					
					//To validate the address field for Homeless member
					try{
						if((line1.split("\\*")[1].substring(0).replace("~", "")).contains("Homeless")){
							singleRecordMap.put("address1", "UNK");
							singleRecordMap.put("adresss2", "[Blank]");
							singleRecordMap.put("address3","Homeless");
						}
					}
					catch(Exception e){
						System.out.println("Not a Homeless memeber");
					}
					
					//To validate the address field for P.O. Box
					String address2 = "";
					String address3 = "";
					String newString = "";
					String address1 = "";
					try{
						int ad =line1.split("\\*")[1].substring(0).replace("~", "").indexOf("APT");
						System.out.println("the value is "+ad);						
						address2 = line1.split("\\*")[1].substring(0).replace("~", "").substring(line1.split("\\*")[1].substring(0).replace("~", "").indexOf("APT"));
						//System.out.println("the value is of "+address2);
						newString = line1.split("\\*")[1].substring(0).replace("~", "").replaceAll(address2, "");
						newString.indexOf("P.O.");
						address1 = newString.substring(newString.indexOf("P.O."));
						System.out.println("the value is off "+address1);
						address3 = newString.replaceAll(address1, "");
						System.out.println("the value is "+address3);
						
						singleRecordMap.put("address2",address2);
						singleRecordMap.put("address3",address3);
						singleRecordMap.put("address1",address1);
					}
					catch(Exception e){
						System.out.println("P.O. Box not present in address");
					}
				}

				
				
			//  Storing field values to validate subscriber's City, State, ZipCode
				if (rowsList.get(i).startsWith("N4*")){
					if(intaddress == 0){
					line1 = rowsList.get(i).toString().toLowerCase();
					line1 = line1.replace("~", "");
					try{
						singleRecordMap.put("city", line1.split("\\*")[1]);
						singleRecordMap.put("state", line1.split("\\*")[2]);
						singleRecordMap.put("zipcode", line1.split("\\*")[3].replace("~", ""));
						intaddress = intaddress + 1;
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
					}
				}
				//to store ethincity value
				if(rowsList.get(i).startsWith("DMG*")){
					line1=rowsList.get(i).toString();					
					line1 = line1.replace("~", "");
					try{
						if(line1.split("\\*")[5].length()>6){
						singleRecordMap.put("MEME_MCTR_ETHN_NVL".toLowerCase(),line1.split("\\*")[5].substring(5,11).replace("~", ""));
						}
					}
					catch(Exception e){
						System.out.println("Incorrect Ethnicity data in file");
					}
				}
				
				
				
				// Storing field values to validate subscriber's Effective field
				if(rowsList.get(i).startsWith("DTP*349*")){	
					System.out.println("the val;ues os");
					if((strFileType.equalsIgnoreCase("IRT_EDI834_CalPERS_New Enrollment")|| strFileType.equalsIgnoreCase("eEnrollment_benefit_focus")|| strFileType.equalsIgnoreCase("eExchange_benefit_focus"))){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							singleRecordMap.put("sbel_eff_dt".toLowerCase(), line1.split("\\*")[3].replace("~", ""));
							singleRecordMap.put("SBEL_ELIG_TYPE".toLowerCase(), "TM");
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				//storing field values for the medical coverage added field
				if(rowsList.get(i).startsWith("DTP*348*")){	
					System.out.println("the val;ues os");
					if((strFileType.equalsIgnoreCase("IRT_EDI834_CalPERS_New Enrollment")|| strFileType.equalsIgnoreCase("eEnrollment_benefit_focus")|| strFileType.equalsIgnoreCase("eExchange_benefit_focus"))){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						try{
							singleRecordMap.put("SBEL_EFF_DT_SL".toLowerCase(), line1.split("\\*")[3].replace("~", ""));
							singleRecordMap.put("SBEL_ELIG_TYPE_SL".toLowerCase(), "SL");
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
					//break;
					
				}
				if(rowsList.get(i).startsWith("DTP*303*")){	
					if((strFileType.equalsIgnoreCase("IRT_EDI834_CalPERS_New Enrollment")|| strFileType.equalsIgnoreCase("eEnrollment_benefit_focus")|| strFileType.equalsIgnoreCase("eExchange_benefit_focus"))){
						//line1=rowsList.get(i).toString();
						//line1 = line1.replace("~", "");	
						//try{
							//singleRecordMap.put("SBEL_EFF_DT_SL".toLowerCase(), line1.split("\\*")[3].replace("~", ""));
							//singleRecordMap.put("SBEL_ELIG_TYPE_SL".toLowerCase(), "SL");
						//}
						//catch(Exception e){
							//System.out.println("Data not present for validation");
						//}
					}
					//i=k+1;
					//break;
					
				}
				
				
				

				
				
				// Storing field values to validate PCP information 
				if(rowsList.get(i).startsWith("NM1*P3")){
					if((strFileType.equalsIgnoreCase("IRT_EDI834_CalPERS_New Enrollment")|| strFileType.equalsIgnoreCase("eEnrollment_benefit_focus")|| strFileType.equalsIgnoreCase("eExchange_benefit_focus"))){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("prpr_npi_tx".toLowerCase(),line1.split("\\*")[9]);
							System.out.println(line1);
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
					//break;
				}
				
				// Storing field values to validate Plan information 
				if(rowsList.get(i).startsWith("HD*")){
					if((strFileType.equalsIgnoreCase("IRT_EDI834_CalPERS_New Enrollment")|| strFileType.equalsIgnoreCase("eEnrollment_benefit_focus")|| strFileType.equalsIgnoreCase("eExchange_benefit_focus"))){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("cspi_id".toLowerCase(),line1.split("\\*")[4]);
							System.out.println(line1);
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
					//break;
				}
				// Storing field values to validate GroupId information 
				
				if(rowsList.get(i).startsWith("REF*1L*")){
					if((strFileType.equalsIgnoreCase("IRT_EDI834_CalPERS_New Enrollment")|| strFileType.equalsIgnoreCase("eEnrollment_benefit_focus")|| strFileType.equalsIgnoreCase("eExchange_benefit_focus"))){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("GroupID".toLowerCase(),line1.split("\\*")[2]);
							System.out.println(line1);
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
					//break;
				}
				
				// Storing field values to validate Language information 
				if(rowsList.get(i).startsWith("LUI*")){
					line1=rowsList.get(i).toString();
					line1 = line1.replace("~", "");	
				String LangCode=line1.split("\\*")[2]+1;
					try{
						
						singleRecordMap.put("MEME_MCTR_LANG".toLowerCase(), LangCode);
						
						
					}
					catch(Exception e){
						System.out.println("Incorrect Language data in file");
					}
				}
				
				if(rowsList.get(i).startsWith("NM1*Y2")){
					if((strFileType.equalsIgnoreCase("IRT_EDI834_CalPERS_New Enrollment")|| strFileType.equalsIgnoreCase("eEnrollment_benefit_focus")|| strFileType.equalsIgnoreCase("eExchange_benefit_focus"))){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("prpr_npi".toLowerCase(),line1.split("\\*")[9]);
							System.out.println(line1);
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
					//break;
				}
				
				}
				
								
			//Storing all subscriber filed values map as a value and subscriber id as key
			flatFileValuesMap.put(primaryKey, singleRecordMap);
			//flatFileValuesMap.put(primaryKey, singleRecordMap1);
			
			
			
						
			
			//singleRecordMap.clear();
		}
				
	}
						
		// Returning SortedMap<String, SortedMap<String, String>> with 834 file values
		return flatFileValuesMap;
		//flatFileValuesMap.clear();
		
		}
		
	
	

/**
 * Changing 834 EDI file format when it is having one line
 * @param strFlatFileCompletePath: 834 file complete path
 * @throws Exception: To capture exception
 */
	
public void fileFormatChange834(String strFlatFileCompletePath) throws Exception
{	
	FileWriter fileWriter = null;
	FileReader fileReader  = null;
	BufferedReader bufferedReader = null;
	
	try{
		File inputFile = new File(strFlatFileCompletePath);
		String strLines = "";
		String line = "";
		//Checking for the file existence
		if(!inputFile.exists()){ 
			throw new IllegalStateException("File not found: " + strFlatFileCompletePath);
		} 
		else{
			fileReader =  new FileReader(inputFile);
			bufferedReader =        new BufferedReader(fileReader);
			int intICounter = 0;
			//Reading each line from the file
			while((line = bufferedReader.readLine())!=null){
				strLines = strLines + line;
				intICounter += 1;
				//Checking for single line 834 file
				if(intICounter > 1){
					bufferedReader.close();
					return;
				}
			}
		
			byte [] strBytes = strLines.getBytes();
			String strAllLines = new String (strBytes,StandardCharsets.UTF_8);
			//Replacing "~" symbol with "~\r\n"
			String strFormatLines = strAllLines.replaceAll("~", "~\r\n");
			fileWriter = new FileWriter(strFlatFileCompletePath);
			//Writing the data once again into the file after changes
			fileWriter.write(strFormatLines);
		  }
	}
	
	//For capturing exception
	catch(Exception e){
		e.printStackTrace();
	}
	finally{
		try{
			//Closing all opened file objects
			fileReader.close();
			fileWriter.close();
			bufferedReader.close();
		}
		catch(Exception ex){
			//ex.printStackTrace();
		}
	}
}

/*
**
* @param testFlatFileCompletePath: File complete path
* @param strSSNumber: To capture specific subscriber section
* @param strFileName: 834 file type
* @return: List of subscriber lines
* @throws Exception" To capture the exception
*/

public  List<String> parse834File(String testFlatFileCompletePath,String strCINNNumber, String strFileName) throws Exception{
                File inputFile = new File(testFlatFileCompletePath);
                String line=null;
                BufferedReader bufferedReader = null;
                List<String> rowsList=new ArrayList<String>();
                //For checking file existence
                if(!inputFile.exists()){ 
                                  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
                  } 
                 else{
                                //Changing the layout when it is having in one single line
                                  fileFormatChange834(testFlatFileCompletePath);
                                  if((strFileName.contains("IRT_EDI834_CalPERS_")|| strFileName.contains("eEnrollment_benefit_focus")|| strFileName.contains("eExchange_benefit_focus"))){
                                                  FileReader fileReader =  new FileReader(testFlatFileCompletePath);
                                                  bufferedReader = new BufferedReader(fileReader);
                                                  boolean flag=false;
                                                  //Reading each line in the file 
                                      while((line = bufferedReader.readLine()) != null) {
                                                  //Checking for the CINN Number
                                                                if(line.contains(strCINNNumber)){
                                                                       flag=true;
                                                                  }
                                                                  //Checking for the starting line for each subscriber section
                                                                  if((line.startsWith("INS*Y*18*"))|| (line.startsWith("INS*N"))){
                                                                                  if(flag){
                                                                                                  break;
                                                                       }else{
                                                                                   //To clear the records if it is not matches to the provided CINN number
                                                                           rowsList.clear();
                                                                        }
                                                                   }
                                                                   //Adding lines to the records list
                                                                                rowsList.add(line);
                                                                  }   
                                      }
                                  
                                                                  //To capture DHCS file specific subscriber lines
                                                                  else if(strFileName.contains("DHCS")){
                                                                                  FileReader fileReader =  new FileReader(testFlatFileCompletePath);
                                                                                  bufferedReader =  new BufferedReader(fileReader);
                                                                                  boolean flag=false;
                                                                                  //Reading each line in the file 
                                                                      while((line = bufferedReader.readLine()) != null){
                                                                      //Checking for the CINN Number
                                                                                  if(line.contains(strCINNNumber)){
                                                                                                  flag=true;
                                                                          }
                                                                          //Checking for the starting line for each subscriber section
                                                                          if((line.startsWith("INS*Y*18*"))|| (line.startsWith("INS*N"))){
                                                                                 if(flag){
                                                                                                 break;
                                                                                 }else{
                                                                                                 //To clear the records if it is not matches to the provided CINN number
                                                                                                 rowsList.clear();
                                                                                  }
                                                                               }
                                                                               //Adding lines to the records list
                                                                               rowsList.add(line);
                                                                               }  
                                                                  }
                                                                  else{
                                                                                  //Printing line when user has selected invalid file
                                                                                  System.out.println("Please select valid file type to retrieve data from flat file ");
                                                                  }
                                }
                
                 //To close the bufferedReader object
                if(bufferedReader!=null)
                                bufferedReader.close();
                               return rowsList;
}


/**
* To capture SSN Numbers from 834 file
* @param testFlatFileCompletePath: 834 File complete path
* @param strFileName: 834 file type
* @return: List of SSN Numbers
* @throws Exception: Throwing exception
*/

public  List<String> parse834FileForCINNNumbers(String testFlatFileCompletePath, String strFileName){
                File inputFile = new File(testFlatFileCompletePath);
                SortedMap<String, String> singleRecordMap1 = null;
                singleRecordMap1 = new TreeMap<String, String>();
                String line=null;
                BufferedReader bufferedReader = null;
                List<String> rowsList=new ArrayList<String>();
                List<String> rowsList1=new ArrayList<String>();
                
                
                 boolean blnSubscriberFlag =false;
                try{
                    //Checking for the file existence
                    if(!inputFile.exists()){ 
                                throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
                    } 
                    else{
                                //Changing the layout when it is not expected
                                    fileFormatChange834(testFlatFileCompletePath);
                                    //To capture SSN Numbers from LACare file
                                    if((strFileName.contains("IRT_EDI834_CalPERS_")|| strFileName.contains("eEnrollment_benefit_focus")|| strFileName.contains("eExchange_benefit_focus"))){
                                                FileReader fileReader =  new FileReader(testFlatFileCompletePath);
                                                                bufferedReader = new BufferedReader(fileReader);
                                                                //Looping through all lined for checking CINN Number line
                                                                while((line = bufferedReader.readLine()) != null){
                                                                                if(line.startsWith("NM1*IL*1*")){
                                                                                	//count++;
                                                                                	//if (!blnSubscriberFlag){
                                                                                        //Adding CINN number to the list
                                                                                        rowsList.add(line.split("\\*")[9].replace("~", ""));
                                                                                        //blnSubscriberFlag = true;
                                                                                	//}
                                                                                	//if(count>=1){
                                                                                		//if(line.startsWith("NM1*IL*1*")){
                                                                                		
                                                                                		//rowsList1.add(line.split("\\*")[9].replace("~", ""));
                                                                                		//rowsList1.add
                                                                                	//}
                                                                                			
                                                                                	//} 
                                                                                	//count++;
                                                                               }
                                                                                /*if(line.startsWith("ST*")){
                                                                                	blnSubscriberFlag = false;
                                                                               }*/
                                                                }   
                                    }
                                    
                                    
                                                //To capture CINN Numbers from DHCS file
                                    else if(strFileName.contains("DHCS")){
                                                FileReader fileReader =  new FileReader(testFlatFileCompletePath);
                                                                bufferedReader = new BufferedReader(fileReader);
                                                                //Looping through all lined for checking CINN Number line
                                                                while((line = bufferedReader.readLine()) != null){
                                                                                if(line.startsWith("REF*0F*")){
                                                                                                //Adding CINN number to the list
                                                                        rowsList.add(line.split("\\*")[2].replace("~", ""));
                                                                     }
                                                                }  
                                    }
                                    else{
                                                System.out.println("Please select valid file type to retrieve data from flat file ");
                                                }
                }
                    
                 //To close the bufferReader object
                if(bufferedReader != null)
                                bufferedReader.close();
}
                //To capture and print the exception
                catch (Exception e){
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                }
                
                //For returning list of CINN numbers 
                return rowsList;
                
                
}




/**
 * @param testFlatFileCompletePath: File complete path
 * @param strSSNNNumber: To capture specific subscriber section
 * @param strFileName: 834 file type
 * @return: List of subscriber lines
 * @throws Exception" To capture the exception
 */




/**
 * To find file type for 834 
 * @param strFileName: Name of the file
 * @return: File name used for coding
 */

public String fileType834(String strFileName){
	if(strFileName.contains("\\")){
		strFileName = strFileName.substring(strFileName.lastIndexOf("\\") + 1);
		//System.out.println("file name is"+ strFileName);
	}
	//Checking for the expected file name
	if(strFileName.contains("CFST.D"))
		return "LACounty_Medi-Cal_Members(LACare)834";
	else if(strFileName.contains("834"))
		return "IRT_EDI834_CalPERS_New Enrollment";
	else if(strFileName.startsWith("eEnrollment_benefit_"))
		return "eEnrollment_benefit_focus";
	else if(strFileName.startsWith("eExchange_benefit_"))
		return "eExchange_benefit_focus";
	else 
		System.out.println("This file name is invalid: " + strFileName );
		return null;
}

//below method is to handle the index out of bound exception
public String  partialStringRetrieval(String strKeyName,String line,int indexValue, int intStartPos, int intEndingPos){
	if(!(intStartPos == 0 && intEndingPos == 0)){
		 try{
             String strValue = line.split("\\*")[indexValue].substring(intStartPos,intEndingPos).replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    return strValue;
             }
		 }
		 catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
			return "";
		 }
	}
	else{
		 try{
             String strValue = line.split("\\*")[indexValue].replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
            	 return strValue;
             }
		 }
         catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
            return "";
       }
	}
	return "";
}


public static  List<SortedMap<String,String>> parseFileWithOutHeaderByDelimeter(String delimeter,String testFlatFileCompletePath,String fieldColumnMappingFilePath,String mappingSheetName) throws IOException{
	 File inputFile = new File(testFlatFileCompletePath);
	 List<SortedMap<String,String>> listOfRows=new ArrayList<SortedMap<String,String>>();
	 String line=null;
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  }
	 else{
		 System.out.println("Starting of File Reading . . . . . .  . . . . ");
		 new ExcelUtilsExtended(fieldColumnMappingFilePath,mappingSheetName);
		 FileReader fileReader =  new FileReader(testFlatFileCompletePath);
		 @SuppressWarnings("resource")
	     BufferedReader bufferedReader = new BufferedReader(fileReader);
		 while((line = bufferedReader.readLine()) != null){
			 String[] columnsArray = line.split(delimeter);
			 SortedMap<String,String> rowMap=new TreeMap<String,String>();
			 int columnLength=columnsArray.length;
			 for(int i=0;i<columnLength;i++){
				 String fileFieldName=String.valueOf(i);
			     String columnNameKey=ExcelUtilsExtended.getDBColumnName(fileFieldName);
				 if(columnNameKey!=null){
					 rowMap.put(columnNameKey.toLowerCase(),columnsArray[i].toLowerCase());	//System.out.println(rowNo+"  columnlength::"+columnLength+" index: "+i+"  "+rowsList.get(rowNo)[i]);
				 }
			 }
		 listOfRows.add(rowMap);
		 }   	    
 	}
	return listOfRows;
}


public SortedMap<String,SortedMap<String,String>> sortedMapMergingRough(SortedMap<String,SortedMap<String,String>> map1,SortedMap<String,SortedMap<String,String>> map2){
	SortedMap<String,SortedMap<String,String>> map3Return = new TreeMap<String,SortedMap<String,String>>();
	SortedMap<String,String> tempMap1 = new TreeMap<String, String>();
	SortedMap<String,String> tempMap2 = new TreeMap<String, String>();
	SortedMap<String,String> tempMapMerged = new TreeMap<String, String>();
	String tempMapKey1 = null;
	String tempMapKey2 = null;
	Boolean blnFlag = false;
	
	for(Entry<String,SortedMap<String,String>> mapEntry1 : map1.entrySet()){
		tempMap1 = mapEntry1.getValue();
		tempMapKey1 = mapEntry1.getKey();
		for(Entry<String,SortedMap<String,String>> mapEntry2 : map2.entrySet()){
			tempMap2 = mapEntry2.getValue();
			tempMapKey2 = mapEntry1.getKey();
			if(tempMapKey1.equalsIgnoreCase(tempMapKey2)){
				tempMapMerged.putAll(tempMap1);
				tempMapMerged.putAll(tempMap2);
				map3Return.put(tempMapKey1, tempMapMerged);
				blnFlag = true;
			}
		}
	}
	
	if(!blnFlag && map1.size()!=0){
		map3Return.putAll(map1);
	}
	
	else if(!blnFlag && (map2.size()!=0)){
		map3Return.putAll(map2);
	}
	
	return map3Return;
	
}

// Function for merging of all the query maps into a single map
public SortedMap<String,SortedMap<String,String>> sortedMapMerging(SortedMap<String,SortedMap<String,String>> map1,SortedMap<String,SortedMap<String,String>> map2){
    SortedMap<String,SortedMap<String,String>> map3Return = new TreeMap<String,SortedMap<String,String>>();
    SortedMap<String,String> tempMap1 = new TreeMap<String, String>();
    SortedMap<String,String> tempMap2 = new TreeMap<String, String>();
    String tempMapKey1 = null;
    
    for(Entry<String,SortedMap<String,String>> mapEntry1 : map1.entrySet()){
    	tempMap1 = mapEntry1.getValue();
        tempMapKey1 = mapEntry1.getKey();
        if(map2.containsKey(tempMapKey1)){
        	SortedMap<String,String> tempMapMerged = new TreeMap<String, String>();
            tempMap2 = map2.get(tempMapKey1);
            tempMapMerged.putAll(tempMap1);
            tempMapMerged.putAll(tempMap2);
            map3Return.put(tempMapKey1, tempMapMerged);
         }
         else{
        	map3Return.put(tempMapKey1, tempMap1);
         }
    }
    
    for(Entry<String,SortedMap<String,String>> mapEntry2 : map2.entrySet()){
    	tempMap1 = mapEntry2.getValue();
        tempMapKey1 = mapEntry2.getKey();
        if(!map1.containsKey(tempMapKey1)){
        	map3Return.put(tempMapKey1, tempMap1);
        }  
    }
    
    return map3Return;
}

//Function to get Special Indicator data from database
public SortedMap<String, SortedMap<String, String>>  getSpecialIndicatorData(Set<String> strPrimaryKeySet, String strQuery, String strColumn1,String strColumn2,String strColumn3){
	SortedMap<String,String> strMap = new TreeMap<String,String>();
    SortedMap<String, SortedMap<String, String>> strMapReturn = new TreeMap<String, SortedMap<String, String>>();
    List<Map<String, Object>> specialIndicatorResultSet1 = null;
    String strQueryPrimaryKey = null;
    for(String strPrimaryKey: strPrimaryKeySet){
    	strQueryPrimaryKey = strQuery.replace("Parameter1", strPrimaryKey.toUpperCase());
        specialIndicatorResultSet1 = new DBUtils().getResultSetAsMapList("facets", strQueryPrimaryKey);
        strMap = resultSetToDictionarySpecificColumns(specialIndicatorResultSet1, strColumn1, strColumn2, strColumn3);
        strMapReturn.put(strPrimaryKey, strMap);
    }
    return strMapReturn;
}


public  SortedMap<String,String> resultSetToDictionarySpecificColumns(List<Map<String,Object>> queryResultList, String strColumn1,String strColumn2,String strColumn3){
	SortedMap<String,String> strMap = new TreeMap<String,String>();
	String strTempColumn1 = "";
	String strTempColumn2 = "";
	String strTempColumn3 = "";
	for(int intICounter=0;intICounter<queryResultList.size();intICounter++){
		if(queryResultList.get(intICounter).get(strColumn3)!=null){
			strTempColumn3 =  queryResultList.get(intICounter).get(strColumn3).toString();
		}
		else{
			strTempColumn3 = "[Blank]";
		}
		strTempColumn1 = queryResultList.get(intICounter).get(strColumn1).toString().toLowerCase();
		strTempColumn2 = queryResultList.get(intICounter).get(strColumn2).toString().toLowerCase();	
		strMap.put( strTempColumn1 + "_" +  strTempColumn2,strTempColumn3 );
	}
	return strMap;
	}


}



