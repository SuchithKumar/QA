package com.bsc.qa.facets.afa.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;




import org.apache.commons.collections4.map.HashedMap;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.bsc.qa.facets.afa.excel_reader.AfaInvoiceReportReader;
import com.bsc.qa.facets.afa.pojo.ClaimsActivitySummary;
import com.bsc.qa.facets.afa.pojo.FrontPage;
import com.bsc.qa.facets.afa.pojo.MemberDetails;
import com.bsc.qa.facets.afa.pojo.PlanDetails;
import com.bsc.qa.facets.afa.pojo.ShieldSaving;
import com.bsc.qa.facets.afa.test.AfaInvoiceReportValidationTest;

public class DatabaseUtil {
	/*
	 * GROUPNAME GROUPADDRESS ATTENTION GROUPBILLINGID FUNDINGPERIOD BILDUEDATE
	 * INVOICENO INVOICEDATE CURRENTPERIODCLAIMS BALANCEFORWARD
	 * TOTALDUEFORCLAIMSREIMBURSEMENT BSCACCOUNTANTNAME PHONE FAX EMAIL
	 */
	private Map<String,FrontPage> frontPageDBMap;
	private Map<String,List<ClaimsActivitySummary>> claimsActivitySummaryDBMap;
	private Map<String,List<MemberDetails>> memberDetailsDBMap;
	private  Map<String,List<PlanDetails>> planDetailsDBMap;
	private Map<String,List<ShieldSaving>> shieldSavingDBMap;
	private Session session = AfaInvoiceReportValidationTest.session;
	public static Set<String> frontPageInputSet = new HashSet<String>();
	public static Set<String> claimsActivitySummaryInputSet = new HashSet<String>();
	public static Set<String> shieldSavingsInputSet = new HashSet<String>();
	public static Set<String> memberDetailsInputSet = new HashSet<String>();
	public static Set<String> planDetailsInputSet = new HashSet<String>();
	
	public Map<String,FrontPage> getFrontPageData() {
		frontPageDBMap = new HashedMap<String, FrontPage>();
		QueriesUtil util = new QueriesUtil();
		SQLQuery outerQuery =  session
				.createSQLQuery(util.queriesMap().get("FrontPageUpdatedQuery"));
		List<Object[]> outerResultList = new ArrayList<Object[]>();
		outerResultList = outerQuery.list();
		for (Object[] frontPageData : outerResultList) {
			frontPageInputSet.add((String) frontPageData[6]);
			
		}
		
		for (String invoiceId : frontPageInputSet) {
			List<String> invoiceList = new ArrayList<String>();
			invoiceList.add(invoiceId);
			SQLQuery query = (SQLQuery) session
					.createSQLQuery(util.queriesMap().get("FrontPageQuery")).setParameterList("invoiceId", invoiceList.toArray());
			List<Object[]> resultList = new ArrayList<Object[]>();
			resultList = query.list();
			FrontPage frontPage = new FrontPage();
			for (Object[] frontPageData : resultList) {
				
				frontPage.setGroupName((String) frontPageData[0]);
				frontPage.setGroupAddress((String) frontPageData[1]);
				frontPage.setAttention((String) frontPageData[2]);
				frontPage.setGroupBillingId((String) frontPageData[3]);
				frontPage.setFundingPeriod((String) frontPageData[4]);
				frontPage.setBillDueDate((String) frontPageData[5]);
				frontPage.setInvoiceNo((String) frontPageData[6]);
				frontPage.setInvoiceDate((String) frontPageData[7]);
				frontPage.setCurrentPeriodClaims((String) frontPageData[8]);
				frontPage.setBalanceForward((String) frontPageData[9]);
				frontPage.setTotalDueForClaimsReimbursement((String) frontPageData[10]);
				frontPage.setBscAccountantName((String) frontPageData[11]);
				frontPage.setPhone((String) frontPageData[12]);
				frontPage.setFax((String) frontPageData[13]);
				frontPage.setEmail((String) frontPageData[14]);
				
				if(frontPage.getBscAccountantName()==null || frontPage.getBscAccountantName().equalsIgnoreCase(" ")){
					frontPage.setBscAccountantName("");
				}
				if(frontPage.getAttention()==null || frontPage.getAttention().equalsIgnoreCase(" ")){
					frontPage.setAttention("");
				}
				if(frontPage.getFax()==null || frontPage.getFax().equalsIgnoreCase(" ")){
					frontPage.setFax("");
				}
				if(frontPage.getPhone()==null || frontPage.getPhone().equalsIgnoreCase(" ")){
					frontPage.setPhone("");
				}
				if(frontPage.getEmail()==null || frontPage.getEmail().equalsIgnoreCase(" ")){
					frontPage.setEmail("");
				}
				frontPageDBMap.put(invoiceId,frontPage);
				
			}
			
			
		}
//		for(Map.Entry<String, FrontPage> entry : frontPageDBMap.entrySet()){
//			System.out.println("DataBase Row: "+entry.getValue());
//		}
		
		return frontPageDBMap;

	}

	public Map<String,List<ClaimsActivitySummary>> getClaimsActivitySummary() {
		claimsActivitySummaryDBMap = new HashMap<String, List<ClaimsActivitySummary>>();
		QueriesUtil util = new QueriesUtil();
		
		SQLQuery outerQuery =  session
				.createSQLQuery(util.queriesMap().get("ClaimsActivitySummaryUpdatedQuery"));
		
		List<Object[]> outerResultList = new ArrayList<Object[]>();
		outerResultList = outerQuery.list();
		for (Object[] claimsActivitySummaryData : outerResultList) {
			claimsActivitySummaryInputSet.add((String) claimsActivitySummaryData[6]);
		}
		
		for (String invoiceId : claimsActivitySummaryInputSet) {
			List<String> invoiceList = new ArrayList<String>();
			invoiceList.add(invoiceId);
		SQLQuery query = (SQLQuery) session
				.createSQLQuery(util.queriesMap().get("ClaimsActivitySummaryQuery")).setParameterList("invoiceId", invoiceList.toArray());
		
		List<Object[]> resultList = new ArrayList<Object[]>();
		resultList = query.list();
		List<ClaimsActivitySummary> claimsActivityList = new ArrayList<ClaimsActivitySummary>();
		
		for (Object[] claimsActivitySummaryData : resultList) {
			ClaimsActivitySummary claimsActivitySummary = new ClaimsActivitySummary();
			claimsActivitySummary
					.setClaimPaymentPeriod((String) claimsActivitySummaryData[0]);
			claimsActivitySummary
					.setInvoiceDate((String) claimsActivitySummaryData[1]);
			claimsActivitySummary
					.setGroupName((String) claimsActivitySummaryData[2]);
			claimsActivitySummary
					.setGroupBillingId((String) claimsActivitySummaryData[3]);
			claimsActivitySummary
					.setClaimsCycle((String) claimsActivitySummaryData[4]);
			claimsActivitySummary
					.setBillDueDate((String) claimsActivitySummaryData[5]);
			claimsActivitySummary
					.setInvoiceNo((String) claimsActivitySummaryData[6]);
			claimsActivitySummary
					.setBillingCategory((String) claimsActivitySummaryData[7]);
			claimsActivitySummary
					.setMedical((String) claimsActivitySummaryData[8]);
			claimsActivitySummary
					.setCostContainment((String) claimsActivitySummaryData[9]);
			claimsActivitySummary
					.setInterest((String) claimsActivitySummaryData[10]);
			claimsActivitySummary
					.setDental((String) claimsActivitySummaryData[11]);
			claimsActivitySummary
					.setPharmacy((String) claimsActivitySummaryData[12]);
			claimsActivitySummary
					.setBlueCardAccessFees((String) claimsActivitySummaryData[13]);
			claimsActivitySummary
					.setStopLossAdvancedFunding((String) claimsActivitySummaryData[14]);
			claimsActivitySummary
					.setHealthReimbursementAccount((String) claimsActivitySummaryData[15]);
			claimsActivitySummary
					.setSubTotalClaimsActivity((String) claimsActivitySummaryData[16]);
			claimsActivitySummary
					.setTotal((String) claimsActivitySummaryData[17]);
			if(!claimsActivitySummary.getSubTotalClaimsActivity().trim().equalsIgnoreCase("$0")){
//				System.out.println("DataBase Row: "+claimsActivitySummary);
				claimsActivityList.add(claimsActivitySummary);
			}
		}
			claimsActivitySummaryDBMap.put(invoiceId, claimsActivityList);
		}
		return claimsActivitySummaryDBMap;
	}

	public Map<String,List<MemberDetails>> getMemberDetails() {
		memberDetailsDBMap = new HashMap<String, List<MemberDetails>>();
		QueriesUtil util = new QueriesUtil();
		
		SQLQuery outerQuery = (SQLQuery) session
				.createSQLQuery(util.queriesMap().get("MemberDetailsUpdatedQuery"));//.setParameterList("invoiceId", invoiceList.toArray());
		List<Object[]> outerResultList = new ArrayList<Object[]>();
		outerResultList = outerQuery.list();
		for (Object[] memberDetailsData : outerResultList) {
			memberDetailsInputSet.add(String.valueOf(memberDetailsData[4]).trim());
		}
		for (String invoiceId : memberDetailsInputSet) {
			List<String> invoiceList = new ArrayList<String>();
			invoiceList.add(invoiceId);
		SQLQuery query = (SQLQuery) session
				.createSQLQuery(util.queriesMap().get("MemberDetailsQuery")).setParameterList("invoiceId", invoiceList.toArray());
		List<Object[]> resultList = new ArrayList<Object[]>();
		resultList = query.list();
		List<MemberDetails> memberDetailsList = new ArrayList<MemberDetails>();
		for (Object[] memberDetailsData : resultList) {
			MemberDetails memberDetails = new MemberDetails();
			memberDetails.setGroupName(String.valueOf(memberDetailsData[0]).trim());
			memberDetails.setGroupBillingId(String.valueOf(memberDetailsData[1]).trim());
			memberDetails.setClaimsCycle(String.valueOf(memberDetailsData[2]).trim());
			memberDetails.setBillDueDate(String.valueOf(memberDetailsData[3]).trim());
			memberDetails.setInvoiceNo(String.valueOf(memberDetailsData[4]).trim());
			memberDetails.setGroupIdName(String.valueOf(memberDetailsData[5]).trim());
			memberDetails.setBillingCategory(String.valueOf(memberDetailsData[6]).trim());
			memberDetails.setPlanId(String.valueOf(memberDetailsData[7]).trim());
			memberDetails.setClassId(String.valueOf(memberDetailsData[8]).trim());
			memberDetails.setSubscriberId(String.valueOf(memberDetailsData[9]).trim());
			memberDetails.setSsn(String.valueOf(memberDetailsData[10]).trim());
			memberDetails.setSubscriberName(String.valueOf(memberDetailsData[11]).trim());
			memberDetails.setPatientName(String.valueOf(memberDetailsData[12]).trim());
			memberDetails.setRelationship(String.valueOf(memberDetailsData[13]).trim());
			memberDetails.setDept(String.valueOf(memberDetailsData[14]).trim());
			memberDetails.setClaimId(String.valueOf(memberDetailsData[15]).trim());
			memberDetails.setCheckNumber((BigDecimal)memberDetailsData[16]);
			memberDetails.setPaidDate(String.valueOf(memberDetailsData[17]).trim());
			memberDetails.setFromDate(String.valueOf(memberDetailsData[18]).trim());
			memberDetails.setToDate(String.valueOf(memberDetailsData[19]).trim());
			memberDetails.setPayeeName(String.valueOf(memberDetailsData[20]).trim());
			memberDetails.setPayeeId(String.valueOf(memberDetailsData[21]).trim());
			memberDetails.setCoverage(String.valueOf(memberDetailsData[22]).trim());
			memberDetails.setDeductible(String.valueOf(memberDetailsData[23]).trim());
			memberDetails.setCoinsurance(String.valueOf(memberDetailsData[24]).trim());
			memberDetails.setCopay(String.valueOf(memberDetailsData[25]).trim());
			memberDetails.setMedical(String.valueOf(memberDetailsData[26]).trim());
			memberDetails.setCostContainment(String.valueOf(memberDetailsData[27]).trim());
			memberDetails.setInterest(String.valueOf(memberDetailsData[28]).trim());
			memberDetails.setDental(String.valueOf(memberDetailsData[29]).trim());
			memberDetails.setPharmacy(String.valueOf(memberDetailsData[30]).trim());
			memberDetails.setBluecard(String.valueOf(memberDetailsData[31]).trim());
			memberDetails.setStoploss(String.valueOf(memberDetailsData[32]).trim());
			memberDetails.setHra(String.valueOf(memberDetailsData[33]).trim());
			memberDetails.setTotalPaid(String.valueOf(memberDetailsData[34]).trim());
			memberDetailsList.add(memberDetails);
//			System.out.println("DataBase Row: "+memberDetails);
		}
		memberDetailsDBMap.put(invoiceId, memberDetailsList);
		}
		return memberDetailsDBMap;
	}

	public Map<String,List<ShieldSaving>> getShieldSaving() {
		shieldSavingDBMap = new HashMap<String, List<ShieldSaving>>();
		List<ShieldSaving> shieldSavingsList = new ArrayList<ShieldSaving>();
		QueriesUtil util = new QueriesUtil();
		
		SQLQuery outerQuery = session
				.createSQLQuery(util.queriesMap().get("ShieldSavingsUpdatedQuery"));//.setParameterList("invoiceId", invoiceList.toArray());
		List<Object[]> outerResultList = new ArrayList<Object[]>();
		
		outerResultList = outerQuery.list();
		for (Object[] shieldSavingData : outerResultList) {
			shieldSavingsInputSet.add((String)shieldSavingData[5]);
		}
		for (String invoiceId : shieldSavingsInputSet) {
			List<String> invoiceList = new ArrayList<String>();
			invoiceList.add(invoiceId);
		SQLQuery query = (SQLQuery) session
				.createSQLQuery(util.queriesMap().get("ShieldSavingsQuery")).setParameterList("invoiceId", invoiceList.toArray());
		List<Object[]> resultList = new ArrayList<Object[]>();
		resultList = query.list();
		for (Object[] shieldSavingData : resultList) {
			ShieldSaving shieldSaving = new ShieldSaving();
			shieldSaving.setClaimPaymentPeriod((String) shieldSavingData[0]);
			shieldSaving.setGroupName((String) shieldSavingData[1]);
			shieldSaving.setGroupBillingId((String) shieldSavingData[2]);
			shieldSaving.setClaimsCycle((String) shieldSavingData[3]);
			shieldSaving.setBillDueDate((String) shieldSavingData[4]);
			shieldSaving.setInvoiceNo((String) shieldSavingData[5]);
			shieldSaving.setBillingCategory((String) shieldSavingData[6]);
			shieldSaving.setProviderChargedAmount((String) shieldSavingData[7]);
			shieldSaving.setSavings((String) shieldSavingData[8]);
			shieldSaving.setDisallowed((String) shieldSavingData[9]);
			shieldSaving.setAllowedAmount((String) shieldSavingData[10]);
			shieldSaving.setCostContainment((String) shieldSavingData[11]);
			shieldSaving.setTotal((String) shieldSavingData[12]);
			
			if(!shieldSaving.getTotal().equalsIgnoreCase("$0")){
				shieldSavingsList.add(shieldSaving);
//				System.out.println("DataBase Row: "+shieldSaving);
			}
			
		}
		
		shieldSavingDBMap.put(invoiceId,shieldSavingsList);
		}
		
		return shieldSavingDBMap;
	}

	public Map<String, List<PlanDetails>> getPlanDetails() {
		planDetailsDBMap = new HashMap<String, List<PlanDetails>>();
		QueriesUtil util = new QueriesUtil();
		 
		SQLQuery outerQuery = session
				.createSQLQuery(util.queriesMap().get("PlanDetailsUpdatedQuery"));//.setParameterList("invoiceId", invoiceList.toArray());
		List<Object[]> outerResultList = new ArrayList<Object[]>();
		outerResultList = outerQuery.list();
		for (Object[] planDetailsData : outerResultList) {
			planDetailsInputSet.add((String) planDetailsData[4]);
		}
		
		for (String invoiceId : planDetailsInputSet) {
			List<String> invoiceList = new ArrayList<String>();
			invoiceList.add(invoiceId);
			List<PlanDetails> planDetailsDBList = new ArrayList<PlanDetails>(); 
		SQLQuery query = (SQLQuery) session
				.createSQLQuery(util.queriesMap().get("PlanDetailsQuery")).setParameterList("invoiceId", invoiceList.toArray());
		List<Object[]> resultList = new ArrayList<Object[]>();
		resultList = query.list();

		for (Object[] planDetailsData : resultList) {
			PlanDetails planDetails = new PlanDetails();
			planDetails.setGroupName((String) planDetailsData[0]);
			planDetails.setAfaId((String) planDetailsData[1]);
			planDetails.setClaimsCycle((String) planDetailsData[2]);
			planDetails.setBillDueDate((String) planDetailsData[3]);
			planDetails.setInvoiceNo((String) planDetailsData[4]);
				planDetails.setGroupIdName((String) planDetailsData[5]);
				planDetails.setPln((String) planDetailsData[6]);
				planDetails.setCbc((String) planDetailsData[7]);
				planDetails.setGrpId((String) planDetailsData[8]);
				planDetails.setCoverage((String) planDetailsData[9]);
				planDetails.setPlanDetailsTotals((String) planDetailsData[10]);
				planDetails.setMedical((String) planDetailsData[11]);
				planDetails.setCostContainment((String) planDetailsData[12]);
				planDetails.setInterest((String) planDetailsData[13]);
				planDetails.setDental((String) planDetailsData[14]);
				planDetails.setPharmacy((String) planDetailsData[15]);
				planDetails.setStoploss((String) planDetailsData[16]);
				planDetails.setBluecard((String) planDetailsData[17]);
				planDetails.setHra((String) planDetailsData[18]);
				planDetails.setTotalPaid((String) planDetailsData[19]);
				planDetails.setSortOrder1((BigDecimal) planDetailsData[20]);
				planDetails.setSortOrder2((BigDecimal) planDetailsData[21]);
				planDetailsDBList.add(planDetails);
//				System.out.println("DataBase Row: "+planDetails);
			}
		planDetailsDBMap.put(invoiceId, planDetailsDBList);
		}
		return planDetailsDBMap;
	}
}
