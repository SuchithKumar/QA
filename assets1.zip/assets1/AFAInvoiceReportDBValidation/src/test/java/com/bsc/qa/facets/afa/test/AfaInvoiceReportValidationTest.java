package com.bsc.qa.facets.afa.test;

import java.io.File;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.assertj.core.api.SoftAssertions;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.bqsa.AutomationStringUtilities;
import com.bsc.qa.facets.afa.dao.DatabaseUtil;
import com.bsc.qa.facets.afa.excel_reader.AfaInvoiceReportReader;
import com.bsc.qa.facets.afa.pojo.ClaimsActivitySummary;
import com.bsc.qa.facets.afa.pojo.FrontPage;
import com.bsc.qa.facets.afa.pojo.MemberDetails;
import com.bsc.qa.facets.afa.pojo.PlanDetails;
import com.bsc.qa.facets.afa.pojo.ShieldSaving;
import com.bsc.qa.facets.afa.utility.Connection;
import com.bsc.qa.facets.afa.utility.HibernateUtil;
import com.bsc.qa.framework.base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

public class AfaInvoiceReportValidationTest extends BaseTest implements
		IHookable {

	Connection conn = new Connection();
	AutomationStringUtilities decoder = new AutomationStringUtilities();
	SessionFactory factory;
	Map<String, FrontPage> frontPageDBMap;
	Map<String, FrontPage> frontPageExcelMap;
	Map<String, List<ShieldSaving>> shieldSavingDBMap;
	Map<String, List<ShieldSaving>> shieldSavingExcelMap;
	Map<String, List<ClaimsActivitySummary>> claimsActivitySummaryDBMap;
	Map<String, List<ClaimsActivitySummary>> claimsActivitySummaryExcelMap;
	Map<String, List<MemberDetails>> memberDetailsDBMap;
	Map<String, List<MemberDetails>> memberDetailsExcelMap;
	Map<String, List<PlanDetails>> planDetailsDBMap;
	Map<String, List<PlanDetails>> planDetailsExcelMap;

	public String afaInvoiceReportFile;
	public String inputExcelFile;

	String afaInvoiceReportPath = System.getenv("INPUT_EDI_PATH") + "/";
	String oracleServer = System.getenv("FACETS_SERVER");
	String oraclePort = System.getenv("FACETS_PORT");
	String oracleDB = System.getenv("FACETS_DB");
	String oracleUser = System.getenv("FACETS_USER");
	String oraclePassword = System.getenv("FACETS_PASSWORD");

	String oracleUrl = "jdbc:oracle:thin:@" + oracleServer + ":" + oraclePort
			+ ":" + oracleDB;
	Set<String> inputSet;
	public static Session session;
	Logger logger1 = LoggerFactory
			.getLogger(AfaInvoiceReportValidationTest.class);

	@BeforeSuite
	public void getConnection() {
		// afaInvoiceReportPath =
		// "\\\\ainf423s\\QES_Automation\\opstest\\PDR\\INTERMEDIATE\\INVOICE\\";
		// \\\\ainf423s\\QES_Automation\\opstest\\PDR\\INPUT\\ SQA-1352
		conn.setUsername(oracleUser);
		conn.setPassword(oraclePassword);
		conn.setUrl(oracleUrl);
		factory = HibernateUtil.createSessionFactory(conn);
		session = factory.openSession();
		Transaction txn = session.beginTransaction();
		boolean success = session.isConnected();
		txn.commit();
		if (success == true)
			logger1.info("Succesfully connected to DB!!");

		try {
			afaInvoiceReportFile = afaInvoiceReportPath
					+ getMatchingAndLatestFile(afaInvoiceReportPath,
							"BRD543709-AFA Claims Billing Invoice repo*.xlsx")
							.getName();

		} catch (Exception e) {
			e.printStackTrace();
			if (e.getMessage().contains("No files matching")) {
				logger1.error(e.getMessage());
			}
			logger1.error("Unable to find the Latest AFA Invoice Report File from the given env variable afaInvoiceReportPath"
					+ afaInvoiceReportPath);
			logger1.info("Ending test execution...");
			if (session != null) {
				logger1.info("Closing DB Connection...");
				session.close();
				logger1.info("Succesfully closed DB connection!");
			}
			logger1.info("Test execution ended!");			
			//TODO: System.exit(-1) is ok if you must have it. Preferably do not do any system.exit
			System.exit(-1);
		}
	}

	@BeforeTest
	public void beforeTest() throws Exception {
		DatabaseUtil util = new DatabaseUtil();

		AfaInvoiceReportReader reader = new AfaInvoiceReportReader();

		try {
			frontPageDBMap = util.getFrontPageData();
			logger1.info("Fetched Front Page Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Front Page");
			e.printStackTrace();
		}
		try {
			frontPageExcelMap = reader.getFrontPageData();
			logger1.info("Fetched Front Page Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Front Page");
			e.printStackTrace();
		}

		try {
			shieldSavingDBMap = util.getShieldSaving();
			logger1.info("Fetched Shield saving Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Shield Savings Page");
			e.printStackTrace();
		}
		try {
			shieldSavingExcelMap = reader
					.getShieldSavingData(shieldSavingDBMap);
			logger1.info("Fetched Shield saving Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Shield Savings Page");
			e.printStackTrace();
		}

		try {
			claimsActivitySummaryDBMap = util.getClaimsActivitySummary();
			logger1.info("Fetched Claims Activity Summary Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Claims Activity Summary Page");
			e.printStackTrace();
		}
		try {
			claimsActivitySummaryExcelMap = reader
					.getClaimsActivitySummaryData(claimsActivitySummaryDBMap);
			logger1.info("Fetched Claims Activity Summary Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Claims Activity Summary Page");
			e.printStackTrace();
		}

		try {
			memberDetailsDBMap = util.getMemberDetails();
			logger1.info("Fetched Member details Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Member Details Page");
			e.printStackTrace();
		}
		try {
			memberDetailsExcelMap = reader
					.getMemberDetailsData(memberDetailsDBMap);
			logger1.info("Fetched Member details Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Member Details Page");
			e.printStackTrace();
		}

		try {
			planDetailsDBMap = util.getPlanDetails();
			logger1.info("Fetched Plan Details Data from DB");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching DB data for Plan Details Page");
			e.printStackTrace();
		}
		try {
			planDetailsExcelMap = reader.getPlanDetailsData(planDetailsDBMap);
			logger1.info("Fetched Plan Details Data from Excel");
		} catch (Exception e) {
			logger1.error("Something wrong while fetching Excel data for Plan Details Page");
			e.printStackTrace();
		}

	}

	//TODO: Eneter javadoc for all test methods and helper methods
	/**
	 * Tidal job creates a report in an excel sheet. The test method converts that to a map and uses it as a 'actual'. Expceted is from the DB.
	 * 
	 * @param invoiceNo Invoice number as string
	 * @param frontPageExcelTable Map of data from the frontPageExcel worksheet
	 * @param frontPageDBTable Map of data from the DB 
	 */
	@Test(dataProvider = "provideFrontPageData")
	public void testFrontPageData(String invoiceNo,
			Hashtable<String, FrontPage> frontPageExcelTable,
			Hashtable<String, FrontPage> frontPageDBTable) {
		// TODO: remove all occurances of reportInit from test methods. There
		// should be no reportInit anywhere except the run method.
		reportInit("Test front page data || Invoice No => ", invoiceNo);
		// TODO: Delete all instantiations of softAssert. Use softAssertions
		// provided by framework
		SoftAssert softassert = new SoftAssert();

		softAssertions
				.assertThat(frontPageExcelTable.get(invoiceNo).getGroupName())
				.as("GroupName || Expected( DB Value) ==> "
						+ frontPageDBTable.get(invoiceNo).getGroupName()
						+ " ||  Actual(Invoice Report) ==> "
						+ frontPageExcelTable.get(invoiceNo).getGroupName())
				.isEqualTo(frontPageDBTable.get(invoiceNo).getGroupName());

		if (frontPageExcelTable
				.get(invoiceNo)
				.getGroupName()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getGroupName())) {
			
			//TODO: Remove all occuranes of LogStatus.PASS and FAIL. Enter the message in the as section of softAssertions.
			logger.log(LogStatus.PASS, "GroupName || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getGroupName()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getGroupName());
		} else {
			logger.log(LogStatus.FAIL, "GroupName || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getGroupName()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getGroupName());
		}

		softassert.assertEquals(frontPageExcelTable.get(invoiceNo)
				.getGroupAddress(), frontPageDBTable.get(invoiceNo)
				.getGroupAddress());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getGroupAddress()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getGroupAddress())) {
			logger.log(LogStatus.PASS,
					"GroupAddress || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo).getGroupAddress()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getGroupAddress());
		} else {
			logger.log(LogStatus.FAIL,
					"GroupAddress || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo).getGroupName()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getGroupAddress());
		}

		softassert
				.assertEquals(
						frontPageExcelTable.get(invoiceNo).getAttention(),
						frontPageDBTable.get(invoiceNo).getAttention());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getAttention()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getAttention())) {
			logger.log(LogStatus.PASS, "Attention || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getAttention()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getAttention());
		} else {
			logger.log(LogStatus.FAIL, "Attention || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getAttention()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getAttention());
		}

		softassert.assertEquals(frontPageExcelTable.get(invoiceNo)
				.getGroupBillingId(), frontPageDBTable.get(invoiceNo)
				.getGroupBillingId());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getGroupBillingId()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getGroupBillingId())) {
			logger.log(LogStatus.PASS,
					"GroupBillingId || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getGroupBillingId()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getGroupBillingId());
		} else {
			logger.log(LogStatus.FAIL,
					"GroupBillingId || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getGroupBillingId()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getGroupBillingId());
		}

		softassert.assertEquals(frontPageExcelTable.get(invoiceNo)
				.getFundingPeriod(), frontPageDBTable.get(invoiceNo)
				.getFundingPeriod());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getFundingPeriod()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getFundingPeriod())) {
			logger.log(LogStatus.PASS,
					"FundingPeriod || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getFundingPeriod()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getFundingPeriod());
		} else {
			logger.log(LogStatus.FAIL,
					"FundingPeriod || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getFundingPeriod()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getFundingPeriod());
		}

		softassert.assertEquals(frontPageExcelTable.get(invoiceNo)
				.getBillDueDate(), frontPageDBTable.get(invoiceNo)
				.getBillDueDate());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getBillDueDate()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getBillDueDate())) {
			logger.log(LogStatus.PASS,
					"BillDueDate || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo).getBillDueDate()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getBillDueDate());
		} else {
			logger.log(LogStatus.FAIL,
					"BillDueDate || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo).getBillDueDate()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getBillDueDate());
		}
		softassert
				.assertEquals(
						frontPageExcelTable.get(invoiceNo).getInvoiceNo(),
						frontPageDBTable.get(invoiceNo).getInvoiceNo());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getInvoiceNo()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getInvoiceNo())) {
			logger.log(LogStatus.PASS, "InvoiceNo || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getInvoiceNo()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getInvoiceNo());
		} else {
			logger.log(LogStatus.FAIL, "InvoiceNo || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getInvoiceNo()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getInvoiceNo());
		}
		softassert.assertEquals(frontPageExcelTable.get(invoiceNo)
				.getInvoiceDate(), frontPageDBTable.get(invoiceNo)
				.getInvoiceDate());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getInvoiceDate()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getInvoiceDate())) {
			logger.log(LogStatus.PASS,
					"InvoiceDate || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo).getInvoiceDate()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getInvoiceDate());
		} else {
			logger.log(LogStatus.FAIL,
					"InvoiceDate || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo).getInvoiceDate()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getInvoiceDate());
		}
		softassert.assertEquals(frontPageExcelTable.get(invoiceNo)
				.getCurrentPeriodClaims(), frontPageDBTable.get(invoiceNo)
				.getCurrentPeriodClaims());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getCurrentPeriodClaims()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo)
								.getCurrentPeriodClaims())) {
			logger.log(LogStatus.PASS,
					"CurrentPeriodClaims || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getCurrentPeriodClaims()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getCurrentPeriodClaims());
		} else {
			logger.log(LogStatus.FAIL,
					"CurrentPeriodClaims || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getCurrentPeriodClaims()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getCurrentPeriodClaims());
		}
		softassert.assertEquals(frontPageExcelTable.get(invoiceNo)
				.getBalanceForward(), frontPageDBTable.get(invoiceNo)
				.getBalanceForward());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getBalanceForward()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getBalanceForward())) {
			logger.log(LogStatus.PASS,
					"BalanceForward || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getBalanceForward()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getBalanceForward());
		} else {
			logger.log(LogStatus.FAIL,
					"BalanceForward || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getBalanceForward()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getBalanceForward());
		}
		softassert.assertEquals(frontPageExcelTable.get(invoiceNo)
				.getTotalDueForClaimsReimbursement(),
				frontPageDBTable.get(invoiceNo)
						.getTotalDueForClaimsReimbursement());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getTotalDueForClaimsReimbursement()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo)
								.getTotalDueForClaimsReimbursement())) {
			logger.log(LogStatus.PASS,
					"ClaimsReimbursement || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getTotalDueForClaimsReimbursement()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getTotalDueForClaimsReimbursement());
		} else {
			logger.log(LogStatus.FAIL,
					"ClaimsReimbursement || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getTotalDueForClaimsReimbursement()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getTotalDueForClaimsReimbursement());
		}
		softassert.assertEquals(frontPageExcelTable.get(invoiceNo)
				.getBscAccountantName(), frontPageDBTable.get(invoiceNo)
				.getBscAccountantName());
		if (frontPageExcelTable
				.get(invoiceNo)
				.getBscAccountantName()
				.equalsIgnoreCase(
						frontPageDBTable.get(invoiceNo).getBscAccountantName())) {
			logger.log(LogStatus.PASS,
					"BscAccountantName || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getBscAccountantName()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getBscAccountantName());
		} else {
			logger.log(LogStatus.FAIL,
					"BscAccountantName || Expected( DB Value) ==> "
							+ frontPageDBTable.get(invoiceNo)
									.getBscAccountantName()
							+ " ||  Actual(Invoice Report) ==> "
							+ frontPageExcelTable.get(invoiceNo)
									.getBscAccountantName());
		}
		softassert.assertEquals(frontPageExcelTable.get(invoiceNo).getPhone(),
				frontPageDBTable.get(invoiceNo).getPhone());
		if (frontPageExcelTable.get(invoiceNo).getPhone()
				.equalsIgnoreCase(frontPageDBTable.get(invoiceNo).getPhone())) {
			logger.log(LogStatus.PASS, "Phone || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getPhone()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getPhone());
		} else {
			logger.log(LogStatus.FAIL, "Phone || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getPhone()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getPhone());
		}
		softassert.assertEquals(frontPageExcelTable.get(invoiceNo).getFax(),
				frontPageDBTable.get(invoiceNo).getFax());
		if (frontPageExcelTable.get(invoiceNo).getFax()
				.equalsIgnoreCase(frontPageDBTable.get(invoiceNo).getFax())) {
			logger.log(LogStatus.PASS, "Fax || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getFax()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getFax());
		} else {
			logger.log(LogStatus.FAIL, "Fax || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getFax()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getFax());
		}
		softassert.assertEquals(frontPageExcelTable.get(invoiceNo).getEmail(),
				frontPageDBTable.get(invoiceNo).getEmail());
		if (frontPageExcelTable.get(invoiceNo).getEmail()
				.equalsIgnoreCase(frontPageDBTable.get(invoiceNo).getEmail())) {
			logger.log(LogStatus.PASS, "Email || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getEmail()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getEmail());
		} else {
			logger.log(LogStatus.FAIL, "Email || Expected( DB Value) ==> "
					+ frontPageDBTable.get(invoiceNo).getEmail()
					+ " ||  Actual(Invoice Report) ==> "
					+ frontPageExcelTable.get(invoiceNo).getEmail());
		}
		softassert.assertAll();

	}

	@Test(dataProvider = "provideClaimsActivitySummaryData")
	public void testClaimsActivitySummaryData(
			String invoiceNo,
			Hashtable<String, List<ClaimsActivitySummary>> ClaimsActivitySummaryExcelTable,
			Hashtable<String, List<ClaimsActivitySummary>> ClaimsActivitySummaryDBTable) {
		List<ClaimsActivitySummary> claimsActivitySummaryExcelList = claimsActivitySummaryExcelMap
				.get(invoiceNo);
		List<ClaimsActivitySummary> claimsActivitySummaryDBList = claimsActivitySummaryDBMap
				.get(invoiceNo);
		reportInit("Test Claims Activity Summary Data || Invoice No => ",
				invoiceNo);
		SoftAssert softAssert = new SoftAssert();
		for (ClaimsActivitySummary excelClaim : claimsActivitySummaryExcelList) {

			for (int i = 0; i < claimsActivitySummaryDBList.size(); i++) {
				ClaimsActivitySummary dbClaim = claimsActivitySummaryDBList
						.get(i);
				if (excelClaim.getBillingCategory().equalsIgnoreCase(
						dbClaim.getBillingCategory())) {
					logger.log(LogStatus.INFO, "Validating Billing Category : "
							+ dbClaim.getBillingCategory());
					softAssert.assertEquals(excelClaim.getClaimPaymentPeriod(),
							dbClaim.getClaimPaymentPeriod(),
							"claimPaymentPeriod Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getClaimPaymentPeriod().equalsIgnoreCase(
							dbClaim.getClaimPaymentPeriod())) {
						logger.log(LogStatus.PASS,
								"ClaimPaymentPeriod || Expected( DB Value) ==> "
										+ dbClaim.getClaimPaymentPeriod()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getClaimPaymentPeriod());
					} else {
						logger.log(LogStatus.FAIL,
								"ClaimPaymentPeriod || Expected( DB Value) ==> "
										+ dbClaim.getClaimPaymentPeriod()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getClaimPaymentPeriod());
					}
					softAssert.assertEquals(
							excelClaim.getInvoiceDate(),
							dbClaim.getInvoiceDate(),
							"invoiceDate Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getInvoiceDate().equalsIgnoreCase(
							dbClaim.getInvoiceDate())) {
						logger.log(LogStatus.PASS,
								"InvoiceDate || Expected( DB Value) ==> "
										+ dbClaim.getInvoiceDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getInvoiceDate());
					} else {
						logger.log(LogStatus.FAIL,
								"InvoiceDate || Expected( DB Value) ==> "
										+ dbClaim.getInvoiceDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getInvoiceDate());
					}
					softAssert.assertEquals(
							excelClaim.getGroupName(),
							dbClaim.getGroupName(),
							"groupName Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getGroupName().equalsIgnoreCase(
							dbClaim.getGroupName())) {
						logger.log(LogStatus.PASS,
								"GroupName || Expected( DB Value) ==> "
										+ dbClaim.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getGroupName());
					} else {
						logger.log(LogStatus.FAIL,
								"GroupName || Expected( DB Value) ==> "
										+ dbClaim.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getGroupName());
					}
					softAssert.assertEquals(excelClaim.getGroupBillingId(),
							dbClaim.getGroupBillingId(),
							"groupBillingId Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getGroupBillingId().equalsIgnoreCase(
							dbClaim.getGroupBillingId())) {
						logger.log(LogStatus.PASS,
								"GroupBillingId || Expected( DB Value) ==> "
										+ dbClaim.getGroupBillingId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getGroupBillingId());
					} else {
						logger.log(LogStatus.FAIL,
								"GroupBillingId || Expected( DB Value) ==> "
										+ dbClaim.getGroupBillingId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getGroupBillingId());
					}
					softAssert.assertEquals(
							excelClaim.getClaimsCycle(),
							dbClaim.getClaimsCycle(),
							"claimsCycle Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getClaimsCycle().equalsIgnoreCase(
							dbClaim.getClaimsCycle())) {
						logger.log(LogStatus.PASS,
								"ClaimsCycle || Expected( DB Value) ==> "
										+ dbClaim.getClaimsCycle()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getClaimsCycle());
					} else {
						logger.log(LogStatus.FAIL,
								"ClaimsCycle || Expected( DB Value) ==> "
										+ dbClaim.getClaimsCycle()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getClaimsCycle());
					}
					softAssert.assertEquals(
							excelClaim.getBillDueDate(),
							dbClaim.getBillDueDate(),
							"billDueDate Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getBillDueDate().equalsIgnoreCase(
							dbClaim.getBillDueDate())) {
						logger.log(LogStatus.PASS,
								"BillDueDate || Expected( DB Value) ==> "
										+ dbClaim.getBillDueDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getBillDueDate());
					} else {
						logger.log(LogStatus.FAIL,
								"BillDueDate || Expected( DB Value) ==> "
										+ dbClaim.getBillDueDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getBillDueDate());
					}
					softAssert.assertEquals(
							excelClaim.getInvoiceNo(),
							dbClaim.getInvoiceNo(),
							"invoiceNo Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getInvoiceNo().equalsIgnoreCase(
							dbClaim.getInvoiceNo())) {
						logger.log(LogStatus.PASS,
								"InvoiceNo || Expected( DB Value) ==> "
										+ dbClaim.getInvoiceNo()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getInvoiceNo());
					} else {
						logger.log(LogStatus.FAIL,
								"InvoiceNo || Expected( DB Value) ==> "
										+ dbClaim.getInvoiceNo()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getInvoiceNo());
					}
					softAssert.assertEquals(excelClaim.getBillingCategory(),
							dbClaim.getBillingCategory(),
							"billingCategory Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getBillingCategory().equalsIgnoreCase(
							dbClaim.getBillingCategory())) {
						logger.log(LogStatus.PASS,
								"BillingCategory || Expected( DB Value) ==> "
										+ dbClaim.getBillingCategory()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getBillingCategory());
					} else {
						logger.log(LogStatus.FAIL,
								"BillingCategory || Expected( DB Value) ==> "
										+ dbClaim.getBillingCategory()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getBillingCategory());
					}
					softAssert.assertEquals(
							excelClaim.getMedical(),
							dbClaim.getMedical(),
							"medical Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getMedical().equalsIgnoreCase(
							dbClaim.getMedical())) {
						logger.log(
								LogStatus.PASS,
								"Medical || Expected( DB Value) ==> "
										+ dbClaim.getMedical()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getMedical());
					} else {
						logger.log(
								LogStatus.FAIL,
								"Medical || Expected( DB Value) ==> "
										+ dbClaim.getMedical()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getMedical());
					}
					softAssert.assertEquals(excelClaim.getCostContainment(),
							dbClaim.getCostContainment(),
							"costContainment Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getCostContainment().equalsIgnoreCase(
							dbClaim.getCostContainment())) {
						logger.log(LogStatus.PASS,
								"CostContainment || Expected( DB Value) ==> "
										+ dbClaim.getCostContainment()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getCostContainment());
					} else {
						logger.log(LogStatus.FAIL,
								"CostContainment || Expected( DB Value) ==> "
										+ dbClaim.getCostContainment()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getCostContainment());
					}
					softAssert.assertEquals(
							excelClaim.getInterest(),
							dbClaim.getInterest(),
							"interest Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getInterest().equalsIgnoreCase(
							dbClaim.getInterest())) {
						logger.log(LogStatus.PASS,
								"Interest || Expected( DB Value) ==> "
										+ dbClaim.getInterest()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getInterest());
					} else {
						logger.log(LogStatus.FAIL,
								"Interest || Expected( DB Value) ==> "
										+ dbClaim.getInterest()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getInterest());
					}
					softAssert.assertEquals(
							excelClaim.getDental(),
							dbClaim.getDental(),
							"dental Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getDental().equalsIgnoreCase(
							dbClaim.getDental())) {
						logger.log(
								LogStatus.PASS,
								"Dental || Expected( DB Value) ==> "
										+ dbClaim.getDental()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getDental());
					} else {
						logger.log(
								LogStatus.FAIL,
								"Dental || Expected( DB Value) ==> "
										+ dbClaim.getDental()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getDental());
					}
					softAssert.assertEquals(
							excelClaim.getPharmacy(),
							dbClaim.getPharmacy(),
							"pharmacy Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getPharmacy().equalsIgnoreCase(
							dbClaim.getPharmacy())) {
						logger.log(LogStatus.PASS,
								"Pharmacy || Expected( DB Value) ==> "
										+ dbClaim.getPharmacy()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getPharmacy());
					} else {
						logger.log(LogStatus.FAIL,
								"Pharmacy || Expected( DB Value) ==> "
										+ dbClaim.getPharmacy()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getPharmacy());
					}
					softAssert.assertEquals(excelClaim.getBlueCardAccessFees(),
							dbClaim.getBlueCardAccessFees(),
							"blueCardAccessFees Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getBlueCardAccessFees().equalsIgnoreCase(
							dbClaim.getBlueCardAccessFees())) {
						logger.log(LogStatus.PASS,
								"BlueCardAccessFees || Expected( DB Value) ==> "
										+ dbClaim.getBlueCardAccessFees()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getBlueCardAccessFees());
					} else {
						logger.log(LogStatus.FAIL,
								"BlueCardAccessFees || Expected( DB Value) ==> "
										+ dbClaim.getBlueCardAccessFees()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getBlueCardAccessFees());
					}
					softAssert.assertEquals(
							excelClaim.getStopLossAdvancedFunding(),
							dbClaim.getStopLossAdvancedFunding(),
							"stopLossAdvancedFunding Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getStopLossAdvancedFunding()
							.equalsIgnoreCase(
									dbClaim.getStopLossAdvancedFunding())) {
						logger.log(
								LogStatus.PASS,
								"StopLossAdvancedFunding || Expected( DB Value) ==> "
										+ dbClaim.getStopLossAdvancedFunding()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim
												.getStopLossAdvancedFunding());
					} else {
						logger.log(
								LogStatus.FAIL,
								"StopLossAdvancedFunding || Expected( DB Value) ==> "
										+ dbClaim.getStopLossAdvancedFunding()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim
												.getStopLossAdvancedFunding());
					}
					softAssert.assertEquals(
							excelClaim.getHealthReimbursementAccount(),
							dbClaim.getHealthReimbursementAccount(),
							"healthReimbursementAccount Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getHealthReimbursementAccount()
							.equalsIgnoreCase(
									dbClaim.getHealthReimbursementAccount())) {
						logger.log(
								LogStatus.PASS,
								"HealthReimbursementAccount || Expected( DB Value) ==> "
										+ dbClaim
												.getHealthReimbursementAccount()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim
												.getHealthReimbursementAccount());
					} else {
						logger.log(
								LogStatus.FAIL,
								"HealthReimbursementAccount || Expected( DB Value) ==> "
										+ dbClaim
												.getHealthReimbursementAccount()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim
												.getHealthReimbursementAccount());
					}
					softAssert.assertEquals(
							excelClaim.getSubTotalClaimsActivity(),
							dbClaim.getSubTotalClaimsActivity(),
							"subTotalClaimsActivity Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getSubTotalClaimsActivity()
							.equalsIgnoreCase(
									dbClaim.getSubTotalClaimsActivity())) {
						logger.log(
								LogStatus.PASS,
								"SubTotalClaimsActivity || Expected( DB Value) ==> "
										+ dbClaim.getSubTotalClaimsActivity()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim
												.getSubTotalClaimsActivity());
					} else {
						logger.log(
								LogStatus.FAIL,
								"SubTotalClaimsActivity || Expected( DB Value) ==> "
										+ dbClaim.getSubTotalClaimsActivity()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim
												.getSubTotalClaimsActivity());
					}
					softAssert.assertEquals(
							excelClaim.getTotal(),
							dbClaim.getTotal(),
							"total Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbClaim.getBillingCategory());
					if (excelClaim.getTotal().equalsIgnoreCase(
							dbClaim.getTotal())) {
						logger.log(
								LogStatus.PASS,
								"Total || Expected( DB Value) ==> "
										+ dbClaim.getTotal()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getTotal());
					} else {
						logger.log(
								LogStatus.FAIL,
								"Total || Expected( DB Value) ==> "
										+ dbClaim.getTotal()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelClaim.getTotal());
					}

				}
			}

		}
		softAssert.assertAll();
	}

	@Test(dataProvider = "provideShieldSavingData")
	public void testShieldSavingData(String invoiceNo,
			Hashtable<String, List<ShieldSaving>> shieldSavingExcelTable,
			Hashtable<String, List<ShieldSaving>> shieldSavingDBTable) {
		List<ShieldSaving> shieldSavingExcelList = shieldSavingExcelMap
				.get(invoiceNo);
		List<ShieldSaving> shieldSavingDBList = shieldSavingDBMap
				.get(invoiceNo);
		reportInit("Test Shield Saving Data || Invoice No => ", invoiceNo);
		SoftAssert softAssert = new SoftAssert();
		for (ShieldSaving excelShieldSaving : shieldSavingExcelList) {
			for (int i = 0; i < shieldSavingDBList.size(); i++) {
				ShieldSaving dbShieldSaving = shieldSavingDBList.get(i);
				if (excelShieldSaving.getBillingCategory().equalsIgnoreCase(
						dbShieldSaving.getBillingCategory())) {
					logger.log(
							LogStatus.INFO,
							"Testing for Billing Category - "
									+ dbShieldSaving.getBillingCategory());

					softAssert.assertEquals(
							excelShieldSaving.getClaimPaymentPeriod(),
							dbShieldSaving.getClaimPaymentPeriod(),
							"ClaimPaymentPeriod Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getClaimPaymentPeriod()
							.equalsIgnoreCase(
									dbShieldSaving.getClaimPaymentPeriod())) {
						logger.log(
								LogStatus.PASS,
								"ClaimPaymentPeriod || Expected( DB Value) ==> "
										+ dbShieldSaving
												.getClaimPaymentPeriod()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving
												.getClaimPaymentPeriod());
					} else {
						logger.log(
								LogStatus.FAIL,
								"ClaimPaymentPeriod || Expected( DB Value) ==> "
										+ dbShieldSaving
												.getClaimPaymentPeriod()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving
												.getClaimPaymentPeriod());
					}

					softAssert.assertEquals(
							excelShieldSaving.getGroupName(),
							dbShieldSaving.getGroupName(),
							"GroupName Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getGroupName().equalsIgnoreCase(
							dbShieldSaving.getGroupName())) {
						logger.log(LogStatus.PASS,
								"GroupName || Expected( DB Value) ==> "
										+ dbShieldSaving.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getGroupName());
					} else {
						logger.log(LogStatus.FAIL,
								"GroupName || Expected( DB Value) ==> "
										+ dbShieldSaving.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getGroupName());
					}

					softAssert.assertEquals(
							excelShieldSaving.getGroupBillingId(),
							dbShieldSaving.getGroupBillingId(),
							"GroupBillingId Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getGroupBillingId().equalsIgnoreCase(
							dbShieldSaving.getGroupBillingId())) {
						logger.log(LogStatus.PASS,
								"GroupBillingId || Expected( DB Value) ==> "
										+ dbShieldSaving.getGroupBillingId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getGroupBillingId());
					} else {
						logger.log(LogStatus.FAIL,
								"GroupBillingId || Expected( DB Value) ==> "
										+ dbShieldSaving.getGroupBillingId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getGroupBillingId());
					}

					softAssert.assertEquals(
							excelShieldSaving.getClaimsCycle(),
							dbShieldSaving.getClaimsCycle(),
							"ClaimsCycle Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getClaimsCycle().equalsIgnoreCase(
							dbShieldSaving.getClaimsCycle())) {
						logger.log(LogStatus.PASS,
								"ClaimsCycle || Expected( DB Value) ==> "
										+ dbShieldSaving.getClaimsCycle()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getClaimsCycle());
					} else {
						logger.log(LogStatus.FAIL,
								"ClaimsCycle || Expected( DB Value) ==> "
										+ dbShieldSaving.getClaimsCycle()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getClaimsCycle());
					}

					softAssert.assertEquals(
							excelShieldSaving.getBillDueDate(),
							dbShieldSaving.getBillDueDate(),
							"BillDueDate Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getBillDueDate().equalsIgnoreCase(
							dbShieldSaving.getBillDueDate())) {
						logger.log(LogStatus.PASS,
								"BillDueDate || Expected( DB Value) ==> "
										+ dbShieldSaving.getBillDueDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getBillDueDate());
					} else {
						logger.log(LogStatus.FAIL,
								"BillDueDate || Expected( DB Value) ==> "
										+ dbShieldSaving.getBillDueDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getBillDueDate());
					}

					softAssert.assertEquals(
							excelShieldSaving.getInvoiceNo(),
							dbShieldSaving.getInvoiceNo(),
							"InvoiceNo Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getInvoiceNo().equalsIgnoreCase(
							dbShieldSaving.getInvoiceNo())) {
						logger.log(LogStatus.PASS,
								"InvoiceNo || Expected( DB Value) ==> "
										+ dbShieldSaving.getInvoiceNo()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getInvoiceNo());
					} else {
						logger.log(LogStatus.FAIL,
								"InvoiceNo || Expected( DB Value) ==> "
										+ dbShieldSaving.getInvoiceNo()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getInvoiceNo());
					}

					softAssert.assertEquals(
							excelShieldSaving.getBillingCategory(),
							dbShieldSaving.getBillingCategory(),
							"BillingCategory Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getBillingCategory()
							.equalsIgnoreCase(
									dbShieldSaving.getBillingCategory())) {
						logger.log(
								LogStatus.PASS,
								"BillingCategory || Expected( DB Value) ==> "
										+ dbShieldSaving.getBillingCategory()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving
												.getBillingCategory());
					} else {
						logger.log(
								LogStatus.FAIL,
								"BillingCategory || Expected( DB Value) ==> "
										+ dbShieldSaving.getBillingCategory()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving
												.getBillingCategory());
					}

					softAssert.assertEquals(
							excelShieldSaving.getProviderChargedAmount(),
							dbShieldSaving.getProviderChargedAmount(),
							"ProviderChargedAmount Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getProviderChargedAmount()
							.equalsIgnoreCase(
									dbShieldSaving.getProviderChargedAmount())) {
						logger.log(
								LogStatus.PASS,
								"ProviderChargedAmount || Expected( DB Value) ==> "
										+ dbShieldSaving
												.getProviderChargedAmount()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving
												.getProviderChargedAmount());
					} else {
						logger.log(
								LogStatus.FAIL,
								"ProviderChargedAmount || Expected( DB Value) ==> "
										+ dbShieldSaving
												.getProviderChargedAmount()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving
												.getProviderChargedAmount());
					}

					softAssert.assertEquals(
							excelShieldSaving.getSavings(),
							dbShieldSaving.getSavings(),
							"Savings Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getSavings().equalsIgnoreCase(
							dbShieldSaving.getSavings())) {
						logger.log(LogStatus.PASS,
								"Savings || Expected( DB Value) ==> "
										+ dbShieldSaving.getSavings()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getSavings());
					} else {
						logger.log(LogStatus.FAIL,
								"Savings || Expected( DB Value) ==> "
										+ dbShieldSaving.getSavings()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getSavings());
					}

					softAssert.assertEquals(
							excelShieldSaving.getDisallowed(),
							dbShieldSaving.getDisallowed(),
							"Disallowed Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getDisallowed().equalsIgnoreCase(
							dbShieldSaving.getDisallowed())) {
						logger.log(LogStatus.PASS,
								"Disallowed || Expected( DB Value) ==> "
										+ dbShieldSaving.getDisallowed()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getDisallowed());
					} else {
						logger.log(LogStatus.FAIL,
								"Disallowed || Expected( DB Value) ==> "
										+ dbShieldSaving.getDisallowed()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getDisallowed());
					}

					softAssert.assertEquals(
							excelShieldSaving.getAllowedAmount(),
							dbShieldSaving.getAllowedAmount(),
							"AllowedAmount Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getAllowedAmount().equalsIgnoreCase(
							dbShieldSaving.getAllowedAmount())) {
						logger.log(LogStatus.PASS,
								"AllowedAmount || Expected( DB Value) ==> "
										+ dbShieldSaving.getAllowedAmount()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getAllowedAmount());
					} else {
						logger.log(LogStatus.FAIL,
								"AllowedAmount || Expected( DB Value) ==> "
										+ dbShieldSaving.getAllowedAmount()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getAllowedAmount());
					}

					softAssert.assertEquals(
							excelShieldSaving.getCostContainment(),
							dbShieldSaving.getCostContainment(),
							"CostContainment Mismatch for Invoice NO:"
									+ invoiceNo + " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getCostContainment()
							.equalsIgnoreCase(
									dbShieldSaving.getCostContainment())) {
						logger.log(
								LogStatus.PASS,
								"CostContainment || Expected( DB Value) ==> "
										+ dbShieldSaving.getCostContainment()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving
												.getCostContainment());
					} else {
						logger.log(
								LogStatus.FAIL,
								"CostContainment || Expected( DB Value) ==> "
										+ dbShieldSaving.getCostContainment()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving
												.getCostContainment());
					}

					softAssert.assertEquals(
							excelShieldSaving.getTotal(),
							dbShieldSaving.getTotal(),
							"Total Mismatch for Invoice NO:" + invoiceNo
									+ " Billing category:"
									+ dbShieldSaving.getBillingCategory());
					if (excelShieldSaving.getTotal().equalsIgnoreCase(
							dbShieldSaving.getTotal())) {
						logger.log(LogStatus.PASS,
								"Total || Expected( DB Value) ==> "
										+ dbShieldSaving.getTotal()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getTotal());
					} else {
						logger.log(LogStatus.FAIL,
								"Total || Expected( DB Value) ==> "
										+ dbShieldSaving.getTotal()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelShieldSaving.getTotal());
					}
				}
			}
		}
		softAssert.assertAll();
	}

	@Test(dataProvider = "provideMemberDetailsData")
	public void testMemberDetailsData(String invoiceNo,
			Hashtable<String, List<MemberDetails>> memberDetailsExcelTable,
			Hashtable<String, List<MemberDetails>> memberDetailsDBTable) {
		List<MemberDetails> memberDetailsExcelList = memberDetailsExcelMap
				.get(invoiceNo);
		List<MemberDetails> memberDetailsDBList = memberDetailsDBMap
				.get(invoiceNo);
		reportInit("Test Member Details Data || Invoice No => ", invoiceNo);
		SoftAssert softAssert = new SoftAssert();
		for (MemberDetails excelMemberDetails : memberDetailsExcelList) {
			for (int i = 0; i < memberDetailsDBList.size(); i++) {
				MemberDetails dbMemberDetails = memberDetailsDBList.get(i);
				if (excelMemberDetails.getClaimId().equalsIgnoreCase(
						dbMemberDetails.getClaimId())) {
					softAssert.assertEquals(excelMemberDetails.getGroupName(),
							dbMemberDetails.getGroupName(),
							"GroupName Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getGroupName().equalsIgnoreCase(
							dbMemberDetails.getGroupName())) {
						logger.log(LogStatus.PASS,
								"ClaimPaymentPeriod || Expected( DB Value) ==> "
										+ dbMemberDetails.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getGroupName());
					} else {
						logger.log(LogStatus.FAIL,
								"ClaimPaymentPeriod || Expected( DB Value) ==> "
										+ dbMemberDetails.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getGroupName());
					}

					softAssert.assertEquals(
							excelMemberDetails.getGroupBillingId(),
							dbMemberDetails.getGroupBillingId(),
							"GroupBillingId Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getGroupBillingId()
							.equalsIgnoreCase(
									dbMemberDetails.getGroupBillingId())) {
						logger.log(
								LogStatus.PASS,
								"GroupBillingId || Expected( DB Value) ==> "
										+ dbMemberDetails.getGroupBillingId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails
												.getGroupBillingId());
					} else {
						logger.log(
								LogStatus.FAIL,
								"GroupBillingId || Expected( DB Value) ==> "
										+ dbMemberDetails.getGroupBillingId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails
												.getGroupBillingId());
					}

					softAssert.assertEquals(excelMemberDetails.getGroupName(),
							dbMemberDetails.getGroupName(),
							"GroupName Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getGroupName().equalsIgnoreCase(
							dbMemberDetails.getGroupName())) {
						logger.log(LogStatus.PASS,
								"GroupName || Expected( DB Value) ==> "
										+ dbMemberDetails.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getGroupName());
					} else {
						logger.log(LogStatus.FAIL,
								"GroupName || Expected( DB Value) ==> "
										+ dbMemberDetails.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getGroupName());
					}

					softAssert.assertEquals(
							excelMemberDetails.getBillDueDate(),
							dbMemberDetails.getBillDueDate(),
							"BillDueDate Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getBillDueDate().equalsIgnoreCase(
							dbMemberDetails.getBillDueDate())) {
						logger.log(LogStatus.PASS,
								"BillDueDate || Expected( DB Value) ==> "
										+ dbMemberDetails.getBillDueDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getBillDueDate());
					} else {
						logger.log(LogStatus.FAIL,
								"BillDueDate || Expected( DB Value) ==> "
										+ dbMemberDetails.getBillDueDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getBillDueDate());
					}

					softAssert.assertEquals(excelMemberDetails.getInvoiceNo(),
							dbMemberDetails.getInvoiceNo(),
							"InvoiceNo Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getInvoiceNo().equalsIgnoreCase(
							dbMemberDetails.getInvoiceNo())) {
						logger.log(LogStatus.PASS,
								"InvoiceNo || Expected( DB Value) ==> "
										+ dbMemberDetails.getInvoiceNo()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getInvoiceNo());
					} else {
						logger.log(LogStatus.FAIL,
								"InvoiceNo || Expected( DB Value) ==> "
										+ dbMemberDetails.getInvoiceNo()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getInvoiceNo());
					}

					softAssert.assertEquals(
							excelMemberDetails.getGroupIdName(),
							dbMemberDetails.getGroupIdName(),
							"GroupIdName Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getGroupIdName().equalsIgnoreCase(
							dbMemberDetails.getGroupIdName())) {
						logger.log(LogStatus.PASS,
								"GroupIdName || Expected( DB Value) ==> "
										+ dbMemberDetails.getGroupIdName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getGroupIdName());
					} else {
						logger.log(LogStatus.FAIL,
								"GroupIdName || Expected( DB Value) ==> "
										+ dbMemberDetails.getGroupIdName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getGroupIdName());
					}

					softAssert.assertEquals(
							excelMemberDetails.getBillingCategory(),
							dbMemberDetails.getBillingCategory(),
							"BillingCategory Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getBillingCategory()
							.equalsIgnoreCase(
									dbMemberDetails.getBillingCategory())) {
						logger.log(
								LogStatus.PASS,
								"BillingCategory || Expected( DB Value) ==> "
										+ dbMemberDetails.getBillingCategory()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails
												.getBillingCategory());
					} else {
						logger.log(
								LogStatus.FAIL,
								"BillingCategory || Expected( DB Value) ==> "
										+ dbMemberDetails.getBillingCategory()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails
												.getBillingCategory());
					}

					softAssert.assertEquals(
							excelMemberDetails.getPlanId(),
							dbMemberDetails.getPlanId(),
							"PlanId Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getPlanId().equalsIgnoreCase(
							dbMemberDetails.getPlanId())) {
						logger.log(LogStatus.PASS,
								"PlanId || Expected( DB Value) ==> "
										+ dbMemberDetails.getPlanId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPlanId());
					} else {
						logger.log(LogStatus.FAIL,
								"PlanId || Expected( DB Value) ==> "
										+ dbMemberDetails.getPlanId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPlanId());
					}

					softAssert.assertEquals(
							excelMemberDetails.getClassId(),
							dbMemberDetails.getClassId(),
							"ClassId Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getClassId().equalsIgnoreCase(
							dbMemberDetails.getClassId())) {
						logger.log(LogStatus.PASS,
								"ClassId || Expected( DB Value) ==> "
										+ dbMemberDetails.getClassId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getClassId());
					} else {
						logger.log(LogStatus.FAIL,
								"ClassId || Expected( DB Value) ==> "
										+ dbMemberDetails.getClassId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getClassId());
					}

					softAssert.assertEquals(
							excelMemberDetails.getSubscriberId(),
							dbMemberDetails.getSubscriberId(),
							"SubscriberId Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getSubscriberId().equalsIgnoreCase(
							dbMemberDetails.getSubscriberId())) {
						logger.log(LogStatus.PASS,
								"SubscriberId || Expected( DB Value) ==> "
										+ dbMemberDetails.getSubscriberId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getSubscriberId());
					} else {
						logger.log(LogStatus.FAIL,
								"SubscriberId || Expected( DB Value) ==> "
										+ dbMemberDetails.getSubscriberId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getSubscriberId());
					}

					softAssert.assertEquals(
							excelMemberDetails.getSsn(),
							dbMemberDetails.getSsn(),
							"Ssn Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getSsn().equalsIgnoreCase(
							dbMemberDetails.getSsn())) {
						logger.log(LogStatus.PASS,
								"Ssn || Expected( DB Value) ==> "
										+ dbMemberDetails.getSsn()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getSsn());
					} else {
						logger.log(LogStatus.FAIL,
								"Ssn || Expected( DB Value) ==> "
										+ dbMemberDetails.getSsn()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getSsn());
					}

					softAssert.assertEquals(
							excelMemberDetails.getSubscriberName(),
							dbMemberDetails.getSubscriberName(),
							"SubscriberName Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getSubscriberName()
							.equalsIgnoreCase(
									dbMemberDetails.getSubscriberName())) {
						logger.log(
								LogStatus.PASS,
								"SubscriberName || Expected( DB Value) ==> "
										+ dbMemberDetails.getSubscriberName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails
												.getSubscriberName());
					} else {
						logger.log(
								LogStatus.FAIL,
								"SubscriberName || Expected( DB Value) ==> "
										+ dbMemberDetails.getSubscriberName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails
												.getSubscriberName());
					}

					softAssert.assertEquals(
							excelMemberDetails.getPatientName(),
							dbMemberDetails.getPatientName(),
							"PatientName Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getPatientName().equalsIgnoreCase(
							dbMemberDetails.getPatientName())) {
						logger.log(LogStatus.PASS,
								"PatientName || Expected( DB Value) ==> "
										+ dbMemberDetails.getPatientName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPatientName());
					} else {
						logger.log(LogStatus.FAIL,
								"PatientName || Expected( DB Value) ==> "
										+ dbMemberDetails.getPatientName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPatientName());
					}

					softAssert.assertEquals(
							excelMemberDetails.getRelationship(),
							dbMemberDetails.getRelationship(),
							"Relationship Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getRelationship().equalsIgnoreCase(
							dbMemberDetails.getRelationship())) {
						logger.log(LogStatus.PASS,
								"Relationship || Expected( DB Value) ==> "
										+ dbMemberDetails.getRelationship()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getRelationship());
					} else {
						logger.log(LogStatus.FAIL,
								"Relationship || Expected( DB Value) ==> "
										+ dbMemberDetails.getRelationship()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getRelationship());
					}

					softAssert.assertEquals(
							excelMemberDetails.getDept(),
							dbMemberDetails.getDept(),
							"Dept Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getDept().equalsIgnoreCase(
							dbMemberDetails.getDept())) {
						logger.log(LogStatus.PASS,
								"Dept || Expected( DB Value) ==> "
										+ dbMemberDetails.getDept()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getDept());
					} else {
						logger.log(LogStatus.FAIL,
								"Dept || Expected( DB Value) ==> "
										+ dbMemberDetails.getDept()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getDept());
					}

					softAssert.assertEquals(
							excelMemberDetails.getClaimId(),
							dbMemberDetails.getClaimId(),
							"ClaimId Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getClaimId().equalsIgnoreCase(
							dbMemberDetails.getClaimId())) {
						logger.log(LogStatus.PASS,
								"ClaimId || Expected( DB Value) ==> "
										+ dbMemberDetails.getClaimId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getClaimId());
					} else {
						logger.log(LogStatus.FAIL,
								"ClaimId || Expected( DB Value) ==> "
										+ dbMemberDetails.getClaimId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getClaimId());
					}

					softAssert.assertEquals(
							excelMemberDetails.getCheckNumber(),
							dbMemberDetails.getCheckNumber(),
							"CheckNumber Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getCheckNumber().compareTo(
							dbMemberDetails.getCheckNumber()) == 0) {
						logger.log(LogStatus.PASS,
								"CheckNumber || Expected( DB Value) ==> "
										+ dbMemberDetails.getCheckNumber()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getCheckNumber());
					} else {
						logger.log(LogStatus.FAIL,
								"CheckNumber || Expected( DB Value) ==> "
										+ dbMemberDetails.getCheckNumber()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getCheckNumber());
					}

					softAssert.assertEquals(
							excelMemberDetails.getPaidDate(),
							dbMemberDetails.getPaidDate(),
							"PaidDate Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getPaidDate().equalsIgnoreCase(
							dbMemberDetails.getPaidDate())) {
						logger.log(LogStatus.PASS,
								"PaidDate || Expected( DB Value) ==> "
										+ dbMemberDetails.getPaidDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPaidDate());
					} else {
						logger.log(LogStatus.FAIL,
								"PaidDate || Expected( DB Value) ==> "
										+ dbMemberDetails.getPaidDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPaidDate());
					}

					softAssert.assertEquals(
							excelMemberDetails.getFromDate(),
							dbMemberDetails.getFromDate(),
							"FromDate Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getFromDate().equalsIgnoreCase(
							dbMemberDetails.getFromDate())) {
						logger.log(LogStatus.PASS,
								"FromDate || Expected( DB Value) ==> "
										+ dbMemberDetails.getFromDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getFromDate());
					} else {
						logger.log(LogStatus.FAIL,
								"FromDate || Expected( DB Value) ==> "
										+ dbMemberDetails.getFromDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getFromDate());
					}

					softAssert.assertEquals(
							excelMemberDetails.getToDate(),
							dbMemberDetails.getToDate(),
							"ToDate Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getToDate().equalsIgnoreCase(
							dbMemberDetails.getToDate())) {
						logger.log(LogStatus.PASS,
								"ToDate || Expected( DB Value) ==> "
										+ dbMemberDetails.getToDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getToDate());
					} else {
						logger.log(LogStatus.FAIL,
								"ToDate || Expected( DB Value) ==> "
										+ dbMemberDetails.getToDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getToDate());
					}

					softAssert.assertEquals(excelMemberDetails.getPayeeName(),
							dbMemberDetails.getPayeeName(),
							"PayeeName Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getPayeeName().equalsIgnoreCase(
							dbMemberDetails.getPayeeName())) {
						logger.log(LogStatus.PASS,
								"PayeeName || Expected( DB Value) ==> "
										+ dbMemberDetails.getPayeeName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPayeeName());
					} else {
						logger.log(LogStatus.FAIL,
								"PayeeName || Expected( DB Value) ==> "
										+ dbMemberDetails.getPayeeName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPayeeName());
					}

					softAssert.assertEquals(
							excelMemberDetails.getPayeeId(),
							dbMemberDetails.getPayeeId(),
							"PayeeId Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getPayeeId().equalsIgnoreCase(
							dbMemberDetails.getPayeeId())) {
						logger.log(LogStatus.PASS,
								"PayeeId || Expected( DB Value) ==> "
										+ dbMemberDetails.getPayeeId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPayeeId());
					} else {
						logger.log(LogStatus.FAIL,
								"PayeeId || Expected( DB Value) ==> "
										+ dbMemberDetails.getPayeeId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPayeeId());
					}

					softAssert.assertEquals(
							excelMemberDetails.getCoverage(),
							dbMemberDetails.getCoverage(),
							"Coverage Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getCoverage().equalsIgnoreCase(
							dbMemberDetails.getCoverage())) {
						logger.log(LogStatus.PASS,
								"Coverage || Expected( DB Value) ==> "
										+ dbMemberDetails.getCoverage()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getCoverage());
					} else {
						logger.log(LogStatus.FAIL,
								"Coverage || Expected( DB Value) ==> "
										+ dbMemberDetails.getCoverage()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getCoverage());
					}

					softAssert.assertEquals(excelMemberDetails.getDeductible(),
							dbMemberDetails.getDeductible(),
							"Deductible Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getDeductible().equalsIgnoreCase(
							dbMemberDetails.getDeductible())) {
						logger.log(LogStatus.PASS,
								"Deductible || Expected( DB Value) ==> "
										+ dbMemberDetails.getDeductible()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getDeductible());
					} else {
						logger.log(LogStatus.FAIL,
								"Deductible || Expected( DB Value) ==> "
										+ dbMemberDetails.getDeductible()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getDeductible());
					}

					softAssert.assertEquals(
							excelMemberDetails.getCoinsurance(),
							dbMemberDetails.getCoinsurance(),
							"Coinsurance Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getCoinsurance().equalsIgnoreCase(
							dbMemberDetails.getCoinsurance())) {
						logger.log(LogStatus.PASS,
								"Coinsurance || Expected( DB Value) ==> "
										+ dbMemberDetails.getCoinsurance()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getCoinsurance());
					} else {
						logger.log(LogStatus.FAIL,
								"Coinsurance || Expected( DB Value) ==> "
										+ dbMemberDetails.getCoinsurance()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getCoinsurance());
					}

					softAssert.assertEquals(
							excelMemberDetails.getCopay(),
							dbMemberDetails.getCopay(),
							"Copay Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getCopay().equalsIgnoreCase(
							dbMemberDetails.getCopay())) {
						logger.log(LogStatus.PASS,
								"Copay || Expected( DB Value) ==> "
										+ dbMemberDetails.getCopay()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getCopay());
					} else {
						logger.log(LogStatus.FAIL,
								"Copay || Expected( DB Value) ==> "
										+ dbMemberDetails.getCopay()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getCopay());
					}

					softAssert.assertEquals(
							excelMemberDetails.getMedical(),
							dbMemberDetails.getMedical(),
							"Medical Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getMedical().equalsIgnoreCase(
							dbMemberDetails.getMedical())) {
						logger.log(LogStatus.PASS,
								"Medical || Expected( DB Value) ==> "
										+ dbMemberDetails.getMedical()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getMedical());
					} else {
						logger.log(LogStatus.FAIL,
								"Medical || Expected( DB Value) ==> "
										+ dbMemberDetails.getMedical()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getMedical());
					}

					softAssert.assertEquals(
							excelMemberDetails.getCostContainment(),
							dbMemberDetails.getCostContainment(),
							"CostContainment Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getCostContainment()
							.equalsIgnoreCase(
									dbMemberDetails.getCostContainment())) {
						logger.log(
								LogStatus.PASS,
								"CostContainment || Expected( DB Value) ==> "
										+ dbMemberDetails.getCostContainment()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails
												.getCostContainment());
					} else {
						logger.log(
								LogStatus.FAIL,
								"CostContainment || Expected( DB Value) ==> "
										+ dbMemberDetails.getCostContainment()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails
												.getCostContainment());
					}

					softAssert.assertEquals(
							excelMemberDetails.getInterest(),
							dbMemberDetails.getInterest(),
							"Interest Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getInterest().equalsIgnoreCase(
							dbMemberDetails.getInterest())) {
						logger.log(LogStatus.PASS,
								"Interest || Expected( DB Value) ==> "
										+ dbMemberDetails.getInterest()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getInterest());
					} else {
						logger.log(LogStatus.FAIL,
								"Interest || Expected( DB Value) ==> "
										+ dbMemberDetails.getInterest()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getInterest());
					}

					softAssert.assertEquals(
							excelMemberDetails.getDental(),
							dbMemberDetails.getDental(),
							"Dental Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getDental().equalsIgnoreCase(
							dbMemberDetails.getDental())) {
						logger.log(LogStatus.PASS,
								"Dental || Expected( DB Value) ==> "
										+ dbMemberDetails.getDental()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getDental());
					} else {
						logger.log(LogStatus.FAIL,
								"Dental || Expected( DB Value) ==> "
										+ dbMemberDetails.getDental()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getDental());
					}

					softAssert.assertEquals(
							excelMemberDetails.getPharmacy(),
							dbMemberDetails.getPharmacy(),
							"Pharmacy Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getPharmacy().equalsIgnoreCase(
							dbMemberDetails.getPharmacy())) {
						logger.log(LogStatus.PASS,
								"Pharmacy || Expected( DB Value) ==> "
										+ dbMemberDetails.getPharmacy()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPharmacy());
					} else {
						logger.log(LogStatus.FAIL,
								"Pharmacy || Expected( DB Value) ==> "
										+ dbMemberDetails.getPharmacy()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getPharmacy());
					}

					softAssert.assertEquals(
							excelMemberDetails.getBluecard(),
							dbMemberDetails.getBluecard(),
							"Bluecard Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getBluecard().equalsIgnoreCase(
							dbMemberDetails.getBluecard())) {
						logger.log(LogStatus.PASS,
								"Bluecard || Expected( DB Value) ==> "
										+ dbMemberDetails.getBluecard()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getBluecard());
					} else {
						logger.log(LogStatus.FAIL,
								"Bluecard || Expected( DB Value) ==> "
										+ dbMemberDetails.getBluecard()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getBluecard());
					}

					softAssert.assertEquals(
							excelMemberDetails.getStoploss(),
							dbMemberDetails.getStoploss(),
							"Stoploss Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getStoploss().equalsIgnoreCase(
							dbMemberDetails.getStoploss())) {
						logger.log(LogStatus.PASS,
								"Stoploss || Expected( DB Value) ==> "
										+ dbMemberDetails.getStoploss()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getStoploss());
					} else {
						logger.log(LogStatus.FAIL,
								"Stoploss || Expected( DB Value) ==> "
										+ dbMemberDetails.getStoploss()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getStoploss());
					}

					softAssert.assertEquals(
							excelMemberDetails.getHra(),
							dbMemberDetails.getHra(),
							"Hra Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getHra().equalsIgnoreCase(
							dbMemberDetails.getHra())) {
						logger.log(LogStatus.PASS,
								"Hra || Expected( DB Value) ==> "
										+ dbMemberDetails.getHra()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getHra());
					} else {
						logger.log(LogStatus.FAIL,
								"Hra || Expected( DB Value) ==> "
										+ dbMemberDetails.getHra()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getHra());
					}

					softAssert.assertEquals(excelMemberDetails.getTotalPaid(),
							dbMemberDetails.getTotalPaid(),
							"TotalPaid Mismatch for claim ID:"
									+ dbMemberDetails.getClaimId());
					if (excelMemberDetails.getTotalPaid().equalsIgnoreCase(
							dbMemberDetails.getTotalPaid())) {
						logger.log(LogStatus.PASS,
								"TotalPaid || Expected( DB Value) ==> "
										+ dbMemberDetails.getTotalPaid()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getTotalPaid());
					} else {
						logger.log(LogStatus.FAIL,
								"TotalPaid || Expected( DB Value) ==> "
										+ dbMemberDetails.getTotalPaid()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelMemberDetails.getTotalPaid());
					}
				}
			}
		}
		softAssert.assertAll();
	}

	@Test(dataProvider = "providePlanDetailsData")
	public void testPlanDetailsData(String invoiceNo,
			Hashtable<String, List<PlanDetails>> planDetailsExcelTable,
			Hashtable<String, List<PlanDetails>> planDetailsDBTable) {
		List<PlanDetails> planDetailsExcelList = planDetailsExcelMap
				.get(invoiceNo);
		List<PlanDetails> planDetailsDBList = planDetailsDBMap.get(invoiceNo);
		SoftAssert softAssert = new SoftAssert();
		reportInit("Test Plan Details Data || Invoice No => ", invoiceNo);
		for (PlanDetails excelPlanDetails : planDetailsExcelList) {
			for (int i = 0; i < planDetailsDBList.size(); i++) {
				PlanDetails dbPlanDetails = planDetailsDBList.get(i);
				if (excelPlanDetails.getPlanDetailsTotals().equalsIgnoreCase(
						dbPlanDetails.getPlanDetailsTotals())) {
					logger.log(LogStatus.INFO,
							"Testing for Plan Details Total => "
									+ dbPlanDetails.getPlanDetailsTotals());

					softAssert.assertEquals(
							excelPlanDetails.getGroupName(),
							dbPlanDetails.getGroupName(),
							"	GroupName	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getGroupName().equalsIgnoreCase(
							dbPlanDetails.getGroupName())) {
						logger.log(LogStatus.PASS,
								"GroupName || Expected( DB Value) ==> "
										+ dbPlanDetails.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getGroupName());
					} else {
						logger.log(LogStatus.FAIL,
								"GroupName || Expected( DB Value) ==> "
										+ dbPlanDetails.getGroupName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getGroupName());
					}

					softAssert.assertEquals(
							excelPlanDetails.getAfaId(),
							dbPlanDetails.getAfaId(),
							"	AfaId	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getAfaId().equalsIgnoreCase(
							dbPlanDetails.getAfaId())) {
						logger.log(LogStatus.PASS,
								"AfaId || Expected( DB Value) ==> "
										+ dbPlanDetails.getAfaId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getAfaId());
					} else {
						logger.log(LogStatus.FAIL,
								"AfaId || Expected( DB Value) ==> "
										+ dbPlanDetails.getAfaId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getAfaId());
					}

					softAssert.assertEquals(excelPlanDetails.getClaimsCycle(),
							dbPlanDetails.getClaimsCycle(),
							"	ClaimsCycle	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getClaimsCycle().equalsIgnoreCase(
							dbPlanDetails.getClaimsCycle())) {
						logger.log(LogStatus.PASS,
								"ClaimsCycle || Expected( DB Value) ==> "
										+ dbPlanDetails.getClaimsCycle()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getClaimsCycle());
					} else {
						logger.log(LogStatus.FAIL,
								"ClaimsCycle || Expected( DB Value) ==> "
										+ dbPlanDetails.getClaimsCycle()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getClaimsCycle());
					}

					softAssert.assertEquals(excelPlanDetails.getBillDueDate(),
							dbPlanDetails.getBillDueDate(),
							"	BillDueDate	Mismatch for claim ID:"
									+ dbPlanDetails.getBillDueDate());
					if (excelPlanDetails.getBillDueDate().equalsIgnoreCase(
							dbPlanDetails.getBillDueDate())) {
						logger.log(LogStatus.PASS,
								"BillDueDate || Expected( DB Value) ==> "
										+ dbPlanDetails.getBillDueDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getBillDueDate());
					} else {
						logger.log(LogStatus.FAIL,
								"BillDueDate || Expected( DB Value) ==> "
										+ dbPlanDetails.getBillDueDate()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getBillDueDate());
					}

					softAssert.assertEquals(
							excelPlanDetails.getInvoiceNo(),
							dbPlanDetails.getInvoiceNo(),
							"	InvoiceNo	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getInvoiceNo().equalsIgnoreCase(
							dbPlanDetails.getInvoiceNo())) {
						logger.log(LogStatus.PASS,
								"InvoiceNo || Expected( DB Value) ==> "
										+ dbPlanDetails.getInvoiceNo()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getInvoiceNo());
					} else {
						logger.log(LogStatus.FAIL,
								"InvoiceNo || Expected( DB Value) ==> "
										+ dbPlanDetails.getInvoiceNo()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getInvoiceNo());
					}

					softAssert.assertEquals(excelPlanDetails.getGroupIdName(),
							dbPlanDetails.getGroupIdName(),
							"	GroupIdName	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getGroupIdName().equalsIgnoreCase(
							dbPlanDetails.getGroupIdName())) {
						logger.log(LogStatus.PASS,
								"GroupIdName || Expected( DB Value) ==> "
										+ dbPlanDetails.getGroupIdName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getGroupIdName());
					} else {
						logger.log(LogStatus.FAIL,
								"GroupIdName || Expected( DB Value) ==> "
										+ dbPlanDetails.getGroupIdName()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getGroupIdName());
					}

					softAssert.assertEquals(
							excelPlanDetails.getPln(),
							dbPlanDetails.getPln(),
							"	Pln	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getPln().equalsIgnoreCase(
							dbPlanDetails.getPln())) {
						logger.log(LogStatus.PASS,
								"Pln || Expected( DB Value) ==> "
										+ dbPlanDetails.getPln()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getPln());
					} else {
						logger.log(LogStatus.FAIL,
								"Pln || Expected( DB Value) ==> "
										+ dbPlanDetails.getPln()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getPln());
					}

					softAssert.assertEquals(
							excelPlanDetails.getCbc(),
							dbPlanDetails.getCbc(),
							"	Cbc	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getCbc().equalsIgnoreCase(
							dbPlanDetails.getCbc())) {
						logger.log(LogStatus.PASS,
								"Cbc || Expected( DB Value) ==> "
										+ dbPlanDetails.getCbc()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getCbc());
					} else {
						logger.log(LogStatus.FAIL,
								"Cbc || Expected( DB Value) ==> "
										+ dbPlanDetails.getCbc()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getCbc());
					}

					softAssert.assertEquals(
							excelPlanDetails.getGrpId(),
							dbPlanDetails.getGrpId(),
							"	GrpId	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getGrpId().equalsIgnoreCase(
							dbPlanDetails.getGrpId())) {
						logger.log(LogStatus.PASS,
								"GrpId || Expected( DB Value) ==> "
										+ dbPlanDetails.getGrpId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getGrpId());
					} else {
						logger.log(LogStatus.FAIL,
								"GrpId || Expected( DB Value) ==> "
										+ dbPlanDetails.getGrpId()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getGrpId());
					}

					softAssert.assertEquals(
							excelPlanDetails.getCoverage(),
							dbPlanDetails.getCoverage(),
							"	Coverage	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getCoverage().equalsIgnoreCase(
							dbPlanDetails.getCoverage())) {
						logger.log(LogStatus.PASS,
								"Coverage || Expected( DB Value) ==> "
										+ dbPlanDetails.getCoverage()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getCoverage());
					} else {
						logger.log(LogStatus.FAIL,
								"Coverage || Expected( DB Value) ==> "
										+ dbPlanDetails.getCoverage()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getCoverage());
					}

					softAssert.assertEquals(
							excelPlanDetails.getPlanDetailsTotals(),
							dbPlanDetails.getPlanDetailsTotals(),
							"	PlanDetailsTotals	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getPlanDetailsTotals()
							.equalsIgnoreCase(
									dbPlanDetails.getPlanDetailsTotals())) {
						logger.log(
								LogStatus.PASS,
								"PlanDetailsTotals || Expected( DB Value) ==> "
										+ dbPlanDetails.getPlanDetailsTotals()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails
												.getPlanDetailsTotals());
					} else {
						logger.log(
								LogStatus.FAIL,
								"PlanDetailsTotals || Expected( DB Value) ==> "
										+ dbPlanDetails.getPlanDetailsTotals()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails
												.getPlanDetailsTotals());
					}

					softAssert.assertEquals(
							excelPlanDetails.getMedical(),
							dbPlanDetails.getMedical(),
							"	Medical	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getMedical().equalsIgnoreCase(
							dbPlanDetails.getMedical())) {
						logger.log(LogStatus.PASS,
								"Medical || Expected( DB Value) ==> "
										+ dbPlanDetails.getMedical()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getMedical());
					} else {
						logger.log(LogStatus.FAIL,
								"Medical || Expected( DB Value) ==> "
										+ dbPlanDetails.getMedical()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getMedical());
					}

					softAssert.assertEquals(
							excelPlanDetails.getCostContainment(),
							dbPlanDetails.getCostContainment(),
							"	CostContainment	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getCostContainment().equalsIgnoreCase(
							dbPlanDetails.getCostContainment())) {
						logger.log(LogStatus.PASS,
								"CostContainment || Expected( DB Value) ==> "
										+ dbPlanDetails.getCostContainment()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getCostContainment());
					} else {
						logger.log(LogStatus.FAIL,
								"CostContainment || Expected( DB Value) ==> "
										+ dbPlanDetails.getCostContainment()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getCostContainment());
					}

					softAssert.assertEquals(
							excelPlanDetails.getInterest(),
							dbPlanDetails.getInterest(),
							"	Interest	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getInterest().equalsIgnoreCase(
							dbPlanDetails.getInterest())) {
						logger.log(LogStatus.PASS,
								"Interest || Expected( DB Value) ==> "
										+ dbPlanDetails.getInterest()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getInterest());
					} else {
						logger.log(LogStatus.FAIL,
								"Interest || Expected( DB Value) ==> "
										+ dbPlanDetails.getInterest()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getInterest());
					}

					softAssert.assertEquals(
							excelPlanDetails.getDental(),
							dbPlanDetails.getDental(),
							"	Dental	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getDental().equalsIgnoreCase(
							dbPlanDetails.getDental())) {
						logger.log(LogStatus.PASS,
								"Dental || Expected( DB Value) ==> "
										+ dbPlanDetails.getDental()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getDental());
					} else {
						logger.log(LogStatus.FAIL,
								"Dental || Expected( DB Value) ==> "
										+ dbPlanDetails.getDental()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getDental());
					}

					softAssert.assertEquals(
							excelPlanDetails.getPharmacy(),
							dbPlanDetails.getPharmacy(),
							"	Pharmacy	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getPharmacy().equalsIgnoreCase(
							dbPlanDetails.getPharmacy())) {
						logger.log(LogStatus.PASS,
								"Pharmacy || Expected( DB Value) ==> "
										+ dbPlanDetails.getPharmacy()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getPharmacy());
					} else {
						logger.log(LogStatus.FAIL,
								"Pharmacy || Expected( DB Value) ==> "
										+ dbPlanDetails.getPharmacy()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getPharmacy());
					}

					softAssert.assertEquals(
							excelPlanDetails.getStoploss(),
							dbPlanDetails.getStoploss(),
							"	Stoploss	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getStoploss().equalsIgnoreCase(
							dbPlanDetails.getStoploss())) {
						logger.log(LogStatus.PASS,
								"Stoploss || Expected( DB Value) ==> "
										+ dbPlanDetails.getStoploss()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getStoploss());
					} else {
						logger.log(LogStatus.FAIL,
								"Stoploss || Expected( DB Value) ==> "
										+ dbPlanDetails.getStoploss()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getStoploss());
					}

					softAssert.assertEquals(
							excelPlanDetails.getBluecard(),
							dbPlanDetails.getBluecard(),
							"	Bluecard	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getBluecard().equalsIgnoreCase(
							dbPlanDetails.getBluecard())) {
						logger.log(LogStatus.PASS,
								"Bluecard || Expected( DB Value) ==> "
										+ dbPlanDetails.getBluecard()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getBluecard());
					} else {
						logger.log(LogStatus.FAIL,
								"Bluecard || Expected( DB Value) ==> "
										+ dbPlanDetails.getBluecard()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getBluecard());
					}

					softAssert.assertEquals(
							excelPlanDetails.getHra(),
							dbPlanDetails.getHra(),
							"	Hra	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getHra().equalsIgnoreCase(
							dbPlanDetails.getHra())) {
						logger.log(LogStatus.PASS,
								"Hra || Expected( DB Value) ==> "
										+ dbPlanDetails.getHra()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getHra());
					} else {
						logger.log(LogStatus.FAIL,
								"Hra || Expected( DB Value) ==> "
										+ dbPlanDetails.getHra()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getHra());
					}

					softAssert.assertEquals(
							excelPlanDetails.getTotalPaid(),
							dbPlanDetails.getTotalPaid(),
							"	TotalPaid	Mismatch for claim ID:"
									+ dbPlanDetails.getPlanDetailsTotals());
					if (excelPlanDetails.getTotalPaid().equalsIgnoreCase(
							dbPlanDetails.getTotalPaid())) {
						logger.log(LogStatus.PASS,
								"TotalPaid || Expected( DB Value) ==> "
										+ dbPlanDetails.getTotalPaid()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getTotalPaid());
					} else {
						logger.log(LogStatus.FAIL,
								"TotalPaid || Expected( DB Value) ==> "
										+ dbPlanDetails.getTotalPaid()
										+ " ||  Actual(Invoice Report) ==> "
										+ excelPlanDetails.getTotalPaid());
					}

				}
			}
		}
		softAssert.assertAll();
	}

	@DataProvider
	public Object[][] provideFrontPageData() {
		Object[][] data = new Object[DatabaseUtil.frontPageInputSet.size()][3];
		Hashtable<String, FrontPage> frontPageExcelTable = null;
		Hashtable<String, FrontPage> frontPageDBTable = null;

		int i = 0;
		for (String invoiceNo : DatabaseUtil.frontPageInputSet) {
			frontPageExcelTable = new Hashtable<String, FrontPage>();
			frontPageExcelTable
					.put(invoiceNo, frontPageExcelMap.get(invoiceNo));
			frontPageDBTable = new Hashtable<String, FrontPage>();
			frontPageDBTable.put(invoiceNo, frontPageDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = frontPageExcelTable;
			data[i][2] = frontPageDBTable;
			i++;
		}
		return data;
	}

	@DataProvider
	public Object[][] provideClaimsActivitySummaryData() {
		Object[][] data = new Object[DatabaseUtil.claimsActivitySummaryInputSet
				.size()][3];
		Hashtable<String, List<ClaimsActivitySummary>> ClaimsActivitySummaryExcelTable = null;
		Hashtable<String, List<ClaimsActivitySummary>> ClaimsActivitySummaryDBTable = null;

		int i = 0;
		for (String invoiceNo : DatabaseUtil.claimsActivitySummaryInputSet) {
			ClaimsActivitySummaryExcelTable = new Hashtable<String, List<ClaimsActivitySummary>>();
			ClaimsActivitySummaryExcelTable.put(invoiceNo,
					claimsActivitySummaryExcelMap.get(invoiceNo));
			ClaimsActivitySummaryDBTable = new Hashtable<String, List<ClaimsActivitySummary>>();
			ClaimsActivitySummaryDBTable.put(invoiceNo,
					claimsActivitySummaryDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = ClaimsActivitySummaryExcelTable;
			data[i][2] = ClaimsActivitySummaryDBTable;
			i++;
		}
		return data;
	}

	@DataProvider
	public Object[][] provideShieldSavingData() {
		Object[][] data = new Object[DatabaseUtil.shieldSavingsInputSet.size()][3];
		Hashtable<String, List<ShieldSaving>> shieldSavingExcelTable = null;
		Hashtable<String, List<ShieldSaving>> shieldSavingDBTable = null;

		int i = 0;
		for (String invoiceNo : DatabaseUtil.shieldSavingsInputSet) {

			shieldSavingExcelTable = new Hashtable<String, List<ShieldSaving>>();
			// System.out.println(shieldSavingExcelMap.get(invoiceNo).size()+" Map");
			shieldSavingExcelTable.put(invoiceNo,
					shieldSavingExcelMap.get(invoiceNo));
			shieldSavingDBTable = new Hashtable<String, List<ShieldSaving>>();
			shieldSavingDBTable
					.put(invoiceNo, shieldSavingDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = shieldSavingExcelTable;
			data[i][2] = shieldSavingDBTable;
			i++;
		}
		return data;
	}

	@DataProvider
	public Object[][] provideMemberDetailsData() {
		Object[][] data = new Object[DatabaseUtil.memberDetailsInputSet.size()][3];
		Hashtable<String, List<MemberDetails>> memberDetailsExcelTable = null;
		Hashtable<String, List<MemberDetails>> memberDetailsDBTable = null;

		int i = 0;
		for (String invoiceNo : DatabaseUtil.memberDetailsInputSet) {
			memberDetailsExcelTable = new Hashtable<String, List<MemberDetails>>();
			memberDetailsExcelTable.put(invoiceNo,
					memberDetailsExcelMap.get(invoiceNo));
			memberDetailsDBTable = new Hashtable<String, List<MemberDetails>>();
			memberDetailsDBTable.put(invoiceNo,
					memberDetailsDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = memberDetailsExcelTable;
			data[i][2] = memberDetailsDBTable;
			i++;
		}
		return data;
	}

	@DataProvider
	public Object[][] providePlanDetailsData() {
		Object[][] data = new Object[DatabaseUtil.planDetailsInputSet.size()][3];
		Hashtable<String, List<PlanDetails>> planDetailsExcelTable = null;
		Hashtable<String, List<PlanDetails>> planDetailsDBTable = null;

		int i = 0;
		for (String invoiceNo : DatabaseUtil.planDetailsInputSet) {
			planDetailsExcelTable = new Hashtable<String, List<PlanDetails>>();
			planDetailsExcelTable.put(invoiceNo,
					planDetailsExcelMap.get(invoiceNo));
			planDetailsDBTable = new Hashtable<String, List<PlanDetails>>();
			planDetailsDBTable.put(invoiceNo, planDetailsDBMap.get(invoiceNo));
			data[i][0] = invoiceNo;
			data[i][1] = planDetailsExcelTable;
			data[i][2] = planDetailsDBTable;
			i++;
		}
		return data;
	}

	@AfterSuite
	public void closeConnection() {
		if (session != null) {
			session.close();
			logger1.info("DB Connection Succesfully closed!");
			logger1.info("Test execution ended!");
		}
	}

	/**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssertions = new SoftAssertions();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssertions.assertAll();
	}

	//TODO: Please describe this method. Please do not use any static declarations
	/**
	 * 
	 * @param directoryName
	 * @param wildcard
	 * @return
	 * @throws Exception
	 */
	public File getMatchingAndLatestFile(String directoryName,
			String wildcard) throws Exception {
		{
			File directory = new File(directoryName);
			Collection<File> files = FileUtils.listFiles(directory,
					new WildcardFileFilter(wildcard), null);
			if (files.size() == 0) {
				Exception e = new Exception(
						"No files matching specified pattern -" + wildcard);
				throw new Exception(e);
			}
			File latestFile = null;
			Long lastModified = new Long(0);
			for (File file : files) {
				if (lastModified < file.lastModified()) {
					lastModified = file.lastModified();
					latestFile = file;
				}
			}
			return latestFile;
		}
	}
}
