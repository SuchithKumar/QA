package com.bsc.qa.facets.afa.excel_reader;

import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.bsc.qa.facets.afa.dao.DatabaseUtil;
import com.bsc.qa.facets.afa.pojo.ClaimsActivitySummary;
import com.bsc.qa.facets.afa.pojo.FrontPage;
import com.bsc.qa.facets.afa.pojo.MemberDetails;
import com.bsc.qa.facets.afa.pojo.PlanDetails;
import com.bsc.qa.facets.afa.pojo.ShieldSaving;
import com.bsc.qa.facets.afa.test.AfaInvoiceReportValidationTest;

//TODO: Remove any reporting features other than BQSA reporting features
public class AfaInvoiceReportReader {
//	static File afaInvoiceReport = new File(AfaInvoiceReportValidationTest.afaInvoiceReportFile);
	File afaInvoiceReport  = null;
	private static Set<String> inputInvoiceNoSet = new HashSet<String>();
	private Map<String,FrontPage> frontPageExcelMap;
	private Map<String,List<ShieldSaving>> shieldSavingExcelMap;
	private Map<String,List<ClaimsActivitySummary>> claimsActivitySummaryExcelMap;
	private Map<String,List<MemberDetails>> memberDetailsExcelMap;
	private Map<String,List<PlanDetails>> planDetailsExcelMap;
	


	private static String getCellValue(Cell cell) {
		String celldata = "";
		try {
			switch (cell.getCellTypeEnum()) {
			case STRING:
				celldata = cell.getRichStringCellValue().getString().trim();
				break;
			case NUMERIC:
				if (DateUtil.isCellDateFormatted(cell)) {
					celldata = cell.getDateCellValue().toString();
				} else {
					BigDecimal bigDecimal = BigDecimal.valueOf(cell.getNumericCellValue()).stripTrailingZeros();
					celldata = bigDecimal.toPlainString().trim();
				}
				break;
			default:
				celldata = "";

			}
		} catch (Exception e) {
			//TODO: No empty catch clauses. Must have at least a decent System.out.println and e.printStackTrace()
			System.out.println("ERROR: when getting cell value" );
			e.printStackTrace();
		}

		return celldata;

	}

	public  Map<String,FrontPage> getFrontPageData() {
		frontPageExcelMap = new HashMap<String, FrontPage>();
		
		
		for (String invoiceNO : DatabaseUtil.frontPageInputSet) {
			FrontPage frontPage = new FrontPage();
			try {
				
				Workbook workbook = WorkbookFactory.create(afaInvoiceReport);
				Sheet frontPageSheet = workbook.getSheetAt(0);

				for (int i = 1; i <= frontPageSheet.getLastRowNum(); i++) {
					Row row = frontPageSheet.getRow(i);
					Cell cell = row.getCell(2);
					String celldata = getCellValue(cell);
					if (celldata.contains(invoiceNO)) {
						int rowno = cell.getRowIndex();
						
						Cell groupName = frontPageSheet.getRow(rowno-8).getCell(2);
						Cell groupAddressLine1 = frontPageSheet.getRow(rowno-7).getCell(2);
						Cell groupAddressLine2 = frontPageSheet.getRow(rowno-6).getCell(2);
						Cell attention = frontPageSheet.getRow(rowno-5).getCell(2);
						Cell groupBillingId = frontPageSheet.getRow(rowno-3).getCell(2);
						Cell fundingPeriod = frontPageSheet.getRow(rowno-2).getCell(2);
						Cell billDueDate = frontPageSheet.getRow(rowno-1).getCell(2);
						Cell invoiceNo = frontPageSheet.getRow(rowno).getCell(2);
						Cell invoiceDate = frontPageSheet.getRow(rowno+1).getCell(2);
						Cell currentPeriodClaims = frontPageSheet.getRow(rowno+3).getCell(4);
						Cell balanceForward = frontPageSheet.getRow(rowno+4).getCell(4);
						Cell totalDueForClaimsReimbursement = frontPageSheet.getRow(rowno+6).getCell(4);
						Cell bscAccountName = frontPageSheet.getRow(rowno+10).getCell(6);
						Cell phone = frontPageSheet.getRow(rowno+12).getCell(5);
						Cell fax = frontPageSheet.getRow(rowno+13).getCell(5);
						Cell email = frontPageSheet.getRow(rowno+14).getCell(5);

						frontPage.setGroupName(getCellValue(groupName).trim());
						frontPage.setGroupAddress(getCellValue(groupAddressLine1).trim()+"  "+getCellValue(groupAddressLine2).trim());
						frontPage.setAttention(getCellValue(attention).trim());
						frontPage.setGroupBillingId(getCellValue(groupBillingId).trim());
						frontPage.setAttention(getCellValue(attention).trim().trim());
						frontPage.setGroupBillingId(getCellValue(groupBillingId).trim());
						frontPage.setFundingPeriod(getCellValue(fundingPeriod).trim());
						frontPage.setBillDueDate(getCellValue(billDueDate).trim());
						frontPage.setInvoiceNo(getCellValue(invoiceNo).trim());
						frontPage.setInvoiceDate(getCellValue(invoiceDate).trim());
						frontPage.setCurrentPeriodClaims("$"+getCellValue(currentPeriodClaims).trim());
						frontPage.setBalanceForward("$"+getCellValue(balanceForward).trim());
						frontPage.setTotalDueForClaimsReimbursement("$"+getCellValue(totalDueForClaimsReimbursement).trim());
						frontPage.setBscAccountantName(getCellValue(bscAccountName).trim());
						frontPage.setPhone(getCellValue(phone).trim());
						frontPage.setFax(getCellValue(fax).trim());
						frontPage.setEmail(getCellValue(email).trim());
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			frontPageExcelMap.put(invoiceNO,frontPage);
//			System.out.println("Excel Row   : "+frontPage);
		}
		return frontPageExcelMap;
	}
	
	
	public  Map<String,List<ShieldSaving>> getShieldSavingData(Map<String,List<ShieldSaving>> shieldSavingDBData) {
		shieldSavingExcelMap = new HashMap<String, List<ShieldSaving>>();
		
		
		for (String invoiceNO : DatabaseUtil.shieldSavingsInputSet) {
			List<ShieldSaving> shieldSavingDBList = shieldSavingDBData.get(invoiceNO);
			List<ShieldSaving> shieldSavingExcelList = new ArrayList<ShieldSaving>();
			try {
				Workbook workbook = WorkbookFactory.create(afaInvoiceReport);
				Sheet shieldSavingSheet = workbook.getSheetAt(2);

				for (int i = 1; i <= shieldSavingSheet.getLastRowNum(); i++) {
					Row row = shieldSavingSheet.getRow(i);
					Cell cell = row.getCell(3);
					String celldata = getCellValue(cell);
					if (celldata.contains(invoiceNO)) {
						int rowno = cell.getRowIndex();
						for(int j=0;j<shieldSavingDBList.size();j++){
							ShieldSaving shieldSaving = new ShieldSaving();
							Cell claimPaymentPeriod = shieldSavingSheet.getRow(rowno-6).getCell(2);
							Cell groupName = shieldSavingSheet.getRow(rowno-4).getCell(3);
							Cell groupBillingID = shieldSavingSheet.getRow(rowno-3).getCell(3);
							Cell claimsCycle = shieldSavingSheet.getRow(rowno-2).getCell(3);
							Cell billDueDate = shieldSavingSheet.getRow(rowno-1).getCell(3);
							Cell invoiceNo = shieldSavingSheet.getRow(rowno).getCell(3);
							
							shieldSaving.setClaimPaymentPeriod(getCellValue(claimPaymentPeriod));
							shieldSaving.setGroupName(getCellValue(groupName));
							shieldSaving.setGroupBillingId(getCellValue(groupBillingID));
							shieldSaving.setClaimsCycle(getCellValue(claimsCycle));
							shieldSaving.setBillDueDate(getCellValue(billDueDate));
							shieldSaving.setInvoiceNo(getCellValue(invoiceNo));
							String findbillingCategory = shieldSavingDBList.get(j).getBillingCategory();
//							System.out.println("findbillingCategory : "+findbillingCategory);
							Row billingCategoryRow = shieldSavingSheet.getRow(rowno+4);
							Cell billingCategory 	   = null;
							Cell providerChargedAmount = null;
							Cell savings 			   = null;
							Cell disAllowed 		   = null;
							Cell allowedAmount 		   = null;
							Cell costContainment 	   = null;
							Cell total 				   = null;
							int billingCatIndex = 0;
							int totalIndex = 0;
							for(int a=0;a<billingCategoryRow.getLastCellNum();a++){
								Cell bc = billingCategoryRow.getCell(a);
								if(getCellValue(bc).trim().replace("Billing Category ", "").contains(findbillingCategory)){
									billingCatIndex = bc.getColumnIndex();
//									System.out.println(billingCatIndex+" - billingCatIndex");
									 billingCategory = shieldSavingSheet.getRow(rowno+4).getCell(billingCatIndex);
									 providerChargedAmount = shieldSavingSheet.getRow(rowno+6).getCell(billingCatIndex);
									 savings = shieldSavingSheet.getRow(rowno+7).getCell(billingCatIndex);
									 disAllowed = shieldSavingSheet.getRow(rowno+8).getCell(billingCatIndex);
									 allowedAmount = shieldSavingSheet.getRow(rowno+9).getCell(billingCatIndex);
									 costContainment = shieldSavingSheet.getRow(rowno+10).getCell(billingCatIndex);
									
									
								}
								if(getCellValue(bc).trim().contains("Total")){
								 total = shieldSavingSheet.getRow(rowno+11).getCell(billingCatIndex);
								}
							}
							
							String stringBillingCategory = getCellValue(billingCategory);
							shieldSaving.setBillingCategory(stringBillingCategory.replace("Billing Category ", "").trim());
							
							shieldSaving.setProviderChargedAmount("$"+getCellValue(providerChargedAmount));
							
							String stringSavings = getCellValue(savings);
							shieldSaving.setSavings("$"+stringSavings.replace("-", "").trim());
							
							shieldSaving.setDisallowed("$"+getCellValue(disAllowed));
							shieldSaving.setAllowedAmount("$"+getCellValue(allowedAmount));
							shieldSaving.setCostContainment("$"+getCellValue(costContainment));
							shieldSaving.setTotal("$"+getCellValue(total));
							shieldSavingExcelList.add(shieldSaving);
//							System.out.println("Excel Row   : "+shieldSaving);
							
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			shieldSavingExcelMap.put(invoiceNO,shieldSavingExcelList);
			
		}
		return shieldSavingExcelMap;
	}

	public  Map<String,List<ClaimsActivitySummary>>getClaimsActivitySummaryData(Map<String,List<ClaimsActivitySummary>> claimsActivitySummaryDBMap) {
		claimsActivitySummaryExcelMap = new HashMap<String, List<ClaimsActivitySummary>>();
		
		
		for (String invoiceNO : DatabaseUtil.claimsActivitySummaryInputSet) {
			List<ClaimsActivitySummary> claimsActivitySummaryDBList = claimsActivitySummaryDBMap.get(invoiceNO);
			List<ClaimsActivitySummary> claimsActivitySummaryExcelList = new ArrayList<ClaimsActivitySummary>();
//			for(ClaimsActivitySummary claims:claimsActivitySummaryDBList){
//				System.out.println("DataBase Row: "+claims);
//			}
			try {
				
				Workbook workbook = WorkbookFactory.create(afaInvoiceReport);
				Sheet claimsActivitySummarySheet = workbook.getSheetAt(1);

				for (int i = 1; i <= claimsActivitySummarySheet.getLastRowNum(); i++) {
					
					Row row = claimsActivitySummarySheet.getRow(i);
					Cell cell = row.getCell(3);
					String celldata = getCellValue(cell);
					if (celldata.contains(invoiceNO)) {
						int rowno = cell.getRowIndex();
					for(int j=0;j<claimsActivitySummaryDBList.size();j++){
						ClaimsActivitySummary claimsActivitySummary = new ClaimsActivitySummary();
						Cell claimPaymentPeriod = claimsActivitySummarySheet.getRow(rowno-7).getCell(2);
						Cell invoiceDate = claimsActivitySummarySheet.getRow(rowno-5).getCell(3);
						Cell groupName = claimsActivitySummarySheet.getRow(rowno-4).getCell(3);
						Cell groupBillingId = claimsActivitySummarySheet.getRow(rowno-3).getCell(3);
						Cell claimsCycle = claimsActivitySummarySheet.getRow(rowno-2).getCell(3);
						Cell billDueDate = claimsActivitySummarySheet.getRow(rowno-1).getCell(3);
						Cell invoiceNo = claimsActivitySummarySheet.getRow(rowno).getCell(3);
						Row billingCategoryRow = claimsActivitySummarySheet.getRow(rowno+2);
						int billingCatIndex = 0;
						int totalIndex=0;
						String findbillingCategory = claimsActivitySummaryDBList.get(j).getBillingCategory();
//						System.out.println(findbillingCategory+"-findbillingCategory");
//						System.out.println(claimsActivitySummaryDBList.get(j)+" "+j);
						Cell billingCategory	    	=    null;
						Cell medical 					=    null;
						Cell costContainment	  	 	=    null;
						Cell interest			   	 	=    null;
						Cell dental 					=    null;
						Cell pharmacy			    	=    null;
						Cell blueCardAcessFees 			=    null;
						Cell stoplossAdvancedFunding 	=    null;
						Cell healthReimbursementAccount =    null;
						Cell subTotalClaimsActivity 	=    null;
						Cell total 						=    null;
						for(int a=0;a<billingCategoryRow.getLastCellNum();a++){
							Cell bc = billingCategoryRow.getCell(a);
							if(getCellValue(bc).trim().replace("Billing Category ", "").contains(findbillingCategory)){
								billingCatIndex = bc.getColumnIndex();
								 billingCategory	    	= claimsActivitySummarySheet.getRow(rowno+2).getCell(billingCatIndex);
								 medical 					= claimsActivitySummarySheet.getRow(rowno+4).getCell(billingCatIndex);
								 costContainment	  	 	= claimsActivitySummarySheet.getRow(rowno+5).getCell(billingCatIndex);
								 interest			   	 	= claimsActivitySummarySheet.getRow(rowno+6).getCell(billingCatIndex);
								 dental 					= claimsActivitySummarySheet.getRow(rowno+7).getCell(billingCatIndex);
								 pharmacy			    	= claimsActivitySummarySheet.getRow(rowno+8).getCell(billingCatIndex);
								 blueCardAcessFees 			= claimsActivitySummarySheet.getRow(rowno+9).getCell(billingCatIndex);
								 stoplossAdvancedFunding 	= claimsActivitySummarySheet.getRow(rowno+10).getCell(billingCatIndex);
								 healthReimbursementAccount = claimsActivitySummarySheet.getRow(rowno+11).getCell(billingCatIndex);
								 subTotalClaimsActivity 	= claimsActivitySummarySheet.getRow(rowno+12).getCell(billingCatIndex);
								 
							}
							if(getCellValue(bc).trim().contains("Total")){
								totalIndex = bc.getColumnIndex();
								total 						= claimsActivitySummarySheet.getRow(rowno+12).getCell(totalIndex);
							}
						}
							
						claimsActivitySummary.setClaimPaymentPeriod(getCellValue(claimPaymentPeriod));
						claimsActivitySummary.setInvoiceDate(getCellValue(invoiceDate));
						claimsActivitySummary.setGroupName(getCellValue(groupName));
						claimsActivitySummary.setGroupBillingId(getCellValue(groupBillingId));
						claimsActivitySummary.setClaimsCycle(getCellValue(claimsCycle));
						claimsActivitySummary.setBillDueDate(getCellValue(billDueDate));
						claimsActivitySummary.setInvoiceNo(getCellValue(invoiceNo));
						String stringBillingCategory = getCellValue(billingCategory);
						claimsActivitySummary.setBillingCategory(stringBillingCategory.replace("Billing Category ", "").trim());
						claimsActivitySummary.setMedical("$"+getCellValue(medical));
						claimsActivitySummary.setCostContainment("$"+getCellValue(costContainment));
						claimsActivitySummary.setInterest("$"+getCellValue(interest));
						claimsActivitySummary.setDental("$"+getCellValue(dental));
						claimsActivitySummary.setPharmacy("$"+getCellValue(pharmacy));
						claimsActivitySummary.setBlueCardAccessFees("$"+getCellValue(blueCardAcessFees));
						claimsActivitySummary.setStopLossAdvancedFunding("$"+getCellValue(stoplossAdvancedFunding));
						claimsActivitySummary.setHealthReimbursementAccount("$"+getCellValue(healthReimbursementAccount));
						claimsActivitySummary.setSubTotalClaimsActivity("$"+getCellValue(subTotalClaimsActivity));
						claimsActivitySummary.setTotal("$"+getCellValue(total));
						claimsActivitySummaryExcelList.add(claimsActivitySummary);	
//						System.out.println("Excel Row   : "+claimsActivitySummary);
						
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			claimsActivitySummaryExcelMap.put(invoiceNO, claimsActivitySummaryExcelList);
		}
		return claimsActivitySummaryExcelMap;
	}
	
	public  Map<String,List<MemberDetails>> getMemberDetailsData(Map<String,List<MemberDetails>> memberDetailsDBMap) {
		memberDetailsExcelMap = new HashMap<String, List<MemberDetails>>();
		
		
		for (String invoiceNO : DatabaseUtil.memberDetailsInputSet) {
			List<MemberDetails> memberDetailsDBList = memberDetailsDBMap.get(invoiceNO);
			List<MemberDetails> memberDetailsExcelList = new ArrayList<MemberDetails>();
			
			try {
				
				Workbook workbook = WorkbookFactory.create(afaInvoiceReport);
				Sheet memberDetailsSheet = workbook.getSheet("Member Detail");

				for (int i = 1; i <= memberDetailsSheet.getLastRowNum(); i++) {
					Row row = memberDetailsSheet.getRow(i);
					Cell cell = row.getCell(2);
					String celldata = getCellValue(cell);
					int nextIndex = 0;
					if (celldata.contains(invoiceNO)) {
						int rowno = cell.getRowIndex();
					for(int j=0;j<memberDetailsDBList.size();j++){
						MemberDetails dbMember = memberDetailsDBList.get(j);
						MemberDetails memberDetails = new MemberDetails();
						
						String dbMemberGroupIDName = dbMember.getGroupIdName().trim();
						String dbMemberBC = dbMember.getBillingCategory().trim();
//						System.out.println(dbMemberBC+" DB");
						String dbMemberPlan = dbMember.getPlanId().trim();
						String dbMemberClass = dbMember.getClassId().trim();
						String dbMemberSSN = dbMember.getSsn().trim();
						
						Cell groupName = memberDetailsSheet.getRow(rowno-4).getCell(2);
						Cell groupBillingId = memberDetailsSheet.getRow(rowno-3).getCell(2);
						Cell claimsCycle = memberDetailsSheet.getRow(rowno-2).getCell(2);
						Cell billDueDate = memberDetailsSheet.getRow(rowno-1).getCell(2);
						Cell invoiceNo = memberDetailsSheet.getRow(rowno).getCell(2);
						
						String excelMemberGroupIDName1 = null;
						String excelMemberBC = null;
						String excelMemberPlan = null;
						for(int n=row.getRowNum();n<memberDetailsSheet.getLastRowNum();n++){
							
							Cell nextSection = memberDetailsSheet.getRow(n).getCell(0);
							if(getCellValue(nextSection).contains("GROUP NAME")){
								nextIndex = n;
								break;
							}
						}
						int findingRightRowIndex = 0;
						int bcPlanIndex = 0;
						for(int m=rowno;m<nextIndex;m++){
							String excelMemberGroupIDName= getCellValue(memberDetailsSheet.getRow(m).getCell(0)).replace("Group ID/Name:", "").trim();
							
							if(excelMemberGroupIDName.equalsIgnoreCase(dbMemberGroupIDName)){
								excelMemberGroupIDName1 = excelMemberGroupIDName;
								boolean factor1 = true;
								bcPlanIndex = m;
								while(factor1){
									 excelMemberBC = getCellValue(memberDetailsSheet.getRow(bcPlanIndex+1).getCell(0)).replace("Billing Category:", "").trim();
									 excelMemberPlan = getCellValue(memberDetailsSheet.getRow(bcPlanIndex+2).getCell(0)).replace("Plan:", "").trim();
									if(excelMemberBC.equalsIgnoreCase(dbMemberBC)&&excelMemberPlan.equalsIgnoreCase(dbMemberPlan)){
										factor1 = false;
										findingRightRowIndex = bcPlanIndex+3;
									}else{
										bcPlanIndex+=1;
									}
								}
									
								boolean factor = true;
								
								while(factor){
								String excelMemberClass = getCellValue(memberDetailsSheet.getRow(findingRightRowIndex).getCell(0)).trim();
								String excelMemberSSN = getCellValue(memberDetailsSheet.getRow(findingRightRowIndex).getCell(2)).trim();
								if(excelMemberClass.equalsIgnoreCase(dbMemberClass) && excelMemberSSN.equalsIgnoreCase(dbMemberSSN)){
									factor = false;
								}else{
									findingRightRowIndex+=1;
								}
							  }
							
					      }
						}
						Row requiredRow = memberDetailsSheet.getRow(findingRightRowIndex);
						String groupIdName	    = excelMemberGroupIDName1.trim();
						String billingCategory  = excelMemberBC;
						String planId	  	    = excelMemberPlan;
						String classId		    = getCellValue(requiredRow.getCell(0));
						String subscriberId     = getCellValue(requiredRow.getCell(1));
						String ssn			    = getCellValue(requiredRow.getCell(2));
						String subscriberName   = getCellValue(requiredRow.getCell(3));
						String patientName 	    = getCellValue(requiredRow.getCell(4));
						String relationship     = getCellValue(requiredRow.getCell(5));
						String dept 		    = getCellValue(requiredRow.getCell(6));
						String claimId 		    = getCellValue(requiredRow.getCell(7));
						String checkNumber 	    = getCellValue(requiredRow.getCell(8));
						DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
						
						String stringPaidDate 	= getCellValue(requiredRow.getCell(9));
						Date paidDate = (Date)formatter.parse(stringPaidDate);
						Calendar calPaidDate = Calendar.getInstance();
						calPaidDate.setTime(paidDate);
						
						int paidMM = calPaidDate.get(Calendar.MONTH) + 1;
						String paidMMStr ;
						if(paidMM<10){
							paidMMStr = "0"+paidMM;
						}else{
							paidMMStr = ""+paidMM;
						}
						
						int paidDD = calPaidDate.get(Calendar.MONTH) + 1;
						String paidDDStr ;
						if(paidDD<10){
							paidDDStr = "0"+paidDD;
						}else{
							paidDDStr = ""+paidDD;
						}
						String formatedPaidDate = paidMMStr + "/" + paidDDStr + "/" +         calPaidDate.get(Calendar.YEAR);
						
						String stringFromDate 	= getCellValue(requiredRow.getCell(10));
						Date fromDate = (Date)formatter.parse(stringFromDate);
						Calendar calFromDate = Calendar.getInstance();
						calPaidDate.setTime(fromDate);
						int fromMM = calFromDate.get(Calendar.MONTH) + 1;
						String fromMMStr ;
						if(fromMM<10){
							fromMMStr = "0"+fromMM;
						}else{
							fromMMStr = ""+fromMM;
						}
						
						int fromDD = calFromDate.get(Calendar.MONTH) + 1;
						String fromDDStr ;
						if(fromDD<10){
							fromDDStr = "0"+fromDD;
						}else{
							fromDDStr = ""+fromDD;
						}
						String formatedFromDate =  fromMMStr + "/" + fromDDStr + "/" +         calFromDate.get(Calendar.YEAR);
						
						String stringToDate 	= getCellValue(requiredRow.getCell(11));
						Date toDate = (Date)formatter.parse(stringToDate);
						Calendar calToDate = Calendar.getInstance();
						calPaidDate.setTime(toDate);
						
						int toMM = calToDate.get(Calendar.MONTH) + 1;
						String toMMStr ;
						if(toMM<10){
							toMMStr = "0"+toMM;
						}else{
							toMMStr = ""+toMM;
						}
						
						int toDD = calToDate.get(Calendar.MONTH) + 1;
						String toDDStr ;
						if(toDD<10){
							toDDStr = "0"+toDD;
						}else{
							toDDStr = ""+toDD;
						}
						String formatedToDate =  toMMStr + "/" + toDDStr + "/" +         calToDate.get(Calendar.YEAR);
						
						String payeeName 	    = getCellValue(requiredRow.getCell(12));
						String payeeId 		    = getCellValue(requiredRow.getCell(13));
						String coverage 	    = getCellValue(requiredRow.getCell(14));
						String deductible 	    = getCellValue(requiredRow.getCell(15));
						String coinsurance 	    = getCellValue(requiredRow.getCell(16));
						String copay 		    = getCellValue(requiredRow.getCell(17));
						String medical 		    = getCellValue(requiredRow.getCell(18));
						String costContainment  = getCellValue(requiredRow.getCell(19));
						String interest 		= getCellValue(requiredRow.getCell(20));	
						String dental 			= getCellValue(requiredRow.getCell(21));	
						String pharmacy 		= getCellValue(requiredRow.getCell(22));	
						String bluecard 		= getCellValue(requiredRow.getCell(23));	
						String stoploss 		= getCellValue(requiredRow.getCell(24));	
						String hra 				= getCellValue(requiredRow.getCell(25));	
						String totalPaid 		= getCellValue(requiredRow.getCell(26));	
						
						memberDetails.setGroupName(getCellValue(groupName).trim());
						memberDetails.setGroupBillingId(getCellValue(groupBillingId).trim());
						memberDetails.setClaimsCycle(getCellValue(claimsCycle).trim());
						memberDetails.setBillDueDate(getCellValue(billDueDate).trim());
						memberDetails.setInvoiceNo(getCellValue(invoiceNo).trim());
						memberDetails.setGroupIdName(groupIdName);
						memberDetails.setBillingCategory(billingCategory);
						memberDetails.setPlanId(planId);
						memberDetails.setClassId(classId);
						memberDetails.setSubscriberId(subscriberId);
						memberDetails.setSsn(ssn);
						memberDetails.setSubscriberName(subscriberName);
						memberDetails.setPatientName(patientName);
						memberDetails.setRelationship(relationship );
						memberDetails.setDept(dept);
						memberDetails.setClaimId(claimId);
						memberDetails.setCheckNumber(new BigDecimal(checkNumber).setScale(0,BigDecimal.ROUND_DOWN));
						memberDetails.setPaidDate(formatedPaidDate);
						memberDetails.setFromDate(formatedFromDate);
						memberDetails.setToDate(formatedToDate);
						memberDetails.setPayeeName(payeeName);
						memberDetails.setPayeeId(payeeId);
						memberDetails.setCoverage(coverage);
						memberDetails.setDeductible("$"+deductible);
						memberDetails.setCoinsurance("$"+coinsurance);
						memberDetails.setCopay("$"+copay);
						memberDetails.setMedical("$"+medical);
						memberDetails.setCostContainment("$"+costContainment);
						memberDetails.setInterest("$"+interest);
						memberDetails.setDental("$"+dental);
						memberDetails.setPharmacy("$"+pharmacy);
						memberDetails.setBluecard("$"+bluecard);
						memberDetails.setStoploss("$"+stoploss);
						memberDetails.setHra("$"+hra);
						memberDetails.setTotalPaid("$"+totalPaid);
						
						memberDetailsExcelList.add(memberDetails);	
//						System.out.println("Excel Row   : "+memberDetails);
						
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			memberDetailsExcelMap.put(invoiceNO, memberDetailsExcelList);
		}
		return memberDetailsExcelMap;
	}
	
	public  Map<String,List<PlanDetails>> getPlanDetailsData(Map<String,List<PlanDetails>> planDetailsDBMap) {
		planDetailsExcelMap = new HashMap<String, List<PlanDetails>>();
		
		String plan = null;
		Map<String, PlanDetails> resultingPlansMap = new HashMap<String, PlanDetails>();
		
		for (String invoiceNO : DatabaseUtil.planDetailsInputSet) {
			List<PlanDetails> planDetailsDBList = planDetailsDBMap.get(invoiceNO);
			List<PlanDetails> planDetailsExcelList = new ArrayList<PlanDetails>();
			
			try {
				
				Workbook workbook = WorkbookFactory.create(afaInvoiceReport);
				Sheet planDetailsSheet = workbook.getSheet("Plan Detail");

				for (int i = 1; i <= planDetailsSheet.getLastRowNum(); i++) {
					Row row = planDetailsSheet.getRow(i);
					Cell cell = row.getCell(1);
					String celldata = getCellValue(cell);
					int nextIndex = 0;
					if (celldata.contains(invoiceNO)) {
						int rowno = cell.getRowIndex();
						
					for(int j=0;j<planDetailsDBList.size();j++){
						PlanDetails dbPlan = planDetailsDBList.get(j);
						PlanDetails planDetails = new PlanDetails();
						
						String dbPlanGroupIDName = dbPlan.getGroupIdName().trim();
						String dbPlanBC = dbPlan.getCbc().trim();
						
						Cell groupName = planDetailsSheet.getRow(rowno-4).getCell(1);
						Cell groupBillingId = planDetailsSheet.getRow(rowno-3).getCell(1);
						Cell claimsCycle = planDetailsSheet.getRow(rowno-2).getCell(1);
						Cell billDueDate = planDetailsSheet.getRow(rowno-1).getCell(1);
						Cell invoiceNo = planDetailsSheet.getRow(rowno).getCell(1);
						
						String excelPlanGroupIDName1 = null;
						String excelPlanBC = null;
						String PLANDETAILSTOTALS =  null;
						for(int n=row.getRowNum();n<planDetailsSheet.getLastRowNum();n++){
							
							Cell nextSection = planDetailsSheet.getRow(n).getCell(0);
							if(getCellValue(nextSection).contains("GROUP NAME")){
								nextIndex = n;
//								System.out.println("Next Index:"+nextIndex);
								break;
							}
						}
						int findingRightRowIndex = 0;
						int bcPlanIndex = 0;
						for(int m=rowno;m<nextIndex;m++){
							String excelPlanGroupIDName= getCellValue(planDetailsSheet.getRow(m).getCell(0)).replace("Group ID/Name:", "").trim();
							if(excelPlanGroupIDName.equalsIgnoreCase(dbPlan.getGroupIdName().trim())){
								excelPlanGroupIDName1 = excelPlanGroupIDName;
								boolean factor1 = true;
								bcPlanIndex = m;
								while(factor1){
									 excelPlanBC = getCellValue(planDetailsSheet.getRow(bcPlanIndex+1).getCell(0)).replace("Billing Category:", "").trim();
									if(excelPlanBC.equalsIgnoreCase(dbPlan.getCbc().trim())){
										factor1 = false;
										findingRightRowIndex = bcPlanIndex+2;
//										System.out.println("Finding right index : "+findingRightRowIndex);
									}else{
										bcPlanIndex+=1;
									}
								}
									
								boolean factor = true;
								
								while(factor){
								String excelPlanDetailsTotals = getCellValue(planDetailsSheet.getRow(findingRightRowIndex).getCell(0)).trim();
								if(excelPlanDetailsTotals.equalsIgnoreCase(dbPlan.getPlanDetailsTotals().trim())){
//									System.out.println("Finding right index:"+findingRightRowIndex);
									PLANDETAILSTOTALS = excelPlanDetailsTotals;  
									factor = false;
								}else{
									findingRightRowIndex+=1;
								}
							  }
							
					      }
						}
						
						Row requiredRow = planDetailsSheet.getRow(findingRightRowIndex);
						
						String groupIdName	    = excelPlanGroupIDName1.trim();
						String billingCategory  = excelPlanBC;

						String PLN = "";
						if(getCellValue(requiredRow.getCell(0)).contains("Subtotal for Plan:")){
						 PLN	    = getCellValue(requiredRow.getCell(0)).replace("Subtotal for Plan:", "").trim();
						 plan = PLN;
						}
						String GRPID 		    = groupIdName.trim().substring(0, 8);
						String MEDICAL 	    = getCellValue(requiredRow.getCell(2));
						String COSTCONTAINMENT 		    = getCellValue(requiredRow.getCell(3));
						String INTEREST 		    = getCellValue(requiredRow.getCell(4));
						String DENTAL  = getCellValue(requiredRow.getCell(5));
						String PHARMACY 		= getCellValue(requiredRow.getCell(6));	
						String STOPLOSS 			= getCellValue(requiredRow.getCell(7));	
						String BLUECARD 		= getCellValue(requiredRow.getCell(8));	
						String HRA 		= getCellValue(requiredRow.getCell(9));	
						String TOTALPAID 		= getCellValue(requiredRow.getCell(10));	
						planDetails.setGroupName(getCellValue(groupName).trim());
						planDetails.setAfaId(getCellValue(groupBillingId));
						planDetails.setClaimsCycle(getCellValue(claimsCycle));
						planDetails.setBillDueDate(getCellValue(billDueDate));
						planDetails.setInvoiceNo(getCellValue(invoiceNo));
						planDetails.setGroupIdName(groupIdName);
						planDetails.setCoverage("HEALTH");
						planDetails.setCbc(billingCategory);
						planDetails.setPlanDetailsTotals(PLANDETAILSTOTALS);
						planDetails.setPln(PLN);
						planDetails.setGrpId(PLN);
						planDetails.setMedical("$"+MEDICAL);
						planDetails.setCostContainment("$"+COSTCONTAINMENT);
						planDetails.setInterest("$"+INTEREST);
						planDetails.setDental("$"+DENTAL);
						planDetails.setPharmacy("$"+PHARMACY);
						planDetails.setStoploss("$"+STOPLOSS);
						planDetails.setBluecard("$"+BLUECARD);
						planDetails.setHra("$"+HRA);
						planDetails.setGrpId(GRPID);
						planDetails.setTotalPaid("$"+TOTALPAID);
						planDetails.setSortOrder1(new BigDecimal("0"));
						planDetails.setSortOrder2(new BigDecimal("0"));
						
						planDetailsExcelList.add(planDetails);	
						
						
						}
					}
				}
				for(PlanDetails planDetails : planDetailsExcelList){
					planDetails.setPln(plan);
//					System.out.println("Excel Row   : "+planDetails);
					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			planDetailsExcelMap.put(invoiceNO, planDetailsExcelList);
		}
		return planDetailsExcelMap;
	}
	
}
