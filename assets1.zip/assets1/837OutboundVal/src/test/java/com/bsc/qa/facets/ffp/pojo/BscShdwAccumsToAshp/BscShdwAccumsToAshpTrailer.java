package com.bsc.qa.facets.ffp.pojo.BscShdwAccumsToAshp;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;// <== Mandatory 

@PositionalRecord(ignorePositionNotFound=true) // <== Mandatory 

public class BscShdwAccumsToAshpTrailer {
	
	private String Record_Type;
	private String  Filler_Unused1;
	private String  Total_Records_On_File;
	private String  Total_Dollar_Amount;
	private String  Filler_Unused2;
	/**
	 * @return the record_Type
	 */
	public String getRecord_Type() {
		return Record_Type;
	}
	/**
	 * @param record_Type the record_Type to set
	 */
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	/**
	 * @return the filler_Unused1
	 */
	public String getFiller_Unused1() {
		return Filler_Unused1;
	}
	/**
	 * @param filler_Unused1 the filler_Unused1 to set
	 */
	public void setFiller_Unused1(String filler_Unused1) {
		Filler_Unused1 = filler_Unused1;
	}
	/**
	 * @return the total_Records_On_File
	 */
	public String getTotal_Records_On_File() {
		return Total_Records_On_File;
	}
	/**
	 * @param total_Records_On_File the total_Records_On_File to set
	 */
	public void setTotal_Records_On_File(String total_Records_On_File) {
		Total_Records_On_File = total_Records_On_File;
	}
	/**
	 * @return the total_Dollar_Amount
	 */
	public String getTotal_Dollar_Amount() {
		return Total_Dollar_Amount;
	}
	/**
	 * @param total_Dollar_Amount the total_Dollar_Amount to set
	 */
	public void setTotal_Dollar_Amount(String total_Dollar_Amount) {
		Total_Dollar_Amount = total_Dollar_Amount;
	}
	/**
	 * @return the filler_Unused2
	 */
	public String getFiller_Unused2() {
		return Filler_Unused2;
	}
	/**
	 * @param filler_Unused2 the filler_Unused2 to set
	 */
	public void setFiller_Unused2(String filler_Unused2) {
		Filler_Unused2 = filler_Unused2;
	}
	
}
