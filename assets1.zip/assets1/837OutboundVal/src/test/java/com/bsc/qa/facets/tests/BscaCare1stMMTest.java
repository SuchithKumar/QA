package com.bsc.qa.facets.tests;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.Element;

import org.apache.commons.io.FileUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileHeader;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileTrailer;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.readers.BscAccumsToOptumRxReader;
import com.bsc.qa.facets.ffpojo.readers.BscaCare1stMMFlatFileReader;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelFunctions;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable{
	//private static String strSubscriber_ID;  
    //final private static String strUniqueIdentifier1 = "SUBSCRIBER_ID"; // <= first 
    //final private static String strUniqueIdentifier2 = "RELATIONSHIP_CODE"; // <= second
    private static BscaCare1stMMFlatFileReader ffpExtract;
    private static String filePath;
    private static String sheetName,SUCName;
	private static DBUtils objDBUtility;//Mandatory declaration 
	public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
	private static Path path;
	private static Path inputDataPath;
	private static String resultsDestinationFolderPath,rootLocationOfInputFiles;
	private static String resultsSourceFolderPath;
    private static int bodyRowsCount;
	private static List<Map<String, String>> testHeader;
	private static List<Map<String, String>> testBody;
	private static List<Map<String, String>> testTrailer;
	private static Map<String, String> flatFileValuesMap=new HashMap<String,String>();
	//private static Map<String,String>sqlQueryValuesMap;
	private static	Map<String,String>queryDataMap=new HashMap<String,String>();
	private static	List<Map<String,String>>listOfRecords=new ArrayList<Map<String,String>>();
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles", "ResultsDestinationFolderPath"}) //Note parrams order
	//public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
		public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles,String ResultsDestinationFolderPath){	//Args order matters should match to params order		
		 path = Paths.get("\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\SUC automation\\Results\\"+timestamp);
		
		 if(!Files.exists(path))
		{
		try {
			Files.createDirectories(path);
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
		
		
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		filePath=TestDataSheetLocation;
		sheetName=NameOfTestDataSheet;
		rootLocationOfInputFiles=RootLocationOfFlatFiles;
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		//Below step is for setting up the path of the input file
		// TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
			//Below step is for getting complete path of the input file		 
		 
		 //filePAth = tesFile.getCompleteTestFilePath();	 
		
	}

	//************************************** TEST METHODS************************
	
	@Test(dataProvider = "masterDataProvider")
	private static void File_Header_Body_Trailer_Validation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();
		String SQLQuery = data.get("SqlQuery").toString();
		SUCName=data.get("SUC Name").toString();
		String inputFileName=data.get("Input File Name").toString();
		
		ffpExtract = new BscaCare1stMMFlatFileReader(inputFileName);//this will set up the FileReader of ffpojo library
		//Parse headers,Body and trailers and store in to testHeaders,testBody and testTrailer
				try {
					testHeader = ffpExtract.getListOfHeaderValues();
					testBody = ffpExtract.getListOfBodyValues();
					testTrailer = ffpExtract.getListOfTrailerValues();
					bodyRowsCount = testBody.size(); 
					listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
				/*Below will be replaced with one mapVariable having all the keys and values for validation*/
					for(Map.Entry<String,String> map:testHeader.get(0).entrySet()){//this for loop will add all the Header field values in to dictionary
						flatFileValuesMap.put(map.getKey(), map.getValue());
					}
					for(Map.Entry<String,String> map:testBody.get(0).entrySet()){//this for loop will add all the Body field values in to dictionary
						flatFileValuesMap.put(map.getKey(), map.getValue());
					}
					for(Map.Entry<String,String> map:testTrailer.get(0).entrySet()){//this for loop will add all the Trailer field values in to dictionary
						flatFileValuesMap.put(map.getKey(), map.getValue());
					}
					if(listOfRecords.size()>1){//check for more than one record
						 System.out.println("Test Case Failed");
						 softAssertion.assertTrue(listOfRecords.size()>1||listOfRecords.size()<1, "More Than one records ar" );
					}else if(listOfRecords.size()<1){//check for less than one record
						softAssertion.assertTrue(listOfRecords.size()<1, "Less than one record is present" );
					}
					else{
				//Below is the main test case field to field validation 
					queryDataMap=listOfRecords.get(0);
					OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
						}
	     
			
			} catch (Exception e) {
				System.out.println("Test Case Failed due to Exception.....!!");
				softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!" +e.getMessage());
				e.printStackTrace();
			}finally{
				softAssertion.assertAll();	//<== absolutely must be here
			}
				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void File_Content_Validation(Map<String, String> data) {
		 SoftAssert softAssertion= new SoftAssert();
		 List<Map<String , String>> listOfHeadersMap  = new ArrayList<Map<String,String>>();
	     List<Map<String , String>> listOfBodyMap  = new ArrayList<Map<String,String>>();
	     List<Map<String , String>> listOfTrailerMap  = new ArrayList<Map<String,String>>();
 		 Map<String,List<Object>> recordsMap=new HashMap<String,List<Object>>();
 		logger.log(LogStatus.INFO,"Starting test File_Content_Validation");
  //***********************************************************************************************
    //************************** Retrieving Sql Query Data *******************************
 		try{
 		String SQLQuery = data.get("SqlQuery").toString();
 		 SUCName = data.get("SUC Name").toString();
			listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
		
 		
		String inputFileName=data.get("Input File Name").toString();
		ffpExtract = new BscaCare1stMMFlatFileReader(inputFileName);//this will set up the FileReader of ffpojo library
		
			
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody.class);   // <== BODY
			ffDefinition.setHeader(BscaCare1stMMFlatFileHeader.class);
			ffDefinition.setTrailer(BscaCare1stMMFlatFileTrailer.class);
			recordsMap=ffpExtract.getFlatFileData(ffDefinition);
			
			/*for(Object record:recordsMap.get("Header")){
				BscaCare1stMMFlatFileHeader header = (BscaCare1stMMFlatFileHeader)record;
				Map<String,String> headersMap=new HashMap<String,String>();
				//headersMap.put("Record_Type_Header", header.getRecord_Type_Header()); //<== Add 
			//	headersMap.put("Contract_Number_Header", header.getContract_Number_Header()); //<== Add 
				headersMap.put("Payment_Date", header.getPayment_Date());
				listOfHeadersMap.add(headersMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
			}*/
			for(Object record:recordsMap.get("Body")){
				BscaCare1stMMFlatFileBody body = (BscaCare1stMMFlatFileBody)record;
				Map<String,String> bodyMap=new HashMap<String,String>();
				//bodyMap.put("Record_Type_Body", body.getRecord_Type_Body()); //<== Add 
				bodyMap.put("CONTR_NBR_TXT", body.getContract_Number_Body()); //<== Add 
				bodyMap.put("PBP_CD", body.getPBP_Number()); //<== Add 
				bodyMap.put("HICN", body.getHIC_Number()); //<== Add 
				bodyMap.put("PREM_ADJ_STRT_DT", body.getPremium_Adjustment_Period_Start_Date()); //<== Add 
				bodyMap.put("PREM_ADJ_END_DT", body.getPremium_Adjustment_Period_End_Date()); //<== Add 
				bodyMap.put("UNCOV_MO_TXT", body.getNumber_of_Months_in_Premium_Adjustment_Period()); //<== Add 
				bodyMap.put("LEP_AMT", body.getLEP_Amount()); //<== Add 
				listOfBodyMap.add(bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
			}
			/*for(Object record:recordsMap.get("Trailer")){
				BscaCare1stMMFlatFileTrailer trailer = (BscaCare1stMMFlatFileTrailer)record;
				Map<String,String> trailerMap=new HashMap<String,String>();
				trailerMap.put("Record_Type_Trailer", trailer.getRecord_Type_Trailer()); //<== Add 
				listOfTrailerMap.add(trailerMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
			}*/
			//******************* below is the code for field to field validation*************
			if(listOfRecords.size()>1){//check for more than one record
				 System.out.println("Test Case Failed");
				 softAssertion.assertTrue(listOfRecords.size()>1||listOfRecords.size()<1, "More Than one records ar" );
			}else if(listOfRecords.size()<1){//check for less than one record
				softAssertion.assertTrue(listOfRecords.size()<1, "Less than one record is present" );
			}
				else{
			//Below is the main test case field to field validation 
				queryDataMap=listOfRecords.get(0);//First element of list
				OtherUtilities.validate(listOfBodyMap.get(0),queryDataMap,softAssertion);
				
			}
			
 		} catch (Exception e) {
			System.out.println("Test Case Failed due to Exception.....!!");
			softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
			e.printStackTrace();
		}finally{
		softAssertion.assertAll();	//<== absolutely must be here
		}
		
	}
	@Test(dataProvider = "masterDataProvider")
	private static void InboundAndOutboundValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			String inputFileName=data.get("Input File Name").toString();
			List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithDelimeter(inputFileName);
			String primaryKeyColumnName="CONFIRMATIONNUMBER";
			String parameter1= data.get("Query parameter1").toString();
			
			Map<String,String>sourceRowMap=TestFileUtil.getRowMap(primaryKeyColumnName,parameter1,rowsList);
			System.out.println("source Map for the given Primary Key"+sourceRowMap);
			String queryFromDataSheet = data.get("SqlQuery").toString();
			String	SQLQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim());
		
			listOfRecords = objDBUtility.resultSetToDictionary(SQLQuery);//queryDataMap
			queryDataMap=listOfRecords.get(0);//First element of list
			System.out.println("Source Map:"+sourceRowMap);
			System.out.println("_______________________________________________");
			System.out.println("Query Dat map: "+queryDataMap);
			OtherUtilities.validate(sourceRowMap,queryDataMap,softAssertion);
			 } catch (Exception e) {
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					softAssertion.assertAll();	//<== absolutely must be here
				}
				
	}
	


//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{
		//Map<String, String> dataMap = new HashMap<String, String>();
		//dataMap = ExcelUtils.getTestMethodData(method.getName());
		//data = new Object[][] { { dataMap },{ dataMap } };
		//  Object[][] testObjArray = ExcelFunctions.getTableArray("src//test//resources//TestData.xlsx","BSCA_Care1st_MM_Test");
		//	      return (testObjArray);
		
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, sheetName);
		  Object[][] testDataArray= 	  ExcelUtils.getTableArray(filePath, sheetName);
		  List<Object> list=new ArrayList<Object>();
		  
		  int noOfTestCases=0;
		 String runMode="Y";
		  for(int row=0;row<=testDataArray.length-1;row++){
			  
			if(method.getName().equalsIgnoreCase(testDataArray[row][2].toString())&& runMode.equalsIgnoreCase(testDataArray[row][9].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++){
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);
				//data[row][0]=rowDataMap;
				
			}
		}
		  
		  Object[][] data = new Object[noOfTestCases][1];
		  for(int row=0;row<list.size();row++){
			  data[row][0]=list.get(row);
		  }
		//data = new Object[][] { { list.get(0) },{ list.get(1) },{ list.get(2) }  };
		//System.out.println("Balu data:"+data[2][0]);
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		ReportFactory.closeReport();
	}
	
	@AfterMethod
	public void afterMethod() throws IOException{
		inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		File srcDir = new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		
		Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
	}
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
			try {
	//-----		Path htmlReportSourcePath=Paths.get(resultsSourceFolderPath+"//test-output//emailable-report.html");//storing report source path in htmlReportSourcePath 
	//-----		Path htmlReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\emailable-report.html");//storing report source path in htmlReportDestinationPath
			
			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
	//-----			TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files
			
			
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	  }
	
}
