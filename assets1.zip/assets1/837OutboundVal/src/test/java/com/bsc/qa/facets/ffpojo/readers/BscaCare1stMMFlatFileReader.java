package com.bsc.qa.facets.ffpojo.readers;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileHeader;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileTrailer;
import com.github.ffpojo.exception.FFPojoException;
import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.file.reader.RecordType;

public class BscaCare1stMMFlatFileReader {
	
	String testFlatFileCompletePath; // <== Path to a test file  
	
	public BscaCare1stMMFlatFileReader(String testFlatFileCompletePath) {//Constructor for Reader class
		this.testFlatFileCompletePath = testFlatFileCompletePath;
	} 

	//************************* method for FLAT FILE FIELDS MAP *************************//
	public Map<String,List<Object>> getFlatFileData(FlatFileReaderDefinition ffDefinition) throws IOException{
		List<Object> headerRowsList=new ArrayList<Object>();//list for header rows
		List<Object> bodyRowsList=new ArrayList<Object>();//list for body rows
		List<Object> trailerRowsList=new ArrayList<Object>();//list for trailer rows
		Map<String,List<Object>> recordsMap=new HashMap<String,List<Object>>();
        File inputFile = new File(testFlatFileCompletePath);
		if (!inputFile.exists()) { 
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
		} else { 
			//invoking the FlatFile Reader proving parameters
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
			
			//List<Object> list=Arrays.asList(ffReader);
			for (Object record :ffReader ) {//Iterating through the reader object and adding the records in list 
					
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.HEADER) { //<=== Headers field values
					
					headerRowsList.add(record);
				}
				if (recordType == RecordType.BODY) {	//<=== Body field values
					
					bodyRowsList.add(record);
				}
				if(recordType == RecordType.TRAILER){	//<=== Trailer field values
					
					trailerRowsList.add(record);
				}
					
			}
			ffReader.close();							//Closing ffReader 
			recordsMap.put("Header", headerRowsList); 	//putting the headerRowsList,trailer and body rows lists in to map
			recordsMap.put("Body", bodyRowsList);
			recordsMap.put("Trailer", trailerRowsList);
					
		}
				
		return recordsMap; // method return value 
						
	} // <==  public List<Map<String, String>> getListOfHeaderValues(){
	
	
	
	////////////////////////////////FLAT FILE HEADER TO LIST////////////////////
	public List<Map<String, String>> getListOfHeaderValues() throws IOException{
						
		List<Map<String , String>> headersList  = new ArrayList<Map<String,String>>();
		
        File inputFile = new File(testFlatFileCompletePath);
        /*FileReader fileReader = 
                new FileReader(testFlatFileCompletePath);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);
			String line=null;
            while((line = bufferedReader.readLine()) != null) {
                System.out.println("Flat File content:::::::::::"+line);
            }   
*/
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { // if (!inputFile.exists()) { 
			
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody.class);   // <== BODY
			ffDefinition.setHeader(BscaCare1stMMFlatFileHeader.class);
			ffDefinition.setTrailer(BscaCare1stMMFlatFileTrailer.class);
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
			
			int key=0;
		//List<Object> list=Arrays.asList(ffReader);
		
				for (Object record :ffReader ) {
					
					
				RecordType recordType = ffReader.getRecordType();
				if (recordType == RecordType.HEADER) { //<=== Headers 
					Map<String,String> headersMap = new HashMap<String, String>();
					
					//System.out.println("HEADER FOUND: ");
					
					BscaCare1stMMFlatFileHeader header = (BscaCare1stMMFlatFileHeader)record;
					
					
					headersMap.put("Record_Type_Header", header.getRecord_Type_Header()); //<== Add 
					headersMap.put("Contract_Number_Header", header.getContract_Number_Header()); //<== Add 
					headersMap.put("Payment_Date", header.getPayment_Date()); //<== Add 
				
					
					headersList.add(key,headersMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
				    	
					key++;
				    		//System.out.println("Header Map::"+headersMap);
				} //if (recordType == RecordType.HEADER)
				
				/*if(recordType == RecordType.BODY){
					System.out.println("-------------Body values are present----------");
					
		   	      }
				if(recordType == RecordType.TRAILER){
					System.out.println("-------------Trailer values are present----------");
		   	      }else{
		   	    	  System.out.println("I'm in else loop");
		   	      }*/
				
			} // <== for (Object record : ffReader) {
			ffReader.close(); //Close Object 
		} // if (!inputFile.exists()) { 
	
		return headersList; // method return value 
						
	} // <==  public List<Map<String, String>> getListOfHeaderValues(){
	
	
	////////////////////////////////FLAT FILE BODY TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfBodyValues() throws IOException{
				
		List<Map<String , String>> bodyList  = new ArrayList<Map<String,String>>();
		// get file 
        File inputFile = new File(testFlatFileCompletePath);
    	//test if file exist 
		if (!inputFile.exists()) { 
			//cry if file does not exist 
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { //if (!inputFile.exists()) { 
			// do the magic if file exists 
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody.class);   // <== BODY
			ffDefinition.setHeader(BscaCare1stMMFlatFileHeader.class);
			ffDefinition.setTrailer(BscaCare1stMMFlatFileTrailer.class);
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		    int counter = 0;
		  //  List<Object> list=Arrays.asList(ffReader);
			for (Object record : ffReader) {
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.BODY) { //<=== BODY 
					
					Map<String,String> bodyMap = new HashMap<String, String>(); //<== NEW HASH MAP ON EVERY LOOP 
					
					BscaCare1stMMFlatFileBody body = (BscaCare1stMMFlatFileBody)record;
					
					bodyMap.put("Record_Type_Body", body.getRecord_Type_Body()); //<== Add 
					bodyMap.put("Contract_Number_Body", body.getContract_Number_Body()); //<== Add 
					bodyMap.put("PBP_Number", body.getPBP_Number()); //<== Add 
					bodyMap.put("HIC_Number", body.getHIC_Number()); //<== Add 
					bodyMap.put("Premium_Adjustment_Period_Start_Date", body.getPremium_Adjustment_Period_Start_Date()); //<== Add 
					bodyMap.put("Premium_Adjustment_Period_End_Date", body.getPremium_Adjustment_Period_End_Date()); //<== Add 
					bodyMap.put("Number_of_Months_in_Premium_Adjustment_Period", body.getNumber_of_Months_in_Premium_Adjustment_Period()); //<== Add 
					bodyMap.put("LEP_Amount", body.getLEP_Amount()); //<== Add 

					bodyList.add(counter,bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
					
					counter++;
					
				    			
				}			
				else if(recordType == RecordType.HEADER){
		   	      }
				else if(recordType == RecordType.TRAILER){
		   	      }else{
		   	    	  System.out.println("Im in else of Body Values");
		   	      }
			 } // <== for (Object record : ffReader) {
			
			ffReader.close(); //Close Object 	
		} // if (!inputFile.exists()) { 
		
		return bodyList; // method return value 
	
	} // <==  public List<Map<String, String>> getListOfBodyValues(){
	
	
	////////////////////////////////FLAT TRAILER VALUES TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfTrailerValues() throws IOException{
	//return list map 	
    List<Map<String , String>> trailerList  = new ArrayList<Map<String,String>>();

    File inputFile = new File(testFlatFileCompletePath); // <== Import of file under test 

    if (!inputFile.exists()) { 
	
	   throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	
    } else { // if (!inputFile.exists()) {
    	
    	FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody.class);   // <== BODY
        ffDefinition.setHeader(BscaCare1stMMFlatFileHeader.class);  ffDefinition.setTrailer(BscaCare1stMMFlatFileTrailer.class);

        FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
      //  List<Object> list=Arrays.asList(ffReader);
        for (Object record : ffReader) {
   	      RecordType recordType = ffReader.getRecordType();
   	
   	      if (recordType == RecordType.TRAILER) { //<=== TRAILER 
   		
   		    Map<String,String> TrailerMap = new HashMap<String, String>();
   		
   		   // System.out.println("Trailer FOUND: ");
   		
   		 BscaCare1stMMFlatFileTrailer trailer = (BscaCare1stMMFlatFileTrailer)record;
   	
   		    TrailerMap.put("Record_Type_Trailer", trailer.getRecord_Type_Trailer()); //<== Add 
   		 
   		 
   						
   		    trailerList.add(0,TrailerMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
   	    			
   	      }else if(recordType == RecordType.BODY){
   	      }
		else if(recordType == RecordType.HEADER){
   	      }
        } // <== for (Object record : ffReader) {
        
    ffReader.close(); //Close Object 
    
    } //if (!inputFile.exists()) {

     return trailerList; // method return value 
		
	}	// <== public List<Map<String, String>> getListOfTrailerValues(){
	
	
	
//SAMPLE to READ ALL in ONE METHOD NOT USED BY TEST < GOOD FOR DEBUGGING
public void readExtracts() throws IOException, FFPojoException {
		
		File inputFile = new File(testFlatFileCompletePath);
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		}
		
		
		FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody.class);   // <== BODY
		ffDefinition.setHeader(BscaCare1stMMFlatFileHeader.class); ffDefinition.setTrailer(BscaCare1stMMFlatFileTrailer.class);
		
		FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
	
		for (Object record : ffReader) {
			
			RecordType recordType = ffReader.getRecordType();
			
			if (recordType == RecordType.HEADER) { //<=== Headers 
				
				System.out.print("HEADER FOUND: " + record.hashCode());
				//BscAccumsToCvsHeader header = (BscAccumsToCvsHeader)record;
				//System.out.println(header.getHEADER_INDICATOR());
			
			} else if (recordType == RecordType.BODY) {
				
				//BscAccumsToDBPSHDWBody cust = (BscAccumsToDBPSHDWBody)record;
				//System.out.println(cust.getMEMBER_FIRST_NAME()+ " " + cust.getMEMBER_LAST_NAME());
			
			} else if (recordType == RecordType.TRAILER) {
				
				//System.out.println("TRAILER FOUND: ");
				//BscAccumsToCvsTrailer trailer = (BscAccumsToNavitusTrailer)record;
				//System.out.println(trailer.getTOTAL_AMOUNT());
			}
		
		
		}
		
		ffReader.close();

	}
	
}
