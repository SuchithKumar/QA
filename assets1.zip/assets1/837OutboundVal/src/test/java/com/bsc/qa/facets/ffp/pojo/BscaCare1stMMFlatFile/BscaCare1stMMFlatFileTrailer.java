package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileTrailer {

private String Record_Type_Trailer;

	
	
	
public String getRecord_Type_Trailer() {
	return Record_Type_Trailer;
}

public void setRecord_Type_Trailer(String record_Type_Trailer) {
	Record_Type_Trailer = record_Type_Trailer;
}






}
