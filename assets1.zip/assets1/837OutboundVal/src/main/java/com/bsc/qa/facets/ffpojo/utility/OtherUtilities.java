package com.bsc.qa.facets.ffpojo.utility;

import java.util.Map;

import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

public class OtherUtilities extends BaseTest{
	
	public static void validate(Map<String, String> flatFileValuesMap,	Map<String, String> queryDataMap,SoftAssert softAssertion) {
		//SoftAssert softAssertion= new SoftAssert();
		for(String key:queryDataMap.keySet()){
			if(flatFileValuesMap.containsKey(key)){
				OtherUtilities.validateActualAndExpectedValues(key,flatFileValuesMap.get(key),queryDataMap.get(key),softAssertion);
			  System.out.println("Acctual Value: " + flatFileValuesMap.get(key) + "Expected Value: " + queryDataMap.get(key));
			}else{
				 softAssertion.assertTrue(flatFileValuesMap.containsKey(key), "Element " + key + " is ot present" );
				//softAssertion.assertEquals(null,queryDataMap.get(key).toString().trim(),"<<" + key + ">> " );
				 logger.log(LogStatus.INFO, key+" is not present Input File");
			}
			
		}
		
		
	}

	private static void validateActualAndExpectedValues(String key,String flatFileValue,String dbValue,SoftAssert softAssertion) {
		if(key.equalsIgnoreCase("APPLICANTBIRTHDATE")){
			
				softAssertion.assertTrue(flatFileValue.contains(dbValue.substring(0, 4)), "Element " + key + " is ot present" );
				logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
		}else{
				if(dbValue==null){
					dbValue="";
				}
		  softAssertion.assertEquals(flatFileValue,dbValue, "<<" + key + ">> " );
			logger.log(LogStatus.INFO," Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
		}
		
	}
	
	
	

}
