package com.bsc.qa.facets.ffpojo.utility;

/**
 * Serhiy Malyy 
 * Class allows to locate most recent file in folder by last date/time modified
 * It enables file-based test to run and select files under test from folder and eliminates the need to hardcode file name
 * 
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestFileUtil {

	String FlatFileRootDirectory;
	String InterfaceSpecoficFolder; 
	
	
	public TestFileUtil(String flatFileRootDirectory,String interfaceSpecoficFolder) {
		
		FlatFileRootDirectory = flatFileRootDirectory;
		InterfaceSpecoficFolder = interfaceSpecoficFolder;
	}

	public static File lastFileModified(String dir) {
	    File fl = new File(dir);
	    File[] files = fl.listFiles(new FileFilter() {          
	        public boolean accept(File file) {
	            return file.isFile();
	        }
	    });
	    long lastMod = Long.MIN_VALUE;
	    File choice = null;
	    for (File file : files) {
	        if (file.lastModified() > lastMod) {
	            choice = file;
	            lastMod = file.lastModified();
	        }
	    }
	    return choice; //lastFileModified
	}
	
	public File getTestFile(){
		
		String completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		
		System.out.println("Test file root directory is:" + FlatFileRootDirectory);
		System.out.println("Test file spefic directory is:" + InterfaceSpecoficFolder);
		
		File objFile = lastFileModified (completePath);
		
		return objFile;
	
	}
	
	public String getCompleteTestFilePath(){
		
		String completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		
		System.out.println("Complete path to test file is:"+ completePath);
		
		File objFile = lastFileModified (completePath);
		
		String obsPath = objFile.getAbsolutePath();	
		
		System.out.println("----------------------test File Info -------------------------------------");
		System.out.println(" ");
		System.out.println("Absolute file under test is :"+ obsPath);
		System.out.println(" ");
		System.out.println("----------------------test File Info -------------------------------------");
		return obsPath;
	
				
		
	}

	public static void copyFile(Path htmlSourcePath, Path htmlReportDestinationPath) throws IOException {
		Files.copy(htmlSourcePath, htmlReportDestinationPath,StandardCopyOption.REPLACE_EXISTING);	
		
		
	}

public static  List<Map<String,String>> parseFileWithDelimeter(String testFlatFileCompletePath) throws IOException{
	
			 //String testFlatFileCompletePath="\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\SUC automation\\Required Documents\\12. SUC546265-DRX To MAM\\MAPDP_Complete_2018_20180401.bsc180401111900.txt";
			 File inputFile = new File(testFlatFileCompletePath);
			 List<Map<String,String>> listOfRows=new ArrayList<Map<String,String>>();
			 String line=null;
			 String cvsSplitBy = "\t";
			 List<String[]> rowsList=new ArrayList<String[]>();
		 	 if (!inputFile.exists()) { 
		 		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			  } else {
								System.out.println("Starting of File Reading . . . . . .  . . . . ");
								FileReader fileReader =  new FileReader(testFlatFileCompletePath);
								BufferedReader bufferedReader =        new BufferedReader(fileReader);
									
						        while((line = bufferedReader.readLine()) != null) {
					                String[] columnsArray = line.split(cvsSplitBy);
					                rowsList.add(columnsArray);
						       		}   
						       System.out.println("__________________________________________________________");
						       //  Map map=new HashMap();
						       String[] columns=rowsList.get(0);
						       int numberOfRows=rowsList.size();
						      //  int columnLength=rowsList.get(0).length;
								
						      for(int rowNo=1;rowNo<numberOfRows;rowNo++){
									Map<String,String> rowMap=new HashMap<String,String>();
									int columnLength=rowsList.get(rowNo).length;
									for(int i=0;i<columnLength;i++){
										rowMap.put(columns[i].toUpperCase(), rowsList.get(rowNo)[i]);	//System.out.println(rowNo+"  columnlength::"+columnLength+" index: "+i+"  "+rowsList.get(rowNo)[i]);
									}
									listOfRows.add(rowMap);
							}
		    	}
		 	return listOfRows;
}

public static  Map<String,String> getRowMap(String primaryKeyColumnName, String primaryKeyValue, List<Map<String, String>> rowsList) {

		for(Map<String,String> map:rowsList){
			if(primaryKeyValue.equals(map.get(primaryKeyColumnName))){
				return map;
				}
			}
	return null;
}

}
