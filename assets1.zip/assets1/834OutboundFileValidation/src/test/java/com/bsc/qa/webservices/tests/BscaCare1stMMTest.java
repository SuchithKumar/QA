package com.bsc.qa.webservices.tests;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.h2.engine.SysProperties;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.Edi834Utility;
import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable {
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	
	public BscaCare1stMMTest(String inputFileName) {
		this.inputFileName = inputFileName;
	}
	// ************************************** TEST
	// METHODS************************

	// Main test method to validate 834 file against FACETS database.
	@Test()
	private void test834FileValidation() throws IOException {
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;

		// Retrieving test data value from test data sheet
		String strCompleteFilePath = System.getenv("INPUT_EDI_PATH");
		//File cinn_file=new File(System.getenv("CIN_COMPLETE_FILE_PATH")+"\\file2.txt");
		
		//Creating Edi834Utility class object
		Edi834Utility edi834Utility = new Edi834Utility();
		
		Map<String, String> data = null;
		try{
			data = getData("test834FileValidation");
		} 
		catch (Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try{
			flatFileValuesMap = edi834Utility.get834FileData(
			strCompleteFilePath, inputFileName,data);
		} 
		catch (Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Retrieve's all primary keys into flatFileValuesMap
		Set<String> keys = flatFileValuesMap.keySet();
		String  inClauseStringBuilderstr = "";
        int intICounter = 0;
        List<String> strKeysList = new ArrayList<String>();
        List<String> strKeysList_cinn = new ArrayList<String>();
        
        //Loop used to get the subscribers data to pass it is input to the query
        for(String key:keys){
        	strKeysList_cinn.add(key);
        }
        
        for(String key : keys){
            intICounter++;
            inClauseStringBuilderstr = inClauseStringBuilderstr + "'" + key + "',";
            
            //Storing 1000 subscribers data in a list variable
            if(intICounter >=1000){
                //Removing extra ',' at the end of the map
                inClauseStringBuilderstr = inClauseStringBuilderstr.substring(0, (inClauseStringBuilderstr.length()-1));
                //Adding the 1000 subscribers data to list
                strKeysList.add(inClauseStringBuilderstr);
                strKeysList_cinn.add(key);
                intICounter = 0;
                inClauseStringBuilderstr = "";
            }
		}
        
        //Storing last subscribers data which are less than 1000
		if((intICounter < 1000) && (intICounter !=0)){
            //Removing extra ',' at the end of the map
            inClauseStringBuilderstr = inClauseStringBuilderstr.substring(0, (inClauseStringBuilderstr.length()-1));
            strKeysList.add(inClauseStringBuilderstr);
            inClauseStringBuilderstr = "";
		}

		StringBuilder strMeetQuery = new StringBuilder();
		for (String key : keys){
			  strMeetQuery = strMeetQuery.append(data.get("MEET_QUERY").replace("Parameter1", key.toUpperCase()) + " UNION ");
		}
		
		strMeetQuery.delete(strMeetQuery.lastIndexOf("UNION"), strMeetQuery.length());
		String strQuery = "      ";
		String query1=" ";
		
		//To get 834 file type
		String	strFileType = edi834Utility.fileType834(inputFileName);
		
		//Loop used to get 1000 subscribers data and store the same in main SortedMap
        for(String strKeySet : strKeysList ){
        	if(strFileType.contains("834") || strFileType.contains("HCO")){
        		//Creating where clause statement for each 1000 subscribers data
	        	strQuery = strQuery + data.get("PRIMARY_KEY") + " in (" + strKeySet + ")" + " Or ";
	        	query1=query1+data.get("Cinn_query")+ " in (" + strKeySet + ")";
	        	System.out.println("query is..."+query1);
	       }
	        else if(strFileType.contains("Salesforce_PCP_Assign") ){
	        	//Creating where clause statement for each 1000 subscribers data
	        	strQuery = strQuery + data.get("PRIMARY_KEY2") + " in (" + strKeySet + ")" + " Or ";
	        }
	        else if( strFileType.contains("TRR")){
	        	//Creating where clause statement for each 1000 subscribers data
	        	strQuery = strQuery + data.get("PRIMARY_KEY3") + " in (" + strKeySet + ")" + " Or ";
	        }
        }
        
        strQuery = strQuery.substring(0, strQuery.length()-4).trim();
        
        // Query from data sheet columns are stored in the following maps
        SortedMap<String, SortedMap<String, String>> sql1Map = null;
        SortedMap<String, SortedMap<String, String>> prprIdMap = null;
        SortedMap<String, SortedMap<String, String>> queryDataMap = null;
        SortedMap<String, SortedMap<String, String>> spclIndicMap = null;
        SortedMap<String, SortedMap<String, String>> spclIndcDateMap = null;
        SortedMap<String, SortedMap<String, String>> eligibilityTermMap = null;
        SortedMap<String, SortedMap<String, String>> eligibilityReinstMap = null;
        SortedMap<String, SortedMap<String, String>> meetMap = null;
        SortedMap<String, SortedMap<String, String>> sql1Map_cinn = null;
        
        String strActualQuery = "";
        
        // Start validation for file type "834"
        if(strFileType.contains("834")){
        	
        //PrintStream fileStream = new PrintStream(new File(System.getenv("CIN_COMPLETE_FILE_PATH"))+"\\file1.txt");
	    //Replaces 'in clause' string in the query with all subscriber Id's in comma separated format
	        	        
	    sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("SQL_TEMPLATE") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    eligibilityTermMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("ELIGIBILITY_QUERY1") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    eligibilityReinstMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("ELIGIBILITY_QUERY2") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    prprIdMap = new DBUtils().getResultSetAsSortedMap("facets", data.get("PRPRID_QUERY") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
	    spclIndicMap  = edi834Utility.getSpecialIndicatorData(keys, data.get("SPECIALINDICATOR_QUERY") ,"DTA_ELEM_BUS_NM", "CUSTM_DTA_ELEM_KEY","CUSTM_DTA_ELEM_VAL_TXT");
	    spclIndcDateMap  = edi834Utility.getSpecialIndicatorData(keys, data.get("SPECIALINDICATORDATE_QUERY") ,"DTA_ELEM_BUS_NM", "CUSTM_DTA_ELEM_KEY","CUSTM_DTA_ELEM_VAL_DT");
		meetMap = new DBUtils().getResultSetAsSortedMap("facets", strMeetQuery.toString().toUpperCase(),data.get("PRIMARY_KEY4"));
		
		strActualQuery = data.get("SQL_TEMPLATE") + "  " + strQuery.toString().toUpperCase();
		
		//Putting all the maps data into the main map - queryDataMap
	    queryDataMap = edi834Utility.sortedMapMerging(sql1Map,eligibilityTermMap);
        queryDataMap = edi834Utility.sortedMapMerging(queryDataMap,eligibilityReinstMap);
        queryDataMap = edi834Utility.sortedMapMerging(queryDataMap,prprIdMap);
        queryDataMap = edi834Utility.sortedMapMerging(queryDataMap,spclIndicMap);
        queryDataMap = edi834Utility.sortedMapMerging(queryDataMap,spclIndcDateMap);
        
        
        sql1Map_cinn = new DBUtils().getResultSetAsSortedMap("facets",query1.toString().toUpperCase(), data.get("PRIMARY_KEY"));
         
       	String[] cinn_no=null;
       	File cinn_file_idcards=new File(System.getenv("CIN_COMPLETE_FILE_PATH_IDcards"));
       	File cinn_file_welcomekit=new File(System.getenv("CIN_COMPLETE_FILE_PATH_WKIT"));
       	
       	for(int c=0;c<=strKeysList_cinn.size()-1;c++){
        	try{
	        	if(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meme_medcd_no").equals(null)){
	        		System.out.println("in iffff");
		       	}
		       	else{
		       		if(!cinn_file_idcards.exists()){
		       			cinn_file_idcards.createNewFile();
	       			}
	       			if(!cinn_file_welcomekit.exists()){
	       				cinn_file_welcomekit.createNewFile();
	       			}
	       		BufferedWriter filewriter=new BufferedWriter(new FileWriter(cinn_file_idcards,true));
	       		BufferedWriter filewriter1=new BufferedWriter(new FileWriter(cinn_file_welcomekit,true));
	       			
	       		filewriter.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meme_medcd_no"));
	       		filewriter.append("-");
	       		filewriter.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meia_req_type"));
	       		filewriter.append("-");
	       		filewriter.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("sbsb_id"));
	       		filewriter.newLine();
	       		filewriter.close();
	       		filewriter1.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meme_medcd_no"));
	       		filewriter1.append("-");
	       		filewriter1.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("meia_req_type"));
	       		filewriter1.append("-");
	       		filewriter1.append(sql1Map_cinn.get(strKeysList_cinn.get(c)).get("sbsb_id"));
	       		filewriter1.newLine();
	       		filewriter1.close();
	       		}
	        }
	        catch(NullPointerException e){
	        	System.out.println("null value");
	        }
       	}
    }
        
        else if(strFileType.contains("Salesforce_PCP_Assign") ){
        	//Replaces 'in clause' string in the query with all subscriber ids in comma separated format
            sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("SalesForceFileQueries") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY2"));
            strActualQuery = data.get("SalesForceFileQueries") + "  " + strQuery.toString().toUpperCase();
        }
        else if(strFileType.contains("HCO")){
        	//Replaces 'in clause' string in the query with all subscriber ids in comma separated format
            sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("HCOFileQueries") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
            strActualQuery = data.get("HCOFileQueries") + "  " + strQuery.toString().toUpperCase();
        }
        else if(strFileType.contains("TRR")){
        	//Replaces 'in clause' string in the query with all subscriber ids in comma separated format
            sql1Map = new DBUtils().getResultSetAsSortedMap("facets", data.get("TRRFileQueries") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY3"));
            strActualQuery =  data.get("TRRFileQueries") + "  " + strQuery.toString().toUpperCase();
        }
        else{
        	System.out.println("Please provide valid file");
        }
        
        Set<String> primaryKeySet = flatFileValuesMap.keySet();
        int intJCounter = 1;
        
        
		//TODO: Temporary workaround to validate - if data in file is in DB then pass. Must remove this and uncomment the MapDifference code below when all data elements are accounted for.
		//Below section will loop on each primaryKey in the "flatfilevaluemap"
		for (String primaryKey: primaryKeySet){
			
			//capture single subscriber id from flatfilevaluemap
			SortedMap<String, String> rowMap = flatFileValuesMap.get(primaryKey);
			
			//To get the report for each subscriber in the XML
			//Parameters: to display report header in the HTML
			if(intJCounter != 1){
				reportInit("834FileToDbValidation ", ": Subscriber ID: " +primaryKey);
				logger.log(LogStatus.INFO, "Starting Test - test834FileValidation ");
			}
			intJCounter++;
			logger.log(LogStatus.INFO, "File Path: " + inputFileName);
			logger.log(LogStatus.INFO, "Query used to fetch database data : " + strActualQuery );
			logger.log(LogStatus.INFO, "Subscriber used for validation is: " + primaryKey.toUpperCase());
			logger.log(LogStatus.INFO, "Field Name: Actual | Expected");
			
			String[] strArrayModified = new String[2];
			String strPrimaryDbKey = "";
	        SortedMap<String, String> strPrimaryDbMap = new TreeMap<String,String>();
	       
	        if(queryDataMap.containsKey(primaryKey)){
	        	strPrimaryDbMap = queryDataMap.get(primaryKey); //Check this map for FACETS DB validations
	        }
	        
	        String strPrimaryMeetKey = "";
	        SortedMap<String, String> strPrimaryMeetMap = new TreeMap<String,String>();
	        if(meetMap.size()>0){
	        	for(Entry<String,SortedMap<String, String>> entryMap : meetMap.entrySet()){
	        		strPrimaryMeetKey = entryMap.getKey();
			        if(strPrimaryMeetKey.contains(primaryKey)){
			        	strPrimaryMeetMap = entryMap.getValue(); //Check for this map for MEET validations
			        }
			    }
	        }   
	        
	        //Performing MEET and FACETS database validations
			try{
				//Checking if data is not present in Facets db but present in MEET with respective error
				if((strPrimaryDbMap.isEmpty() && strPrimaryMeetMap.size()>0)){
					logger.log(LogStatus.WARNING, "Data is NOT present in Facets database but present in MEET for this CINN Number: " + primaryKey.toUpperCase() + " with Error Value as: " + strPrimaryMeetMap.get("error_value") + " and Error Description as: " + strPrimaryMeetMap.get("error_description") + ".");
				}
				//Checking if data is not present in Facets db as well as in MEET db
				else if(strPrimaryDbMap.isEmpty() && strPrimaryMeetMap.isEmpty()){
					logger.log(LogStatus.FAIL, "Data is NOT present in Facets and MEET database for this CINN Number: " + primaryKey.toUpperCase()  + ". Please check MMS logs for more details");
				}
				//Checking if data is present in Facets db and not present in MEET then start with the validations
				else if (queryDataMap.size()>0){
					//Retrieving value from database for each of the keys				
					SortedMap<String,String> strSubscriberID = queryDataMap.get(primaryKey);
					
					//Below section will loop on each key in the flatfilevaluemap
					for (String columnKey : rowMap.keySet()){
						//Retrieving value from flat file for each of the keys 
						String fileValue = rowMap.get(columnKey);
						String dbValue = "";
						//Retrieving value from database for each of the keys				
						dbValue = queryDataMap.get(primaryKey).get(columnKey);
						strArrayModified = funcSourceTargetTransformationLogic(columnKey,fileValue,dbValue);
						fileValue = strArrayModified[0];
						dbValue = strArrayModified[1];
						//Comparing source and target values to report in the logger
						System.out.println("Keys and values for comparison: " +columnKey + "|" + fileValue + "|" + dbValue );
						
						if(columnKey.contains("ADDRESS1".toLowerCase()) || columnKey.contains("ADDRESS2".toLowerCase()) || columnKey.contains("CITY".toLowerCase())){
							if(fileValue.contains(dbValue)){
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							else{
								logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							System.out.println(columnKey + ": " + fileValue + " | " + dbValue);
							softAssert.assertTrue(fileValue.contains(dbValue),  primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
						}
						
						else if (columnKey.contains("prpr_id")){
							if(fileValue.equalsIgnoreCase("[Blank]")){
								if(!dbValue.equalsIgnoreCase("[Blank]")){
									logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									softAssert.assertTrue(true, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
								}
								else{
									logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
									softAssert.assertTrue(false, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
								}
								System.out.println(columnKey + ": " + fileValue + " | " + dbValue);
							}
						
						else{
							if(fileValue.equalsIgnoreCase(dbValue)){
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							else{
								logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
						}
					}
						
						else if (columnKey.contains("MEDS Renewal Date_443".toLowerCase())){
							if(dbValue.contains(fileValue)){
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							else
							{
								logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							System.out.println(columnKey + ": " + fileValue + " | " + dbValue);
							softAssert.assertTrue(dbValue.contains(fileValue),  primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
						}
						
						else{
							if(fileValue.equalsIgnoreCase(dbValue)){
								logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							else{
								logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
							}
							System.out.println(columnKey + ": " + fileValue + " | " + dbValue);
							softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " is not present in database");
						}				
					}
				}
			}
					
			//Reporting subscriber ID in HTML report when it is not loaded into FACETS
			catch(Exception e){
				logger.log(LogStatus.FAIL," This Subscriber id (" + primaryKey.toUpperCase() + ") is NOT loaded into FACETS");
			}
		}
	}
	
	private  String [] funcSourceTargetTransformationLogic(String key,String fileValue,String dbValue) throws Exception{
		String fileModifiedValue,dbModifiedValue;
		String [] strReturn = new String[2];
		
		if(fileValue == null){
			fileValue = "[Blank]";
			fileModifiedValue = fileValue;
		}
		else{
			fileModifiedValue = fileValue;
		}
		
		if(dbValue == null){
			dbValue = "[Blank]";
			dbModifiedValue = dbValue;
		}
		else{
			dbModifiedValue = dbValue;
		}
		
		//Replacing null values with [Blank] for user understanding
		if(fileValue.toString().trim().equalsIgnoreCase(""))
			fileValue = "[Blank]";
		if(dbValue.toString().trim().equalsIgnoreCase(""))
			dbValue = "[Blank]";
		if(fileValue.equalsIgnoreCase(";")|| fileValue.equalsIgnoreCase(";;"))
			fileValue = "[Blank]";
		fileModifiedValue = fileValue.trim().toUpperCase();
		dbModifiedValue = dbValue.trim().toUpperCase();
		
		
		//To validate Primary County Code field field
		if(key.equalsIgnoreCase("Primary County_411")){					
			if(fileModifiedValue.contains(dbModifiedValue)){
				if(dbModifiedValue.equals("19") || dbModifiedValue.equals("37"));{
				}
			}
			else{
				System.out.println("Invalid County Code");
			}
		}
		
		 //To validate ETHNICITY field
		 if(key.equalsIgnoreCase("MEME_MCTR_ETHN_NVL")){
			 String strQuery = "Select distinct FACETS_ETHNIC_CD from CU_ETHNIC_MAP_XREF where EDI_ETHNIC_CD = '" + fileValue + "'";
			 Map<String,String> ethinicity = new HashMap<String,String>();
			 ethinicity = new DBUtils().getOneRowResultSetAsMap("facets", strQuery);
			 fileModifiedValue = ethinicity.get("FACETS_ETHNIC_CD");
			 if(fileModifiedValue == null){
				 fileModifiedValue = "[Blank]";
			 }
		} 
		 
		 
		 //To validate PRPR_ID field
		 if(key.equalsIgnoreCase("PRPR_ID")){
			 try{
				 String getPcpQuery = "SELECT PRPR_ID FROM PFI.PFI_LACARE_XWALK where LACARE_ID = '" + fileValue.trim() + "'";
				 System.out.println("prpr query"+getPcpQuery);
				 Map<String,String> prprMap = new HashMap <String,String>();
				 prprMap = new DBUtils().getOneRowResultSetAsMap("facets", getPcpQuery);
				 fileModifiedValue = prprMap.get("PRPR_ID");
				 System.out.println("file value" + fileModifiedValue);
				 if(fileModifiedValue == null){
					 fileModifiedValue = "[Blank]";
				 }
			 }
			 catch (Exception e){
				 System.out.println("PRPR Id not found");
			 }
		 } 		 
		strReturn[0] = fileModifiedValue;
		strReturn[1] = 	dbModifiedValue;
		return strReturn;
	}

		
	//TODO: Replace valueExistsInDb with this logic whenever all data elements on the file and DB are accounted for
	/**
	 * Pefrom a diff between actual vs expected
	 * @param flatFileValuesMap
	 * @param sql1Map
	 * @return map diff as a sorted map of sorted maps
	 */
	
	@SuppressWarnings("unused")
	private MapDifference<String, SortedMap<String, String>> getMapDiff(
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap,
		SortedMap<String, SortedMap<String, String>> sql1Map) {
		MapDifference<String, SortedMap<String, String>> diff = Maps.difference(flatFileValuesMap, sql1Map);

		Set<String> keysOnlyInActual = diff.entriesOnlyOnLeft().keySet();
		Set<String> keysOnlyInExpected = diff.entriesOnlyOnRight().keySet();
		
		if (!keysOnlyInActual.isEmpty()) {
			System.out.println("Keys only in actual: ");
			for (String key : keysOnlyInActual){
				System.out.println(key);
			}
		}

		if (!keysOnlyInExpected.isEmpty()){
			System.out.println("Keys only in expected: ");
			for (String key : keysOnlyInExpected){
				System.out.println(key);
			}
		}

		if (!diff.areEqual()){
			Set<String> entriesDifferingKeySet = diff.entriesDiffering().keySet();
			Map<String, ValueDifference<SortedMap<String, String>>> entriesDifferring = diff.entriesDiffering();
			ValueDifference<SortedMap<String, String>> valuesDifference = null;
			System.out.println("Entries differring");
			System.out.println("------------------");
			for (String key : entriesDifferingKeySet){
				System.out.println("key = " + key);
				valuesDifference = entriesDifferring.get(key);
				System.out.println("ACTUAL: \t" + valuesDifference.leftValue());
				System.out.println("EXPECTED: \t" + valuesDifference.rightValue());
				System.out.println("\t\tActual \t\t|\t\t Expected");
				logger.log(LogStatus.INFO, "\t\tActual \t\t|\t\t Expected values for CINN number: " + key);
				
				//Developer needs to ensure that both the file map and database maps have the SAME number AND order of Key values.
				//If this is not done, additional logic will be requried to handle the comparison.
				for (String diffKey : valuesDifference.leftValue().keySet()){
					String left = valuesDifference.leftValue().get(diffKey);
					String right = valuesDifference.rightValue().get(diffKey);
					if (!(left == null && right == null) && !left.equals(right)){
						System.out.println(diffKey + ": " + left + " | " + right);
						logger.log(LogStatus.FAIL, diffKey + ": " + left + " | " + right);
					}
					else{
						logger.log(LogStatus.PASS, diffKey + ": " + left + " | " + right);
					}
				}
				System.out.println("\n");
			}
		}
		return diff;
	}

	/**
	 * //To run test method, this method will initiate the HTML report
	 * 
	 * @Override run is a hook before @Test method
	 */
	
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult){
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting Test " + testResult.getName());
		callBack.runTestMethod(testResult);
		//To display the failure count in console
		softAssert.assertAll(); 
	}

	private Map<String, String> getData(String testMethodName) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		// assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/" + this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, testMethodName);
		return dataMap;
	}
}
