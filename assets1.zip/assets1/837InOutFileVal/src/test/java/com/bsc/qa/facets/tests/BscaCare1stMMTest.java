package com.bsc.qa.facets.tests;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable{
	//private static String strSubscriber_ID;  
    //final private static String strUniqueIdentifier1 = "SUBSCRIBER_ID"; // <= first 
    //final private static String strUniqueIdentifier2 = "RELATIONSHIP_CODE"; // <= second
    public static String filePath;
    private static String sheetName;
	private static DBUtils objDBUtility;//Mandatory declaration 
	public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
	private static Path path;
	private static Path inputDataPath;
	private static String resultsDestinationFolderPath;
	//	private static String resultsSourceFolderPath;
	//private static String filePAth ;//Mandatory 
	private static Map<String, String> flatFileValuesMap=new HashMap<String,String>();
	//private static Map<String,String>sqlQueryValuesMap;
	private static	Map<String,String>queryDataMap=new HashMap<String,String>();
	private static	Map<String,String>queryDataMap2=new HashMap<String,String>();
	
	private static	List<Map<String,String>>listOfRecords=new ArrayList<Map<String,String>>();
	private static String rootLocationOfInputFiles;
	private static String SUCName;
	private static int lineSegmentNumber = 0;
	

	
	//************************************** TEST METHODS************************	

	// Main test method to validate 837 file provider, subscriber and claim details against FACETS database.
	@Test(dataProvider = "masterDataProvider")
	private static void test837FileValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			
			//Retrieving test data value from test data sheet
			String inputFileName=data.get("InputFileName").toString();
			SUCName=data.get("SUC Name").toString();
			String strCompleteFilePath = rootLocationOfInputFiles + "\\"+SUCName+"\\" + inputFileName;
			String parameter1=data.get("ClaimID").toString();
			String parameter2=data.get("PatientAccountNumber").toString();
			String strInputFileName=data.get("InputFileName").toString();
			
			//Retrieving static queries data from FACETS database
			String queryFromDataSheet = data.get("SqlStaticQuery").toString();
			String	SqlQueryStatic=queryFromDataSheet.replace( "Parameter1",parameter1.trim());
			
			//Retrieving dynamic queries data from FACETS database
			String dynamicQueryFromDataSheet = data.get("SqlDynamicQuery").toString();
			String	SqlDynamicQuery=dynamicQueryFromDataSheet.replace( "Parameter1",parameter1.trim());
			
			//To get the values from 837 file
			List<String>rowsList=	TestFileUtil.parse837File(strCompleteFilePath,parameter1);
			int intSubscriber = 0;
			flatFileValuesMap.clear();
			
			//Displaying test data mandatory values in the logger
			logger.log(LogStatus.INFO,  " Patient Account number: " + parameter2);
			logger.log(LogStatus.INFO,  " Claim id: " + parameter1);
			logger.log(LogStatus.INFO,  " Validated file name: " + strInputFileName);
			logger.log(LogStatus.INFO,  " Queries used to retrive Static fileds: " + SqlQueryStatic);
			logger.log(LogStatus.INFO,  " Queries used to retrive Dynamic fileds: " + SqlDynamicQuery);
			System.out.println(" Patient Account number: " + parameter1);
			System.out.println(" Claim id: " + parameter2);
			
			//Reading file lines to retrieve required values
			for(int i=0;i<rowsList.size();i++){
				System.out.println(" currentr Line is: " + rowsList.get(i));
				//NM1*IL this loop is coming twice so it is failing there
				// To validate subscriber details
				if(rowsList.get(i).startsWith("NM1*IL")){
					if(intSubscriber == 0){
						String line1=rowsList.get(i).toString();
						flatFileValuesMap.put("SBSB_ID", line1.split("\\*")[9].replace("~", ""));
						flatFileValuesMap.put("SBSB_LAST_NAME", line1.split("\\*")[3]);
						flatFileValuesMap.put("SBSB_FIRST_NAME", line1.split("\\*")[4]);
						flatFileValuesMap.put("SBSB_MID_INIT", line1.split("\\*")[5].replace("~", ""));
						String line2=rowsList.get(i+1).toString();
						String line3=rowsList.get(i+2).toString();
						String line4=rowsList.get(i+3).toString();
						flatFileValuesMap.put("SBAD_ADDR1", line2.split("\\*")[1].replace("~", ""));
						flatFileValuesMap.put("SBAD_CITY", line3.split("\\*")[1]);
						flatFileValuesMap.put("SBAD_STATE", line3.split("\\*")[2]);
						
						
						flatFileValuesMap.put("SBAD_ZIP", line3.split("\\*")[3].replace("~", ""));
						flatFileValuesMap.put("MEME_BIRTH_DT", line4.split("\\*")[2]);
						flatFileValuesMap.put("MEME_SEX", line4.split("\\*")[3].replace("~", ""));
						intSubscriber = intSubscriber + 1;
					}
					
				}
				// To validate provider details
				else if(rowsList.get(i).startsWith("NM1*85")){
					String line1=rowsList.get(i).toString();
					String line2=rowsList.get(i+1).toString();
					String line3=rowsList.get(i+2).toString();
					String line4=rowsList.get(i+3).toString();
					flatFileValuesMap.put("PRPR_NAME", line1.split("\\*")[3]);
					flatFileValuesMap.put("PRPR_NPI", line1.split("\\*")[9].replace("~", ""));
					
					//MCTN_ID this columnis matching
					//error PRAD_ID replaced with MCTN_ID
					flatFileValuesMap.put("MCTN_ID", line4.split("\\*")[2].replace("~", ""));
					flatFileValuesMap.put("PRAD_ADDR1", line2.split("\\*")[1].replace("~", ""));
					flatFileValuesMap.put("PRAD_CITY", line3.split("\\*")[1]);
					flatFileValuesMap.put("PRAD_STATE", line3.split("\\*")[2]);
					flatFileValuesMap.put("PRAD_ZIP", line3.split("\\*")[3].replace("~", ""));
				
				}
				// Claim details 	
				//Drug code
			
				// To validate Claim Received date				
				else if(rowsList.get(i).startsWith("BHT")){
					String line1=rowsList.get(i).toString();
					flatFileValuesMap.put("CLCL_RECD_DT", line1.split("\\*")[4].replace("~", ""));
					
			
				}
				
				// To validate Total charge amount in various amount section
				//Need to check with Fun team on this functionality
				else if(rowsList.get(i).startsWith("CLM")){
					String line1=rowsList.get(i).toString();
					flatFileValuesMap.put("CLCL_TOT_CHG",  line1.split("\\*")[2].replace("~", ""));
				}
				
				
				//Dynamic fields putting into map
				

				// Claim details 	
				//Drug code
				//need to handle for different line items
				if(rowsList.get(i).startsWith("HI")){
					String line1=rowsList.get(i).toString();
					String[] drugCode = line1.split("\\*");
					for (int intICounter=0; intICounter < drugCode.length-1; intICounter++)
					{	
						if(drugCode[intICounter+1].contains(":")){
							if(intICounter == 0)
								flatFileValuesMap.put("IDCD_ID_" + (intICounter+1) , drugCode[intICounter+1].split(":")[1].replace("~", ""));
							else
								flatFileValuesMap.put("IDCD_ID_" + (intICounter+1), drugCode[intICounter+1].split(":")[1].replace("~", ""));
						}
						else if(drugCode[intICounter+1].contains(">")){
							if(intICounter == 0)
								flatFileValuesMap.put("IDCD_ID_" + (intICounter+1) , drugCode[intICounter+1].split(">")[1].replace("~", ""));
							else
								flatFileValuesMap.put("IDCD_ID_" + (intICounter+1), drugCode[intICounter+1].split(">")[1].replace("~", ""));
						}
						else
							logger.log(LogStatus.FAIL, "Invalid character present in the line starts with 'HI' in Claim segment details ");
						
					}
				}
				
				//To get line item details
				else if(rowsList.get(i).startsWith("LX*")){
					lineSegmentNumber = lineSegmentNumber + 1;
					lineItemValidation(rowsList,i,flatFileValuesMap,lineSegmentNumber);
					
				
				}
			
			}
			
			System.out.println("flatFileValuesMap: "+flatFileValuesMap);
			
			Map<String,String> queryDataMapStatic = new HashMap <String,String>();
		
			queryDataMapStatic = objDBUtility.resultSetToDictionaryMultiKeyValues(SqlQueryStatic);//queryDataMap
			
			
		
			System.out.println("flatFileValuesMap: "+flatFileValuesMap);
			
			//Retrieving multiple record values and storing in data map
			Map<String,String> queryDataMapDynamicFields = new HashMap<String,String>();
			queryDataMapDynamicFields = objDBUtility.resultSetToDictionaryMultiValues(SqlDynamicQuery);//queryDataMap
			
			//Merging static and dynamic maps into single map
			queryDataMap.putAll(queryDataMapStatic);
			queryDataMap.putAll(queryDataMapDynamicFields);
			System.out.println("queryDataMap:"+queryDataMap);
			System.out.println("flatFileValuesMap:"+flatFileValuesMap);
			
			//OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
			//Comparing dynamic fields with softassertion logic
			OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
			
			
		
			 } catch (Exception e) {
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					//softAssertion.assertAll();	//<== absolutely must be here
				}
				
	}
	
	
	

	
	//Retrieving multiple line items data and storing into a maps for validation
	private static void lineItemValidation(List<String>rowsList, int lineNumber,Map<String, String> flatFileValuesMap, int lineSegmentNumber) throws Exception{
		
		int lineItemEndLineNumber=0,lineItemStartLineNumber;
		int intCDMLTODT = 0;
		
		lineItemStartLineNumber = lineNumber;
		//To check line item start or end
		for(int intICounter = lineNumber+1;intICounter<rowsList.size()-1;intICounter++){
			
			if(rowsList.get(intICounter).startsWith("LX") || rowsList.get(intICounter).startsWith("SE")){
				lineItemEndLineNumber = intICounter-1;
				break;
			}
			
		}
		
		for (int intJCounter = lineItemStartLineNumber; intJCounter<=lineItemEndLineNumber; intJCounter++){
			
			// To retrieve line item From date of service
			if(rowsList.get(intJCounter).startsWith("DTP*472")){
				String lineVal1=rowsList.get(intJCounter).toString();
				if(lineSegmentNumber ==1)
					flatFileValuesMap.put("CDML_FROM_DT_" + lineSegmentNumber , lineVal1.split("\\*")[3].replace("~", ""));
				else
					flatFileValuesMap.put("CDML_FROM_DT_" + lineSegmentNumber, lineVal1.split("\\*")[3].replace("~", ""));
			}
			
			//To retrieve To date of service
			else if(rowsList.get(intJCounter).startsWith("DTP*573Dup")){
				intCDMLTODT = intCDMLTODT + 1;
				String lineVal1=rowsList.get(intJCounter).toString();
				if(lineSegmentNumber == 1)
					flatFileValuesMap.put("CDML_TO_DT_" + lineSegmentNumber , lineVal1.split("\\*")[3].replace("~", ""));
				else
					flatFileValuesMap.put("CDML_TO_DT_" + lineSegmentNumber, lineVal1.split("\\*")[3].replace("~", ""));
			}
			
			// To retrieve Procedure code details
			else if(rowsList.get(intJCounter).startsWith("SV1")){
				String lineVal1=rowsList.get(intJCounter).toString();
				if(lineVal1.split("\\*")[1].contains(":")){
					if(lineSegmentNumber == 1)
						flatFileValuesMap.put("IPCD_ID_" + lineSegmentNumber, lineVal1.split("\\*")[1].split(":")[1].replace("~", ""));
					else
						flatFileValuesMap.put("IPCD_ID_" + lineSegmentNumber, lineVal1.split("\\*")[1].split(":")[1].replace("~", ""));
				}
				else if(lineVal1.split("\\*")[1].contains(">")){
					if(lineSegmentNumber == 1)
						flatFileValuesMap.put("IPCD_ID_" + lineSegmentNumber, lineVal1.split("\\*")[1].split(">")[1].replace("~", ""));
					else
						flatFileValuesMap.put("IPCD_ID_" + lineSegmentNumber, lineVal1.split("\\*")[1].split(">")[1].replace("~", ""));
				}
				else
					logger.log(LogStatus.FAIL, "Invalid character present in the line starts with 'SV1' in Claim segment details ");
			}
			
			
		
			
		}
		//if to date is not present then assigning from date as to date
		if(intCDMLTODT==0){
			flatFileValuesMap.put("CDML_TO_DT_" + lineSegmentNumber , flatFileValuesMap.get("CDML_FROM_DT_" + lineSegmentNumber));
		}

		
	}
	
	
	
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles","ResultsDestinationFolderPath"}) //Note parrams order	
	public void setUpTest(@Optional("NameOfTestDataSheet") String NameOfTestDataSheet,@Optional("TestDataSheetLocation") String TestDataSheetLocation,@Optional("DB_Name") String DB_Name, @Optional("DB_User") String DB_User, @Optional("DB_Pwd") String DB_Pwd , @Optional("DB_Server") String DB_Server, @Optional("DB_Port") String DB_Port, @Optional("RootLocationOfFlatFiles") String RootLocationOfFlatFiles, @Optional("ResultsDestinationFolderPath") String ResultsDestinationFolderPath){    //Args order matters should match to params order
		filePath=TestDataSheetLocation;
		System.out.println("TestDate Loc:"+TestDataSheetLocation);
		
		path = Paths.get("target\\Results\\"+timestamp);
		//public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
		 if(!Files.exists(path))
		{
		try {
			Files.createDirectories(path);
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
		
		
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		sheetName=NameOfTestDataSheet;
		rootLocationOfInputFiles = RootLocationOfFlatFiles;
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
		
		
		
		
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, "Environment");
		  Object[][] testDataArray=  ExcelUtils.getTableArray(filePath, "Environment");
		  List<Object> list=new ArrayList<Object>();
		  Map<String, String> rowDataMap = new HashMap<String, String>();
		  int noOfTestCases=0;
		 String runMode="Yes";
		  for(int row=0;row<=testDataArray.length-1;row++){
			if(runMode.equalsIgnoreCase(testDataArray[row][1].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				//Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++){
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);
				//data[row][0]=rowDataMap;
			}
		}
		 
		  if(noOfTestCases!=1){
			  System.out.println("Please select only one Environment record in testdata sheet ");
			  logger.log(LogStatus.FAIL, "Please select only one Environment record in testdata sheet ");
			  
		  }
		  else if (rowDataMap.get("DBName").toString().trim().equalsIgnoreCase("") ||
				  rowDataMap.get("DBUserName").toString().trim().equalsIgnoreCase("") ||
				  rowDataMap.get("DBPassword").toString().trim().equalsIgnoreCase("") ||
				  rowDataMap.get("DBServer").toString().trim().equalsIgnoreCase("") ||
				  rowDataMap.get("DBPort").toString().trim().equalsIgnoreCase(""))
		  {
			  System.out.println("Please select valid database connection details in Environment sheet in testdata ");
			  logger.log(LogStatus.FAIL, "Please select valid database connection details in Environment sheet in testdata ");
		  }
		  else{
			  
			  DB_Name = rowDataMap.get("DBName");
			  DB_User = rowDataMap.get("DBUserName");
			  DB_Pwd = rowDataMap.get("DBPassword");
			  DB_Server = rowDataMap.get("DBServer");
			  DB_Port = rowDataMap.get("DBPort");
		  }
		  
		
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		//Below step is for setting up the path of the input file
		 //TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
			//Below step is for getting complete path of the input file		 
		 
		 //filePAth = tesFile.getCompleteTestFilePath();	 
		
	}


	
	


     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		
		//initBrowser(testResult.getTestName(), testResult.getMethod().getMethodName());
		Map<String,String> map=(Map<String,String>) callBack.getParameters()[0];
		String testCaseDetails=", Patient Account Number: "+map.get("PatientAccountNumber")+", Claim ID: "+map.get("ClaimID");
		//reportInit(testResult.getTestContext().getName(), browser,testCaseName, testResult.getMethod().getMethodName());
		
		reportInit(testResult.getTestContext().getName(), testResult.getName() + testCaseDetails);
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{
		//Map<String, String> dataMap = new HashMap<String, String>();
		//dataMap = ExcelUtils.getTestMethodData(method.getName());
		//data = new Object[][] { { dataMap },{ dataMap } };
		//  Object[][] testObjArray = ExcelFunctions.getTableArray("src//test//resources//TestData.xlsx","BSCA_Care1st_MM_Test");
		//	      return (testObjArray);
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, sheetName);
		  Object[][] testDataArray=  ExcelUtils.getTableArray(filePath, sheetName);
		  List<Object> list=new ArrayList<Object>();
		  int noOfTestCases=0;
		 String runMode="Yes";
		  for(int row=0;row<=testDataArray.length-1;row++){
			if(method.getName().equalsIgnoreCase(testDataArray[row][2].toString())&& runMode.equalsIgnoreCase(testDataArray[row][3].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++){
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);
				//data[row][0]=rowDataMap;
			}
		}
		  
		  Object[][] data = new Object[noOfTestCases][1];
		  for(int row=0;row<list.size();row++){
			  data[row][0]=list.get(row);
		  }
		//data = new Object[][] { { list.get(0) },{ list.get(1) },{ list.get(2) }  };
		//System.out.println("Balu data:"+data[2][0]);
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		ReportFactory.closeReport();
	}
	
	@AfterMethod
	public void afterMethod() throws IOException{
		inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		File srcDir = new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
	}
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
			try {
	//-----		Path htmlReportSourcePath=Paths.get(resultsSourceFolderPath+"//test-output//emailable-report.html");//storing report source path in htmlReportSourcePath 
	//-----		Path htmlReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\emailable-report.html");//storing report source path in htmlReportDestinationPath
			
			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
	//-----			TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files
			
			
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	  }
	
	  
	  
		
		@Test(dataProvider = "masterDataProvider")
		private static void test837FileStaticFieldsValidation(Map<String, String> data) {
			SoftAssert softAssertion= new SoftAssert();	 
			try {
				String inputFileName=data.get("InputFileName").toString();
				SUCName=data.get("SUC Name").toString();
				String strCompleteFilePath = rootLocationOfInputFiles + "\\"+SUCName+"\\" + inputFileName;
				String parameter1=data.get("ClaimID").toString();
				String parameter2=data.get("PatientAccountNumber").toString();
				List<String>rowsList=	TestFileUtil.parse837File(strCompleteFilePath,parameter1);
				int intSubscriber = 0;
				flatFileValuesMap.clear();
				
				logger.log(LogStatus.INFO,  " Patient Account number: " + parameter1);
				logger.log(LogStatus.INFO,  " Claim id: " + parameter2);
				System.out.println(" Patient Account number: " + parameter1);
				System.out.println(" Claim id: " + parameter2);
				
				for(int i=0;i<rowsList.size();i++){
					System.out.println(" currentr Line is: " + rowsList.get(i));
					//NM1*IL this loop is coming twice so it is failing there
					// To validate subscriber details
					if(rowsList.get(i).startsWith("NM1*IL")){
						if(intSubscriber == 0){
							String line1=rowsList.get(i).toString();
							flatFileValuesMap.put("SBSB_ID", line1.split("\\*")[9].replace("~", ""));
							flatFileValuesMap.put("SBSB_LAST_NAME", line1.split("\\*")[3]);
							flatFileValuesMap.put("SBSB_FIRST_NAME", line1.split("\\*")[4]);
							flatFileValuesMap.put("SBSB_MID_INIT", line1.split("\\*")[5].replace("~", ""));
							String line2=rowsList.get(i+1).toString();
							String line3=rowsList.get(i+2).toString();
							String line4=rowsList.get(i+3).toString();
							flatFileValuesMap.put("SBAD_ADDR1", line2.split("\\*")[1].replace("~", ""));
							flatFileValuesMap.put("SBAD_CITY", line3.split("\\*")[1]);
							flatFileValuesMap.put("SBAD_STATE", line3.split("\\*")[2]);
							
							
							flatFileValuesMap.put("SBAD_ZIP", line3.split("\\*")[3].replace("~", ""));
							flatFileValuesMap.put("MEME_BIRTH_DT", line4.split("\\*")[2]);
							flatFileValuesMap.put("MEME_SEX", line4.split("\\*")[3].replace("~", ""));
							intSubscriber = intSubscriber + 1;
						}
						
					}
					// To validate provider details
					else if(rowsList.get(i).startsWith("NM1*85")){
						String line1=rowsList.get(i).toString();
						String line2=rowsList.get(i+1).toString();
						String line3=rowsList.get(i+2).toString();
						String line4=rowsList.get(i+3).toString();
						flatFileValuesMap.put("PRPR_NAME", line1.split("\\*")[3]);
						flatFileValuesMap.put("PRPR_NPI", line1.split("\\*")[9].replace("~", ""));
						
						//MCTN_ID this columnis matching
						//error PRAD_ID replaced with MCTN_ID
						flatFileValuesMap.put("MCTN_ID", line4.split("\\*")[2].replace("~", ""));
						flatFileValuesMap.put("PRAD_ADDR1", line2.split("\\*")[1].replace("~", ""));
						flatFileValuesMap.put("PRAD_CITY", line3.split("\\*")[1]);
						flatFileValuesMap.put("PRAD_STATE", line3.split("\\*")[2]);
						flatFileValuesMap.put("PRAD_ZIP", line3.split("\\*")[3].replace("~", ""));
					
					}
					// Claim details 	
					//Drug code
				
					// To validate Claim Received date				
					else if(rowsList.get(i).startsWith("BHT")){
						String line1=rowsList.get(i).toString();
						flatFileValuesMap.put("CLCL_RECD_DT", line1.split("\\*")[4].replace("~", ""));
						
				
					}
					
					// To validate Total charge amount in various amount section
					//Need to check with Fun team on this functionality
					else if(rowsList.get(i).startsWith("CLM")){
						String line1=rowsList.get(i).toString();
						flatFileValuesMap.put("CLCL_TOT_CHG",  line1.split("\\*")[2].replace("~", ""));
					}
					
				
				}
				
				System.out.println("flatFileValuesMap: "+flatFileValuesMap);
				String queryFromDataSheet = data.get("SqlStaticQuery").toString();
				String	SqlQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim());
			
				queryDataMap = objDBUtility.resultSetToDictionaryMultiKeyValues(SqlQuery);//queryDataMap
				
				
				
				System.out.println("queryDataMap:"+queryDataMap);
				System.out.println("flatFileValuesMap:"+flatFileValuesMap);
				
				OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
				
				
		
				 } catch (Exception e) {
						System.out.println("Test Case Failed due to Exception.....!!");
						softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
						e.printStackTrace();
					}finally{
						//softAssertion.assertAll();	//<== absolutely must be here
					}
					
		}
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void test837FileDynamicFieldsValidation(Map<String, String> data) {
			SoftAssert softAssertion= new SoftAssert();	 
			try {
				String inputFileName=data.get("InputFileName").toString();
				SUCName=data.get("SUC Name").toString();
				String strCompleteFilePath = rootLocationOfInputFiles + "\\"+SUCName+"\\" + inputFileName;
				String parameter1=data.get("ClaimID").toString();
				List<String>rowsList=	TestFileUtil.parse837File(strCompleteFilePath,parameter1);
				int intSubscriber = 0;
				flatFileValuesMap.clear();
				
				for(int i=0;i<rowsList.size();i++){
					System.out.println(" currentr Line is: " + rowsList.get(i));
				
			
					// Claim details 	
					//Drug code
					//need to handle for different line items
					if(rowsList.get(i).startsWith("HI")){
						String line1=rowsList.get(i).toString();
						String[] drugCode = line1.split("\\*");
						for (int intICounter=0; intICounter < drugCode.length-1; intICounter++)
						{	
							if(drugCode[intICounter+1].contains(":")){
								if(intICounter == 0)
									flatFileValuesMap.put("IDCD_ID_" + (intICounter+1) , drugCode[intICounter+1].split(":")[1].replace("~", ""));
								else
									flatFileValuesMap.put("IDCD_ID_" + (intICounter+1), drugCode[intICounter+1].split(":")[1].replace("~", ""));
							}
							else if(drugCode[intICounter+1].contains(">")){
								if(intICounter == 0)
									flatFileValuesMap.put("IDCD_ID_" + (intICounter+1) , drugCode[intICounter+1].split(">")[1].replace("~", ""));
								else
									flatFileValuesMap.put("IDCD_ID_" + (intICounter+1), drugCode[intICounter+1].split(">")[1].replace("~", ""));
							}
							else
								logger.log(LogStatus.FAIL, "Invalid character present in the line starts with 'HI' in Claim segment details ");
							
						}
					}
					
					
					else if(rowsList.get(i).startsWith("LX*")){
						lineSegmentNumber = lineSegmentNumber + 1;
						lineItemValidation(rowsList,i,flatFileValuesMap,lineSegmentNumber);
						
					
					}
					
				}
				
				System.out.println("flatFileValuesMap: "+flatFileValuesMap);
				String queryFromDataSheet = data.get("SqlStaticQuery").toString();
				String	SqlQuery=queryFromDataSheet.replace( "Parameter1",parameter1.trim());
				//Retrieving multiple record values and storing in data map
				queryDataMap = objDBUtility.resultSetToDictionaryMultiValues(SqlQuery);//queryDataMap
				listOfRecords = objDBUtility.resultSetToDictionary(SqlQuery);//queryDataMap
				queryDataMap2 = listOfRecords.get(0);
				
				
				System.out.println("queryDataMap:"+queryDataMap);
				System.out.println("flatFileValuesMap:"+flatFileValuesMap);
				
				//OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
				//Comparing dynamic fields with softassertion logic
				OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion);
				
		
				 } catch (Exception e) {
						System.out.println("Test Case Failed due to Exception.....!!");
						softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
						e.printStackTrace();
					}finally{
						//softAssertion.assertAll();	//<== absolutely must be here
					}
					
		}
		
		
		
		//To get multiple data from database
		private static void multiLineQuery(String SqlQuery) throws Exception{
			
			
			//List<Map<String,String>>listOfRecords
			 Map<String,String>queryDataMapSub=new HashMap<String,String>();
			listOfRecords = objDBUtility.resultSetToDictionary(SqlQuery);//queryDataMap
			
			for(Map<String,String> map: listOfRecords){
				
			}
			for (int intICounter = 0; intICounter <listOfRecords.size()-1; intICounter++){
				queryDataMapSub=listOfRecords.get(intICounter);//First element of list
				
				
			}
			
			queryDataMap=listOfRecords.get(0);//First element of list
			
		}
}
