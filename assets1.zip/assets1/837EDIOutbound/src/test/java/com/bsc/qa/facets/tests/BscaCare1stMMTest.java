package com.bsc.qa.facets.tests;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable{
	
    public static String filePath;
    private static String sheetName;
	private static DBUtils objDBUtility;//Mandatory declaration 
	public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
	private static Path path;
	private static Path inputDataPath;
	private static String resultsDestinationFolderPath;
	
	private static String rootLocationOfInputFiles;
	private static String SUCName;
		
	//************************************** TEST METHODS************************	

	// Main test method to validate 837 file provider, subscriber and claim details against FACETS database.
	@Test(dataProvider = "masterDataProvider")
	private static void test837FileValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {
			
			//RETRIEVING DATA FROM TEST DATA SHEET
			String inputFileName=data.get("InputFileName").toString();
			String outputFileName=data.get("OutboundFileName").toString();
			//String strClaimID=data.get("ClaimID").toString();
			SUCName=data.get("SUC Name").toString();
			String strCompleteFilePath = rootLocationOfInputFiles + "\\"+SUCName+"\\" + inputFileName;
			String strCompleteFilePathTarget = rootLocationOfInputFiles + "\\"+SUCName+"\\" + outputFileName;
			
			
			logger.log(LogStatus.PASS, "837 file validataion has started");
			
			//Validating the first row from Outbound file with Inbound file
			String strInboundFirstRow = TestFileUtil.parse837FilForFirstLine(strCompleteFilePath);
			String strOutboundFirstRow = TestFileUtil.parse837FilForFirstLine(strCompleteFilePathTarget);
			String [] arraystrInboundFirstRow  =  strInboundFirstRow.split("\\*");
			String [] arraystrOutboundFirstRow =  strOutboundFirstRow.split("\\*");
			//Field level validation of first row
			if(arraystrInboundFirstRow[6].equalsIgnoreCase(arraystrOutboundFirstRow[8]))
			{
				logger.log(LogStatus.PASS, "Outbound file matched with Inbound file");
			}
			else
			{
				logger.log(LogStatus.FAIL, "Outbound file not matched with Inbound file");
				System.out.println("Execution Terminated as the were files not matched");
				System.exit(1);
			}
			
			//Validating the number of claims from outbound to inbound file
			List<String>inboundClaimRowList=	TestFileUtil.parse837FileClaimVerification(strCompleteFilePath);
			List<String>outboundClaimRowList=	TestFileUtil.parse837FileClaimVerification(strCompleteFilePathTarget);
			List<String> processedClaimIDs = OtherUtilities.claimListValidate(inboundClaimRowList,outboundClaimRowList,softAssertion);

			//Validating the rows from ST to SE for all the claims 
			String strClaimIDLineTemp = null;
			String strResultValue = null;
			//Clearing the data in Results-sheet of Test data file
			ExcelUtils.clearExcelData(filePath, "Results");
			
			for (int intICounter = 0; intICounter<processedClaimIDs.size() ; intICounter++)
			{	
				
				 strClaimIDLineTemp = processedClaimIDs.get(intICounter);
				 
				 	//To get the values from 837 Inbound file 
					List<String>rowListInboundTemp =	TestFileUtil.parse837File(strCompleteFilePath,strClaimIDLineTemp);
					//To get the values from 837 Inbound file 
					List<String>rowListOutboundTemp =	TestFileUtil.parse837File(strCompleteFilePathTarget,strClaimIDLineTemp);
					
					OtherUtilities.listValidate(rowListInboundTemp,rowListOutboundTemp,strClaimIDLineTemp,filePath,softAssertion);
					
					strResultValue ="New Claim|New|New|New";
					ExcelUtils.setResultsInExcel(strCompleteFilePath, "Results", strResultValue );
				
			}
			
			 } catch (Exception e) {
					System.out.println("Test Case Failed due to Exception.....!!");
					softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
					e.printStackTrace();
				}finally{
					//softAssertion.assertAll();	//<== absolutely must be here
				}
				
	}
	
	
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles","ResultsDestinationFolderPath"}) //Note parrams order	
	public void setUpTest(@Optional("NameOfTestDataSheet") String NameOfTestDataSheet,@Optional("TestDataSheetLocation") String TestDataSheetLocation,@Optional("DB_Name") String DB_Name, @Optional("DB_User") String DB_User, @Optional("DB_Pwd") String DB_Pwd , @Optional("DB_Server") String DB_Server, @Optional("DB_Port") String DB_Port, @Optional("RootLocationOfFlatFiles") String RootLocationOfFlatFiles, @Optional("ResultsDestinationFolderPath") String ResultsDestinationFolderPath){    //Args order matters should match to params order
		filePath=TestDataSheetLocation;
		System.out.println("TestDate Loc:"+TestDataSheetLocation);
		
		path = Paths.get("target\\Results\\"+timestamp);
		//public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
		 if(!Files.exists(path))
		{
		try {
			Files.createDirectories(path);
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
		
		
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		sheetName=NameOfTestDataSheet;
		rootLocationOfInputFiles = RootLocationOfFlatFiles;
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
		
		
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, "Environment");
		  Object[][] testDataArray=  ExcelUtils.getTableArray(filePath, "Environment");
		  List<Object> list=new ArrayList<Object>();
		  Map<String, String> rowDataMap = new HashMap<String, String>();
		  int noOfTestCases=0;
		 String runMode="Yes";
		  for(int row=0;row<=testDataArray.length-1;row++){
			if(runMode.equalsIgnoreCase(testDataArray[row][1].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				//Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++){
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);
				//data[row][0]=rowDataMap;
			}
		  }
		 
		  if(noOfTestCases!=1){
			  System.out.println("Please select only one Environment record in testdata sheet ");
			  logger.log(LogStatus.FAIL, "Please select only one Environment record in testdata sheet ");
			  
		  }
		  else if (rowDataMap.get("DBName").toString().trim().equalsIgnoreCase("") ||
				  rowDataMap.get("DBUserName").toString().trim().equalsIgnoreCase("") ||
				  rowDataMap.get("DBPassword").toString().trim().equalsIgnoreCase("") ||
				  rowDataMap.get("DBServer").toString().trim().equalsIgnoreCase("") ||
				  rowDataMap.get("DBPort").toString().trim().equalsIgnoreCase(""))
		  {
			  System.out.println("Please select valid database connection details in Environment sheet in testdata ");
			  logger.log(LogStatus.FAIL, "Please select valid database connection details in Environment sheet in testdata ");
		  }
		  else{
			  
			  DB_Name = rowDataMap.get("DBName");
			  DB_User = rowDataMap.get("DBUserName");
			  DB_Pwd = rowDataMap.get("DBPassword");
			  DB_Server = rowDataMap.get("DBServer");
			  DB_Port = rowDataMap.get("DBPort");
		  }
		  
		
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		//Below step is for setting up the path of the input file
		 //TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
			//Below step is for getting complete path of the input file		 
		 
		 //filePAth = tesFile.getCompleteTestFilePath();	 
		
	}


	
	


     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		
		//initBrowser(testResult.getTestName(), testResult.getMethod().getMethodName());
		Map<String,String> map=(Map<String,String>) callBack.getParameters()[0];
		//String testCaseDetails=", Patient Account Number: "+map.get("PatientAccountNumber")+", Claim ID: "+map.get("ClaimID");
		//reportInit(testResult.getTestContext().getName(), browser,testCaseName, testResult.getMethod().getMethodName());
		
		reportInit(testResult.getTestContext().getName(), testResult.getName() );
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{
		//Map<String, String> dataMap = new HashMap<String, String>();
		//dataMap = ExcelUtils.getTestMethodData(method.getName());
		//data = new Object[][] { { dataMap },{ dataMap } };
		//  Object[][] testObjArray = ExcelFunctions.getTableArray("src//test//resources//TestData.xlsx","BSCA_Care1st_MM_Test");
		//	      return (testObjArray);
		  Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, sheetName);
		  Object[][] testDataArray=  ExcelUtils.getTableArray(filePath, sheetName);
		  List<Object> list=new ArrayList<Object>();
		  int noOfTestCases=0;
		 String runMode="Yes";
		  for(int row=0;row<=testDataArray.length-1;row++){
			if(method.getName().equalsIgnoreCase(testDataArray[row][2].toString())&& runMode.equalsIgnoreCase(testDataArray[row][3].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++){
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);
				//data[row][0]=rowDataMap;
			}
		}
		  
		  Object[][] data = new Object[noOfTestCases][1];
		  for(int row=0;row<list.size();row++){
			  data[row][0]=list.get(row);
		  }
		//data = new Object[][] { { list.get(0) },{ list.get(1) },{ list.get(2) }  };
		//System.out.println("Balu data:"+data[2][0]);
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		ReportFactory.closeReport();
	}
	
	@AfterMethod
	public void afterMethod() throws IOException{
		inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		File srcDir = new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
	}
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
			try {
	//-----		Path htmlReportSourcePath=Paths.get(resultsSourceFolderPath+"//test-output//emailable-report.html");//storing report source path in htmlReportSourcePath 
	//-----		Path htmlReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\emailable-report.html");//storing report source path in htmlReportDestinationPath
			
			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
	//-----			TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files
			
			
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	  }
	
	  
	  
		
		
		
		
		
}
