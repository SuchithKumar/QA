package com.bsc.qa.facets.ffpojo.utility;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
//import com.bsc.qa.facets.tests.Date;
//import com.bsc.qa.facets.tests.SimpleDateFormat;
import com.relevantcodes.extentreports.LogStatus;

import java.text.SimpleDateFormat;
import java.util.Date;




public class OtherUtilities extends BaseTest{
	// Validating in bound file and FACETS database column values
	public static void validate(Map<String, String> InboundList,	Map<String, String> OutboundList,SoftAssert softAssertion) throws Exception {
		//SoftAssert softAssertion= new SoftAssert();
		for(String key:InboundList.keySet()){
			if(OutboundList.containsKey(key)){
				OtherUtilities.validateActualAndExpectedValues(key,InboundList.get(key),OutboundList.get(key),softAssertion);
				System.out.println(" FieldName: " + key + ", FileValue: " + InboundList.get(key) + ", DBValue: " + OutboundList.get(key));
			}else{
				 softAssertion.assertTrue(OutboundList.containsKey(key), "Element " + key + " is not present in Database" );
				 logger.log(LogStatus.FAIL, key+" column is not present Database");
			}	
		}
	
	}
	
	
	// Validating Outbound lines with inbound file - line to line comparsion 
	public static List<String> claimListValidate (List<String> InboundList,List<String> OutboundList, SoftAssert softAssertion)  throws Exception 

	{
	
		boolean blnFound = false;
		String strInboundLineVal = null;
		System.out.println("InboundList:"+InboundList.size()+"OutboundList:"+OutboundList.size());
		List<String> rowList = new ArrayList<String>();
		for(String OutboundLineVal:OutboundList){
			
			
			for(String InboundLineVal:InboundList){
				blnFound = false;
				strInboundLineVal = InboundLineVal;
				if(OutboundLineVal.equalsIgnoreCase(InboundLineVal))
				{
					blnFound = true;
					logger.log(LogStatus.PASS, "Claims Validation: <br> Outbound claim patient account data: " + OutboundLineVal +  " <br> Inbound claim patient account data: " + InboundLineVal);
					rowList.add(OutboundLineVal);				
					break;
				}
				
			}
			
			if(blnFound == false){
							 
				 logger.log(LogStatus.FAIL, "Claims Validation: <br> Inbound claim patient account data: " + OutboundLineVal + " <br> Data is different in Inbound file "+strInboundLineVal);
								
			}
		}
		
		return rowList;
			
	}
	
	// Validating Outbound lines with inbound file - line to line comparsion 
		public static void listValidate (List<String> InboundList,List<String> OutboundList,String claimID,String strCompleteFilePath, SoftAssert softAssertion)  throws Exception 

		{
			boolean blnFound = false;
			String strInboundLineVal = null;
			String strResultValue = null;
			System.out.println("InboundList:"+InboundList.size()+"OutboundList:"+OutboundList.size());
			for(String OutboundLineVal:OutboundList){
				
				
				for(String InboundLineVal:InboundList){
					blnFound = false;
					strInboundLineVal = InboundLineVal;
					if(OutboundLineVal.equalsIgnoreCase(InboundLineVal))
					{
						blnFound = true;
						logger.log(LogStatus.PASS, "Outbound file line data: " + OutboundLineVal +  " <br> Inbound file line data: " + InboundLineVal);
							
						strResultValue = claimID + "|" + OutboundLineVal + "|" + InboundLineVal + "|" + "Pass";
						ExcelUtils.setResultsInExcel(strCompleteFilePath, "Results", strResultValue );
						break;
					}
					
					
				}
				
				if(blnFound == false){
								 
					 logger.log(LogStatus.FAIL, "Outbound file line data: " + OutboundLineVal +  " <br> Data is different in Inbound file ");
					 strResultValue = claimID + "|" + OutboundLineVal + "|" + "" + "|" + "Fail";
						ExcelUtils.setResultsInExcel(strCompleteFilePath, "Results", strResultValue );
									
				}
			}
			
		}
	
	// Validating in bound file and FACETS database column values 
	private static void validateActualAndExpectedValues(String key,String fileValue,String dbValue,SoftAssert softAssertion) throws Exception {
		
		String fileModifiedValue = fileValue.trim().toUpperCase();
		String dbModifiedValue = dbValue.trim().toUpperCase();
		
		//Replacing null values with [Blank] for user understanding
		if(fileValue.toString().trim().equalsIgnoreCase(""))
			fileValue = "[Blank]";
		if(dbValue.toString().trim().equalsIgnoreCase(""))
			dbValue = "[Blank]";
		//To validate CDML_CHG_AMT field
		if(key.equalsIgnoreCase("CDML_CHG_AMT")){
			
			/*//float dbValueFloat = new Float(dbValue);
			double dbValueDouble = new Double(dbValue);
			DecimalFormat df = new DecimalFormat("###.##");
			//String dbValueFloatefwef = df.format(dbValueDouble);
			double dbValueFloatefwef = (Math.round(dbValueDouble*100.00)/100.00);*/
			
			//System.out.println(" DB float value:" + (dbValueFloatefwef) );
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			
		}
		//Error need to handle this with equal logic
		else if (key.contains("IPCD_ID")){
			assertContainLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			
		}
		//To validate PRPR_NAME field
		else if(key.equalsIgnoreCase("PRPR_NAME")){
			
			dbModifiedValue= dbModifiedValue.replace(",", "");
			dbModifiedValue= dbModifiedValue.replace(".", "");
			
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			
		}
		//To validate CLCL_RECD_DT field
		else if(key.equalsIgnoreCase("CLCL_RECD_DT")){
			
			fileModifiedValue = dateAddSub(fileValue,-1);
			
			if(fileModifiedValue.equalsIgnoreCase(dbModifiedValue)){
				 assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			}
			else{
				assertEqualLogger(key,fileValue,dbValue,fileValue,dbValue,softAssertion);
			}
				
		}
		else{
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
		}
			
				
	
	}

	
	public static String dateAddSub(String strDate, int intDays) throws Exception{
		
		//Specifying date format that matches the given date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar c = Calendar.getInstance();
		try{
		   //Setting the date to the given date
		   c.setTime(sdf.parse(strDate));
		}catch(ParseException e){
			e.printStackTrace();
			return null;
		 }
		   
		//Number of Days to add
		c.add(Calendar.DAY_OF_MONTH, intDays);  
		//Date after adding the days to the given date
		return sdf.format(c.getTime());
	}


	public static void printTestCaseDeatilsInReport(Map<String, String> data) {		
		
		String strSUCName= data.get("SUC Name").toString();		
		String strTestCaseId = data.get("Test Case ID").toString();		
		String strTestCaseName = data.get("Test Case Name").toString();		
		String strStepNumber = data.get("Step Number").toString();
		//String strInputFileName = data.get("Input File Name").toString();
		logger.log(LogStatus.INFO," SUC Name: " + strSUCName + ", Test Case ID: " + strTestCaseId + ", Test Case Name: " + strTestCaseName + ", Step Number:" + strStepNumber);
		//logger.log(LogStatus.INFO," Input File Name: " + strInputFileName);
	}
	
	
	
	public static void assertEqualLogger(String key, String flatFileValue, String dbValue,String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(flatFileValue.equalsIgnoreCase(dbValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}
	}
	
	public static void assertContainLogger(String key, String flatFileValue, String dbValue, String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(dbValue.contains(flatFileValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}
	}
	
	public static void assertFailLogger(String key, String flatFileValue, String dbValue, String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(false, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
	}




	
	
	//below method is to check whether the given number is numeric or not
		public static boolean isNumeric(String str) {
		    int size = str.length();
		    for (int i = 0; i < size; i++) {
		        if (!Character.isDigit(str.charAt(i))) {
		            return false;
		        }
		    }

		    return size > 0;
		} 

}
