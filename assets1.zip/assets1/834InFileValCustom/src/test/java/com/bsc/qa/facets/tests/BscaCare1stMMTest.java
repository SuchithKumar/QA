package com.bsc.qa.facets.tests;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody;
/*import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileHeader;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileTrailer;*/
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.readers.BscaCare1stMMFlatFileReader;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable{
	//private static String strSubscriber_ID;  
	//final private static String strUniqueIdentifier1 = "SUBSCRIBER_ID"; // <= first 
	//final private static String strUniqueIdentifier2 = "RELATIONSHIP_CODE"; // <= second
	public static String filePath;
	private static String sheetName;
	private static DBUtils objDBUtility;//Mandatory declaration 
	public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
	private static Path path;
	private static Path inputDataPath;
	private static String resultsDestinationFolderPath;
	//private static String resultsSourceFolderPath;
	//private static String filePAth ;//Mandatory 
	private static Map<String, String> flatFileValuesMap=new HashMap<String,String>();
	//private static Map<String,String>sqlQueryValuesMap;
	private static	Map<String,String>queryDataMap=new HashMap<String,String>();
	static Map<String,String> finalQueryDataMap = new HashMap <String,String>();
	private static	List<Map<String,String>>listOfRecords=new ArrayList<Map<String,String>>();
	private static String rootLocationOfInputFiles;
	private static String SUCName;

	public static BscaCare1stMMFlatFileReader ffpExtract;

	public static int flag = 1;
	public static int flag1=0;

	//************************************** TEST METHODS************************	

	// Main test method to validate 834 file against FACETS database.
	@Test(dataProvider = "masterDataProvider")
	private static void test834FileValidation(Map<String, String> data) {
		SoftAssert softAssertion= new SoftAssert();	 
		try {

			//Retrieving test data value from test data sheet
			String inputFileName=data.get("InputFileName").toString();
			SUCName=data.get("SUC Name").toString();
			String strCompleteFilePath = rootLocationOfInputFiles + "\\"+SUCName+"\\" + inputFileName;
			String parameter1=data.get("CINNNUmber").toString();
			String strInputFileName=data.get("InputFileName").toString();
			String strFileType=data.get("FileType").toString();
			String strFileFieldAndTableColumnMapping = "src//test//resources//FileFieldAndTableColumnMapping.xlsx";
			String strOtherQueries = data.get("OtherQueries").toString();
			String strspecialIndicatorQueriesFromDataSheet =   data.get("SpecialIndicatorQueries").toString();
			//String strOtherQueries1 = data.get("OtherQueries1").toString();
			List<Map<String,String>> queryResultList;
			//Retrieving static queries data from FACETS database
			String queryFromDataSheet = data.get("SqlQueries").toString();
			String meetQueryFromDataSheet = data.get("MEETQueries").toString();
			String queryFromTestDataSheet = data.get("EligibilityQueries").toString();
			String strHCOFileQueries = data.get("HCOFileQueries").toString();
			String strTRRFileQueries = data.get("TRRFileQueries").toString();
			String strSalesForceFileQueries = data.get("SalesForceFileQueries").toString();
			String SqlQueries=queryFromDataSheet.replace( "Parameter1",parameter1.trim());
			String MEETQueries=meetQueryFromDataSheet.replace( "Parameter1",parameter1.trim());
			String EligibilityQueries=queryFromTestDataSheet.replace( "Parameter1",parameter1.trim());
			String strspecialIndicatorQueries = strspecialIndicatorQueriesFromDataSheet.replace("Parameter1",parameter1.trim());


			logger.log(LogStatus.INFO, "File name used for validation is: " + strInputFileName);
			strFileType = TestFileUtil.fileType834(strInputFileName);

			if(strFileType.contains("834"))
			{
				
				//To get the values from 837 file
				//TestFileUtil.fileFormatChange834(strCompleteFilePath);

				TestFileUtil.createFolder(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
				Path strFlatFilePath = Paths.get(strCompleteFilePath);
				Path destination = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName + "\\" + inputFileName);
				TestFileUtil.copyFile(strFlatFilePath, destination);
				List<String>rowsList=TestFileUtil.parse834File(strCompleteFilePath,parameter1,strFileType);
				int intSubscriber = 0;
				String line1 = "";
				flatFileValuesMap.clear();
				strOtherQueries = strOtherQueries.replaceAll("Parameter1", parameter1);
				//strOtherQueries1 = strOtherQueries1.replaceAll("Parameter1", parameter1);

				//Displaying test data mandatory values in the logger
				logger.log(LogStatus.INFO,  " CINN Number: " + parameter1);
				logger.log(LogStatus.INFO,  " Validated file name: " + strInputFileName);
				logger.log(LogStatus.INFO,  " Queries used to retrive data from database: " + SqlQueries);
				logger.log(LogStatus.INFO,  " Queries used to retrive MEET data from database: " + MEETQueries);
				logger.log(LogStatus.INFO,  " Queries used to retrive eligibility data from database: " + EligibilityQueries);

				//To implement Eligibility Validations
				String line3 = "";
				String line4 = "";
				String HCPCode = "";
				String strAidCode ="";
				String hcpStatusCode = "";
				String eligibilityDate = "";
				String hcpCode = "";
							
				if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
					for(int i = rowsList.size()-1;i>=0;i--){
						System.out.println("value of i is*****"+i);
						if(rowsList.size()>0){
							if(rowsList.get(i).startsWith("HD*")){
					
					// To Validate ELIGIBILITY Scenarios for LACare file
							
							if(flag ==1){
								strAidCode=rowsList.get(i).toString().split("\\*")[4].substring(19,21);
								System.out.println("Aid Code " +strAidCode);
								hcpStatusCode=rowsList.get(i).toString().split("\\*")[4].substring(14,16);
								System.out.println("HCP Status Code  "+ hcpStatusCode);
								line3=rowsList.get(i+1).toString();
								eligibilityDate = line3.split("\\*")[3].substring(0,8);
								System.out.println("Eligibility Date " + eligibilityDate);
								flatFileValuesMap.put("SBEL_EFF_DT",eligibilityDate);
							}
							if(rowsList.size()>1){	
								
					// To validate DISENROLLMENT scenario
								
							if(flag>1) {
								String hcpcompcode=rowsList.get(i).toString().split("\\*")[4].substring(14,16);
								if(strAidCode.equals(rowsList.get(i).toString().split("\\*")[4].substring(19,21))&&!hcpStatusCode.equalsIgnoreCase(rowsList.get(i).toString().split("\\*")[4].substring(14,16))&& hcpcompcode.equalsIgnoreCase("00") || hcpcompcode.equalsIgnoreCase(" ")){								
								line1=rowsList.get(i).toString();
								line3=rowsList.get(i+1).toString();
								line4=rowsList.get(i+2).toString();
								eligibilityDate = line3.split("\\*")[3].substring(0,8);
								System.out.println("hcp comp code is "+rowsList.get(i).toString().split("\\*")[4].substring(14,16));
								System.out.println("***hcp status code****" + hcpStatusCode);
								System.out.println("***Eligibility date****" + eligibilityDate);
								
								flatFileValuesMap.put("SBEL_EFF_DT",eligibilityDate);
								
								if (!line4.isEmpty()&&line4.contains("COB")){
									hcpCode = line4.split("\\*")[2];
									System.out.println("*****HCP Code****" + hcpCode);
								}
								else
								{
								System.out.println("COB details are not present in the file");
								}

								break;
							}
							}
							flag++;
							
				
					// To validate CHANGE scenario
							
							if(flag>1) {
								String hcpcompcode=rowsList.get(i).toString().split("\\*")[4].substring(14,16);
								if(!strAidCode.equals(rowsList.get(i).toString().split("\\*")[4].substring(19,21))&& hcpStatusCode.equalsIgnoreCase("01") && hcpcompcode.equalsIgnoreCase("01")){								
									line1=rowsList.get(i).toString();
									line3=rowsList.get(i+1).toString();
									line4=rowsList.get(i+2).toString();
									eligibilityDate = line3.split("\\*")[3].substring(0,8);
									System.out.println("hcp comp code is "+rowsList.get(i).toString().split("\\*")[4].substring(14,16));
									System.out.println("***Eligibility date****" + eligibilityDate);
									System.out.println("***hcp status code****" + hcpStatusCode);
									
									flatFileValuesMap.put("SBEL_EFF_DT",eligibilityDate);

									if (!line4.isEmpty()&&line4.contains("COB")){
										hcpCode = line4.split("\\*")[2];
										System.out.println("*****HCP Code****" + hcpCode);
									}
									else
									{
									System.out.println("COB details are not present in the file");
									}
									break;
							}
							}
							flag++;
							
				
					// To validate REINSTATE scenario
									
							if(flag>1) {
								String hcpcompcode=rowsList.get(i).toString().split("\\*")[4].substring(14,16);
								if(!hcpStatusCode.equalsIgnoreCase(rowsList.get(i).toString().split("\\*")[4].substring(14,16))&& hcpcompcode.equalsIgnoreCase("01")){								
									line1=rowsList.get(i).toString();
									line3=rowsList.get(i+1).toString();
									line4=rowsList.get(i+2).toString();
									eligibilityDate = line3.split("\\*")[3].substring(0,8);
									System.out.println("hcp comp code is "+rowsList.get(i).toString().split("\\*")[4].substring(14,16));
									System.out.println("***Eligibility date****" + eligibilityDate);
									System.out.println("***hcp status code****" + hcpStatusCode);
									System.out.println("before" +eligibilityDate);
									flatFileValuesMap.put("SBEL_EFF_DT",eligibilityDate);
									
									if (!line4.isEmpty()&&line4.contains("COB")){
										hcpCode = line4.split("\\*")[2];
										System.out.println("*****HCP Code****" + hcpCode);
									}
									else
									{
										System.out.println("COB details are not present in the file");
									}
									break;
								}
							}
							flag++;
						}
					}
				}
			}
		}	
				
				// To Validate ELIGIBILITY Scenarios for LACare-SD file
				
				if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") || strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834")){
					for(int i = rowsList.size()-1;i>=0;i--){
						System.out.println("value of i is*****"+i);
						if(rowsList.size()>0){
							if(rowsList.get(i).startsWith("HD*")){
								if(flag ==1){
									hcpStatusCode=rowsList.get(i).toString().split("\\*")[4].substring(4,6);
									System.out.println("This is HCP status code  " +hcpStatusCode);
									line3=rowsList.get(i+1).toString();
									eligibilityDate = line3.split("\\*")[3].substring(0,8);
									flatFileValuesMap.put("SBEL_EFF_DT",eligibilityDate);
								}

				if(rowsList.size()>1){		
							
				// To validate DISENOLLMENT Scenario
								
							if(flag>1){
								for(int j = rowsList.size()-1;j>=0;j--){
									if(rowsList.get(j).startsWith("REF*RB*")){	
										strAidCode=rowsList.get(j).toString().split("\\*")[2].substring(0,2);
										System.out.println("This is aid code  "+strAidCode);
										
										String hcpcompcode=rowsList.get(i).toString().split("\\*")[4].substring(4,6);
										if(strAidCode.equals(rowsList.get(j).toString().split("\\*")[2].substring(0,2))&&!hcpStatusCode.equalsIgnoreCase(rowsList.get(i).toString().split("\\*")[4].substring(4,6))&& hcpcompcode.equalsIgnoreCase("00")){								
											if(flag1==0){
											line3=rowsList.get(i+1).toString();
											eligibilityDate = line3.split("\\*")[3].substring(0,8);
											System.out.println("***Eligibility date****" + eligibilityDate);
											flatFileValuesMap.put("SBEL_EFF_DT",eligibilityDate);
											flag1+=1;
											}				
										}		
							
									}
									
								}														
							}
							flag++;
							
				
			 // To validate REINSTATE Scenario
								
						if(flag>1) {
								for(int j = rowsList.size()-1;j>=0;j--){
									if(rowsList.get(j).startsWith("REF*RB*")){
										strAidCode=rowsList.get(j).toString().split("\\*")[2].substring(0,2);
										System.out.println("This is aid code  "+strAidCode);
										
										String hcpcompcode=rowsList.get(i).toString().split("\\*")[4].substring(4,6);
										if(!hcpStatusCode.equalsIgnoreCase(rowsList.get(i).toString().split("\\*")[4].substring(4,6))&&hcpcompcode.equalsIgnoreCase("01")){								
											if(flag1==0){
											line3=rowsList.get(i+1).toString();
											eligibilityDate = line3.split("\\*")[3].substring(0,8);
											System.out.println("***Eligibility date****" + eligibilityDate);
											flatFileValuesMap.put("SBEL_EFF_DT",eligibilityDate);
											flag1+=1;
											}				
										}		
								
									}
										
								}														
						}
						flag++;
					}
				}
			}
		}
	}
				
				//Reading file lines to retrieve required values
				
				for(int i=0;i<rowsList.size();i++){
					System.out.println(" current Line is: " + rowsList.get(i));
					//NM1*IL this loop is coming twice so it is failing there

					// To validate subscriber's First name, last Name and Middle Initial
					if(rowsList.get(i).startsWith("NM1*IL*")){
						if(intSubscriber == 0){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							flatFileValuesMap.put("LAST_NAME", line1.split("\\*")[3]);
							flatFileValuesMap.put("FIRST_NAME", line1.split("\\*")[4]);
							//flatFileValuesMap.put("MIDINIT", line1.split("\\*")[5].replace("~", ""));						
							intSubscriber = intSubscriber + 1;
						}												
					}

					// To validate subscriber's Telephone Number
					if(rowsList.get(i).startsWith("PER*IP*")){			
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						flatFileValuesMap.put("TELEPHONE", line1.split("\\*")[4].replace("~", ""));	
					}

					// To validate subscriber's Address
					if(rowsList.get(i).startsWith("N3*")){			
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						flatFileValuesMap.put("ADDRESS1", line1.split("\\*")[1].substring(0).replace("~", ""));					
						//String strAddress = line1.split("\\*")[1];
						//flatFileValuesMap.put("ADDRESS2", line1.split("\\*")[1].substring(0).replace("~", ""));
					}


					// To validate Ethnicity
					if(rowsList.get(i).startsWith("DMG*")){			
						line1=rowsList.get(i).toString();					
						line1 = line1.replace("~", "");
						flatFileValuesMap.put("MEME_MCTR_ETHN_NVL",line1.split("\\*")[5].substring(5,11).replace("~", ""));					
					}


					// To validate subscriber's City LACare
					if(rowsList.get(i).startsWith("N4*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							flatFileValuesMap.put("CITY", line1.split("\\*")[1].replace("~", ""));
						}
					}

					// To validate subscriber's City LACare-SD
					if(rowsList.get(i).startsWith("N4*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							flatFileValuesMap.put("CITY", line1.split("\\*")[1].substring(0,2).replace("~", ""));
						}
					}														

					// To validate subscriber's City, State, Zipcode
					if(rowsList.get(i).startsWith("N4*")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						flatFileValuesMap.put("CITY", line1.split("\\*")[1].replace("~", ""));
						flatFileValuesMap.put("STATE", line1.split("\\*")[2].replace("~", ""));
						flatFileValuesMap.put("ZIPCODE", line1.split("\\*")[3].replace("~", ""));
					}

					// To validate subscriber's DOB and Gender
					if(rowsList.get(i).startsWith("DMG*")){			
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						flatFileValuesMap.put("DOB", line1.split("\\*")[2]);
						flatFileValuesMap.put("SEX", line1.split("\\*")[3].replace("~", ""));
					}

					// To validate subscriber's AID Code for LACare
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MECD_MCTR_AIDC1", line1.split("\\*")[4].substring(0,2).replace("~", ""));
						}
					}


					// To validate subscriber's AID Code for LACare-SD
					if(rowsList.get(i).startsWith("REF*3H*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MECD_MCTR_AIDC2", "00" + line1.split("\\*")[2].substring(3,5).replace("~", ""));
						}
					}

					if(rowsList.get(i).startsWith("REF*CE*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MECD_MCTR_AIDC3", "00" + line1.split("\\*")[2].substring(0,2).replace("~", ""));
						}
					}

					// To validate subscriber's AID Code for DHCS
					if(rowsList.get(i).startsWith("REF*3H*")){
						if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") || strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834"))
						{
							line1=rowsList.get(i).toString();	
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MECD_MCTR_AIDC4", "00" + line1.split("\\*")[2].substring(3,5).replace("~", ""));				
						}
					}

					if(rowsList.get(i).startsWith("REF*CE*")){
						if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") || strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MECD_MCTR_AIDC5", "00" + line1.split("\\*")[2].substring(0,2).replace("~", ""));
						}
					}


					// To validate Family Link id for LACare
					if(rowsList.get(i).startsWith("REF*3H*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MEME_FAM_LINK_ID", line1.split("\\*")[2].replace("~", ""));			
						}
					}				

					// To validate Family Link id for LACare-SD
					if(rowsList.get(i).startsWith("REF*3H*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MEME_FAM_LINK_ID", line1.split("\\*")[2].substring(6,13).replace("~", ""));			
						}
					}

					// To validate Family Link id for DHCS
					if(rowsList.get(i).startsWith("REF*3H*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") || strFileType.equalsIgnoreCase("SDCounty_Cal-MediConnect_Members(DHCS)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MEME_FAM_LINK_ID", line1.split("\\*")[2].substring(6,13).replace("~", ""));			
						}
					}
					
					
					// To Validate Language field
					if(rowsList.get(i).startsWith("LUI*")){
						line1=rowsList.get(i).toString();
						line1 = line1.replace("~", "");	
						
						String languageFileVal = line1.split("\\*")[4].substring(0,1).replace("~", "");
						flatFileValuesMap.put("MEME_MCTR_LANG", languageFileVal);
						
						HashMap<String, String> language = new HashMap<String, String>();
						
						// Adding elements to HashMap
						language.put("1", "SP01");
						language.put("2", "CA01");
						language.put("3", "JA01");
						language.put("4", "KO01");
						language.put("5", "TG01");
						language.put("6", "EN01");
						language.put("7", "EN01");
						language.put("B", "MN01");
						language.put("E", "AM01");
						language.put("J", "TU01");
						language.put("K", "HE01");
						language.put("L", "FR01");
						language.put("N", "RU01");
						language.put("P", "PR01");
						language.put("Q", "IT01");
						language.put("R", "AR01");
						language.put("T", "TH01");
						language.put("V", "VI01");
						
						List<String> langList = new ArrayList<String>(language.keySet());					
										
						for (int k=0;k<langList.size();k++){
							System.out.println(langList.get(k));
							if(langList.get(k).equalsIgnoreCase(flatFileValuesMap.put("MEME_MCTR_LANG", languageFileVal))){
								System.out.println("print single lang code " + langList.get(k));
								System.out.println("print encoded value " +language.get(langList.get(k)));
								System.out.println("final language value" + flatFileValuesMap.put("MEME_MCTR_LANG", language.get(langList.get(k))));
							}
							flatFileValuesMap.put("MEME_MCTR_LANG_1", language.get(langList.get(k)));
						}
					}
						
					
					//***********To validate Special Indicator Fields in LACare************

					// Validation of "CCS GHPP indicator_401" field
					if(rowsList.get(i).startsWith("REF*ZZ*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("CCS GHPP indicator_401", line1.split("\\*")[2].replace("~", ""));			
						}
					}

					// Validation of "Death date_402" field
					if(rowsList.get(i).startsWith("DTP*357*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("Death date_402", line1.split("\\*")[3].replace("~", ""));
						}
					}

					// Validation of "Primary Aid Code_403" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Primary Aid Code_403", line1.split("\\*")[4].substring(0,2).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Primary Aid Code_403",line1,4,0,2);
						}
					}

					// Validation of "Primary ESC_404" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Primary ESC_404", line1.split("\\*")[4].substring(2,5).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Primary ESC_404",line1,4,2,5);
						}
					}

					// Validation of "Special Aid Code1_405" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Special Aid Code1_405", line1.split("\\*")[4].substring(5,7).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Special Aid Code1_405",line1,4,5,7);
						}
					}

					// Validation of "Special Aid Code2_406" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Special Aid Code2_406", line1.split("\\*")[4].substring(7,9).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Special Aid Code2_406",line1,4,7,9);
						}	
					}

					// Validation of "Special Aid Code3_407" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							//flatFileValuesMap.put("Special Aid Code3_407", line1.split("\\*")[4].substring(9,11).replace("~", ""));
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Special Aid Code3_407",line1,4,9,11);	
						}
					}

					// Validation of "OHC Code_408" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("OHC Code_408", line1.split("\\*")[4].substring(11,12).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"OHC Code_408",line1,4,11,12);
						}
					}

					// Validation of "Medicare Status Code_409" field -- Need not validate this field as discussed with Functional Team
					/*if(rowsList.get(i).startsWith("HD*021*")){
					if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
					line1=rowsList.get(i).toString();
					line1 = line1.replace("~", "");					
					//flatFileValuesMap.put("Medicare Status Code_409", line1.split("\\*")[4].substring(12,13).replace("~", ""));			
					OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Medicare Status Code_409",line1,4,12,13);
					}
				}*/

					// Validation of "HCP Status_410" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("HCP Status_410", line1.split("\\*")[4].substring(14,16).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"HCP Status_410",line1,4,14,16);
						}	
					}

					// Validation of "Primary County_411" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Primary County_411", line1.split("\\*")[4].substring(21,23).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Primary County_411",line1,4,21,23);
						}
					}

					// Validation of "Medicare Part D_412" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Medicare Part D_412", line1.split("\\*")[4].substring(23,24).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Medicare Part D_412",line1,4,23,24);
						}
					}

					// Validation of "Federal Contract Number_413" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Federal Contract Number_413", line1.split("\\*")[4].substring(24,29).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Federal Contract Number_413",line1,4,24,29);
						}
					}

					// Validation of "Carrier Code_414" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Carrier Code_414", line1.split("\\*")[4].substring(29,33).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Carrier Code_414",line1,4,29,33);
						}
					}

					// Validation of "Policy Start Date_415" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Policy Start Date_415", line1.split("\\*")[4].substring(33,41).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Policy Start Date_415",line1,4,33,41);
						}
					}

					// Validation of "ETO Transaction Code Qualifier Code_416" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("ETO Transaction Code Qualifier Code_416", line1.split("\\*")[4].substring(41,43).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"ETO Transaction Code Qualifier Code_416",line1,4,41,43);
						}	
					}

					// Validation of "BAS Indicator_417" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("CBAS Indicator_417", line1.split("\\*")[4].substring(43,44).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"CBAS Indicator_417",line1,4,43,44);
						}
					}

					// Validation of "Medi-Cal Participation Indicator_418" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Medi-Cal Participation Indicator_418", line1.split("\\*")[4].substring(44,45).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Medi-Cal Participation Indicator_418",line1,4,44,45);
						}
					}

					// Validation of "CCI Opt out Indicator_419" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("CCI Opt out Indicator_419", line1.split("\\*")[4].substring(45,46).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"CCI Opt out Indicator_419",line1,4,45,46);
						}
					}

					// Validation of "ESRD Indicator_420" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("ESRD Indicator_420", line1.split("\\*")[4].substring(46,47).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"ESRD Indicator_420",line1,4,46,47);
						}
					}

					// Validation of "Part D LIS Indicator_421" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Part D LIS Indicator_421", line1.split("\\*")[4].substring(47,48).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Part D LIS Indicator_421",line1,4,47,48);
						}
					}

					// Validation of "CCI Exclusion Indicator_422" field
					if(rowsList.get(i).startsWith("HD*021*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("CCI Exclusion Indicator_422", line1.split("\\*")[4].substring(48,49).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"CCI Exclusion Indicator_422",line1,4,48,49);
						}
					}

					// Validation of "Nursing Facility Resident_423" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Nursing Facility Resident_423", line1.split("\\*")[4].substring(49,50).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Nursing Facility Resident_423",line1,4,49,50);
						}
					}	

					// Validation of "SI-NSI indicator_424" field
					if(rowsList.get(i).startsWith("REF*XX1*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("SI-NSI indicator_424", line1.split("\\*")[2].substring(2,3).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"SI-NSI indicator_424",line1,2,2,3);
						}
					}

					// Validation of "HCBS HIGH indicator_425" field
					if(rowsList.get(i).startsWith("REF*XX1*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("HCBS HIGH indicator_425", line1.split("\\*")[2].substring(3,4).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"HCBS HIGH indicator_425",line1,2,3,4);
						}
					}

					// Validation of "Subplan Indicator_426" field
					if(rowsList.get(i).startsWith("REF*XX1*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Subplan Indicator_426", line1.split("\\*")[2].substring(0,2).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Subplan Indicator_426",line1,2,0,2);
						}
					}

					// Validation of "Part D LIS Reassignee Indicator_427" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Part D LIS Reassignee Indicator_427", line1.split("\\*")[4].substring(47,48).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Part D LIS Reassignee Indicator_427",line1,4,47,48);
						}
					}

					// Validation of "MEDS ID_428" field
					if(rowsList.get(i).startsWith("REF*0F*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MEDS ID_428", line1.split("\\*")[2].replace("~", ""));			
						}
					}

					// Validation of "Prior MEDS ID_429" field
					if(rowsList.get(i).startsWith("REF*Q4*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("Prior MEDS ID_429", line1.split("\\*")[2].replace("~", ""));			
						}
					}

					// Validation of "Family Budget Unit & Person Number_430" field
					if(rowsList.get(i).startsWith("REF*1L*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Family Budget Unit & Person Number_430", line1.split("\\*")[2].substring(11,14).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Family Budget Unit & Person Number_430",line1,2,11,14);	
						}
					}

					//From 431 to 436 it is not applicable				

					// Validation of "Last Premium paid date_438" field
					if(rowsList.get(i).startsWith("DTP*543*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("Last Premium paid date_438", line1.split("\\*")[2].replace("~", ""));			
						}
					}

					// Validation of "SOC Amount_439" field
					if(rowsList.get(i).startsWith("AMT*C1*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("SOC Amount_439", line1.split("\\*")[2].replace("~", ""));			
						}
					}

					//440 is also Not applicable

					// Validation of "Institutional Indicator_441" field
					if(rowsList.get(i).startsWith("REF*XXI*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Institutional Indicator_441", line1.split("\\*")[2].substring(0,5).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Institutional Indicator_441",line1,2,0,5);
						}
					}

					// Validation of "Restriction_442" field
					if(rowsList.get(i).startsWith("HD*01*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Restriction_442", line1.split("\\*")[2].substring(16,19).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Restriction_442",line1,2,16,19);
						}
					}

					// Validation of "MEDS Renewal Date_443" field
					if(rowsList.get(i).startsWith("DTP*03*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MEDS Renewal Date_443", line1.split("\\*")[3].replace("~", ""));			
						}
					}

					// Validation of "Card Issue Date_444" field
					if(rowsList.get(i).startsWith("DTP*473*")){	
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834")){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("Card Issue Date_444", line1.split("\\*")[3].replace("~", ""));			
						}
					}
					
					//***********To validate Special Indicator Fields in DHCS************

					// Validation of "CCS GHPP indicator_401" field
					if(rowsList.get(i).startsWith("REF*6O*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("CCS GHPP indicator_401", line1.split("\\*")[2].substring(0,1).replace("~", ""));			
						}
					}

					// Validation of "Death date_402" field
					if(rowsList.get(i).startsWith("REF*17*;")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("Death date_402", line1.split("\\*")[2].substring(1,7).replace("~", ""));			
						}
					}

					// Validation of "Primary Aid Code_403" field
					if(rowsList.get(i).startsWith("REF*CE*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Primary Aid Code_403", line1.split("\\*")[2].substring(0,2).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Primary Aid Code_403",line1,2,0,2);
						}
					}

					// Validation of "Primary ESC_404" field
					if(rowsList.get(i).startsWith("REF*CE*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Primary ESC_404", line1.split("\\*")[2].substring(3,6).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Primary ESC_404",line1,2,3,6);
						}
					}

					// Validation of "Special Aid Code1_405" field
					if(rowsList.get(i).startsWith("REF*CE*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Special Aid Code1_405", line1.split("\\*")[2].substring(7,8).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Special Aid Code1_405",line1,2,7,8);
						}
					}

					// Validation of "Special Aid Code2_406" field
					if(rowsList.get(i).startsWith("REF*CE*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Special Aid Code2_406", line1.split("\\*")[2].substring(9,10).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Special Aid Code2_406",line1,2,9,10);
						}
					}

					// Validation of "Special Aid Code3_407" field
					if(rowsList.get(i).startsWith("REF*CE*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							//flatFileValuesMap.put("Special Aid Code3_407", line1.split("\\*")[2].substring(11,12).replace("~", ""));
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Special Aid Code3_407",line1,2,11,12);	
						}
					}

					// Validation of "OHC Code_408" field
					if(rowsList.get(i).startsWith("REF*17*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("OHC Code_408", line1.split("\\*")[2].substring(0,1).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"OHC Code_408",line1,2,0,1);
						}
					}

					// Validation of "Medicare Status Code_409" field
					/*if(rowsList.get(i).startsWith("REF*9V*")){	
					if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
					line1=rowsList.get(i).toString();
					line1 = line1.replace("~", "");					
					flatFileValuesMap.put("Medicare Status Code_409", line1.split("\\*")[2].replace("~", ""));			
					//OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Medicare Status Code_409",line1,4,12,13);
					}
				}*/

					// Validation of "HCP Status_410" field
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("HCP Status_410", line1.split("\\*")[4].substring(4,6).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"HCP Status_410",line1,4,4,6);
						}
					}

					// Validation of "Primary County_411" field
					if(rowsList.get(i).startsWith("N4*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("Primary County_411", line1.split("\\*")[6].replace("~", ""));			
							//OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Primary County_411",line1,4,21,23);
						}
					}

					// Validation of "Medicare Part D_412" field
					if(rowsList.get(i).startsWith("REF*9V")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Medicare Part D_412", line1.split("\\*")[2].substring(4,5).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Medicare Part D_412",line1,2,4,5);
						}
					}

					// Validation of "Federal Contract Number_413" field
					if(rowsList.get(i).startsWith("REF*DX*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Federal Contract Number_413", line1.split("\\*")[2].substring(0,1).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Federal Contract Number_413",line1,2,0,1);
						}
					}

					// Validation of "Carrier Code_414" field
					if(rowsList.get(i).startsWith("REF*DX*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Carrier Code_414", line1.split("\\*")[2].substring(1,5).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Carrier Code_414",line1,2,1,5);
						}
					}

					// Validation of "Policy Start Date_415" field
					if(rowsList.get(i).startsWith("REF*DX*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Policy Start Date_415", line1.split("\\*")[2].substring(2,4).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Policy Start Date_415",line1,2,2,4);
						}
					}

					// Validation of "ETO Transaction Code Qualifier Code_416" field -- This field is NA --
					if(rowsList.get(i).startsWith("HD*021*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("ETO Transaction Code Qualifier Code_416", line1.split("\\*")[4].substring(41,43).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"ETO Transaction Code Qualifier Code_416",line1,4,41,43);
						}
					}

					// Validation of "BAS Indicator_417" field
					if(rowsList.get(i).startsWith("REF*17**")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("CBAS Indicator_417", line1.split("\\*")[2].substring(1,3).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"CBAS Indicator_417",line1,2,1,3);
						}
					}

					// Validation of "Medi-Cal Participation Indicator_418" field
					if(rowsList.get(i).startsWith("REF*17*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Medi-Cal Participation Indicator_418", line1.split("\\*")[2].substring(2,4).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Medi-Cal Participation Indicator_418",line1,2,2,4);
						}
					}

					// Validation of "CCI Opt out Indicator_419" field
					if(rowsList.get(i).startsWith("REF*17*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("CCI Opt out Indicator_419", line1.split("\\*")[2].substring(3,5).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"CCI Opt out Indicator_419",line1,2,3,5);
						}
					}


					// Validation of "ESRD Indicator_420" field
					if(rowsList.get(i).startsWith("REF*17*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("ESRD Indicator_420", line1.split("\\*")[2].substring(5,6).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"ESRD Indicator_420",line1,2,5,6);
						}
					}

					// Validation of "Part D LIS Indicator_421" field
					if(rowsList.get(i).startsWith("REF*17*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Part D LIS Indicator_421", line1.split("\\*")[2].substring(5,7).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Part D LIS Indicator_421",line1,2,5,7);
						}
					}

					// Validation of "CCI Exclusion Indicator_422" field
					if(rowsList.get(i).startsWith("REF*17*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("CCI Exclusion Indicator_422", line1.split("\\*")[2].substring(6,8).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"CCI Exclusion Indicator_422",line1,2,6,8);
						}
					}

					// Validation of "Nursing Facility Resident_423" field
					if(rowsList.get(i).startsWith("REF*17*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Nursing Facility Resident_423", line1.split("\\*")[2].substring(7,9).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Nursing Facility Resident_423",line1,2,7,9);
						}
					}

					// Validation of "SI-NSI indicator_424" field
					if(rowsList.get(i).startsWith("REF*17*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("SI-NSI indicator_424", line1.split("\\*")[2].substring(8,10).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"SI-NSI indicator_424",line1,2,8,10);
						}
					}

					// Validation of "HCBS HIGH indicator_425" field
					if(rowsList.get(i).startsWith("REF*17*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("HCBS HIGH indicator_425", line1.split("\\*")[2].substring(9,11).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"HCBS HIGH indicator_425",line1,2,9,11);
						}
					}

					// Validation of "Subplan Indicator_426" field
					if(rowsList.get(i).startsWith("REF*17*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Subplan Indicator_426", line1.split("\\*")[2].substring(11,13).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Subplan Indicator_426",line1,2,11,13);
						}
					}

					// Validation of "Part D LIS Reassignee Indicator_427" field
					if(rowsList.get(i).startsWith("REF*17*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Part D LIS Reassignee Indicator_427", line1.split("\\*")[2].substring(5,7).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Part D LIS Reassignee Indicator_427",line1,2,5,7);
						}
					}

					// Validation of "MEDS ID_428" field
					if(rowsList.get(i).startsWith("REF*1L*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("MEDS ID_428", line1.split("\\*")[2].replace("~", ""));			
						}
					}

					// Validation of "Prior MEDS ID_429" field
					if(rowsList.get(i).startsWith("REF*Q4*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("Prior MEDS ID_429", line1.split("\\*")[2].replace("~", ""));			
						}
					}

					// Validation of "Family Budget Unit & Person Number_430" field
					if(rowsList.get(i).startsWith("REF*3H*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Family Budget Unit & Person Number_430", line1.split("\\*")[2].substring(13,16).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Family Budget Unit & Person Number_430",line1,2,13,16);	
						}
					}

					// Validation of "Residence Address Flag_431" field
					if(rowsList.get(i).startsWith("REF*6O*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Residence Address Flag_431", line1.split("\\*")[2].substring(2,3).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Residence Address Flag_431",line1,2,2,3);	
						}
					}

					// Validation of "Residence Address Indicator_432" field
					if(rowsList.get(i).startsWith("REF*6O*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Residence Address Indicator_432", line1.split("\\*")[2].substring(4,5).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Residence Address Indicator_432",line1,2,4,5);	
						}
					}

					// Validation of "Mailing Address Flag_433" field
					if(rowsList.get(i).startsWith("REF*6O*")){	
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Mailing Address Flag_433", line1.split("\\*")[2].substring(3,5).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Mailing Address Flag_433",line1,2,3,5);	
						}
					}

					// Validation of "Residence Zip Delivery Code_434" field
					if(rowsList.get(i).startsWith("REF*6O*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Residence Zip Delivery Code_434", line1.split("\\*")[2].substring(7,8).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Residence Zip Delivery Code_434",line1,2,7,8);	
						}
					}

					// Validation of "Mailing Zip delivery code_435" field
					if(rowsList.get(i).startsWith("REF*6O*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Mailing Zip delivery code_435", line1.split("\\*")[2].substring(4,6).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Mailing Zip delivery code_435",line1,2,4,6);	
						}
					}

					// Validation of "Personal ID Number_436" field
					if(rowsList.get(i).startsWith("REF*ABB*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("Personal ID Number_436", line1.split("\\*")[2].replace("~", ""));			
							//OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Personal ID Number_436",line1,2,4,6);	
						}
					}

					// Validation of Maintenance Effective_437 and Last Premium paid date_438 fields is not applicable			

					// Validation of "SOC Amount_439" field
					if(rowsList.get(i).startsWith("AMT*R*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("SOC Amount_439", line1.split("\\*")[2].replace("~", ""));			
						}
					}

					// Validation of "SOC certification day_440" field
					if(rowsList.get(i).startsWith("REF*ZZ*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							flatFileValuesMap.put("SOC certification day_440", line1.split("\\*")[2].substring(1,3).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"SOC certification day_440",line1,2,1,3);
						}
					}

					// Validation of "Institutional Indicator_441" field
					if(rowsList.get(i).startsWith("REF*17*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Institutional Indicator_441", line1.split("\\*")[2].substring(10,12).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Institutional Indicator_441",line1,2,10,12);
						}
					}

					// Validation of "Restriction_442" field is not applicable				

					// Validation of "MEDS Renewal Date_443" field
					if(rowsList.get(i).startsWith("REF*17*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("MEDS Renewal Date_443", line1.split("\\*")[2].substring(12,14).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"MEDS Renewal Date_443",line1,2,12,14);
						}
					}

					// Validation of "Card Issue Date_444" field
					if(rowsList.get(i).startsWith("REF*17*")){
						if(strFileType.equalsIgnoreCase("SDCounty_Medi-Cal_Members(DHCS)834") || strFileType.equalsIgnoreCase("LACounty_Cal-MediConnect_Members(DHCS)834") ){
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");					
							//flatFileValuesMap.put("Card Issue Date_444", line1.split("\\*")[2].substring(14,16).replace("~", ""));			
							OtherUtilities.partialStringRetrieval(flatFileValuesMap,"Card Issue Date_444",line1,2,14,16);
						}	
					}


					// To validate PCP information for LACare
					if(rowsList.get(i).startsWith("PER*IC*")){
						if(strFileType.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834"))
						{
							line1=rowsList.get(i).toString();
							line1 = line1.replace("~", "");
							String strPCPInput = line1.split("\\*")[4].substring(15, 29);
							Map<String,String> flatFileDBDataMap = new HashMap <String,String>();
							strOtherQueries = strOtherQueries.replaceAll("Parameter1", strPCPInput);
							flatFileDBDataMap = objDBUtility.resultSetToDictionaryMultiKeyValues(strOtherQueries);//queryDataMap
							if((flatFileDBDataMap.get("PRPR_ID") != null ? flatFileDBDataMap.get("PRPR_ID") : "").trim().equalsIgnoreCase("")){
								logger.log(LogStatus.PASS, "PCP Data is NOT present in the flat file for this LACare ID:" + strPCPInput);
							}
							else{
								flatFileValuesMap.put("PRPR_ID", flatFileDBDataMap.get("PRPR_ID"));
							}


						}
					}
				}	


				Map<String,String> queryDataMap = new HashMap <String,String>();	
				Map<String,String> queryDataMap1 = new HashMap <String,String>();
				Map<String,String> queryDataMap2 = new HashMap <String,String>();
				queryDataMap = objDBUtility.resultSetToDictionaryMultiKeyValues(SqlQueries);//queryDataMap
				queryDataMap2 = objDBUtility.resultSetToDictionaryMultiKeyValues(MEETQueries);//queryDataMap2
				queryDataMap1 = objDBUtility.resultSetToDictionaryMultiKeyValues(EligibilityQueries);//queryDataMap1

				List<Map<String,String>> otherQueriesResultSet = objDBUtility.resultSetToDictionary(strOtherQueries);//queryDataMap

				String[] queriesspecialIndicatorArray=strspecialIndicatorQueries.split(";");
				List<Map<String,String>> specialIndicatorResultSet1 = objDBUtility.resultSetToDictionary(queriesspecialIndicatorArray[0]);//queryDataMap
				List<Map<String,String>> specialIndicatorResultSet2 = objDBUtility.resultSetToDictionary(queriesspecialIndicatorArray[1]);//queryDataMap
				//List<Map<String,String>> otherQueriesResultSet1 = objDBUtility.resultSetToDictionary(strOtherQueries1);//queryDataMap1

				Map<String,String> strMap = objDBUtility.resultSetToDictionarySpecificColumns(specialIndicatorResultSet1, "DTA_ELEM_BUS_NM", "CUSTM_DTA_ELEM_KEY","CUSTM_DTA_ELEM_VAL_TXT");
				Map<String,String> strMap1 = objDBUtility.resultSetToDictionarySpecificColumns(specialIndicatorResultSet2, "DTA_ELEM_BUS_NM", "CUSTM_DTA_ELEM_KEY","CUSTM_DTA_ELEM_VAL_DT");
				//Map<String,String> strMap2 = objDBUtility.resultSetToDictionarySpecificColumns(otherQueriesResultSet, "DTA_ELEM_BUS_NM", "CUSTM_DTA_ELEM_KEY","CUSTM_DTA_ELEM_VAL_DT");

				System.out.println("queryDataMap for special:"+strMap);
				queryDataMap.putAll(strMap);
				queryDataMap.putAll(queryDataMap1);
				queryDataMap.putAll(strMap1);
				
				System.out.println("queryDataMap:"+queryDataMap);
				System.out.println("queryDataMap1:"+queryDataMap1);
				System.err.println("queryDataMap2:" + queryDataMap2);
				System.out.println("flatFileValuesMap:"+flatFileValuesMap);
				
				List<Map<String,String>>putQueryDataMap=new ArrayList<Map<String,String>>();
				putQueryDataMap.add(queryDataMap);
				
				
				// To validate if data is present in Facets and MEET
				
				if(queryDataMap.size()>0 && queryDataMap2.size()>0){
					logger.log(LogStatus.WARNING, "Data is present in facets as well as in MEET database, with error in MEET as: " + queryDataMap2.get("ERROR_DESCRIPTION") );
				}
				
				if (putQueryDataMap.size()>0){
					finalQueryDataMap = putQueryDataMap.get(0);
				}
				
				
				if(queryDataMap.isEmpty() && queryDataMap2.size()>0){
					logger.log(LogStatus.WARNING, "Data is NOT present in Facets database but present in MEET with error as: " + queryDataMap2.get("ERROR_DESCRIPTION_1"));
				}
				
				if (queryDataMap.isEmpty() && queryDataMap2.isEmpty()){
					logger.log(LogStatus.FAIL, "Data is NOT present in Facets and MEET database for this CINN Number: " + parameter1 + " . Please check the error logs for more details");
				}
				
				//Comparing dynamic fields with SOFTASSERTION logic				
				OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion,objDBUtility);
			}
			
			
			else if(strFileType.contains("HCO"))
			{
				List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\t",strCompleteFilePath,strFileFieldAndTableColumnMapping,"HCO");
				String strCINNNumber="";
				for(Map<String,String> map:rowsList){
					strCINNNumber = map.get("CINNNumber");
					logger.log(LogStatus.INFO, "CINN Number used for HCO file validation is: " + strCINNNumber);
					flatFileValuesMap = TestFileUtil.getRowMap("CINNNumber",strCINNNumber ,rowsList);
					flatFileValuesMap.remove("CINNNumber");

					String strHCOFileQueriesParameter = strHCOFileQueries.replace( "Parameter1",strCINNNumber.trim());

					queryResultList = objDBUtility.resultSetToDictionary(strHCOFileQueriesParameter);//queryDataMap
					if(queryResultList.size() > 0){
						queryDataMap = queryResultList.get(0);

					}
					else{
						logger.log(LogStatus.FAIL, "Data is NOT present in the database for this CINN Number:" + strCINNNumber);
					}


					//Comparing dynamic fields with softassertion logic
					OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion,objDBUtility);

				}


			}
			else if(strFileType.contains("TRR"))
			{

				//Map<String,String> rowsList = TestFileUtil.parseHCOFile(strCompleteFilePath,parameter1);

				List<Map<String , String>> listOfBodyMap  = new ArrayList<Map<String,String>>();
				Map<String,List<Object>> recordsMap=new HashMap<String,List<Object>>();



				try {


					ffpExtract = new BscaCare1stMMFlatFileReader(strCompleteFilePath);//this will set up the FileReader of ffpojo library


					FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody.class);   // <== BODY
					recordsMap=ffpExtract.getFlatFileData(ffDefinition);

					for(Object record:recordsMap.get("Body")){
						BscaCare1stMMFlatFileBody body = (BscaCare1stMMFlatFileBody)record;
						Map<String,String> bodyMap=new HashMap<String,String>();
						bodyMap.put("HICN", body.getHICN()); 
						bodyMap.put("FIRST_NAME", body.getFIRST_NAME()); 
						bodyMap.put("LAST_NAME", body.getLAST_NAME()); 
						bodyMap.put("MID_INIT", body.getMID_INIT()); 
						bodyMap.put("TRANS_RPLY_CD", body.getTRANS_RPLY_CD()); 
						bodyMap.put("TRANS_TYP_CD", body.getTRANS_TYP_CD()); 

						System.out.println("bodyMap:"+bodyMap);
						listOfBodyMap.add(bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
					}

					System.out.println("Map data:" + listOfBodyMap.get(0));


					for(Map<String,String> subscriberMap: listOfBodyMap){
						String strHICNNumber = subscriberMap.get("HICN").trim();
						logger.log(LogStatus.INFO, "HICN Number used for TRR file validation is: " + strHICNNumber);
						//hard coded to avoid data not present error
						//strHICNNumber = "96533548D";
						String strTRRFileQueriesParameter = strTRRFileQueries.replace( "Parameter1",strHICNNumber);


						queryResultList = objDBUtility.resultSetToDictionary(strTRRFileQueriesParameter);//queryDataMap

						if(queryResultList.size() > 0){
							queryDataMap = queryResultList.get(0);

						}
						else{
							logger.log(LogStatus.FAIL, "Data is NOT present in the database for this HICN Number:" + strHICNNumber);
						}

						System.out.println("Source map:" + subscriberMap);
						System.out.println("Target map:" + queryDataMap);


						//Comparing dynamic fields with softassertion logic
						OtherUtilities.validate(subscriberMap,queryDataMap,softAssertion,objDBUtility);

					}

				}
				catch(Exception e)
				{
					e.printStackTrace();

				}


			}
			else if(strFileType.contains("Salesforce_PCP_Assign"))
			{


				List<Map<String,String>>rowsList=	TestFileUtil.parseFileWithOutHeaderByDelimeter("\\|",strCompleteFilePath,strFileFieldAndTableColumnMapping,"SalesForce");
				String strCINNNumber="";

				List<Map<String,String>>rowsListSF = new ArrayList<Map<String,String>>();

				for(Map<String,String> map: rowsList){
					Map<String,String> rowsListMap = new HashMap<String,String>();
					for(String key: map.keySet()){

						rowsListMap.put(key, map.get(key).replaceAll("\"", ""));
					}
					rowsListSF.add(rowsListMap);
				}
				for(Map<String,String> map:rowsListSF){
					strCINNNumber = map.get("CIN").replaceAll("\"", "");
					logger.log(LogStatus.INFO, "CINN Number used for HCO file validation is: " + strCINNNumber);
					flatFileValuesMap = TestFileUtil.getRowMap("CIN",strCINNNumber ,rowsListSF);
					//strCINNNumber = "47323150A";
					String strSalesForceFileQueriesParameter = strSalesForceFileQueries.replace( "Parameter1",strCINNNumber.trim());

					queryResultList = objDBUtility.resultSetToDictionary(strSalesForceFileQueriesParameter);//queryDataMap

					if(queryResultList.size() > 0){
						queryDataMap = queryResultList.get(0);

					}
					else{
						logger.log(LogStatus.FAIL, "Data is NOT present in the database for this CINN Number:" + strCINNNumber);
					}




					//Comparing dynamic fields with softassertion logic
					OtherUtilities.validate(flatFileValuesMap,queryDataMap,softAssertion,objDBUtility);




				}
			}


		} catch (Exception e) {
			System.out.println("Test Case Failed due to Exception.....!!");
			softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
			e.printStackTrace();
		}finally{
			softAssertion.assertAll();	//<== absolutely must be here
		}

	}






	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles","ResultsDestinationFolderPath"}) //Note parrams order	
	public void setUpTest(@Optional("NameOfTestDataSheet") String NameOfTestDataSheet,@Optional("TestDataSheetLocation") String TestDataSheetLocation,@Optional("DB_Name") String DB_Name, @Optional("DB_User") String DB_User, @Optional("DB_Pwd") String DB_Pwd , @Optional("DB_Server") String DB_Server, @Optional("DB_Port") String DB_Port, @Optional("RootLocationOfFlatFiles") String RootLocationOfFlatFiles, @Optional("ResultsDestinationFolderPath") String ResultsDestinationFolderPath){    //Args order matters should match to params order
		filePath=TestDataSheetLocation;
		System.out.println("TestDate Loc:"+TestDataSheetLocation);

		path = Paths.get("target\\Results\\"+timestamp);
		//public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
		if(!Files.exists(path))
		{
			try {
				Files.createDirectories(path);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}


		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);

		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}

		sheetName=NameOfTestDataSheet;
		rootLocationOfInputFiles = RootLocationOfFlatFiles;
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);




		Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, "Environment");
		Object[][] testDataArray=  ExcelUtils.getTableArray(filePath, "Environment");
		List<Object> list=new ArrayList<Object>();
		Map<String, String> rowDataMap = new HashMap<String, String>();
		int noOfTestCases=0;
		String runMode="Yes";
		for(int row=0;row<=testDataArray.length-1;row++){
			if(runMode.equalsIgnoreCase(testDataArray[row][1].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				//Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++){
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);
				//data[row][0]=rowDataMap;
			}
		}

		if(noOfTestCases!=1){
			System.out.println("Please select only one Environment record in testdata sheet ");
			logger.log(LogStatus.FAIL, "Please select only one Environment record in testdata sheet ");

		}
		else if (rowDataMap.get("DBName").toString().trim().equalsIgnoreCase("") ||
				rowDataMap.get("DBUserName").toString().trim().equalsIgnoreCase("") ||
				rowDataMap.get("DBPassword").toString().trim().equalsIgnoreCase("") ||
				rowDataMap.get("DBServer").toString().trim().equalsIgnoreCase("") ||
				rowDataMap.get("DBPort").toString().trim().equalsIgnoreCase(""))
		{
			System.out.println("Please select valid database connection details in Environment sheet in testdata ");
			logger.log(LogStatus.FAIL, "Please select valid database connection details in Environment sheet in testdata ");
		}
		else{

			DB_Name = rowDataMap.get("DBName");
			DB_User = rowDataMap.get("DBUserName");
			DB_Pwd = rowDataMap.get("DBPassword");
			DB_Server = rowDataMap.get("DBServer");
			DB_Port = rowDataMap.get("DBPort");
		}


		//NOTE DB UTIL OBJECT CREATION! 
		objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		//Below step is for setting up the path of the input file
		//TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
		//Below step is for getting complete path of the input file		 

		//filePAth = tesFile.getCompleteTestFilePath();	 

	}






	/**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {

		//initBrowser(testResult.getTestName(), testResult.getMethod().getMethodName());
		Map<String,String> map=(Map<String,String>) callBack.getParameters()[0];
		String testCaseDetails=", CINN Number: "+map.get("CINNNUmber");
		//reportInit(testResult.getTestContext().getName(), browser,testCaseName, testResult.getMethod().getMethodName());

		reportInit(testResult.getTestContext().getName(), testResult.getName() + testCaseDetails);
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	

	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{
		//Map<String, String> dataMap = new HashMap<String, String>();
		//dataMap = ExcelUtils.getTestMethodData(method.getName());
		//data = new Object[][] { { dataMap },{ dataMap } };
		//  Object[][] testObjArray = ExcelFunctions.getTableArray("src//test//resources//TestData.xlsx","BSCA_Care1st_MM_Test");
		//	      return (testObjArray);
		Object[][] columnArray=  ExcelUtils.getColumnArray(filePath, sheetName);
		Object[][] testDataArray=  ExcelUtils.getTableArray(filePath, sheetName);
		List<Object> list=new ArrayList<Object>();
		int noOfTestCases=0;
		String runMode="Yes";
		for(int row=0;row<=testDataArray.length-1;row++){
			if(method.getName().equalsIgnoreCase(testDataArray[row][2].toString())&& runMode.equalsIgnoreCase(testDataArray[row][3].toString())){
				noOfTestCases++;
				System.out.println("TestCase Name Form Data Sheet:::"+testDataArray[row][1].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++){
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
				}
				list.add(rowDataMap);
				//data[row][0]=rowDataMap;
			}
		}

		Object[][] data = new Object[noOfTestCases][1];
		for(int row=0;row<list.size();row++){
			data[row][0]=list.get(row);
		}
		//data = new Object[][] { { list.get(0) },{ list.get(1) },{ list.get(2) }  };
		//System.out.println("Balu data:"+data[2][0]);

		return data;
	}
	@AfterClass
	public void afterClass() {
		ReportFactory.closeReport();
	}

	@AfterMethod
	public void afterMethod() throws IOException{
		/*inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		File srcDir = new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
		 */	}

	//after exection of all the tests in the suit,results and input data will be stored in results folder
	@AfterSuite
	public void afterSuite() {
		//assigning the resultsDestinationPath from testNG.xml
		try {
			//-----		Path htmlReportSourcePath=Paths.get(resultsSourceFolderPath+"//test-output//emailable-report.html");//storing report source path in htmlReportSourcePath 
			//-----		Path htmlReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\emailable-report.html");//storing report source path in htmlReportDestinationPath

			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
			//-----			TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
				Files.createDirectories(inputDataPath);//Creating directory
			}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files


		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	}





}
