package com.bsc.qa.facets.ffpojo.utility;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
//import com.bsc.qa.facets.tests.Date;
//import com.bsc.qa.facets.tests.SimpleDateFormat;
import com.relevantcodes.extentreports.LogStatus;

import java.text.SimpleDateFormat;
import java.util.Date;


public class OtherUtilities extends BaseTest{
	// Validating in bound file and FACETS database column values
	public static void validate(Map<String, String> flatFileValuesMap,	Map<String, String> queryDataMap,SoftAssert softAssertion,DBUtils objDBUtility) throws Exception {
		//SoftAssert softAssertion= new SoftAssert();
		for(String key:flatFileValuesMap.keySet()){
			if(queryDataMap.containsKey(key)){
				OtherUtilities.validateActualAndExpectedValues(key,flatFileValuesMap.get(key),queryDataMap.get(key),softAssertion,objDBUtility);
				System.out.println(" FieldName: " + key + ", FileValue: " + flatFileValuesMap.get(key) + ", DBValue: " + queryDataMap.get(key));
			}else{
				 softAssertion.assertTrue(queryDataMap.containsKey(key), "Element " + key + " is not present in Database" );
				 logger.log(LogStatus.FAIL, key+" is not present in Database");
			}	
		}
		
		
	
	}
	
	public static void validateEligibility(Map<String, String> flatFileValuesMap1,	Map<String, String> queryDataMap1,SoftAssert softAssertion,DBUtils objDBUtility) throws Exception {
		//SoftAssert softAssertion= new SoftAssert();
		for(String key:flatFileValuesMap1.keySet()){
			if(queryDataMap1.containsKey(key)){
				OtherUtilities.validateActualAndExpectedValues(key,flatFileValuesMap1.get(key),queryDataMap1.get(key),softAssertion,objDBUtility);
				System.out.println(" FieldName: " + key + ", FileValue: " + flatFileValuesMap1.get(key) + ", DBValue: " + queryDataMap1.get(key));
			}else{
				 softAssertion.assertTrue(queryDataMap1.containsKey(key), "Element " + key + " is not present in Database" );
				 logger.log(LogStatus.FAIL, key+" is not present in Database");
			}	
		}
		
		
	
	}

	
	
	// Validating In-bound file and FACETS database column values 
	private static void validateActualAndExpectedValues(String key,String fileValue,String dbValue,SoftAssert softAssertion,DBUtils objDBUtility) throws Exception {
		
		String fileModifiedValue,dbModifiedValue;
		
		if(fileValue == null){
			fileValue = "[Blank]";
			fileModifiedValue = fileValue;
		}
		if(dbValue == null){
			dbValue = "[Blank]";
			dbModifiedValue = dbValue;
		}
		
		
		//Replacing null values with [Blank] for user understanding
		if(fileValue.toString().trim().equalsIgnoreCase(""))
			fileValue = "[Blank]";
		if(dbValue.toString().trim().equalsIgnoreCase(""))
			dbValue = "[Blank]";
		
		fileModifiedValue = fileValue.trim().toUpperCase();
		dbModifiedValue = dbValue.trim().toUpperCase();
		
		
		
		//To validate CDML_CHG_AMT field
		if(key.equalsIgnoreCase("CDML_CHG_AMT")){
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
		}
		//Error need to handle this with equal logic
		else if (key.contains("IPCD_ID")){
			assertContainLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			
		}
		//To validate PRPR_NAME field
		else if(key.equalsIgnoreCase("PRPR_NAME")){
			
			dbModifiedValue= dbModifiedValue.replace(",", "");
			dbModifiedValue= dbModifiedValue.replace(".", "");
			
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			
		}
		//To validate CLCL_RECD_DT field
		else if(key.equalsIgnoreCase("CLCL_RECD_DT")){
			
			fileModifiedValue = dateAddSub(fileValue,-1);
			
			if(fileModifiedValue.equalsIgnoreCase(dbModifiedValue)){
				 assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			}
			else{
				assertEqualLogger(key,fileValue,dbValue,fileValue,dbValue,softAssertion);
			}
				
		}  
		
		//To validate MECD_MCTR_AIDC1 field
		else if(key.equalsIgnoreCase("MECD_MCTR_AIDC1")){
			
			fileModifiedValue = ("0000" + fileValue).substring(("0000" + fileValue).length() - 4);
			
			if(fileModifiedValue.equalsIgnoreCase(dbModifiedValue)){
				 assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			}
			else{
				assertEqualLogger(key,fileValue,dbValue,fileValue,dbValue,softAssertion);
			}
				
		} 
		
		
			
		//To validate ETHNICITY field
		else if(key.equalsIgnoreCase("MEME_MCTR_ETHN_NVL")){
			String strQuery = "Select distinct FACETS_ETHNIC_CD from CU_ETHNIC_MAP_XREF where EDI_ETHNIC_CD = '" + fileValue + "'";
			List<Map<String,String>> ethinicity = objDBUtility.resultSetToDictionary(strQuery) ;
			fileModifiedValue = ethinicity.get(0).get("FACETS_ETHNIC_CD");
			if(fileModifiedValue == null){
				fileModifiedValue = "[Blank]";
			}	
				if(fileModifiedValue.equalsIgnoreCase(dbModifiedValue)){
					assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileModifiedValue,dbModifiedValue,softAssertion);		 
				}
				else{
					assertEqualLogger(key,fileValue,dbValue,fileValue,dbValue,softAssertion);				
				}
		} 
				
		//To validate CITY field
		else if(key.equalsIgnoreCase("CITY")){
			if(fileModifiedValue.contains(dbModifiedValue)){
				assertContainLogger1(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			}			
		}
		
		
		//To validate Primary County Code field field
		else if(key.equalsIgnoreCase("Primary County_411")){					
			if(fileModifiedValue.contains(dbModifiedValue)){
				if(dbModifiedValue.equals("19") || dbModifiedValue.equals("37"));{
					assertContainLogger1(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
				}
			}
			else
			{
				System.out.println("Invalid County Code");
			}
		}		
		
		//To validate PRPR_ID field
		else if(key.equalsIgnoreCase("PRPR_ID")){
		
			if(fileValue.equalsIgnoreCase("[Blank]")){
				if(!dbValue.equalsIgnoreCase("[Blank]")){
				logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
				}
				else
				{
				logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
				}
			
			}
			else{
				assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
			}
		
		}  

		
		
		//To validate ADDRESS field
		else if(key.equalsIgnoreCase("ADDRESS1") || key.equalsIgnoreCase("ADDRESS2")){
			if(fileModifiedValue.contains(dbModifiedValue)){
				assertContainLogger(key,dbModifiedValue,fileModifiedValue,fileValue,dbValue,softAssertion);
			}
		}
		
		//To compare remaining all field values
		else{
			assertEqualLogger(key,fileModifiedValue,dbModifiedValue,fileValue,dbValue,softAssertion);
		}
	}
	
	
	
	public static String dateAddSub(String strDate, int intDays) throws Exception{
		
		//Specifying date format that matches the given date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar c = Calendar.getInstance();
		try{
		   //Setting the date to the given date
		   c.setTime(sdf.parse(strDate));
		}catch(ParseException e){
			e.printStackTrace();
			return null;
		 }
		   
		//Number of Days to add
		c.add(Calendar.DAY_OF_MONTH, intDays);  
		//Date after adding the days to the given date
		return sdf.format(c.getTime());
	}


	public static void printTestCaseDeatilsInReport(Map<String, String> data) {		
		
		String strSUCName= data.get("SUC Name").toString();		
		String strTestCaseId = data.get("Test Case ID").toString();		
		String strTestCaseName = data.get("Test Case Name").toString();		
		String strStepNumber = data.get("Step Number").toString();
		//String strInputFileName = data.get("Input File Name").toString();
		logger.log(LogStatus.INFO," SUC Name: " + strSUCName + ", Test Case ID: " + strTestCaseId + ", Test Case Name: " + strTestCaseName + ", Step Number:" + strStepNumber);
		//logger.log(LogStatus.INFO," Input File Name: " + strInputFileName);
	}
	
	
	
	public static void assertEqualLogger(String key, String flatFileValue, String dbValue,String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(flatFileValue.equalsIgnoreCase(dbValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");			
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}
	}
	
	public static void assertContainLogger(String key, String flatFileValue, String dbValue, String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(dbValue.contains(flatFileValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}		
	}
	
	public static void assertContainLogger1(String key, String flatFileValue, String dbValue, String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(flatFileValue.contains(dbValue), " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(flatFileValue.contains(dbValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
		}
	}
	
	public static void assertFailLogger(String key, String flatFileValue, String dbValue, String flatFileVOriginalalue, String dbOriginalValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(false, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileVOriginalalue + " | Database value: " + dbOriginalValue + " >>");
	}

	
	//below method is to check whether the given number is numeric or not
		public static boolean isNumeric(String str) {
		    int size = str.length();
		    for (int i = 0; i < size; i++) {
		        if (!Character.isDigit(str.charAt(i))) {
		            return false;
		        }
		    }

		    return size > 0;
		} 
		
	//below method is to handle the index out of bound exception
		public static void partialStringRetrieval(Map<String,String> flatFileValuesMap,String strKeyName,String line,int indexValue, int intStartPos, int intEndingPos){
            try{
                String strValue = line.split("\\*")[indexValue].substring(intStartPos,intEndingPos).replace("~", "").trim();
                if(!(strValue.equalsIgnoreCase(""))){
                       flatFileValuesMap.put(strKeyName, strValue);
                }
                
          }
          catch(Exception e){
                //System.out.println("Flat file value is not present for '" + strKeyName + "' field");
          }

			
		}
		
		
			
}
