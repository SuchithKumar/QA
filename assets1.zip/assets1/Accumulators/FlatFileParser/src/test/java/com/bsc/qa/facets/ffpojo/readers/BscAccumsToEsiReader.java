package com.bsc.qa.facets.ffpojo.readers;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.bsc.qa.facets.ffp.pojo.BscAccumsToEsi.BscAccumsToEsiHeader;
import com.bsc.qa.facets.ffp.pojo.BscAccumsToEsi.BscAccumsToEsiNewBody;
import com.bsc.qa.facets.ffp.pojo.BscAccumsToEsi.BscAccumsToEsiTrailer;

import com.github.ffpojo.exception.FFPojoException;
import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.file.reader.RecordType;

public class BscAccumsToEsiReader {
	
	
	String testFlatFileCompletePath; // <== Path to a test file  
	
	public BscAccumsToEsiReader(String testFlatFileCompletePath) {
		this.testFlatFileCompletePath = testFlatFileCompletePath;
	} //public AshpAccumsToBscaReader(String testFlatFileCompletePath) {

	
	////////////////////////////////FLAT FILE HEADER TO LIST////////////////////
	public List<Map<String, String>> getListOfHeaderValues() throws IOException{
						
		List<Map<String , String>> headersList  = new ArrayList<Map<String,String>>();
		
        File inputFile = new File(testFlatFileCompletePath);
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { // if (!inputFile.exists()) { 
			
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscAccumsToEsiNewBody.class);  // <== BODY
			ffDefinition.setHeader(BscAccumsToEsiHeader.class);
			ffDefinition.setTrailer(BscAccumsToEsiTrailer.class);
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		
			for (Object record : ffReader) {
				
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.HEADER) { //<=== Headers 
					
					Map<String,String> headersMap = new HashMap<String, String>();
					
					//System.out.println("HEADER FOUND: ");
					
					BscAccumsToEsiHeader header = (BscAccumsToEsiHeader)record;
				
					headersMap.put("Processor_Routing_Identification", header.getProcessor_Routing_Identification()); //<== Add 
					headersMap.put("Record_Type", header.getRecord_Type()); //<== Add 
					headersMap.put("Transmission_Type", header.getTransmission_Type()); //<== Add 
					headersMap.put("Creation_Date", header.getCreation_Date()); //<== Add 
					headersMap.put("Creation_Time", header.getCreation_Time()); //<== Add 
					headersMap.put("Sender_ID", header.getSender_ID()); //<== Add 
					headersMap.put("Receiver_ID", header.getReceiver_ID()); //<== Add 
					headersMap.put("Batch_Number", header.getBatch_Number()); //<== Add 
					headersMap.put("File_Type", header.getFile_Type()); //<== Add 
					headersMap.put("Version_Number", header.getVersion_Number()); //<== Add 
					headersMap.put("Reserved", header.getReserved()); //<== Add 
									
					headersList.add(0,headersMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
				    			
				} //if (recordType == RecordType.HEADER)
				
			} // <== for (Object record : ffReader) {
			
			ffReader.close(); //Close Object 
		
		} // if (!inputFile.exists()) { 
	
		return headersList; // method return value 
						
	} // <==  public List<Map<String, String>> getListOfHeaderValues(){
	
	
	////////////////////////////////FLAT FILE BODY TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfBodyValues() throws IOException{
				
		List<Map<String , String>> bodyList  = new ArrayList<Map<String,String>>();
		// get file 
        File inputFile = new File(testFlatFileCompletePath);
    	//test if file exist 
		if (!inputFile.exists()) { 
			//cry if file does not exist 
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { //if (!inputFile.exists()) { 
			// do the magic if file exists 
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscAccumsToEsiNewBody.class);   // <== BODY
			ffDefinition.setHeader(BscAccumsToEsiHeader.class);
			ffDefinition.setTrailer(BscAccumsToEsiTrailer.class);
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		    int counter = 0;
		    
			for (Object record : ffReader) {
				
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.BODY) { //<=== BODY 
					
					Map<String,String> bodyMap = new HashMap<String, String>(); //<== NEW HASH MAP ON EVERY LOOP 
					
					BscAccumsToEsiNewBody body = (BscAccumsToEsiNewBody)record;
				
					bodyMap.put("Processor_Routing_Identification", body.getProcessor_Routing_Identification()); //<== Add 
					bodyMap.put("Record_Type", body.getRecord_Type()); //<== Add 
					bodyMap.put("Transmission_File_Type", body.getTransmission_File_Type()); //<== Add 
					bodyMap.put("Sender_Id", body.getSender_Id()); //<== Add 
					bodyMap.put("Receiver_Id", body.getReceiver_Id()); //<== Add 
					bodyMap.put("Submission_Number", body.getSubmission_Number()); //<== Add 
					bodyMap.put("Reject_Code", body.getReject_Code()); //<== Add 
					bodyMap.put("Record_Length", body.getRecord_Length()); //<== Add 
					bodyMap.put("Transmission_Date", body.getTransmission_Date()); //<== Add 
					bodyMap.put("Transmission_Time", body.getTransmission_Time()); //<== Add 
					bodyMap.put("Date_of_Service", body.getDate_of_Service()); //<== Add 
					bodyMap.put("Service_Provider_ID_Qualifier", body.getService_Provider_ID_Qualifier()); //<== Add 
					bodyMap.put("Service_Provider_ID", body.getService_Provider_ID()); //<== Add 
					bodyMap.put("Document_Reference_Identifier", body.getDocument_Reference_Identifier()); //<== Add 
					bodyMap.put("Transmission_ID", body.getTransmission_ID()); //<== Add 
					bodyMap.put("Benefit_Type", body.getBenefit_Type()); //<== Add
					bodyMap.put("In_Network_Indicator", body.getIn_Network_Indicator());
					bodyMap.put("Formulary_Status", body.getFormulary_Status());
					bodyMap.put("Accumulator_Action_Code", body.getAccumulator_Action_Code());
					bodyMap.put("Benefit_Effective_Date", body.getBenefit_Effective_Date());
					bodyMap.put("Benefit_Termination_Date", body.getBenefit_Termination_Date());
					bodyMap.put("Accumulator_Change_Source_Code", body.getAccumulator_Change_Source_Code());
					bodyMap.put("Transaction_ID", body.getTransaction_ID());
					bodyMap.put("Transaction_ID_Cross_Reference", body.getTransaction_ID_Cross_Reference());
					bodyMap.put("Cardholder_ID", body.getCardholder_ID());
					bodyMap.put("Patient_First_Name", body.getPatient_First_Name());
					bodyMap.put("Patient_Last_Name", body.getPatient_Last_Name());
					bodyMap.put("Patient_Relationship_Code", body.getPatient_Relationship_Code());
					bodyMap.put("Date_of_Birth", body.getDate_of_Birth());
					bodyMap.put("Patient_Gender_Code", body.getPatient_Gender_Code());
					bodyMap.put("Carrier_Number", body.getCarrier_Number());
					bodyMap.put("Contract_Number", body.getContract_Number());
					bodyMap.put("Accumulator_Balance_Count", body.getAccumulator_Balance_Count());
					bodyMap.put("Accumulator_Balance_Qualifier_1", body.getAccumulator_Balance_Qualifier_1());
					bodyMap.put("Accumulator_Network_Indicator_1", body.getAccumulator_Network_Indicator_1());
					bodyMap.put("Accumulator_Applied_Amount_1", body.getAccumulator_Applied_Amount_1());
					bodyMap.put("Action_Code_1", body.getAction_Code_1());
					bodyMap.put("Accumulator_Balance_Qualifier_2", body.getAccumulator_Balance_Qualifier_2());
					bodyMap.put("Accumulator_Network_Indicator_2", body.getAccumulator_Network_Indicator_2());
					bodyMap.put("Accumulator_Applied_Amount_2", body.getAccumulator_Applied_Amount_2());
					bodyMap.put("Action_Code_2", body.getAction_Code_2());
					bodyMap.put("Accumulator_Balance_Qualifier_3", body.getAccumulator_Balance_Qualifier_3());
					bodyMap.put("Accumulator_Network_Indicator_3", body.getAccumulator_Network_Indicator_3());
					bodyMap.put("Accumulator_Applied_Amount_3", body.getAccumulator_Applied_Amount_3());
					bodyMap.put("Action_Code_3", body.getAction_Code_3());
					bodyMap.put("Accumulator_Balance_Qualifier_4", body.getAccumulator_Balance_Qualifier_4());
					bodyMap.put("Accumulator_Network_Indicator_4", body.getAccumulator_Network_Indicator_4());
					bodyMap.put("Accumulator_Applied_Amount_4", body.getAccumulator_Applied_Amount_4());
					bodyMap.put("Action_Code_4", body.getAction_Code_4());
					bodyMap.put("Accumulator_Balance_Qualifier_5", body.getAccumulator_Balance_Qualifier_5());
					bodyMap.put("Accumulator_Network_Indicator_5", body.getAccumulator_Network_Indicator_5());
					bodyMap.put("Accumulator_Applied_Amount_5", body.getAccumulator_Applied_Amount_5());
					bodyMap.put("Action_Code_5", body.getAction_Code_5());	
					bodyMap.put("Accumulator_Balance_Qualifier_6", body.getAccumulator_Balance_Qualifier_6());
					bodyMap.put("Accumulator_Network_Indicator_6", body.getAccumulator_Network_Indicator_6());
					bodyMap.put("Accumulator_Applied_Amount_6", body.getAccumulator_Applied_Amount_6());
					bodyMap.put("Action_Code_6", body.getAction_Code_6());			
					bodyList.add(counter,bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
					counter++;
				    			
				}			
			 } // <== for (Object record : ffReader) {
			
			ffReader.close(); //Close Object 	
			
		} // if (!inputFile.exists()) { 
		
		return bodyList; // method return value 
	
	} // <==  public List<Map<String, String>> getListOfBodyValues(){
	
	
	////////////////////////////////FLAT TRAILER VALUES TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfTrailerValues() throws IOException{
	//return list map 	
    List<Map<String , String>> trailerList  = new ArrayList<Map<String,String>>();

    File inputFile = new File(testFlatFileCompletePath); // <== Import of file under test 

    if (!inputFile.exists()) { 
	
	   throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	
    } else { // if (!inputFile.exists()) {
    	
    	FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscAccumsToEsiNewBody.class);   // <== BODY
        ffDefinition.setHeader(BscAccumsToEsiHeader.class);  ffDefinition.setTrailer(BscAccumsToEsiTrailer.class);

        FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);

        for (Object record : ffReader) {
   	
   	      RecordType recordType = ffReader.getRecordType();
   	
   	      if (recordType == RecordType.TRAILER) { //<=== TRAILER 
   		
   		    Map<String,String> TrailerMap = new HashMap<String, String>();
   		
   		   // System.out.println("Trailer FOUND: ");
   		
   		    BscAccumsToEsiTrailer trailer = (BscAccumsToEsiTrailer)record;
   	
   		    TrailerMap.put("Processor_Routing_Identification", trailer.getProcessor_Routing_Identification()); //<== Add 
   		    TrailerMap.put("Record_Type", trailer.getRecord_Type());
   		    TrailerMap.put("Batch_Number", trailer.getBatch_Number());
   		    TrailerMap.put("Record_Count", trailer.getRecord_Count());
   		    TrailerMap.put("Message", trailer.getMessage());
   		    TrailerMap.put("Reserved", trailer.getReserved());
   		    
   		    trailerList.add(0,TrailerMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
   	    			
   	      }
   	
        } // <== for (Object record : ffReader) {

    ffReader.close(); //Close Object 
    
    } //if (!inputFile.exists()) {

	
     return trailerList; // method return value 
		
	}	// <== public List<Map<String, String>> getListOfTrailerValues(){
	
	
	
//SAMPLE to READ ALL in ONE METHOD NOT USED BY TEST < GOOD FOR DEBUGGING
public void readExtracts() throws IOException, FFPojoException {
		
		File inputFile = new File(testFlatFileCompletePath);
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		}
		
		
		FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscAccumsToEsiNewBody.class);   // <== BODY
		ffDefinition.setHeader(BscAccumsToEsiHeader.class); ffDefinition.setTrailer(BscAccumsToEsiTrailer.class);
		
		FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
	
		for (Object record : ffReader) {
			
			RecordType recordType = ffReader.getRecordType();
			
			if (recordType == RecordType.HEADER) { //<=== Headers 
				
				System.out.print("HEADER FOUND: " + record.hashCode());
				//BscAccumsToCvsHeader header = (BscAccumsToCvsHeader)record;
				//System.out.println(header.getHEADER_INDICATOR());
			
			} else if (recordType == RecordType.BODY) {
				
				//BscAccumsToCvsBody cust = (BscAccumsToCvsBody)record;
				//System.out.println(cust.getMEMBER_FIRST_NAME()+ " " + cust.getMEMBER_LAST_NAME());
			
			} else if (recordType == RecordType.TRAILER) {
				
				//System.out.println("TRAILER FOUND: ");
				//BscAccumsToCvsTrailer trailer = (BscAccumsToCvsTrailer)record;
				//System.out.println(trailer.getTOTAL_AMOUNT());
			}
		
		
		}
		
		ffReader.close();

	}
	
	
	
	

}
