package com.bsc.qa.facets.tests;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.readers.BscAccumsToMHSAReader;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.github.ffpojo.exception.FFPojoException;
import com.relevantcodes.extentreports.LogStatus;

public class BscaAccumsToMHSATest extends BaseTest implements IHookable{

	
   private static int bodyRowsCount;
   private static int limitAndDeductiblebuckets [][]={{1,3,5,12,16,11,18,26,10,14,24},{1,2,3}};
   
    private static BscAccumsToMHSAReader ffpExtract;
    
	private static List<Map<String, String>> testHeader;
	private static List<Map<String, String>> testBody;
	private static List<Map<String, String>> testTrailer;
    
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles", "FileSpecificFolderName"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
        
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
	 	
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		 
		 TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
		 
		 filePAth = tesFile.getCompleteTestFilePath();	 
		 
		 //read flat file before test 
		  ffpExtract = new BscAccumsToMHSAReader(filePAth);
		 
			//Parse headers and store in to testHeaders
			try {
				
				testHeader = ffpExtract.getListOfHeaderValues();
			
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST OF HEADER");
				e.printStackTrace();
			}
			
			//Parse headers and store in to testHeaders
			try {
				
				testBody = ffpExtract.getListOfBodyValues(); // array list of hash map values 
				
				bodyRowsCount = testBody.size(); // body rows count
				
				System.out.println("File message body contains "+ bodyRowsCount +" rows");
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST OF BODY VALUES");
				e.printStackTrace();
			}
			
			
			//Parse headers and store in to testHeaders
			try {
				
				testTrailer = ffpExtract.getListOfTrailerValues();
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST OF TRAILER VALUES");
				e.printStackTrace();
			}
			
			
		 
	}
	
	
	
@Test(enabled = true, dataProvider = "masterDataProvider")
	
	public void testMHSAallHeaderElelemnts(Map<String, String> data) throws FFPojoException, IOException{ 
		
		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		SoftAssert softAssertion= new SoftAssert();
		
	    String SQLQuery = data.get("SQL_MHSA_HEADER_QUERY").toString();

          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;
		     
		     try { //resultSetToArrayList may result in error so it is called in try catch block 
		    	 
		    	 arrayOfDBHashMapVals = objDBUtility.resultSetToArrayList(SQLQuery);
		    	 
		    		for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
		    			
		    			//Gets each key name in the loop
		    			for (String DBkey : DBmap.keySet()) { // 
		    			
		    				System.out.println(DBkey);
		    			    // for each array item of flat file map  
		    				for (Map<String, String> FFmap : testHeader) {
		    					
		    					// Test if DB Key exists in FF ste of Keys 
		    			        if (FFmap.containsKey(DBkey.toUpperCase())) {

		    			            //key exists
		    			            System.out.println("DB Key Found in FF Map -  " + FFmap.get(DBkey));
		    			            
		    			            softAssertion.assertEquals((FFmap.get(DBkey).toString()).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );

		    			        } else {
		    			            //key does not exists report failure 
		    			        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Header Element " + DBkey + " is Required" );
		    			        	System.out.println("Acctual Value: " + (FFmap.get(DBkey)) + " Expected Value: " + (DBmap.get(DBkey)));
		    			        }
		    					
		    				} // for (Map<String, String> FFmap : testHeaders) {
		    			
		    			}//for (String key : map.keySet()) {
		    			
		    			
		    		} // for (Map<String, String> map : testHeaders) {
		    		
		    		//SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		    		softAssertion.assertAll();
		    		
		     } catch (SQLException e) {
					// TODO Auto-generated catch block
		    	 System.out.println("Something went Wrong while getting your db data");
					e.printStackTrace();
				}
	
	}
	
	
	
	/// FILE COMPLETE BODY VALIDATION IN SINGLE TEST METHOD
	@Test(enabled = true, dataProvider = "masterDataProvider")
	public void testMHSAallBODYElelemnts(Map<String, String> data) throws FFPojoException, IOException{ 
		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		SoftAssert softAssertion= new SoftAssert();
		
		//GEt query from data sheet(map), not meme id is not updated
		String strRawSQLQuery = data.get("SQL_MHSA_Body_QUERY").toString();
		//System.out.println(strRawSQLQuery);
	  
		  // declaration of array of hash map 
          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;

		 // for each row of data in flat file output
		 for (Map<String, String> FFmap : testBody) {	
			 
			 System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ NEW BODY ROW ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			
			 //Capture the unique id value of the current row first 
			String strUniqueIDValueOne  = FFmap.get("Record_Type").trim() + FFmap.get("Member_ID").trim() + FFmap.get("First_Name").trim() + FFmap.get("Middle_Name").trim() + FFmap.get("Last_Name").trim() + " ";
			 
			String strUniqueIDValueTwo  = FFmap.get("Gender").trim() + FFmap.get("DOB").trim() + FFmap.get("Accum_Type").trim();
		        	
			   limitBucketsArray_loop: // <== Loop NAME 
			   for(int i=0; i<limitAndDeductiblebuckets.length; i++) {
			       
				   for(int j=0; j<limitAndDeductiblebuckets[i].length; j++) {
			           
			    	   System.out.println("Current Bucket Value at arr["+i+"]["+j+"] is "+limitAndDeductiblebuckets[i][j]);
			       
		    	 // for (int iLimitBucket : limitBucketsArray){
				   
				 	String updatedLimitiBucketdQuery = strRawSQLQuery.replace("INT_BUCKET_VALUE", String.valueOf(limitAndDeductiblebuckets[i][j]));
				 	
			    	// call to query and parse SQL output to and array of HashMap
			    	 arrayOfDBHashMapVals = objDBUtility.getUniqueResultSetToArrayList(updatedLimitiBucketdQuery, strUniqueIDValueOne, strUniqueIDValueTwo);
		    	   
		    	 // for each row of db output 
		    		for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
		    			
		    			//Gets each key name in DB HashMap
		    			for (String DBkey : DBmap.keySet()) { // 
		    			   
		    				//System.out.println("@@ DB Key " + DBkey + " @@@ DB Value " + DBmap.get(DBkey).toString());
		    				 printMapVals(null, DBmap, DBkey );
		    			     
		    				 if ((!DBkey.equals("FIELD1")) && (!DBkey.equals("FIELD2"))) {
		    					 		 	    				
		    					// Test if DB Key exists in FF ste of Keys 
		    			        if (FFmap.containsKey(DBkey)) {

		    			            //key exist
		    			            System.out.println("DB Key Found in FF Map - " + FFmap.get(DBkey));
		    			            
		    			            printMapVals(FFmap, null, DBkey );
		    			            
		    			            softAssertion.assertEquals((FFmap.get(DBkey)).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );

		    			            
		    			            System.out.println("Acctual Value: " + (FFmap.get(DBkey)).trim() + " Expected Value: " + (DBmap.get(DBkey).toString()).trim());
		    			        
		    			        } else {
		    			            //key does not exists report failure 
		    			        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Body Element " + DBkey + " is Required" );
		    			        }
		    			        
		    				 } ///if ((!DBkey.equals( "FIELD1"))  || (!DBkey.equals( "FIELD2"))) {    
		    			  
		    			        
		    			}//for (String key : map.keySet()) {
		    			
		    			
		    		  break limitBucketsArray_loop;	// <== Exit form Limit Bucket loop (// Exit named loop)
		    		  
		    		} // for (Map<String, Object> DBmap : arrayOfDBHashMapVals)  // for each item of DB hash map array 
		    		
			       
				  } // <== for(int j=0; j<limitAndDeductiblebuckets[i].length; j++) { innter loop = dedactible bucket 
				   
			   }  // for(int i=0; i<limitAndDeductiblebuckets.length; i++) { outer loop = limit bucket 
		    				    		
		    //SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		    softAssertion.assertAll();

		 }//for (Map<String, String> FFmap : arrayOfFlatFileHashMap) {	
		
	} // public void testMHSABodyValidation(Map<String, String> data) throws FFPojoException, IOException{ 
	

	

//	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@HEADER TEST METHODS@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

//		
//		
//		///@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Trailer Methods
@Test(enabled = true, dataProvider = "masterDataProvider")
	
	public void testMHSAallTrailerElelemnts(Map<String, String> data) throws FFPojoException, IOException{ 
		
		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		SoftAssert softAssertion= new SoftAssert();
		
	    String SQLQuery = data.get("SQL_MHSA_TRAILER_QUERY").toString();

          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;
		     
		     try { //resultSetToArrayList may result in error so it is called in try catch block 
		    	 
		    	 arrayOfDBHashMapVals = objDBUtility.resultSetToArrayList(SQLQuery);
		    	 
		    		for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
		    			
		    			//Gets each key name in the loop
		    			for (String DBkey : DBmap.keySet()) { // 
		    			
		    				System.out.println(DBkey);
		    			    // for each array item of flat file map  
		    				for (Map<String, String> FFmap : testTrailer) {
		    					
								// Test if DB Key exists in FF ste of Keys 
						        if (FFmap.containsKey(DBkey)) {
						        	

						        	//TOTAL RECORDS VALIDATION
						        	if (DBkey.equals("TOTAL_RECORDS")){
						        		
						        			    			        		
						        		String actualValue = FFmap.get(DBkey).toString().trim();
						        		
						        		//testing the lenth of TOTAL_RECORDS field
						        		softAssertion.assertEquals(actualValue.length(), 9, " Expected lenth of TOTAL_RECORDS is 9 chars long ");
						        		
						        		//remove zeros from 000000005 to 5
						        		actualValue = actualValue.replaceFirst("^0+(?!$)", "");
						        		
						        		//note the conversion of integer value 
						        		softAssertion.assertEquals(actualValue.trim(), (String.valueOf(bodyRowsCount)).trim(), "<<" + DBkey + ">> " );

						        	}else{ // if (DBkey.equals("TOTAL_RECORDS")){

						            //key exists
						            //System.out.println("DB Key Found in FF Map - " + FFmap.get(DBkey));
						            
						            printMapVals(FFmap, null, DBkey );
						            
						            softAssertion.assertEquals((FFmap.get(DBkey).toString()).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );

						            System.out.println("Acctual Value: " + (FFmap.get(DBkey).toString()).trim() + " Expected Value: " + (DBmap.get(DBkey).toString()).trim());
						        
						        	}
						            
						        } else {
						            //key does not exists report failure 
						        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Trailer Element " + DBkey + " is Required" );
						        }
		    					
		    				} // for (Map<String, String> FFmap : testHeaders) {
		    			
		    			}//for (String key : map.keySet()) {
		    			
		    			
		    		} // for (Map<String, String> map : testHeaders) {
		    		
		    		//SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		    		softAssertion.assertAll();
		    		
		     } catch (SQLException e) {
					// TODO Auto-generated catch block
		    	 System.out.println("Something went Wrong while getting your trailer db data");
					e.printStackTrace();
				}
	
	}
//	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@BODY TEST METHODS



//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Test Methods that should be present in every test @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    
private static DBUtils objDBUtility;//Mandatory declaration 
private static String filePAth ;//Mandatory 

//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) {
		Object[][] data = null;
		Map<String, String> dataMap = new HashMap<String, String>();

		dataMap = ExcelUtils.getTestMethodData(method.getName());
		data = new Object[][] { { dataMap } };
		return data;
	}

	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
}