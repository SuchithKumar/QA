package com.bsc.qa.facets.ffp.pojo.BscAccumsToEsi;

public class BscAccumsToEsiTrailer {
	/**
	 * @return the processor_Routing_Identification
	 */
	public String getProcessor_Routing_Identification() {
		return Processor_Routing_Identification;
	}
	/**
	 * @return the record_Type
	 */
	public String getRecord_Type() {
		return Record_Type;
	}
	/**
	 * @return the batch_Number
	 */
	public String getBatch_Number() {
		return Batch_Number;
	}
	/**
	 * @return the record_Count
	 */
	public String getRecord_Count() {
		return Record_Count;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return Message;
	}
	/**
	 * @return the reserved
	 */
	public String getReserved() {
		return Reserved;
	}
	/**
	 * @param processor_Routing_Identification the processor_Routing_Identification to set
	 */
	public void setProcessor_Routing_Identification(
			String processor_Routing_Identification) {
		Processor_Routing_Identification = processor_Routing_Identification;
	}
	/**
	 * @param record_Type the record_Type to set
	 */
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	/**
	 * @param batch_Number the batch_Number to set
	 */
	public void setBatch_Number(String batch_Number) {
		Batch_Number = batch_Number;
	}
	/**
	 * @param record_Count the record_Count to set
	 */
	public void setRecord_Count(String record_Count) {
		Record_Count = record_Count;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		Message = message;
	}
	/**
	 * @param reserved the reserved to set
	 */
	public void setReserved(String reserved) {
		Reserved = reserved;
	}
	private String Processor_Routing_Identification;
	private String Record_Type;
	private String Batch_Number;
	private String Record_Count;
	private String Message;
	private String Reserved;

}
