package com.bsc.qa.facets.ffp.pojo.BscAccumsToEsi;

public class BscAccumsToEsiNewBody {
	//Serhiy TEst
	private String Processor_Routing_Identification;
	private String Record_Type;
	private String Transmission_File_Type;
	private String Sender_Id;
	private String Receiver_Id;
	private String Submission_Number;	
	private String Reject_Code;
	private String Record_Length;
	private String Transmission_Date;
	private String Transmission_Time;
	private String Date_of_Service;
	private String Service_Provider_ID_Qualifier;
	private String Service_Provider_ID;
	private String Document_Reference_Identifier;
	private String Transmission_ID;
	private String Benefit_Type;
	private String In_Network_Indicator;
	private String Formulary_Status;
	private String Accumulator_Action_Code;
	private String Benefit_Effective_Date;
	private String Benefit_Termination_Date;
	private String Accumulator_Change_Source_Code;
	private String Transaction_ID;
	private String Transaction_ID_Cross_Reference;
	private String Cardholder_ID;
	private String Patient_First_Name;
	private String Patient_Last_Name;
	private String Patient_Relationship_Code;
	private String Date_of_Birth;
	private String Patient_Gender_Code;
	private String Carrier_Number;
	private String Contract_Number;
	private String Accumulator_Balance_Count;
	private String Accumulator_Balance_Qualifier_1;
	private String Accumulator_Network_Indicator_1;
	private String Accumulator_Applied_Amount_1;
	private String Action_Code_1;
	private String Accumulator_Balance_Qualifier_2;
	private String Accumulator_Network_Indicator_2;
	private String Accumulator_Applied_Amount_2;
	private String Action_Code_2;
	private String Accumulator_Balance_Qualifier_3;
	private String Accumulator_Network_Indicator_3;
	private String Accumulator_Applied_Amount_3;
	private String Action_Code_3;
	private String Accumulator_Balance_Qualifier_4;
	private String Accumulator_Network_Indicator_4;
	private String Accumulator_Applied_Amount_4;
	private String Action_Code_4;
	private String Accumulator_Balance_Qualifier_5;
	private String Accumulator_Network_Indicator_5;
	private String Accumulator_Applied_Amount_5;
	private String Action_Code_5;
	private String Accumulator_Balance_Qualifier_6;
	private String Accumulator_Network_Indicator_6;
	private String Accumulator_Applied_Amount_6;
	private String Action_Code_6;
	/**
	 * @return the processor_Routing_Identification
	 */
	public String getProcessor_Routing_Identification() {
		return Processor_Routing_Identification;
	}
	/**
	 * @return the record_Type
	 */
	public String getRecord_Type() {
		return Record_Type;
	}
	/**
	 * @return the transmission_File_Type
	 */
	public String getTransmission_File_Type() {
		return Transmission_File_Type;
	}
	/**
	 * @return the sender_Id
	 */
	public String getSender_Id() {
		return Sender_Id;
	}
	/**
	 * @return the receiver_Id
	 */
	public String getReceiver_Id() {
		return Receiver_Id;
	}
	/**
	 * @return the submission_Number
	 */
	public String getSubmission_Number() {
		return Submission_Number;
	}
	/**
	 * @return the reject_Code
	 */
	public String getReject_Code() {
		return Reject_Code;
	}
	/**
	 * @return the record_Length
	 */
	public String getRecord_Length() {
		return Record_Length;
	}
	/**
	 * @return the transmission_Date
	 */
	public String getTransmission_Date() {
		return Transmission_Date;
	}
	/**
	 * @return the transmission_Time
	 */
	public String getTransmission_Time() {
		return Transmission_Time;
	}
	/**
	 * @return the date_of_Service
	 */
	public String getDate_of_Service() {
		return Date_of_Service;
	}
	/**
	 * @return the service_Provider_ID_Qualifier
	 */
	public String getService_Provider_ID_Qualifier() {
		return Service_Provider_ID_Qualifier;
	}
	/**
	 * @return the service_Provider_ID
	 */
	public String getService_Provider_ID() {
		return Service_Provider_ID;
	}
	/**
	 * @return the document_Reference_Identifier
	 */
	public String getDocument_Reference_Identifier() {
		return Document_Reference_Identifier;
	}
	/**
	 * @return the transmission_ID
	 */
	public String getTransmission_ID() {
		return Transmission_ID;
	}
	/**
	 * @return the benefit_Type
	 */
	public String getBenefit_Type() {
		return Benefit_Type;
	}
	/**
	 * @return the in_Network_Indicator
	 */
	public String getIn_Network_Indicator() {
		return In_Network_Indicator;
	}
	/**
	 * @return the formulary_Status
	 */
	public String getFormulary_Status() {
		return Formulary_Status;
	}
	/**
	 * @return the accumulator_Action_Code
	 */
	public String getAccumulator_Action_Code() {
		return Accumulator_Action_Code;
	}
	/**
	 * @return the benefit_Effective_Date
	 */
	public String getBenefit_Effective_Date() {
		return Benefit_Effective_Date;
	}
	/**
	 * @return the benefit_Termination_Date
	 */
	public String getBenefit_Termination_Date() {
		return Benefit_Termination_Date;
	}
	/**
	 * @return the accumulator_Change_Source_Code
	 */
	public String getAccumulator_Change_Source_Code() {
		return Accumulator_Change_Source_Code;
	}
	/**
	 * @return the transaction_ID
	 */
	public String getTransaction_ID() {
		return Transaction_ID;
	}
	/**
	 * @return the transaction_ID_Cross_Reference
	 */
	public String getTransaction_ID_Cross_Reference() {
		return Transaction_ID_Cross_Reference;
	}
	/**
	 * @return the cardholder_ID
	 */
	public String getCardholder_ID() {
		return Cardholder_ID;
	}
	/**
	 * @return the patient_First_Name
	 */
	public String getPatient_First_Name() {
		return Patient_First_Name;
	}
	/**
	 * @return the patient_Last_Name
	 */
	public String getPatient_Last_Name() {
		return Patient_Last_Name;
	}
	/**
	 * @return the patient_Relationship_Code
	 */
	public String getPatient_Relationship_Code() {
		return Patient_Relationship_Code;
	}
	/**
	 * @return the date_of_Birth
	 */
	public String getDate_of_Birth() {
		return Date_of_Birth;
	}
	/**
	 * @return the patient_Gender_Code
	 */
	public String getPatient_Gender_Code() {
		return Patient_Gender_Code;
	}
	/**
	 * @return the carrier_Number
	 */
	public String getCarrier_Number() {
		return Carrier_Number;
	}
	/**
	 * @return the contract_Number
	 */
	public String getContract_Number() {
		return Contract_Number;
	}
	/**
	 * @return the accumulator_Balance_Count
	 */
	public String getAccumulator_Balance_Count() {
		return Accumulator_Balance_Count;
	}
	/**
	 * @return the accumulator_Balance_Qualifier_1
	 */
	public String getAccumulator_Balance_Qualifier_1() {
		return Accumulator_Balance_Qualifier_1;
	}
	/**
	 * @return the accumulator_Network_Indicator_1
	 */
	public String getAccumulator_Network_Indicator_1() {
		return Accumulator_Network_Indicator_1;
	}
	/**
	 * @return the accumulator_Applied_Amount_1
	 */
	public String getAccumulator_Applied_Amount_1() {
		return Accumulator_Applied_Amount_1;
	}
	/**
	 * @return the action_Code_1
	 */
	public String getAction_Code_1() {
		return Action_Code_1;
	}
	/**
	 * @return the accumulator_Balance_Qualifier_2
	 */
	public String getAccumulator_Balance_Qualifier_2() {
		return Accumulator_Balance_Qualifier_2;
	}
	/**
	 * @return the accumulator_Network_Indicator_2
	 */
	public String getAccumulator_Network_Indicator_2() {
		return Accumulator_Network_Indicator_2;
	}
	/**
	 * @return the accumulator_Applied_Amount_2
	 */
	public String getAccumulator_Applied_Amount_2() {
		return Accumulator_Applied_Amount_2;
	}
	/**
	 * @return the action_Code_2
	 */
	public String getAction_Code_2() {
		return Action_Code_2;
	}
	/**
	 * @return the accumulator_Balance_Qualifier_3
	 */
	public String getAccumulator_Balance_Qualifier_3() {
		return Accumulator_Balance_Qualifier_3;
	}
	/**
	 * @return the accumulator_Network_Indicator_3
	 */
	public String getAccumulator_Network_Indicator_3() {
		return Accumulator_Network_Indicator_3;
	}
	/**
	 * @return the accumulator_Applied_Amount_3
	 */
	public String getAccumulator_Applied_Amount_3() {
		return Accumulator_Applied_Amount_3;
	}
	/**
	 * @return the action_Code_3
	 */
	public String getAction_Code_3() {
		return Action_Code_3;
	}
	/**

	/**
	 * @return the accumulator_Balance_Qualifier_4
	 */
	public String getAccumulator_Balance_Qualifier_4() {
		return Accumulator_Balance_Qualifier_4;
	}
	/**
	 * @return the accumulator_Network_Indicator_4
	 */
	public String getAccumulator_Network_Indicator_4() {
		return Accumulator_Network_Indicator_4;
	}
	/**
	 * @return the accumulator_Applied_Amount_4
	 */
	public String getAccumulator_Applied_Amount_4() {
		return Accumulator_Applied_Amount_4;
	}
	/**
	 * @return the action_Code_4
	 */
	public String getAction_Code_4() {
		return Action_Code_4;
	}
	/**
	 * @return the accumulator_Balance_Qualifier_5
	 */
	public String getAccumulator_Balance_Qualifier_5() {
		return Accumulator_Balance_Qualifier_5;
	}
	/**
	 * @return the accumulator_Network_Indicator_5
	 */
	public String getAccumulator_Network_Indicator_5() {
		return Accumulator_Network_Indicator_5;
	}
	/**
	 * @return the accumulator_Applied_Amount_5
	 */
	public String getAccumulator_Applied_Amount_5() {
		return Accumulator_Applied_Amount_5;
	}
	/**
	 * @return the action_Code_5
	 */
	public String getAction_Code_5() {
		return Action_Code_5;
	}
	/**
	 * @return the accumulator_Balance_Qualifier_6
	 */
	public String getAccumulator_Balance_Qualifier_6() {
		return Accumulator_Balance_Qualifier_6;
	}
	/**
	 * @return the accumulator_Network_Indicator_6
	 */
	public String getAccumulator_Network_Indicator_6() {
		return Accumulator_Network_Indicator_6;
	}
	/**
	 * @return the accumulator_Applied_Amount_6
	 */
	public String getAccumulator_Applied_Amount_6() {
		return Accumulator_Applied_Amount_6;
	}
	/**
	 * @return the action_Code_6
	 */
	public String getAction_Code_6() {
		return Action_Code_6;
	}
	/**
	 * @param processor_Routing_Identification the processor_Routing_Identification to set
	 */
	public void setProcessor_Routing_Identification(
			String processor_Routing_Identification) {
		Processor_Routing_Identification = processor_Routing_Identification;
	}
	/**
	 * @param record_Type the record_Type to set
	 */
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	/**
	 * @param transmission_File_Type the transmission_File_Type to set
	 */
	public void setTransmission_File_Type(String transmission_File_Type) {
		Transmission_File_Type = transmission_File_Type;
	}
	/**
	 * @param sender_Id the sender_Id to set
	 */
	public void setSender_Id(String sender_Id) {
		Sender_Id = sender_Id;
	}
	/**
	 * @param receiver_Id the receiver_Id to set
	 */
	public void setReceiver_Id(String receiver_Id) {
		Receiver_Id = receiver_Id;
	}
	/**
	 * @param submission_Number the submission_Number to set
	 */
	public void setSubmission_Number(String submission_Number) {
		Submission_Number = submission_Number;
	}
	/**
	 * @param reject_Code the reject_Code to set
	 */
	public void setReject_Code(String reject_Code) {
		Reject_Code = reject_Code;
	}
	/**
	 * @param record_Length the record_Length to set
	 */
	public void setRecord_Length(String record_Length) {
		Record_Length = record_Length;
	}
	/**
	 * @param transmission_Date the transmission_Date to set
	 */
	public void setTransmission_Date(String transmission_Date) {
		Transmission_Date = transmission_Date;
	}
	/**
	 * @param transmission_Time the transmission_Time to set
	 */
	public void setTransmission_Time(String transmission_Time) {
		Transmission_Time = transmission_Time;
	}
	/**
	 * @param date_of_Service the date_of_Service to set
	 */
	public void setDate_of_Service(String date_of_Service) {
		Date_of_Service = date_of_Service;
	}
	/**
	 * @param service_Provider_ID_Qualifier the service_Provider_ID_Qualifier to set
	 */
	public void setService_Provider_ID_Qualifier(
			String service_Provider_ID_Qualifier) {
		Service_Provider_ID_Qualifier = service_Provider_ID_Qualifier;
	}
	/**
	 * @param service_Provider_ID the service_Provider_ID to set
	 */
	public void setService_Provider_ID(String service_Provider_ID) {
		Service_Provider_ID = service_Provider_ID;
	}
	/**
	 * @param document_Reference_Identifier the document_Reference_Identifier to set
	 */
	public void setDocument_Reference_Identifier(
			String document_Reference_Identifier) {
		Document_Reference_Identifier = document_Reference_Identifier;
	}
	/**
	 * @param transmission_ID the transmission_ID to set
	 */
	public void setTransmission_ID(String transmission_ID) {
		Transmission_ID = transmission_ID;
	}
	/**
	 * @param benefit_Type the benefit_Type to set
	 */
	public void setBenefit_Type(String benefit_Type) {
		Benefit_Type = benefit_Type;
	}
	/**
	 * @param in_Network_Indicator the in_Network_Indicator to set
	 */
	public void setIn_Network_Indicator(String in_Network_Indicator) {
		In_Network_Indicator = in_Network_Indicator;
	}
	/**
	 * @param formulary_Status the formulary_Status to set
	 */
	public void setFormulary_Status(String formulary_Status) {
		Formulary_Status = formulary_Status;
	}
	/**
	 * @param accumulator_Action_Code the accumulator_Action_Code to set
	 */
	public void setAccumulator_Action_Code(String accumulator_Action_Code) {
		Accumulator_Action_Code = accumulator_Action_Code;
	}
	/**
	 * @param benefit_Effective_Date the benefit_Effective_Date to set
	 */
	public void setBenefit_Effective_Date(String benefit_Effective_Date) {
		Benefit_Effective_Date = benefit_Effective_Date;
	}
	/**
	 * @param benefit_Termination_Date the benefit_Termination_Date to set
	 */
	public void setBenefit_Termination_Date(String benefit_Termination_Date) {
		Benefit_Termination_Date = benefit_Termination_Date;
	}
	/**
	 * @param accumulator_Change_Source_Code the accumulator_Change_Source_Code to set
	 */
	public void setAccumulator_Change_Source_Code(
			String accumulator_Change_Source_Code) {
		Accumulator_Change_Source_Code = accumulator_Change_Source_Code;
	}
	/**
	 * @param transaction_ID the transaction_ID to set
	 */
	public void setTransaction_ID(String transaction_ID) {
		Transaction_ID = transaction_ID;
	}
	/**
	 * @param transaction_ID_Cross_Reference the transaction_ID_Cross_Reference to set
	 */
	public void setTransaction_ID_Cross_Reference(
			String transaction_ID_Cross_Reference) {
		Transaction_ID_Cross_Reference = transaction_ID_Cross_Reference;
	}
	/**
	 * @param cardholder_ID the cardholder_ID to set
	 */
	public void setCardholder_ID(String cardholder_ID) {
		Cardholder_ID = cardholder_ID;
	}
	/**
	 * @param patient_First_Name the patient_First_Name to set
	 */
	public void setPatient_First_Name(String patient_First_Name) {
		Patient_First_Name = patient_First_Name;
	}
	/**
	 * @param patient_Last_Name the patient_Last_Name to set
	 */
	public void setPatient_Last_Name(String patient_Last_Name) {
		Patient_Last_Name = patient_Last_Name;
	}
	/**
	 * @param patient_Relationship_Code the patient_Relationship_Code to set
	 */
	public void setPatient_Relationship_Code(String patient_Relationship_Code) {
		Patient_Relationship_Code = patient_Relationship_Code;
	}
	/**
	 * @param date_of_Birth the date_of_Birth to set
	 */
	public void setDate_of_Birth(String date_of_Birth) {
		Date_of_Birth = date_of_Birth;
	}
	/**
	 * @param patient_Gender_Code the patient_Gender_Code to set
	 */
	public void setPatient_Gender_Code(String patient_Gender_Code) {
		Patient_Gender_Code = patient_Gender_Code;
	}
	/**
	 * @param carrier_Number the carrier_Number to set
	 */
	public void setCarrier_Number(String carrier_Number) {
		Carrier_Number = carrier_Number;
	}
	/**
	 * @param contract_Number the contract_Number to set
	 */
	public void setContract_Number(String contract_Number) {
		Contract_Number = contract_Number;
	}
	/**
	 * @param accumulator_Balance_Count the accumulator_Balance_Count to set
	 */
	public void setAccumulator_Balance_Count(String accumulator_Balance_Count) {
		Accumulator_Balance_Count = accumulator_Balance_Count;
	}
	/**
	 * @param accumulator_Balance_Qualifier_1 the accumulator_Balance_Qualifier_1 to set
	 */
	public void setAccumulator_Balance_Qualifier_1(
			String accumulator_Balance_Qualifier_1) {
		Accumulator_Balance_Qualifier_1 = accumulator_Balance_Qualifier_1;
	}
	/**
	 * @param accumulator_Network_Indicator_1 the accumulator_Network_Indicator_1 to set
	 */
	public void setAccumulator_Network_Indicator_1(
			String accumulator_Network_Indicator_1) {
		Accumulator_Network_Indicator_1 = accumulator_Network_Indicator_1;
	}
	/**
	 * @param accumulator_Applied_Amount_1 the accumulator_Applied_Amount_1 to set
	 */
	public void setAccumulator_Applied_Amount_1(String accumulator_Applied_Amount_1) {
		Accumulator_Applied_Amount_1 = accumulator_Applied_Amount_1;
	}
	/**
	 * @param action_Code_1 the action_Code_1 to set
	 */
	public void setAction_Code_1(String action_Code_1) {
		Action_Code_1 = action_Code_1;
	}
	/**
	 * @param accumulator_Balance_Qualifier_2 the accumulator_Balance_Qualifier_2 to set
	 */
	public void setAccumulator_Balance_Qualifier_2(
			String accumulator_Balance_Qualifier_2) {
		Accumulator_Balance_Qualifier_2 = accumulator_Balance_Qualifier_2;
	}
	/**
	 * @param accumulator_Network_Indicator_2 the accumulator_Network_Indicator_2 to set
	 */
	public void setAccumulator_Network_Indicator_2(
			String accumulator_Network_Indicator_2) {
		Accumulator_Network_Indicator_2 = accumulator_Network_Indicator_2;
	}
	/**
	 * @param accumulator_Applied_Amount_2 the accumulator_Applied_Amount_2 to set
	 */
	public void setAccumulator_Applied_Amount_2(String accumulator_Applied_Amount_2) {
		Accumulator_Applied_Amount_2 = accumulator_Applied_Amount_2;
	}
	/**
	 * @param action_Code_2 the action_Code_2 to set
	 */
	public void setAction_Code_2(String action_Code_2) {
		Action_Code_2 = action_Code_2;
	}
	/**
	 * @param accumulator_Balance_Qualifier_3 the accumulator_Balance_Qualifier_3 to set
	 */
	public void setAccumulator_Balance_Qualifier_3(
			String accumulator_Balance_Qualifier_3) {
		Accumulator_Balance_Qualifier_3 = accumulator_Balance_Qualifier_3;
	}
	/**
	 * @param accumulator_Network_Indicator_3 the accumulator_Network_Indicator_3 to set
	 */
	public void setAccumulator_Network_Indicator_3(
			String accumulator_Network_Indicator_3) {
		Accumulator_Network_Indicator_3 = accumulator_Network_Indicator_3;
	}
	/**
	 * @param accumulator_Applied_Amount_3 the accumulator_Applied_Amount_3 to set
	 */
	public void setAccumulator_Applied_Amount_3(String accumulator_Applied_Amount_3) {
		Accumulator_Applied_Amount_3 = accumulator_Applied_Amount_3;
	}
	/**
	 * @param action_Code_3 the action_Code_3 to set
	 */
	public void setAction_Code_3(String action_Code_3) {
		Action_Code_3 = action_Code_3;
	}
	/**
	 * @param accumulator_Benefit_Period_Amount_3 the accumulator_Benefit_Period_Amount_3 to set
	 */

	
	/**
	 * @param accumulator_Balance_Qualifier_4 the accumulator_Balance_Qualifier_4 to set
	 */
	public void setAccumulator_Balance_Qualifier_4(
			String accumulator_Balance_Qualifier_4) {
		Accumulator_Balance_Qualifier_4 = accumulator_Balance_Qualifier_4;
	}
	/**
	 * @param accumulator_Network_Indicator_4 the accumulator_Network_Indicator_4 to set
	 */
	public void setAccumulator_Network_Indicator_4(
			String accumulator_Network_Indicator_4) {
		Accumulator_Network_Indicator_4 = accumulator_Network_Indicator_4;
	}
	/**
	 * @param accumulator_Applied_Amount_4 the accumulator_Applied_Amount_4 to set
	 */
	public void setAccumulator_Applied_Amount_4(String accumulator_Applied_Amount_4) {
		Accumulator_Applied_Amount_4 = accumulator_Applied_Amount_4;
	}
	/**
	 * @param action_Code_4 the action_Code_4 to set
	 */
	public void setAction_Code_4(String action_Code_4) {
		Action_Code_4 = action_Code_4;
	}
	/**
	 * @param accumulator_Balance_Qualifier_5 the accumulator_Balance_Qualifier_5 to set
	 */
	public void setAccumulator_Balance_Qualifier_5(
			String accumulator_Balance_Qualifier_5) {
		Accumulator_Balance_Qualifier_5 = accumulator_Balance_Qualifier_5;
	}
	/**
	 * @param accumulator_Network_Indicator_5 the accumulator_Network_Indicator_5 to set
	 */
	public void setAccumulator_Network_Indicator_5(
			String accumulator_Network_Indicator_5) {
		Accumulator_Network_Indicator_5 = accumulator_Network_Indicator_5;
	}
	/**
	 * @param accumulator_Applied_Amount_5 the accumulator_Applied_Amount_5 to set
	 */
	public void setAccumulator_Applied_Amount_5(String accumulator_Applied_Amount_5) {
		Accumulator_Applied_Amount_5 = accumulator_Applied_Amount_5;
	}
	/**
	 * @param action_Code_5 the action_Code_5 to set
	 */
	public void setAction_Code_5(String action_Code_5) {
		Action_Code_5 = action_Code_5;
	}
	/**
	 * @param accumulator_Balance_Qualifier_6 the accumulator_Balance_Qualifier_6 to set
	 */
	public void setAccumulator_Balance_Qualifier_6(
			String accumulator_Balance_Qualifier_6) {
		Accumulator_Balance_Qualifier_6 = accumulator_Balance_Qualifier_6;
	}
	/**
	 * @param accumulator_Network_Indicator_6 the accumulator_Network_Indicator_6 to set
	 */
	public void setAccumulator_Network_Indicator_6(
			String accumulator_Network_Indicator_6) {
		Accumulator_Network_Indicator_6 = accumulator_Network_Indicator_6;
	}
	/**
	 * @param accumulator_Applied_Amount_6 the accumulator_Applied_Amount_6 to set
	 */
	public void setAccumulator_Applied_Amount_6(String accumulator_Applied_Amount_6) {
		Accumulator_Applied_Amount_6 = accumulator_Applied_Amount_6;
	}
	/**
	 * @param action_Code_6 the action_Code_6 to set
	 */
	public void setAction_Code_6(String action_Code_6) {
		Action_Code_6 = action_Code_6;
	}
	
}