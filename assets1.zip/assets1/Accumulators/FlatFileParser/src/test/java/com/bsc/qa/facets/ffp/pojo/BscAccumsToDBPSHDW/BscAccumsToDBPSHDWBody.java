package com.bsc.qa.facets.ffp.pojo.BscAccumsToDBPSHDW;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscAccumsToDBPSHDWBody {
	private String DETAIL_INDICATOR;
	private String GROUP_ID;
	private String SUBSCRIBER_NUMBER;
	private String RELATIONSHIP_CODE;
	private String MEMBER_IDENTIFICATION_NUMBER;
	private String GENDER;
	private String MEMBER_LAST_NAME;
	private String MEMBER_FIRST_NAME	;
	private String MEMBER_MIDDLE_INIT;
	private String MEMBER_DOB;
	private String CLAIM_REFERENCE_NUMBER;
	private String DATE_OF_SERVICE;
	private String INPATIENT_OUTPATIENT;
	private String BENEFIT_LEVEL;
	private String PLAN_CODE;
	private String BENEFIT_CATEGORY;
	private String POLICY_HOLDER_ID;
	private String BILLED_AMT;
	private String ALLOWED_AMT;
	private String NOT_COVERED_AMT;
	private String NET_AMT;
	private String SHDW_ACCUMULATOR_TYPE;
	private String SHDW_ACCUMULATOR_AMT;
		private String BENEFIT_YEAR;
	private String FILLER;
	/**
	 * @return the dETAIL_INDICATOR
	 */
	public String getDETAIL_INDICATOR() {
		return DETAIL_INDICATOR;
	}
	/**
	 * @param dETAIL_INDICATOR the dETAIL_INDICATOR to set
	 */
	public void setDETAIL_INDICATOR(String dETAIL_INDICATOR) {
		DETAIL_INDICATOR = dETAIL_INDICATOR;
	}
	/**
	 * @return the gROUP_ID
	 */
	public String getGROUP_ID() {
		return GROUP_ID;
	}
	/**
	 * @param gROUP_ID the gROUP_ID to set
	 */
	public void setGROUP_ID(String GROUP_ID) {
		this.GROUP_ID = GROUP_ID;
	}
	/**
	 * @return the sUBSCRIBER_NUMBER
	 */
	public String getSUBSCRIBER_NUMBER() {
		return SUBSCRIBER_NUMBER;
	}
	/**
	 * @param sUBSCRIBER_NUMBER the sUBSCRIBER_NUMBER to set
	 */
	public void setSUBSCRIBER_NUMBER(String SUBSCRIBER_NUMBER) {
		this.SUBSCRIBER_NUMBER = SUBSCRIBER_NUMBER;
	}
	/**
	 * @return the rELATIONSHIP_CODE
	 */
	public String getRELATIONSHIP_CODE() {
		return RELATIONSHIP_CODE;
	}
	/**
	 * @param rELATIONSHIP_CODE the rELATIONSHIP_CODE to set
	 */
	public void setRELATIONSHIP_CODE(String rELATIONSHIP_CODE) {
		RELATIONSHIP_CODE = rELATIONSHIP_CODE;
	}
	/**
	 * @return the mEMBER_IDENTIFICATION_NUMBER
	 */
	public String getMEMBER_IDENTIFICATION_NUMBER() {
		return MEMBER_IDENTIFICATION_NUMBER;
	}
	/**
	 * @param mEMBER_IDENTIFICATION_NUMBER the mEMBER_IDENTIFICATION_NUMBER to set
	 */
	public void setMEMBER_IDENTIFICATION_NUMBER(String mEMBER_IDENTIFICATION_NUMBER) {
		MEMBER_IDENTIFICATION_NUMBER = mEMBER_IDENTIFICATION_NUMBER;
	}
	/**
	 * @return the gENDER
	 */
	public String getGENDER() {
		return GENDER;
	}
	/**
	 * @param gENDER the gENDER to set
	 */
	public void setGENDER(String gENDER) {
		GENDER = gENDER;
	}
	/**
	 * @return the mEMBER_LAST_NAME
	 */
	public String getMEMBER_LAST_NAME() {
		return MEMBER_LAST_NAME;
	}
	/**
	 * @param mEMBER_LAST_NAME the mEMBER_LAST_NAME to set
	 */
	public void setMEMBER_LAST_NAME(String mEMBER_LAST_NAME) {
		MEMBER_LAST_NAME = mEMBER_LAST_NAME;
	}
	/**
	 * @return the mEMBER_FIRST_NAME
	 */
	public String getMEMBER_FIRST_NAME() {
		return MEMBER_FIRST_NAME;
	}
	/**
	 * @param mEMBER_FIRST_NAME the mEMBER_FIRST_NAME to set
	 */
	public void setMEMBER_FIRST_NAME(String mEMBER_FIRST_NAME) {
		MEMBER_FIRST_NAME = mEMBER_FIRST_NAME;
	}
	/**
	 * @return the mEMBER_MIDDLE_INIT
	 */
	public String getMEMBER_MIDDLE_INIT() {
		return MEMBER_MIDDLE_INIT;
	}
	/**
	 * @param mEMBER_MIDDLE_INIT the mEMBER_MIDDLE_INIT to set
	 */
	public void setMEMBER_MIDDLE_INIT(String mEMBER_MIDDLE_INIT) {
		MEMBER_MIDDLE_INIT = mEMBER_MIDDLE_INIT;
	}
	/**
	 * @return the mEMBER_DOB
	 */
	public String getMEMBER_DOB() {
		return MEMBER_DOB;
	}
	/**
	 * @param mEMBER_DOB the mEMBER_DOB to set
	 */
	public void setMEMBER_DOB(String mEMBER_DOB) {
		MEMBER_DOB = mEMBER_DOB;
	}
	/**
	 * @return the cLAIM_REFERENCE_NUMBER
	 */
	public String getCLAIM_REFERENCE_NUMBER() {
		return CLAIM_REFERENCE_NUMBER;
	}
	/**
	 * @param cLAIM_REFERENCE_NUMBER the cLAIM_REFERENCE_NUMBER to set
	 */
	public void setCLAIM_REFERENCE_NUMBER(String cLAIM_REFERENCE_NUMBER) {
		CLAIM_REFERENCE_NUMBER = cLAIM_REFERENCE_NUMBER;
	}
	/**
	 * @return the dATE_OF_SERVICE
	 */
	public String getDATE_OF_SERVICE() {
		return DATE_OF_SERVICE;
	}
	/**
	 * @param dATE_OF_SERVICE the dATE_OF_SERVICE to set
	 */
	public void setDATE_OF_SERVICE(String dATE_OF_SERVICE) {
		DATE_OF_SERVICE = dATE_OF_SERVICE;
	}
	/**
	 * @return the iNPATIENT_OUTPATIENT
	 */
	public String getINPATIENT_OUTPATIENT() {
		return INPATIENT_OUTPATIENT;
	}
	/**
	 * @param iNPATIENT_OUTPATIENT the iNPATIENT_OUTPATIENT to set
	 */
	public void setINPATIENT_OUTPATIENT(String iNPATIENT_OUTPATIENT) {
		INPATIENT_OUTPATIENT = iNPATIENT_OUTPATIENT;
	}
	/**
	 * @return the bENEFIT_LEVEL
	 */
	public String getBENEFIT_LEVEL() {
		return BENEFIT_LEVEL;
	}
	/**
	 * @param bENEFIT_LEVEL the bENEFIT_LEVEL to set
	 */
	public void setBENEFIT_LEVEL(String bENEFIT_LEVEL) {
		BENEFIT_LEVEL = bENEFIT_LEVEL;
	}
	/**
	 * @return the pLAN_CODE
	 */
	public String getPLAN_CODE() {
		return PLAN_CODE;
	}
	/**
	 * @param pLAN_CODE the pLAN_CODE to set
	 */
	public void setPLAN_CODE(String pLAN_CODE) {
		PLAN_CODE = pLAN_CODE;
	}
	/**
	 * @return the bENEFIT_CATEGORY
	 */
	public String getBENEFIT_CATEGORY() {
		return BENEFIT_CATEGORY;
	}
	/**
	 * @param bENEFIT_CATEGORY the bENEFIT_CATEGORY to set
	 */
	public void setBENEFIT_CATEGORY(String bENEFIT_CATEGORY) {
		BENEFIT_CATEGORY = bENEFIT_CATEGORY;
	}
	/**
	 * @return the pOLICY_HOLDER_ID
	 */
	public String getPOLICY_HOLDER_ID() {
		return POLICY_HOLDER_ID;
	}
	/**
	 * @param pOLICY_HOLDER_ID the pOLICY_HOLDER_ID to set
	 */
	public void setPOLICY_HOLDER_ID(String pOLICY_HOLDER_ID) {
		POLICY_HOLDER_ID = pOLICY_HOLDER_ID;
	}
	/**
	 * @return the bILLED_AMT
	 */
	public String getBILLED_AMT() {
		return BILLED_AMT;
	}
	/**
	 * @param bILLED_AMT the bILLED_AMT to set
	 */
	public void setBILLED_AMT(String bILLED_AMT) {
		BILLED_AMT = bILLED_AMT;
	}
	/**
	 * @return the aLLOWED_AMT
	 */
	public String getALLOWED_AMT() {
		return ALLOWED_AMT;
	}
	/**
	 * @param aLLOWED_AMT the aLLOWED_AMT to set
	 */
	public void setALLOWED_AMT(String aLLOWED_AMT) {
		ALLOWED_AMT = aLLOWED_AMT;
	}
	/**
	 * @return the nOT_COVERED_AMT
	 */
	public String getNOT_COVERED_AMT() {
		return NOT_COVERED_AMT;
	}
	/**
	 * @param nOT_COVERED_AMT the nOT_COVERED_AMT to set
	 */
	public void setNOT_COVERED_AMT(String nOT_COVERED_AMT) {
		NOT_COVERED_AMT = nOT_COVERED_AMT;
	}
	/**
	 * @return the nET_AMT
	 */
	public String getNET_AMT() {
		return NET_AMT;
	}
	/**
	 * @param nET_AMT the nET_AMT to set
	 */
	public void setNET_AMT(String nET_AMT) {
		NET_AMT = nET_AMT;
	}
	
	/**
	 * @return the aCCUMULATOR_AMT
	 */
	public String getSHDW_ACCUMULATOR_AMT() {
		return SHDW_ACCUMULATOR_AMT;
	}
	/**
	 * @param aCCUMULATOR_AMT the aCCUMULATOR_AMT to set
	 */
	public void setSHDW_ACCUMULATOR_AMT(String sHDW_ACCUMULATOR_AMT) {
		SHDW_ACCUMULATOR_AMT = sHDW_ACCUMULATOR_AMT;
	}
	/**
	 * @return the bENEFIT_YEAR
	 */
	public String getBENEFIT_YEAR() {
		return BENEFIT_YEAR;
	}
	/**
	 * @param bENEFIT_YEAR the bENEFIT_YEAR to set
	 */
	public void setBENEFIT_YEAR(String bENEFIT_YEAR) {
		BENEFIT_YEAR = bENEFIT_YEAR;
	}
	/**
	 * @return the fILLER
	 */
	public String getFILLER() {
		return FILLER;
	}
	/**
	 * @param fILLER the fILLER to set
	 */
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public String getSHDW_ACCUMULATOR_TYPE() {
		return SHDW_ACCUMULATOR_TYPE;
	}
	public void setSHDW_ACCUMULATOR_TYPE(String sHDW_ACCUMULATOR_TYPE) {
		SHDW_ACCUMULATOR_TYPE = sHDW_ACCUMULATOR_TYPE;
	}}

