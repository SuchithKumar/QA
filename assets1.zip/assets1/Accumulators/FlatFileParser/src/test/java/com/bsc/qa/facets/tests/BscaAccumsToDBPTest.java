package com.bsc.qa.facets.tests;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.readers.BscAccumsToDBPReader;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.github.ffpojo.exception.FFPojoException;
import com.relevantcodes.extentreports.LogStatus;

public class BscaAccumsToDBPTest extends BaseTest implements IHookable{
	
	
	private static String strMember_ID;
	private static int bodyRowsCount;
	
    private static BscAccumsToDBPReader ffpExtract;
    
	private static List<Map<String, String>> testHeader;
	private static List<Map<String, String>> testBody;
	private static List<Map<String, String>> testTrailer;
	
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles", "FileSpecificFolderName"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
        
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
	 	
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		 
		 TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
		 
		 filePAth = tesFile.getCompleteTestFilePath();	 
		 
		 //read flat file before test 
		  ffpExtract = new BscAccumsToDBPReader(filePAth);
		 
			//Parse headers and store in to testHeader
			try {
				
				testHeader = ffpExtract.getListOfHeaderValues();
			
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			//Parse headers and store in to testHeader
			try {
				
				testBody = ffpExtract.getListOfBodyValues(); // array list of hash map values 
				
				bodyRowsCount = testBody.size(); // body rows count
				
				System.out.println("File message body contains "+ bodyRowsCount +" rows");
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			
			//Parse headers and store in to testHeader
			try {
				
				testTrailer = ffpExtract.getListOfTrailerValues();
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			
		 
	}
	
	
	
	@Test(enabled = true,priority = 2, dataProvider = "masterDataProvider")
	
	public void OutboundDBPHeaderReqElementsValidation(Map<String, String> data) throws FFPojoException, IOException{ 
		
		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		SoftAssert softAssertion= new SoftAssert();
		
	    String SQLQuery = data.get("SQL_Header").toString();

          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;
		     
		     try { //resultSetToArrayList may result in error so it is called in try catch block 
		    	 
		    	 arrayOfDBHashMapVals = objDBUtility.resultSetToArrayList(SQLQuery);
		    	 
		    		for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
		    			
		    			//Gets each key name in the loop
		    			for (String DBkey : DBmap.keySet()) { // 
		    			
		    				System.out.println(DBkey);
		    			    // for each array item of flat file map  
		    				for (Map<String, String> FFmap : testHeader) {
		    					
		    					// Test if DB Key exists in FF ste of Keys 
		    			        if (FFmap.containsKey(DBkey)) {

		    			            //key exists
		    			            System.out.println("DB Key Found in FF Map -  " + FFmap.get(DBkey));
		    			            
		    			            softAssertion.assertEquals((FFmap.get(DBkey).toString()).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );

		    			        } else {
		    			            //key does not exists report failure 
		    			        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Header Element " + DBkey + " is Required" );
		    			        	System.out.println("Acctual Value: " + (FFmap.get(DBkey).toString()).trim() + " Expected Value: " + (DBmap.get(DBkey).toString()).trim());
		    			        }
		    					
		    				} // for (Map<String, String> FFmap : testHeader) {
		    			
		    			}//for (String key : map.keySet()) {
		    			
		    			
		    		} // for (Map<String, String> map : testHeader) {
		    		
		    		//SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		    		softAssertion.assertAll();
		    		
		     } catch (SQLException e) {
					// TODO Auto-generated catch block
		    	 System.out.println("Something went Wrong while getting you db data");
					e.printStackTrace();
				}
	
	}	
	
	@Test(enabled = true, priority = 3, dataProvider = "masterDataProvider")
	public void OutboundDBPBodyReqElementsValidation(Map<String, String> data) throws FFPojoException, IOException{ 
		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		SoftAssert softAssertion= new SoftAssert();
		
		//GEt query from data sheet(map), not meme id is not updated
		String strRawSQLQuery = data.get("SQL_Body").toString();
		
		  // print out row count
		  System.out.println("File message body contains "+ bodyRowsCount +" rows");
		  
		  // declaration of array of hash map 
          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;

		 // for each row of data in flat file output
		 for (Map<String, String> FFmap : testBody) {			
			
			 //Capture the unique id value of the current row first 
			 strMember_ID = FFmap.get("MEMBER_ID");
			 
			 String Accum_Code = FFmap.get("ACCUMULATION_CODE");
		        	
			 // call to query and parse SQL output to and array of HashMap
			 arrayOfDBHashMapVals = objDBUtility.getUniqueResultSetToArrayList(strRawSQLQuery, strMember_ID, Accum_Code);
			 
			 // test for records set count , number of records from db should match to number of records in file (Important to understand that record set  = 1 row of data, not map key)
			 
			  softAssertion.assertEquals(bodyRowsCount, arrayOfDBHashMapVals.size(), "Recods verification, flat file records set vs database records set: "); 

			   
			 // for each row of db output 
				for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
					
					//Gets each key name in DB HashMap
					for (String DBkey : DBmap.keySet()) { // 
					   
						//System.out.println("@@ DB Key " + DBkey + " @@@ DB Value " + DBmap.get(DBkey).toString());
						 printMapVals(null, DBmap, DBkey );
					    
							// Test if DB Key exists in FF ste of Keys 
					        if (FFmap.containsKey(DBkey)) {

					            //key exist
					            System.out.println("DB Key Found in FF Map - " + FFmap.get(DBkey));
					            
					            printMapVals(FFmap, null, DBkey );
					            
					            softAssertion.assertEquals((FFmap.get(DBkey).toString()).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );

					            
					            System.out.println("Acctual Value: " + (FFmap.get(DBkey).toString()).trim() + " Expected Value: " + (DBmap.get(DBkey).toString()).trim());
					        
					        } else {
					            //key does not exists report failure 
					        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Body Element " + DBkey + " is Required" );
					        }
					
					}//for (String key : map.keySet()) {
					
					
				} // for (Map<String, String> map : testBody) {
				
				//SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
				softAssertion.assertAll();

		 }//for (Map<String, String> FFmap : testBody) {	
		
	}
	
	
	@Test(enabled = true, priority = 6, dataProvider = "masterDataProvider")
	public void OutboundDBPFooterElementsValidation(Map<String, String> data) throws FFPojoException, IOException{ 
		//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
		SoftAssert softAssertion= new SoftAssert();
		
		// the name of element in the file that contains  row unique id value.
		//final String "MEMBER_ID" = "MEMBER_ID"; //Absolutely  must match to the name from ffpojo-ifm.xml
				
		//Get query from data sheet(map)
		String strRawSQLQuery = data.get("SQL_Trailer").toString();

		  // declaration of array of hash map 
          ArrayList<Map<String, Object>> arrayOfDBHashMapVals;

		 // for each row of data in flat file output
		 for (Map<String, String> FFmap : testTrailer) {			
					        	
			 // call to query and parse SQL output to and array of HashMap
			 arrayOfDBHashMapVals = objDBUtility.getUniqueResultSetToArrayList(strRawSQLQuery, strMember_ID, null);
			   
			 // for each row of db output 
				for (Map<String, Object> DBmap : arrayOfDBHashMapVals) { // for each item of DB hash map array  
					
					//Gets each key name in DB HashMap
					for (String DBkey : DBmap.keySet()) { // 
					   
						//System.out.println("@@ DB Key " + DBkey + " @@@ DB Value " + DBmap.get(DBkey).toString());
						 
						  printMapVals(null, DBmap, DBkey );
						
							// Test if DB Key exists in FF ste of Keys 
					        if (FFmap.containsKey(DBkey)) {
					        	

					        	//TOTAL RECORDS VALIDATION
					        	if (DBkey.equals("TOTAL_RECORDS")){
					        		
					        			    			        		
					        		String actualValue = FFmap.get(DBkey).toString().trim();
					        		
					        		//testing the lenth of TOTAL_RECORDS field
					        		softAssertion.assertEquals(actualValue.length(), 9, " Expected lenth of TOTAL_RECORDS is 9 chars long ");
					        		//remove zeros from 000000005 to 5
					        		actualValue = actualValue.replaceFirst("^0+(?!$)", "");
					        		 //note the conversion of integer value 
					        		  softAssertion.assertEquals(actualValue.trim(), (String.valueOf(bodyRowsCount)).trim(), "<<" + DBkey + ">> " );

					        	}else{ // if (DBkey.equals("TOTAL_RECORDS")){

					            //key exists
					            //System.out.println("DB Key Found in FF Map - " + FFmap.get(DBkey));
					            
					            printMapVals(FFmap, null, DBkey );
					            
					            softAssertion.assertEquals((FFmap.get(DBkey).toString()).trim(), (DBmap.get(DBkey).toString()).trim(), "<<" + DBkey + ">> " );

					            System.out.println("Acctual Value: " + (FFmap.get(DBkey).toString()).trim() + " Expected Value: " + (DBmap.get(DBkey).toString()).trim());
					        
					        	}
					            
					        } else {
					            //key does not exists report failure 
					        	softAssertion.assertTrue(FFmap.containsKey(DBkey), "Expected Body Element " + DBkey + " is Required" );
					        }
					
					}//for (String key : map.keySet()) {
					
					
				} // for (Map<String, String> map : testTrailer) {
				
				//SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
				softAssertion.assertAll();

		 }//for (Map<String, String> FFmap : testBody) {	
		
	}
	
		
	
	
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 3 Test Methods that should be present in every test @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 3 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	    
	
	private static DBUtils objDBUtility;//Mandatory declaration 
	private static String filePAth ;//Mandatory 

	//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
	//private static SoftAssert softAssertion= new SoftAssert();

	     /**
		 * @Override run is a hook before @Test method
		 */
		@Override
		public void run(IHookCallBack callBack, ITestResult testResult) {	
			reportInit(testResult.getTestContext().getName(), testResult.getName());
			softAssert = new SoftAssert();
			logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
			callBack.runTestMethod(testResult);	
			softAssert.assertAll();				
		}	
		
		@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
		private static Object[][] getData(Method method) {
			Object[][] data = null;
			Map<String, String> dataMap = new HashMap<String, String>();

			dataMap = ExcelUtils.getTestMethodData(method.getName());
			data = new Object[][] { { dataMap } };
			return data;
		}
		
		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 3 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
}
