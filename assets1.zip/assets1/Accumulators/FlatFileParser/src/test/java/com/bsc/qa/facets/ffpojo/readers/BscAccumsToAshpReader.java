package com.bsc.qa.facets.ffpojo.readers;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.bsc.qa.facets.ffp.pojo.BscShdwAccumsToAshp.*;

import com.github.ffpojo.exception.FFPojoException;
import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.file.reader.RecordType;

public class BscAccumsToAshpReader{
	
	
	String testFlatFileCompletePath; // <== Path to a test file  
	
	public BscAccumsToAshpReader(String testFlatFileCompletePath) {
		this.testFlatFileCompletePath = testFlatFileCompletePath;
	} //public AshpAccumsToBscaReader(String testFlatFileCompletePath) {

	
	////////////////////////////////FLAT FILE HEADER TO LIST////////////////////
	public List<Map<String, String>> getListOfHeaderValues() throws IOException{
						
		List<Map<String , String>> headersList  = new ArrayList<Map<String,String>>();
		
        File inputFile = new File(testFlatFileCompletePath);
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { // if (!inputFile.exists()) { 
			
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscShdwAccumsToAshpBody.class);   // <== BODY
			ffDefinition.setHeader(BscShdwAccumsToAshpHeader.class); ffDefinition.setTrailer(BscShdwAccumsToAshpTrailer.class);
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		
			for (Object record : ffReader) {
				
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.HEADER) { //<=== Headers 
					
					Map<String,String> headersMap = new HashMap<String, String>();
					
					//System.out.println("HEADER FOUND: ");
					
					BscShdwAccumsToAshpHeader header = (BscShdwAccumsToAshpHeader)record;
				
				    headersMap.put("Record_Type".toUpperCase(), header.getRecord_Type()); //<== Add
					headersMap.put("Filler_Unused1".toUpperCase(), header.getFiller_Unused1()); //<== Add
					headersMap.put("Company_Name".toUpperCase(), header.getCompany_Name()); //<== Add
					headersMap.put("Creation_Date".toUpperCase(), header.getCreation_Date()); //<== Add
					headersMap.put("Filler_Unused2".toUpperCase(), header.getFiller_Unused2()); //<== Add
					headersMap.put("Frequency".toUpperCase(), header.getFrequency()); //<== Add
					headersMap.put("Company_Control_Code".toUpperCase(), header.getCompany_Control_Code()); //<== Add
					headersMap.put("Filler".toUpperCase(), header.getFiller()); //<== Add
 										
					headersList.add(0,headersMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
				    			
				} //if (recordType == RecordType.HEADER)
				
			} // <== for (Object record : ffReader) {
			
			ffReader.close(); //Close Object 
		
		} // if (!inputFile.exists()) { 
	
		return headersList; // method return value 
						
	} // <==  public List<Map<String, String>> getListOfHeaderValues(){
	
	
	/// TO DO: Finish BODY and Trailer Serhiy
	
	////////////////////////////////FLAT FILE BODY TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfBodyValues() throws IOException{
				
		List<Map<String , String>> bodyList  = new ArrayList<Map<String,String>>();
		// get file 
        File inputFile = new File(testFlatFileCompletePath);
    	//test if file exist 
		if (!inputFile.exists()) { 
			//cry if file does not exist 
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { //if (!inputFile.exists()) { 
			// do the magic if file exists 
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscShdwAccumsToAshpBody.class);   // <== BODY
			ffDefinition.setHeader(BscShdwAccumsToAshpHeader.class); ffDefinition.setTrailer(BscShdwAccumsToAshpTrailer.class);
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		    int counter = 0;
		    
			for (Object record : ffReader) {
				
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.BODY) { //<=== BODY 
					
					Map<String,String> bodyMap = new HashMap<String, String>(); //<== NEW HASH MAP ON EVERY LOOP 
					
					BscShdwAccumsToAshpBody body = (BscShdwAccumsToAshpBody)record;
				
					bodyMap.put("Record_Type".toUpperCase(), body.getRecord_Type()); //<== Add
					bodyMap.put("Member_ID_Patient".toUpperCase(), body.getMember_ID_Patient()); //<== Add
					bodyMap.put("First_Name".toUpperCase(), body.getFirst_Name()); //<== Add
					bodyMap.put("Middle_Name".toUpperCase(), body.getMember_ID_Patient()); //<== Add
					bodyMap.put("Last_Name".toUpperCase(), body.getLast_Name()); //<== Add
					bodyMap.put("Gender".toUpperCase(), body.getGender()); //<== Add
					bodyMap.put("DOB".toUpperCase(), body.getDOB()); //<== Add
					bodyMap.put("Type_of_accumulator".toUpperCase(), body.getType_of_accumulator()); //<== Add
					bodyMap.put("Filler_Unused1".toUpperCase(), body.getFiller_Unused1()); //<== Add
					bodyMap.put("Accumulator_start_date".toUpperCase(), body.getAccumulator_start_date()); //<== Add
					bodyMap.put("Accumulator_end_date".toUpperCase(), body.getAccumulator_end_date()); //<== Add
					bodyMap.put("Accumulator_dollar_amount".toUpperCase(), body.getAccumulator_dollar_amount()); //<== Add
					bodyMap.put("Filler_Unused2".toUpperCase(), body.getFiller_Unused2()); //<== Add

					bodyList.add(counter,bodyMap); //<== Put Hash Map to Array List. 
					counter++;
				    			
				}			
			 } // <== for (Object record : ffReader) {
			
			ffReader.close(); //Close Object 	
			
		} // if (!inputFile.exists()) { 
		
		return bodyList; // method return value 
	
	} // <==  public List<Map<String, String>> getListOfBodyValues(){
	
	
	////////////////////////////////FLAT TRAILER VALUES TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfTrailerValues() throws IOException{
	//return list map 	
    List<Map<String , String>> trailerList  = new ArrayList<Map<String,String>>();

    File inputFile = new File(testFlatFileCompletePath); // <== Import of file under test 

    if (!inputFile.exists()) { 
	
	   throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	
    } else { // if (!inputFile.exists()) {
    	
    	FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscShdwAccumsToAshpBody.class);   // <== BODY
		ffDefinition.setHeader(BscShdwAccumsToAshpHeader.class); ffDefinition.setTrailer(BscShdwAccumsToAshpTrailer.class);

        FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);

        for (Object record : ffReader) {
   	
   	      RecordType recordType = ffReader.getRecordType();
   	
   	      if (recordType == RecordType.TRAILER) { //<=== TRAILER 
   		
   		    Map<String,String> TrailerMap = new HashMap<String, String>();
   		
   		   // System.out.println("Trailer FOUND: ");
   		
   		 BscShdwAccumsToAshpTrailer trailer = (BscShdwAccumsToAshpTrailer)record;
   	
   		  TrailerMap.put("Record_Type".toUpperCase(), trailer.getRecord_Type()); //<== Add
   		  TrailerMap.put("Filler_Unused1".toUpperCase(), trailer.getFiller_Unused1()); //<== Add
   		  TrailerMap.put("Total_Records_On_File".toUpperCase(), trailer.getTotal_Records_On_File()); //<== Add
   		  TrailerMap.put("Total_Dollar_Amount".toUpperCase(), trailer.getTotal_Dollar_Amount()); //<== Add
   		  TrailerMap.put("Filler_Unused2".toUpperCase(), trailer.getFiller_Unused2()); //<== Add
 		 
   						
   		  trailerList.add(0,TrailerMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
   	    			
   	      }
   	
        } // <== for (Object record : ffReader) {

    ffReader.close(); //Close Object 
    
    } //if (!inputFile.exists()) {

	
     return trailerList; // method return value 
		
	}	// <== public List<Map<String, String>> getListOfTrailerValues(){
	
	
	
//SAMPLE to READ ALL in ONE METHOD NOT USED BY TEST < GOOD FOR DEBUGGING
public void readExtracts() throws IOException, FFPojoException {
		
		File inputFile = new File(testFlatFileCompletePath);
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		}
		
		
		FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscShdwAccumsToAshpBody.class);   // <== BODY
		ffDefinition.setHeader(BscShdwAccumsToAshpHeader.class); ffDefinition.setTrailer(BscShdwAccumsToAshpTrailer.class);
		
		FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
	
		for (Object record : ffReader) {
			
			RecordType recordType = ffReader.getRecordType();
			
			if (recordType == RecordType.HEADER) { //<=== Headers 
				
				System.out.print("HEADER FOUND: " + record.hashCode());
				//BscAccumsToDBPSHDWHeader header = (BscAccumsToDBPSHDWHeader)record;
				//System.out.println(header.getHEADER_INDICATOR());
			
			} else if (recordType == RecordType.BODY) {
				
				//BscAccumsToDBPSHDWBody cust = (BscAccumsToDBPSHDWBody)record;
				//System.out.println(cust.getMEMBER_FIRST_NAME()+ " " + cust.getMEMBER_LAST_NAME());
			
			} else if (recordType == RecordType.TRAILER) {
				
				//System.out.println("TRAILER FOUND: ");
				//BscAccumsToDBPSHDWHeader trailer = (BscAccumsToDBPSHDWHeader)record;
				//System.out.println(trailer.getTOTAL_AMOUNT());
			}
		
		
		}
		
		ffReader.close();

	}
	
	
	
	

}
