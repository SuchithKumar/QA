package com.bsc.qa.facets.ffp.pojo.BscAccumsToSavemart;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscAccumsToSavemartHeader {

	private String HEADER_INDICATOR;
	private String CLIENT_NAME;
	private String FILE_DATE;
	private String FILLER;
	/**
	 * @return the hEADER_INDICATOR
	 */
	public String getHEADER_INDICATOR() {
		return HEADER_INDICATOR;
	}
	/**
	 * @param hEADER_INDICATOR the hEADER_INDICATOR to set
	 */
	public void setHEADER_INDICATOR(String hEADER_INDICATOR) {
		HEADER_INDICATOR = hEADER_INDICATOR;
	}
	/**
	 * @return the cLIENT_NAME
	 */
	public String getCLIENT_NAME() {
		return CLIENT_NAME;
	}
	/**
	 * @param cLIENT_NAME the cLIENT_NAME to set
	 */
	public void setCLIENT_NAME(String cLIENT_NAME) {
		CLIENT_NAME = cLIENT_NAME;
	}
	/**
	 * @return the fILE_DATE
	 */
	public String getFILE_DATE() {
		return FILE_DATE;
	}
	/**
	 * @param fILE_DATE the fILE_DATE to set
	 */
	public void setFILE_DATE(String fILE_DATE) {
		FILE_DATE = fILE_DATE;
	}
	/**
	 * @return the fILLER
	 */
	public String getFILLER() {
		return FILLER;
	}
	/**
	 * @param fILLER the fILLER to set
	 */
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}


}
