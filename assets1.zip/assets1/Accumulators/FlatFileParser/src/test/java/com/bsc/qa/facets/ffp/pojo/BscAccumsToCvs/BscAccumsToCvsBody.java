package com.bsc.qa.facets.ffp.pojo.BscAccumsToCvs;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscAccumsToCvsBody {
	
	private String RECORD_TYPE;
	private String MEMBER_ID;
	private String CARRIER;
	private String ACCOUNT;
	private String GROUP;
	private String ADJUSTMENT_TYPE;
	private String ADJUSTMENT_AMOUNT;
	private String ACCUMULATION_CODE;
	private String ADJUSTMENT_DATE;
	private String ADJUSTMENT_CODE;
	private String LARGE_ADJUSTMENT_AMOUNT;
	private String RESERVED_FILLER_SPACES;
	private String INCOMING_ADJUSTMENT_AMOUNT;
	private String ACCUMULATED_AMOUNT;
	private String BODY_FILLER;
	private String BODY_FILLER_1;

	/**
	 * @return the rECORD_TYPE
	 */
	public String getRECORD_TYPE() {
		return RECORD_TYPE;
	}
	/**
	 * @param rECORD_TYPE the rECORD_TYPE to set
	 */
	public void setRECORD_TYPE(String RECORD_TYPE) {
		this.RECORD_TYPE = RECORD_TYPE;
	}
	/**
	 * @return the mEMBER_ID
	 */
	public String getMEMBER_ID() {
		return MEMBER_ID;
	}
	/**
	 * @param mEMBER_ID the mEMBER_ID to set
	 */
	public void setMEMBER_ID(String MEMBER_ID) {
		this.MEMBER_ID = MEMBER_ID;
	}
	/**
	 * @return the CARRIER
	 */
	public String getCARRIER() {
		return CARRIER;
	}
	/**
	 * @param CARRIER the CARRIER to set
	 */
	public void setCARRIER(String CARRIER) {
		this.CARRIER = CARRIER;
	}
	/**
	 * @return the ACCOUNT
	 */
	public String getACCOUNT() {
		return ACCOUNT;
	}
	/**
	 * @param ACCOUNT the ACCOUNT to set
	 */
	public void setACCOUNT(String ACCOUNT) {
		this.ACCOUNT = ACCOUNT;
	}
	/**
	 * @return the GROUP
	 */
	public String getGROUP() {
		return GROUP;
	}
	/**
	 * @param GROUP the GROUP to set
	 */
	public void setGROUP(String GROUP) {
		this.GROUP = GROUP;
	}
	/**
	 * @return the aDJUSTMENT_TYPE
	 */
	public String getADJUSTMENT_TYPE() {
		return ADJUSTMENT_TYPE;
	}
	/**
	 * @param aDJUSTMENT_TYPE the aDJUSTMENT_TYPE to set
	 */
	public void setADJUSTMENT_TYPE(String aDJUSTMENT_TYPE) {
		ADJUSTMENT_TYPE = aDJUSTMENT_TYPE;
	}
	/**
	 * @return the ADJUSTMENT_AMOUNT
	 */
	public String getADJUSTMENT_AMOUNT() {
		return ADJUSTMENT_AMOUNT;
	}
	/**
	 * @param ADJUSTMENT_AMOUNT the ADJUSTMENT_AMOUNT to set
	 */
	public void setADJUSTMENT_AMOUNT(String ADJUSTMENT_AMOUNT) {
		this.ADJUSTMENT_AMOUNT = ADJUSTMENT_AMOUNT;
	}
	/**
	 * @return the ACCUMULATION_CODE
	 */
	public String getACCUMULATION_CODE() {
		return ACCUMULATION_CODE;
	}
	/**
	 * @param ACCUMULATION_CODE the ACCUMULATION_CODE to set
	 */
	public void setACCUMULATION_CODE(String ACCUMULATION_CODE) {
		this.ACCUMULATION_CODE = ACCUMULATION_CODE;
	}
	/**
	 * @return the ADJUSTMENT_DATE
	 */
	public String getADJUSTMENT_DATE() {
		return ADJUSTMENT_DATE;
	}
	/**
	 * @param ADJUSTMENT_DATE the ADJUSTMENT_DATE to set
	 */
	public void setADJUSTMENT_DATE(String ADJUSTMENT_DATE) {
		this.ADJUSTMENT_DATE = ADJUSTMENT_DATE;
	}
	/**
	 * @return the ADJUSTMENT_CODE
	 */
	public String getADJUSTMENT_CODE() {
		return ADJUSTMENT_CODE;
	}
	/**
	 * @param ADJUSTMENT_CODE the ADJUSTMENT_CODE to set
	 */
	public void setADJUSTMENT_CODE(String ADJUSTMENT_CODE) {
		this.ADJUSTMENT_CODE = ADJUSTMENT_CODE;
	}
	/**
	 * @return the LARGE_ADJUSTMENT_AMOUNT
	 */
	public String getLARGE_ADJUSTMENT_AMOUNT() {
		return LARGE_ADJUSTMENT_AMOUNT;
	}
	/**
	 * @param LARGE_ADJUSTMENT_AMOUNT the LARGE_ADJUSTMENT_AMOUNT to set
	 */
	public void setLARGE_ADJUSTMENT_AMOUNT(String LARGE_ADJUSTMENT_AMOUNT) {
		this.LARGE_ADJUSTMENT_AMOUNT = LARGE_ADJUSTMENT_AMOUNT;
	}
	/**
	 * @return the RESERVED_FILLER_SPACES
	 */
	public String getRESERVED_FILLER_SPACES() {
		return RESERVED_FILLER_SPACES;
	}
	/**
	 * @param RESERVED_FILLER_SPACES the RESERVED_FILLER_SPACES to set
	 */
	public void setRESERVED_FILLER_SPACES(String RESERVED_FILLER_SPACES) {
		this.RESERVED_FILLER_SPACES = RESERVED_FILLER_SPACES;
	}
	/**
	 * @return the INCOMING_ADJUSTMENT_AMOUNT
	 */
	public String getINCOMING_ADJUSTMENT_AMOUNT() {
		return INCOMING_ADJUSTMENT_AMOUNT;
	}
	/**
	 * @param INCOMING_ADJUSTMENT_AMOUNT the INCOMING_ADJUSTMENT_AMOUNT to set
	 */
	public void setINCOMING_ADJUSTMENT_AMOUNT(String INCOMING_ADJUSTMENT_AMOUNT) {
		this.INCOMING_ADJUSTMENT_AMOUNT = INCOMING_ADJUSTMENT_AMOUNT;
	}
	/**
	 * @return the ACCUMULATED_AMOUNT
	 */
	public String getACCUMULATED_AMOUNT() {
		return ACCUMULATED_AMOUNT;
	}
	/**
	 * @param ACCUMULATED_AMOUNT the ACCUMULATED_AMOUNT to set
	 */
	public void setACCUMULATED_AMOUNT(String ACCUMULATED_AMOUNT) {
		this.ACCUMULATED_AMOUNT = ACCUMULATED_AMOUNT;
	}
	/**
	 * @return the bODY_FILLER
	 */
	public String getBODY_FILLER() {
		return BODY_FILLER;
	}
	/**
	 * @param bODY_FILLER the bODY_FILLER to set
	 */
	public void setBODY_FILLER(String bODY_FILLER) {
		BODY_FILLER = bODY_FILLER;
	}
	/**
	 * @return the bODY_FILLER_1
	 */
	public String getBODY_FILLER_1() {
		return BODY_FILLER_1;
	}
	/**
	 * @param bODY_FILLER_1 the bODY_FILLER_1 to set
	 */
	public void setBODY_FILLER_1(String bODY_FILLER_1) {
		BODY_FILLER_1 = bODY_FILLER_1;
	}

	}

