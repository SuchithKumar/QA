package com.bsc.qa.facets.ffp.pojo.BscAccumsToDBPSHDW;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;// <== Mandatory 

@PositionalRecord(ignorePositionNotFound=true) // <== Mandatory 

public class BscAccumsToDBPSHDWTrailer {
	
	private String TRAILER_INDICATOR;
	private String TOTAL_RECORDS;
	private String TOTAL_AMOUNT;
	private String FILLER;
	/**
	 * @return the tRAILER_INDICATOR
	 */
	public String getTRAILER_INDICATOR() {
		return TRAILER_INDICATOR;
	}
	/**
	 * @param tRAILER_INDICATOR the tRAILER_INDICATOR to set
	 */
	public void setTRAILER_INDICATOR(String tRAILER_INDICATOR) {
		TRAILER_INDICATOR = tRAILER_INDICATOR;
	}
	/**
	 * @return the tOTAL_RECORDS
	 */
	public String getTOTAL_RECORDS() {
		return TOTAL_RECORDS;
	}
	/**
	 * @param tOTAL_RECORDS the tOTAL_RECORDS to set
	 */
	public void setTOTAL_RECORDS(String tOTAL_RECORDS) {
		TOTAL_RECORDS = tOTAL_RECORDS;
	}
	/**
	 * @return the tOTAL_AMOUNT
	 */
	public String getTOTAL_AMOUNT() {
		return TOTAL_AMOUNT;
	}
	/**
	 * @param tOTAL_AMOUNT the tOTAL_AMOUNT to set
	 */
	public void setTOTAL_AMOUNT(String tOTAL_AMOUNT) {
		TOTAL_AMOUNT = tOTAL_AMOUNT;
	}
	/**
	 * @return the fILLER
	 */
	public String getFILLER() {
		return FILLER;
	}
	/**
	 * @param fILLER the fILLER to set
	 */
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
}
