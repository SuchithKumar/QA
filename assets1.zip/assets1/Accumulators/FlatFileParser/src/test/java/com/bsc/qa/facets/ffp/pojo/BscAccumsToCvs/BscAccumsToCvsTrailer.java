package com.bsc.qa.facets.ffp.pojo.BscAccumsToCvs;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;// <== Mandatory 

@PositionalRecord(ignorePositionNotFound=true) // <== Mandatory 

public class BscAccumsToCvsTrailer {
	
	private String RECORD_TYPE;
	private String CARRIER;
	private String TOTAL_RECORDS;
	private String FILLER;
	/**
	 * @return the RECORD_TYPE
	 */
	public String getRECORD_TYPE() {
		return RECORD_TYPE;
	}
	/**
	 * @param RECORD_TYPE the RECORD_TYPE to set
	 */
	public void setRECORD_TYPE(String RECORD_TYPE) {
		this.RECORD_TYPE = RECORD_TYPE;
	}
	/**
	 * @return the CARRIER
	 */
	public String getCARRIER() {
		return CARRIER;
	}
	/**
	 * @param CARRIER the CARRIER to set
	 */
	public void setCARRIER(String CARRIER) {
		this.CARRIER = CARRIER;
	}
	/**
	 * @return the TOTAL_RECORDS
	 */
	public String getTOTAL_RECORDS() {
		return TOTAL_RECORDS + 1;
	}
	/**
	 * @param TOTAL_RECORDS the TOTAL_RECORDS to set
	 */
	public void setTOTAL_RECORDS(String TOTAL_RECORDS) {
		this.TOTAL_RECORDS = TOTAL_RECORDS;
	}
	/**
	 * @return the FILLER
	 */
	public String getFILLER() {
		return FILLER;
	}
	/**
	 * @param FILLER the FILLER to set
	 */
	public void setFILLER(String FILLER) {
		this.FILLER = FILLER;
	}

	

}
