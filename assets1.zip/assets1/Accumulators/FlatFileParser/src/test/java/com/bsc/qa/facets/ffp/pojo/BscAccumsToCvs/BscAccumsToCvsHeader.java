package com.bsc.qa.facets.ffp.pojo.BscAccumsToCvs;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true)

public class BscAccumsToCvsHeader {
	
	
	private String RECORD_TYPE;
	private String CARRIER;
	private String CARRIER_NAME;
	private String ADDRESS_1;
	private String ADDRESS_2;
	private String CITY;
	private String STATE;
	private String ZIP;
	private String PHONE;
	private String CREATION_DATE;
	private String FILLER;
	
	/**
	 * @return the RECORD_TYPE
	 */
	public String getRECORD_TYPE() {
		return RECORD_TYPE;
	}
	/**
	 * @param RECORD_TYPE the RECORD_TYPE to set
	 */
	public void setRECORD_TYPE(String RECORD_TYPE) {
		this.RECORD_TYPE = RECORD_TYPE;
	}
	/**
	 * @return the CARRIER
	 */
	public String getCARRIER() {
		return CARRIER;
	}
	/**
	 * @param CARRIER the CARRIER to set
	 */
	public void setCARRIER(String CARRIER) {
		this.CARRIER = CARRIER;
	}
	/**
	 * @return the CARRIER_NAME
	 */
	public String getCARRIER_NAME() {
		return CARRIER_NAME;
	}
	/**
	 * @param CARRIER_NAME the CARRIER_NAME to set
	 */
	public void setCARRIER_NAME(String CARRIER_NAME) {
		this.CARRIER_NAME = CARRIER_NAME;
	}
	/**
	 * @return the ADDRESS_1
	 */
	public String getADDRESS_1() {
		return ADDRESS_1;
	}
	/**
	 * @param ADDRESS_1 the ADDRESS_1 to set
	 */
	public void setADDRESS_1(String ADDRESS_1) {
		this.ADDRESS_1 = ADDRESS_1;
	}
	/**
	 * @return the ADDRESS_2
	 */
	public String getADDRESS_2() {
		return ADDRESS_2;
	}
	/**
	 * @param ADDRESS_2 the ADDRESS_2 to set
	 */
	public void setADDRESS_2(String ADDRESS_2) {
		this.ADDRESS_2 = ADDRESS_2;
	}
	/**
	 * @return the CITY
	 */
	public String getCITY() {
		return CITY;
	}
	/**
	 * @param CITY the CITY to set
	 */
	public void setCITY(String CITY) {
		this.CITY = CITY;
	}
	/**
	 * @return the STATE
	 */
	public String getSTATE() {
		return STATE;
	}
	/**
	 * @param STATE the STATE to set
	 */
	public void setSTATE(String STATE) {
		this.STATE = STATE;
	}
	/**
	 * @return the ZIP
	 */
	public String getZIP() {
		return ZIP;
	}
	/**
	 * @param ZIP the ZIP to set
	 */
	public void setZIP(String ZIP) {
		this.ZIP = ZIP;
	}
	/**
	 * @return the PHONE
	 */
	public String getPHONE() {
		return PHONE;
	}
	/**
	 * @param PHONE the PHONE to set
	 */
	public void setPHONE(String PHONE) {
		this.PHONE = PHONE;
	}
	/**
	 * @return the CREATION_DATE
	 */
	public String getCREATION_DATE() {
		return CREATION_DATE;
	}
	/**
	 * @param CREATION_DATE the CREATION_DATE to set
	 */
	public void setCREATION_DATE(String CREATION_DATE) {
		this.CREATION_DATE = CREATION_DATE;
	}
	/**
	 * @return the FILLER
	 */
	public String getFILLER() {
		return FILLER;
	}
	/**
	 * @param FILLER the FILLER to set
	 */
	public void setFILLER(String FILLER) {
		this.FILLER = FILLER;
	}


	
	

}
