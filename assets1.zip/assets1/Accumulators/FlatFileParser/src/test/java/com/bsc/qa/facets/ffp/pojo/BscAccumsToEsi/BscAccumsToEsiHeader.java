package com.bsc.qa.facets.ffp.pojo.BscAccumsToEsi;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true)

public class BscAccumsToEsiHeader {
	private String Processor_Routing_Identification;
	private String Record_Type;
	private String Transmission_Type;
	private String Creation_Date;
	private String Creation_Time;
	private String Sender_ID;
	private String Receiver_ID;
	private String Batch_Number;
	private String File_Type;
	private String Version_Number;
	private String Reserved;
	/**
	 * @return the processor_Routing_Identification
	 */
	public String getProcessor_Routing_Identification() {
		return Processor_Routing_Identification;
	}
	/**
	 * @return the record_Type
	 */
	public String getRecord_Type() {
		return Record_Type;
	}
	/**
	 * @return the transmission_Type
	 */
	public String getTransmission_Type() {
		return Transmission_Type;
	}
	/**
	 * @return the creation_Date
	 */
	public String getCreation_Date() {
		return Creation_Date;
	}
	/**
	 * @return the creation_Time
	 */
	public String getCreation_Time() {
		return Creation_Time;
	}
	/**
	 * @return the sender_ID
	 */
	public String getSender_ID() {
		return Sender_ID;
	}
	/**
	 * @return the receiver_ID
	 */
	public String getReceiver_ID() {
		return Receiver_ID;
	}
	/**
	 * @return the batch_Number
	 */
	public String getBatch_Number() {
		return Batch_Number;
	}
	/**
	 * @return the file_Type
	 */
	public String getFile_Type() {
		return File_Type;
	}
	/**
	 * @return the version_Number
	 */
	public String getVersion_Number() {
		return Version_Number;
	}
	/**
	 * @return the reserved
	 */
	public String getReserved() {
		return Reserved;
	}
	/**
	 * @param processor_Routing_Identification the processor_Routing_Identification to set
	 */
	public void setProcessor_Routing_Identification(
			String processor_Routing_Identification) {
		Processor_Routing_Identification = processor_Routing_Identification;
	}
	/**
	 * @param record_Type the record_Type to set
	 */
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	/**
	 * @param transmission_Type the transmission_Type to set
	 */
	public void setTransmission_Type(String transmission_Type) {
		Transmission_Type = transmission_Type;
	}
	/**
	 * @param creation_Date the creation_Date to set
	 */
	public void setCreation_Date(String creation_Date) {
		Creation_Date = creation_Date;
	}
	/**
	 * @param creation_Time the creation_Time to set
	 */
	public void setCreation_Time(String creation_Time) {
		Creation_Time = creation_Time;
	}
	/**
	 * @param sender_ID the sender_ID to set
	 */
	public void setSender_ID(String sender_ID) {
		Sender_ID = sender_ID;
	}
	/**
	 * @param receiver_ID the receiver_ID to set
	 */
	public void setReceiver_ID(String receiver_ID) {
		Receiver_ID = receiver_ID;
	}
	/**
	 * @param batch_Number the batch_Number to set
	 */
	public void setBatch_Number(String batch_Number) {
		Batch_Number = batch_Number;
	}
	/**
	 * @param file_Type the file_Type to set
	 */
	public void setFile_Type(String file_Type) {
		File_Type = file_Type;
	}
	/**
	 * @param version_Number the version_Number to set
	 */
	public void setVersion_Number(String version_Number) {
		Version_Number = version_Number;
	}
	/**
	 * @param reserved the reserved to set
	 */
	public void setReserved(String reserved) {
		Reserved = reserved;
	}
	
}
