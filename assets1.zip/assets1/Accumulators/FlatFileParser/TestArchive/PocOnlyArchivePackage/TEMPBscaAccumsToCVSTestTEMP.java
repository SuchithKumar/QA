package PocOnlyArchivePackage;


import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.relevantcodes.extentreports.LogStatus;

public class TEMPBscaAccumsToCVSTestTEMP extends BaseTest implements IHookable{

	private static String strSubscriber_ID;  
    private static int bodyRowsCount;
    
    final private static String strUniqueIdentifier1 = "SUBSCRIBER_ID"; // <= first 
    final private static String strUniqueIdentifier2 = "RELATIONSHIP_CODE"; // <= second
    
    private static TEMPOfBscAccumsToCvsReaderTEMP ffpExtract;
    
	private static List<Map<String, String>> testHeader;
	private static List<Map<String, String>> testBody;
	private static List<Map<String, String>> testTrailer;
    
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles", "FileSpecificFolderName"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
        
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
	 	
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		 
		 TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
		 
		 filePAth = tesFile.getCompleteTestFilePath();	 
		 
		 //read flat file before test 
		  ffpExtract = new TEMPOfBscAccumsToCvsReaderTEMP(filePAth);
		 
			//Parse headers and store in to testHeaders
			try {
				testHeader = ffpExtract.getListOfHeaderValues();
			
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			//Parse headers and store in to testHeaders
			try {
				testBody = ffpExtract.getListOfBodyValues(); // array list of hash map values 
				
				bodyRowsCount = testBody.size(); // body rows count
				
				//please note the index zero. Assumption is made here that body of contained single row of data. 
				strSubscriber_ID = testBody.get(0).get(strUniqueIdentifier1); // <== Unique ID will vary from file to file
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			
			//Parse headers and store in to testHeaders
			try {
				testTrailer = ffpExtract.getListOfTrailerValues();
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			
		 
	}
	

	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@HEADER TEST METHODS
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderRecordType(Map<String, String> data) {

		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
	    
		String SQLQuery = data.get("SqlRecordType").toString();

	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
	    // Test if DB Key exists in FF set of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    		
	    	  System.out.println("Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here
				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderCarrier(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
	    String SQLQuery = data.get("SqlHeaderCarrier").toString();

	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    		
	    	  System.out.println("Acctual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here			
	}
	
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderCreationDate(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
	    String SQLQuery = data.get("SqlCreationDate").toString();
	   
	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    		
	    	  System.out.println("Acctual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here
	}
	

	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderFiller(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
	    String SQLQuery = data.get("SqlHeaderFiller").toString();

	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strSubscriber_ID,null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0); //<== Index one 
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    		
	    	  System.out.println("Acctual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here 	
	     				
	}
	
	
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@BODY TEST METHODS
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyRecordType(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		String SQLQuery = data.get("SqlBodyRecordType").toString();
	    
	    
	    for (Map<String, String> FlatFileMap : testBody) {
	      
	    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
	    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
	    	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in FF ste of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    		
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	    
	    softAssertion.assertAll();	//<== absolutely must be here   
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMemberId(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		String SQLQuery = data.get("SqlMemberID").toString();

	    for (Map<String, String> FlatFileMap : testBody) {
	      
	    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
	    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
	    	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in FF ste of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    		
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	    
	    softAssertion.assertAll();	//<== absolutely must be here
	     				
	}
	
	
	
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyCarrier(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlBodyCarrier").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}
	
		
		@Test(dataProvider = "masterDataProvider")
		private static void testAccount(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlAccount").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testGroupId(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlGroupId").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here    
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testAdjustmentType(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlAdjustmentType").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testAdjustmentAmount(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlAdjustmentAmount").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testAccumulationCode(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlAccumulationCode").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testAdjustmentDate(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlAdjustmentDate").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
				
				// Conditional test for element that may contain empty values from facets db 
				if ((expectedValue.equalsIgnoreCase("blank")) & (isNullOrBlank(FlatFileMap.get(expectedFieldName).toString()))){			
				   expectedValue = "";		// reset value to empty for validation. Removes word blank	
			     }		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testAdjustmentCode(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlAdjustmentCode").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
				
				// Conditional test for element that may contain empty values from facets db 
				if ((expectedValue.equalsIgnoreCase("blank")) & (isNullOrBlank(FlatFileMap.get(expectedFieldName).toString()))){			
				   expectedValue = "";		// reset value to empty for validation. Removes word blank	
			     }

				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testAdjustmentReservedFillerSpaces(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sqlAdjustmentReservedFillerSpaces").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
				
				// Conditional test for element that may contain empty values from facets db 
				if ((expectedValue.equalsIgnoreCase("blank")) & (isNullOrBlank(FlatFileMap.get(expectedFieldName).toString()))){			
				   expectedValue = "";		// reset value to empty for validation. Removes word blank	
			     }		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testIncomingAdjustmentAmount(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("TestIncomingAdjustmentAmount").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
				
				// Conditional test for element that may contain empty values from facets db 
				if ((expectedValue.equalsIgnoreCase("blank")) & (isNullOrBlank(FlatFileMap.get(expectedFieldName).toString()))){			
				   expectedValue = "";		// reset value to empty for validation. Removes word blank	
			     }		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testAccumulatedAmount(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("TestAccumulatedAmount").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
				
				// Conditional test for element that may contain empty values from facets db 
				if ((expectedValue.equalsIgnoreCase("blank")) & (isNullOrBlank(FlatFileMap.get(expectedFieldName).toString()))){			
				   expectedValue = "";		// reset value to empty for validation. Removes word blank	
			     }		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testFiller1(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlTestFiller1").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
				
				// Conditional test for element that may contain empty values from facets db 
				if ((expectedValue.equalsIgnoreCase("blank")) & (isNullOrBlank(FlatFileMap.get(expectedFieldName).toString()))){			
				   expectedValue = "";		// reset value to empty for validation. Removes word blank	
			     }		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testFiller2(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlTestFiller2").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne,strUniqueIdValueTwo);
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
				
				// Conditional test for element that may contain empty values from facets db 
				if ((expectedValue.equalsIgnoreCase("blank")) & (isNullOrBlank(FlatFileMap.get(expectedFieldName).toString()))){			
				   expectedValue = "";		// reset value to empty for validation. Removes word blank	
			     }		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		

	
		///@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Trailer Methods
		
		@Test(dataProvider = "masterDataProvider")
		private static void testFooterRecordType(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlTestFooterRecordType").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testTrailer) {
		      
		    	//String strUniqueIdValue = FlatFileMap.get(strUniqueIdentifier1);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		@Test(dataProvider = "masterDataProvider")
		private static void testFooterCarrier(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlTestFooterCarrier").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testTrailer) {
		      
		    	//String strUniqueIdValue = FlatFileMap.get(strUniqueIdentifier1);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}	
		
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testFooterTotalRecords(Map<String, String> data) {
	
			SoftAssert softAssertion= new SoftAssert();

		    for (Map<String, String> FlatFileMap : testTrailer) {

				//get records colmn name to string 
				String expectedFieldName = "TOTAL_RECORDS" ;// strRecordSet[0].trim(); 

			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			    	 
		        	String actualValue = FlatFileMap.get(expectedFieldName).toString().trim();
		        		
		        		//testing the lenth of TOTAL_RECORDS field
		        		softAssertion.assertEquals(actualValue.length(), 30, " Expected lenth of TOTAL_RECORDS is 9 chars long ");
		        		
		        		//remove zeros from 000000005 to 5
		        		 actualValue = actualValue.replaceFirst("^0+(?!$)", "");
		        		 
		        		 //note the conversion of integer value 
		        		 
		        		 softAssertion.assertEquals(actualValue.trim(), (String.valueOf(bodyRowsCount)).trim(), " Expected Value: " + bodyRowsCount );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim()  );
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }   
		    
		    softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		@Test(dataProvider = "masterDataProvider")
		private static void testFooterFiller(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlTestFooterFiller").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testTrailer) {
		      
		    	//String strUniqueIdValue = FlatFileMap.get(strUniqueIdentifier1);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		      softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}	
	
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@BODY TEST METHODS
	


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Test Methods that should be present in every test @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    
private static DBUtils objDBUtility;//Mandatory declaration 
private static String filePAth ;//Mandatory 

//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) {
		Object[][] data = null;
		Map<String, String> dataMap = new HashMap<String, String>();

		dataMap = ExcelUtils.getTestMethodData(method.getName());
		data = new Object[][] { { dataMap } };
		return data;
	}

	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
}