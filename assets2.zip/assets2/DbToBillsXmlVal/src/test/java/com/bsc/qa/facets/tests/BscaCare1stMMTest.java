package com.bsc.qa.facets.tests;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.utility.XMLParse;
import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable{



private String inputFileName = null;
private SoftAssert softAssert = null;
private XMLParse xMLParse = null;

public BscaCare1stMMTest(String inputFileName) {
	this.inputFileName = inputFileName;
}


	//************************************** TEST METHODS************************
		
		//To validate XML fields with database values for Bills
		@Test()
		private void testXMLToDBValidationBills() {
			try {
				xMLParse = new XMLParse();
				//For fetching test data from test data excel file 
				Map<String, String> data = null;
				try {
					data = getData("XMLToDBValidationBills");
				} catch (Exception e) {
					e.printStackTrace();
				}
				//to retrieve parent tag from test data sheet
				String xmlTag=data.get("ELEMENT_TAG_NAME").toString().trim();		
				String xmlFilePath =inputFileName;
				//For the initial XML setup
				xMLParse.xmlSetup(xmlFilePath);
				//assigning mapping sheet name in test data sheet to local variable
				String mappingSheetName="MappingSheet_PHPBills";
				//To fetch all invoice Numbers from XML, multiple subscriber data will be retrieved with pipe (|) delimiter
				String invoiceNumberList = xMLParse.uniqueDetailsExtraction(xmlTag,"data",3);
				//Verifying valid invoice ID details from XML
				if(!invoiceNumberList.equalsIgnoreCase("")) {
					
					String [] invoiceNumberArray = invoiceNumberList.split("\\|");
					
					//Iterating for all invoice Numbers to validate XML versus Database values
					for(int intICounter = 1; intICounter< invoiceNumberArray.length ; intICounter++){
						//To skip the first report which is initialized in the run method
						if(intICounter > 0 )
						{
							
							//To get the report for each invoice Number in the XML
							//Parameters: to display report header in the HTML						
							reportInit("PHP_Bills XML to Facets("+System.getenv("ENVNAME")+")DB Validation", "Invoice ID:" + invoiceNumberArray[intICounter]);
							logger.log(LogStatus.INFO, "Starting test testXMLToDBValidationBills");
							
						}
						//To log the XML file path in HTML report
						logger.log(LogStatus.INFO, "XML file path: " + xmlFilePath);
						//To log the invoiceNumber details in HTML report
						logger.log(LogStatus.INFO, "Validating Invoice ID: " + invoiceNumberArray[intICounter]);
						System.out.println("Validating Invoice ID: " + invoiceNumberArray[intICounter]);
						//validating specific Invoice Number's data, this is the main method for validating Bills
						xMLParse.nodeExtraction(xmlTag, mappingSheetName, invoiceNumberArray[intICounter], softAssert);
						
					}
					
				}
				//To report the statement when file does not have invoice Numbers
				else {
					logger.log(LogStatus.FAIL, "Please provide valid file name and inputs to fetch invoiceID data") ;
				}

				
				
			}
			catch (Exception e)	{
				System.out.println("Test script Failed due to Exception.....!!");
				logger.log(LogStatus.FAIL, "Test script Failed due to Exception.....!!" + e.getMessage() );
				softAssert.fail("Test script Failed due to Exception.....!!", e.getCause());
				e.printStackTrace();
			}finally{
				softAssert.assertAll();	//<== absolutely must be here
			}
		}

		
	/**
	 * //To run test method, this method will initiate the HTML report
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		//To execute test method multiple times
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}

	/**
	 * DataProvider for returning the specific test data based on test method
	 * name
	 * 
	 * @param String: Method name
	 * @return
	 */

	private Map<String,String> getData(String method) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		//assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";
		//Fetching data from test data excel file based on method name
		dataMap = ExcelUtils.getTestMethodData(xlsPath, method);
		
		return dataMap;
	}

	  }
	
