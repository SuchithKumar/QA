package com.bsc.qa.facets.utility;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.DefaultEditorKit.PasteAction;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.poi.hssf.record.PrecisionRecord;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.facets.utility.ExcelUtilsExtended;
import com.relevantcodes.extentreports.LogStatus;

public class XMLParseBSCLobs extends BaseTest {


	private Document doc;
	public String subscriberId;

	public SoftAssert softAssertion = null;

	DBUtils dbUtils;
	
	private int index = 0;
	private int flagLEP = 0;
	private String past_due_amount = "";
	private String net_cred_deb = "";
	private String curr_charges = "";
	public String dbValue;
	private String SQLQuery = "";
	private String strUniqueData = "";
	private int	intUniqueIndexNumber=0;
	/**
	 * To create instance of document builder for the XML
	 * @param xmlPath: XML file complete path
	 */
	public void xmlSetup(String xmlPath) throws ParserConfigurationException,SAXException,IOException {
		DocumentBuilder dBuilder;
		File fXmlFile = new File(xmlPath);// Creating file for the given path
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		try {
			// creating instance for the DocumentBuilder
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
		}
		//To capture the ParserConfigurationException exception
		catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		//To capture the SAXException exception
		catch (SAXException e) {
			e.printStackTrace();
		}
		//To capture the IOException exception
		catch (IOException e) {
			e.printStackTrace();
		}
	
	}

	/**
	 * To extract Unique section from XML and compare XML data against database
	 * @param tagName: Parent tag name
	 * @param mappingSheetName: Filed versus queries mapping sheet
	 * @param invoiceId: Unique ID to fetch specific section
	 * @param softAssert: 
	 * @throws Exception 
	 */
	public void nodeExtraction(String lobfile,String tagName, String mappingSheetName,
			String invoiceId, SoftAssert softAssert) throws Exception {
		//To get the elements using tagName
		NodeList PagesList = doc.getElementsByTagName(tagName);
		//Checking each parent tag sections in the XML using for loop
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);
			index = 0;
			flagLEP = 0;
			softAssertion = softAssert;
			//System.out.println("node isssssssssssssssss "+(Element)node);
			//System.out.println(node.getNodeValue());
			//Calling recursive function to fetch and compare tag values with database values
			if (hasChildElements((Element) node)) {
				parseChildElements(lobfile,(Element) node, mappingSheetName, invoiceId, tagName, (Element) node);
				
			}
		}
	}
	/**
	 * To extract Unique data from XML
	 * @param tagName: Primary parent tag name
	 * @param strUniqueTagName: Unique tag name
	 * @return : To return all unique values with "|" this delimiter
	 * @throws SQLException: To throw the SQLException exception
	 * @throws ParseException: To throw the ParseException exception
	 */
public String uniqueDetailsExtraction(String tagName, String strUniqueTagName, int intIndexNumber) throws SQLException, ParseException{
		
		//To initialize the variable
		strUniqueData = "";
		//To get the elements using tagName
		NodeList PagesList = doc.getElementsByTagName(tagName);
		//Checking each parent tag sections in the XML using for loop
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);
			index = 0;
			intUniqueIndexNumber = 0;
			//To check the node when it is having child elements
			if (hasChildElements((Element) node)) {				
				//To extract Unique tag data from XML 
				parseChildElementsForUniqueIDs((Element) node, strUniqueTagName,intIndexNumber);
			}
		}
		// Returning unique data with pipe (|) delimiter
		return strUniqueData;
	}


		/**
	 * To extract Unique data from XML
	 * @param nNode: Parent node to retrieve child nodes along with tag values
	 * @param strUniqueTagName: Unique tag name to retrieve corresponding value
	 * @throws SQLException: To throw the SQLException exception
	 * @throws ParseException:  To throw the ParseException exception
	 */
private void parseChildElementsForUniqueIDs(Element nNode, String strUniqueTagName, int intIndexNumber)	throws SQLException, ParseException {
	
	String elementName = "";
	String elementvalue = "";
	
	NodeList children = nNode.getChildNodes();// get child nodes of node
	for (int i = 0; i < children.getLength(); i++) { // loop through all child nodes
		Node node = (Node) children.item(i);
		if (node.getNodeType() == Node.ELEMENT_NODE) {
			elementName = node.getNodeName().trim().toString();

			elementvalue = node.getTextContent().trim().toString();
			//Checking unique element name in the XML
			if ((elementName.equalsIgnoreCase(strUniqueTagName))) {
				intUniqueIndexNumber += 1;
				if(intUniqueIndexNumber == intIndexNumber){
					//Storing Unique data into strUniqueData variable with pipe (|) delimiter
					strUniqueData = strUniqueData + "|" + elementvalue;
				}
				
				
			} else if (hasChildElements((Element) node)) {// checking for the child elements
				//calling recursive function to fetch data from child				
				parseChildElementsForUniqueIDs((Element) node, strUniqueTagName,intIndexNumber);
			}
		}
	}
}


	/**
	 * Recursive method to parse all the elements under the node	 * 
	 * @param nNode: Node name for extraction
	 * @param mappingSheetName:  Test data mapping sheet name for queries
	 * @param invoiceId: Unique id to retrieve matching section from XML
	 * @param tagname: Tag Name
	 * @param pNode: Parent node name
	 * @throws Exception 
	 */
	private void parseChildElements(String lobfile,Element nNode, String mappingSheetName,	String invoiceId, String tagname, Element pNode)
			throws Exception {
		NodeList children = nNode.getChildNodes();// get child nodes of node
		for (int i = 0; i < children.getLength(); i++) { // loop through child nodes

			Node node = (Node) children.item(i);
			//Checking for the element node
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				String elementName = node.getNodeName().trim().toString();
				String elementvalue = node.getTextContent().trim().toString();
				//System.out.println("Element Name: "+elementName );
				//System.out.println("Element Value: "+elementvalue );
				//getValuesOfElement(lobfile,(Element)node, mappingSheetName, invoiceId);
				if ((elementName.equalsIgnoreCase("data"))
						&& (elementvalue.equalsIgnoreCase(invoiceId))) {
					//System.out.println("Inside after Comparison");
					getElementAtttributes((Element) pNode, mappingSheetName, invoiceId);// getting attributes of elements
					getChildElements(lobfile,(Element) pNode, mappingSheetName,	invoiceId, tagname);// getting child elements
				} else if (hasChildElements((Element) node)) {// checking for child nodes
					//Calling the recursive method inside the same method
					
					parseChildElements(lobfile,(Element) node, mappingSheetName, invoiceId, tagname, pNode);
				}
			}
		}
	}

	
	/**
	 * To retrieve database value for the nodes and compare database values with XML attribute values
	 * @param node: Node name for comparison
	 * @param sheetName: Test data mapping sheet name for queries
	 * @param invoiceId: Unique ID for the query input
	 * @throws SQLException: To throw the SQLException exception
	 * @throws ParseException: To throw the ParseException exception
	 */
	private void getElementAtttributes(Element node, String sheetName, String invoiceId) throws SQLException, ParseException {
		

		if (node.hasAttributes()) {// checking for attributes in node
			NamedNodeMap attributesList = node.getAttributes();// all attributes
																// in node
			//Loop through all attribute lists
			for (int attribute_Number = 0; attribute_Number < attributesList.getLength(); attribute_Number++) {
				Attr attr = (Attr) attributesList.item(attribute_Number);
				String attributeName = attr.getNodeName();// Attribute name capture
				String attributeValue = attr.getNodeValue();// attribute value capture
				//System.out.println("AttributeDetails");
				//System.out.println(attributeName+ " : "+attributeValue);
				//getValuesOfElement(attr.getNodeName(), sheetName, invoiceId);
				//Retrieving and Storing database value into a dbValue variable
//				String dbValue = getElementValueFromDB(attributeName.trim().toString(), invoiceId, sheetName, node);
//				if(dbValue == null){
//					//To compare XML value against database value
//					validataXmlAndDbValues(attributeName.trim().toString(),	attributeValue, "[Blank]");
//				}
//				if(!dbValue.equalsIgnoreCase("TagNotConsiderForValidation")){
//						//To compare XML value against database value
//						validataXmlAndDbValues(attributeName.trim().toString(),	attributeValue, dbValue);
//				}
			}
		}
	}

	/**
	 * To retrieve database value for the nodes and compare database values with XML values
	 * @param node: Node name for comparison
	 * @param sheetName: Test data mapping sheet name for queries
	 * @param invoiceId: Unique id to replace in the query
	 * @throws Exception 
	 */
	private void getValuesOfElement(String lobfile,Element node, String sheetName,	String invoiceId) throws Exception {
		String elementName = node.getNodeName();
		String xpath = getXPath(node);
		
		
			if(elementName.trim().equalsIgnoreCase("bill_type")){		   		
		   		
		   		dbValue = getElementValueFromDB("bill_type_med", invoiceId,sheetName, node);
		   		//System.out.println(dbValue);
		   		//System.out.println("nodevalue :"+node.getTextContent());
		   		String xmlValue  = node.getTextContent();
		   		validataXmlAndDbValues("bill_type", xmlValue, dbValue);
		   	}
			
			if(elementName.equalsIgnoreCase("line_of_business")){
				if(lobfile.toString().equalsIgnoreCase("mbill")){
					dbValue = getElementValueFromDB("premium_stmt_printid", invoiceId,sheetName, node);
					String xmlValue  = node.getTextContent();
					validataXmlAndDbValues("premium_stmt_printid", xmlValue, dbValue);
				}
				if(lobfile.toString().equalsIgnoreCase("cbill")){
					dbValue = getElementValueFromDB("premium_stmt_printid", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		String xmlValue  = node.getTextContent();
					validataXmlAndDbValues("premium_stmt_printid", xmlValue, dbValue);
				}
			}
			if(elementName.trim().equalsIgnoreCase("line_of_business")){
				if(lobfile.toString().equalsIgnoreCase("mbill")){
					dbValue = getElementValueFromDB("line_of_business_med", invoiceId,sheetName, node);
					//System.out.println(dbValue);
					//System.out.println("nodevalue :"+node.getTextContent());
					String xmlValue  = node.getTextContent();
					validataXmlAndDbValues("line_of_business", xmlValue, dbValue);
				}
				if(lobfile.toString().equalsIgnoreCase("cbill")){
					dbValue = getElementValueFromDB("line_of_business_care", invoiceId,sheetName, node);
					//System.out.println(dbValue);
					//System.out.println("nodevalue :"+node.getTextContent());
					String xmlValue  = node.getTextContent();
					validataXmlAndDbValues("line_of_business", xmlValue, dbValue);
				}
		   	}
			
			if(elementName.trim().equalsIgnoreCase("inserts")){
		   		dbValue = getElementValueFromDB("inserts", invoiceId,sheetName, node);
		   		//System.out.println(dbValue);
		   		//System.out.println("nodevalue :"+node.getTextContent());
		   		String xmlValue  = node.getTextContent();
		   		validataXmlAndDbValues("inserts", xmlValue, dbValue);	
		   	}
			
			if(elementName.trim().equalsIgnoreCase("lang_code")){
		   		dbValue = getElementValueFromDB("lang_code", invoiceId,sheetName, node);
		   		//System.out.println(dbValue);
		   		//System.out.println("nodevalue :"+node.getTextContent());
		   		String xmlValue  = node.getTextContent();
		   		validataXmlAndDbValues("lang_code", xmlValue, dbValue);	
		   	}
			
			if(elementName.trim().equalsIgnoreCase("bill")){
		   		dbValue = getElementValueFromDB("bill_id", invoiceId,sheetName, node);
		   		//System.out.println(dbValue);
		   		//System.out.println("nodevalue :"+node.getTextContent());
		   		String xmlValue  = node.getTextContent();
		   		validataXmlAndDbValues("bill_id", xmlValue, dbValue);	
		   	}
			
			if(elementName.trim().equalsIgnoreCase("special_handling_code")){
		   		dbValue = getElementValueFromDB("special_handling_code", invoiceId,sheetName, node);
		   		//System.out.println(dbValue);
		   		//System.out.println("nodevalue :"+node.getTextContent());
		   		String xmlValue  = node.getTextContent();
		   		validataXmlAndDbValues("special_handling_code", xmlValue, dbValue);	
		   	}
		   	if(elementName.trim().equalsIgnoreCase("suppress_print")){
		   		dbValue = getElementValueFromDB("suppress_print", invoiceId,sheetName, node);
		   		//System.out.println(dbValue);
		   		//System.out.println("nodevalue :"+node.getTextContent());
		   		String xmlValue  = node.getTextContent();
		   		validataXmlAndDbValues("suppress_print", xmlValue, dbValue);	
		   	}
		   	if(elementName.trim().equalsIgnoreCase("mail_redirect")){
		   		dbValue = getElementValueFromDB("mail_redirect", invoiceId,sheetName, node);
		   		//System.out.println(dbValue);
		   		//System.out.println("nodevalue :"+node.getTextContent());
		   		String xmlValue  = node.getTextContent();
		   		validataXmlAndDbValues("mail_redirect", xmlValue, dbValue);	
		   	}
		   	if(elementName.trim().equalsIgnoreCase("bill_status")){
		   		dbValue = getElementValueFromDB("bill_status", invoiceId,sheetName, node);
		   		//System.out.println(dbValue);
		   		//System.out.println("nodevalue :"+node.getTextContent());
		   		String xmlValue  = node.getTextContent();
		   		validataXmlAndDbValues("bill_status", xmlValue, dbValue);	
		   	}
		   	if(elementName.trim().equalsIgnoreCase("data")){
		   		index++;
		   		//System.out.println(index);
		   		if(index==2){
		   			dbValue = getElementValueFromDB("member_number", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		String member_number  = node.getTextContent();
			   		validataXmlAndDbValues("member_number", member_number, dbValue);
		   		}
		   		if(index==3){
		   			dbValue = getElementValueFromDB("invoice_number", invoiceId,sheetName, node);
		   			//System.out.println(dbValue);
		   			//System.out.println("nodevalue :"+node.getTextContent());
		   			String xmlValue  = node.getTextContent();
		   			validataXmlAndDbValues("invoice_number", xmlValue, dbValue);
		   		}
		   		if(index==7){
		   			dbValue = getElementValueFromDB("group_id", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		String xmlValue  = node.getTextContent();
			   		validataXmlAndDbValues("group_id", xmlValue, dbValue);
		   		}
		   		if(index==10){
		   			dbValue = getElementValueFromDB("bill_date", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		String xmlValue  = node.getTextContent();
			   		validataXmlAndDbValues("bill_date", xmlValue, dbValue);
		   		}
		   		if(index==11){
		   			dbValue = getElementValueFromDB("billing_period", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		String xmlValue  = node.getTextContent();
			   		validataXmlAndDbValues("billing_period", xmlValue, dbValue);
		   		}
		   		if(index==12){
		   			dbValue = getElementValueFromDB("due_date", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		String xmlValue  = node.getTextContent();
			   		validataXmlAndDbValues("due_date", xmlValue, dbValue);
		   		}
		   		if(index==13){
		   			dbValue = getElementValueFromDB("previous_amount_due", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		String xmlValue  = node.getTextContent();
			   		xmlValue = xmlValue.replace(",","");
			   		validataXmlAndDbValues("previous_amount_due", xmlValue, dbValue);
		   		}
		   		if(index==14){
		   			dbValue = getElementValueFromDB("payments", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		String xmlValue  = node.getTextContent();
			   		xmlValue = xmlValue.replace(",","");
			   		validataXmlAndDbValues("payments", xmlValue, dbValue);
		   		}
		   		if(index==15){
		   			dbValue = getElementValueFromDB("past_due_amount", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		past_due_amount  = node.getTextContent();
			   		past_due_amount = past_due_amount.replace(",","");
			   		validataXmlAndDbValues("past_due_amount", past_due_amount, dbValue);
		   		}
		   		if(index==16){
		   			dbValue = getElementValueFromDB("current_charges", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
		   			curr_charges  = node.getTextContent();
			   		curr_charges = curr_charges.replace(",","");
			   		validataXmlAndDbValues("current_charges", curr_charges, dbValue);
		   		}
		   		if(index==17){
		   			dbValue = getElementValueFromDB("net_credits_debits", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
		   			net_cred_deb  = node.getTextContent();
			   		net_cred_deb = net_cred_deb.replace(",","");
			   		validataXmlAndDbValues("net_credits_debits", net_cred_deb, dbValue);
		   		}
		   		
		   		if(index==18){
		   			dbValue = getElementValueFromDB("total_amount_due", invoiceId,sheetName, node);
			   		//System.out.println(dbValue);
			   		//System.out.println("nodevalue :"+node.getTextContent());
			   		String total_amt_due  = node.getTextContent();
			   		total_amt_due = total_amt_due.replace(",","");
			   		double sum_amount= Double.parseDouble(past_due_amount)+(Double.parseDouble(curr_charges))+
	   				Double.parseDouble(net_cred_deb);
			   		
			   		double total_amount = Double.parseDouble(total_amt_due);
			   		
			   		DecimalFormat df = new DecimalFormat("#.##");      
			   		sum_amount = Double.valueOf(df.format(sum_amount));
			   		total_amount = Double.valueOf(df.format(total_amount));
//
//			   		System.out.println("total_amount"+total_amount);
//			   		System.out.println("sum_amount"+sum_amount);
			   		
			   		if(Double.compare(total_amount,sum_amount)== 0){
			   			validataXmlAndDbValues("total_amount_due", total_amt_due, dbValue);
			   		}
			   		else{
						logger.log(LogStatus.FAIL, "Total_amount_Due"	+ "|---------- xmlValue: " + total_amt_due
								+ "----------dbValue: " + dbValue);
			   		}
			   		
		   		}
		   	}
		   	//validating mail_to_address
		   	if(lobfile.toString().equalsIgnoreCase("bill3")){
		   		if(elementName.trim().equalsIgnoreCase("address_line1")){
			        
	        		if(xpath.contains("mail_to_address/address/address_line1")){
	        			dbValue = getElementValueFromDB("mail_to_address/address_line1",invoiceId, sheetName, node);   				
	        			String xmlValue = node.getTextContent();
	    				validataXmlAndDbValues("mail_to_address/address_line1", xmlValue, dbValue);
	        		}

	        	}
		   		if(elementName.trim().equalsIgnoreCase("address_line2")){
	        		
	        		if(xpath.contains("mail_to_address/address/address_line2")){
	        			dbValue = getElementValueFromDB("mail_to_address/address_line3",invoiceId, sheetName, node);   				
	        			String xmlValue = node.getTextContent();
	    				validataXmlAndDbValues("mail_to_address/address_line2", xmlValue, dbValue);
	        		}
	        	}
		   		if(elementName.trim().equalsIgnoreCase("address_line3")){
	        		
	        		if(xpath.contains("mail_to_address/address/address_line3")){
	        			dbValue = getElementValueFromDB("mail_to_address/address_line",invoiceId, sheetName, node);   				
	        			String xmlValue = node.getTextContent();
	    				validataXmlAndDbValues("mail_to_address/address_line3", xmlValue, dbValue);
	        		}
	        	}
		   		
		   		
		   	}
		   	else{
		   	if(elementName.trim().equalsIgnoreCase("address_line1")){
		        
        		if(xpath.contains("mail_to_address/address/address_line1")){
        			dbValue = getElementValueFromDB("mail_to_address/address_line1",invoiceId, sheetName, node);   				
        			String xmlValue = node.getTextContent();
    				validataXmlAndDbValues("mail_to_address/address_line1", xmlValue, dbValue);
        		}

        	}
        	
		   	if(elementName.trim().equalsIgnoreCase("address_line2")){
        		
        		if(xpath.contains("mail_to_address/address/address_line2")){
        			dbValue = getElementValueFromDB("mail_to_address/address_line3",invoiceId, sheetName, node);   				
        			String xmlValue = node.getTextContent();
    				validataXmlAndDbValues("mail_to_address/address_line2", xmlValue, dbValue);
        		}
        	}
		   	if(elementName.trim().equalsIgnoreCase("address_line3")){
   
		   		if(xpath.contains("mail_to_address/address/address_line3")){
		   			dbValue = getElementValueFromDB("mail_to_address/address_line3",invoiceId, sheetName, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("mail_to_address/address_line3", xmlValue, dbValue);
		   		}
    		
		   	}
		   	}
		   	if(elementName.trim().equalsIgnoreCase("city")){
		   		if(xpath.contains("mail_to_address/address/city")){
		   			dbValue = getElementValueFromDB("mail_to_address/city",invoiceId, sheetName, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("mail_to_address/city", xmlValue, dbValue);
		   		}
   
		   	}
    	
		   	if(elementName.trim().equalsIgnoreCase("state")){
		   		if(xpath.contains("mail_to_address/address/state")){
		   			dbValue = getElementValueFromDB("mail_to_address/state",invoiceId, sheetName, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("mail_to_address/state", xmlValue, dbValue);
		   		}
   
		   	}
		   	if(elementName.trim().equalsIgnoreCase("zip")){
		   		if(xpath.contains("mail_to_address/address/zip")){
		   			dbValue = getElementValueFromDB("mail_to_address/zip",invoiceId, sheetName, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("mail_to_address/zip", xmlValue, dbValue);
		   		}
		   	}
		   	
		 	//validating leptext and lepamount values

		   	if(lobfile.toString().equalsIgnoreCase("mbill")){
		   		if((elementName.trim().equalsIgnoreCase("text1"))||(elementName.trim().equalsIgnoreCase("text2"))){
			   		if((elementName.trim().equalsIgnoreCase("text1"))&& (node.getTextContent().contains("LEP"))){
			   			flagLEP = 1;
		   		}
			   		if(flagLEP==1){
			   			String lep = node.getTextContent();
		   				if(lep.length()==9){
		   					dbValue = getElementValueFromDB("lep_text", invoiceId,sheetName, node);
		   					validataXmlAndDbValues("lep_text", lep, dbValue);
			   		}
			   		}
			   		if((elementName.trim().equalsIgnoreCase("text2"))&&(flagLEP==1)){
			   			dbValue = getElementValueFromDB("lep_amt", invoiceId,sheetName, node);
			   			String xmlValue  = node.getTextContent();
	   					validataXmlAndDbValues("lep_amt", xmlValue, dbValue);	
	   					flagLEP = 0;
			   		}
		   		}
		   	}
		   	//MAPD_IPDP
		   if(lobfile.toString().equalsIgnoreCase("mbill")){
			  if(elementName.toString().equalsIgnoreCase("contact_indicative")){
				  String xmlValue  = node.getTextContent();
				  if(xmlValue.length()==13){
					  dbValue = getElementValueFromDB("mapd_pdp", invoiceId,sheetName, node);
				   		//System.out.println(dbValue);
				   		//System.out.println("nodevalue :"+node.getTextContent());
					 
				   		validataXmlAndDbValues("mapd_pdp", xmlValue, dbValue); 
				  }
			  }
		   }
        
        //Medsupp
        if(lobfile.toString().equalsIgnoreCase("bill2")){
        	if(elementName.toString().equalsIgnoreCase("cdf1")){
        	dbValue = getElementValueFromDB("cdf1_Medsupp", invoiceId,sheetName, node);
	   		//System.out.println(dbValue);
	   		//System.out.println("nodevalue :"+node.getTextContent());
	   		String xmlValue  = node.getTextContent();
	   		validataXmlAndDbValues("cdf1_Medsupp", xmlValue, dbValue);
        	}
        	
        }
        //IFP
       if(lobfile.toString().equalsIgnoreCase("bill3")||lobfile.toString().equalsIgnoreCase("bill4")||lobfile.toString().equalsIgnoreCase("bill2")){
    	   if(lobfile.toString().equalsIgnoreCase("bill3")||lobfile.toString().equalsIgnoreCase("bill4")){
        	if(elementName.toString().equalsIgnoreCase("cdf1")){
        		dbValue = getElementValueFromDB("cdf1_IFP", invoiceId,sheetName, node);
		   		//System.out.println(dbValue);
		   		//System.out.println("nodevalue :"+node.getTextContent());
		   		String xmlValue  = node.getTextContent();
		   		validataXmlAndDbValues("cdf1_IFP", xmlValue, dbValue);
        	}
    	   }
        	
        	if(elementName.trim().equalsIgnoreCase("branding_id")){
        		if((lobfile.toString().equalsIgnoreCase("bill3"))||(lobfile.toString().equalsIgnoreCase("bill2"))){
        			//System.out.println("xpath is:"+xpath);
        			if(xpath.contains("main_logo/branding_id")){
        				dbValue = getElementValueFromDB("main_logo/branding_id_OFF",invoiceId, sheetName, node);   				
        				String xmlValue = node.getTextContent();
        				validataXmlAndDbValues("main_logo/branding_id", xmlValue, dbValue);
        			}
        			if(xpath.contains("remit_logo/branding_id")){
        				dbValue = getElementValueFromDB("remit_logo/branding_id_OFF",invoiceId, sheetName, node);   				
        				String xmlValue = node.getTextContent();
        				validataXmlAndDbValues("remit_logo/branding_id", xmlValue, dbValue);
        			}
        		}
        		if(lobfile.toString().equalsIgnoreCase("bill4")){
        			//System.out.println("xpath is:"+xpath);
        			if(xpath.contains("main_logo/branding_id")){
        				dbValue = getElementValueFromDB("main_logo/branding_id_ON",invoiceId, sheetName, node);   				
        				String xmlValue = node.getTextContent();
        				validataXmlAndDbValues("main_logo/branding_id", xmlValue, dbValue);
        			}
        			if(xpath.contains("remit_logo/branding_id")){
        				dbValue = getElementValueFromDB("remit_logo/branding_id_ON",invoiceId, sheetName, node);   				
        				String xmlValue = node.getTextContent();
        				validataXmlAndDbValues("remit_logo/branding_id", xmlValue, dbValue);
        			}
        		}
    		
        			
        	}
        	if(elementName.trim().equalsIgnoreCase("logo_text")){
        		//System.out.println("xpath is:"+xpath);
        			if(xpath.contains("main_logo/logo_text")){
        				dbValue = getElementValueFromDB("main_logo/logo_text",invoiceId, sheetName, node);   				
        				String xmlValue = node.getTextContent();
        				validataXmlAndDbValues("main_logo/logo_text", xmlValue, dbValue);
        			}
        		    if(xpath.contains("remit_logo/logo_text")){
        			dbValue = getElementValueFromDB("remit_logo/logo_text",invoiceId, sheetName, node);   				
        			String xmlValue = node.getTextContent();
    				validataXmlAndDbValues("remit_logo/logo_text", xmlValue, dbValue);
        		}
        	}
       }
		   	}
    
        	
    	
      
       
		
   		
       
		
	

	/**
	 * @param elemetName: To fetch the value from XML
	 * @param invoiceId: To replace in the query
	 * @param sheetName: Test data mapping sheet name for queries
	 * @param node: Node name
	 * @return: String: Database value for the respective query 
	 * @throws SQLException: To throw the ParseException exception
	 * @throws ParseException: To throw the ParseException exception
	 */

	public String getElementValueFromDB(String elemetName, String invoiceId,
			String sheetName, Element node) throws SQLException, ParseException {
		//Fetching query for the respective element name
		String query = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
		.getQueryFromMappingSheet(elemetName, sheetName);
		if(query == null){
			return "TagNotConsiderForValidation";
		}
		String[][] dbValue = null;
		//Checking for the NOT null value from test data mapping sheet
		if (query != null) {
			//Replacing "UniqueId" with invoice ID in the query
			if(elemetName.trim().equalsIgnoreCase("member_number")){
				subscriberId = node.getTextContent();
				//System.out.println("subscriber id is"+subscriberId);
			}
			if((elemetName.trim().equalsIgnoreCase("lep_text"))||(elemetName.trim().equalsIgnoreCase("lep_amt"))||					(elemetName.trim().equalsIgnoreCase("current_charges"))||
					(elemetName.trim().equalsIgnoreCase("net_credits_debits"))||(elemetName.trim().equalsIgnoreCase("mapd_pdp"))){
				//System.out.println("verifiied lep_value and subscriberId is :"+subscriberId);
				
				query = query.replace("SubscriberId", subscriberId);
			}
			SQLQuery = query.replace("UniqueId", invoiceId);
//		
//			System.out.println(SQLQuery);
//			System.out.println("DB Name: "+System.getenv("FACETS_DB"));
//			System.out.println("DB User: "+System.getenv("FACETS_USER"));
//			System.out.println("DB Password: "+System.getenv("FACETS_PASSWORD"));
//			System.out.println("DB Port: "+System.getenv("FACETS_PORT"));
//			System.out.println("DB Server: "+System.getenv("FACETS_SERVER"));
//			//Retrieving 2D array from database
			dbValue = (String[][]) new DBUtils().getTableArray("facets",SQLQuery);
//			System.out.println("length is "+dbValue.length);
		//	System.out.println("&&&&&&&&&&&&&&&&&&& "+dbValue.toString());
			//System.out.println("--------------"+dbValue[0][0]+"---------");
		}
		//Checking for the null value from database
		
		if (dbValue == null) {
 			return null;
 		} 
 		//Checking for the blank value from database
 			else if(dbValue.length == 0) {
 				return null;
 		}
 		//Returning 2D array 0,0 index value
 			else {
// 			System.out.println("Returned dbValue[0][0]: "+dbValue[0][0]);
 				return dbValue[0][0];
 		}
	}

	/**
	 *  To retrieve child nodes of node
	 * @param nNode: Main node name
	 * @param sheetName: Mapping sheet name
	 * @param invoiceId: To retrieve unique specific section
	 * @param tagname: Tag Name
	 * @throws Exception 
	 */
	private void getChildElements(String lobfile,Element nNode, String sheetName, String invoiceId, String tagname) throws Exception {
		NodeList children = nNode.getChildNodes();//To get child nodes of node

		// loop through all child nodes
		for (int i = 0; i < children.getLength(); i++) { 
			Node node = (Node) children.item(i);
			// System.out.println("node has child element: "+node);
			//Checking for the element node
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				if (hasChildElements((Element) node)) {// checking for child nodes
					// childCount++;
					// if(node.getTextContent().equalsIgnoreCase("ERMA L RHODES"))
					getElementAtttributes((Element) node, sheetName, invoiceId);// getting attributes of elements
					getChildElements(lobfile,(Element) node, sheetName, invoiceId, tagname);// getting child elements
					{
						if (node.hasAttributes()) //Checking for the node attributes

						{
							NamedNodeMap attributesList = node.getAttributes();
							for (int attribute_Number = 0; attribute_Number < attributesList
									.getLength(); attribute_Number++) {
							}
						}
						// System.out.println("getchildelement1: "+node.getTextContent());
					}
				}

				else {
					
					getValuesOfElement(lobfile,(Element) node, sheetName, invoiceId);
				}

			}

		}
	}

	/**
	 * To check the child nodes of the node
	 * @param element: Node name
	 * @return: Boolean value True or False
	 */
	private boolean hasChildElements(Element element) {
		//To get child nodes for the given node
		NodeList children = element.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			// looping through the nodes and checking for element node
			if (children.item(i).getNodeType() == Node.ELEMENT_NODE)
				return true;
		}
		return false;
	}

	/**
	 * To compare XML values against database values
	 * @param elementName: Tag name for reporting
	 * @param xmlValue:  XML value for comparison
	 * @param dbValue: Database value for comparison
	 */
	public void validataXmlAndDbValues(String elementName, String xmlValue,	String dbValue) {
		
		String status = "Fail";
		
		if(dbValue == null){
			//To compare XML value against database value
			
			dbValue= "[Blank]";
		}
		
		//Comparing both XML value and database value using soft assertion
		softAssertion.assertEquals(xmlValue.replaceAll("\\s+","").toUpperCase().trim(),	dbValue.replaceAll("\\s+","").toUpperCase().trim(),
			"xmlValue:" + xmlValue.replaceAll("\\s+","") + "| dbValue:" + dbValue.replaceAll("\\s+",""));
		// Pass logger for showing the results in extent report file
		if (xmlValue.replaceAll("\\s+", "").equalsIgnoreCase(dbValue.replaceAll("\\s+", ""))) {

			status = "Pass";
			logger.log(LogStatus.PASS, " Element Name: " + elementName + "|---------- Actual (XML file) value: " + xmlValue
					+ "---------- Expected (Database) value: " + dbValue + "|----------Status: " + status);
			System.out.println("Passed Element Name: " + elementName + "|---------- xmlValue: " + xmlValue.replaceAll("\\s+", "")
					+ "----------dbValue: " + dbValue.replaceAll("\\s+", ""));
		}
		// Failure logger for showing the results in extent report file
		else {
			logger.log(LogStatus.FAIL, " Element Name: " + elementName	+ "|---------- Actual (XML file) value: " + xmlValue
					+ "---------- Expected (Database) value: " + dbValue + "|----------Status: " + status);
			System.out.println("Failed Element Name: " + elementName + "|---------- xmlValue: " + xmlValue.replaceAll("\\s+", "")
					+ "----------dbValue: " + dbValue.replaceAll("\\s+", ""));
		}
		
		
	}

	
	/**
	 * To retrieve all file names from folder
	 * @param strFolderPath: Folder path  
	 * @return: returning files names in list
	 */
	public List<String> getFileNamesFromFolder(String strFolderPath)
	{
		List<String> fileNames = new ArrayList<String>();
		File folder = new File(strFolderPath);
		File[] files = folder.listFiles();//fetching no list of files from folder
		//Looping through all files in a folder
		for(int fileIndex = 0;fileIndex<files.length;fileIndex++) {
			//Checking for the directory
			if(files[fileIndex].isDirectory()){
				continue;
			}
			
			String fileName = files[fileIndex].getName();//fetching file name
			fileNames.add(fileName);
			
			//System.out.println("The file name is "+fileName);
			
		}
		return fileNames;
	}
	
	

	
	/**
	 *To get the XPath for the given node
	 * @param node: Node name
	 * @return: To return the XPath
	 */
	private String getXPath(Node node) {
		Node parent = node.getParentNode();
		if (parent == null) {
			return "";
		}
		//For returning XPath
		return getXPath(parent) + "/" + node.getNodeName();

	}

	

}
