package com.bsc.qa.facets.tests;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.utility.ExcelUtilsExtended;
import com.bsc.qa.facets.utility.XMLParseBSCLobs;
import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.relevantcodes.extentreports.LogStatus;

public class BscaBSCLobsTest extends BaseTest implements IHookable {
	private String inputFileName = null;
	private XMLParseBSCLobs xMLParse = null;
	private SoftAssert softAssert = null;
	
	public BscaBSCLobsTest(String inputFileName) {
		this.inputFileName=inputFileName;
		// TODO Auto-generated constructor stub
	}
	@Test void testXMLToDBValidationBSC_Bills() {
		softAssert = new SoftAssert();
		try {
			xMLParse = new XMLParseBSCLobs();
			//For fetching test data from test data excel file 
			Map<String, String> data = null;
			try {
				data = getData("XMLToDBValidationBills");
				System.out.println(data);
				
			} catch (Exception e) {
				System.out.println("in catch");
				e.printStackTrace();
			}
			//to retrieve parent tag from test data sheet
			String xmlTag = data.get("ELEMENT_TAG_NAME").toString().trim();
			//System.out.println(xmlTag);
			String xmlFilePath =inputFileName;	
			//For the initial XML setup
			xMLParse.xmlSetup(xmlFilePath);
			//assigning mapping sheet name in test data sheet to local variable
			String mappingSheetName = "MappingSheet_BSCBills";
			
		
			
			String FilePath = xmlFilePath.toString();
					
			String filename = FilePath.substring(xmlFilePath.lastIndexOf("\\")+1);
			filename = filename.toString().trim();
			System.out.println("The file name is: "+filename );
			
			
			int count = filename.length();
			//validating whether the filename is in valid format or not 
			if(((filename.substring(0,9).equals("bsc.fcts.")) && (filename.substring(count-11,count).equals(".tst.01.xml"))&&
				(Integer.valueOf(filename.substring(9,11))>=00 )&&(Integer.valueOf(filename.substring(9,11))<=12))&&
					(Integer.valueOf(filename.substring(11,13))>=00) &&( Integer.valueOf(filename.substring(11,13))<=31)&&
						(Integer.valueOf(filename.substring(13,17))>=0000) && (Integer.valueOf(filename.substring(9,11))<=9999)&&							
						(Integer.valueOf(filename.substring(17,19))>=00) && (Integer.valueOf(filename.substring(17,19))<=23)&&
						(Integer.valueOf(filename.substring(19,21))>=00) && (Integer.valueOf(filename.substring(19,21))<=59)&&
						(Integer.valueOf(filename.substring(21,23))>=00) && (Integer.valueOf(filename.substring(21,23))<=59)&&
										((filename.substring(23,29).equals(".cbill"))||(filename.substring(23,29).equals(".mbill"))||
												(filename.substring(23,29).equals(".bill2"))||(filename.substring(23,29).equals(".bill3"))||
												(filename.substring(23,29).equals(".bill4")))){
											System.out.println(filename+" is a valid filename");
			String lobfile = filename.substring(24,29);
			//To fetch all invoiceNumbers from XML, multiple subscriber data will be retrieved with pipe (|) delimiter
			//fetching all the invoice Id's present in the file
			String invoiceNumberList = xMLParse.uniqueDetailsExtraction(xmlTag,"data",3);
			//Verifying valid invoice Number details from XML
			if(!invoiceNumberList.equalsIgnoreCase("")) {
				String [] invoiceNumberArray = invoiceNumberList.split("\\|");
				
				//Iterating for all invoice Numbers to validate XML versus Database values
				for(int intICounter = 1; intICounter< invoiceNumberArray.length ; intICounter++){
					if(intICounter > 0)
					{
						
						//To get the report for each invoiceNumber in the XML
						//Parameters: to display report header in the HTML						
						reportInit("BSC_Bills XML to Facets("+System.getenv("ENVNAME")+")DB Validation", "Invoice ID:" + invoiceNumberArray[intICounter]);
						logger.log(LogStatus.INFO, "Starting test testXMLToDBValidationBSC_Bills");
						
					}
					//To log the XML file path in HTML report
					logger.log(LogStatus.INFO, "XML file path: " + xmlFilePath);
					//To log the invoiceNumber details in HTML report
					logger.log(LogStatus.INFO, "Validating Invoice ID: " + invoiceNumberArray[intICounter]);
					System.out.println("Validating Invoice ID: " + invoiceNumberArray[intICounter]);
					//validating specific Invoice Number's data, this is the main method for validating Bills
					xMLParse.nodeExtraction(lobfile,xmlTag, mappingSheetName, invoiceNumberArray[intICounter], softAssert);
					
				}
				
			}
			//To report the statement when file does not have invoice numbers
			else {
				logger.log(LogStatus.FAIL, "Please provide valid file name and inputs to fetch invoiceID data") ;
			}
		
		
			
		}
			else{
				System.out.println(filename+" is an invalid filename");
			    logger.log(LogStatus.FAIL, "Please provide valid file name") ;
				//break;
			}
				
		
	}
		
		catch (Exception e)	{
			System.out.println("Test script Failed due to Exception.....!!");
			logger.log(LogStatus.FAIL, "Test script Failed due to Exception.....!!" + e.getMessage() );
			softAssert.fail("Test script Failed due to Exception.....!!", e.getCause());
			e.printStackTrace();
		}finally{
			softAssert.assertAll();	//<== absolutely must be here
		}
	}


	
	
	/**
	 * //To run test method, this method will initiate the HTML report
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		//To execute test method multiple times
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}
	
	/**
	 * DataProvider for returning the specific test data based on test method
	 * name
	 * 
	 * @param String: Method name
	 * @return
	 */
	private Map<String,String> getData(String method) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		//assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";
		System.out.println("xls path is " +xlsPath);
		//Fetching data from test data excel file based on method name
		//String xlsPath = "\\bsc\\it\\VDI_Home_SAC\\pbhuva01\\Desktop\\BscaBSCTest.xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, method);
		return dataMap;
	}
	

}
