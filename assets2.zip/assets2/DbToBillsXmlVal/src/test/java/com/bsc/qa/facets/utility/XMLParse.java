package com.bsc.qa.facets.utility;
import static org.testng.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.testng.asserts.SoftAssert;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.relevantcodes.extentreports.LogStatus;



public class XMLParse extends BaseTest {
	
	private  DocumentBuilder dBuilder;
	private  Document doc;
	private SoftAssert softAssertion = null;
	int index=0;
	public  String dbValue;
	private String strUniqueData = "";
	private int intUniqueIndexNumber = 0;
	double lepAmount;
	double lsiAmount;
	int flagLEP = 0;
	int flagLSI = 0;
	public String xml_suppress_print = "";
	public String payments = "";
	public String past_due_amount="";
	public String total_amt_due="";
	public String curr_charges = "";
	public String net_cred_deb = "";
	
	
	/**
	 * To create instance of document builder for the XML
	 * @param xmlPath: XML file complete path
	 */
	public  void xmlSetup(String xmlPath) {
		File fXmlFile=new File(xmlPath);//Creating file for the given path
		//ExcelUtilities.setUp();
		//creating instance for the DocumentBuilderFactory
		DocumentBuilderFactory dbFactory= DocumentBuilderFactory.newInstance();
		
		try {
			//creating instance for the DocumentBuilder
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
		} catch (ParserConfigurationException e) {e.printStackTrace();		}
		  catch (SAXException e) {e.printStackTrace();} 
		  catch (IOException e) {e.printStackTrace();}
	}
	
	public  ArrayList<String> attributeValue(String tagName){
		//System.out.println("Extracting attribute values!!");
		ArrayList<String> idList = new ArrayList<String>();//List for storing attributes
		//Accessing the the nodes having tagname
		NodeList PagesList=doc.getElementsByTagName(tagName);
		//Looping through the nodeslist
		for(int nodeNo =0;nodeNo<PagesList.getLength();nodeNo++){
			Node node = (Node)PagesList.item(nodeNo);
			
			//checking for the attributes in node
			if(node.hasAttributes()){
				NamedNodeMap attributesList=node.getAttributes();//getting all the attributes in the node
				//looping through the attributes list
				for(int attribute_Number=0;attribute_Number<attributesList.getLength();attribute_Number++){
				//getting Attributes in the attributes list	
					Attr attr=(Attr) attributesList.item(attribute_Number);
				//	String attributeName=attr.getNodeName();
					String attributeValue=attr.getNodeValue();
//					System.out.println("The attribute values are !!!!"+attributeValue);
					idList.add(attributeValue);
				}
			}else{System.out.println("The node has no attributes!!!");}
	}
		return idList;//retuning the attributes list
	}
	
	
	
	/**
	 * To extract Unique data from XML
	 * @param tagName: Primary parent tag name
	 * @param strUniqueTagName: Unique tag name
	 * @return : To return all unique values with "|" this delimiter
	 * @throws SQLException: To throw the SQLException exception
	 * @throws ParseException: To throw the ParseException exception
	 */
	public String uniqueDetailsExtraction(String tagName, String strUniqueTagName, int intIndexNumber) throws SQLException, ParseException{
		
		//To initialize the variable
		strUniqueData = "";
		//To get the elements using tagName
		NodeList PagesList = doc.getElementsByTagName(tagName);
		//Checking each parent tag sections in the XML using for loop
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);
			index = 0;
			intUniqueIndexNumber = 0;
			//To check the node when it is having child elements
			if (hasChildElements((Element) node)) {				
				//To extract Unique tag data from XML 
				parseChildElementsForUniqueIDs((Element) node, strUniqueTagName,intIndexNumber);
			}
		}
		// Returning unique data with pipe (|) delimiter
		return strUniqueData;
	}
	

	/**
	 * To extract Unique data from XML
	 * @param nNode: Parent node to retrieve child nodes along with tag values
	 * @param strUniqueTagName: Unique tag name to retrieve corresponding value
	 * @throws SQLException: To throw the SQLException exception
	 * @throws ParseException:  To throw the ParseException exception
	 */
	private void parseChildElementsForUniqueIDs(Element nNode, String strUniqueTagName, int intIndexNumber)	throws SQLException, ParseException {
		
		String elementName = "";
		String elementvalue = "";
		
		NodeList children = nNode.getChildNodes();// get child nodes of node
		for (int i = 0; i < children.getLength(); i++) { // loop through all child nodes
			Node node = (Node) children.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				elementName = node.getNodeName().trim().toString();
	
				elementvalue = node.getTextContent().trim().toString();
				//Checking unique element name in the XML
				if ((elementName.equalsIgnoreCase(strUniqueTagName))) {
					intUniqueIndexNumber += 1;
					if(intUniqueIndexNumber == intIndexNumber){
						//Storing Unique data into strUniqueData variable with pipe (|) delimiter
						strUniqueData = strUniqueData + "|" + elementvalue;
					}
					
					
				} else if (hasChildElements((Element) node)) {// checking for the child elements
					//calling recursive function to fetch data from child				
					parseChildElementsForUniqueIDs((Element) node, strUniqueTagName,intIndexNumber);
				}
			}
		}
	}

	
	
	//Method to extract elements and attributes and its values
	public  void  nodeExtraction(String tagName,String mappingSheetName,String invoiceId, SoftAssert softAssert) throws SQLException, ParseException {
	
		//System.out.println("Tag Name is : " + tagName);
        NodeList PagesList=doc.getElementsByTagName("*");
        Node pNode = null;
		//System.out.println("xml tags are "+PagesList.getLength());
		for(int nodeNo =0;nodeNo<PagesList.getLength();nodeNo++){
			softAssertion = softAssert;
		Node node = (Node)PagesList.item(nodeNo);
		if (node.getNodeName().equalsIgnoreCase(tagName))
		{
			 pNode = node;
		}
	 //System.out.println("Parent Node is :" + pNode.getNodeName());
		index=0;
		 lepAmount=0.00;
		 lsiAmount=0.00;
        if(node.hasAttributes()){
			NamedNodeMap attributesList=node.getAttributes();
			for(int attribute_Number=0;attribute_Number<attributesList.getLength();attribute_Number++){
				//softAssertion = softAssert;
				Attr attr=(Attr) attributesList.item(attribute_Number);
				String attributeValue=attr.getNodeValue();
			     if(attributeValue.equals(invoiceId)){
				   if(hasChildElements((Element)node)){
					   //System.out.println("Parent Node is :" + pNode.getNodeName());
						getElementAtttributes((Element)pNode, mappingSheetName);
							getChildElements((Element)pNode,mappingSheetName,invoiceId);
					   }
				}
			     }
			}
		}
		}
	 //Method to retrieve all the attributes of elements
		private void getElementAtttributes(Element node, String sheetName) throws SQLException {
			if(node.hasAttributes()){
				NamedNodeMap attributesList=node.getAttributes();
					for(int attribute_Number=0;attribute_Number<attributesList.getLength();attribute_Number++){
						Attr attr=(Attr) attributesList.item(attribute_Number);
				//System.out.println("attributeName: "+attributeName);
						//String attributeValue=attr.getNodeValue();
					 //  System.out.println("attributeValue: "+attributeValue);
			            //ExcelUtilities.setCellData(attributeName,attributeValue,elementType,rowNo++);
						//System.out.println("AttributeName: "+attributeName+"  attributeValue:"+attributeValue);
					}
			}
			
		}
		
		public void validataXmlAndDbValues(String elementName,String xmlValue, String dbValue) {
			//validation of the xml and db values
			//System.out.println(" Element Name: " + elementName + "|---------- xmlValue: " +xmlValue.replaceAll("\\s+","")+ "----------dbValue: " + dbValue.replaceAll("\\s+",""));
		  softAssertion.assertEquals(xmlValue.replaceAll("\\s+",""), dbValue.replaceAll("\\s+",""),"xmlValue:"+xmlValue.replaceAll("\\s+","")+"| dbValue:"+dbValue.replaceAll("\\s+",""));
			String status="Fail";	
			// Pass logger for showing the results in extent report file
			if (xmlValue.replaceAll("\\s+", "").equalsIgnoreCase(dbValue.replaceAll("\\s+", ""))) {

				status = "Pass";
				logger.log(LogStatus.PASS, " Element Name: " + elementName + "|---------- Actual (XML file) value: " + xmlValue
						+ "---------- Expected (Database) value: " + dbValue + "|----------Status: " + status);
				System.out.println("Passed Element Name: " + elementName + "|---------- xmlValue: " + xmlValue.replaceAll("\\s+", "")
						+ "----------dbValue: " + dbValue.replaceAll("\\s+", ""));
			}
			// Failure logger for showing the results in extent report file
			else {
				logger.log(LogStatus.FAIL, " Element Name: " + elementName	+ "|---------- Actual (XML file) value: " + xmlValue
						+ "---------- Expected (Database) value: " + dbValue + "|----------Status: " + status);
				System.out.println("Failed Element Name: " + elementName + "|---------- xmlValue: " + xmlValue.replaceAll("\\s+", "")
						+ "----------dbValue: " + dbValue.replaceAll("\\s+", ""));
				
			}
			
				
		}
		/**
		 *To get the XPath for the given node
		 * @param node: Node name
		 * @return: To return the XPath
		 */
		private String getXPath(Node node) {
			Node parent = node.getParentNode();
			if (parent == null) {
				return "";
			}
			//For returning XPath
			return getXPath(parent) + "/" + node.getNodeName();

		}
		
		//This method is used to get each node value from xml and compare with respective DB Value
		private void getValuesOfElement(Element node,  String sheetName,String invoiceId) throws SQLException {
			String xpath = getXPath(node);
			//getting the query for the given element name
			String elementName=node.getNodeName();
			//System.out.println("elementName: "+elementName);
			NodeList children=node.getChildNodes();
	       //System.out.println("children:"+node.getTextContent());
	        Node elementvalue1Parent=node.getParentNode();

			
			  
		 //System.out.println("Parent:"+elementvalue1Parent);
		   	if(elementName.toString().equalsIgnoreCase("data"))
				{
		   		  index++;
				   //System.out.println("index of parent:"+ index);
				//}
					 if(index==3)
					 {
					   // System.out.println("i am in index 1");
					   dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"Invoice_Number",sheetName,invoiceId, node);
					   // System.out.println("db value is:"      +dbValue);
					   validataXmlAndDbValuesWrapper(node,"Invoice_Number",dbValue);
					   
				       }
					 else if(index==1)
					 {
						 // System.out.println("i am in index 1");
						 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"group_Number",sheetName,invoiceId, node);
						 //System.out.println("The element name is "+node.getNodeName().trim().toString()+"_"+"group_Number");
						// System.out.println("db value is:"      +dbValue);
						 validataXmlAndDbValuesWrapper(node,"group_Number",dbValue);
						//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"group_Number",node.getTextContent(),dbValue);
					 }
					 else if(index==2)
					 {
						 // System.out.println("i am in index 2");
						 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"Member_No",sheetName,invoiceId, node);
						 // System.out.println("db value is:"      +dbValue);
						 validataXmlAndDbValuesWrapper(node,"Member_No",dbValue);
						 //validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"Member_No",node.getTextContent(),dbValue);
					 }
					 else if(index==9)
					 {
						 // System.out.println("i am in index 9");
						 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"account_number",sheetName,invoiceId, node);
						 // System.out.println("db value is:"      +dbValue);
						 validataXmlAndDbValuesWrapper(node,"account_number",dbValue);
						//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"account_number",node.getTextContent(),dbValue);
					 }
					 else if(index==10)
					 {
						 // System.out.println("i am in index 1");
						 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"bill_date",sheetName,invoiceId, node);
						 // System.out.println("db value is:"      +dbValue);
						 validataXmlAndDbValuesWrapper(node,"bill_date",dbValue);
						//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"bill_date",node.getTextContent(),dbValue);
					 }
					 else if(index==11)
					 {
						 // System.out.println("i am in index 1");
						 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"Billing_Period",sheetName,invoiceId, node);
						 // System.out.println("db value is:"      +dbValue);
						 validataXmlAndDbValuesWrapper(node,"Billing_Period",dbValue);
						//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"Billing_Period",node.getTextContent(),dbValue);
					 }
					 else if(index==12)
					 {
						 // System.out.println("i am in index 1");
						 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"bill_due_date",sheetName,invoiceId, node);
						//  System.out.println("db value is:"      +dbValue);
						 validataXmlAndDbValuesWrapper(node,"bill_due_date",dbValue);
						//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"bill_due_date",node.getTextContent(),dbValue);
					 }
					 else if(index==14)
					 {
						 // System.out.println("i am in index 1");
						 payments = node.getTextContent();
						 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"total_payment",sheetName,invoiceId, node);
						 // System.out.println("db value is:"      +dbValue);
						 validataXmlAndDbValuesWrapper(node,"total_payment",dbValue);
						//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"total_payment",node.getTextContent(),dbValue);
					 }
					 else if(index==13)
					 {
						 // System.out.println("i am in index 5");
						 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"previous_amount_due",sheetName,invoiceId, node);
						 // System.out.println("db value is:"      +dbValue);
						 validataXmlAndDbValuesWrapper(node,"previous_amount_due",dbValue);
						//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"previous_amount_due",node.getTextContent(),dbValue);
					 }
					 else if(index==15)
					 {
						 // System.out.println("i am in index 5");
						 past_due_amount=node.getTextContent();
						 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"PastDueAmount",sheetName,invoiceId, node);
						 // System.out.println("db value is:"      +dbValue);
						 validataXmlAndDbValuesWrapper(node,"PastDueAmount",dbValue);
						//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"PastDueAmount",node.getTextContent(),dbValue);
					 }
					  else if(index==18)
					 {
						 // System.out.println("i am in index 5");
						  total_amt_due = node.getTextContent();
						  dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"TotalAmountDue",sheetName,invoiceId, node);
						  //String total_amt_due  = node.getTextContent();
						  total_amt_due = total_amt_due.replace(",","");
					   		double sum_amount= Double.parseDouble(past_due_amount)+(Double.parseDouble(curr_charges))+
			   				Double.parseDouble(net_cred_deb);
					   		
					   		double total_amount = Double.parseDouble(total_amt_due);
					   		
					   		DecimalFormat df = new DecimalFormat("#.##");      
					   		sum_amount = Double.valueOf(df.format(sum_amount));
					   		total_amount = Double.valueOf(df.format(total_amount));
					   		
					   		if(Double.compare(total_amount,sum_amount)== 0){
					   			//validataXmlAndDbValues("total_amount_due", total_amt_due, dbValue);
					   			validataXmlAndDbValuesWrapper(node,"TotalAmountDue",dbValue);
					   		}
					   		else{
					   			System.out.println("Failed Total_amount_Due Calculation"	+ "|---------- total_amt_due: " + total_amount
										+ "----------(past_due_amt+current_charges+net_cred_deb): " + sum_amount);
								logger.log(LogStatus.FAIL,"Total_amount_Due Calculation"	+ "|---------- total_amt_due: " + total_amount
									+ "----------(past_due_amt+current_charges+net_cred_deb): " + sum_amount );
//								softAssertion.fail("Failed due to Total_amount_due Calculation testcase");
								
					   		}
						
					 }
					  else if(index==4)
						 {
							 // System.out.println("i am in index 5");
							 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"TotalDue",sheetName,invoiceId, node);
							 // System.out.println("db value is:"      +dbValue);
							 validataXmlAndDbValuesWrapper(node,"TotalDue",dbValue);
							//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"TotalDue",node.getTextContent(),dbValue);
						 }
					  else if(index==16)
						 {
							 // System.out.println("i am in index 5");
						  	curr_charges = node.getTextContent();
							 dbValue=getElementValueFromDB(node.getNodeName().trim().toString()+"_"+"CurrentCharges",sheetName,invoiceId, node);
							 // System.out.println("db value is:"      +dbValue);
							 validataXmlAndDbValuesWrapper(node,"CurrentCharges",dbValue);
							//validataXmlAndDbValues(node.getNodeName().trim().toString()+"_"+"CurrentCharges",node.getTextContent(),dbValue);
						 }
					  else if (index==17)
					  {
						  net_cred_deb = node.getTextContent();
							 
					  }

				}
		
		   	//Validating suppress_print tag
//		   	if(elementName.toString().equalsIgnoreCase("suppress_print"))
//            {
//                  //System.out.println("&& Inside supress print");
//                    xml_suppress_print=node.getTextContent();
//                   //System.out.println("%%%%% suppress_print"+ xml_suppress_print);
//              dbValue=getElementValueFromDB("sup_print",sheetName,invoiceId, node);
//              validataXmlAndDbValues("suppress_print", xml_suppress_print, dbValue);
//              
//              
//            }
            
            //Validating contact_indicative tag
  			 if(elementName.toString().equalsIgnoreCase("contact_indicative"))
  			 {
  				 String xmlValue  = node.getTextContent();
  				 if(xmlValue.length()==3)
  				 {
  					  dbValue = getElementValueFromDB("contact_indicative_TTY",sheetName,invoiceId, node);
  				   	  validataXmlAndDbValues("contact_indicative", xmlValue, dbValue); 
  				 }
  				 if(xmlValue.length()==13){
  					  dbValue = getElementValueFromDB("contact_indicative_MemSerDep",sheetName,invoiceId, node);
  					  validataXmlAndDbValues("contact_indicative", xmlValue, dbValue); 
  				  }
  			  }
  			  //-------------------- Return Address And Remit Address Validation-----------------------------------------
  			  if(elementName.trim().equalsIgnoreCase("address_line1")){
        		if(xpath.contains("return_address/address/address_line1")){
        			dbValue = getElementValueFromDB("return_address/address_line1",sheetName,invoiceId, node);   				
        			String xmlValue = node.getTextContent();
    				validataXmlAndDbValues("return_address/address_line1", xmlValue, dbValue);
        		}
        		if(xpath.contains("remit_address/address/address_line1")){
        			dbValue = getElementValueFromDB("remit_address/address_line1",sheetName,invoiceId, node);   				
        			String xmlValue = node.getTextContent();
    				validataXmlAndDbValues("remit_address/address_line1", xmlValue, dbValue);
        		}

        	}
        	
		   	if(elementName.trim().equalsIgnoreCase("address_line2")){
        		
        		if(xpath.contains("return_address/address/address_line2")){
        			dbValue = getElementValueFromDB("return_address/address_line2",sheetName,invoiceId, node);   				
        			String xmlValue = node.getTextContent();
    				validataXmlAndDbValues("return_address/address_line2", xmlValue, dbValue);
        		}
        		if(xpath.contains("remit_address/address/address_line2")){
        			dbValue = getElementValueFromDB("remit_address/address_line2",sheetName,invoiceId, node);   				
        			String xmlValue = node.getTextContent();
    				validataXmlAndDbValues("remit_address/address_line2", xmlValue, dbValue);
        		}
        	}
		   	if(elementName.trim().equalsIgnoreCase("address_line3")){
   
		   		if(xpath.contains("return_address/address/address_line3")){
		   			dbValue =getElementValueFromDB("return_address/address_line3",sheetName,invoiceId, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("return_address/address_line3", xmlValue, dbValue);
		   		}
    		
		   	}
		   	
		   	if(elementName.trim().equalsIgnoreCase("city")){
		   		if(xpath.contains("return_address/address/city")){
		   			dbValue = getElementValueFromDB("return_address/city",sheetName,invoiceId, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("return_address/city", xmlValue, dbValue);
		   		}
		   		if(xpath.contains("remit_address/address/city")){
		   			dbValue = getElementValueFromDB("remit_address/city",sheetName,invoiceId, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("remit_address/city", xmlValue, dbValue);
		   		}
   
		   	}
    	
		   	if(elementName.trim().equalsIgnoreCase("state")){
		   		if(xpath.contains("return_address/address/state")){
		   			dbValue = getElementValueFromDB("return_address/state",sheetName,invoiceId, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("return_address/state", xmlValue, dbValue);
		   		}
		   		if(xpath.contains("remit_address/address/state")){
		   			dbValue = getElementValueFromDB("remit_address/state",sheetName,invoiceId, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("remit_address/state", xmlValue, dbValue);
		   		}
   
		   	}
		   	if(elementName.trim().equalsIgnoreCase("zip")){
		   		if(xpath.contains("return_address/address/zip")){
		   			dbValue = getElementValueFromDB("return_address/zip",sheetName,invoiceId, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("return_address/zip", xmlValue, dbValue);
		   		}
		   		if(xpath.contains("remit_address/address/zip")){
		   			dbValue = getElementValueFromDB("remit_address/zip",sheetName,invoiceId, node);   				
		   			String xmlValue = node.getTextContent();
		   			validataXmlAndDbValues("remit_address/zip", xmlValue, dbValue);
		   		}
		   	}
		   	
	//-------------------------------------------LEP and LIS Calculations (LEP+LSI==Net Credit/Debit)--------------
		   	if((elementName.trim().equalsIgnoreCase("text1"))&&(node.getTextContent().contains("LEP"))){
		   		flagLEP = 1;
		   	}
		   	if((elementName.trim().equalsIgnoreCase("text2")&& (flagLEP==1))){
		   		String xmlValue = node.getTextContent();
		   		lepAmount=lepAmount+Double.parseDouble(xmlValue);
		   		flagLEP = 0;
		   	}
		   	
		 	if((elementName.trim().equalsIgnoreCase("text1"))&&(node.getTextContent().contains("100% Part D Subsidy"))){
		   		flagLSI = 1;
		   	}
		   	if((elementName.trim().equalsIgnoreCase("text2")&& (flagLSI==1))){
		   		String xmlValue = node.getTextContent();
		   		lsiAmount=lsiAmount+Double.parseDouble(xmlValue);
		   		flagLSI = 0;
		   	}
		   	if((elementName.trim().equalsIgnoreCase("text1"))&&((node.getTextContent().contains("Net Credits/Debits"))||(node.getTextContent().contains("None Applied")))){
		   		double netCredDeb = Double.parseDouble(net_cred_deb);
		   		if(((lepAmount+lsiAmount)==0.0)|| (netCredDeb == 0.0)){
		   			System.out.println("LEP or LSI Amount is not present for this invoiceID");
		   		}
		   		else if(((lepAmount+lsiAmount) == netCredDeb)){
		   			System.out.println("LEP and LSI Amount Calculation Passed : |-----------(LEP + LSI) Amount: " + (lepAmount+lsiAmount)
							+ "---------- Net Credit/Debit  " + netCredDeb + "");
		   			logger.log(LogStatus.PASS,"|LEP and LSI Amount Calculation-----------(LEP + LSI) Amount : " + (lepAmount+lsiAmount)
							+ "---------- Net Credit/Debit  " + netCredDeb + "|----------Status: Pass "); 
		   		}else{
		   			System.out.println("LEP and LSI Amount Calculation Failed : |-----------(LEP + LSI) Amount: " + (lepAmount+lsiAmount)
							+ "---------- Net Credit/Debit  " + netCredDeb + "");
		   			logger.log(LogStatus.FAIL,"|LEP and LSI Amount Calculation---------- (LEP + LSI) Amount: " + (lepAmount+lsiAmount)
							+ "---------- Net Credit/Debit  " + netCredDeb + "|----------Status: Fail "); 
		   		}
//		   		if(xml_suppress_print.trim().trim().equalsIgnoreCase("Y"))
//	              {
//	              if(past_due_amount.equalsIgnoreCase("0.00") && total_amt_due.equalsIgnoreCase("0.00") 
//	            		  && payments.equalsIgnoreCase("0.00") && net_cred_deb.equalsIgnoreCase("0.00")){
//	            	  	System.out.println("TC015 is Passed-----suppress_print:"+xml_suppress_print+"-----PastDueAmount:"+past_due_amount+"-----TotalAmountDue:"+total_amt_due+"-------"
//	                    		+ "Payments:"+payments+"------Net_Cedit_Debit:"+net_cred_deb+"");
//	                    logger.log(LogStatus.PASS,"TC015--------suppress_print:"+xml_suppress_print+"-----PastDueAmount:"+past_due_amount+"-----TotalAmountDue:"+total_amt_due+"-------"
//	                    		+ "Payments:"+payments+"------Net_Cedit_Debit:"+net_cred_deb+" Status: Pass");
//	                     
//	              }
//	             else{
//	                    System.out.println("TC015 is Failed-----suppress_print:"+xml_suppress_print+"-----PastDueAmount:"+past_due_amount+"-----TotalAmountDue:"+total_amt_due+"-------"
//	                    		+ "Payments:"+payments+"------Net_Cedit_Debit:"+net_cred_deb+"");
//	                    logger.log(LogStatus.FAIL," TC015--------suppress_print:"+xml_suppress_print+"-----PastDueAmount:"+past_due_amount+"-----TotalAmountDue:"+total_amt_due+"-------"
//	                    		+ "Payments:"+payments+"------Net_Cedit_Debit:"+net_cred_deb+" Status: Fail");
//	                  }
//	              }
		   	}
		      		
		}
				
		/**
		 * To retrieve database value for the nodes and compare database values with XML values
		 * @param node: Node name for comparison
		 * @param sheetName: Test data mapping sheet name for queries
		 * @param invoiceId: Unique id to replace in the query
		 * @param elemetName: Name of the element to be validated
		 * @throws Exception 
		 */	
	//This method is used to retrieve value of the field from the database	
	private String getElementValueFromDB(String elemetName,  String sheetName,String invoiceId,Element node ) throws SQLException {
		//retrieve query for the given element name
		//System.out.println("tHE ELEMENT NAME IS "+elemetName);
		String query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", sheetName).getQueryFromMappingSheet(elemetName,sheetName);
		if(query == null){
			return "TagNotConsiderForValidation";
		}
		//System.out.println("Query:"+query);
	      // System.out.println("children:"+node.getTextContent());
	       /*if(elemetName.equalsIgnoreCase("data"))
			{
				query=dbValue;
			}*/
		String[][] dbValue = null;
	   if(query!=null){//check for the null values of query
		//	String	SQLQuery=query.replace( "VAR_SBSB_ID_VALUE",BillId);//replacing subscriber id
			 String SQLQuery=query.replace( "UniqueId",invoiceId);//replacing subscriber id
			 //System.out.println("Running SQLQuery: "+SQLQuery);
			 
			//running the query and getting the database value
			//Retrieving 2D array from database
			dbValue = (String[][]) new DBUtils().getTableArray("facets",SQLQuery);
//			System.out.println("Data retrieved from SQLQuery: "+dbValue);
//			
//			if(elemetName.equalsIgnoreCase("sup_print")){
//				try {
//					System.out.println("Waiting for 2 mins");
//					Thread.sleep(120000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
			
			 //dbValue=BscaCare1stMMTest.objDBUtility.getDatabaseValue(SQLQuery);
			// System.out.println("dbvalue:  "+dbValue);
			
		}
	 //Checking for the null value from database
	 		if (dbValue == null) {
	 			return null;
	 		} 
	 		//Checking for the blank value from database
	 		else if(dbValue.length == 0) {
	 			return null;
	 		}
	 		//Returning 2D array 0,0 index value
	 		else {
//	 			System.out.println("Returned dbValue[0][0]: "+dbValue[0][0]);
	 			return dbValue[0][0];
	 			
	 		}
	}
	
	
	//This method is to retrieve child nodes of node
	private void getChildElements(Element nNode,  String sheetName,String invoiceId) throws SQLException {
		NodeList children=nNode.getChildNodes();
		//System.out.println("children: "+children);
//		if(children.toString().trim().contains("remit_address"))
//		{
//			return;
//		}
//		if(children.toString().trim().contains("return_address"))
//		{
//			return;
//		}
		//String xPath = getXPath(nNode);
		//System.out.println("The xpath is "+xPath);
		for(int i=0;i<children.getLength();i++){
				Node node=(Node) children.item(i);
				
				
					if(node.getNodeType()==Node.ELEMENT_NODE){
						if(hasChildElements((Element)node)){
							
								//childCount++;
								getElementAtttributes((Element) node, sheetName);
								getChildElements((Element)node,sheetName,invoiceId);
						   }else{ 
							 	getValuesOfElement((Element)node,sheetName,invoiceId);
							    }
					   }}}
	
	//Method to check if element has child nodes
	private boolean hasChildElements(Element el) {
		//get child nodes for the given node
		NodeList children=el.getChildNodes();
		for(int i=0;i<children.getLength();i++){
			//looping through the nodes and checking for element node
		if(children.item(i).getNodeType()==Node.ELEMENT_NODE)//chck for element node
			return true;
		}
		
	return false;
	}
	
	
	//Method to compare xml against the db value
	private void validataXmlAndDbValuesWrapper(Element node,String strFieldName, String dbValue){
	
		if(dbValue == null){
			//To compare XML value against database value
		
			validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + strFieldName, node.getTextContent(), "[Blank]");
		}
		//Checking for the database value when field is considered for validation
		else if(!dbValue.equalsIgnoreCase("TagNotConsiderForValidation")){
			//To compare XML value against database value
		
			validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + strFieldName, node.getTextContent(),	dbValue);
		
		}
	}


}
	

