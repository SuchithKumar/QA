package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileBody {

	
	private String EFFPLNYR_PRODID_LANG;
	private String SUBID_LSTNM;
	private String MEME_FIRST_NAME;
	private String MEME_MID_INIT;
	private String ADDRESS;
	private String SBAD_CITY;
	private String STATE_ZIP;
	private String IPA_ID;
	
	public String getEFFPLNYR_PRODID_LANG() {
		return EFFPLNYR_PRODID_LANG;
	}
	public void setEFFPLNYR_PRODID_LANG(String eFFPLNYR_PRODID_LANG) {
		EFFPLNYR_PRODID_LANG = eFFPLNYR_PRODID_LANG;
	}
	
	public String getSUBID_LSTNM() {
		return SUBID_LSTNM;
	}
	public void setSUBID_LSTNM(String sUBID_LSTNM) {
		SUBID_LSTNM = sUBID_LSTNM;
	}
	public String getMEME_FIRST_NAME() {
		return MEME_FIRST_NAME;
	}
	public void setMEME_FIRST_NAME(String mEME_FIRST_NAME) {
		MEME_FIRST_NAME = mEME_FIRST_NAME;
	}
	public String getMEME_MID_INIT() {
		return MEME_MID_INIT;
	}
	public void setMEME_MID_INIT(String mEME_MID_INIT) {
		MEME_MID_INIT = mEME_MID_INIT;
	}
	public String getADDRESS() {
		return ADDRESS;
	}
	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}
	public String getSBAD_CITY() {
		return SBAD_CITY;
	}
	public void setSBAD_CITY(String sBAD_CITY) {
		SBAD_CITY = sBAD_CITY;
	}
	public String getSTATE_ZIP() {
		return STATE_ZIP;
	}
	public void setSTATE_ZIP(String sTATE_ZIP) {
		STATE_ZIP = sTATE_ZIP;
	}
	public String getIPA_ID() {
		return IPA_ID;
	}
	public void setIPA_ID(String iPA_ID) {
		IPA_ID = iPA_ID;
	}
		
	
}
