package com.bsc.qa.facets.ffpojo.utility;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.testng.asserts.SoftAssert;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.tests.BscaCare1stMMTest;
import com.relevantcodes.extentreports.LogStatus;

public class XMLParse extends BaseTest {

	private static DocumentBuilder dBuilder;
	private static Document doc;
	private static String uniqueId;
	public static ExcelUtils excelUtils;
	public static int messageTextIndex;

	public static int hcpcsIndex;
	public static int line_item_charge_amtIndex;
	public static int original_units_of_service_countIndex;
	public static int service_start_dateIndex;
	public static int contractual_obligationIndex;
	public static int serviceallowed_amtIndex;
	public static int servicedeductible_amtIndex;
	public static int claimallowed_amtIndex;
	public static int claimdeductible_amtIndex;
	public static int copay_amtIndex;
	public static int line_item_provider_pmt_amt_printIndex;
	public static Map<String, String> claimListMap = new HashMap<String, String>();
	public static Map<String, String> claimMap = new HashMap<String, String>();
	public static int claimIdIndex;
	public static Map<String, String> claimidMap = new HashMap<String, String>();
	public static String claimId;
	public static int keyIndex;
	public static SoftAssert softAssertion;
	private static HashMap<Integer, String> collNumCellValueMap = new HashMap<Integer, String>();
	public static int claimTagIndex;
	private static int execNo_CollNum_Datasheet = 0;
	private static int elementName_CollNum_Datasheet = 1;
	private static int comments_Datasheet = 5;
	private static int expectedValue_CollNum_Datasheet = 2;
	public static List<Map<String, String>> dbValueList = new ArrayList<Map<String, String>>();
	private static int actualValueCollNum = 3;

	private static int resultCollNum = 4;
	private static int rowNum_Datasheet = 0;

	public static void xmlSetup(String xmlPath) {
		File fXmlFile = new File(xmlPath);// Creating file for the given path
		// ExcelUtilities.setUp();
		// creating instance for the DocumentBuilderFactory
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		try {
			// creating instance for the DocumentBuilder
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static ArrayList<String> attributeValue(String tagName,
			String attributename) {

		// System.out.println("Extracting attribute values!!");
		ArrayList<String> idList = new ArrayList<String>();// List for storing
															// attributes

		Map<String, ArrayList<String>> claimMap = new HashMap<String, ArrayList<String>>();
		// Accessing the the nodes having tagname
		NodeList PagesList = doc.getElementsByTagName(tagName);// tags are upto
																// refined
																// address
																// only.not
																// taking child
																// nodes like
																// address1
		// System.out.println("PagesList"+ PagesList);
		// Looping through the nodeslist
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);
			// checking for the attributes in node
			if (node.hasAttributes()) {
				NamedNodeMap attributesList = node.getAttributes();// getting
																	// all the
																	// attributes
																	// in the
																	// node
				// looping through the attributes list
				for (int attribute_Number = 0; attribute_Number < attributesList
						.getLength(); attribute_Number++) {
					// getting Attributes in the attributes list
					Attr attr = (Attr) attributesList.item(attribute_Number);
					String attributeName = attr.getNodeName();
					String attributeValue = attr.getNodeValue();
					// System.out.println("The attribute values are !!!!"+attributeValue);

					if (attributeName.equalsIgnoreCase(attributename)
							&& (attributeValue.matches("^[0-9]*$"))) {

						idList.add(attributeValue);

					}
				}
			}
		}

		return idList;// retuning the attributes list

	}

	public static Map<String, String> extractClaimId(String tagName,
			String clamTagName, String uId) {
		
			ArrayList<String> claimList = new ArrayList<String>();
			NodeList PagesList = doc.getElementsByTagName(tagName);
			// System.out.println("size:"+PagesList.getLength());

			softAssertion = softAssert;// soft assertion for validation
			uniqueId = uId;// subscriber id value
			// System.out.println("index:"+getIndexOfTag(tagName,uniqueId));
			Node node = (Node) PagesList.item(getIndexOfTag(tagName, uniqueId));

			claimIdIndex = 1;
			// Node node1 =
			// (Node)PagesList.item(getIndexOfTag("refined_address",uniqueId));
			// System.out.println("list of node"+node);
			if (hasChildElements((Element) node)) {

				claimListMap = getClaimValues((Element) node);

			}
			return claimListMap;

		} 
		

	// Method to extract s and attributes and its values
	public static void nodeExtraction(String tagName, String uId,
			String mappingSheetName, Map<String, String> claimIdMap,
			List<Map<String, String>> DBValueList, SoftAssert softAssert)
			throws Exception {
		try {
			// Accessing the the nodes having tagname
			// System.out.println("tagNmae:"+tagName);
			NodeList PagesList = doc.getElementsByTagName(tagName);
			// System.out.println("size:"+PagesList.getLength());

			softAssertion = softAssert;// soft assertion for validation
			uniqueId = uId;// subscriber id value

			messageTextIndex = 1;

			dbValueList = DBValueList;
			hcpcsIndex = 1;

			line_item_charge_amtIndex = 1;
			original_units_of_service_countIndex = 1;
			service_start_dateIndex = 1;
			contractual_obligationIndex = 1;
			serviceallowed_amtIndex = 1;
			servicedeductible_amtIndex = 1;
			claimallowed_amtIndex = 1;
			claimdeductible_amtIndex = 1;

			copay_amtIndex = 1;
			line_item_provider_pmt_amt_printIndex = 1;

			keyIndex = 1;

			claimTagIndex = 1;
			claimidMap = claimIdMap;

			claimId = claimidMap.get(uniqueId + "_" + keyIndex);
			System.out.println("The claim id for "+uniqueId+" is "+claimId);

			// System.out.println("index:"+getIndexOfTag(tagName,uniqueId));
			Node node = (Node) PagesList.item(getIndexOfTag(tagName, uniqueId));

			// Node node1 =
			// (Node)PagesList.item(getIndexOfTag("refined_address",uniqueId));
			// System.out.println("list of node"+node);
			if (hasChildElements((Element) node)) {// checking for node has
													// child
													// elements or not
				getElementAtttributes((Element) node, mappingSheetName,
						claimId, messageTextIndex);// attributes
				// elements
				// of
				// given
				// node
				getChildElements((Element) node, mappingSheetName, claimId,
						tagName);// child
									// elements
									// of
									// given
									// node
			}
		} catch (Exception E) {
			E.printStackTrace();
		}

	}

	// Method to retrieve all the attributes of elements
	private static void getElementAtttributes(Element node, String sheetName,
			String Id, int index) throws Exception {

		try {

			if (node.hasAttributes()) {// checking for attributes in node
				NamedNodeMap attributesList = node.getAttributes();// all
																	// attributes
																	// in node
				for (int attribute_Number = 0; attribute_Number < attributesList
						.getLength(); attribute_Number++) {
					// Looping through the nodeslist and getting individual
					// elements
					Attr attr = (Attr) attributesList.item(attribute_Number);
					String attributeName = attr.getNodeName();// Attribute name
					String attributeValue = attr.getNodeValue();// attribute
																// value
					// System.out.println("attributeName: "+attributeName);
					// System.out.println("attributeValue: "+attributeValue);
					// System.out.println("Excel Sheet Value: "+Id);

					String xpath = getXPath(node);
					/*
					 * System.out.println("The xpath is " + xpath +
					 * " attribute Name is " + attributeName +
					 * "The expected Id is " + claimId + " The actual value is "
					 * + attributeValue);
					 */
					if (attributeName
							.equalsIgnoreCase("payer_claim_control_num")) {

						claimId = claimidMap.get(uniqueId + "_" + keyIndex);

						String dbValue = getDbValue(uniqueId, attributeName,
								claimId, String.valueOf(index));

						// getting the query for the given element name
						/*
						 * String dbValue = getElementValueFromDB(xpath.trim(),
						 * Id, sheetName, node, hcpcsIndex, messageTextIndex);
						 */
						String ScrubbedDBVAlue = getscrubDBdata(node
								.getNodeName().trim().toString(), dbValue);
						// System.out.println("I am inside If and getting DB value");
						// System.out.println("db value"+dbValue);
						if (dbValue != null) {

							// call validate method for validation of xml value
							// and
							// db value
							validataXmlAndDbValues(attributeName.trim()
									.toString(), attributeValue,
									ScrubbedDBVAlue, dbValue, xpath.trim(),
									String.valueOf(hcpcsIndex), uniqueId,
									claimId);
						}

						keyIndex++;
					} else if (attributeName.contains("provider_num")) {

						String tagName = HomeUI.excelUtils
								.getTagNameFromMappingSheet(xpath, sheetName);
						String dbValue = getDbValue(uniqueId, tagName, claimId,
								String.valueOf(index));
						String ScrubbedDBVAlue = getscrubDBdata(node
								.getNodeName().trim().toString(), dbValue);

						if (dbValue != null) {

							// call validate method for validation of xml value
							// and
							// db value
							validataXmlAndDbValues(attributeName.trim()
									.toString(), attributeValue,
									ScrubbedDBVAlue, dbValue, xpath.trim(),
									String.valueOf(hcpcsIndex), uniqueId,
									claimId);
						}
					}

					else if (attributeName.contains("subscriber_num")) {

						String tagName = HomeUI.excelUtils
								.getTagNameFromMappingSheet(xpath, sheetName);
						String dbValue = getDbValue(uniqueId, tagName, claimId,
								String.valueOf(index));
						String ScrubbedDBVAlue = getscrubDBdata(node
								.getNodeName().trim().toString(), dbValue);

						if (dbValue != null) {

							// call validate method for validation of xml value
							// and
							// db value
							validataXmlAndDbValues(attributeName.trim()
									.toString(), attributeValue,
									ScrubbedDBVAlue, dbValue, xpath.trim(),
									String.valueOf(hcpcsIndex), uniqueId,
									claimId);
						}
					}

					// }
				}
			}
		} catch (Exception E) {
			E.printStackTrace();
		}
	}

	private static void getValuesOfElement(Element node, String sheetName,
			String Id, int hcpcsIndex, int messageTextIndex, int index)
			throws Exception {
		try {
			// getting the query for the given element name
			String scrubbedValue = null;
			String xpath = getXPath(node);
			String dbValue = null;

			String tagName = HomeUI.excelUtils.getTagNameFromMappingSheet(
					xpath, sheetName);
			/*
			 * if (tagName != null) {
			 * System.out.println("The tag name from excel datasheet is " +
			 * tagName); }
			 */

			// System.out.println("The node name outside if is "+node.getNodeName());
			if (node.getNodeName().equalsIgnoreCase("hcpcs_code")) {

				// System.out.println("The node name inside if is "+node.getNodeName());
				dbValue = getDbValue(uniqueId, node.getNodeName(), claimId,
						String.valueOf(hcpcsIndex));

				scrubbedValue = getscrubDBdata(xpath, dbValue);
			} else if (node.getNodeName().equalsIgnoreCase("message_text")) {
				// System.out.println("The node name inside if is "+node.getNodeName());
				dbValue = getDbValue(uniqueId, node.getNodeName(), claimId,
						String.valueOf(messageTextIndex));

				scrubbedValue = getscrubDBdata(xpath, dbValue);

			} else if (node.getNodeName().equalsIgnoreCase(
					"line_item_charge_amt")
					|| node.getNodeName().equalsIgnoreCase(
							"original_units_of_service_count")
					|| node.getNodeName()
							.equalsIgnoreCase("service_start_date")
					|| node.getNodeName().equalsIgnoreCase(
							"contractual_obligation")
					|| xpath.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/allowed_amt")
					|| xpath.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/deductible_amt")
					|| xpath.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/claim_supplemental_amt/allowed_amt")
					|| xpath.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/claim_supplemental_amt/deductible_amt")
					|| node.getNodeName().equalsIgnoreCase("copay_amt")
					|| xpath.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_provider_pmt_amt_print")) {
				// System.out.println("The node name inside if is "+node.getNodeName());

				if (tagName != null && !tagName.equals("")) {

					// System.out.println("The tag name in condition is " +
					// tagName);

					dbValue = getDbValue(uniqueId, tagName, claimId,
							String.valueOf(index));
					scrubbedValue = getscrubDBdata(xpath, dbValue);

				} else {

					// System.out.println("The xpath in if is " + xpath);
					dbValue = getDbValue(uniqueId, node.getNodeName(), claimId,
							String.valueOf(index));
					scrubbedValue = getscrubDBdata(xpath, dbValue);
				}

				// System.out.println("The scrubbed value is " + scrubbedValue);

			} else {

				// System.out.println("The node name inside else is "+node.getNodeName());
				if (tagName != null && !tagName.equals("")) {
					dbValue = getDbValue(uniqueId, tagName, claimId,
							String.valueOf(index));

					scrubbedValue = getscrubDBdata(xpath, dbValue);

					/*
					 * if (xpath .equalsIgnoreCase(
					 * "/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/patient_info/name"
					 * )) {
					 * 
					 * System.out.println("The db value for element name " +
					 * tagName + " is " + scrubbedValue); }
					 */

				} else {
					dbValue = getDbValue(uniqueId, node.getNodeName(), claimId,
							String.valueOf(index));

					scrubbedValue = getscrubDBdata(xpath, dbValue);
				}
			}
			/*
			 * String dbValue = getElementValueFromDB(xpath, claimId, sheetName,
			 * node, hcpcsIndex, messageTextIndex);
			 */
			// String ScrubbedDBVAlue = getscrubDBdata(xpath, dbValue);
			// System.out.println("Node Value = "+node.getNodeName().trim().toString());
			// String xPath = getXPath(node);
			String strValue = null;
			if (dbValue != null) {
				/*
				 * if (node.getNodeName().trim().toString()
				 * .equalsIgnoreCase("address_1")) { strValue =
				 * node.getTextContent().toUpperCase().replace(".", "");
				 * validataXmlAndDbValues(node.getNodeName().trim().toString(),
				 * scrubbedValue, dbValue, dbValue, xpath.trim(),
				 * String.valueOf(hcpcsIndex));
				 * 
				 * } else if (node.getNodeName().trim().toString()
				 * .equalsIgnoreCase("postal_code")) { strValue =
				 * node.getTextContent().toUpperCase().substring(0, 5);
				 * validataXmlAndDbValues(node.getNodeName().trim().toString(),
				 * scrubbedValue, dbValue, dbValue, xpath.trim(),
				 * String.valueOf(hcpcsIndex)); //
				 * System.out.println("The postal code is "+strValue); }
				 */

				// else {

				// call validate method for validation of xml value and db value
				// System.out.println("The hcpcsIndex is " + hcpcsIndex);
				validataXmlAndDbValues(node.getNodeName().trim().toString(),
						node.getTextContent().trim().toUpperCase(),
						scrubbedValue, dbValue, xpath.trim(),
						String.valueOf(hcpcsIndex), uniqueId, claimId);
				// }
			}
		} catch (Exception E) {

			E.printStackTrace();

		}
	}

	public static String getDbValue(String Tcn, String columnName,
			String claimId, String index) {

		String dbValue = null;

		for (int dbvaluemapIndex = 0; dbvaluemapIndex < dbValueList.size(); dbvaluemapIndex++) {

			Map<String, String> dbValueMap = new HashMap<String, String>();

			dbValueMap = dbValueList.get(dbvaluemapIndex);

			for (Map.Entry<String, String> entry : dbValueMap.entrySet()) {

				if (entry.getKey().equalsIgnoreCase(
						Tcn + "_" + claimId + "_" + columnName + "_" + index)) {

					dbValue = entry.getValue();

					/*
					 * System.out.println("The dbvalue for " + columnName +
					 * "is " + dbValue);
					 */
				}
			}

		}
		return dbValue;

	}

	private static String getElementValueFromDB(String elemetName, String Id,
			String sheetName, Element node, int hcpcsIndex, int messageTextIndex)
			throws SQLException {
		// retrieve query for the given element name
		// System.out.println("elemetName Name:"+elemetName.trim().toString()+"|SheetName:"+sheetName);
		// SelectValidation selectValidation = new SelectValidation();
		ExcelUtils excelUtils = new ExcelUtils(
				HomeUI.excelFile.getAbsolutePath(), sheetName);

		String query = excelUtils.getQueryFromMappingSheet(elemetName,
				sheetName);
		String dbValue = null;
		// String xPath = getXPath(node);
		if (elemetName.equalsIgnoreCase("statement_mode")) {
			query = dbValue;
		} else if (elemetName.equalsIgnoreCase("correspondence")) {
			query = dbValue;
		}

		if (elemetName
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/original_composite_procedure/hcpcs_code")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_charge_amt")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/original_units_of_service_count")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_start_date")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/adjustment/contractual_obligation")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/allowed_amt")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/deductible_amt")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/copay_amt")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_provider_pmt_amt_print")) {

			if (query != null) {// check for the null values of query
				// String SQLQuery=query.replace(
				// "VAR_SBSB_ID_VALUE",subscriberId);//replacing subscriber id

				String SQLQuery = query.replace("UniqueId", claimId);// replacing
				// subscriber id

				if (SQLQuery.contains("RowNo")) {
					SQLQuery = SQLQuery.replace("RowNo",
							String.valueOf(hcpcsIndex));

					System.out.println("Query after row no is replaced "
							+ SQLQuery);

				}
				// String SQLQuery=query.replace(
				// "{$PARAM1}",subscriberId);//replacing subscriber id
				// running the query and getting the database value
				dbValue = DBConnection.dbUtils.getDatabaseValue(SQLQuery);

				System.out.println("Db value after query replaced is "
						+ dbValue);

			}

		} else {

			if (query != null) {// check for the null values of query
				// String SQLQuery=query.replace(
				// "VAR_SBSB_ID_VALUE",subscriberId);//replacing subscriber id

				String SQLQuery = query.replace("UniqueId", claimId);// replacing
				// subscriber id

				// String SQLQuery=query.replace(
				// "{$PARAM1}",subscriberId);//replacing subscriber id
				// running the query and getting the database value
				dbValue = DBConnection.dbUtils.getDatabaseValue(SQLQuery);

			}
		}
		return dbValue;
	}

	// This method is to retrieve child nodes of node
	private static void getChildElements(Element nNode, String sheetName,
			String Id, String tagName) throws Exception {

		try {
			if (nNode.getNodeName().equalsIgnoreCase("claim")) {

				claimTagIndex++;

			}

			NamedNodeMap attributesList = nNode.getAttributes();// all
																// attributes in

			Node parent = nNode.getParentNode();
			// System.out.println("parentnode is " + nNode.getNodeName());

			NodeList children = nNode.getChildNodes();// get child nodes of
														// node//child node is

			// System.out.println("children: "+children);
			String xpath = getXPath(nNode);

			for (int i = 0; i < children.getLength(); i++) { // loop through
																// child nodes
				Node node = (Node) children.item(i);
				// System.out.println("node children:"+node);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					if (hasChildElements((Element) node)) {// checking for child

						/*
						 * System.out.println("Verify The parent node name is "
						 * + node.getParentNode().getNodeName());
						 */
						if (claimTagIndex > 1
								&& node.getParentNode().getNodeName()
										.equalsIgnoreCase("claim")
								&& node.getNodeName().equalsIgnoreCase(
										"claim_summary")) {

							hcpcsIndex = 1;

							messageTextIndex = 1;

							line_item_charge_amtIndex = 1;

							original_units_of_service_countIndex = 1;

							service_start_dateIndex = 1;

							contractual_obligationIndex = 1;

							serviceallowed_amtIndex = 1;
							servicedeductible_amtIndex = 1;
							claimallowed_amtIndex = 1;
							claimdeductible_amtIndex = 1;

							copay_amtIndex = 1;

							line_item_provider_pmt_amt_printIndex = 1;

						}

						getElementAtttributes((Element) node, sheetName, Id,
								messageTextIndex);// getting
						// attributes
						// of
						// elements
						// System.out.println("Tag name : " + tagName);
						getChildElements((Element) node, sheetName, Id, tagName);// getting
																					// child

						// System.out.println("(Element)node"+(Element)node);

					}
					/*
					 * else if((node.toString().contains("allowed_amt"))&&
					 * (attributeValue.contains("270.00"))) { return; }
					 */
					else {
						if (node.getNodeName().equalsIgnoreCase("message_text")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									line_item_charge_amtIndex);
							messageTextIndex++;
						}

						else if (node.getNodeName().equalsIgnoreCase(
								"line_item_charge_amt")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									line_item_charge_amtIndex);
							line_item_charge_amtIndex++;
						}

						else if (node.getNodeName().equalsIgnoreCase(
								"original_units_of_service_count")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									original_units_of_service_countIndex);
							original_units_of_service_countIndex++;
						}

						else if (node.getNodeName().equalsIgnoreCase(
								"service_start_date")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									service_start_dateIndex);
							service_start_dateIndex++;
						}

						else if (node.getNodeName().equalsIgnoreCase(
								"contractual_obligation")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									contractual_obligationIndex);
							contractual_obligationIndex++;
						}

						else if (xpath
								.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/allowed_amt")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									serviceallowed_amtIndex);
							serviceallowed_amtIndex++;
						}

						else if (xpath
								.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/claim_supplemental_amt/allowed_amt")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									claimallowed_amtIndex);
							claimallowed_amtIndex++;
						}

						else if (xpath
								.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/deductible_amt")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									servicedeductible_amtIndex);
							servicedeductible_amtIndex++;
						}

						else if (xpath
								.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/claim_supplemental_amt/deductible_amt")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									claimdeductible_amtIndex);
							claimdeductible_amtIndex++;
						}

						else if (node.getNodeName().equalsIgnoreCase(
								"copay_amt")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									copay_amtIndex);
							copay_amtIndex++;
						}

						else if (node.getNodeName().equalsIgnoreCase(
								"line_item_provider_pmt_amt_print")) {

							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									line_item_provider_pmt_amt_printIndex);
							line_item_provider_pmt_amt_printIndex++;
						}

						else if (node.getNodeName().equalsIgnoreCase(
								"hcpcs_code")) {
							// System.out.println("The hcpcsindex is " +
							// hcpcsIndex);
							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									line_item_charge_amtIndex);

							hcpcsIndex++;
						} else {
							// System.out.println("I am in else printing DB");
							getValuesOfElement((Element) node, sheetName, Id,
									hcpcsIndex, messageTextIndex,
									line_item_charge_amtIndex);// getting
							// values of
							// elements
						}
					}
				}

			}
		} catch (Exception E) {
			E.printStackTrace();
		}

	}

	private static boolean hasChildElements(Element el) {
		// get child nodes for the given node
		NodeList children = el.getChildNodes();

		for (int i = 0; i < children.getLength(); i++) {
			// looping through the nodes and checking for element node
			if (children.item(i).getNodeType() == Node.ELEMENT_NODE)// chck for
																	// element
																	// node

				return true;
		}
		return false;
	}

	public static int getIndexOfTag(String tagName, String uniqueId) {

		int tagIndex = 0;
		boolean flag = false;
		NodeList PagesList = doc.getElementsByTagName("*");
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {

			Node node = (Node) PagesList.item(nodeNo);
			Element element = (Element) node;
			// System.out.println("element"+element);
			if (element.getTagName().toString().trim()
					.equalsIgnoreCase(tagName)) {
				tagIndex++;
			}
			/*
			 * else if(element.getTagName().toString().trim().equalsIgnoreCase(
			 * "refined_address")) { element.getFirstChild();
			 * 
			 * }
			 */

			if (node.hasAttributes()) {// check for node has attributes or not
				NamedNodeMap attributesList = node.getAttributes();// getting
																	// all
																	// attributes
																	// of node
				// looping through attributes list of element
				for (int attribute_Number = 0; attribute_Number < attributesList
						.getLength(); attribute_Number++) {
					Attr attr = (Attr) attributesList.item(attribute_Number);
					// String attributeName=attr.getNodeName();
					String attributeValue = attr.getNodeValue();// attribute
																// value
					// System.out.println("AttrValu:"+attributeValue+"|input:"+subscriberId+"|"+attributeValue.equals(subscriberId));
					if (attributeValue.toString().trim()
							.equalsIgnoreCase(uniqueId)) {// checking for the
															// attribute value
						flag = true;
						break;
					}
				}
				if (flag) {
					break;
				}
			}
		}
		return tagIndex;

	}

	public static String getscrubDBdata(String element, String value)
			throws ParseException {

		// System.out.println("The xpath in getscrubdata is " + element);
		if (value == null) {
			return null;
		} else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/bsc_line_of_business")) {
			value = value.replace("CARE1", "C1");
		}
		/*
		 * else if(element.contains("print_amt")) { value =
		 * value.replace("********270*DOLLARS*00*CTS*","270"); }
		 */
		else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/payer_address/correspondence/refined_address/city")) {
			value = value.toUpperCase() + ",";
		} else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/provider/address/generic_address/address_1")) {
			value = value.replace(".", "");
			// System.out.println(": " + value);

		} else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/pmt/pmt_amt")) {

			value = "$" + value;

		}

		else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/pmt/pmt_date")) {

			value = value.substring(0, 10);

			// System.out.println("The db date is "+value);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat format2 = new SimpleDateFormat("MM dd yy");
			Date date = format1.parse(value);

			value = format2.format(date);
			// System.out.println(value);

		} else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/payer_address/correspondence/refined_address/address_1")) {

			value = value + ",";

		} else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/payer_address/correspondence/refined_address/city")) {

			value = value.toUpperCase() + ",";

		}

		else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/payer_address/return/refined_address/city")) {

			value = value.toUpperCase() + ",";

		} /*
		 * else if (element .equalsIgnoreCase(
		 * "/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/claim_received_date"
		 * )) { // value = value.substring(0,10);
		 * 
		 * // System.out.println("The db date is "+value);
		 * 
		 * if (value.contains("/") == false) { SimpleDateFormat format1 = new
		 * SimpleDateFormat("MM dd yy"); SimpleDateFormat format2 = new
		 * SimpleDateFormat("MM/dd/yy"); Date date = format1.parse(value);
		 * 
		 * value = format2.format(date); // System.out.println(value); } }
		 */

		else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_start_date")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_end_date")) {

			// value = value.substring(0, 10);

			// System.out.println("The db date is "+value);
			SimpleDateFormat format1 = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat format2 = new SimpleDateFormat("MM/dd/yy");
			Date date = format1.parse(value);

			value = format2.format(date);
			// System.out.println("The coverted start date is " + value);

		}

		else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/stmt_control_info/statement_date")) {

			// value = value.substring(0, 10);

			// System.out.println("The db date is "+value);

			try {
				SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
				SimpleDateFormat format2 = new SimpleDateFormat("MM/dd/yy");
				Date date = format1.parse(value);

				value = format2.format(date);
				System.out.println("The coverted start date     is " + value);

			} catch (Exception E) {

			}

		}

		else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/claim_received_date")) {

			try {
				SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
				SimpleDateFormat format2 = new SimpleDateFormat("MM/dd/yy");
				Date date = format1.parse(value);

				value = format2.format(date);
				System.out
						.println("The coverted  converted claim received date   is "
								+ value);
			} catch (Exception E) {

				SimpleDateFormat format1 = new SimpleDateFormat("MM dd yy");
				SimpleDateFormat format2 = new SimpleDateFormat("MM/dd/yy");
				Date date = format1.parse(value);

				value = format2.format(date);

			}

		}

		else if (element
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/batch_control_info/claim_charge_amt")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/batch_control_info/provider_pmt_amt_print")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/total_claim_charge_amt")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/patient_responsibility")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/previous_pmt")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/claim_pmt_amt_print")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_charge_amt")

				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/copay_amt")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/batch_supplemental_control_info/copay_amt")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_provider_pmt_amt_print")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/additional_subscriber_claim_info/noncovered_chrgs")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/additional_subscriber_service_info/noncovered_chrgs")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/additional_subscriber_claim_info/patient_liability_amt")
				|| element
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/additional_subscriber_claim_info/network_sav_amt")) {

			DecimalFormat twoDForm = new DecimalFormat("0.00");

			Float convertedValue = Float.valueOf(value);

			value = twoDForm.format(convertedValue);

			// value = String.valueOf(convertedValue);

			// System.out.println("The converted dbValue is " + value);
		}
		return value;

	}

	private static String getXPath(Node node) {
		Node parent = node.getParentNode();
		if (parent == null) {
			return "";
		}
		return getXPath(parent) + "/" + node.getNodeName();

	}

	public static Map<String, String> getClaimValues(Element nNode) {
		try {
			NodeList children = nNode.getChildNodes();// get child nodes of

			for (int i = 0; i < children.getLength(); i++) { // loop through
				// child nodes
				Node node = (Node) children.item(i);
				// System.out.println("node children:"+node);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					if (hasChildElements((Element) node)) {// checking for child
						/*
						 * System.out.println("The childnodename is " +
						 * node.getNodeName());
						 */
						if (node.getNodeName().trim().equalsIgnoreCase("claim")) {

							if (node.hasAttributes()) {

								NamedNodeMap attributeList = node
										.getAttributes();

								for (int attributeIndex = 0; attributeIndex < attributeList
										.getLength(); attributeIndex++) {

									Attr attribute = (Attr) attributeList
											.item(attributeIndex);

									/*
									 * System.out.println("The attribute name is "
									 * + attribute.getName());
									 */
									if (attribute.getName().equalsIgnoreCase(
											"payer_claim_control_num")) {
										
										

										claimMap.put(
												uniqueId
														+ "_"
														+ String.valueOf(claimIdIndex),
												attribute.getValue());
										claimMap.put("Index",
												String.valueOf(claimIdIndex));
										claimIdIndex++;

									}

								}
							}
						}

						else {

							getClaimValues((Element) node);
						}

					}

				}

			}
		} catch (Exception E) {
			E.printStackTrace();
		}
		return claimMap;

	}

	public static void updateDatasheet(String executionNo, String comments,
			String element, String expectedXmlValue, String dataSheetName,
			String actualValue, String result) throws Exception {

		// SelectValidation selectValidation = new SelectValidation();

		// excelUtils = new ExcelUtils(HomeUI.excelFile.getAbsolutePath(),
		// dataSheetName);

		if ((!element.equalsIgnoreCase("insert_string"))
				&& (!element.equalsIgnoreCase("special_handling_code"))) {

			collNumCellValueMap.put(execNo_CollNum_Datasheet, executionNo);// execution
																			// No
																			// Map

			collNumCellValueMap.put(comments_Datasheet, comments);// Eob Map

			collNumCellValueMap.put(elementName_CollNum_Datasheet, element);// Element
																			// Map

			collNumCellValueMap.put(expectedValue_CollNum_Datasheet,
					expectedXmlValue);

			collNumCellValueMap.put(actualValueCollNum, actualValue);

			collNumCellValueMap.put(resultCollNum, result);

			// System.out.println("The datasheet name and row num is "+dataSheetName
			// + rowNum_Datasheet );

			HomeUI.excelUtils.CreateRowAndCell(dataSheetName, rowNum_Datasheet,
					collNumCellValueMap);

			// ExcelUtils.writeToWorkBook(HomeUI.excelFile.getAbsolutePath());

			rowNum_Datasheet++;

		}

		// expected Value Map

		// Below one is to create row and columns in datasheet

	}

	public static void validataXmlAndDbValues(String elementName,
			String xmlValue, String dbValue, String originalDbValue,
			String xpath, String index, String Tcn, String claim)
			throws Exception {
		// validation of the xml and db values
		softAssertion.assertEquals(xmlValue.replaceAll("\\s+", ""),
				dbValue.replaceAll("\\s+", ""),
				"xmlValue:" + xmlValue.replaceAll("\\s+", "") + "| dbValue:"
						+ dbValue.replaceAll("\\s+", ""));
		String status = "Fail";

		String comments = "";

		/*
		 * if (xpath .equalsIgnoreCase(
		 * "/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/patient_info/name"
		 * )) {
		 * 
		 * System.out.println("The db value for patient name is " + dbValue); }
		 * else if (xpath .equalsIgnoreCase(
		 * "/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_charge_amt"
		 * )) {
		 * 
		 * System.out.println("The db value for line item charge amount is " +
		 * dbValue); } else if (xpath .equalsIgnoreCase(
		 * "/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/claim_received_date"
		 * )) {
		 * 
		 * System.out.println("The db value for claim received date is " +
		 * dbValue); }
		 */

		if (xmlValue.contains("$") || xmlValue.contains(",")) {

			xmlValue = xmlValue.replaceAll("\\,", "");

			if (dbValue.contains(",")) {

				dbValue = dbValue.replaceAll("\\,", "");

			}

			if (dbValue.matches("\\d*$") || dbValue.contains(".")
					&& !dbValue.contains("$") && xmlValue.contains("$")) {

				dbValue = "$" + dbValue;

				/*
				 * System.out.println("The dbValue after adding $ is " +
				 * dbValue);
				 */

			}

			/*
			 * System.out.println("Xml value after removing comma is " +
			 * xmlValue + "and Db Value is " + dbValue);
			 */
		}

		if (xmlValue.replaceAll("\\s+", "").equalsIgnoreCase(
				dbValue.replaceAll("\\s+", ""))) {
			status = "Pass";
			logger.log(LogStatus.PASS, "Statement No :" + Tcn
					+ "<br /> Element Name: " + elementName
					+ "<br /> xmlValue: " + xmlValue + "<br />dbValue: "
					+ dbValue + "<br /> Status:" + status);

			updateDatasheet(Tcn, comments, elementName, xmlValue, "Result",
					dbValue, status);
		}

		else {
			if (xpath
					.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/additional_subscriber_claim_info/plan_name")
					|| xpath.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/claim_summary/additional_claim_identification/group_num")) {

				if (xmlValue.replaceAll("\\s+", "").contains(
						dbValue.replaceAll("\\s+", ""))) {

					comments = "Comparison is failed due to Format issue.";
				}
			}

			logger.log(LogStatus.FAIL, "Statement No :" + Tcn
					+ "<br /> Element Name: " + elementName
					+ "<br /> xmlValue: " + xmlValue + "<br /> dbValue: "
					+ dbValue + "<br /> Status:" + status + "<br /> Comments: "
					+ comments);

			updateDatasheet(Tcn, comments, elementName, xmlValue, "Result",
					dbValue, status);

		}
	}

}
