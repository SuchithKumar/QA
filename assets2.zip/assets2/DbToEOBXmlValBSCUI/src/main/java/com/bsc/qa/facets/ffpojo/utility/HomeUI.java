package com.bsc.qa.facets.ffpojo.utility;

import java.awt.Desktop;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;








import javax.swing.JLabel;
import javax.swing.ImageIcon;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTextField;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.border.TitledBorder;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.UIManager;

import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;

import javax.swing.JProgressBar;
import javax.swing.JButton;

@SuppressWarnings("serial")
public class HomeUI extends JFrame {

	public JPanel contentPane;
	public static File excelFile;
	public static File xmlFile;
	public static DBUtils dbUtils;
	public DatabaseEnvironment environment;
	private static ArrayList<String> transactionIdList = new ArrayList<String>();
	private static ArrayList<String> idList;
	public int query1ColumnNo = 0;
	public int query2ColumnNo = 1;
	public int query3ColumnNo = 2;
	public int query4ColumnNo = 3;
	public int query5ColumnNo = 4;
	public int query6ColumnNo = 5;
	public int query7ColumnNo = 6;
	public static ExcelUtils excelUtils;
	
	public static JTextField textField_xml;
	public static JTextField textField_testData;
	public int xx, xy;
	public static JTextField textField_DBUsername;
	public static JPasswordField passwordField_DBPassword;
	//public static String pathForXML;
	//public static String pathForTestDataSheet;
	public static String environmentValue;
	//public static String rdbValue = "DbToXml";
	public static String dbUsername, dbPassword;
	public static String pathForResults;
	public static String pathR;
	public static String resultPath;
	private JTextField textField_ResultsPath;

	/**
	 * Launch the application.
	 */

	static SoftAssert softAssertion = new SoftAssert();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomeUI frame = new HomeUI();
					frame.setUndecorated(true);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HomeUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 726, 639);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, 0, 229, 646);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {

				xx = e.getX();
				xy = e.getY();
			}
		});
		lblNewLabel_1.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x = e.getXOnScreen();
				int y = e.getYOnScreen();

				HomeUI.this.setLocation(x - xx, y - xy);

			}

		});
		lblNewLabel_1
				.setIcon(new ImageIcon(
						"\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\EOB Automation\\DbToProvXmlValBsc\\src\\test\\resources\\images\\logo.png"));
		lblNewLabel_1.setBounds(0, -15, 253, 238);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("XML VALIDATOR");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(10, 238, 200, 50);
		panel.add(lblNewLabel_2);

		JLabel lblinstructionsuploadTheEob = new JLabel(
				"<html><body width='%1s'><h3>Steps to start validation:</h3><br>1. Browse EOB Xml file</br> <br>2. Browse Mapping Sheet</br><br>3. Select Environment</br> <br>4. Enter your Username & Password for selected Environment</br><br>5. Click START to initiate validation</br></html>");
		lblinstructionsuploadTheEob.setForeground(Color.WHITE);
		lblinstructionsuploadTheEob.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblinstructionsuploadTheEob.setBackground(Color.WHITE);
		lblinstructionsuploadTheEob.setBounds(10, 299, 200, 172);
		panel.add(lblinstructionsuploadTheEob);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel
				.setIcon(new ImageIcon(
						"\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\EOB Automation\\DbToProvXmlValBsc\\src\\test\\resources\\images\\xmlIcon2.jpg"));
		lblNewLabel.setBounds(291, 63, 69, 63);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_3 = new JLabel("X");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setBounds(670, 11, 23, 39);
		contentPane.add(lblNewLabel_3);

		textField_xml = new JTextField();
		textField_xml.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textField_xml.setText(xmlFile.getAbsolutePath());
			
			}
		});
		textField_xml.setBounds(370, 76, 206, 38);
		contentPane.add(textField_xml);
		textField_xml.setColumns(10);

		textField_testData = new JTextField();
		textField_testData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_testData.setText(xmlFile.getAbsolutePath());
			}
		});
		textField_testData.setBounds(370, 154, 206, 38);
		contentPane.add(textField_testData);
		textField_testData.setColumns(10);

		Button button_Launch = new Button("START");
		button_Launch.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				
				
				String mappingSheetName="Mappingsheet";
				
				String querysheetName = "Queries";
				
				resultPath = textField_ResultsPath.getText();
				
				System.out.println("the result path is "+resultPath);
				
				BaseTest bt=new BaseTest();

				System.out.println("XML path: " + xmlFile);
				System.out.println("Test Data Sheet path: " + excelFile);
				
				
				try {

					
					
					 Map<String,String> querydataMap1 = new HashMap<String,String>();
					 Map<String,String> querydataMap2 = new HashMap<String,String>();
					Map<String,String> querydataMap3 = new HashMap<String,String>();
					 Map<String,String> querydataMap4 = new HashMap<String,String>();
					 Map<String,String> querydataMap5 = new HashMap<String,String>();
					 Map<String,String> querydataMap6 = new HashMap<String,String>();
					 Map<String,String> querydataMap7 = new HashMap<String,String>();
					 List< Map<String,String>> dBValuesList = new ArrayList< Map<String,String>>();
					 
					 String testCaseName= "XML: "+xmlFile.getName();
					 
					 BaseTest baseTest = new BaseTest();
					//Retrieving data from test data sheet and storing data in variables
					 baseTest.reportInit("DbToXmlValidation",testCaseName);
						
						//XMLParse.xmlSetup(selectValidation.xmlFile.getAbsolutePath());
					
					XMLParse.xmlSetup(xmlFile.getAbsolutePath());
					
					
					
					
				//	String mappingSheetPath="/DbToSubscriberXmlVal/src/test/resources/TestData.xlsx";
					transactionIdList = XMLParse.attributeValue("stmt","stmt_num");
					
					//idList = XMLParse.attributeValue("claim", "payer_claim_control_num");
					
					 excelUtils = new ExcelUtils(excelFile.getAbsolutePath(),querysheetName);
					
					String query1 = excelUtils.getCellData(1, query1ColumnNo);
					String query2 = excelUtils.getCellData(1, query2ColumnNo);
					String query3 = excelUtils.getCellData(1, query3ColumnNo);
					String query4 = excelUtils.getCellData(1, query4ColumnNo);
					String query5 = excelUtils.getCellData(1, query5ColumnNo);
					String query6 = excelUtils.getCellData(1, query6ColumnNo);
					String query7 = excelUtils.getCellData(1, query7ColumnNo);
						
					
					
					for(int i=0;i<transactionIdList.size();i++){
						 Map<String,String> claimIdMap = new HashMap<String,String>();
						 
						claimIdMap = XMLParse.extractClaimId("stmt", "claim", transactionIdList.get(i));
						
						System.out.println("The transaction id list and size are "+transactionIdList.get(i)+" "+transactionIdList.size());
						System.out.println("The claimIdMap is "+claimIdMap);
						String tcnId = transactionIdList.get(i).substring(0,16);
						
						String seqId = transactionIdList.get(i).substring(16,16+transactionIdList.get(i).length()-16);
						
						
					/*	System.out.println("The tcn id is "+tcnId+" the seq id is "+seqId);
						
						System.out.println("The claim tag index is "+XMLParse.claimIdIndex);*/
						
						System.out.println("The claim id index is "+Integer.valueOf(claimIdMap.get("Index")));
						
						for(int claimIndex = 1;claimIndex<=Integer.valueOf(claimIdMap.get("Index"));claimIndex++){
							
							String replacedquery1;
							String replacedquery2;
							String replacedquery3;
							String replacedquery4;
							String replacedquery5;
							String replacedquery6;
							String replacedquery7;
							
							
							//System.out.println("The query1 is "+ query1);
							
							String claimId = claimIdMap.get(transactionIdList.get(i)+"_"+claimIndex);
							
							System.out.println("The claim id is "+claimId);
							
							replacedquery1 = query1.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
							
							replacedquery2 = query2.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						
							
							replacedquery3 = query3.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
							replacedquery4 = query4.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
							replacedquery5 = query5.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
							replacedquery6 = query6.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
							replacedquery7 = query7.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
							
							
							querydataMap1 =  dbUtils.resultSetToDictionary(replacedquery1,claimId,transactionIdList.get(i));
							
							querydataMap2 = dbUtils.resultSetToDictionary(replacedquery2,claimId,transactionIdList.get(i));
							
							querydataMap3 = dbUtils.resultSetToDictionary(replacedquery3,claimId,transactionIdList.get(i));
							
							querydataMap4 = dbUtils.resultSetToDictionary(replacedquery4,claimId,transactionIdList.get(i));
							
							querydataMap5 = dbUtils.resultSetToDictionary(replacedquery5,claimId,transactionIdList.get(i));
							
							querydataMap6 = dbUtils.resultSetToDictionary(replacedquery6,claimId,transactionIdList.get(i));
							
							querydataMap7 = dbUtils.resultSetToDictionary(replacedquery7,claimId,transactionIdList.get(i));
							
							
							
							/*System.out.println("The query map1 is "+ querydataMap1 );
							System.out.println("The query map2 is "+ querydataMap2);
							System.out.println("The query map3 is "+ querydataMap3 );
							System.out.println("The query map4 is "+ querydataMap4 );
							System.out.println("The query map5 is "+ querydataMap5 );
							System.out.println("The query map6 is "+ querydataMap6 );
							System.out.println("The query map7 is "+ querydataMap7 );*/
							
							dBValuesList.add(querydataMap1);
							
							dBValuesList.add(querydataMap2);
							
							dBValuesList.add(querydataMap3);
							
							dBValuesList.add(querydataMap4);
							
							dBValuesList.add(querydataMap5);
							
							dBValuesList.add(querydataMap6);
							
							dBValuesList.add(querydataMap7);
							
							//query = query.replaceAll(tcnId,"Trans_Id").replaceAll(seqId,"Seq_Id").replaceAll(claimId,"Claim_Id");
						}
						
						//System.out.println("The claim id map is "+claimIdMap.get(transactionIdList.get(2)+"_150"));
						//System.out.println("The transaction id's are "+transactionIdList.get(i));

						XMLParse.nodeExtraction("stmt",transactionIdList.get(i),mappingSheetName,claimIdMap,dBValuesList,softAssertion);
						
						
					}
					
					//ExcelUtils excelutils = new ExcelUtils(excelFile.getAbsolutePath(),"Result");
					System.out.println("The path is "+excelFile.getAbsolutePath());
					excelUtils.writeToWorkBook(excelFile.getAbsolutePath());
					
					ReportFactory.closeReport();
					/*File srcFile = new File(this.getClass()
							.getResource("/Report.html").getFile());*/
					File srcFile = new File(System.getProperty("user.dir")
							+ "/BSC-reports/Report.html");
					System.out.println(srcFile.getAbsolutePath());
					String timestamp = LocalDateTime.now().format(
							DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss"));

					// File destFile = new
					// File("target/BSC-reports/"+timestamp+"/Report.html");

					ReportFactory.closeReport();
					File destFolder = null;
					if(resultPath==null){

					 destFolder = new File(System.getProperty("user.dir")
							+ "/Results/BSC-reports/" + timestamp);
					}else{
					
					 destFolder = new File(resultPath+ timestamp);
					}
					if (destFolder.exists()) {
						destFolder.delete();
					}
					destFolder.mkdirs();

					File destFile = new File(destFolder + "/Report.html");

					System.out.println(destFile.getAbsolutePath());

					java.nio.file.Files.copy(srcFile.toPath(),
							destFile.toPath());
					
					java.nio.file.Files.copy(excelFile
							.toPath(), new File(destFolder + "/Result.xlsx")
							.toPath());
					
					JOptionPane.showMessageDialog(null,
							"Comparison is completed successfully");

					Desktop deskTop = Desktop.getDesktop();

					deskTop.open(destFolder);

					
				} catch (Exception E) {

					JOptionPane.showMessageDialog(null,
							"Comparison is not successfull!!");

					E.printStackTrace();
				}
			}

		});

		button_Launch.setBackground(Color.LIGHT_GRAY);
		button_Launch.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_Launch.setBounds(370, 591, 206, 39);
		contentPane.add(button_Launch);

		Button button_xmlUpload = new Button("Browse");
		button_xmlUpload.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_xmlUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					FileChooser fileChooser = new FileChooser();

					File file = fileChooser.getFile();

					if (file.getName().contains(".xml")) {

						xmlFile = file;

						System.out.println("The xml file name is "
								+ xmlFile.getName());
						
						textField_xml.setText(xmlFile.getAbsolutePath());

						JOptionPane.showMessageDialog(null,
								"Xml file is uploaded successfully!!");
					}
				} catch (Exception E) {

				}

			}
		});
		button_xmlUpload.setBackground(Color.LIGHT_GRAY);
		button_xmlUpload.setBounds(606, 76, 87, 38);
		contentPane.add(button_xmlUpload);

		Button button_dataSheetUpload = new Button("Browse");
		button_dataSheetUpload.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_dataSheetUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					FileChooser fileChooser = new FileChooser();

					File file = fileChooser.getFile();

					//System.out.println("The file name is " + file.getName());

					if (file.getName().contains(".xls")
							|| file.getName().contains(".xlsx")) {

						excelFile = file;

						System.out.println("The  file name is "
								+ excelFile.getName());
						
						textField_testData.setText(excelFile.getAbsolutePath());

						JOptionPane.showMessageDialog(null,
								"Datasheet is uploaded successfully!!");
					}
				} catch (Exception E) {

				}

			}
		});
		button_dataSheetUpload.setBackground(Color.LIGHT_GRAY);
		button_dataSheetUpload.setBounds(606, 154, 87, 38);
		contentPane.add(button_dataSheetUpload);

		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4
				.setIcon(new ImageIcon(
						"\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\"
								+ "Automation\\EOB Automation\\DbToProvXmlValBsc\\src\\test\\resources\\images"
								+ "\\excelsheetLogo2.png"));
		lblNewLabel_4.setBounds(291, 142, 69, 63);
		contentPane.add(lblNewLabel_4);

		JLabel lblEnvironment = new JLabel("FACETS ENVIRONMENT");
		lblEnvironment.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblEnvironment.setBounds(248, 227, 121, 50);
		contentPane.add(lblEnvironment);

		JComboBox comboBox_Environment = new JComboBox();
		comboBox_Environment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				environmentValue = comboBox_Environment.getSelectedItem()
						.toString();

			}
		});
		comboBox_Environment.setForeground(Color.DARK_GRAY);
		comboBox_Environment.setFont(new Font("Tahoma", Font.PLAIN, 12));
		comboBox_Environment.setBackground(Color.LIGHT_GRAY);
		comboBox_Environment.setModel(new DefaultComboBoxModel(new String[] {
				"SELECT", "FACN52A", "FACN51A", "FACH71A", "FACH70A",
				"FACH64A", "FACH63A" }));
		comboBox_Environment.setBounds(370, 235, 206, 35);
		contentPane.add(comboBox_Environment);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBorder(new TitledBorder(UIManager
				.getBorder("TitledBorder.border"), "", TitledBorder.LEADING,
				TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(370, 299, 206, 213);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		textField_DBUsername = new JTextField();
		textField_DBUsername.setBounds(10, 46, 189, 35);
		panel_1.add(textField_DBUsername);
		textField_DBUsername.setColumns(10);

		passwordField_DBPassword = new JPasswordField();
		passwordField_DBPassword.setBounds(10, 127, 187, 35);
		panel_1.add(passwordField_DBPassword);

		JLabel lbl_DBUsername = new JLabel("Username");
		lbl_DBUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl_DBUsername.setBounds(10, 11, 200, 50);
		panel_1.add(lbl_DBUsername);

		JLabel lbl_DBPassword = new JLabel("Password");
		lbl_DBPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl_DBPassword.setBounds(10, 91, 200, 50);
		panel_1.add(lbl_DBPassword);

		JButton btnTest = new JButton("Login");
		btnTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {

					dbUsername = textField_DBUsername.getText();
					dbPassword = passwordField_DBPassword.getText();
					if (comboBox_Environment.getSelectedIndex() != 0) {

						if (dbUsername != null
								&& !dbUsername.equalsIgnoreCase("")) {

							if (String.valueOf(dbPassword) != null
									&& !String.valueOf(dbPassword)
											.equalsIgnoreCase("")) {

								String dbName = comboBox_Environment
										.getSelectedItem().toString();

								System.out.println("The db name is " + dbName);

								// String userName = UserName.getText();

								// String password =
								// String.valueOf(passwordField.getPassword());

								environment = new DatabaseEnvironment();

								environment.setEnvironment(dbName);

								String dbServer = environment.getDBServer();

								String dbPort = environment.getDBPort();

								dbUtils = new DBUtils(dbName, dbUsername,
										dbPassword, dbServer, dbPort);

								dbUtils.setUpDBConnection();

							} else {

								JOptionPane.showMessageDialog(null,
										"Please enter password!!");
							}

						} else {
							JOptionPane.showMessageDialog(null,
									"Please enter UserName!!");
						}
					} else {
						JOptionPane.showMessageDialog(null,
								"Please select Environment!!");
					}

				} catch (Exception E) {

					E.printStackTrace();
				}
			}
		});
		btnTest.setBounds(10, 173, 89, 23);
		panel_1.add(btnTest);

		textField_ResultsPath = new JTextField();
		
		textField_ResultsPath.setColumns(10);
		textField_ResultsPath.setBounds(370, 539, 206, 38);
		contentPane.add(textField_ResultsPath);

		JLabel lblPathForResults = new JLabel("Path for Results");
		lblPathForResults.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPathForResults.setBounds(248, 535, 121, 50);
		contentPane.add(lblPathForResults);

		/*
		 * JProgressBar progressBar = new JProgressBar();
		 * progressBar.setStringPainted(true); progressBar.setBounds(583, 602,
		 * 110, 17); contentPane.add(progressBar);
		 */

		/*
		 * Button button_pathForResults = new Button("Browse");
		 * button_pathForResults.addActionListener(new ActionListener() { public
		 * void actionPerformed(ActionEvent e) {
		 * 
		 * JFileChooser chooser = new JFileChooser();
		 * chooser.setCurrentDirectory(new java.io.File("."));
		 * chooser.setDialogTitle("choosertitle");
		 * chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		 * chooser.setAcceptAllFileFilterUsed(false);
		 * 
		 * if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
		 * 
		 * try { pathR=
		 * FileUtils.readFileToString(chooser.getCurrentDirectory(),"UTF-8");
		 * lblPathForResults.setText(pathR);
		 * 
		 * } catch (IOException e1) {
		 * 
		 * lblPathForResults.setText(pathR); // TODO Auto-generated catch block
		 * e1.printStackTrace(); }
		 * 
		 * } } }); button_pathForResults.setFont(new Font("Tahoma", Font.BOLD,
		 * 12)); button_pathForResults.setBackground(Color.LIGHT_GRAY);
		 * button_pathForResults.setBounds(606, 539, 87, 38);
		 * contentPane.add(button_pathForResults);
		 */

	}
}
