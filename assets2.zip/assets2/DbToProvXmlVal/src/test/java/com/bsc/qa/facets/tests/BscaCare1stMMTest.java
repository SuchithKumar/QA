package com.bsc.qa.facets.tests;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.io.FileUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.bsc.qa.facets.ffpojo.utility.XMLParse;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable{
public static String filePath;
private static String sheetName;
public static DBUtils objDBUtility;//Mandatory declaration 
public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
private static Path path;
private static Path inputDataPath;
private static String resultsDestinationFolderPath;
private static String rootLocationOfInputFiles;
private static String SUCName;
static SoftAssert softAssertion= new SoftAssert();	 
	//************************************** TEST METHODS************************
		@Test(dataProvider = "masterDataProvider")
		private static void testXMLToDBValidationProvider(Map<String, String> data) {
			
			try {
				OtherUtilities.printTestCaseDeatilsInReport(data);
				//Retrieving data from test data sheet and storing data in variables
				String subscriberId= data.get("Query parameter1").toString().trim();
				
				String transactionNo = data.get("TransactionNo").trim();
				
				//System.out.println("The transaction no is "+transactionNo);
				
			//	System.out.println("subscrid"+subscriberId);
				SUCName = data.get("Keyword Name").toString();
				String xmlTag=data.get("Element TagName").toString().trim();	
				//String sheetName_MetadataSheet="Subscriber_EOB";
				String inputFileName=data.get("Input File Name").toString();
				String xmlFilePath = rootLocationOfInputFiles + "\\"+SUCName+"\\" + inputFileName;
				XMLParse.xmlSetup(xmlFilePath);
				String mappingSheetName="Mappingsheet_Provider";
			//	String mappingSheetPath="/DbToSubscriberXmlVal/src/test/resources/TestData.xlsx";
				XMLParse.nodeExtraction(xmlTag,transactionNo,mappingSheetName,subscriberId,softAssertion);
				//OtherUtilities.validate(sourceRowMap,queryDataMap,softAssertion);*/
				 } catch (Exception e){
						//System.out.println("Test Case Failed due to Exception.....!!");
						softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
						e.printStackTrace();
					}finally{
						//softAssertion.assertAll();	//<== absolutely must be here
					}
					
		}
		
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port",
		"RootLocationOfFlatFiles","ResultsDestinationFolderPath"}) //Note parrams order	
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name,
			String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles,
			String ResultsDestinationFolderPath){    //Args order matters should match to params order
		filePath=TestDataSheetLocation;
		path = Paths.get("target\\Results\\"+timestamp);
		 if(!Files.exists(path)){
			try {
				Files.createDirectories(path);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		//System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		//test data sheet name
		sheetName=NameOfTestDataSheet;
		//path of the input test files
		rootLocationOfInputFiles = RootLocationOfFlatFiles;
		//path of the results folder 
		resultsDestinationFolderPath=ResultsDestinationFolderPath;
		// Functional call to initialize cache from data sheet 
	//	ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		//statement to set up databse connection
		 objDBUtility.setUpDBConnection();
		 //Below step is for setting up the path of the input file
		 //TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
			//Below step is for getting complete path of the input file		 
		 
		 //filePAth = tesFile.getCompleteTestFilePath();	 
		
	}


//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		Map map=(Map) callBack.getParameters()[0];
		String testCaseName="TestcaseID:"+map.get("Test Case ID")+"SubscriberID:"+map.get("Query parameter1");
		reportInit(testResult.getTestContext().getName(), testResult.getName(),testCaseName);
		System.out.println("testCaseName"+testCaseName);
		
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{


		  Object[][] columnArray=   ExcelUtils.getColumnArray(filePath, sheetName);
		  Object[][] testDataArray= ExcelUtils.getTableArray(filePath, sheetName);
		  List<Object> list=new ArrayList<Object>();
		
		  int noOfTestCases=0;
		  String runMode="Yes";
		  for(int row=0;row<=testDataArray.length-1;row++){
			if(method.getName().substring(4).equalsIgnoreCase(testDataArray[row][1].toString())&& runMode.equalsIgnoreCase(testDataArray[row][2].toString())){
				noOfTestCases++;
				//System.out.println("TestCase  Data Sheet:::"+testDataArray[row][1].toString());
				//map for storing all rows which are having run mode "yes"
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++)
				{
				//looping through all teh columns and puting the values in rowmap
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
					
				}
				//System.out.println("Row Datamap"+rowDataMap);
				list.add(rowDataMap);//adding rows map in to list
				//data[row][0]=rowDataMap;
			}
		}
		  Object[][] data = new Object[noOfTestCases][1];
		  for(int row=0;row<list.size();row++){
			  data[row][0]=list.get(row);//adding the rowmap data into object array
		  }
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		//clsong the report after execution
		ReportFactory.closeReport();
	}
	
	@AfterMethod
	public void afterMethod() throws IOException{
		//path for results destination folder
		inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		File srcDir = new File(rootLocationOfInputFiles+"\\"+SUCName+"\\");//Input Data folder path
		Path SUCFolderPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = resultsDestinationFolderPath+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
	}
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
		try {
			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			Path extentReportDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\Report.html");//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
			//TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get("src\\test\\resources\\TestData.xlsx");//storing report source path in testDataSourcePath
			Path testDataSheetDestinationPath=Paths.get(resultsDestinationFolderPath+timestamp+"\\InputData\\TestData.xlsx");//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files
			
			
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	  }
	  public static void validataXmlAndDbValues(String elementName,String xmlValue, String dbValue,String originalDbValue) {
			//validation of the xml and db values
			softAssertion.assertEquals(xmlValue.replaceAll("\\s+",""), dbValue.replaceAll("\\s+",""),"xmlValue:"+xmlValue.replaceAll("\\s+","")+"| dbValue:"+dbValue.replaceAll("\\s+",""));
			String status="Fail";
			
			if(xmlValue.replaceAll("\\s+","").equalsIgnoreCase(dbValue.replaceAll("\\s+",""))){
				status="Pass";
				logger.log(LogStatus.PASS," Element Name: " + elementName + "|---------- xmlValue: " +xmlValue+ "----------dbValue: " + originalDbValue+"|----------Status:"+status);
			}
			
			
			else{
				logger.log(LogStatus.FAIL," Element Name: " + elementName + "|---------- xmlValue: " +xmlValue+ "----------dbValue: " + originalDbValue+"|----------Status:"+status);
				}
			//logger for showing the results in extents report html file
			
			System.out.println(" Element Name: " + elementName + "|---------- xmlValue: " +xmlValue.replaceAll("\\s+","")+ "----------dbValue: " + dbValue.replaceAll("\\s+",""));
				
		}
	  
}
