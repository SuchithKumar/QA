package com.bsc.qa.facets.ffpojo.utility;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.testng.asserts.SoftAssert;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.tests.BscaCare1stMMTest;
import com.relevantcodes.extentreports.LogStatus;

public class XMLParse extends BaseTest {
	
	private static DocumentBuilder dBuilder;
	private static Document doc;
	private static String uniqueId;
	static SoftAssert softAssertion;
	public static void xmlSetup(String xmlPath) {
		File fXmlFile=new File(xmlPath);//Creating file for the given path
		//ExcelUtilities.setUp();
		//creating instance for the DocumentBuilderFactory
		DocumentBuilderFactory dbFactory= DocumentBuilderFactory.newInstance();
		
		try {
			//creating instance for the DocumentBuilder
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
		} catch (ParserConfigurationException e) {e.printStackTrace();		}
		  catch (SAXException e) {e.printStackTrace();} 
		  catch (IOException e) {e.printStackTrace();}
	}
	
	public static ArrayList<String> attributeValue(String tagName){
		//System.out.println("Extracting attribute values!!");
		ArrayList<String> idList = new ArrayList<String>();//List for storing attributes
		//Accessing the the nodes having tagname
		NodeList PagesList=doc.getElementsByTagName(tagName);//tags are upto refined address only.not taking child nodes like address1
		//System.out.println("PagesList"+ PagesList);
		//Looping through the nodeslist
		for(int nodeNo =0;nodeNo<PagesList.getLength();nodeNo++){
			Node node = (Node)PagesList.item(nodeNo);
			//checking for the attributes in node
			if(node.hasAttributes()){
				NamedNodeMap attributesList=node.getAttributes();//getting all the attributes in the node
				//looping through the attributes list
				for(int attribute_Number=0;attribute_Number<attributesList.getLength();attribute_Number++){
				//getting Attributes in the attributes list	
					Attr attr=(Attr) attributesList.item(attribute_Number);
				//	String attributeName=attr.getNodeName();
					String attributeValue=attr.getNodeValue();
				//System.out.println("The attribute values are !!!!"+attributeValue);
					idList.add(attributeValue);
				}
			}else{
				//System.out.println("The node has no attributes!!!");}
			}
	}
		return idList;//retuning the attributes list
		
	}
	//Method to extract s and attributes and its values
	public static void  nodeExtraction(String tagName, String uId, String mappingSheetName,String subscriberId, SoftAssert softAssert) 
			throws SQLException {
		//Accessing the the nodes having tagname
		//System.out.println("tagNmae:"+tagName);
		//System.out.println(" I am in node extraction");
		NodeList PagesList=doc.getElementsByTagName(tagName);
		//System.out.println("size:"+PagesList.getLength());

		
		
		softAssertion=softAssert;//soft assertion for validation
		uniqueId=uId;//subscriber id  value
       // System.out.println("index:"+getIndexOfTag(tagName,uniqueId));
		Node node = (Node)PagesList.item(getIndexOfTag(tagName,uniqueId));
		
		//Node node1 = (Node)PagesList.item(getIndexOfTag("refined_address",uniqueId));
		//System.out.println("list of node"+node);
		if(hasChildElements((Element)node)){//checking for node has child elements or not
			getElementAtttributes((Element)node,mappingSheetName,subscriberId);//attributes elements of given node
			getChildElements((Element)node,mappingSheetName,subscriberId,tagName);//child elements of given node
		   }
		
		
	}
	//Method to retrieve all the attributes of elements
		private static void getElementAtttributes(Element node, String sheetName,String Id) throws SQLException {
			if(node.hasAttributes()){//checking for attributes in node
				NamedNodeMap attributesList=node.getAttributes();//all attributes in node
					for(int attribute_Number=0;attribute_Number<attributesList.getLength();attribute_Number++)
					{
						//Looping through the nodeslist and getting individual elements
						Attr attr=(Attr) attributesList.item(attribute_Number);
						String attributeName=attr.getNodeName();//Attribute name
						String attributeValue=attr.getNodeValue();//attribute value
					//	System.out.println("attributeName: "+attributeName);
					//	System.out.println("attributeValue: "+attributeValue);
					//	System.out.println("Excel Sheet Value: "+Id);
						
						if ((attributeName.contains("payer_claim_control_num")) && (attributeValue.contains(Id)))
						{
					
						//getting the query for the given element name
						String dbValue=getElementValueFromDB(attributeName.trim().toString(),Id,sheetName,node);
						String ScrubbedDBVAlue = getscrubDBdata(node.getNodeName().trim().toString(), dbValue);
					//	System.out.println("I am inside If and getting DB value");
						//System.out.println("db value"+dbValue);
						if(dbValue!=null){
							
							//call validate method for validation of xml value and db value
							BscaCare1stMMTest.validataXmlAndDbValues(attributeName.trim().toString(), attributeValue, ScrubbedDBVAlue,dbValue);	
						}
						}
					}
			}
		}

		private static void getValuesOfElement(Element node,  String sheetName,String Id) throws SQLException {
			//getting the query for the given element name
			String dbValue=getElementValueFromDB(node.getNodeName().trim().toString(),Id,sheetName,node);
			String ScrubbedDBVAlue = getscrubDBdata(node.getNodeName().trim().toString(), dbValue);
			//System.out.println("Node Value = "+node.getNodeName().trim().toString());
			//System.out.println("Node Value = "+node.getNodeValue().trim().toString());
		//	String xPath = getXPath(node);
			String strValue=null;
			if(dbValue!=null){
				if(node.getNodeName().trim().toString().equalsIgnoreCase("approved_to_pay")){
					strValue = node.getTextContent().toUpperCase().replace("$", "");
					BscaCare1stMMTest.validataXmlAndDbValues(node.getNodeName().trim().toString().replace("$", ""), strValue, ScrubbedDBVAlue,dbValue);
				}
				
				else if(node.getNodeName().trim().toString().equalsIgnoreCase("Address_1")){
					strValue = node.getTextContent().toUpperCase().replace(",", "");
					BscaCare1stMMTest.validataXmlAndDbValues(node.getNodeName().trim().toString().toUpperCase().replace(",", ""), strValue, ScrubbedDBVAlue,dbValue);
				}
			//call validate method for validation of xml value and db value
				BscaCare1stMMTest.validataXmlAndDbValues(node.getNodeName().trim().toString(), node.getTextContent().trim().toUpperCase(), ScrubbedDBVAlue,dbValue);
				}
			}
			
	private static String getElementValueFromDB(String elemetName,String Id,  String sheetName,Element node) throws SQLException {
		//retrieve query for the given element name
		//System.out.println("elemetName Name:"+elemetName.trim().toString());
		
		String query=ExcelUtils.getQueryFromMappingSheet(elemetName,sheetName);
		String dbValue=null;
	//	String xPath = getXPath(node);
		if(elemetName.equalsIgnoreCase("statement_mode"))
		{
			query=dbValue;
		}
		else if(elemetName.equalsIgnoreCase("correspondence"))
		{
			query=dbValue;
		}
	
		if(query!=null){//check for the null values of query
			//String	SQLQuery=query.replace( "VAR_SBSB_ID_VALUE",subscriberId);//replacing subscriber id
	       String SQLQuery=query.replace( "UniqueId",Id);//replacing subscriber id
	       //System.out.println("SQLQuery:  "+SQLQuery);
			//StringSQLQuery=query.replace( "{$PARAM1}",subscriberId);//replacing subscriber id
			//running the query and getting the database value
			 dbValue=BscaCare1stMMTest.objDBUtility.getDatabaseValue(SQLQuery);
			// System.out.println("elemetName :"+elemetName.trim().toString());
			 //System.out.println("dbValue: "+dbValue);
			 String ScrubbedDBVAlue = getscrubDBdata(node.getNodeName().trim().toString(), dbValue);
			 if(node.getNodeName().equalsIgnoreCase("print_amt"))
				{
					try {
					
					if (dbValue.indexOf(".") != 0)
					{
						dbValue = "**********"+dbValue.substring(0,dbValue.indexOf("."))+"*DOLLARS*"+dbValue.substring(dbValue.indexOf(".")+1)+"*CTS*";
						dbValue=BscaCare1stMMTest.objDBUtility.getDatabaseValue(SQLQuery)+"**********"+dbValue.substring(0,dbValue.indexOf("."))+"*DOLLARS*"+dbValue.substring(dbValue.indexOf(".")+1)+"*CTS*";
					}
					}
					catch(Exception e)
					{
						//dbValue = "*********"+dbValue+"*DOLLARS*"+"00*CTS*";
					}
					
				}
			 else if(node.getNodeName().equalsIgnoreCase("bsc_line_of_business"))
			 {
				 dbValue=dbValue.toString().trim().replace("CARE1", "C1");
			 }
			 
			 
			 
			 
			 else if(node.getNodeName().contains("bsc_line_of_business"))
			 {
				 dbValue=dbValue.toString().trim().substring(0, 3);
				 
			 }
			 
	    }else{
			//System.out.println("else query:"+query);
		}
		return dbValue;
	}
	//This method is to retrieve child nodes of node
	private static void getChildElements(Element nNode,String sheetName,String Id,String tagName) throws SQLException {
		NamedNodeMap attributesList=nNode.getAttributes();//all attributes in node
		for(int attribute_Number=0;attribute_Number<attributesList.getLength();attribute_Number++)
		{
			//Looping through the nodeslist and getting individual elements
			Attr attr=(Attr) attributesList.item(attribute_Number);
			String attributeName=attr.getNodeName();//Attribute name
			String attributeValue=attr.getNodeValue();//attribute value
			//System.out.println("attributeName: "+attributeName);
			//System.out.println("attributeValue: "+attributeValue);
		    if((attributeName.contains("payer_claim_control_num")) && (!attributeValue.contains(Id)))
			{
				return;
			}
		    else if((attributeName.equalsIgnoreCase("service_id"))&&(attributeValue.equalsIgnoreCase("2"))||(attributeValue.equalsIgnoreCase("3"))||(attributeValue.equalsIgnoreCase("4"))||(attributeValue.equalsIgnoreCase("5")))
			{
				return;
			}
		    /*else if((attributeName.equalsIgnoreCase("service_id"))&&(attributeValue.equalsIgnoreCase("2"))||(attributeValue.equalsIgnoreCase("3"))||(attributeValue.equalsIgnoreCase("4"))||(attributeValue.equalsIgnoreCase("5")))
			{
				return;
			}*/
			
			
		}
	
		 Node parent = nNode.getParentNode();
		//System.out.println("parent"+parent);
		 		 
		 NodeList children=nNode.getChildNodes();//get child nodes of node//child node is refined address.
	  // System.out.println("children: "+children);
		 
		/*if(parent.getNodeName().equals("claim_batch")||children.toString().contains("payer_address"))
		{
			return;
		}*/
		/*if(parent.getNodeName().equals("correspondence")||children.toString().contains("correspondence"))
		{
			return;
		}*/
		 if(children.toString().contains("generic_address"))
		{
			return;
		}
		 else if(children.toString().contains("refined_address"))
			{
				return;
			}
		 else if(((Node) children).toString().contains("batch_control_info"))
			{
				return;
			}
		 
	 else if(((Node) children).getNodeName().equals("batch_supplemental_control_info")||nNode.getNodeName().toString().contains("allowed_amt"))
		{
			return;
		}
		 else if(((Node) children).getNodeName().equals("service_supplemental_amt")||nNode.getNodeName().toString().contains("allowed_amt"))
		{
			return;
		}
		
		else
		for(int i=0;i<children.getLength();i++)
		{ //loop through child nodes
				Node node=(Node) children.item(i);
				//System.out.println("node children:"+node);
			      if(node.getNodeType()==Node.ELEMENT_NODE)
			      {
						if(hasChildElements((Element)node))
						{//checking for child nodes
								//childCount++;
								getElementAtttributes((Element)node,sheetName,Id);//getting attributes of elements
							//	System.out.println("Tag name : " + tagName);
								getChildElements((Element)node,sheetName,Id,tagName);//getting child elements
								//System.out.println("(Element)node"+(Element)node);
						}
						
						else
						{
							   //System.out.println("I am in else printing DB");
							 	getValuesOfElement((Element)node,sheetName,Id);//getting values of elements
					      }
			      }
			      }
		}
		

		
	
	private static boolean hasChildElements(Element el) {
		//get child nodes for the given node
		NodeList children=el.getChildNodes();
		
		for(int i=0;i<children.getLength();i++){
			//looping through the nodes and checking for element node
		if(children.item(i).getNodeType()==Node.ELEMENT_NODE)//chck for element node
		
			return true;
		}
	return false;
	}


	public static int getIndexOfTag(String tagName,String uniqueId){
		
		int tagIndex=0;
		boolean flag=false;
		NodeList PagesList=doc.getElementsByTagName("*");
		for(int nodeNo =0;nodeNo<PagesList.getLength();nodeNo++){
			
			Node node = (Node)PagesList.item(nodeNo);
			Element element=(Element)node;
			//System.out.println("element"+element);
			if(element.getTagName().toString().trim().equalsIgnoreCase(tagName))
			{
				tagIndex++;	
			}
			/*else if(element.getTagName().toString().trim().equalsIgnoreCase("refined_address"))
			{
			   element.getFirstChild();
				
			}*/
			
			if(node.hasAttributes()){//check for node has attributes or not
				NamedNodeMap attributesList=node.getAttributes();//getting all attributes of node
				//looping through attributes list of element
				for(int attribute_Number=0;attribute_Number<attributesList.getLength();attribute_Number++){
					Attr attr=(Attr) attributesList.item(attribute_Number);
				//	String attributeName=attr.getNodeName();
					String attributeValue=attr.getNodeValue();//attribute value
					//System.out.println("AttrValu:"+attributeValue+"|input:"+subscriberId+"|"+attributeValue.equals(subscriberId));
					if(attributeValue.toString().trim().equalsIgnoreCase(uniqueId)){//checking for the attribute value
						flag=true;
						break;
						}
				}	
				if(flag){
					break;
				}
			}
		}
		return tagIndex;
		
	}
	
 public static String getscrubDBdata(String element, String value)
 {
	 
	/*if  (element.contains("bsc_line_of_business"))
	{
		value = value.replace("CARE1", "C1");
	}*/
  /*if(element.contains("print_amt"))
	{
		value = value.replace("********214*DOLLARS*00*CTS*","270");
	}*/
	 /*if(element.contains("city"))
	{
		value = value.toUpperCase()+",";
	}*/
	/*else if(element.contains("print_amt"))
	{
		try {
		
		if (value.indexOf(".") != 0)
		{
			value = "********"+value.substring(0,value.indexOf("."))+"*DOLLARS*"+value.substring(value.indexOf(".")+1)+"*CTS*";
		}
		}
		catch(Exception e)
		{
			value = "********"+value+"*DOLLARS*"+"00*CTS*";
		}
		
	}*/
	/*else if(element.contains("postal_code"))
	{
		value = value.substring(0, 5);
		
     }*/
	/*else if(element.contains("address_1"))
	{
		value = value.replace(",", "");
		//System.out.println(": "+value);
		
     }*/

	
	return value;
	 
 }


		}
	

