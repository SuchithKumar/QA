package com.bsc.qa.facets.utility;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.dom4j.tree.ElementNameIterator;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.relevantcodes.extentreports.LogStatus;

public class XMLParseBSCLobs extends BaseTest {


	private Document doc;
	public String subscriberId;

	public SoftAssert softAssertion = null;
	private String sbid="";
	DBUtils dbUtils;
	
	private int index = 0;
	private int index_bename = 0;
	private int index_p_name=0;
	private int index_phn_no=0;
	private int index_pcp_date=0;
	private int intPhoneNumberLabelIndex = 0;
	private String strFormatID = "";
	public String dbValue;
	private String strUniqueData = "";
	private String strDestination="";
	private String strLanguageCode="";
	private String strreasonindicator="";
	private String flag1="no";
	private String flag2="no";
	private String flag2_calpers="yes";
	private String flag2_fehbp="yes";
	private String flag_aso_r="yes";
	private String flag_aso_l="yes";
	private String flag_hmo_r="yes";
	private String flag_hmo_l="yes";
	private String flag_custom_r="yes";
	private String flag_custom_l="yes";
	private String flag_mid_large_l="yes";
	private String flag_mid_large_r="yes";
	private String flag_meia_sts="yes";
	private String flag_address="no";
	private String flag2_calpers_r="yes";
	private String flag_groupno_MId_large="no";
	private String flag_group_id="no";
	private String group_number;
	
	
	/**
	 * To create instance of document builder for the XML
	 * @param xmlPath: XML file complete path
	 */
	public void xmlSetup(String xmlPath) throws ParserConfigurationException,SAXException,IOException {
		DocumentBuilder dBuilder;
		File fXmlFile = new File(xmlPath);// Creating file for the given path
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		try {
			// creating instance for the DocumentBuilder
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
		}
		//To capture the ParserConfigurationException exception
		catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		//To capture the SAXException exception
		catch (SAXException e) {
			e.printStackTrace();
		}
		//To capture the IOException exception
		catch (IOException e) {
			e.printStackTrace();
		}
	
	}

	/**
	 * To extract Unique section from XML and compare XML data against database
	 * @param tagName: Parent tag name
	 * @param mappingSheetName: Filed versus queries mapping sheet
	 * @param subscriberId: Unique ID to fetch specific section
	 * @param softAssert: 
	 * @throws Exception 
	 */
	public void nodeExtraction(String tagName, String mappingSheetName,
			String subscriberId, SoftAssert softAssert) throws Exception {
		//To get the elements using tagName
		NodeList PagesList = doc.getElementsByTagName(tagName);
		  flag1="no";
		  flag2="no";
		  flag2_calpers="yes";
		  flag2_fehbp="yes";
		  flag_aso_r="yes";
		  flag_aso_l="yes";
		  flag_custom_r="yes";
		  flag_custom_l="yes";
		  flag_hmo_r="yes";
		  flag_hmo_l="yes";
		  flag_mid_large_l="yes";
		  flag_mid_large_r="yes";
		  flag_meia_sts="yes";
		  flag_address="no";
		  flag2_calpers_r="yes";
		  flag_groupno_MId_large="yes";
		  flag_group_id="no";
		//Checking each parent tag sections in the XML using for loop
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);
			index = 0;
			strFormatID = "";
			intPhoneNumberLabelIndex = 0;
			softAssertion = softAssert;
			
			System.out.println("node is "+(Element)node);
			
			//Calling recursive function to fetch and compare tag values with database values
			if (hasChildElements((Element) node)) {
				/*System.out.println("Mapping sheet name "+mappingSheetName);
				System.out.println("subscriberId "+subscriberId);*/
				System.out.println("tagName "+tagName);
				System.out.println("(Element) node "+(Element) node);
				parseChildElements((Element) node, mappingSheetName, subscriberId, tagName, (Element) node);
				
			}
		}
	}
	/**
	 * To extract Unique data from XML
	 * @param tagName: Primary parent tag name
	 * @param strUniqueTagName: Unique tag name
	 * @return : To return all unique values with "|" this delimiter
	 * @throws SQLException: To throw the SQLException exception
	 * @throws ParseException: To throw the ParseException exception
	 */
	public String UniqueDetailsExtraction(String tagName, String strUniqueTagName) throws SQLException, ParseException{
		
		//To initialize the variable
		strUniqueData = "";
		//To get the elements using tagName
		NodeList PagesList = doc.getElementsByTagName(tagName);
		//Checking each parent tag sections in the XML using for loop
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);
			index = 0;
			//To check the node when it is having child elements
			if (hasChildElements((Element) node)) {				
				//To extract Unique tag data from XML 
				parseChildElementsForUniqueIDs((Element) node, strUniqueTagName);
			}
		}
		// Returning unique data with pipe (|) delimiter
		return strUniqueData;
	}
	
	/**
	 * To extract Unique data from XML
	 * @param nNode: Parent node to retrieve child nodes along with tag values
	 * @param strUniqueTagName: Unique tag name to retrieve corresponding value
	 * @throws SQLException: To throw the SQLException exception
	 * @throws ParseException:  To throw the ParseException exception
	 */
	private void parseChildElementsForUniqueIDs(Element nNode, String strUniqueTagName)	throws SQLException, ParseException {
		
		String elementName = "";
		String elementvalue = "";
		
		NodeList children = nNode.getChildNodes();// get child nodes of node
		for (int i = 0; i < children.getLength(); i++) { // loop through all child nodes
			Node node = (Node) children.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				elementName = node.getNodeName().trim().toString();
				elementvalue = node.getTextContent().trim().toString();
				//Checking unique element name in the XML
				if ((elementName.equalsIgnoreCase(strUniqueTagName))) {
					//Storing Unique data into strUniqueData variable with pipe (|) delimiter
					strUniqueData = strUniqueData + "|" + elementvalue;
					
				} else if (hasChildElements((Element) node)) {// checking for the child elements
					//calling recursive function to fetch data from child				
					parseChildElementsForUniqueIDs((Element) node, strUniqueTagName);
				}
			}
		}
	}

	/**
	 * Recursive method to parse all the elements under the node	 * 
	 * @param nNode: Node name for extraction
	 * @param mappingSheetName:  Test data mapping sheet name for queries
	 * @param subscriberId: Unique id to retrieve matching section from XML
	 * @param tagname: Tag Name
	 * @param pNode: Parent node name
	 * @throws Exception 
	 */
	private void parseChildElements(Element nNode, String mappingSheetName,	String subscriberId, String tagname, Element pNode)
			throws Exception {
		NodeList children = nNode.getChildNodes();// get child nodes of node
		for (int i = 0; i < children.getLength(); i++) { // loop through child nodes

			Node node = (Node) children.item(i);
			//Checking for the element node
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				String elementName = node.getNodeName().trim().toString();
				String elementvalue = node.getTextContent().trim().toString();
				// System.out.println("Element Name: "+elementName );
				// System.out.println("Element Value: "+elementvalue );
				if ((elementName.equalsIgnoreCase("subscriber_id"))
						&& (elementvalue.equalsIgnoreCase(subscriberId))) {
					getElementAtttributes((Element) pNode, mappingSheetName, subscriberId);// getting attributes of elements
					getChildElements((Element) pNode, mappingSheetName,	subscriberId, tagname);// getting child elements
				} else if (hasChildElements((Element) node)) {// checking for child nodes
					//Calling the recursive method inside the same method
					/*System.out.println("Mapping sheet name in 191"+mappingSheetName);
					System.out.println("subscriberId in 191 "+subscriberId);
					System.out.println("tagName in 191"+tagname);
					System.out.println("(Element) node in 191 "+(Element) node);
					System.out.println("p node is in 191"+pNode);
					*/
					//ystem.out.println("tagname is in parseChildElements "+pNode);
					parseChildElements((Element) node, mappingSheetName, subscriberId, tagname, pNode);
				}
			}
		}
	}

	
	/**
	 * To retrieve database value for the nodes and compare database values with XML attribute values
	 * @param node: Node name for comparison
	 * @param sheetName: Test data mapping sheet name for queries
	 * @param subscriberId: Unique ID for the query input
	 * @throws SQLException: To throw the SQLException exception
	 * @throws ParseException: To throw the ParseException exception
	 */
	private void getElementAtttributes(Element node, String sheetName, String subscriberId) throws SQLException, ParseException {
		
		if (node.hasAttributes()) {// checking for attributes in node
			NamedNodeMap attributesList = node.getAttributes();// all attributes
																// in node
			//Loop through all attribute lists
			for (int attribute_Number = 0; attribute_Number < attributesList.getLength(); attribute_Number++) {
				Attr attr = (Attr) attributesList.item(attribute_Number);
				String attributeName = attr.getNodeName();// Attribute name capture
				String attributeValue = attr.getNodeValue();// attribute value capture
				//Retrieving and Storing database value into a dbValue variable
				String dbValue = getElementValueFromDB(attributeName.trim().toString(), subscriberId, sheetName, node);
				if(dbValue == null){
					//To compare XML value against database value
					validataXmlAndDbValues(attributeName.trim().toString(),	attributeValue, "[Blank]");
				}
				if(!dbValue.equalsIgnoreCase("TagNotConsiderForValidation")){
						//To compare XML value against database value
					System.out.println("attribute name is "+ attributeName.trim().toString());
						validataXmlAndDbValues(attributeName.trim().toString(),	attributeValue, dbValue);
				}
			}
		}
	}

	/**
	 * To retrieve database value for the nodes and compare database values with XML values
	 * @param node: Node name for comparison
	 * @param sheetName: Test data mapping sheet name for queries
	 * @param subscriberId: Unique id to replace in the query
	 * @throws Exception 
	 */
	private void getValuesOfElement(Element node, String sheetName,	String subscriberId) throws Exception {
		// getting the query for the given element name
		// System.out.println("XML value is "+node.getNodeName().trim().toString());
		// System.out.println("FormatID: "+FormatID);

		String elementName = node.getNodeName();
		String xpath = getXPath(node);
		// System.out.println("elementName: "+elementName);
		// System.out.println("children:"+node.getTextContent());
		// System.out.println("Parentnode:         "+Parentnode);
		
		String vendorn= UniqueDetailsExtraction("header","destination");
		//System.out.println("vendor name isssss "+vendorn);
		if (elementName.trim().equalsIgnoreCase("format_id")) {
			strFormatID = node.getTextContent();
		}
		
		//Storing Format ID for Mobile number label and Mobile number data fields comparison
		if (elementName.trim().equalsIgnoreCase("language_code")) {
			strLanguageCode = node.getTextContent();
			System.out.println("str lang code issssss "+strLanguageCode);
		}
		if (elementName.trim().equalsIgnoreCase("reason_indicator")) {
			strreasonindicator = node.getTextContent();
		}
		//Validating address_1 field
		if (elementName.trim().equalsIgnoreCase("address_1")) {
			
			// System.out.println("index of parent:"+ index);
			if (xpath.contains("send_address/address_1")) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"Send_Address",xpath);
			}
			if (xpath.contains("return_address/address_1")) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"return_address",xpath);
			}
		}
		//Validating address_2 field
		if (elementName.trim().equalsIgnoreCase("address_2")) {
			
			// System.out.println("index of parent:"+ index);
			if (xpath.contains("send_address/address_2")) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"Send_Address",xpath);
			}
			if (xpath.contains("return_address/address_2")) {
				//Fetching and comparing XML and database values
				System.out.println("");
				if(node.getTextContent().contains("FEHBP"))
				{
					flag1="yes";
					System.out.println("in yesssss of FEHBP");
				}
				else if(node.getTextContent().contains("CalPERS"))
				{
					flag2="yes";
					System.out.println("in yesssss of CalPERS");
				}
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"return_address",xpath);
				flag_address="yes";
			}
		}
		//Validating City field
		if (elementName.trim().equalsIgnoreCase("city")) {
			
			// System.out.println("index of parent:"+ index);
			if (xpath.contains("send_address/city")) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"Send_Address",xpath);
			}
			if (xpath.contains("return_address/city")) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"return_address",xpath);
			}
		}
		//Validating state field
		if (elementName.trim().equalsIgnoreCase("state")) {
			
			// System.out.println("index of parent:"+ index);

			if (xpath.contains("send_address/state")) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"Send_Address",xpath);
			}
			if (xpath.contains("return_address/state")) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"return_address",xpath);
			}
		}
		//Validating zip field
		if (elementName.trim().equalsIgnoreCase("zip"))

		{
			
			// System.out.println("index of parent:"+ index);
			if (xpath.contains("send_address/zip")) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"Send_Address",xpath);
			}
			if (xpath.contains("return_address/zip")) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetchingWithXPath(node,subscriberId,sheetName,"return_address",xpath);
			}
		}
		if(elementName.trim().equalsIgnoreCase("group_number")){
			group_number=node.getTextContent();
			String[][] dbValue1_val;
			String query_lang_code = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
			.getQueryFromMappingSheet("Mid_large_group_id", sheetName);
			String SQLQuery = query_lang_code.replace("GroupId", group_number);
			try{
				dbValue1_val =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
				if(dbValue1_val[0][0].contains("Large")|| dbValue1_val[0][0].contains("Midsize")){
					System.out.println("in mid large group id");
					flag_groupno_MId_large="true";
				}
			}
			
			catch(Exception e)
			{
				System.out.println("query is returning null");
			}
			flag_group_id="yes";
			
		}
		//	System.out.println("language issssssssssssssssss "+strLanguageCode);

    	String[][] dbValue1=null;
    	String[][] dbValue2=null;
			//For validating CalPERs plan
    	if(flag_address.equalsIgnoreCase("yes")&& flag_group_id.equalsIgnoreCase("yes") && ( flag_mid_large_l.equalsIgnoreCase("yes")&&flag_mid_large_r.equalsIgnoreCase("yes")&&flag2_calpers_r.equalsIgnoreCase("yes")&& flag2_calpers.equalsIgnoreCase("yes")&& flag2_fehbp.equalsIgnoreCase("yes") && flag_aso_l.equalsIgnoreCase("yes")&&flag_hmo_l.equalsIgnoreCase("yes")))
    	{
    		if(flag_groupno_MId_large.equalsIgnoreCase("true")){
    			//Id card for Mid-Large lob
				System.out.println("id card lob is Mid-Large");
				String query_lang_code = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
    			.getQueryFromMappingSheet("language_code", sheetName);
    			String SQLQuery = query_lang_code.replace("UniqueId", subscriberId);
    			String query1_rsn_ind = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
    			.getQueryFromMappingSheet("reason_indicator", sheetName);
    			String SQLQuery1 = query1_rsn_ind.replace("UniqueId", subscriberId);
    			try{
        			dbValue1 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
        			dbValue2 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery1);
        			System.out.println("query isssssssssssssss for rs "+SQLQuery1);
    				System.out.println("strLanguageCode is  "+strLanguageCode+" dbval issssss "+dbValue1[0][0]+" val isss "+dbValue1[0][0].equalsIgnoreCase(strLanguageCode));
    				System.out.println("strreasonindicator is  "+strreasonindicator+" dbval issssss "+dbValue2[0][0]);
        			if (dbValue1[0][0].equalsIgnoreCase(strLanguageCode))
        			{
        				System.out.println("dbvalue is  inside "+dbValue1[0][0]);
        				System.out.println("strLanguageCode is inside "+strLanguageCode);
        				if(dbValue1[0][0].equalsIgnoreCase("EN") && flag_mid_large_l.equalsIgnoreCase("yes")){
        					System.out.println("In English ID Cards for Mid-Large plans");
        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for Mid-Large plan ");
        				flag_mid_large_l="no";
        				}
        				System.out.println("%%% db val "+dbValue2[0][0]);
        				System.out.println("%%% ri val "+strreasonindicator);
        			}
        			if(dbValue2[0][0].equalsIgnoreCase(strreasonindicator)){
            			if(dbValue2[0][0].equalsIgnoreCase("N")){
            				System.out.println("In ID Cards for Mid-Large plan for New type enrollment");
            				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for Mid-Large plan with New type enrollment ");
            				flag_mid_large_r="no";
            			}else if(dbValue2[0][0].equalsIgnoreCase("C")){
            				System.out.println("In ID Cards for Mid-Large plan for Change type enrollment");
            				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for Mid-Large plan with Change type enrollment ");
            				flag_mid_large_r="no";
            			}else if(dbValue2[0][0].equalsIgnoreCase("R")){
            				System.out.println("In ID Cards for Mid-Large plan for Replacement type enrollment");
            				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for Mid-Large plan with Replacement type enrollment ");
            				flag_mid_large_r="no";
            			}	else if(dbValue2[0][0].equalsIgnoreCase("D")){
            				System.out.println("In ID Cards for Mid-Large plan for Duplicate type enrollment");
            				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for Mid-Large plan with Duplicate type enrollment ");
            				flag_mid_large_r="no";
            			}else{
            				System.out.println("subscriber is not present for Mid-Large plan for ARVATO vendor");
            			}
            			flag_mid_large_r="no";	
        			}
        						
    		
    			
        			flag_groupno_MId_large="no";
			
	}
		catch(Exception e)
		{
			System.out.println("query is returning null for Mid-Large ");
		}
	
    		}
    		else if(vendorn.contains("ARVATO")&& (flag2.equalsIgnoreCase("yes"))){
    		if(flag2_calpers_r.equalsIgnoreCase("yes") || flag2_calpers.equalsIgnoreCase("yes") ){
    			//Id card for Calpers lob
    		System.out.println("inside calpers loop");
    		String query_lang_code = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
			.getQueryFromMappingSheet("language_code", sheetName);
			String SQLQuery = query_lang_code.replace("UniqueId", subscriberId);
			String query1_rsn_ind = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
			.getQueryFromMappingSheet("reason_indicator", sheetName);
			
			String SQLQuery1 = query1_rsn_ind.replace("UniqueId", subscriberId);
    			try{
        			dbValue1 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
        			dbValue2 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery1);
        			if (dbValue1[0][0].equalsIgnoreCase(strLanguageCode)&& flag2_calpers.equalsIgnoreCase("yes"))
        			{
        				System.out.println("in loop 3rd stmt "+strLanguageCode);
        				if(dbValue1[0][0].equalsIgnoreCase("EN")){
        					System.out.println("In English ID Cards for CalPERS plan");
        					logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for CalPERS plan ");
        					flag2_calpers="no";
        				}
        				else if(dbValue1[0][0].equalsIgnoreCase("SP")){
        					System.out.println("In Spanish ID Cards for CalPERS plan");
        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received Spanish ID Cards for CalPERS plan ");
        				flag2_calpers="no";
        				}
        			}	
        			if(dbValue2[0][0].equalsIgnoreCase(strreasonindicator)&& flag2_calpers_r.equalsIgnoreCase("yes")){
        			if(dbValue2[0][0].equalsIgnoreCase("N")){
        				System.out.println("In ID Cards for CalPERS plan for New type enrollment");
        			logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for CalPERS plan with New type enrollment ");
        			flag2_calpers_r="no";
        			}else if(dbValue2[0][0].equalsIgnoreCase("C")){
        				System.out.println("In ID Cards for CalPERS plan for Change type enrollment");
        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for CalPERS plan with Change type enrollment ");
        				flag2_calpers_r="no";
        			}else if(dbValue2[0][0].equalsIgnoreCase("R")){
        				System.out.println("In ID Cards for CalPERS plan for Replacement type enrollment");
        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for CalPERS plan with Replacement type enrollment ");
        				flag2_calpers_r="no";
        			}else if(dbValue2[0][0].equalsIgnoreCase("D")){
        				System.out.println("In ID Cards for CalPERS plan for Duplicate type enrollment");
        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for CalPERS plan with Duplicate type enrollment ");
        				flag2_calpers_r="no";
        			}else{
        				System.out.println("subscriber is not present for CalPERS plan for ARVATO vendor");
        			}
    			
    			}
    						
			}
    			catch(Exception e)
    			{
    				System.out.println("query is returning null for calPERS");
    			}
				
				
			}
    	}
			
			//For validating FEHBP plans
    	
    	
			else if(vendorn.contains("ARVATO")&& flag1.equalsIgnoreCase("yes")){
				//Id card for FEHBP lob
	    		String query_lang_code = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
				.getQueryFromMappingSheet("language_code", sheetName);
				String SQLQuery = query_lang_code.replace("UniqueId", subscriberId);
				String query1_rsn_ind = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
				.getQueryFromMappingSheet("reason_indicator", sheetName);
				String SQLQuery1 = query1_rsn_ind.replace("UniqueId", subscriberId);
	    			try{
	        			dbValue1 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
	        			dbValue2 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery1);
	        			if (dbValue1[0][0].equalsIgnoreCase(strLanguageCode))
	        			{
	        				if(dbValue1[0][0].equalsIgnoreCase("EN")){
	        					System.out.println("In English ID Cards for FEHBP plan");
	        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for FEHBP plan ");
	        				}
	        				else if(dbValue1[0][0].equalsIgnoreCase("SP")){
	        					System.out.println("In Spanish ID Cards for FEHBP plan");
	        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received Spanish ID Cards for FEHBP plan ");
	        				}
	        			}	
	        			if(dbValue2[0][0].equalsIgnoreCase(strreasonindicator)){
	        			if(dbValue2[0][0].equalsIgnoreCase("N")){
	        				System.out.println("In ID Cards for FEHBP plan for New type enrollment");
	        			logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for FEHBP plan with New type enrollment ");
	        			flag2_fehbp="no";
	        			}else if(dbValue2[0][0].equalsIgnoreCase("C")){
	        				System.out.println("In ID Cards for FEHBP plan for Change type enrollment");
	        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for FEHBP plan with Change type enrollment ");
	        				flag2_fehbp="no";
	        			}else if(dbValue2[0][0].equalsIgnoreCase("R")){
	        				System.out.println("In ID Cards for FEHBP plan for Replacement type enrollment");
	        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for FEHBP plan with Replacement type enrollment ");
	        				flag2_fehbp="no";
	        			}else if(dbValue2[0][0].equalsIgnoreCase("D")){
	        				System.out.println("In ID Cards for FEHBP plan for Duplicate type enrollment");
	        				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for FEHBP plan with Duplicate type enrollment ");
	        				flag2_fehbp="no";
	        			}else{
	        				System.out.println("subscriber is not present for FEHBP plan for ARVATO vendor");
	        			}
        			}
    			}
    			catch(Exception e)
    			{
    				System.out.println("query is returning null");
    			}
			}
			//For validating HMO and ASO plans
			else{
				
				String query2 = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
    			.getQueryFromMappingSheet("HMO_format_id", sheetName);
				//System.out.println("sheet name is   "+sheetName);
				//System.out.println("query is "+query2);
				String query3 = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
    			.getQueryFromMappingSheet("ASO_format_id", sheetName);
				String query4=new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
    			.getQueryFromMappingSheet("Custom_format_id", sheetName);
				String SQLQuery2 = query2.replace("UniqueId1", subscriberId);
				String SQLQuery3 = query3.replace("UniqueId1", subscriberId);
				String SQLQuery4 = query4.replace("UniqueId1", subscriberId);
        		String[][]	dbValue1_hmo =  (String[][])new DBUtils().getTableArray("facets",SQLQuery2);
        			String[][] dbValue2_aso =  (String[][])new DBUtils().getTableArray("facets",SQLQuery3);
        			String[][] dbValue2_custom =  (String[][])new DBUtils().getTableArray("facets",SQLQuery4);
        			if(!(dbValue2_aso.length==0)){
        			//*****Id card for ASO lob********
        				if(flag_aso_l.equalsIgnoreCase("yes")|| flag_aso_r.equalsIgnoreCase("yes")){
        				System.out.println("id card lob is ASO");
        				String query_lang_code = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
            			.getQueryFromMappingSheet("language_code", sheetName);
            			String SQLQuery = query_lang_code.replace("UniqueId", subscriberId);
            			String query1_rsn_ind = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
            			.getQueryFromMappingSheet("reason_indicator", sheetName);
            			String SQLQuery1 = query1_rsn_ind.replace("UniqueId", subscriberId);
            			try{
                			dbValue1 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
                			dbValue2 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery1);
                			if (dbValue1[0][0].equalsIgnoreCase(strLanguageCode))
                			{
                				System.out.println("dbvalue is  inside "+dbValue1[0][0]);
                				System.out.println("strLanguageCode is inside "+strLanguageCode);
                				if(dbValue1[0][0].equalsIgnoreCase("EN") && flag_aso_l.equalsIgnoreCase("yes")){
                					System.out.println("In English ID Cards for ASO plans");
                				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for ASO plan ");
                				flag_aso_l="no";
                				}
                			if(dbValue2[0][0].equalsIgnoreCase(strreasonindicator)&& flag_aso_r.equalsIgnoreCase("yes")){
                    			if(dbValue2[0][0].equalsIgnoreCase("N")){
                    				System.out.println("In ID Cards for ASO plan for New type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for ASO plan with New type enrollment ");
                    			}else if(dbValue2[0][0].equalsIgnoreCase("C")){
                    				System.out.println("In ID Cards for ASO plan for Change type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for ASO plan with Change type enrollment ");
                    			}else if(dbValue2[0][0].equalsIgnoreCase("R")){
                    				System.out.println("In ID Cards for ASO plan for Replacement type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for ASO plan with Replacement type enrollment ");
                    			}	else if(dbValue2[0][0].equalsIgnoreCase("D")){
                    				System.out.println("In ID Cards for ASO plan for Duplicate type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for ASO plan with Duplicate type enrollment ");
                    			}else{
                    				System.out.println("subscriber is not present for ASO plan for ARVATO vendor");
                    				
                    			}
                    			flag_aso_r="no";	
                			}
            			}
			}
    			catch(Exception e)
    			{
    				System.out.println("query is returning null for ASO ");
    			}
			}
        			}
        			else if((!dbValue1_hmo.equals(null))&& dbValue1_hmo.length!=0 && (!flag_groupno_MId_large.equalsIgnoreCase("true"))){
        				//*****Id card for HMO lob********
        				if(flag_hmo_l.equalsIgnoreCase("yes")|| flag_hmo_r.equalsIgnoreCase("yes")){
        				System.out.println("id card lob is HMO");
        				String query_lang_code = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
            			.getQueryFromMappingSheet("language_code", sheetName);
            			String SQLQuery = query_lang_code.replace("UniqueId", subscriberId);
            			String query1_rsn_ind = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
            			.getQueryFromMappingSheet("reason_indicator", sheetName);
            		
            			String SQLQuery1 = query1_rsn_ind.replace("UniqueId", subscriberId);
            			try{
                			dbValue1 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
                			dbValue2 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery1);
                			if (dbValue1[0][0].equalsIgnoreCase(strLanguageCode)&& flag_hmo_l.equalsIgnoreCase("yes"))
                			{
                				if(dbValue1[0][0].equalsIgnoreCase("SP")){
                					System.out.println("In Spanish ID Cards for HMO plans");
                				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received Spanish ID Cards for HMO plan ");
                				
                				}else if(dbValue1[0][0].equalsIgnoreCase("EN")){
                					System.out.println("In English ID Cards for HMO plans");
                				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for HMO plan ");
                				}
                				flag_hmo_l="no";
                				}
                			if(dbValue2[0][0].equalsIgnoreCase(strreasonindicator) && flag_hmo_r.equalsIgnoreCase("yes")){
                    			if(dbValue2[0][0].equalsIgnoreCase("N")){
                    				System.out.println("In ID Cards for HMO plan for New type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for HMO plan with New type enrollment ");
                    			}else if(dbValue2[0][0].equalsIgnoreCase("C")){
                    				System.out.println("In ID Cards for HMO plan for Change type enrollment");
                    			}else if(dbValue2[0][0].equalsIgnoreCase("R")){
                    				System.out.println("In ID Cards for HMO plan for Replacement type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for HMO plan with Replacement type enrollment ");
                    			}	else if(dbValue2[0][0].equalsIgnoreCase("D")){
                    				System.out.println("In ID Cards for HMO plan for Duplicate type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for HMO plan with Duplicate type enrollment ");
                    			}else{
                    				System.out.println("subscriber is not present for HMO plan for ARVATO vendor");
                    				
                    			}
                    			flag_hmo_r="no";
                			}
                			if(flag_meia_sts.equals("yes")){
                			String query1_meia_sts = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
                			.getQueryFromMappingSheet("MEIA_STS", sheetName);
                			String SQLQuery_sts = query1_meia_sts.replace("UniqueId", subscriberId);
                			try{
                    			dbValue1 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery_sts);
                    			if(dbValue1[0][0].contains("03")){
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" is in awaiting processing status");
                    				System.out.println("Id Card request is in Awaiting Processing status");
                    				flag_meia_sts="no";	
                    			}
                			}
                    			catch(Exception e)
                    			{
                    				System.out.println("query is returning null for HMO MEIA_STS query");
                    			}
                			}			
            			}
    			catch(Exception e)
    			{
    				System.out.println("query is returning null for HMO ");
    			}
        				}
        			}
        			else if( dbValue2_custom.length!=0 &&(flag_custom_l.equalsIgnoreCase("yes")|| flag_custom_r.equalsIgnoreCase("yes") )){
        				//*****Id card for Custom lob********
        				System.out.println("id card lob is custom");
        				String query_lang_code = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
            			.getQueryFromMappingSheet("language_code", sheetName);
            			String SQLQuery = query_lang_code.replace("UniqueId", subscriberId);
            			String query1_rsn_ind = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
            			.getQueryFromMappingSheet("reason_indicator", sheetName);
            			String SQLQuery1 = query1_rsn_ind.replace("UniqueId", subscriberId);
            			try{
                			dbValue1 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
                			dbValue2 =  (String[][])new DBUtils().getTableArray("facets",SQLQuery1);
                			if (dbValue1[0][0].equalsIgnoreCase(strLanguageCode))
                			{
                				System.out.println("dbvalue is  inside "+dbValue1[0][0]);
                				System.out.println("strLanguageCode is inside "+strLanguageCode);
                				if(dbValue1[0][0].equalsIgnoreCase("EN") && flag_custom_l.equalsIgnoreCase("yes")){
                					System.out.println("In English ID Cards for custom plans");
                				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for Custom plan ");
                				}else if(dbValue1[0][0].equalsIgnoreCase("EN") && flag_custom_l.equalsIgnoreCase("yes")){
                					System.out.println("In English ID Cards for custom plans");
                				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received English ID Cards for Custom plan ");
                				}
                				flag_custom_l="no";
                				}
                			if(dbValue2[0][0].equalsIgnoreCase(strreasonindicator)&& flag_custom_r.equalsIgnoreCase("yes")){
                    			if(dbValue2[0][0].equalsIgnoreCase("N")){
                    				System.out.println("In ID Cards for Custom plan for New type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for Custom plan with New type enrollment ");
                    			}else if(dbValue2[0][0].equalsIgnoreCase("C")){
                    				System.out.println("In ID Cards for Custom plan for Change type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for Custom plan with Change type enrollment ");
                    			}else if(dbValue2[0][0].equalsIgnoreCase("R")){
                    				System.out.println("In ID Cards for Custom plan for Replacement type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for Custom plan with Replacement type enrollment ");
                    			}	else if(dbValue2[0][0].equalsIgnoreCase("D")){
                    				System.out.println("In ID Cards for Custom plan for Duplicate type enrollment");
                    				logger.log(LogStatus.INFO, "Subscriber ID "+subscriberId+" received ID Cards for Custom plan with Duplicate type enrollment ");
                    			}else{
                    				System.out.println("subscriber is not present for Custom plan for ARVATO vendor");
                    				
                    			}
                    			flag_custom_r="no";	
                			}
            			}
    			catch(Exception e)
    			{
    				System.out.println("query is returning null for Custom ");
    			}
			}
        			}
    	}	  		
    	dbValue = getElementValueFromDB(node.getNodeName().trim().toString(), subscriberId, sheetName, node);
		if(dbValue == null){
			//To compare XML value against database value
			validataXmlAndDbValues(node.getNodeName().trim().toString(),node.getTextContent(), "[Blank]");
		}
		else if(!dbValue.equalsIgnoreCase("TagNotConsiderForValidation")){
			//To compare XML value against database value
		System.out.println("element name is in above loop "+node.getNodeName());
			validataXmlAndDbValues(node.getNodeName().trim().toString(),node.getTextContent(), dbValue);
		}
}
    	
		//Validating phone_number_label all fields
	/*	if (elementName.trim().equalsIgnoreCase("phone_number_label")) {
			intPhoneNumberLabelIndex++;
			
			
			if(intPhoneNumberLabelIndex == 1){
				
				//To compare XML value against database value
				validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + "Member Services", node.getTextContent(), "Member Services");
			}
			else if(intPhoneNumberLabelIndex == 2){
				
				//To compare XML value against database value
				validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + "TTY (hearing impaired)", node.getTextContent(), "TTY (hearing impaired)");
			}
			else if(intPhoneNumberLabelIndex == 3){
				
				//To compare XML value against database value
				validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + "Pharmacy Help Desk", node.getTextContent(), "Pharmacy Help Desk");
			}
			else if(intPhoneNumberLabelIndex == 4){
				
				//To compare XML value against database value
				validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + "Behavioral Health", node.getTextContent(), "Behavioral Health");
			}
			
	/*	if (elementName.trim().equalsIgnoreCase("phone_number_data")) {
			index++;
			// System.out.println("index of parent:"+ index);

			if (index == 1) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetching(node,subscriberId,sheetName,"Member Services","Member Services");
			} else if (index == 2) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetching(node,subscriberId,sheetName,"TTY_Hearing_Impaired","TTY_Hearing_Impaired");
			} else if (index == 3) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetching(node,subscriberId,sheetName,"Pharmacy Help Desk","Pharmacy Help Desk");
			} else if (index == 4) {
				//Fetching and comparing XML and database values
				databaseAndXMLValuesFetching(node,subscriberId,sheetName,"Behavioral Health","Behavioral Health");
			}
		}*/
   	/**
	 * @param elemetName: To fetch the value from XML
	 * @param subscriberId: To replace in the query
	 * @param sheetName: Test data mapping sheet name for queries
	 * @param node: Node name
	 * @return: String: Database value for the respective query 
	 * @throws SQLException: To throw the ParseException exception
	 * @throws ParseException: To throw the ParseException exception
	 */
	public String getElementValueFromDB(String elemetName, String subscriberId,
			String sheetName, Element node) throws SQLException, ParseException {
		//Fetching query for the respective element name
		String query = new ExcelUtilsExtended("src/test/resources/BscaBSCLobsTest.xlsx", sheetName)
		.getQueryFromMappingSheet(elemetName, sheetName);
		
		if(query == null){
			return "TagNotConsiderForValidation";
		}
		String[][] dbValue = null;
		//Checking for the NOT null value from test data mapping sheet
		if (query != null) {
				if(elemetName.trim().equalsIgnoreCase("card_classification")){
				String query_grp_id = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", sheetName)
    			.getQueryFromMappingSheet("group_number", sheetName);
			
    			String SQLQuery = query_grp_id.replace("UniqueId", subscriberId);
    			try{
        			dbValue =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
        			String group_id=dbValue[0][0];
    				String SQLQuery1 = query.replace("UniqueId", subscriberId).replace("GroupId",group_id);
    				dbValue = (String[][]) new DBUtils().getTableArray("facets",SQLQuery1);
        			
    			}
    			catch(Exception e)
    			{
    				System.out.println("query is returning null for group id");
    			}
				
			}
			else{
				String SQLQuery = query.replace("UniqueId", subscriberId);
				System.out.println("current query isss  "+SQLQuery);
				dbValue = (String[][]) new DBUtils().getTableArray("facets",SQLQuery);
			}
			
		}
		if (dbValue == null) {
			return null;
		} 
		else if(dbValue.length == 0) {
			return null;
		}
		//Returning 2D array 0,0 index value
		else {
			return dbValue[0][0];
		}
	}

	/**
	 *  To retrieve child nodes of node
	 * @param nNode: Main node name
	 * @param sheetName: Mapping sheet name
	 * @param subscriberId: To retrieve unique specific section
	 * @param tagname: Tag Name
	 * @throws Exception 
	 */
	private void getChildElements(Element nNode, String sheetName, String subscriberId, String tagname) throws Exception {
		NodeList children = nNode.getChildNodes();//To get child nodes of node

		if (children.toString().trim().contains("provider_address")) {
			return;
		}
		// loop through all child nodes
		for (int i = 0; i < children.getLength(); i++) { 
			Node node = (Node) children.item(i);
			//Checking for the element node
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				if (hasChildElements((Element) node)) {// checking for child nodes
					getElementAtttributes((Element) node, sheetName, subscriberId);// getting attributes of elements
					getChildElements((Element) node, sheetName, subscriberId, tagname);// getting child elements
					{
						if (node.hasAttributes()) //Checking for the node attributes

						{
							NamedNodeMap attributesList = node.getAttributes();
							for (int attribute_Number = 0; attribute_Number < attributesList
									.getLength(); attribute_Number++) {
							}
						}
					}
				}

				else {
					
					getValuesOfElement((Element) node, sheetName, subscriberId);
				}

			}

		}
	}

	/**
	 * To check the child nodes of the node
	 * @param element: Node name
	 * @return: Boolean value True or False
	 */
	private boolean hasChildElements(Element element) {
		//To get child nodes for the given node
		NodeList children = element.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			// looping through the nodes and checking for element node
			if (children.item(i).getNodeType() == Node.ELEMENT_NODE)
				return true;
		}
		return false;
	}

	/**
	 * To compare XML values against database values
	 * @param elementName: Tag name for reporting
	 * @param xmlValue:  XML value for comparison
	 * @param dbValue: Database value for comparison
	 */
	public void validataXmlAndDbValues(String elementName, String xmlValue,	String dbValue) {
		
		String status = "Fail";
		
		//Replacing "," with "" in XML value when element name as city_Send_Address
		if (elementName.contains("city_Send_Address")) {
			xmlValue = xmlValue.toString().replace(",", "");

		}
		else if (elementName.contains("subscriber_id")) {
			
			sbid=dbValue;
		}
		else if (elementName.contains("contact_phone_number")) {
			xmlValue = xmlValue.toString().replace("(", "").replace(")","").replace(" ", "").replace("-","");

		}
		else if (elementName.contains("address_1_Send_Address")) {
			xmlValue = xmlValue.toString().replace(" ,", "");

		}
			
		//Replacing "-" with "" in XML value when element name as zip_Send_Address
		else if (elementName.contains("zip_Send_Address")) {
			//xmlValue = xmlValue.toString().replace("-", "");

		} 
		//Replacing "." with "" in XML value when element name as address_2_Send_Address
		else if (elementName.contains("address_2_Send_Address")) {
			xmlValue = xmlValue.toString().replace(".", "").replace(",", "");
			dbValue = dbValue.toString().replace(".", "").replace(",", "");
		}
		/*else if (elementName.contains("instruction_texts")) {
			
			dbValue = dbValue.toString().replace("&\\gt;", ">").replace("&\\lt;", "<").replace("&\\apos;", "'");
			
		}*/
		else if (elementName.contains("zip_return_address")) {
			xmlValue = xmlValue.toString().substring(0, 5);
		//	dbValue = dbValue.toString().replace(".", "").replace(",", "");
		}
		
		else if (elementName.contains("provider_name")) {
			index_p_name++;
			String query = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", "Mappingsheet_IDcard")
			.getQueryFromMappingSheet("provider_name", "Mappingsheet_IDcard");
		String[][] dbvalue_provider_name;
		System.out.println("sub id is "+sbid);
			String SQLQuery = query.replace("UniqueId", sbid);
			System.out.println("query isss in loop  "+SQLQuery);
			try{
				dbvalue_provider_name=  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
    		
			if(index_p_name==1)
			{
				dbValue=dbvalue_provider_name[0][0];
			}
			else if(index_p_name==2){
				dbValue=dbvalue_provider_name[1][0];
			}
			if(index_p_name==3){
				dbValue=dbvalue_provider_name[2][0];
			}
			}
			catch(Exception e)
			{
				System.out.println("query is returning null");
			}
		//	xmlValue = xmlValue.toString().substring(0, 5);
		//	dbValue = dbValue.toString().replace(".", "").replace(",", "");
		}
		else if (elementName.contains("be_name")) {
			index_bename++;
			String query = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", "Mappingsheet_IDcard")
			.getQueryFromMappingSheet("be_name", "Mappingsheet_IDcard");
		String[][] dbvalue_provider_name;
		System.out.println("sub id is "+sbid);
			String SQLQuery = query.replace("UniqueId", sbid);
			System.out.println("query isss in loop  "+SQLQuery);
			try{
				dbvalue_provider_name=  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
    		
			if(index_bename==1)
			{
				dbValue=dbvalue_provider_name[0][0];
			}
			else if(index_bename==2){
				dbValue=dbvalue_provider_name[1][0];
			}
			if(index_bename==3){
				dbValue=dbvalue_provider_name[2][0];
			}
			}
			catch(Exception e)
			{
				System.out.println("query is returning null in be name");
			}
		}
		else if (elementName.contains("provider_phone_number")) {
			index_phn_no++;
			String query = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", "Mappingsheet_IDcard")
			.getQueryFromMappingSheet("provider_phone_number", "Mappingsheet_IDcard");
		String[][] dbvalue_provider_name;
		System.out.println("sub id is "+sbid);
			String SQLQuery = query.replace("UniqueId", sbid);
			System.out.println("query isss in loop  "+SQLQuery);
			try{
				dbvalue_provider_name=  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
    		
			if(index_phn_no==1)
			{
				dbValue=dbvalue_provider_name[0][0];
			}
			else if(index_phn_no==2){
				dbValue=dbvalue_provider_name[1][0];
			}
			if(index_phn_no==3){
				dbValue=dbvalue_provider_name[2][0];
			}
			}
			catch(Exception e)
			{
				System.out.println("query is returning null in phone no");
			}
		}
		else if (elementName.contains("pcp_effective_date")) {
			index_pcp_date++;
			String query = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", "Mappingsheet_IDcard")
			.getQueryFromMappingSheet("pcp_effective_date", "Mappingsheet_IDcard");
		String[][] dbvalue_provider_name;
		System.out.println("sub id is "+sbid);
			String SQLQuery = query.replace("UniqueId", sbid);
			System.out.println("query isss in loop  "+SQLQuery);
			try{
				dbvalue_provider_name=  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
    		
			if(index_pcp_date==1)
			{
				dbValue=dbvalue_provider_name[0][0];
			}
			else if(index_pcp_date==2){
				dbValue=dbvalue_provider_name[1][0];
			}
			if(index_pcp_date==3){
				dbValue=dbvalue_provider_name[2][0];
			}
			}
			catch(Exception e)
			{
				System.out.println("query is returning null in be date");
			}
		}
		
		//Comparing both XML value and database value using soft assertion 
		softAssertion.assertEquals(xmlValue.replaceAll("\\s+", "").toUpperCase(),	dbValue.replaceAll("\\s+", "").toUpperCase(),
				"xmlValue:" + xmlValue.replaceAll("\\s+", "") + "| dbValue:" + dbValue.replaceAll("\\s+", ""));
		
		if (xmlValue.replaceAll("\\s+", "").equalsIgnoreCase(dbValue.replaceAll("\\s+", ""))) {

			status = "Pass";
			logger.log(LogStatus.PASS, " Element Name: " + elementName + "|---------- Actual (XML file) value: " + xmlValue
					+ "----------Expected (Database) value: " + dbValue + "|----------Status: " + status);
		}
		// Failure logger for showing the results in extent report file
		else {
			logger.log(LogStatus.FAIL, " Element Name: " + elementName	+ "|---------- Actual (XML file) value: " + xmlValue
					+ "----------Expected (Database) value: " + dbValue + "|----------Status: " + status);
			System.out.println("Failed Element Name: " + elementName + "|---------- xmlValue: " + xmlValue.replaceAll("\\s+", "")
					+ "----------dbValue: " + dbValue.replaceAll("\\s+", ""));
		}
	}

	
	/**
	 * To retrieve all file names from folder
	 * @param strFolderPath: Folder path  
	 * @return: returning files names in list
	 */
	public List<String> getFileNamesFromFolder(String strFolderPath)
	{
		List<String> fileNames = new ArrayList<String>();
		File folder = new File(strFolderPath);
		File[] files = folder.listFiles();//fetching no list of files from folder
		//Looping through all files in a folder
		for(int fileIndex = 0;fileIndex<files.length;fileIndex++) {
			//Checking for the directory
			if(files[fileIndex].isDirectory()){
				continue;
			}
			
			String fileName = files[fileIndex].getName();//fetching file name
			fileNames.add(fileName);
			
			//System.out.println("The file name is "+fileName);
			
		}
		return fileNames;
	}
	
	/**
	 * To fetch XML and database values and compare the same
	 * @param node: Node name
	 * @param subscriberId: Subscriber id to report in the XML
	 * @param sheetName: Mapping sheet name
	 * @param strFieldName: Field name for comparison
	 * @param strMappingFieldName: Field name in the mapping sheet
	 * @throws Exception: Throwing the exception
	 */
	private void databaseAndXMLValuesFetching(Element node,String subscriberId, String sheetName, String strFieldName, String strMappingFieldName) throws Exception{
			System.out.println("node element is "+node.getNodeName().trim().toString());
			System.out.println("strMappingFieldName is "+strMappingFieldName);
			System.out.println("strfield name is "+strFieldName);
			System.out.println("node is "+node);
			//Retrieving and Storing database value into a dbValue variable
			dbValue = getElementValueFromDB(node.getNodeName().trim().toString() + "_" + strMappingFieldName, subscriberId, sheetName, node);
			
			//Checking for the database value when it is NULL
			if(dbValue == null){
				//To compare XML value against database value
				validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + strFieldName, node.getTextContent(), "[Blank]");
			}
			//Checking for the database value when field is considered for validation
			else if(!dbValue.equalsIgnoreCase("TagNotConsiderForValidation")){
				//To compare XML value against database value
				validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + strFieldName, node.getTextContent(),	dbValue);
				
			}
	}
	
	/**
	 * @param node: Node name
	 * @param subscriberId: Unique id to display in the report
	 * @param sheetName: Mapping sheet name
	 * @param strFieldName: XML field name for comparison
	 * @param strXPath: XPath of the node
	 * @throws Exception: To capture the exception
	 */
	private void databaseAndXMLValuesFetchingWithXPath(Element node,String subscriberId, String sheetName, String strFieldName, String strXPath) throws Exception{
		
		//Retrieving and Storing database value into a dbValue variable
		dbValue = getElementValueFromDB(strXPath, subscriberId, sheetName, node);
		//Checking for the database value when it is NULL
		if(dbValue == null){
			//To compare XML value against database value
			validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + strFieldName, node.getTextContent(), "[Blank]");
		}
		//Checking for the database value when field is considered for validation
		else if(!dbValue.equalsIgnoreCase("TagNotConsiderForValidation")){
			//To compare XML value against database value
			validataXmlAndDbValues(node.getNodeName().trim().toString()	+ "_" + strFieldName, node.getTextContent(),	dbValue);
			
		}
}
	
	/**
	 *To get the XPath for the given node
	 * @param node: Node name
	 * @return: To return the XPath
	 */
	private String getXPath(Node node) {
		Node parent = node.getParentNode();
		if (parent == null) {
			return "";
		}
		//For returning XPath
		return getXPath(parent) + "/" + node.getNodeName();

	}

	

}
