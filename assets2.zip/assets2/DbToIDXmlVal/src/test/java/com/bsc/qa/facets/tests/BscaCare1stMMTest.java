package com.bsc.qa.facets.tests;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.text.StrSubstitutor;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.bsc.qa.facets.utility.ExcelUtilsExtended;
import com.bsc.qa.facets.utility.XMLParse;
import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.facets.tests.BscaBSCLobsTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable {
	
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	private XMLParse xMLParse = null;
	
	public BscaCare1stMMTest(String inputFileName) {
		this.inputFileName = inputFileName;
	}
	
	private void testdbvalues_IDcard(String strSubscriberList) throws IOException{
		
			BufferedReader bufferedReader = null;
			String line=null;
			System.out.println("$$$$$$ "+strSubscriberList);
			String[] subscriber_list=strSubscriberList.split("\\|");
			System.out.println("---- "+subscriber_list[1]+"------");
			File cinn_file=new File(System.getenv("CIN_COMPLETE_FILE_PATH_IDcards"));
			//String testFlatFileCompletePath="//bsc/it/VDI_Home_SAC/rbhima01/Desktop/CINN_FILE/file2.txt";
			FileReader fileReader =  new FileReader(cinn_file);
			bufferedReader = new BufferedReader(fileReader);
			String[] cinn_file_content=null;
			
			// Reading each line in the file 
			reportInit("XmlToDbValidation_Subscriber", "SubscriberID in ID card XML validation");
			logger.log(LogStatus.INFO, "Starting test testXMLToDBValidation_IDcard");
			logger.log(LogStatus.INFO, "cinn file path is "+System.getenv("CIN_COMPLETE_FILE_PATH_IDcards"));
					//\\ainf423s\\QES_Automation\\BSCPHP\\VALIDATIONS\\ID_card_CIN_capture\\CINs.csv"
					while((line = bufferedReader.readLine())!=null) {
	        	//Checking for the CINN Number
	        	 cinn_file_content=line.split("-");
	        	System.out.println("cinn code is "+cinn_file_content[1]);
	        	String sheetName="Mappingsheet_IDcard";
	        	String[][] dbValue=null;
	        	//String flag="No";
	        	if(cinn_file_content[1].equalsIgnoreCase("N")||cinn_file_content[1].equalsIgnoreCase("C"))
	        	{
	        				String flag="No";
		    	        	
			        		for(int j=1;j<subscriber_list.length;j++){
		        			
		        			if (cinn_file_content[2].equals(subscriber_list[j])){
		        				flag="Yes";
		        				
		        				break;
		        			}
		        			}
		        	
		        	
		        		if(flag.equalsIgnoreCase("Yes"))
		        		{
		        			System.out.println("subscriber present "+cinn_file_content[2]);
		        			logger.log(LogStatus.PASS, "Subscriber ID "+cinn_file_content[2]+" is present in ID Card XML -------Status:Pass");	
		        		}
		        		else{
		        		
		        					System.out.println("subscriber not present "+cinn_file_content[2]);	
		        			logger.log(LogStatus.FAIL, "Subscriber ID "+cinn_file_content[2]+" is not present in ID Card XML -------Status:Fail");
		        			String query = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", sheetName)
		        			.getQueryFromMappingSheet("cdm_error_query", sheetName);
	        			
		        			String SQLQuery = query.replace("UniqueId", cinn_file_content[2]);
		        			try{
			        			dbValue =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
			        			
			        			System.out.println("***************** "+dbValue[0][0]+"*********** "+dbValue[0][1]);
			        			logger.log(LogStatus.INFO, "Subscriber ID is not present in the xml because of : "+dbValue[0][1]);
			        			}
			        			catch(Exception e)
			        			{
			        				System.out.println("query is returning null");
			        			}
			        	}
	        				
	        	} 
	        	if(cinn_file_content[1].equalsIgnoreCase("X")){
	        		String flag1="No";
	        	
	        		for(int j=1;j<subscriber_list.length;j++){
        			
        			if (cinn_file_content[2].equals(subscriber_list[j])){
        				flag1="Yes";
        				
        				break;
        			}
        			}
        
        	
        		if(flag1.equalsIgnoreCase("Yes"))
        		{
        			System.out.println("subscriber present "+cinn_file_content[2]);
        			logger.log(LogStatus.FAIL, "Subscriber ID "+cinn_file_content[2]+" is present in ID Card XML in not loaded scenario -------Status:Fail");	
        		}
        		else{
        			
        					System.out.println("subscriber not present "+cinn_file_content[2]);	
        			logger.log(LogStatus.PASS, "Subscriber ID "+cinn_file_content[2]+" is not present in ID Card XML in not loaded scenario -------Status:Pass");
        			
	        	}
	        	}		
	        }
	        
	        if(bufferedReader != null)
	    		bufferedReader.close();
	        BufferedWriter filewriter=new BufferedWriter(new FileWriter(cinn_file,false));
	        filewriter.flush();
	        filewriter.close();
	    	}
	//To validate XML fields with database values for ID Cards
	@Test()
	
	public void testXMLToDBValidation_IDcard() {

		try {
			xMLParse = new XMLParse();
			//For fetching test data from test data excel file 
			Map<String, String> data = null;
			try {
				data = getData("testXMLToDBValidation_IDcard");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("in catch");
				e.printStackTrace();
			}
			//to retrieve parent tag from test data sheet
			String xmlTag = data.get("ELEMENT_TAG_NAME").toString().trim();
			//to retrieve file path from environment variable
			//String xmlFilePath = inputFileName;
			File dirfolder=new File(System.getenv("INPUT_FILE_FULLPATH"));
		//	System.out.println("path for BSC LOBs is out "+dirfolder.getPath());
		//	if (dirfolder.getPath().contains("QES_Automation\\BSC\\VALIDATIONS"))
			/*if (dirfolder.getPath().contains("bsc_lob_trial_files"))
			{*/
		//		System.out.println("path for BSC LOBs is "+dirfolder.getPath());
		//		//	BscaBSCLobsTest bscaBSCLobstest=new BscaBSCLobsTest(dirfolder);
					//bscaBSCLobstest.testXMLToDBValidationBSC_IDcard();

			/*}
		else if (dirfolder.getPath().contains("QES_Automation\\BSCPHP\\VALIDATIONS"))
			{*/
			//	File[] xmlfiles=dirfolder.listFiles();
			
			//for(File file:xmlfiles){
				
			//	System.out.println("file path for php LOBs is "+file.getPath());
				String xmlFilePath =inputFileName;	
			//For the initial XML setup
			xMLParse.xmlSetup(xmlFilePath);
			//assigning mapping sheet name in test data sheet to local variable
			String mappingSheetName = "Mappingsheet_IDcard";
			//To fetch all subscribers from XML, multiple subscriber data will be retrieved with pipe (|) delimiter
			String strSubscriberList = xMLParse.UniqueDetailsExtraction(xmlTag,"subscriber_id");
			System.out.println(strSubscriberList);
			//testdbvalues_IDcard(strSubscriberList);
			//Verifying valid subscribers details from XML
			if(!strSubscriberList.equalsIgnoreCase("")) {
				
				String [] strSubscriberArray = strSubscriberList.split("\\|");
				//Iterating for a ll subscribers to validate XML versus Database values
				for(int intICounter = 1; intICounter< strSubscriberArray.length ; intICounter++){
					//To skip the first report which is initialized in the run method
					if(intICounter > 1 )
					{
						
						//To get the report for each subscriber in the XML
						//Parameters: to display report header in the HTML						
						reportInit("XmlToDbValidation_Subscriber", "testXMLToDBValidation_IDcard,Subscriber ID:" + strSubscriberArray[intICounter]);
						logger.log(LogStatus.INFO, "Starting test testXMLToDBValidation_IDcard");
						
					}
					//To log the XML file path in HTML report
					logger.log(LogStatus.INFO, "XML file path: " + xmlFilePath);
					//To log the subscriber details in HTML report
					logger.log(LogStatus.INFO, "Validating Subscriber ID: " + strSubscriberArray[intICounter]);
					System.out.println("Validating Subscriber ID: " + strSubscriberArray[intICounter]);
					//validating specific subscribers data, this is the main method for validating ID Cards
					xMLParse.nodeExtraction(xmlTag, mappingSheetName, strSubscriberArray[intICounter], softAssert);
				}
			}
			
			//To report the statement when file does not have subscribers
			else {
				logger.log(LogStatus.FAIL, "Please provide valid file name and inputs to fetch subscriber data") ;
			}
			testdbvalues_IDcard(strSubscriberList);

		//} 
		//}
		}
		catch (Exception e)	{
			System.out.println("Test script Failed due to Exception.....!!");
			logger.log(LogStatus.FAIL, "Test script Failed due to Exception.....!!" + e.getMessage() );
			e.printStackTrace();
		}finally{
			softAssert.assertAll();	//<== absolutely must be here
		}
		
	}

	/**
	 * //To run test method, this method will initiate the HTML report
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		//To execute test method multiple times
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}

	/**
	 * DataProvider for returning the specific test data based on test method
	 * name
	 * 
	 * @param String: Method name
	 * @return
	 */

	private Map<String,String> getData(String method) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		//assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";
		System.out.println("xls path is "+xlsPath);
		//Fetching data from test data excel file based on method name
		dataMap = ExcelUtils.getTestMethodData(xlsPath, method);
		
		return dataMap;
	}

}
