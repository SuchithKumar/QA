/**
 * 
 */
package com.bsc.qa.facets.tests;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.IntConsumer;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.utility.ExcelUtilsExtended;
import com.bsc.qa.facets.utility.XMLParseBSCLobs;
import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.relevantcodes.extentreports.LogStatus;

/**
 * @author ngami01
 *
 */
public class BscaBSCLobsTest extends BaseTest implements IHookable {

	private String inputFileName = null;
	private XMLParseBSCLobs xMLParse = null;
	private SoftAssert softAssert = null;
	public BscaBSCLobsTest(String inputFileName) {
		this.inputFileName=inputFileName;
		// TODO Auto-generated constructor stub
	}
	private void testdbvalues_IDcard(String strSubscriberList) throws IOException{
		
		BufferedReader bufferedReader = null;
		String line=null;
		System.out.println("$$$$$$ "+strSubscriberList);
		String[] subscriber_list=strSubscriberList.split("\\|");
		System.out.println("---- "+subscriber_list[1]+"------");
		File cinn_file=new File(System.getenv("CIN_COMPLETE_FILE_PATH_IDcards"));
		//String testFlatFileCompletePath="//bsc/it/VDI_Home_SAC/rbhima01/Desktop/CINN_FILE/file2.txt";
		FileReader fileReader =  new FileReader(cinn_file);
		bufferedReader = new BufferedReader(fileReader);
		String[] cinn_file_content=null;
		
		// Reading each line in the file 
		reportInit("XmlToDbValidation_Subscriber", "SubscriberID in ID card XML validation");
		logger.log(LogStatus.INFO, "Starting test testXMLToDBValidation_IDcard");
		logger.log(LogStatus.INFO, "cinn file path is "+System.getenv("CIN_COMPLETE_FILE_PATH_IDcards"));
				//\\ainf423s\\QES_Automation\\BSCPHP\\VALIDATIONS\\ID_card_CIN_capture\\CINs.csv"
				while((line = bufferedReader.readLine())!=null) {
        	//Checking for the CINN Number
        	 cinn_file_content=line.split("-");
        	System.out.println("cinn code is "+cinn_file_content[1]);
        	String sheetName="Mappingsheet_IDcard";
        	String[][] dbValue=null;
        	//String flag="No";
        	if(cinn_file_content[1].equalsIgnoreCase("N")||cinn_file_content[1].equalsIgnoreCase("C"))
        	{
        				String flag="No";
	    	        	
		        		for(int j=1;j<subscriber_list.length;j++){
	        			
	        			if (cinn_file_content[2].equals(subscriber_list[j])){
	        				flag="Yes";
	        				
	        				break;
	        			}
	        			}
	        	
	        	
	        		if(flag.equalsIgnoreCase("Yes"))
	        		{
	        			System.out.println("subscriber present "+cinn_file_content[2]);
	        			logger.log(LogStatus.PASS, "Subscriber ID "+cinn_file_content[2]+" is present in ID Card XML -------Status:Pass");	
	        		}
	        		else{
	        		
	        					System.out.println("subscriber not present "+cinn_file_content[2]);	
	        			logger.log(LogStatus.FAIL, "Subscriber ID "+cinn_file_content[2]+" is not present in ID Card XML -------Status:Fail");
	        			/*String query = new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", sheetName)
	        			.getQueryFromMappingSheet("cdm_error_query", sheetName);
        			
	        			String SQLQuery = query.replace("UniqueId", cinn_file_content[2]);
	        			try{
		        			dbValue =  (String[][])new DBUtils().getTableArray("facets",SQLQuery);
		        			
		        			System.out.println("***************** "+dbValue[0][0]+"*********** "+dbValue[0][1]);
		        			}
		        			catch(Exception e)
		        			{
		        				System.out.println("query is returning null");
		        			}
		        	}*/
	        		}	
        	} 
        	if(cinn_file_content[1].equalsIgnoreCase("X")){
        		String flag1="No";
        	
        		for(int j=1;j<subscriber_list.length;j++){
    			
    			if (cinn_file_content[2].equals(subscriber_list[j])){
    				flag1="Yes";
    				
    				break;
    			}
    			}
    
    	
    		if(flag1.equalsIgnoreCase("Yes"))
    		{
    			System.out.println("subscriber present "+cinn_file_content[2]);
    			//logger.
    			logger.log(LogStatus.FAIL, "Subscriber ID "+cinn_file_content[2]+" is present in ID Card XML in not loaded scenario -------Status:Fail");	
    		}
    		else{
    			
    					System.out.println("subscriber not present "+cinn_file_content[2]);	
    			logger.log(LogStatus.PASS, "Subscriber ID "+cinn_file_content[2]+" is not present in ID Card XML in not loaded scenario -------Status:Pass");
    			
        	}
        	}		
        }
        
        if(bufferedReader != null)
    		bufferedReader.close();
        BufferedWriter filewriter=new BufferedWriter(new FileWriter(cinn_file,false));
        filewriter.flush();
        filewriter.close();
    	}

	/**
	 * @param args
	 */
	@Test void testXMLToDBValidationBSC_IDcard() {

			try {
				xMLParse = new XMLParseBSCLobs();
				//For fetching test data from test data excel file 
				Map<String, String> data = null;
				Map<String, String> data1 = null;
				try {
					data = getData("testXMLToDBValidation_IDcard");
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println("in catch");
					e.printStackTrace();
				}
				//to retrieve parent tag from test data sheet
				String xmlTag = data.get("ELEMENT_TAG_NAME").toString().trim();
			
				//to retrieve file path from environment variable
				String xmlFilePath = inputFileName;
				xMLParse.xmlSetup(xmlFilePath);
				//assigning mapping sheet name in test data sheet to local variable
				String mappingSheetName = "Mappingsheet_IDcard";
				//To fetch all subscribers from XML, multiple subscriber data will be retrieved with pipe (|) delimiter
			
				
				String strSubscriberList = xMLParse.UniqueDetailsExtraction(xmlTag,"subscriber_id");
				System.out.println(strSubscriberList);
				//testdbvalues_IDcard(strSubscriberList);
				//Verifying valid subscribers details from XML
				if(!strSubscriberList.equalsIgnoreCase("")) {
					System.out.println("in sub listtt");
					String [] strSubscriberArray = strSubscriberList.split("\\|");
					
					//Iterating for a ll subscribers to validate XML versus Database values
					System.out.println("length is "+strSubscriberArray.length);
					System.out.println("sublist"
							+ ""+strSubscriberArray[0]+"*******");
					System.out.println("sublist 1 "+strSubscriberArray[1]);
					System.out.println("sublist 2 "+strSubscriberArray[2]);
					System.out.println("sublist 3 "+strSubscriberArray[3]);
					for(int intICounter = 1; intICounter< strSubscriberArray.length ; intICounter++){
						//To skip the first report which is initialized in the run method
						if(intICounter > 0 )
						{
							System.out.println("********* "+strSubscriberArray[intICounter]);
							//To get the report for each subscriber in the XML
							//Parameters: to display report header in the HTML						
							reportInit("BSC-ID card to Facets ","("+System.getenv("ENVNAME")+") validation - "+" Subscriber ID:" + strSubscriberArray[intICounter]);
							logger.log(LogStatus.INFO, "Starting test testXMLToDBValidation_IDcard");
							
						}
						//To log the XML file path in HTML report
						logger.log(LogStatus.INFO, "XML file path: " + xmlFilePath);
						//To log the subscriber details in HTML report
						logger.log(LogStatus.INFO, "Validating Subscriber ID: " + strSubscriberArray[intICounter]);
						System.out.println("Validating Subscriber ID: " + strSubscriberArray[intICounter]);
						//validating specific subscribers data, this is the main method for validating ID Cards
						xMLParse.nodeExtraction(xmlTag, mappingSheetName, strSubscriberArray[intICounter], softAssert);
					}
				}
				
				//To report the statement when file does not have subscribers
				else {
					logger.log(LogStatus.FAIL, "Please provide valid file name and inputs to fetch subscriber data") ;
				}
				testdbvalues_IDcard(strSubscriberList);
		//	} 
			}
			catch (Exception e)	{
				System.out.println("Test script Failed due to Exception.....!!");
				logger.log(LogStatus.FAIL, "Test script Failed due to Exception.....!!" + e.getMessage() );
				e.printStackTrace();
			}finally{
				softAssert.assertAll();	//<== absolutely must be here
			}
		}
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
	//	reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		//To execute test method multiple times
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}
	private Map<String,String> getData(String method) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		//assigning test data excel file path to a local variable
	//	String xlsPath = "src/test/resources/"
	//			+ this.getClass().getSimpleName() + ".xlsx";
		//Fetching data from test data excel file based on method name
	//	System.out.println("path is "+xlsPath);
		String xlsPath1 = "src/test/resources/"
				+ "BscaBSCLobsTest" + ".xlsx";
		
		
		dataMap = ExcelUtils.getTestMethodData(xlsPath1, method);
		
		return dataMap;
	}
}
