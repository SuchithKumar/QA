package com.bsc.qa.facets.afa.pojo;

public class ErrorStatus {

	private  String result;
	private String comments;
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
	
}
