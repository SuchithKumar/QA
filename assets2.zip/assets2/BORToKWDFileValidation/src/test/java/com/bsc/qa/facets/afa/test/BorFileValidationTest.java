package com.bsc.qa.facets.afa.test;

import static j2html.TagCreator.td;
import static j2html.TagCreator.tr;
import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.record.BottomMarginRecord;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.bqsa.AutomationStringUtilities;
import com.bsc.qa.facets.afa.dao.DatabaseUtil;
import com.bsc.qa.facets.afa.pojo.BORFile;
import com.bsc.qa.facets.afa.pojo.Connection;
import com.bsc.qa.facets.afa.pojo.DatabaseBOR;
import com.bsc.qa.facets.afa.pojo.ErrorStatus;
import com.bsc.qa.facets.afa.pojo.KeywordDB;
import com.bsc.qa.facets.afa.pojo.KeywordFile;
import com.bsc.qa.facets.afa.utility.BaseTest;
import com.bsc.qa.facets.afa.utility.ExcelUtil;
import com.bsc.qa.facets.afa.utility.HibernateUtil;
import com.bsc.qa.facets.ffp.reader.FileReader;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BorFileValidationTest extends BaseTest implements IHookable {
	
	Connection conn = new Connection();
	SessionFactory factory;
	public static Session session;//=null;
	List<BORFile> borFileList, commonClaimIdList;
	Map<String, DatabaseBOR> borDBMap;
	List<KeywordDB> keywordDBList;
	List<KeywordFile> keywordFileList, sortedKeywordClaimIdList;
	public static Map<String, ErrorStatus> testResults = new HashMap<String, ErrorStatus>();
	public static String keywordFilePath = String.valueOf(System.getenv("INPUT_KWD_PATH"))+"/";
	public static String borFilePath = String.valueOf(System.getenv("INPUT_BOR_PATH"))+"/";
	private String bor_filename;
	private String keyword_filename;
	Logger logger1 = LoggerFactory.getLogger(BorFileValidationTest.class);

	@BeforeSuite
	public void getConnection() {
		logger1.info("Starting test execution...");
		logger1.info(keywordFilePath+" keyword  path");
		logger1.info(borFilePath+" BOR Path");
		
		String oracleServer = System.getenv("FACETS_SERVER");
		String oraclePort = System.getenv("FACETS_PORT");
		String oracleDB = System.getenv("FACETS_DB");
		String oracleUser = System.getenv("FACETS_USER");
		String oraclePassword = System.getenv("FACETS_PASSWORD") ; 
		String oracleUrl = "jdbc:oracle:thin:@" + oracleServer + ":" + oraclePort + ":" + oracleDB ;
		
//		borFilePath  = "\\\\ainf423s\\QES_Automation\\opstest\\PDR\\INTERMEDIATE\\BOR\\";
//		keywordFilePath = "\\\\ainf423s\\QES_Automation\\opstest\\PDR\\INTERMEDIATE\\KWD\\";

		
		try {
			bor_filename =borFilePath  + FileReader.getMatchingAndLatestFile(borFilePath, "FACETS_PCT_AFAGL.#*.txt").getName();//
			logger1.info(bor_filename);
		} catch (Exception e1) {
			if(e1.getMessage().contains("No files matching")){
				logger1.error(e1.getMessage());
			}
			logger1.error("Unable to find the Latest BOR File from the given env variable INPUT_BOR_PATH"
					+ borFilePath);
			logger1.info("Ending test execution...");
			if (session != null) {
				logger1.info("Closing DB Connection...");
				session.close();
				logger1.info("Succesfully closed DB connection!");
			}
			logger1.info("Test execution ended!");
			System.exit(0);
		}
		logger1.info("Working with BOR File - "+bor_filename);
		try {
			keyword_filename =keywordFilePath + FileReader.getMatchingAndLatestFile(keywordFilePath, "argus_afa*.txt").getName();
		} catch (Exception e1) {
			if(e1.getMessage().contains("No files matching")){
				logger1.error(e1.getMessage());
			}
			logger1.error("Unable to find the Latest keyword File from the given env variable INPUT_KWD_PATH"
					+ keywordFilePath);
			logger1.info("Ending test execution...");
			if (session != null) {
				logger1.info("Closing DB Connection...");
				session.close();
				logger1.info("Succesfully closed DB connection!");
			}
			logger1.info("Test execution ended!");
			System.exit(0);
		}
		logger1.info("Working with Keyword File --- "+keyword_filename);
		conn.setUsername(oracleUser);
		conn.setPassword(oraclePassword);
		conn.setUrl(oracleUrl);
		try {
			logger1.info("Connecting to Database...");
			logger1.info("Establishing DB connection with the URL - "+conn.getUrl());
			factory = HibernateUtil.createSessionFactory(conn);
		} catch (Exception e) {
			logger1.error( "Provided invalid database environment variables, Unable to Connect to DB");
			logger1.info( "Ending test execution...");
			System.exit(0);
		}
		
		session = factory.openSession();
		Transaction txn = session.beginTransaction();
		boolean success = session.isConnected();
		txn.commit();
		if (success == true){
			logger1.info("Succesfully connected to DB!");
		}
	}
	
	@BeforeTest
	public void getData() throws Exception {
		
		borFilePath= bor_filename;
		keywordFilePath= keyword_filename;
		FileReader fileReader = new FileReader();
		DatabaseUtil util = new DatabaseUtil();
		try {
			borFileList =fileReader.parseBORFile();
		} catch (Exception e) {
			logger1.error( "Unable to locate BOR File / BOR File does not exist is given file location!");
			e.printStackTrace();
			if(session.isConnected()){
				logger1.info("Closing DB Connection...");
				logger1.info("DB Connection Succesfully closed!");
				session.close();
				logger1.info("Ending test exection...");
			}else{
				logger1.info("Ending test exection...");
			}
			System.exit(0);
		}
		
		try {
			borDBMap = util.getDatabaseBorFileHistRecords(session, borFileList);
//			for(Map.Entry<String, DatabaseBOR> entry : borDBMap.entrySet()){
//				System.out.println(entry.getKey());
//			}
		} catch (Exception e1) {
			logger1.info("Something's wrong");
			e1.printStackTrace();
		}
		
		try {
			keywordFileList = fileReader.parseKeywordFile();
		} catch (Exception e) {
			logger1.error("Unable to locate Keyword File / Keyword File does not exist is given file location!");
			e.printStackTrace();
			if(session.isConnected()){
				logger1.info("Closing DB Connection...");
				logger1.info( "DB Connection Succesfully closed!");
				session.close();
				logger1.info( "Ending test exection...");
			}else{
				logger1.info( "Ending test exection...");
			}
			System.exit(0);
		}
		try {
			commonClaimIdList = fileReader.getCommonClaimId();
		} catch (Exception e) {
			logger1.trace("Something wrong in getClaimID method of FileReaderClass!",e.getCause());
//			e.printStackTrace();
//			if(session.isConnected()){
//				logger1.info( "Closing DB Connection...");
//				logger1.info( "DB Connection Succesfully closed!");
//				session.close();
//				logger1.info( "Ending test exection...");
//			}else{
//				logger1.info( "Ending test exection...");
//			}
//			System.exit(0);
		}
		sortedKeywordClaimIdList = fileReader.getSortedKeywordClaimId();
		try {
			keywordDBList = fileReader.getKeywordDBList(commonClaimIdList);
		} catch (Exception e) {
			logger1.trace("Something wrong in getSortedKeywordClaimId method of FileReaderClass!",e.getCause());
			e.printStackTrace();
//			if(session.isConnected()){
//				logger1.info( "Closing DB Connection...");
//				logger1.info( "DB Connection Succesfully closed!");
//				session.close();
//				logger1.info( "Ending test exection...");
//			}else{
//				logger1.info( "Ending test exection...");
//			}
//			System.exit(0);
		}
		
		
	}


	@Test(dataProvider = "allData")
	public void testAllData(String claimId,
			Hashtable<String, BORFile> borTable,
			Hashtable<String, KeywordFile> keywordTable,
			Hashtable<String, KeywordDB> keywordDBTable) {
		Set<Boolean> resultSet = new HashSet<Boolean>();
		reportInit("BOR-Keyword Data validation Test || claim id - ", claimId);
		
		SoftAssert softAssert = new SoftAssert();
		
		// Record Type
		softAssert.assertEquals(keywordTable.get(claimId).getRecord_type(), "EXCL","Record Type Mismatch for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getRecord_type().trim().equalsIgnoreCase("EXCL")){
			logger.log(LogStatus.PASS , "Record_type || Actual Value(BOR File) ==> "+ "EXCL " +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getRecord_type());
		}else{
			logger.log(LogStatus.FAIL , "Record_type || Actual Value(BOR File) ==> "+ "EXCL " +"  || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getRecord_type());
			resultSet.add(false);
		}
			// Sequence Number
		softAssert.assertEquals(keywordTable.get(claimId).getSequence_number(), "01","Sequence Number for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getSequence_number().trim().equalsIgnoreCase("01")){
			logger.log(LogStatus.PASS , "Sequence_number || Actual Value(BOR File) ==> "+ "01" +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getRecord_type());
		}else{
			logger.log(LogStatus.FAIL , "Sequence_number || Actual Value(BOR File) ==> "+ "01" +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getRecord_type());
			resultSet.add(false);
		}
			
		// Claim Number
		softAssert.assertEquals(keywordTable.get(claimId).getClaim_number().trim(), borTable.get(claimId).getClaimNumber().trim(),"Claim Number  for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getClaim_number().trim().equalsIgnoreCase(borTable.get(claimId).getClaimNumber().trim())){
			logger.log(LogStatus.PASS , "Claim_number || Actual Value(BOR File) ==> "+ borTable.get(claimId).getClaimNumber().trim() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getRecord_type());
		}else{
			logger.log(LogStatus.FAIL , "Claim_number || Actual Value(BOR File) ==> "+ borTable.get(claimId).getClaimNumber().trim() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getRecord_type());
			resultSet.add(false);
		}
		// Line Number
		softAssert.assertEquals(keywordTable.get(claimId).getLine_number(),	"01","Line Number for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getLine_number().trim().equalsIgnoreCase("01")){
			logger.log(LogStatus.PASS , "Line_number || Actual Value(BOR File) ==> "+ "01" +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getLine_number());
		}else{
			logger.log(LogStatus.FAIL , "Line_number || Actual Value(BOR File) ==> "+ "01" +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getLine_number());
			resultSet.add(false);
		}
		// Group ID
		softAssert.assertEquals(keywordTable.get(claimId).getGroup_id().trim(), borTable.get(claimId).getGroupNumber().trim(),"Group ID for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getGroup_id().trim().equalsIgnoreCase(borTable.get(claimId).getGroupNumber().trim())){
			logger.log(LogStatus.PASS , "Actual Value(BOR File) ==> "+ borTable.get(claimId).getGroupNumber() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getRecord_type());
		}else{
			logger.log(LogStatus.FAIL , "Actual Value(BOR File) ==> "+ borTable.get(claimId).getGroupNumber() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getRecord_type());
			resultSet.add(false);
		}
		// Subscriber ID
		softAssert.assertEquals(keywordTable.get(claimId).getSubscriber_id().trim(), borTable.get(claimId).getSubscriberId().trim(),"Subscriber ID for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getSubscriber_id().trim().equalsIgnoreCase(borTable.get(claimId).getSubscriberId().trim())){
			logger.log(LogStatus.PASS , "Subscriber_id || Actual Value(BOR File) ==> "+ borTable.get(claimId).getSubscriberId().trim() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getSubscriber_id().trim());
		}else{
			logger.log(LogStatus.FAIL , "Subscriber_id || Actual Value(BOR File) ==> "+ borTable.get(claimId).getSubscriberId().trim() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getSubscriber_id().trim());
			resultSet.add(false);
		}
		// RelationShip Code
		softAssert.assertEquals(keywordTable.get(claimId).getRelationship_code().trim(), keywordDBTable.get(claimId).getRelationshipCode().trim(),"RelationShip Code for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getRelationship_code().trim().equalsIgnoreCase(keywordDBTable.get(claimId).getRelationshipCode())){
			logger.log(LogStatus.PASS , "Relationship_code || Actual Value(Keyword File) ==> "+ keywordDBTable.get(claimId).getRelationshipCode() +" || Expected Value(Keyword DB) ==> " + keywordDBTable.get(claimId).getRelationshipCode().trim());
		}else{
			logger.log(LogStatus.FAIL , "Relationship_code || Actual Value(Keyword File) ==> "+ keywordDBTable.get(claimId).getRelationshipCode() +" || Expected Value(Keyword DB) ==> " + keywordDBTable.get(claimId).getRelationshipCode().trim());
			resultSet.add(false);
		}
		// Member Suffix
		softAssert.assertEquals(keywordTable.get(claimId).getMember_suffix().trim(),borTable.get(claimId).getPersonNumber().trim(),"Member Suffix for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getMember_suffix().trim().equalsIgnoreCase(borTable.get(claimId).getPersonNumber().trim())){
			logger.log(LogStatus.PASS , "Member_suffix || Actual Value(BOR File) ==> "+ borTable.get(claimId).getPersonNumber().trim() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getMember_suffix());
		}else{
			logger.log(LogStatus.FAIL , "Member_suffix || Actual Value(BOR File) ==> "+ borTable.get(claimId).getPersonNumber().trim() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getMember_suffix());
			resultSet.add(false);
		}
		// Plan Category
		softAssert.assertEquals(keywordTable.get(claimId).getPlan_category(),borTable.get(claimId).getProductCategory(),"Plan Category for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getPlan_category().trim().equalsIgnoreCase(borTable.get(claimId).getProductCategory())){
			logger.log(LogStatus.PASS , "Plan_category || Actual Value(BOR File) ==> "+borTable.get(claimId).getProductCategory() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getPlan_category());
		}else{
			logger.log(LogStatus.FAIL , "Plan_category || Actual Value(BOR File) ==> "+borTable.get(claimId).getProductCategory() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getPlan_category());
			resultSet.add(false);
		}
		// Plan ID
		softAssert.assertEquals(keywordTable.get(claimId).getPlan_id(),borTable.get(claimId).getPlanId(),"Plan ID for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getPlan_id().trim().equalsIgnoreCase(borTable.get(claimId).getPlanId())){
			logger.log(LogStatus.PASS , "Plan_id || Actual Value(BOR File) ==> "+ borTable.get(claimId).getPlanId() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getPlan_id());
		}else{
			logger.log(LogStatus.FAIL , "Plan_id || Actual Value(BOR File) ==> "+ borTable.get(claimId).getPlanId() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getPlan_id());
			resultSet.add(false);
		}
		// Class ID
		softAssert.assertEquals(keywordTable.get(claimId).getClass_id(),borTable.get(claimId).getClassId(),"Class ID for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getClass_id().trim().equalsIgnoreCase(borTable.get(claimId).getClassId())){
			logger.log(LogStatus.PASS , "Class_id || Actual Value(BOR File) ==> "+ borTable.get(claimId).getClassId() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getClass_id());
		}else{
			logger.log(LogStatus.FAIL , "Class_id || Actual Value(BOR File) ==> "+ borTable.get(claimId).getClassId() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getClass_id());
			resultSet.add(false);
		}
		// Diagnosis Code Type
		softAssert.assertEquals(keywordTable.get(claimId).getDiagnosis_code_type(), "","Diagnosis Code Type for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getDiagnosis_code_type().trim().equalsIgnoreCase("")){
			logger.log(LogStatus.PASS , "Diagnosis_code_type || Actual Value(BOR File) ==> "+ "" +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getDiagnosis_code_type());
		}else{
			logger.log(LogStatus.FAIL , "Diagnosis_code_type || Actual Value(BOR File) ==> "+ "" +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getDiagnosis_code_type());
			resultSet.add(false);
		}
		// Procedure Code
		softAssert.assertEquals(keywordTable.get(claimId).getProcedure_code().trim(), borTable.get(claimId).getProcedureCode().trim(),"Procedure Code for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getProcedure_code().trim().equalsIgnoreCase(borTable.get(claimId).getProcedureCode().trim())){
			logger.log(LogStatus.PASS , "Procedure_code || Actual Value(BOR File) ==> "+ borTable.get(claimId).getProcedureCode().trim() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getProcedure_code());
		}else{
			logger.log(LogStatus.FAIL , "Procedure_code || Actual Value(BOR File) ==> "+ borTable.get(claimId).getProcedureCode().trim() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getProcedure_code());
			resultSet.add(false);
		}
		// Earliest Service Date
		Date sd = new Date(borTable.get(claimId).getServiceDate());
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		softAssert.assertEquals(keywordTable.get(claimId).getEarliest_service_date(), sdf.format(sd),"Earliest Service Date for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getEarliest_service_date().trim().equalsIgnoreCase(sdf.format(sd))){
			logger.log(LogStatus.PASS , "Earliest_service_date || Actual Value(BOR File) ==> "+ sdf.format(sd) +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getEarliest_service_date());
		}else{
			logger.log(LogStatus.FAIL , "Earliest_service_date || Actual Value(BOR File) ==> "+ sdf.format(sd) +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getEarliest_service_date());
			resultSet.add(false);
		}
		// Paid Amount
		Double borAmt = Double.parseDouble(borTable.get(claimId).getClientPrice());
		MathContext mc = new MathContext(4);
		
		String str = keywordTable.get(claimId).getPaid_amount();
		String str1 = str.substring(0, str.length() - 2) + "."
				+ str.subSequence(str.length() - 2, str.length());
		Double keywordAmt = Double.parseDouble(str1);
		
		BigDecimal bor = new BigDecimal(borAmt,mc);
		BigDecimal keyword = new BigDecimal(keywordAmt,mc);
		
		softAssert.assertEquals(keyword, bor,"Paid Amount for Claim ID :"+claimId);
		if(keyword.compareTo(bor)==0){
			logger.log(LogStatus.PASS , "Paid Amount || Actual Value(BOR File) ==> "+ bor +" || Expected Value(Keyword File) ==> " + keyword);
		}else{
			logger.log(LogStatus.FAIL , "Paid Amount || Actual Value(BOR File) ==> "+ bor +" || Expected Value(Keyword File) ==> " + keyword);
			resultSet.add(false);
		}
		// Accounting Category
		softAssert.assertEquals(keywordTable.get(claimId).getAccounting_category(), "DRUG","Accounting Category for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getAccounting_category().trim().equalsIgnoreCase("DRUG")){
			logger.log(LogStatus.PASS , "Accounting_category || Actual Value(BOR File) ==> "+ "DRUG" +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getAccounting_category());
		}else{
			logger.log(LogStatus.FAIL , "Accounting_category || Actual Value(BOR File) ==> "+ "DRUG" +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getAccounting_category());
			resultSet.add(false);
		}
		// Diagnosis Code
		softAssert.assertEquals(keywordTable.get(claimId).getDiagnosis_code(),borTable.get(claimId).getDiagnosisCode(),"Diagnosis Code for Claim ID :"+claimId);
		if(keywordTable.get(claimId).getDiagnosis_code().trim().equalsIgnoreCase(borTable.get(claimId).getDiagnosisCode())){
			logger.log(LogStatus.PASS , "Diagnosis_code || Actual Value(BOR File) ==> "+ borTable.get(claimId).getDiagnosisCode() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getDiagnosis_code());
		}else{
			logger.log(LogStatus.FAIL , "Diagnosis_code || Actual Value(BOR File) ==> "+ borTable.get(claimId).getDiagnosisCode() +" || Expected Value(Keyword File) ==> " + keywordTable.get(claimId).getDiagnosis_code());
			resultSet.add(false);
		}
		
		softAssert.assertAll();
		
	}

	@DataProvider
	public Object[][] allData() {
		Hashtable<String, BORFile> borTable = null;
		Hashtable<String, KeywordFile> keywordTable = null;
		Hashtable<String, KeywordDB> keywordDBTable = null;
		Object[][] data = null;
		try {
			data = new Object[commonClaimIdList.size()][4];
		} catch (Exception e) {
			logger1.trace("No Data to be provided...", e.getCause());
			if(session.isConnected()){
				logger1.info( "Closing DB Connection...");
				logger1.info( "DB Connection Succesfully closed!");
				session.close();
				logger1.info( "Ending test exection...");
			}else{
				logger1.info( "Ending test exection...");
			}
			System.exit(0);
		}

		for (int i = 0; i < data.length; i++) {
			borTable = new Hashtable<String, BORFile>();
			borTable.put((String) commonClaimIdList.get(i).getClaimId(),
					commonClaimIdList.get(i));
			keywordTable = new Hashtable<String, KeywordFile>();
			keywordTable.put((String) commonClaimIdList.get(i).getClaimId(),
					sortedKeywordClaimIdList.get(i));
			keywordDBTable = new Hashtable<String, KeywordDB>();
			keywordDBTable.put((String) commonClaimIdList.get(i).getClaimId(), keywordDBList.get(i));
			data[i][0] = (String) commonClaimIdList.get(i).getClaimId();
			data[i][1] = borTable;
			data[i][2] = keywordTable;
			data[i][3] = keywordDBTable;
		}

		return data;
	}
	
	@Test(dataProvider="borToDBData")
	public void testBorToDBData(String claimId,Hashtable<String,BORFile> borTable,Hashtable<String,DatabaseBOR> databaseBorTable){
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		reportInit("BOR-Custom Hist Table Data validation || claim id - ", claimId);
		if(databaseBorTable.get(claimId)==null){
			logger.log(LogStatus.INFO, "FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST doesn't contain the data");
			logger.log(LogStatus.FAIL, "Test case failed");
		
		}
		else{
		SoftAssert softassert = new SoftAssert();
		BigDecimal claimAmount = databaseBorTable.get(claimId).getCLM_AMT().setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal clientPrice = databaseBorTable.get(claimId).getCLI_PRC_AMT().setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal bscRevenueAmount = databaseBorTable.get(claimId).getBSC_RVNU_AMT().setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal billedAmount = databaseBorTable.get(claimId).getBIL_AMT().setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal allowedAmount = databaseBorTable.get(claimId).getALLOW_AMT().setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal deductibleAmount = databaseBorTable.get(claimId).getDED_AMT().setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal copayAmount = databaseBorTable.get(claimId).getCOPAY_AMT().setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal coinsAmount = databaseBorTable.get(claimId).getCOINS_AMT().setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal borclaimAmount 	 =	 new BigDecimal(borTable.get(claimId).getClaimAmount()).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal borclientPrice 	=    new BigDecimal(borTable.get(claimId).getClientPrice()).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal borbscRevenueAmount=  new BigDecimal(borTable.get(claimId).getBscRevenueAmount()).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal borbilledAmount		=new BigDecimal(borTable.get(claimId).getBilledAmount()).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal borallowedAmount 	=new BigDecimal(borTable.get(claimId).getAllowedAmount()).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal bordeductibleAmount = new BigDecimal(borTable.get(claimId).getDeductibleAmount()).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal borcopayAmount 		=new BigDecimal(borTable.get(claimId).getCopayAmount()).setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal borcoinsAmount 	=    new BigDecimal(borTable.get(claimId).getCoinsuranceAmount()).setScale(2, BigDecimal.ROUND_HALF_UP);	
		
		softassert.assertEquals(borTable.get(claimId).getClaimId(),databaseBorTable.get(claimId).getFICT_CLM_ID(),"FICT_CLM_ID mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getClaimId().equalsIgnoreCase(databaseBorTable.get(claimId).getFICT_CLM_ID())){
			logger.log(LogStatus.PASS, "FICT_CLM_ID || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getFICT_CLM_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClaimId());
		}else{
			logger.log(LogStatus.FAIL, "FICT_CLM_ID || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getFICT_CLM_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClaimId());
		}
		softassert.assertEquals(borTable.get(claimId).getFileName(),databaseBorTable.get(claimId).getFIL_NM(),"FIL_NM mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getFileName().equalsIgnoreCase(databaseBorTable.get(claimId).getFIL_NM())){
			logger.log(LogStatus.PASS, "FileName || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getFIL_NM() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getFileName());
		}else{
			logger.log(LogStatus.FAIL, "FileName || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getFIL_NM() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getFileName());
		}
		softassert.assertEquals(borTable.get(claimId).getVendorName(),databaseBorTable.get(claimId).getVEND_NM(),"VEND_NM mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getVendorName().equalsIgnoreCase(databaseBorTable.get(claimId).getVEND_NM())){
			logger.log(LogStatus.PASS, "VendorName || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getVEND_NM() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getVendorName());
		}else{
			logger.log(LogStatus.FAIL, "VendorName || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getVEND_NM() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getVendorName());
		}
		softassert.assertEquals(borTable.get(claimId).getGroupNumber(),databaseBorTable.get(claimId).getGRP_NBR(),"GRP_NBR mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getGroupNumber().equalsIgnoreCase(databaseBorTable.get(claimId).getGRP_NBR())){
			logger.log(LogStatus.PASS, "GroupNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getGRP_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getGroupNumber());
		}else{
			logger.log(LogStatus.FAIL, "GroupNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getGRP_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getGroupNumber());
		}
		softassert.assertEquals(borTable.get(claimId).getSubgroupId(),databaseBorTable.get(claimId).getSBGRP_ID(),"SBGRP_ID mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getSubgroupId().equalsIgnoreCase(databaseBorTable.get(claimId).getSBGRP_ID())){
			logger.log(LogStatus.PASS, "SubgroupId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getSBGRP_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getSubgroupId());
		}else{
			logger.log(LogStatus.FAIL, "SubgroupId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getSBGRP_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getSubgroupId());
		}
		softassert.assertEquals(borTable.get(claimId).getSubscriberId(),databaseBorTable.get(claimId).getSBSCR_ID(),"SBSCR_ID mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getSubscriberId().equalsIgnoreCase(databaseBorTable.get(claimId).getSBSCR_ID())){
			logger.log(LogStatus.PASS, "SubscriberId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getSBSCR_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getSubscriberId());
		}else{
			logger.log(LogStatus.FAIL, "SubscriberId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getSBSCR_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getSubscriberId());
		}
		softassert.assertEquals(borTable.get(claimId).getPersonNumber(),databaseBorTable.get(claimId).getPERS_NBR(),"PERS_NBR mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getPersonNumber().equalsIgnoreCase(databaseBorTable.get(claimId).getPERS_NBR())){
			logger.log(LogStatus.PASS, "PersonNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPERS_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getPersonNumber());
		}else{
			logger.log(LogStatus.FAIL, "PersonNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPERS_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getPersonNumber());
		}
		softassert.assertEquals(borTable.get(claimId).getClaimNumber(),databaseBorTable.get(claimId).getCLM_NBR(),"CLM_NBR() mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getClaimNumber().equalsIgnoreCase(databaseBorTable.get(claimId).getCLM_NBR())){
			logger.log(LogStatus.PASS, "ClaimNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCLM_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClaimNumber());
		}else{
			logger.log(LogStatus.FAIL, "ClaimNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCLM_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClaimNumber());
		}
		softassert.assertEquals(borTable.get(claimId).getClaimVersionNumber(),databaseBorTable.get(claimId).getCLM_VER_NBR(),"CLM_VER_NBR mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getClaimVersionNumber().equalsIgnoreCase(databaseBorTable.get(claimId).getCLM_VER_NBR())){
			logger.log(LogStatus.PASS, "ClaimVersionNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCLM_VER_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClaimVersionNumber());
		}else{
			logger.log(LogStatus.FAIL, "ClaimVersionNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCLM_VER_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClaimVersionNumber());
		}
		softassert.assertEquals(String.valueOf(borclaimAmount),String.valueOf(claimAmount),"CLM_AMT mismatch for claimID - "+claimId );
		if(String.valueOf(borclaimAmount).equalsIgnoreCase(String.valueOf(claimAmount))){
			logger.log(LogStatus.PASS, "claimAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(claimAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borclaimAmount));
		}else{
			logger.log(LogStatus.FAIL, "claimAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(claimAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borclaimAmount));
		}
		softassert.assertEquals(String.valueOf(borclientPrice),String.valueOf(clientPrice),"CLI_PRC_AMT mismatch for claimID - "+claimId );
		if(String.valueOf(borclientPrice).equalsIgnoreCase(String.valueOf(clientPrice))){
			logger.log(LogStatus.PASS, "clientPrice || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(clientPrice) + "|| Expected Value(BOR File) ==> "+String.valueOf(borclientPrice));
		}else{
			logger.log(LogStatus.FAIL, "clientPrice || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(clientPrice) + "|| Expected Value(BOR File) ==> "+String.valueOf(borclientPrice));
		}
		softassert.assertEquals(String.valueOf(borbscRevenueAmount),String.valueOf(bscRevenueAmount),"BSC_RVNU_AMT mismatch for claimID - "+claimId );
		if(String.valueOf(borbscRevenueAmount).equalsIgnoreCase(String.valueOf(bscRevenueAmount))){
			logger.log(LogStatus.PASS, "bscRevenueAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(bscRevenueAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borbscRevenueAmount));
		}else{
			logger.log(LogStatus.FAIL, "bscRevenueAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(bscRevenueAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borbscRevenueAmount));
		}
		softassert.assertEquals(borTable.get(claimId).getCheckNumber(),databaseBorTable.get(claimId).getCHK_NBR(),"CHK_NBR mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getCheckNumber().equalsIgnoreCase(databaseBorTable.get(claimId).getCHK_NBR())){
			logger.log(LogStatus.PASS, "CheckNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCHK_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getCheckNumber());
		}else{
			logger.log(LogStatus.FAIL, "CheckNumber || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCHK_NBR() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getCheckNumber());
		}
		softassert.assertEquals(borTable.get(claimId).getCheckDate().toUpperCase(),dateFormat.format(databaseBorTable.get(claimId).getCHK_DT()).toUpperCase(),"CHK_DT mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getCheckDate().equalsIgnoreCase(dateFormat.format(databaseBorTable.get(claimId).getCHK_DT()).toUpperCase())){
			logger.log(LogStatus.PASS, "CheckDate || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + dateFormat.format(databaseBorTable.get(claimId).getCHK_DT()).toUpperCase() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getCheckDate().toUpperCase());
		}else{
			logger.log(LogStatus.FAIL, "CheckDate || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + dateFormat.format(databaseBorTable.get(claimId).getCHK_DT()).toUpperCase() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getCheckDate().toUpperCase());
		}
		softassert.assertEquals(borTable.get(claimId).getServiceDate().toUpperCase(),dateFormat.format(databaseBorTable.get(claimId).getSVC_DT()).toUpperCase(),"SVC_DT mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getServiceDate().toUpperCase().equalsIgnoreCase(dateFormat.format(databaseBorTable.get(claimId).getSVC_DT()).toUpperCase())){
			logger.log(LogStatus.PASS, "ServiceDate || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + dateFormat.format(databaseBorTable.get(claimId).getSVC_DT()).toUpperCase() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getServiceDate().toUpperCase());
		}else{
			logger.log(LogStatus.FAIL, "ServiceDate || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + dateFormat.format(databaseBorTable.get(claimId).getSVC_DT()).toUpperCase() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getServiceDate().toUpperCase());
		}
		softassert.assertEquals(borTable.get(claimId).getPayeeId(),databaseBorTable.get(claimId).getPAYE_ID(),"PAYE_ID mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getPayeeId().equalsIgnoreCase(databaseBorTable.get(claimId).getPAYE_ID())){
			logger.log(LogStatus.PASS, "PayeeId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPAYE_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getPayeeId());
		}else{
			logger.log(LogStatus.FAIL, "PayeeId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPAYE_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getPayeeId());
		}
		softassert.assertEquals(borTable.get(claimId).getPayeeName(),databaseBorTable.get(claimId).getPAYE_NM(),"PAYE_NM mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getPayeeName().equalsIgnoreCase(databaseBorTable.get(claimId).getPAYE_NM())){
			logger.log(LogStatus.PASS, "PayeeName || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPAYE_NM() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getPayeeName());
		}else{
			logger.log(LogStatus.FAIL, "PayeeName || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPAYE_NM() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getPayeeName());
		}
		softassert.assertEquals(borTable.get(claimId).getPlanId(),databaseBorTable.get(claimId).getPLN_ID(),"PLN_ID mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getPlanId().equalsIgnoreCase(databaseBorTable.get(claimId).getPLN_ID())){
			logger.log(LogStatus.PASS, "PlanId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPLN_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getPlanId());
		}else{
			logger.log(LogStatus.FAIL, "PlanId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPLN_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getPlanId());
		}
		softassert.assertEquals(borTable.get(claimId).getProductId(),databaseBorTable.get(claimId).getPRDCT_ID(),"PRDCT_ID mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getProductId().equalsIgnoreCase(databaseBorTable.get(claimId).getPRDCT_ID())){
			logger.log(LogStatus.PASS, "PRDCT_ID || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPRDCT_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProductId());
		}else{
			logger.log(LogStatus.FAIL, "PRDCT_ID || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPRDCT_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProductId());
		}
		softassert.assertEquals(borTable.get(claimId).getProductCategory(),databaseBorTable.get(claimId).getPRDCT_CATEG_CD(),"PRDCT_CATEG_CD mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getProductCategory().equalsIgnoreCase(databaseBorTable.get(claimId).getPRDCT_CATEG_CD())){
			logger.log(LogStatus.PASS, "ProductCategory || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPRDCT_CATEG_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProductCategory());
		}else{
			logger.log(LogStatus.FAIL, "ProductCategory || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPRDCT_CATEG_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProductCategory());
		}
		softassert.assertEquals(borTable.get(claimId).getClassId(),databaseBorTable.get(claimId).getCLS_ID(),"CLS_ID mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getClassId().equalsIgnoreCase(databaseBorTable.get(claimId).getCLS_ID())){
			logger.log(LogStatus.PASS, "ClassId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCLS_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClassId());
		}else{
			logger.log(LogStatus.FAIL, "ClassId || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCLS_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClassId());
		}
		softassert.assertEquals(borTable.get(claimId).getProductBusinessCategory(),databaseBorTable.get(claimId).getPRDCT_BUS_CATEG_CD(),"PRDCT_BUS_CATEG_CD mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getProductBusinessCategory().trim().equalsIgnoreCase(databaseBorTable.get(claimId).getPRDCT_BUS_CATEG_CD().trim())){
			logger.log(LogStatus.PASS, "ProductBusinessCategory || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPRDCT_BUS_CATEG_CD().trim() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProductBusinessCategory().trim());
		}else{
			logger.log(LogStatus.FAIL, "ProductBusinessCategory || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPRDCT_BUS_CATEG_CD().trim() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProductBusinessCategory().trim());
		}
		softassert.assertEquals(borTable.get(claimId).getProductValueCode().trim(),databaseBorTable.get(claimId).getPRDCT_VAL1_CD().trim(),"PRDCT_VAL1_CD mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getProductValueCode().equalsIgnoreCase(databaseBorTable.get(claimId).getPRDCT_VAL1_CD())){
			logger.log(LogStatus.PASS, "ProductValueCode || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPRDCT_VAL1_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProductValueCode());
		}else{
			logger.log(LogStatus.FAIL, "ProductValueCode || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPRDCT_VAL1_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProductValueCode());
		}
		softassert.assertEquals(borTable.get(claimId).getLineOfBusinessId(),databaseBorTable.get(claimId).getLOB_ID(),"LOB_ID mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getLineOfBusinessId().equalsIgnoreCase(databaseBorTable.get(claimId).getLOB_ID())){
			logger.log(LogStatus.PASS, "LOB_ID || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getLOB_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getLineOfBusinessId());
		}else{
			logger.log(LogStatus.FAIL, "LOB_ID || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getLOB_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getLineOfBusinessId());
		}
		softassert.assertEquals(borTable.get(claimId).getLegalEntity(),databaseBorTable.get(claimId).getLGL_ENTY_CD(),"LGL_ENTY_CD mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getLegalEntity().equalsIgnoreCase(databaseBorTable.get(claimId).getLGL_ENTY_CD())){
			logger.log(LogStatus.PASS, "LegalEntity || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getLGL_ENTY_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getLegalEntity());
		}else{
			logger.log(LogStatus.FAIL, "LegalEntity || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getLGL_ENTY_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getLegalEntity());
		}
		softassert.assertEquals(String.valueOf(borbilledAmount),String.valueOf(billedAmount),"BIL_AMT mismatch for claimID - "+claimId );
		if(String.valueOf(borbilledAmount).equalsIgnoreCase(String.valueOf(billedAmount))){
			logger.log(LogStatus.PASS, "billedAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(billedAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borbilledAmount));
		}else{
			logger.log(LogStatus.FAIL, "billedAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(billedAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borbilledAmount));
		}
		softassert.assertEquals(String.valueOf(borallowedAmount),String.valueOf(allowedAmount),"ALLOW_AMT mismatch for claimID - "+claimId );
		if(String.valueOf(borallowedAmount).equalsIgnoreCase(String.valueOf(allowedAmount))){
			logger.log(LogStatus.PASS, "allowedAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(allowedAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borallowedAmount));
		}else{
			logger.log(LogStatus.FAIL, "allowedAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(allowedAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borallowedAmount));
		}
		softassert.assertEquals(String.valueOf(bordeductibleAmount),String.valueOf(deductibleAmount),"DED_AMT mismatch for claimID - "+claimId );
		if(String.valueOf(bordeductibleAmount).equalsIgnoreCase(String.valueOf(deductibleAmount))){
			logger.log(LogStatus.PASS, "deductibleAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(deductibleAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(bordeductibleAmount));
		}else{
			logger.log(LogStatus.FAIL, "deductibleAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(deductibleAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(bordeductibleAmount));
		}
		softassert.assertEquals(String.valueOf(borcoinsAmount),String.valueOf(coinsAmount),"COINS_AMT mismatch for claimID - "+claimId );
		if(String.valueOf(borcoinsAmount).equalsIgnoreCase(String.valueOf(coinsAmount))){
			logger.log(LogStatus.PASS, "coinsAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(coinsAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borcoinsAmount));
		}else{
			logger.log(LogStatus.FAIL, "coinsAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(coinsAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borcoinsAmount));
		}
		softassert.assertEquals(String.valueOf(borcopayAmount),String.valueOf(copayAmount),"COPAY_AMT mismatch for claimID - "+claimId );
		if(String.valueOf(borcopayAmount).equalsIgnoreCase(String.valueOf(copayAmount))){
			logger.log(LogStatus.PASS, "copayAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(copayAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borcopayAmount));
		}else{
			logger.log(LogStatus.FAIL, "copayAmount || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + String.valueOf(copayAmount) + "|| Expected Value(BOR File) ==> "+String.valueOf(borcopayAmount));
		}
		softassert.assertEquals(borTable.get(claimId).getDiagnosisCode(),databaseBorTable.get(claimId).getDIAG_CD(),"DIAG_CD mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getDiagnosisCode().equalsIgnoreCase(databaseBorTable.get(claimId).getDIAG_CD())){
			logger.log(LogStatus.PASS, "DiagnosisCode || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getDIAG_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getDiagnosisCode());
		}else{
			logger.log(LogStatus.FAIL, "DiagnosisCode || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getDIAG_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getDiagnosisCode());
		}
		softassert.assertEquals(borTable.get(claimId).getDiagnosisCodeType(),databaseBorTable.get(claimId).getDIAG_TYP_CD(),"DIAG_TYP_CD mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getDiagnosisCodeType().equalsIgnoreCase(databaseBorTable.get(claimId).getDIAG_TYP_CD())){
			logger.log(LogStatus.PASS, "DiagnosisCodeType || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getDIAG_TYP_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getDiagnosisCodeType());
		}else{
			logger.log(LogStatus.FAIL, "DiagnosisCodeType || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getDIAG_TYP_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getDiagnosisCodeType());
		}
		softassert.assertEquals(borTable.get(claimId).getProcedureCode(),databaseBorTable.get(claimId).getPROC_CD(),"PROC_CD mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getProcedureCode().equalsIgnoreCase(databaseBorTable.get(claimId).getPROC_CD())){
			logger.log(LogStatus.PASS, "PROC_CD || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPROC_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProcedureCode());
		}else{
			logger.log(LogStatus.FAIL, "PROC_CD || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getPROC_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getProcedureCode());
		}
		softassert.assertEquals(borTable.get(claimId).getHcpcs_id(),databaseBorTable.get(claimId).getHCPCS_ID(),"HCPCS_ID mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getHcpcs_id().equalsIgnoreCase(databaseBorTable.get(claimId).getHCPCS_ID())){
			logger.log(LogStatus.PASS, "HCPCS_ID || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getHCPCS_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getHcpcs_id());
		}else{
			logger.log(LogStatus.FAIL, "HCPCS_ID || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getHCPCS_ID() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getHcpcs_id());
		}
		softassert.assertEquals(borTable.get(claimId).getClaimTransactionType(),databaseBorTable.get(claimId).getCLM_TRANS_TYP_CD(),"CLM_TRANS_TYP_CD mismatch for claimID - "+claimId );
		if(borTable.get(claimId).getClaimTransactionType().equalsIgnoreCase(databaseBorTable.get(claimId).getCLM_TRANS_TYP_CD())){
			logger.log(LogStatus.PASS, "ClaimTransactionType || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCLM_TRANS_TYP_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClaimTransactionType());
		}else{
			logger.log(LogStatus.FAIL, "ClaimTransactionType || Actual Value(FACETS_CUSTOM.ARGUS_GL_BOR_FIL_HIST) ==> " + databaseBorTable.get(claimId).getCLM_TRANS_TYP_CD() + "|| Expected Value(BOR File) ==> "+borTable.get(claimId).getClaimTransactionType());
		}
		
		softassert.assertAll();
		
		}
	}
	@DataProvider
	public Object[][] borToDBData() {
		Hashtable<String, BORFile> borTable = null;
		Hashtable<String, DatabaseBOR> databaseBorTable = null;
		FileReader reader = new FileReader();
		List<BORFile> borList = reader.parseBORFile();
		Object[][] data = null;
		try {
			data = new Object[borList.size()][3];
		} catch (Exception e) {
			logger1.trace("No Data to be provided...", e.getCause());
			if(session.isConnected()){
				logger1.info( "Closing DB Connection...");
				logger1.info( "DB Connection Succesfully closed!");
				session.close();
				logger1.info( "Ending test exection...");
			}else{
				logger1.info( "Ending test exection...");
			}
			System.exit(0);
		}

		for (int i = 0; i < data.length; i++) {
			borTable = new Hashtable<String, BORFile>();
			borTable.put(borList.get(i).getClaimNumber().trim()+","+borList.get(i).getClaimVersionNumber().trim(),
					borList.get(i));
			databaseBorTable = new Hashtable<String, DatabaseBOR>();
			DatabaseBOR databaseBor = new DatabaseBOR();
			try {
				databaseBor = borDBMap.get(borList.get(i).getClaimNumber().trim()+","+borList.get(i).getClaimVersionNumber().trim());
				databaseBorTable.put(borList.get(i).getClaimNumber().trim()+","+borList.get(i).getClaimVersionNumber().trim(), databaseBor);
//				System.out.println("Database BOR - "+databaseBor);
			} catch (Exception e) {
				DatabaseBOR adj = new DatabaseBOR();
				adj.setCLM_NBR((String)borList.get(i).getClaimNumber().trim());
//				System.out.println("Database BOR - "+adj);
				databaseBorTable.put((String)borList.get(i).getClaimNumber(), adj);
			}
			
			data[i][0] = borList.get(i).getClaimNumber().trim()+","+borList.get(i).getClaimVersionNumber().trim();
			data[i][1] = borTable;
			data[i][2] = databaseBorTable;
		}
		
		return data;
	}
	
	@AfterTest
	public void writeFailedReports(){
		for(Map.Entry<String, ErrorStatus> testResult :testResults.entrySet() ){
			reportInit("BOR-Keyword Data validation Test || claim id - ", testResult.getKey());
			if(testResult.getValue().getResult().equalsIgnoreCase("PASS")){
				logger.log(LogStatus.INFO, testResult.getValue().getComments());
				logger.log(LogStatus.PASS, "Test case passed");
			}else{
				logger.log(LogStatus.INFO, testResult.getValue().getComments());
				logger.log(LogStatus.FAIL, "Test case failed");
			}
		}
	}
	
	@AfterSuite
	public void closeConnection() {
		if (session != null) {
		logger1.info( "Closing DB Connection...");
		logger1.info( "DB Connection Succesfully closed!");
		session.close();
		}
		logger1.info( "Completed test execution...");
	}

	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		SoftAssert softassert = new SoftAssert();
		callBack.runTestMethod(testResult);
		softassert.assertAll();

	}

}
