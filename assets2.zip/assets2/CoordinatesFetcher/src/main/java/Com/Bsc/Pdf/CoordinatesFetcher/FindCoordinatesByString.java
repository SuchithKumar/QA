package Com.Bsc.Pdf.CoordinatesFetcher;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

public class FindCoordinatesByString
{	 
	public List<TextPositionSequence> findSubwords(PDDocument document, int page, final String searchTerm) throws IOException
	{
	    final List<TextPositionSequence> listOfStringCoordinates = new ArrayList<TextPositionSequence>();
	    PDFTextStripper stripper = new PDFTextStripper()
	    {
	        @Override
	        protected void writeString(String text, List<TextPosition> textPositions) throws IOException
	        {
	            TextPositionSequence word = new TextPositionSequence(textPositions);
	            String string = word.toString();

	            int fromIndex = 0;
	            int index;
	            while ((index = string.indexOf(searchTerm, fromIndex)) > -1)
	            {
	            	listOfStringCoordinates.add(word.subSequence(index, index + searchTerm.length()));
	                fromIndex = index + 1;
	            }
	            super.writeString(text, textPositions);
	        }
	    };

	    stripper.setSortByPosition(true);
	    stripper.setStartPage(page);
	    stripper.setEndPage(page);
	    stripper.getText(document);
	    return listOfStringCoordinates;
	
	}
}
