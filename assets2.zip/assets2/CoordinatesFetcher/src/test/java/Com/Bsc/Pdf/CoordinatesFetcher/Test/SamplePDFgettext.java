package Com.Bsc.Pdf.CoordinatesFetcher.Test;

import java.io.File;



import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;

import Com.Bsc.Pdf.CoordinatesFetcher.FindCoordinatesByString;
import Com.Bsc.Pdf.CoordinatesFetcher.TextPositionSequence;



public class SamplePDFgettext {
	
	public static void main(String[] args) throws Exception
	{
		PDDocument document= PDDocument.load(new File("resources/BSC_BSCST0_dt202304_D09282018_T075228_PID3330344_5137.PDF"));
		FindCoordinatesByString coordinatesByString= new Com.Bsc.Pdf.CoordinatesFetcher.FindCoordinatesByString();
		List<TextPositionSequence> list= new ArrayList<TextPositionSequence>();
		list= coordinatesByString.findSubwords(document, 1, "Blue");
		for(TextPositionSequence l:list)
		{
			System.out.println(l.toString());
			System.out.println(l.getX());
			System.out.println(l.getY());
			System.out.println(l.getWidth());
		}
		
		
		System.out.println("\n");
	
	
	
	
	
	
	
	
	
	
	
	

}
}
