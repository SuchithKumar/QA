package DbToPdfValidator.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtilities {
	public static XSSFWorkbook workbook;
	public static XSSFSheet sheet;
	public static XSSFRow row;
	public static XSSFCell cell;
	public static FileOutputStream fout;
	public static XSSFCellStyle style;

	/*
	 * Below Method is used to open the excel file
	 */
	public static void setUpExcel(String Path) throws IOException {
		FileInputStream file = new FileInputStream(new File(Path));
		workbook = new XSSFWorkbook(file);
		style = workbook.createCellStyle();
	}

	/*
	 * Below method is to find whether row is last row
	 */
	public static boolean isLastRow(int rowNum, String sheetNameDatasheet) {

		if (rowNum == workbook.getSheet(sheetNameDatasheet).getLastRowNum()) {
			return true;
		}
		return false;
	}

	/*
	 * Below method is to shift the rows down or creating rows
	 */
	public static void CreateRowAndCell(String sheetname_Datasheet, int rowNo,
			HashMap<Integer, String> collNumCellValueMap) {
		try {
			sheet = workbook.getSheet(sheetname_Datasheet);
			/*if ((sheet.getRow(rowNo + 1)) != null) {
				System.out.println("row shifting!!!!!!!!!!!");
				sheet.shiftRows(rowNo, sheet.getLastRowNum(), 1);
				row = sheet.createRow(rowNo);
				System.out.println("row shifting completed!!!!");
			} else {*/
				row = sheet.createRow(rowNo+1);
				System.out.println("row creation!!!!!!!!!!!!!");
			
			/*
			 * Below loop is to create cells using the Map
			 */

			for (Map.Entry<Integer, String> map : collNumCellValueMap
					.entrySet()) {
				cell = row.createCell(map.getKey());
				cell.setCellValue(map.getValue());
				style.setAlignment(HorizontalAlignment.LEFT);
				style.setBorderTop(BorderStyle.THIN);
				style.setBorderBottom(BorderStyle.THIN);
				style.setBorderLeft(BorderStyle.THIN);
				style.setBorderRight(BorderStyle.THIN);
				cell.setCellStyle(style);
				row.setRowStyle(style);

			}

		} catch (Exception e) {
			System.out.println("Exception Msg:" + e.getMessage());
			e.printStackTrace();

		}

	}
	
	public static void clearSheet(String sheetName)
	{
		 sheet = workbook.getSheet(sheetName);
		for (Row row : sheet) {
		   sheet.removeRow(row);
		}
	}

	/*
	 * Below method is to get values from cells
	 */
	public static String getCellValue(String sheetName, int rowNum, int collNum) {
		
		String cellData = null;
		try{ 
			sheet = workbook.getSheet(sheetName);
			cell = sheet.getRow(rowNum).getCell(collNum);
			if(cell!=null){
				int dataType = cell.getCellType();
				if  (dataType == 3) {
					return "";
				}else{
					DataFormatter formatter = new DataFormatter(); //creating formatter using the default locale
					 
					cellData  = formatter.formatCellValue(cell);
					//cellData = cell.getStringCellValue();
				}
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return cellData;
	}

		
	

	/*
	 * Below method is to get the row count
	 */
	public static int getRowCount(String SheetName) {
		int iNumber = 0;
		try {
			System.out.println("The sheet name is @@@"+SheetName);
			
			if(workbook!=null){
				sheet = workbook.getSheet(SheetName);	
				System.out.println("in if workbook noty null");
			}else{
				//sheet = workbook.getSheet(SheetName);
				System.out.println("In else block as work book null");
			}
			
			
			iNumber = sheet.getLastRowNum();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return iNumber;
	}
	
	public static int getCellCount(String SheetName){
		
		int cellSize;
		
		sheet =  workbook.getSheet(SheetName);
		
		cellSize = sheet.getRow(0).getLastCellNum();
		
		return cellSize;
		
		
	}

	/*
	 * Below method is to set the cells with values
	 */
	public static void setCellData(String sheetname_Datasheet, int rowNo,int colNum, String cell) throws IOException 
	{
		sheet = workbook.getSheet(sheetname_Datasheet);
		if (sheet.getRow(rowNo) == null) {
			sheet.createRow(rowNo).createCell(colNum).setCellValue(cell);
		} else {
			if (sheet.getRow(rowNo).getCell(colNum) == null) {
				sheet.getRow(rowNo).createCell(colNum).setCellValue(cell);

			} else {
				sheet.getRow(rowNo).getCell(colNum).setCellValue(cell);
			}
		}

	}

	/*
	 * Below method is to write the data into excel
	 */
	public static void writeToWorkBook(String Path) throws Exception {

		fout = new FileOutputStream(new File(Path));
		workbook.write(fout);
	}

	/*
	 * Below method is to close the Excel file
	 */
	public static void closefile() throws Exception {

		// workbook.close();
		fout.close();

	}

	public static void copyFile(File sourceFile, File destinationFile)
			throws IOException {
		Files.copy(sourceFile.toPath(), destinationFile.toPath(),
				StandardCopyOption.REPLACE_EXISTING);
	}
	public static void copyPdf(File sourceFile, File destinationFile)
			throws IOException {
		
		Files.copy(sourceFile.toPath(), destinationFile.toPath());
		
	}

}
