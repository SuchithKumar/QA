package DbToPdfValidator.tests;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import DbToPdfValidator.Utils.DBUtils;
import DbToPdfValidator.Utils.ExcelUtilities;
import DbToPdfValidator.Utils.TextExtractor;

/*
 * Below class is to initiate the test and compare the DB and PDF values and give the result
 */
public class DbToPdfTester {
		
		private static String  actualValue;
	 	private static String filePath;
	    private static String sheetName;
	    private static DBUtils dbUtils;
	    private static String expectedValue; 
	    private static int rowNum_Datasheet =0;
	    private static boolean result;
	    public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss"));
	   
	    /*
	     * Below method is to setup the Excel utilities and DB 
	     */
	    @BeforeClass
	    @Parameters({"TestDataSheetLocation","dataSheetName","NameOfTestDataSheet","sourceDataSheet"})
	    public void setUp(String TestDataSheetLocation,String dataSheetName,String NameOfTestDataSheet,String sourceDatasheet) throws IOException
	    {
	    	 File inputDatasheet = new File(sourceDatasheet);
	    	 File destinationDatasheet = new File(TestDataSheetLocation);
	    	
	    ExcelUtilities.copyFile(inputDatasheet,destinationDatasheet);//Copying the excel from one location to another
	    filePath = TestDataSheetLocation;
		sheetName = NameOfTestDataSheet;
		ExcelUtilities.setUpExcel(filePath);//Initiation of Excel sheet
		
		System.out.println("The file path is "+filePath+" \n The sheet name is "+sheetName);
		
		
		
	}
	
	/*
	 * Below method contains the code to compare the DB data and Pdf Data and insert the result in datasheet.
	 */
	@Test
	@Parameters({"dataSheetName","dBSheetName"})
	public void dbToPdftest(String dataSheetName,String dBSheetName)
	{
		try{
		
		int rowSize_Input = ExcelUtilities.getRowCount(sheetName);
		System.out.println("The row size of input sheet is "+ rowSize_Input);		
		int cellSize_Input = ExcelUtilities.getCellCount(sheetName);		
		System.out.println("The cell size of input sheet is "+ cellSize_Input);	
		/*
		 * Below loop is to iterate through all rows of Input sheet
		 */
		for(int rowIndex = 1;rowIndex <= rowSize_Input;rowIndex++){
			 int executionNo_Input = 0;
			 int EOB_Input_Input = 1;
			 int prevExecNo = 1;
			 int claim_Id_Input = 2;
			 int pdfPath_Input = 3;
			 int dbName_Input = 4;
			 String executionNo = ExcelUtilities.getCellValue(sheetName, rowIndex, executionNo_Input);
			 String EOB = ExcelUtilities.getCellValue(sheetName, rowIndex, EOB_Input_Input);
			 String Id = ExcelUtilities.getCellValue(sheetName, rowIndex, claim_Id_Input);
			 String pdfPath = ExcelUtilities.getCellValue(sheetName, rowIndex, pdfPath_Input);
			 String db_Name = ExcelUtilities.getCellValue(sheetName, rowIndex,dbName_Input );
			
			 setDbEnvironment(dBSheetName,db_Name);//Connecting to Particular DB environment
			
			 System.out.println("The eob is " + EOB);
			//Below condition is to check whether the EOB is Subscriber
			if((EOB.trim()).equalsIgnoreCase("Subscriber_EOB"))//condition to check the type of EOB
			{	
				int rowSize_Sub_Eob = ExcelUtilities.getRowCount(EOB);
				
				System.out.println("The row size in PCP is "+rowSize_Sub_Eob);
					
				//ExcelUtilities.getCellCount(EOB);
				
					TextExtractor.PDFSetup(pdfPath); //to set up the PDF to extract the data
					
				//Below loop is to iterate though all rows in Subscriber sheet
				
				dataRetrieveFromEOBSheet(EOB,Id,executionNo,dataSheetName,rowSize_Sub_Eob);
				
						
					}
			else if((EOB.trim()).equalsIgnoreCase("PCPNotification"))// condition to check the type of EOB
			{
				

				int rowSize_PCP = ExcelUtilities.getRowCount(EOB.trim());
				
				System.out.println("The row size in PCP is "+rowSize_PCP);
				
				//ExcelUtilities.getCellCount(EOB);
				
				
					TextExtractor.PDFSetup(pdfPath); //to set up the PDF to extract the data
					System.out.println("The pdfPath is"+ pdfPath);
					
				dataRetrieveFromEOBSheet(EOB,Id,executionNo,dataSheetName,rowSize_PCP);
			}
			else{
				System.out.println("The eob is not matched!!!!");
			}
			
			Path path = Paths.get("test-output\\"+timestamp);
			if(!Files.exists(path))
			{
			Files.createDirectories(path);//creating folder with timestamp
			}
			
			String fileName = new File(pdfPath).getName(); //Extracting file name of PDF
			String pdfFile = fileName.substring(0, fileName.length()-4);
			ExcelUtilities.copyPdf(new File(pdfPath), new File("test-output\\"+timestamp+"\\"+pdfFile+"_"+rowIndex+".pdf"));//copying PDF files to destination
			prevExecNo++;//counter for execution no
			
			}
					
		
	
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
			
	private void dataRetrieveFromEOBSheet(String eOB, String Id, String executionNo, String dataSheetName, int rowSize_Eob) throws Exception {
		
		System.out.println("The eob is!!!!!!!!!!!!!!!"+eOB);
	
		
		for(int rowIndex_Subscriber = 1;rowIndex_Subscriber<=rowSize_Eob;rowIndex_Subscriber++){
			
			int elementName = 0;
			int Query = 1;
			int top = 2; 
			int parameter1 = 3;
			int parameter2 = 4;
			int parameter3 = 5;
			int parameter4 = 6;
			int xCoordinate;
			int yCoordinate;
			int width;
			String Parameter1;
			String Parameter2;
			String Parameter3;
			String Parameter4;
			int height;
			String element = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, elementName);
			String sqlQuery = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, Query);
			String parameterType =  ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, top);
			
			//Below condition is to check if the parameter type is static
			if(parameterType.equalsIgnoreCase("Static")){
			//Extracting parameter values from Datasheet	
			 Parameter1 = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, parameter1);
			 Parameter2 = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, parameter2);
			 Parameter3 = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, parameter3);
			 Parameter4 = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, parameter4);
			 xCoordinate = Integer.valueOf(Parameter1);
			 yCoordinate = Integer.valueOf(Parameter2);
			  
			 width = Integer.valueOf(Parameter3);
			 height = Integer.valueOf(Parameter4);
			 String  expectedValue_Db = retrieveDbData(sqlQuery,Id,element);//To retrieve data from db
			 System.out.println("The expected value is "+ expectedValue_Db);
			 
			 System.out.println( "The coordinates are "+xCoordinate+" "+yCoordinate+" "+width+" "+height);
				
				 actualValue = TextExtractor.getText(xCoordinate, yCoordinate, width, height);//To retrieve data from Pdf
				
				System.out.println("The actual value is"+ actualValue);
				//To extract the city data from dB
				if(element.equalsIgnoreCase("BLEI_APTC_GRACE_START_DT"))
				{
					String[] expectedValue_GracePeriod = expectedValue_Db.split("\\s+");//Splitting the graceperiod with space to get only date
					
					System.out.println("The actual grace period is "+expectedValue_GracePeriod[0]);
					
					String[] gracePeriod = expectedValue_GracePeriod[0].split("-");//Splitting graceperiod extracted from db with - to get year, month and date
					
					StringBuilder formattedGracePeriod = new StringBuilder();
					
					formattedGracePeriod.append(gracePeriod[1]).append("/").append(gracePeriod[2]).append("/").append(gracePeriod[0]);//Appending the string to create date in new format
					 
					System.out.println("The formattedGrace period is "+formattedGracePeriod.toString());
					
					result = TextExtractor.validateText(formattedGracePeriod.toString().trim(), actualValue.trim());//Validating DB and PDF Data
					System.out.println("The result is "+result);
				}
				else if(element.equalsIgnoreCase("PRAD_ZIP"))
					
				{
					
					System.out.println("The expected Zip is "+expectedValue_Db);
					
					String[] actualValue_Zip = actualValue.split("-");
					
					 actualValue = actualValue_Zip[0].concat(actualValue_Zip[1]);
					
					
					
					System.out.println("The actual zip is "+actualValue);	
					result = TextExtractor.compareText(expectedValue_Db, actualValue);
					
					
					
				}
				else if(element.equalsIgnoreCase("BPCL_EOB_CITY"))
				{
					String actualValue_City = actualValue.substring(0, 11);
					System.out.println("The city is "+actualValue_City);
					 result = TextExtractor.validateText(expectedValue_Db, actualValue_City);
				}
				//To extract the state data from dB
				else if(element.equalsIgnoreCase("BPCL_EOB_State")){
					String actualValue_State = actualValue.substring(13, 15);
					System.out.println("The state is "+actualValue_State);
					 result = TextExtractor.validateText(expectedValue_Db, actualValue_State);
				}
				//To extract the Zip data from dB
				else if(element.equalsIgnoreCase("BPCL_EOB_Zip")){
					String actualValue_Zip = actualValue.substring(16);
					System.out.println("The zip is "+actualValue_Zip);
					result = TextExtractor.validateText(expectedValue_Db, actualValue_Zip);
				}
				else{
					
				 result = TextExtractor.validateText(expectedValue_Db, actualValue);// To compare the DB data and PDF Data
				
				}
				
				//Updating datasheet
				updateDatasheet(executionNo,eOB,element,expectedValue_Db,actualValue,dataSheetName);//To insert the validation results into Datasheet
			
			}
			//below is to check if the parameter is dynamic
			else if(parameterType.equalsIgnoreCase("Dynamic"))
			{
				 String  expectedValue_Db = retrieveDbData(sqlQuery,Id,element);//retrieving  data from dB
				 System.out.println("The expected value is "+ expectedValue_Db);
				 
				 result = TextExtractor.validateTextInPDF(expectedValue_Db);//Extracting data from pdf
				 //updating datasheet
				 updateDatasheet(executionNo,eOB,element,expectedValue_Db,expectedValue_Db,dataSheetName);
			}
			//below is to check if the parameter is table
			else if(parameterType.equalsIgnoreCase("table"))
			{
				//Extracting parameter values from Datasheet
				 Parameter1 = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, parameter1);
				 Parameter2 = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, parameter2);
				 Parameter3 = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, parameter3);
				 Parameter4 = ExcelUtilities.getCellValue(eOB, rowIndex_Subscriber, parameter4);
				 
				float floatValue = 0.00f;
				String  expectedValue_Db = retrieveDbData(sqlQuery,Id,element);
				System.out.println("The expected value is "+ expectedValue_Db);
				 
				float expectedValue = Float.parseFloat(expectedValue_Db)+floatValue;
				System.out.println("The expected value in tester is !!!!!!"+expectedValue);
						result = TextExtractor.tablevalidation(
								expectedValue,
								Parameter2,
								Parameter1);//this is to validate the calculated amount with data in pdf
				//Updating datasheet
				updateDatasheet(executionNo,eOB,element,expectedValue_Db,expectedValue_Db,dataSheetName);
						
					
			}
			
			
			
			
			
			rowNum_Datasheet++;//incrementing the row number of datasheet
			System.out.println("The row number is "+rowNum_Datasheet);
			
			
			
        	  	
          }
		
	}

	//Below method is to connect the database based on the database name
	private void setDbEnvironment(String dBSheetName, String db_Name ) {
		
		int rowSize_Subscriber = ExcelUtilities.getRowCount(dBSheetName);
		
		for(int rowIndex_dB =1;rowIndex_dB<=rowSize_Subscriber;rowIndex_dB++){
			
			  HashMap<String,String> dbEnvironmentMap = new HashMap<String,String>();//Map to store the dB environment detais
			
			  int dB_Server_collNum = 1;
			  int dB_Port_collNum = 2;
			  int dB_User_collNum = 3;
			  int dB_Pwd_collNum = 4;
			  int dB_Name_collNum = 0;
			String dbName = ExcelUtilities.getCellValue(dBSheetName, rowIndex_dB,dB_Name_collNum );
			String dBServer = ExcelUtilities.getCellValue(dBSheetName, rowIndex_dB,dB_Server_collNum );
			String dBPort = ExcelUtilities.getCellValue(dBSheetName, rowIndex_dB,dB_Port_collNum );
			String dBUser = ExcelUtilities.getCellValue(dBSheetName, rowIndex_dB,dB_User_collNum );
			String dBPwd = ExcelUtilities.getCellValue(dBSheetName, rowIndex_dB,dB_Pwd_collNum );
			System.out.println("The dbName from input sheet  is "+db_Name);
			System.out.println("The db Name from environment sheet is "+dbName);
			//Below map is to retrieve the dB name,dB Server, db port,db User, db password by providing proper key
			dbEnvironmentMap.put(dbName+"Server", dBServer);
			dbEnvironmentMap.put(dbName+"Port", dBPort);
			dbEnvironmentMap.put(dbName+"User", dBUser);
			dbEnvironmentMap.put(dbName+"Pwd", dBPwd);
			System.out.println("Initiating dB connection!!!!!!");
			//to check if map contains the key of db name
			if(dbEnvironmentMap.containsKey(db_Name+"Server")){
				
				dbUtils = new DBUtils(dbName,dbEnvironmentMap.get(db_Name+"User"), dbEnvironmentMap.get(db_Name+"Pwd"),  dbEnvironmentMap.get(db_Name+"Server"), dbEnvironmentMap.get(db_Name+"Port"));//Initializing the Db setup
				dbUtils.setUpDBConnection();//Connecting to Db
				System.out.println(" dB connected!!!!!!");
				
			}
			else
			{
				System.out.println("The key is not present!!!!");
			}
		}
		
	}

	//Below method is to update the data into Datasheet
	private void updateDatasheet(String executionNo, String eOB,
			String element, String expectedValue_Db, String actualValue,
			String dataSheetName) {
		 HashMap<Integer, String> collNumCellValueMap = new HashMap<Integer, String>();//Map with the data to be inserted in Datasheet
		 int execNo_CollNum_Datasheet = 0;
		 int typeOfEob_CollNum_Datasheet = 1;
		 int elementName_CollNum_Datasheet = 2;
		 int expectedValue_CollNum_Datasheet = 3;
		 int actualValue_CollNum_Datasheet = 4;
		 int result_CollNum_Datasheet = 5;
		 int resultDescription_CollNum_Datasheet = 6;
		 
		collNumCellValueMap.put(execNo_CollNum_Datasheet, executionNo);//execution No Map
		
		collNumCellValueMap.put(typeOfEob_CollNum_Datasheet, eOB);//Eob Map
		
		collNumCellValueMap.put(elementName_CollNum_Datasheet, element);//Element Map
		
		collNumCellValueMap.put(expectedValue_CollNum_Datasheet, expectedValue_Db);//expected Value Map
		
		if(result){
			if(element.equalsIgnoreCase("PRAD_ZIP")){
				collNumCellValueMap.put(actualValue_CollNum_Datasheet, actualValue);
			}
			else{
		collNumCellValueMap.put(actualValue_CollNum_Datasheet, actualValue);//Actual Value Map
			}
		}
		else{
			collNumCellValueMap.put(actualValue_CollNum_Datasheet, "Value not found in PDF!!!");//Actual Value map
		}
		
		if(result){
		
		collNumCellValueMap.put(result_CollNum_Datasheet, "Pass");//Result Map
		collNumCellValueMap.put(
				resultDescription_CollNum_Datasheet,
				"The expected Value is present in pdf" );//result description Map
		}
		else{
			collNumCellValueMap.put(result_CollNum_Datasheet, "Fail");
			collNumCellValueMap.put(
					resultDescription_CollNum_Datasheet,
					"The expected Value is not present in pdf" );
		}
		
		//Below one is to create row and columns in datasheet
		ExcelUtilities.CreateRowAndCell(dataSheetName,
				rowNum_Datasheet, collNumCellValueMap);
		
	}

	//Below method is to retrieve data from Db
	private String retrieveDbData(String sqlQuery, String Id, String element) throws SQLException {
		 ResultSet queryResult;
		 
		if(sqlQuery.contains("'Claim_Id'")){
		sqlQuery = sqlQuery.replace("'Claim_Id'", "'"+Id+"'");
		System.out.println("the query is "+sqlQuery);
		
				queryResult  =	dbUtils.getQueryDataFromDB(sqlQuery);
		
		}
		else if(sqlQuery.contains("'Sub_id'")){
			sqlQuery = sqlQuery.replace("'Sub_id'", "'"+Id+"'");
			System.out.println("the query is "+sqlQuery);
			
			 queryResult =	dbUtils.getQueryDataFromDB(sqlQuery);
			
		}
		else{
			 queryResult =	dbUtils.getQueryDataFromDB(sqlQuery);
		}
		
		
		/*String[] query = sqlQuery.split("\\=");
		
		query[1]= query[1].replaceAll("'Claim_Id'", "'"+claimId+"'");// Replacing the Claim_id with the claim id provided in Input sheet 
		
	String	mainQuery = query[0].concat("=").concat(query[1]);*/ // Original query after concatenation
		
		/*System.out.println("the query is "+sqlQuery);
			
		ResultSet queryResult =	dbUtils.getQueryDataFromDB(sqlQuery);//Extracting results from Db
*/		
		while(queryResult.next()){
		
		 expectedValue = queryResult.getString(element); // extracting data from particular column

		}
		 return expectedValue;
		
		
	}

	//Below method is to close the excel sheet and shut down the db 
	@AfterClass
	 @Parameters({"TestDataSheetLocation"})
	public void afterTest(String dataSheetLocation) throws Exception
	{
		
		
		ExcelUtilities.writeToWorkBook(filePath);//To write data into Datasheet
		ExcelUtilities.copyFile(new File(dataSheetLocation),new File("test-output\\"+timestamp+"\\Data_Sheet_"+timestamp+".xlsx"));
		TextExtractor.closefile();
		dbUtils.teardownDBConnection();//disconnecting the dB connection
		ExcelUtilities.closefile();//closing excel file
		System.out.println("DB is stopped and excel is closed");
	}
	
	
}
