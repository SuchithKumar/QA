package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileBody35 {
	private String WMDS_TEXT1;
	private String GRGR_ID;
	private String SBSB_ID;
	private String MEME_HICN;
	
	public String getMEME_HICN() {
		return MEME_HICN;
	}
	public void setMEME_HICN(String mEME_HICN) {
		MEME_HICN = mEME_HICN;
	}
	public String getWMDS_TEXT1() {
		return WMDS_TEXT1;
	}
	public void setWMDS_TEXT1(String wMDS_TEXT1) {
		WMDS_TEXT1 = wMDS_TEXT1;
	}
	public String getGRGR_ID() {
		return GRGR_ID;
	}
	public void setGRGR_ID(String gRGR_ID) {
		GRGR_ID = gRGR_ID;
	}
	public String getSBSB_ID() {
		return SBSB_ID;
	}
	public void setSBSB_ID(String sBSB_ID) {
		SBSB_ID = sBSB_ID;
	}
	
}
