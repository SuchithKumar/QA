package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileBody20 {

		private String WMDS_TEXT1;
		private String GRGR_ID;
		private String SBSB_ID;
		private String MEME_SFX;
		private String SBAD_ADDR1;
		private String SBAD_CITY;
		private String SBAD_STATE;
		private String SBAD_ZIP;
		public String getWMDS_TEXT1() {
			return WMDS_TEXT1;
		}
		public void setWMDS_TEXT1(String wMDS_TEXT1) {
			WMDS_TEXT1 = wMDS_TEXT1;
		}
		public String getGRGR_ID() {
			return GRGR_ID;
		}
		public void setGRGR_ID(String gRGR_ID) {
			GRGR_ID = gRGR_ID;
		}
		public String getSBSB_ID() {
			return SBSB_ID;
		}
		public void setSBSB_ID(String sBSB_ID) {
			SBSB_ID = sBSB_ID;
		}
		public String getMEME_SFX() {
			return MEME_SFX;
		}
		public void setMEME_SFX(String mEME_SFX) {
			MEME_SFX = mEME_SFX;
		}
		public String getSBAD_ADDR1() {
			return SBAD_ADDR1;
		}
		public void setSBAD_ADDR1(String sBAD_ADDR1) {
			SBAD_ADDR1 = sBAD_ADDR1;
		}
		public String getSBAD_CITY() {
			return SBAD_CITY;
		}
		public void setSBAD_CITY(String sBAD_CITY) {
			SBAD_CITY = sBAD_CITY;
		}
		public String getSBAD_STATE() {
			return SBAD_STATE;
		}
		public void setSBAD_STATE(String sBAD_STATE) {
			SBAD_STATE = sBAD_STATE;
		}
		public String getSBAD_ZIP() {
			return SBAD_ZIP;
		}
		public void setSBAD_ZIP(String sBAD_ZIP) {
			SBAD_ZIP = sBAD_ZIP;
		}
		
		
		
		
}