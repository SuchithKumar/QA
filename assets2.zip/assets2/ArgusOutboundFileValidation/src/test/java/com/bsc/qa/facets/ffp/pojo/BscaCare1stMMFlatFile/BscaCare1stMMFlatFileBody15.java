package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileBody15 {
	private String WMDS_TEXT1;
	private String GRGR_ID;
	private String SBSB_ID;
	private String MEME_SFX;
	private String BSDL_USER_DATA2;
	
	public String getWMDS_TEXT1() {
		return WMDS_TEXT1;
	}
	public void setWMDS_TEXT1(String wMDS_TEXT1) {
		WMDS_TEXT1 = wMDS_TEXT1;
	}
	public String getGRGR_ID() {
		return GRGR_ID;
	}
	public void setGRGR_ID(String gRGR_ID) {
		GRGR_ID = gRGR_ID;
	}
	public String getSBSB_ID() {
		return SBSB_ID;
	}
	public void setSBSB_ID(String sBSB_ID) {
		SBSB_ID = sBSB_ID;
	}
		
	public String getBSDL_USER_DATA2() {
		return BSDL_USER_DATA2;
	}
	public void setBSDL_USER_DATA2(String bSDL_USER_DATA2) {
		BSDL_USER_DATA2 = bSDL_USER_DATA2;
	}
	public String getMEME_SFX() {
		return MEME_SFX;
	}
	public void setMEME_SFX(String mEME_SFX) {
		MEME_SFX = mEME_SFX;
	}
}


