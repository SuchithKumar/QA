package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileBody02 {
	private String LOB;
	private String GRGR_VAL;
	private String DATE;
	
	public String getLOB() {
		return LOB;
	}
	public void setLOB(String lOB) {
		LOB = lOB;
	}
	public String getGRGR_VAL() {
		return GRGR_VAL;
	}
	public void setGRGR_VAL(String gRGR_VAL) {
		GRGR_VAL = gRGR_VAL;
	}
	public String getDATE() {
		return DATE;
	}
	public void setDATE(String dATE) {
		DATE = dATE;
	}
		
}
