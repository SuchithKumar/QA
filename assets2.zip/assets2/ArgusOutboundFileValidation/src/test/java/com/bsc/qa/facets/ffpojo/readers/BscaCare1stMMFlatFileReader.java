package com.bsc.qa.facets.ffpojo.readers;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;







import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody;
import com.github.ffpojo.exception.FFPojoException;
import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.file.reader.RecordType;

public class BscaCare1stMMFlatFileReader {
	
	String testFlatFileCompletePath; // <== Path to a test file  
	
	public BscaCare1stMMFlatFileReader(String testFlatFileCompletePath) {//Constructor for Reader class
		this.testFlatFileCompletePath = testFlatFileCompletePath;
	} 

	//************************* method for FLAT FILE FIELDS MAP *************************//
	public SortedMap<String,List<Object>> getFlatFileData(FlatFileReaderDefinition ffDefinition) throws IOException{
		List<Object> bodyRowsList=new ArrayList<Object>();//list for body rows
		SortedMap<String,List<Object>> recordsMap=new TreeMap<String,List<Object>>();
		String tempFilePath = System.getenv("TEMP_FILE");
		File inputFile = new File(tempFilePath);
		if (!inputFile.exists()) { 
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
		} else { 
			//invoking the FlatFile Reader proving parameters
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
			
			//List<Object> list=Arrays.asList(ffReader);
			for (Object record :ffReader ) {//Iterating through the reader object and adding the records in list 
					
			
					
					bodyRowsList.add(record);
			
					
			}
			ffReader.close();							//Closing ffReader 
			recordsMap.put("Body", bodyRowsList);
					
		}
				
		return recordsMap; // method return value 
						
	} // <==  public List<Map<String, String>> getListOfHeaderValues(){
	
	
	
//SAMPLE to READ ALL in ONE METHOD NOT USED BY TEST < GOOD FOR DEBUGGING
public void readExtracts() throws IOException, FFPojoException {
		
		File inputFile = new File(testFlatFileCompletePath);
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		}
		
		
		FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody.class);
				
		
		
		FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
	
		for (Object record : ffReader) {
			
			RecordType recordType = ffReader.getRecordType();
			
			if (recordType == RecordType.HEADER) { //<=== Headers 
				
				System.out.print("HEADER FOUND: " + record.hashCode());
				//BscAccumsToCvsHeader header = (BscAccumsToCvsHeader)record;
				//System.out.println(header.getHEADER_INDICATOR());
			
			} else if (recordType == RecordType.BODY) {
				
				//BscAccumsToDBPSHDWBody cust = (BscAccumsToDBPSHDWBody)record;
				//System.out.println(cust.getMEMBER_FIRST_NAME()+ " " + cust.getMEMBER_LAST_NAME());
			
			} else if (recordType == RecordType.TRAILER) {
				
				//System.out.println("TRAILER FOUND: ");
				//BscAccumsToCvsTrailer trailer = (BscAccumsToNavitusTrailer)record;
				//System.out.println(trailer.getTOTAL_AMOUNT());
			}
		
		
		}
		
		ffReader.close();

	}
	
}
