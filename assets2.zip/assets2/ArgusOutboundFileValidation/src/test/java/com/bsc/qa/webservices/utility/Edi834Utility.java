package com.bsc.qa.webservices.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.SortedMap;
import java.util.TreeMap;


import com.bsc.qa.framework.base.BaseTest;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.relevantcodes.extentreports.LogStatus;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody02;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody15;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody16;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody20;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody26;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody30;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody35;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody36;
import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody45;
import com.bsc.qa.facets.ffpojo.readers.BscaCare1stMMFlatFileReader;
import com.relevantcodes.extentreports.LogStatus;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;

/**
 * Edi834Utility class that gets fields data from 834 file to be used for 834 file validation.
 * @author Automation team
 *
 */
public class Edi834Utility extends BaseTest {

	public static BscaCare1stMMFlatFileReader ffpExtract;
	
	/**
	 *For getting 834 file data from 834 EDI file
	 * @param strCompleteFilePath: 834 file path
	 * @param strInputFileName: 834 file name
	 * @return
	 * @throws Exception: To capture the exception
	 */
	/*public SortedMap<String, SortedMap<String, String>> get834FileData(
			String strCompleteFilePath, String strInputFileName)
			throws Exception {*/
	// method used for fetching file data into a map
	public SortedMap<String, SortedMap<String, SortedMap<String, String>>> get834FileData(String strCompleteFilePath, String strInputFileName,Map<String, String> data) throws Exception
	{
	
		String strFileType;
		
		//Declaring a map with keys Subscriber ids and values as all records for that subscriber
		SortedMap<String, SortedMap<String, SortedMap<String, String>>> flatFileValuesMap = null;
		
		strCompleteFilePath = strInputFileName;
		//to get exact file name from file path
		String strInputExactFileName = strInputFileName.substring(strInputFileName.lastIndexOf("\\") + 1);
		// To get Argus file type
		strFileType = fileType834(strInputExactFileName);
		flatFileValuesMap = new TreeMap<String, SortedMap<String, SortedMap<String, String>>>();
		
		 SortedMap<String,List<Object>> recordsMap=new TreeMap<String,List<Object>>();

		// Checking for the 834 file type
		if (strFileType.contains("834")) {
			System.out.println("Inside 834 file type");	
		}
		//Checking for member and Group files
		else if(strFileType.contains("MBR"))
		{
			int recordCounts=0;
			
					try {
						//this will set up the FileReader of ffpojo library
						ffpExtract = new BscaCare1stMMFlatFileReader(strCompleteFilePath);
						// Creating objects for all record types classes
						FlatFileReaderDefinition ffDefinition10 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody.class);
						FlatFileReaderDefinition ffDefinition15 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody15.class);
						FlatFileReaderDefinition ffDefinition16 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody16.class);
						FlatFileReaderDefinition ffDefinition20 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody20.class);
						FlatFileReaderDefinition ffDefinition26 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody26.class);
						FlatFileReaderDefinition ffDefinition30 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody30.class);
						FlatFileReaderDefinition ffDefinition35 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody35.class);
						FlatFileReaderDefinition ffDefinition36 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody36.class);
						FlatFileReaderDefinition ffDefinition45 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody45.class);
						// Creating file object to read the Argus file
						File file=new File(strCompleteFilePath);
						Scanner sc= new Scanner(file);
						// Storing keys as record type with subs id and values as corresponding row details for all subscriber
						SortedMap<String,SortedMap<String , String>> mapOfBodyMap=new TreeMap<String,SortedMap<String , String>>();
						String tempFilePath = System.getenv("TEMP_FILE");
						
						while(sc.hasNextLine()){
							//reading line by line of Argus file
							String line=sc.nextLine();
							String s=line.substring(0, 2);
							String subID="";
							//checking record types of a line for header and trailers
							if(s.equals("00") || s.equals("01") || s.equals("90") || s.equals("99")){
								continue;
							}
							
							else if(s.equals("10")){
								try {
									//writing the line 10 in a temp file 
									File file1 = new File(tempFilePath);
									
									FileWriter fileWriter = new FileWriter(file1);
									fileWriter.write(line);
									
									fileWriter.flush();
									fileWriter.close();
								} catch (IOException e) {
									e.printStackTrace();
								}
								//storing the field records of a line in map, key:Body, Value:Object of records list
								recordsMap=ffpExtract.getFlatFileData(ffDefinition10);
								//storing field records of a line in a sorted map, key: field name, value:corresponding file value
								SortedMap<String,String> bodyMap=new TreeMap<String,String>();
								//Iterating through object list of recordsMap value
								for(Object record:recordsMap.get("Body")){
									
									
									BscaCare1stMMFlatFileBody body = (BscaCare1stMMFlatFileBody)record;
									//Inserting fiel values in corresponding field names in bodyMap
									bodyMap.put("WMDS_TEXT1", body.getWMDS_TEXT1()); 
									bodyMap.put("GRGR_ID", body.getGRGR_ID()); 
									bodyMap.put("SBSB_ID", body.getSBSB_ID()); 
									bodyMap.put("MEPE_EFF_DT", body.getMEPE_EFF_DT()); 
									bodyMap.put("MEPE_TERM_DT", body.getMEPE_TERM_DT()); 
									bodyMap.put("MEME_LAST_NAME", body.getMEME_LAST_NAME()); 
									bodyMap.put("MEME_FIRST_NAME", body.getMEME_FIRST_NAME()); 
									bodyMap.put("Dual_Coverage_indicator", body.getDual_Coverage_indicator()); 
									bodyMap.put("LOB", body.getLOB());
									//System.out.println("bodyMap:"+bodyMap);
									String recordType = body.getSBSB_ID()+"_"+"10";
									//Inserting a complete bodyMap into mapOfBodyMap with key as sub id and record type
									mapOfBodyMap.put(recordType, bodyMap);
									recordCounts=recordCounts+1;
								}
								
							}
							
							
							else if(s.equals("15")){
								try {
									File file1 = new File(tempFilePath);
									FileWriter fileWriter = new FileWriter(file1);
									fileWriter.write(line);
									
									fileWriter.flush();
									fileWriter.close();
								} catch (IOException e) {
									e.printStackTrace();
								}
								recordsMap=ffpExtract.getFlatFileData(ffDefinition15);		
								for(Object record:recordsMap.get("Body")){
									
									
									BscaCare1stMMFlatFileBody15 body = (BscaCare1stMMFlatFileBody15)record;
									SortedMap<String,String> bodyMap=new TreeMap<String,String>();
									
									bodyMap.put("WMDS_TEXT1", body.getWMDS_TEXT1()); 
									bodyMap.put("GRGR_ID", body.getGRGR_ID()); 
									bodyMap.put("SBSB_ID", body.getSBSB_ID()); 
									bodyMap.put("MEME_SFX", body.getMEME_SFX()); 
									bodyMap.put("BSDL_USER_DATA2", body.getBSDL_USER_DATA2()); 
									
									String recordType = body.getSBSB_ID()+"_"+"15"; 
									
									mapOfBodyMap.put(recordType, bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
									recordCounts=recordCounts+1;
								}
							}
														
								else if(s.equals("20")){
									try {
										File file1 = new File(tempFilePath);
										FileWriter fileWriter = new FileWriter(file1);
										fileWriter.write(line);
										
										fileWriter.flush();
										fileWriter.close();
									} catch (IOException e) {
										e.printStackTrace();
									}
									recordsMap=ffpExtract.getFlatFileData(ffDefinition20);		
									for(Object record:recordsMap.get("Body")){
																			
										BscaCare1stMMFlatFileBody20 body = (BscaCare1stMMFlatFileBody20)record;
										SortedMap<String,String> bodyMap=new TreeMap<String,String>();
										
										bodyMap.put("WMDS_TEXT1", body.getWMDS_TEXT1()); 
										bodyMap.put("GRGR_ID", body.getGRGR_ID()); 
										bodyMap.put("SBSB_ID", body.getSBSB_ID()); 
										bodyMap.put("MEME_SFX", body.getMEME_SFX()); 
										bodyMap.put("SBAD_ADDR1", body.getSBAD_ADDR1()); 
										bodyMap.put("SBAD_CITY", body.getSBAD_CITY()); 
										bodyMap.put("SBAD_STATE", body.getSBAD_STATE()); 
										bodyMap.put("SBAD_ZIP", body.getSBAD_ZIP()); 
										
										String recordType = body.getSBSB_ID()+"_"+"20"; 
										
										mapOfBodyMap.put(recordType, bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
										recordCounts=recordCounts+1;
									}
								}
									
				else if(s.equals("26")){
					try {
						File file1 = new File(tempFilePath);
						FileWriter fileWriter = new FileWriter(file1);
						fileWriter.write(line);
						
						fileWriter.flush();
						fileWriter.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					recordsMap=ffpExtract.getFlatFileData(ffDefinition26);		
					for(Object record:recordsMap.get("Body")){
															
						BscaCare1stMMFlatFileBody26 body = (BscaCare1stMMFlatFileBody26)record;
						SortedMap<String,String> bodyMap=new TreeMap<String,String>();
						
						
						bodyMap.put("WMDS_TEXT1", body.getWMDS_TEXT1()); 
						bodyMap.put("GRGR_ID", body.getGRGR_ID()); 
						bodyMap.put("SBSB_ID", body.getSBSB_ID()); 
						bodyMap.put("MEME_SFX", body.getMEME_SFX()); 
						bodyMap.put("REC_TYP_CD", body.getREC_TYP_CD()); 
						bodyMap.put("MSP_RSN_CD", body.getMSP_RSN_CD()); 
						bodyMap.put("SBMT_EFF_DT", body.getSBMT_EFF_DT()); 
						bodyMap.put("TERM_DT", body.getTERM_DT()); 
						bodyMap.put("RX_BIN_NBR", body.getRX_BIN_NBR());
						bodyMap.put("RX_PCN_NBR", body.getRX_PCN_NBR());
						bodyMap.put("GRP_POL_NBR", body.getGRP_POL_NBR());
						bodyMap.put("RX_ID_NBR", body.getRX_ID_NBR());
						bodyMap.put("PERS_CD", body.getPERS_CD());
						
						String recordType = body.getSBSB_ID()+"_"+"26"; 
						mapOfBodyMap.put(recordType, bodyMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
						recordCounts=recordCounts+1;
					}}
										
					else if(s.equals("30")){
						try {
							File file1 = new File(tempFilePath);
							FileWriter fileWriter = new FileWriter(file1);
							fileWriter.write(line);
							
							fileWriter.flush();
							fileWriter.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
						recordsMap=ffpExtract.getFlatFileData(ffDefinition30);		
						for(Object record:recordsMap.get("Body")){
																
							BscaCare1stMMFlatFileBody30 body = (BscaCare1stMMFlatFileBody30)record;
							SortedMap<String,String> bodyMap=new TreeMap<String,String>();
							
							bodyMap.put("WMDS_TEXT1", body.getWMDS_TEXT1()); 
							bodyMap.put("GRGR_ID", body.getGRGR_ID()); 
							bodyMap.put("SBSB_ID", body.getSBSB_ID()); 
							bodyMap.put("MEME_SFX", body.getMEME_SFX()); 
							bodyMap.put("C30_88_102", body.getC30_88_102()); 
							
							String recordType = body.getSBSB_ID()+"_"+"30"; 
							mapOfBodyMap.put(recordType, bodyMap);
							recordCounts=recordCounts+1;
						} }
					else if(s.equals("35")){
						try {
							File file1 = new File(tempFilePath);
							FileWriter fileWriter = new FileWriter(file1);
							fileWriter.write(line);
							
							fileWriter.flush();
							fileWriter.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
						recordsMap=ffpExtract.getFlatFileData(ffDefinition35);		
						for(Object record:recordsMap.get("Body")){
																
							BscaCare1stMMFlatFileBody35 body = (BscaCare1stMMFlatFileBody35)record;
							SortedMap<String,String> bodyMap=new TreeMap<String,String>();
							
							bodyMap.put("WMDS_TEXT1", body.getWMDS_TEXT1()); 
							bodyMap.put("GRGR_ID", body.getGRGR_ID()); 
							bodyMap.put("SBSB_ID", body.getSBSB_ID()); 
							bodyMap.put("MEME_HICN", body.getMEME_HICN());
							//System.out.println("bodyMap:"+bodyMap);
							String recordType = body.getSBSB_ID()+"_35"; 
							mapOfBodyMap.put(recordType, bodyMap);
							recordCounts=recordCounts+1;
							 
						}}	
					else if(s.equals("16")){
						try {
							File file1 = new File(tempFilePath);
							FileWriter fileWriter = new FileWriter(file1);
							fileWriter.write(line);
							
							fileWriter.flush();
							fileWriter.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
						recordsMap=ffpExtract.getFlatFileData(ffDefinition16);		
						for(Object record:recordsMap.get("Body")){
																
							BscaCare1stMMFlatFileBody16 body = (BscaCare1stMMFlatFileBody16)record;
							SortedMap<String,String> bodyMap=new TreeMap<String,String>();
							
							bodyMap.put("WMDS_TEXT1", body.getWMDS_TEXT1()); 
							bodyMap.put("GRGR_ID", body.getGRGR_ID()); 
							bodyMap.put("SBSB_ID", body.getSBSB_ID()); 
							bodyMap.put("Processing_tag_begin_date", body.getProcessing_tag_begin_date());
							bodyMap.put("Processing_tag_end_date", body.getProcessing_tag_end_date());
							
							//System.out.println("bodyMap:"+bodyMap);
							String recordType = body.getSBSB_ID()+"_16"; 
							mapOfBodyMap.put(recordType, bodyMap);
							recordCounts=recordCounts+1;
							 
						}
						}
						else if(s.equals("36")){
							try {
								File file1 = new File(tempFilePath);
								FileWriter fileWriter = new FileWriter(file1);
								fileWriter.write(line);
								
								fileWriter.flush();
								fileWriter.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
							recordsMap=ffpExtract.getFlatFileData(ffDefinition36);		
							for(Object record:recordsMap.get("Body")){
																	
								BscaCare1stMMFlatFileBody36 body = (BscaCare1stMMFlatFileBody36)record;
								SortedMap<String,String> bodyMap=new TreeMap<String,String>();
								
								bodyMap.put("WMDS_TEXT1", body.getWMDS_TEXT1()); 
								bodyMap.put("GRGR_ID", body.getGRGR_ID()); 
								bodyMap.put("SBSB_ID", body.getSBSB_ID()); 
								bodyMap.put("ESRD_Indicator1", body.getESRD_Indicator1()); 
								
								//System.out.println("bodyMap:"+bodyMap);
								String recordType = body.getSBSB_ID()+"_36"; 
								mapOfBodyMap.put(recordType, bodyMap);
								recordCounts=recordCounts+1;
								 
							}
							}
						
							
								else if(s.equals("45")){
									try {
										File file1 = new File(tempFilePath);
										FileWriter fileWriter = new FileWriter(file1);
										fileWriter.write(line);
										
										fileWriter.flush();
										fileWriter.close();
									} catch (IOException e) {
										e.printStackTrace();
									}
									recordsMap=ffpExtract.getFlatFileData(ffDefinition45);		
									for(Object record:recordsMap.get("Body")){
																			
										BscaCare1stMMFlatFileBody45 body = (BscaCare1stMMFlatFileBody45)record;
										SortedMap<String,String> bodyMap=new TreeMap<String,String>();
										
										bodyMap.put("WMDS_TEXT1", body.getWMDS_TEXT1()); 
										bodyMap.put("GRGR_ID", body.getGRGR_ID()); 
										bodyMap.put("SBSB_ID", body.getSBSB_ID()); 
										bodyMap.put("MEME_SFX", body.getMEME_SFX()); 
										bodyMap.put("MERS_COV_EFF_DT", body.getMERS_COV_EFF_DT()); 
										bodyMap.put("MERS_COV_TERM_DT", body.getMERS_COV_TERM_DT()); 
										bodyMap.put("CMC_MERS_RETIRE", body.getCMC_MERS_RETIRE()); 
										
										subID=body.getSBSB_ID();
										//System.out.println("bodyMap:"+bodyMap);
										String recordType = body.getSBSB_ID()+"_"+"45"; 
										
										mapOfBodyMap.put(recordType, bodyMap);  
										// Inserting the complete mapOfBodyMap into flatFileValuesMap keys as Subscriber ids
										flatFileValuesMap.put(subID,mapOfBodyMap);
										recordCounts=recordCounts+1;
									}	
									
									}
								
						}
						
					}
					
					catch(Exception e){
						e.printStackTrace();
					}
					//Using the recordCounts to display rows present in the file in report
					System.out.println("^^^^^^^^^ recordCounts ^^^^^^^^^^^^^^^^: "+ recordCounts);
					reportInit("ARGUS Member File To DbValidation ", ": recordCounts Validation" );
					//using filename displaying the File Path in report
					logger.log(LogStatus.INFO, "File Path: " + strInputFileName);
					logger.log(LogStatus.PASS,"Total number of records/rows present in the file: "+ recordCounts +" -------Status : Pass");
		}
		
		else if(strFileType.contains("HCO"))
		{
			System.out.println("file type HCO");
		}
		else if(strFileType.contains("Salesforce_PCP_Assign")){
			System.out.println("file type Salesforce_PCP_Assign");
		}
		// Returning SortedMap<String, SortedMap<String, String>> with 834 file values
		System.out.println("*********************** flatFileValuesMap ************************************\n"+flatFileValuesMap);
		
		return flatFileValuesMap;
	}
	// Fetching Argus Group file data into a sorted map
	public void getGroupFileData(String strCompleteFilePath, String strInputFileName,Map<String, String> data,String dValue) throws Exception
	{
		
		String strFileType;
		
		strCompleteFilePath = strInputFileName;
		//to get exact file name from file path
		String strInputExactFileName = strInputFileName.substring(strInputFileName.lastIndexOf("\\") + 1);
		// To get Argus group  file type
		strFileType = fileType834(strInputExactFileName);
		//Declaring a map for file data
		SortedMap<String,List<Object>> recordsMap=new TreeMap<String,List<Object>>();

		// Checking for the 834 file type
		if (strFileType.contains("834")) {
			System.out.println("Inside 834 file type");	
		}
		//Checking for member and Group files
		else if(strFileType.contains("GRP"))
		{
			int recordCounts=0;
			
					try {
						//this will set up the FileReader of ffpojo library
						ffpExtract = new BscaCare1stMMFlatFileReader(strCompleteFilePath);
						// Creating objects for all record types classes
						FlatFileReaderDefinition ffDefinition02 = new FlatFileReaderDefinition(BscaCare1stMMFlatFileBody02.class);
						// Creating file object to read the Argus file
						File file=new File(strCompleteFilePath);
						Scanner sc= new Scanner(file);
						
						String tempFilePath = System.getenv("TEMP_FILE");
						int flag=0;
						String fValue="";
						 String fGRGR_ID="";
						 String dbGRGR_ID="";
						 String fCSCS_ID="";
						 String dbCSCS_ID="";
						 String fCSPI_ID="";
						 String dbCSPI_ID="";
						 String fCSPB_BEG_DT="";
						 String dbCSPB_BEG_DT="";
						 String fCSPB_END_DT="";
						 String dbCSPB_END_DT="";
						 //Iterating each lines of a file
						while(sc.hasNextLine()){
							
							String line=sc.nextLine();
							String s=line.substring(0, 2);
							
							if(s.equals("00") || s.equals("01") || s.equals("90") || s.equals("99")){
								continue;
							}
							
							else if(s.equals("02")){
								try {
									recordCounts=recordCounts+1;
									
									File file1 = new File(tempFilePath);
									FileWriter fileWriter = new FileWriter(file1);
									fileWriter.write(line);
									
									fileWriter.flush();
									fileWriter.close();
								} 
								catch (IOException e) {
									e.printStackTrace();
								}
								recordsMap=ffpExtract.getFlatFileData(ffDefinition02);
								//storing the field records of a line in map, key:Body, Value:Object of records list
								for(Object record:recordsMap.get("Body")){
									
									BscaCare1stMMFlatFileBody02 body = (BscaCare1stMMFlatFileBody02)record;
									
//									groupFileValuesMap.put(Integer.toString(recordCounts),bodyMap);
									
							 fValue=body.getGRGR_VAL()+body.getDATE();
							 System.out.println("file value: "+fValue);
							  fGRGR_ID=fValue.substring(0,8);
							  dbGRGR_ID=dValue.substring(0,8);
							  fCSCS_ID=fValue.substring(8,12);
							  dbCSCS_ID=dValue.substring(8,12);
							  fCSPI_ID=fValue.substring(12,20);
							  dbCSPI_ID=dValue.substring(12,20);
							  fCSPB_BEG_DT=fValue.substring(20,28);
							  dbCSPB_BEG_DT=dValue.substring(20,28);
							  fCSPB_END_DT=fValue.substring(28,36);
							  dbCSPB_END_DT=dValue.substring(28,36);
							//Comparing file value with db value
							if(fValue.equalsIgnoreCase(dValue)){
								flag=1;
								reportInit("ARGUS Group File To Db Validation ", ": File Name :  " +strFileType);
								System.out.println("*** File vaue: "+fValue+"---DB vlaue: "+dValue);
								//Displaying all field values with Pass/Fail status in report
								logger.log(LogStatus.PASS,"Critical Field File Values : "+ fValue +"-------DB values : "+dValue+"-------Status : Pass");
								logger.log(LogStatus.PASS,"Element Name : Group ID|----------FileValue : "+fGRGR_ID+"----------DBValue : "+ dbGRGR_ID+"-------Status : Pass");
								logger.log(LogStatus.PASS,"Element Name : CSCS_ID |----------FileValue : "+fCSCS_ID+"----------DBValue : "+ dbCSCS_ID+"-------Status : Pass");
								logger.log(LogStatus.PASS,"Element Name : CSPI_ID|----------FileValue : "+fCSPI_ID+"----------DBValue : "+ dbCSPI_ID+"-------Status : Pass");
								logger.log(LogStatus.PASS,"Element Name : Deductible Benefit Period Begin Date|----------FileValue : "+fCSPB_BEG_DT+"----------DBValue : "+ dbCSPB_BEG_DT+"-------Status : Pass");
								logger.log(LogStatus.PASS,"Element Name : Deductible Benefit Period End Date|----------FileValue : "+fCSPB_END_DT+"----------DBValue : "+ dbCSPB_END_DT+"-------Status : Pass");
								//Displaying LOB in report
								if(body.getLOB().equalsIgnoreCase("0780") || body.getLOB().equalsIgnoreCase("0781") || body.getLOB().equalsIgnoreCase("0782")){
									System.out.println("*** LOB: "+body.getLOB());
									logger.log(LogStatus.PASS,"LOB Id : "+ body.getLOB() +"-------Status : Pass");
									
								}
								else{
									System.out.println("*** Failed for LOB: ***"+body.getLOB());
									logger.log(LogStatus.FAIL,"LOB Id : "+ body.getLOB() +"-------Status : Fail");
								}
							}
							}}
								
							} 
		
						//if test case fails then below details will be displayed in report
						if(flag==0){
							reportInit("ARGUS Group File To Db Validation ", ": File Name :  " +strFileType);
							System.out.println("*** Failed");
							logger.log(LogStatus.FAIL,"Critical Field File Values : "+ fValue +"-------DB values : "+dValue+"-------Status : Fail");
							logger.log(LogStatus.FAIL,"Element Name : Group ID|----------FileValue : "+fGRGR_ID+"----------DBValue : "+ dbGRGR_ID+"-------Status : Fail");
							logger.log(LogStatus.FAIL,"Element Name : CSCS_ID |----------FileValue : "+fCSCS_ID+"----------DBValue : "+ dbCSCS_ID+"-------Status : Fail");
							logger.log(LogStatus.FAIL,"Element Name : CSPI_ID|----------FileValue : "+fCSPI_ID+"----------DBValue : "+ dbCSPI_ID+"-------Status : Fail");
							logger.log(LogStatus.FAIL,"Element Name : Deductible Benefit Period Begin Date|----------FileValue : "+fCSPB_BEG_DT+"----------DBValue : "+ dbCSPB_BEG_DT+"-------Status : Fail");
							logger.log(LogStatus.FAIL,"Element Name : Deductible Benefit Period End Date|----------FileValue : "+fCSPB_END_DT+"----------DBValue : "+ dbCSPB_END_DT+"-------Status : Fail");
							
						}
						
						
					}
					catch (IOException e) {
						e.printStackTrace();
					}
					//Counting the no of records is displayed in report
					System.out.println("Total recordcounts: "+recordCounts);
					reportInit("ARGUS Group File recordCounts Validation ", ": File Name :  " +strFileType); 
					logger.log(LogStatus.PASS,"Detail Record Count : "+ recordCounts +"-------Status : Pass");
					}
		
		}


/**
 * Changing 834 EDI file format when it is having one line
 * @param strFlatFileCompletePath: 834 file complete path
 * @throws Exception: To capture exception
 */
public void fileFormatChange834(String strFlatFileCompletePath) throws Exception
{	
	FileWriter fileWriter = null;
	FileReader fileReader  = null;
	BufferedReader bufferedReader = null;
	
	try{
		File inputFile = new File(strFlatFileCompletePath);
		String strLines = "";
		String line = "";
		//Checking for the file existence
		if (!inputFile.exists()) { 
			  throw new IllegalStateException("File not found: " + strFlatFileCompletePath);
		  } 
		else 
		{
			fileReader =  new FileReader(inputFile);
			bufferedReader =        new BufferedReader(fileReader);
			int intICounter = 0;
			//Reading each line from the file
			while((line = bufferedReader.readLine())!=null)
			{
				strLines = strLines + line;
				intICounter += 1;
				//Checking for single line 834 file
				if(intICounter > 1)
				{
					bufferedReader.close();
					return;
				}
			}
		
			byte [] strBytes = strLines.getBytes();
			String strAllLines = new String (strBytes,StandardCharsets.UTF_8);
			//Replacing "~" symbol with "~\r\n"
			String strFormatLines = strAllLines.replaceAll("~", "~\r\n");
			fileWriter = new FileWriter(strFlatFileCompletePath);
			//Writing the data once again into the file after changes
			fileWriter.write(strFormatLines);
		  }
		
	}
	//For capturing exception
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try{
			//Closing all opened file objects
			fileReader.close();
			fileWriter.close();
			bufferedReader.close();
		}
		catch(Exception ex)
		{
			//ex.printStackTrace();
		}
	}
}

/**
 * @param testFlatFileCompletePath: File complete path
 * @param strCINNNumber: To capture specific subscriber section
 * @param strFileName: 834 file type
 * @return: List of subscriber lines
 * @throws Exception" To capture the exception
 */
public  List<String> parse834File(String testFlatFileCompletePath,String strCINNNumber, String strFileName) throws Exception {
	
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 //For checking file existence
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
		  		//Changing the layout when it is having in one single line
		  		fileFormatChange834(testFlatFileCompletePath);
				  if(strFileName.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834"))
				  {
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader = new BufferedReader(fileReader);
						boolean flag=false;
						// Reading each line in the file 
				        while((line = bufferedReader.readLine()) != null) {
				        	//Checking for the CINN Number
				        	if(line.contains(strCINNNumber)){
				        		flag=true;
				        	}
				        	//Checking for the starting line for each subscriber section
				        	if(line.startsWith("ST")){
				        		if(flag){
				        			break;
				        		}else{
				        			//To clear the records if it is not matches to the provided CINN number
				        			rowsList.clear();
				        		}
				        	}
				        	//Adding lines to the records list
				        	rowsList.add(line);
				       		}   
				  }
				  //To capture DHCS file specific subscriber lines
				  else if(strFileName.contains("DHCS"))
				  {
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader =  new BufferedReader(fileReader);
						boolean flag=false;
						// Reading each line in the file 
				        while((line = bufferedReader.readLine()) != null) {
				        	//Checking for the CINN Number
				        	if(line.contains(strCINNNumber)){
				        		flag=true;
				        	}
				        	//Checking for the starting line for each subscriber section
				        	if(line.startsWith("INS*Y*18*")){
				        		if(flag){
				        			break;
				        		}else{
				        			//To clear the records if it is not matches to the provided CINN number
				        			rowsList.clear();
				        		}
				        	}
				        	//Adding lines to the records list
				        	rowsList.add(line);
				       		}  
				  }
				  else
				  {
					  //Printing line when user has selected invalid file
					  System.out.println("Please select valid file type to retrieve data from flat file ");
				  }

  	}
	 //To close the bufferedReader object
	 if(bufferedReader!=null)
		 bufferedReader.close();

	return rowsList;
}


/**
 * To capture CINN Numbers from 834 file
 * @param testFlatFileCompletePath: 834 File complete path
 * @param strFileName: 834 file type
 * @return: List of CINN Numbers
 * @throws Exception: Throwing exception
 */
public  List<String> parse834FileForCINNNumbers(String testFlatFileCompletePath, String strFileName) {
	
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	try {
	//Checking for the file existence
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
		  		//Changing the layout when it is not expected
					fileFormatChange834(testFlatFileCompletePath);
		  		//To capture CINN Numbers from LACare file
				  if(strFileName.equalsIgnoreCase("LACounty_Medi-Cal_Members(LACare)834"))
				  {
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader = new BufferedReader(fileReader);
						//Looping through all lined for checking CINN Number line
				        while((line = bufferedReader.readLine()) != null) {
				        	if(line.startsWith("NM1*IL*1*")){
				        		//Adding CINN number to the list
				        		rowsList.add(line.split("\\*")[9].replace("~", ""));
				        	}
				       	}   
				  }
				//To capture CINN Numbers from DHCS file
				  else if(strFileName.contains("DHCS"))
				  {
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader = new BufferedReader(fileReader);
						//Looping through all lined for checking CINN Number line
				        while((line = bufferedReader.readLine()) != null) {
				        	if(line.startsWith("REF*0F*")){
				        		//Adding CINN number to the list
				        		rowsList.add(line.split("\\*")[2].replace("~", ""));
				        	}
				       	}  
				  }
				  else
				  {
					  System.out.println("Please select valid file type to retrieve data from flat file ");
				  }

  	}
	 //To close the bufferReader object
	if(bufferedReader != null)
		bufferedReader.close();

	}
	//To capture and print the exception
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//For returning list of CINN numbers 
	return rowsList;
}


/**
 * To find file type for Input file
 * @param strFileName: Name of the file
 * @return: File name used for coding
 */
public String fileType834(String strFileName)
{	
	
	if(strFileName.contains("\\")){
		strFileName = strFileName.substring(strFileName.lastIndexOf("\\") + 1);
	}
	//Checking for the expected file name
	if(strFileName.contains("CFST.D"))
		return "LACounty_Medi-Cal_Members(LACare)834";
	else if(strFileName.contains("DHCS834-DA-") && strFileName.contains("Care1st-SanDiego"))
		return "SDCounty_Medi-Cal_Members(DHCS)834";
	else if(strFileName.contains("DHCS834-DA-") && strFileName.contains("C1CMC-LosAngeles"))
		return "LACounty_Cal-MediConnect_Members(DHCS)834";
	else if(strFileName.contains("DHCS834-DA-") && strFileName.contains("C1CMC-SanDiego"))
		return "SDCounty_Cal-MediConnect_Members(DHCS)834";
	else if(strFileName.contains("Monthly_Salesforce_PCP_Assign"))
		return "Monthly_Salesforce_PCP_Assign";
	else if(strFileName.contains(".DTRRD.D"))
		return "TRR";
	else if(strFileName.startsWith("T_"))
		return "HCO";
	else if(strFileName.contains("ARGUS"))
		return strFileName;
	else
		System.out.println("This file name is invalid: " + strFileName );
		return null;
}



//below method is to handle the index out of bound exception
public String  partialStringRetrieval(String strKeyName,String line,int indexValue, int intStartPos, int intEndingPos){
       
	if(!(intStartPos == 0 && intEndingPos == 0)){
		 try{
             String strValue = line.split("\\*")[indexValue].substring(intStartPos,intEndingPos).replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    return strValue;
             }
             
       }
       catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
    	   return "";
       }
	}
	else{
      
		 try{
             String strValue = line.split("\\*")[indexValue].replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    
                    return strValue;
             }
             
       }
       catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
             return "";
       }
	}
	return "";
       
}



public static  List<SortedMap<String,String>> parseFileWithOutHeaderByDelimeter(String delimeter,String testFlatFileCompletePath,String fieldColumnMappingFilePath,String mappingSheetName) throws IOException{
	
	 //String testFlatFileCompletePath="\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\SUC automation\\Required Documents\\12. SUC546265-DRX To MAM\\MAPDP_Complete_2018_20180401.bsc180401111900.txt";
	 File inputFile = new File(testFlatFileCompletePath);
	 List<SortedMap<String,String>> listOfRows=new ArrayList<SortedMap<String,String>>();
	 String line=null;
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } 
	 else {
						System.out.println("Starting of File Reading . . . . . .  . . . . ");
						//src/test/resources/TestData.xlsx
					//	new ExcelUtils("C:\\Users\\bgujja01\\bqsa32\\workspace\\Care1stMMInboundAndOutboundFileValidation\\src\\test\\resources\\FileFieldAndTableColumnMapping.xlsx","SUC580263");
						new ExcelUtilsExtended(fieldColumnMappingFilePath,mappingSheetName);
						
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						@SuppressWarnings("resource")
						BufferedReader bufferedReader =        new BufferedReader(fileReader);
				        while((line = bufferedReader.readLine()) != null) {
			                String[] columnsArray = line.split(delimeter);
				        	  
			                SortedMap<String,String> rowMap=new TreeMap<String,String>();
							int columnLength=columnsArray.length;
							for(int i=0;i<columnLength;i++){
								String fileFieldName=String.valueOf(i);
							//	System.out.println("excel Value:"+ExcelUtils.getDBColumnName(fileFieldName)+" | "+columnsArray[i]);
								
								String columnNameKey=ExcelUtilsExtended.getDBColumnName(fileFieldName);
								if(columnNameKey!=null){
								rowMap.put(columnNameKey,columnsArray[i]);	//System.out.println(rowNo+"  columnlength::"+columnLength+" index: "+i+"  "+rowsList.get(rowNo)[i]);
								}
							}
							listOfRows.add(rowMap);
			                     		}   
						
				    
 	}
	return listOfRows;
}


	
}
