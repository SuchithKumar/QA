  package com.bsc.qa.webservices.tests;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



import org.h2.engine.SysProperties;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.Edi834Utility;
import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;
import com.relevantcodes.extentreports.LogStatus;
import com.bsc.qa.webservices.utility.ExcelUtilsExtended;

public class BscaCare1stMMTest extends BaseTest implements IHookable {
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	public BscaCare1stMMTest(String inputFileName) {
		System.out.println("Inside constructor:"+inputFileName);
		this.inputFileName = inputFileName;
	}
	// ************************************** TEST
	// METHODS************************

	
	//***Main test method to validate Argus file against FACETS database.****//
	@Test()
	private void test834FileValidation() throws IOException {
		//*** Sorted map for storing file values
		SortedMap<String, SortedMap<String, SortedMap<String, String>>> flatFileValuesMap = null;
 
		// Storing Argus input file path
		String strCompleteFilePath = System.getenv("INPUT_FILE_PATH");
		System.out.println("%% strCompleteFilePath :"+strCompleteFilePath);
		//File cinn_file=new File(System.getenv("CIN_COMPLETE_FILE_PATH")+"\\file2.txt");
		
		//Creating Edi834Utility class object
		Edi834Utility edi834Utility = new Edi834Utility();
		//Declaring a map for getting excel file path 
		Map<String, String> data = null; 
		try{
			data = getData("ArgusOutFileValidation");
} 
		catch (Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try{
			// Calling this method to fetch all file data and assigning into a Sorted map
			flatFileValuesMap = edi834Utility.get834FileData(
			strCompleteFilePath, inputFileName,data);
			System.out.println("Returning final map: "+flatFileValuesMap);
			
		} 
		catch (Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
				// To get 834 file type
		String	strFileType = edi834Utility.fileType834(inputFileName);
		System.out.println("Test********************"+inputFileName);
		
		      
        // Start validation for file type "Argus"
        String grpSubID="";
        String flag1="False";
        //Checking for member file type
        if(strFileType.contains("MBR")){
        	System.out.println("%%% Executed First for MBR %%%");
        //if(strFileType.contains("ARGUS")){
        	String LOB_ID ="";
        	
        	//Retrieve's all primary keys(Subscriber ids) of flatfilevaluemap into a set
    		Set<String> keys = flatFileValuesMap.keySet();
    		String[][] dbValue=null;
        	//System.out.println("keys ****************"+keys);//to check Subscriber ids are coming
			try{
				String mappingsheet="ArgusOutFileVal";
				String dValue="";
				
				int recordCounts=0;
				//logger.log(LogStatus.INFO, "File Path : " + inputFileName);
				//Iterating into set of Sub ids
				for(String sbid:keys){
					grpSubID=sbid;
					//Displaying subs id in report
					reportInit("ARGUS Member File To Db Validation ", ": Subscriber ID :  " +sbid);
					System.out.println("$$$$$$$ SBSBID: "+sbid);
					//Storing all the keys(recordtypes) in a set of each subscribers from the map(mapofBosyMap)
					Set<String> recordTypes=flatFileValuesMap.get(sbid).keySet();
        		// Displaying the file path in report
        			logger.log(LogStatus.INFO, "File Path: " + inputFileName);
        			//Iterating  all the record types of each subscriber
        			for(String records:recordTypes)
        			{
        				//Checking data of one subscriber at a time
        			if(records.contains(sbid)){
        				recordCounts=recordCounts+1;
        				System.out.println("&&&& record type &&"+records);
        				//Storing all the keys of inner most map that is BodyMap into a set
        				Set<String> final_keys=flatFileValuesMap.get(sbid).get(records).keySet();
            			//Displaying the record type in report
            			logger.log(LogStatus.INFO, "Validating Fields of Record Type : " + records);
            			try{
            			//Iterating all the fields of a record type
        				for(String final_key:final_keys)
        				{
        					
        					//System.out.println("final key is "+final_key);//to check field names are coming for each rows
        					String final_query="";
        					String Sql_query ="";
        					//Checking LOB type
        					if(final_key.equalsIgnoreCase("LOB")){
        						String lobId=flatFileValuesMap.get(sbid).get(records).get(final_key);
        						if(lobId.equalsIgnoreCase("0780")){
        							LOB_ID = "MA";
        			        		System.out.println("-------##### ------ MA");
        			        	}
        			        	else if(lobId.equalsIgnoreCase("0781")){
        			        		LOB_ID = "MC";
        			        		System.out.println("-------##### ------ MC");
        			        	}
        			        	else if(lobId.equalsIgnoreCase("0782")){
        			        		LOB_ID = "CMC";
        			        		System.out.println("-------##### ------ CMC");
        			        	}
        						
        					}
        					//Checking "wmds_text1" field and retrieving its DB value
        					else if(final_key.equalsIgnoreCase("wmds_text1")){
       						 // Fetching query from a data sheet
        						Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet(final_key.toUpperCase(),mappingsheet);
       						 	//Making final query after adding subscriber id
        						final_query=Sql_query+" in ('"+sbid+"')";
        					
       						 try{
       							 //Running query in Database
    			        			dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
    			        			
    			        			//System.out.println("**** DB Value *** "+dbValue[0][0]);
    			        			String Uniqueid1=dbValue[0][0];
    			        			String Uniqueid2=dbValue[0][1];
    			        			String Uniqueid3=dbValue[0][2];
    			        			//System.out.println("dbValue1,2,3 : "+Uniqueid1+"\t"+Uniqueid2+"\t"+Uniqueid3);
    			        			
    			        			Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet("WMDS_TEXT2".toUpperCase(),mappingsheet);
    			        			
    			        			final_query=Sql_query+" GRGR_CK = '"+Uniqueid1+"' and CSCS_ID = '"+ Uniqueid2+"' and CSPI_ID = '"+Uniqueid3+"'";
    			        			dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
    			        			
    			        			dValue=dbValue[0][0];
    			        			
    			        			Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet("WMDS_TEXT3".toUpperCase(),mappingsheet);
    			        			final_query=Sql_query+" in ('"+dValue+"')";
    			        			
    			        			dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
    			        			dValue= dbValue[0][0]; 
    			        			
    			        			dValue=dValue.substring(0,4);
    			        			
       						 }
    			        			catch(Exception e)
    			        			{
    			        				dValue="NULL";
    			        				System.out.println("-------------- query is returning null -------");
    			        			}
       					}
        					//-----------------------------------------------
        					else if(final_key.equalsIgnoreCase("C30_88_102") ){
        						
          						 Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet(final_key.toUpperCase(),mappingsheet);
       						 
       						 	final_query=Sql_query+" in ('"+sbid+"')";
          						 try{
          							dValue="NULL";
       			        			dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
       			        			//System.out.println("**** DB Value *** "+dbValue[0][0]);
       			        			String Uniqueid1=dbValue[0][0];
       			        			String Uniqueid2=dbValue[0][1];
       			        			String Uniqueid3=dbValue[0][2];
       			        			String Uniqueid4=dbValue[0][3];
       			        			Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet("TARGET_CODE".toUpperCase(),mappingsheet);
       			        			final_query=Sql_query+" '"+Uniqueid1+"|"+ Uniqueid2+"|"+Uniqueid3+"|"+Uniqueid4+"'";
       			        			dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
       			        			dValue=dbValue[0][0]+"  ";
       			        			System.out.println("%%% After 1st query of C30 "+dValue);
       			        			if(LOB_ID.equalsIgnoreCase("MA")){
	       			        			Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet("MEMD_MCTR_PBP".toUpperCase(),mappingsheet);
	       			        			final_query=Sql_query+" in ('"+sbid+"')";
	       			        			//System.out.println("-------------$$$----- final query of C30_88_102 : "+final_query);
	       			        			dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
	       			        			String dbValue1 = dbValue[0][0];
	       			        			dValue=dValue+dbValue1;
	       			        			System.out.println("%%% final C30 value "+dValue);
       			        			}
       			        			else{
       			        				System.out.println("Inside C30 of  MC/CMC");
       			        				Sql_query= new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", mappingsheet).getQueryFromMappingSheet("CUSTM_DTA_ELEM_VAL_TXT".toUpperCase(), mappingsheet);
       		        					final_query=Sql_query+" in ('"+sbid+"') order by 2 asc";
       		        					//System.out.println("@@@@@ Final final query: "+final_query);
       		        					dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
       		        					if(dbValue[0][0].length()==1){
       		        						dbValue[0][0]=dbValue[0][0]+"  ";
       		        					}
       		        					else if(dbValue[0][0].length()==2){
       		        						dbValue[0][0]=dbValue[0][0]+" ";
       		        					}
       		        					
    				        			dValue =dValue+"   "+dbValue[0][0]+dbValue[1][0];
    				        			//+dbValue[2][0]
    				        			System.out.println("%%% final C30 value MC/CMC "+dValue);
       			        			}
          						 }
       			        			catch(Exception e)
       			        			{
       			        				//dValue="NULL";
       			        				System.out.println("-------------- query is returning null ------- "+final_key+"dbValue: "+dValue);
       			        			}
          					}
        					else if(final_key.equalsIgnoreCase("ESRD_Indicator1") ){
        				try{
        						if(LOB_ID.equalsIgnoreCase("MA")){
	        						Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet("ESRD_Indicator1".toUpperCase(),mappingsheet);
	        						final_query=Sql_query+" in ('"+sbid+"')";
	         						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
	      			        		dValue=dbValue[0][0];
        						}	
      			        		else if(LOB_ID.equalsIgnoreCase("CMC")){
      			        			Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet("ESRD_Indicator2".toUpperCase(),mappingsheet);
            						final_query=Sql_query+" in ('"+sbid+"')";
             						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
          			        		dValue=dbValue[0][0];
          			        		
      			        			}
        						if( !dValue.equalsIgnoreCase("NULL")){
      			        			dValue="1";
      			        		}
        						/*else{
        							dValue="1";
        						}*/
         						 }
      			        			catch(Exception e)
      			        			{
      			        				dValue="NULL";
      			        				System.out.println("-------------- query is returning null ------- "+final_key);
      			        			}
         					}
        					else if(final_key.equalsIgnoreCase("BSDL_USER_DATA2") ){
                				try{
                						if(LOB_ID.equalsIgnoreCase("MA")){
        	        						Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet(final_key.toUpperCase(),mappingsheet);
        	        						final_query=Sql_query+" in ('"+sbid+"')";
        	         						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
        	      			        		dValue=dbValue[0][0];
                						}	
              			        		else if(LOB_ID.equalsIgnoreCase("CMC")||LOB_ID.equalsIgnoreCase("MC")){
              			        			Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet("BSDL_USER_DATA2_MC_CMC".toUpperCase(),mappingsheet);
                    						final_query=Sql_query+" in ('"+sbid+"')";
                     						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
                  			        		dValue=dbValue[0][0];
                  			        		
              			        			}
                						}
              			        			catch(Exception e)
              			        			{
              			        				dValue="NULL";
              			        				System.out.println("-------------- query is returning null ------- "+final_key);
              			        			}
                 					}
        					else if(final_key.equalsIgnoreCase("Dual_Coverage_indicator")){
                				try{
                					//dValue="NULL";
                					if(LOB_ID.equalsIgnoreCase("MA")){
                							System.out.println("((((((((( inside out 780");
        	        						Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet(final_key.toUpperCase(),mappingsheet);
        	        						final_query=Sql_query+" in ('"+sbid+"')";
        	        						//System.out.println("-----0000-----Dual_Coverage_indicator: "+final_query);
        	         						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
        	      			        		dValue=dbValue[0][0];
        	      			        		dValue=dValue.trim();
        	      			        		System.out.println("---****---------Dual_Coverage_indicator DB Value: "+dValue);
        	      			        		
                					}
              			        		else if(LOB_ID.equalsIgnoreCase("MC")){
              			        			System.out.println("((((((((( inside out 781");
              			        			Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet("Dual_Coverage_indicator2".toUpperCase(),mappingsheet);
                    						final_query=Sql_query+" in ('"+sbid+"')";
                    						//System.out.println("-----0000-----Dual_Coverage_indicator: "+final_query);
                     						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
                  			        		dValue=dbValue[0][0];
                  			        		if(dValue.equalsIgnoreCase("0")||dValue.equalsIgnoreCase("4")||dValue.equalsIgnoreCase("5")||dValue.equalsIgnoreCase("6")||dValue.equalsIgnoreCase("8"))
                    						{
                    							dValue="N";
                    						}
                    						if(dValue.equalsIgnoreCase("1")||dValue.equalsIgnoreCase("2")||dValue.equalsIgnoreCase("3")||dValue.equalsIgnoreCase("7")||dValue.equalsIgnoreCase("9"))
                    						{
                    							dValue="S";
                    						}
                  			        		}
              			        		else if(LOB_ID.equalsIgnoreCase("CMC")){
              			        			dValue="N";
              			        		}
                						
                				}
                				catch(Exception e)
			        			{
			        				dValue="NULL";
			        				System.out.println("-------------- query is returning null ------- "+final_key);
			        			}
                				}
        					 else if(final_key.equalsIgnoreCase("SBMT_EFF_DT")||final_key.equalsIgnoreCase("TERM_DT") ||final_key.equalsIgnoreCase("MSP_RSN_CD")||final_key.equalsIgnoreCase("Processing_tag_begin_date")||final_key.equalsIgnoreCase("Processing_tag_end_date")){
                				try{
                							Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet(final_key.toUpperCase(),mappingsheet);
        	        						final_query=Sql_query+" in ('"+sbid+"')"+"order by 1 desc";
        	        						//System.out.println("((((( final_query of"+final_key+" : "+final_query);
        	         						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
        	      			        		dValue=dbValue[0][0];
                				}
                				catch(Exception e)
			        			{
			        				dValue="NULL";
			        				System.out.println("-------------- query is returning null ------- "+final_key);
			        			}
        					 }
        					 else if(final_key.equalsIgnoreCase("REC_TYP_CD") || final_key.equalsIgnoreCase("PERS_CD") ){
                 				try{
                 						
         	        						Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet(final_key.toUpperCase(),mappingsheet);
         	        						final_query=Sql_query+" in ('"+sbid+"')"+"order by 1 asc";
         	         						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
         	      			        		dValue=dbValue[0][0];
                 				}
                 				catch(Exception e)
 			        			{
 			        				dValue="NULL";
 			        				System.out.println("-------------- query is returning null ------- "+final_key);
 			        			}
         					 }
        					 else if(final_key.equalsIgnoreCase("SBAD_ADDR1")){
                  				try{
                  						
          	        						Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet(final_key.toUpperCase(),mappingsheet);
          	        						final_query=Sql_query+" in ('"+sbid+"')"+"order by HIST_TERM_ID asc";
          	         						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
          	      			        		dValue=dbValue[0][0];
                  				}
                  				catch(Exception e)
  			        			{
  			        				dValue="NULL";
  			        				System.out.println("-------------- query is returning null ------- "+final_key);
  			        			}
          					 }
        					 else if(final_key.equalsIgnoreCase("GRP_POL_NBR")){
        						//continue;}
        						 try{
                   						//System.out.println("%%%% Inside GRP_POL_NBR %%%%");
           	        						Sql_query=new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx",mappingsheet).getQueryFromMappingSheet(final_key.toUpperCase(),mappingsheet);
           	        						final_query=Sql_query+" in ('"+sbid+"') order by 1 asc";
           	        						//System.out.println("%%% Final query : "+final_query);
           	         						dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
           	      			        		dValue=dbValue[0][0];
                   				}
                   				catch(Exception e)
   			        			{
   			        				dValue="NULL";
   			        				System.out.println("-------------- query is returning null ------- "+final_key);
   			        			}
           					 }
        				else{
        					try{
	        					Sql_query= new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", mappingsheet).getQueryFromMappingSheet(final_key.toUpperCase(), mappingsheet);
	        					final_query=Sql_query+" in ('"+sbid+"')";
	       					
				        			dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
				        			dValue = dbValue[0][0];
				        			
				        			if(dValue.equalsIgnoreCase("null")){
				        				System.out.println("****** Query is returning Empty : "+final_key);
				        			}
				        			
				        			if(final_key.equalsIgnoreCase("MEME_SFX")&& dValue.equalsIgnoreCase("0"))
				        			{
				        				dValue=dValue+"0";
				        			}
				        			else if(final_key.equalsIgnoreCase("MEME_SFX")&& dValue.equalsIgnoreCase("1"))
				        			{
				        				dValue="0"+dValue;
				        			}
				        			
				        			else if(final_key.equalsIgnoreCase("CMC_MERS_RETIRE")&& !dValue.equalsIgnoreCase("NULL")){
		        						dValue="Y";
		        						System.out.println("^^^^ dbvalue of CMC_MERS_RETIRE "+dValue);
		        					}
				        			else if(final_key.equalsIgnoreCase("MERS_COV_EFF_DT")&& dValue.equalsIgnoreCase("00")){
		        						dValue="00000000";
		        						//System.out.println("^^^^ dbvalue of MERS_COV_EFF_DT "+dValue);
		        					}
				        			else if(final_key.equalsIgnoreCase("MERS_COV_TERM_DT")&& dValue.equalsIgnoreCase("00")){
				        				dValue="00000000";
				        				//System.out.println("^^^^ dbvalue of MERS_COV_TERM_DT "+dValue);
		        					}
				        			
	        					}
				        			catch(Exception e)
				        			{
				        				if(final_key.equalsIgnoreCase("CMC_MERS_RETIRE")){
				        					dValue="N";
				        				}
				        				else{
				        					dValue="NULL";
				        				}
				        				System.out.println("-------------- query is returning null ------- "+final_key);
				        			}
	        					}
        					try{
       					String fValue = flatFileValuesMap.get(sbid).get(records).get(final_key);
    					 
       					dValue=dValue.trim();
       					//fValue=fValue.trim();
    					
    					if(final_key.equalsIgnoreCase("REC_TYP_CD")&&dValue.equalsIgnoreCase("SUP")){
    						dValue="S";
    						
    					}
    					else if(final_key.equalsIgnoreCase("REC_TYP_CD")&&dValue.equalsIgnoreCase("PRM")){
    						dValue="P";
    						
    					}
    					else if(final_key.equalsIgnoreCase("Dual_Coverage_indicator")){
			        			if(dValue.equalsIgnoreCase("PRM") || dValue.equalsIgnoreCase("SUP")){
			        				dValue="N";
			        			System.out.println("---****--------- Final Dual_Coverage_indicator DB Value: "+dValue);
			        			}}
    					else if(final_key.equalsIgnoreCase("SBAD_ZIP")){
    						dValue=dValue.substring(0,5);
		        			System.out.println("---****--------- Final SBAD_ZIP DB Value: "+dValue);
		        			}
        					}
        					catch (Exception e) {
        						System.out.println("Failed at 450 due to "+e+"  "+final_key);
        						logger.log(LogStatus.PASS,"Element Name : "+ final_key +"|----------Reason: "+final_key+" -------Status : Pass ---- Value from the file has been transformed at the database. This is a pass.");
        						System.out.println("^^^^^Pass "+final_key+" -------Status : Pass ---- Value from the file has been transformed at the database. This is a pass.");
        					}
        					
    					
    					try{
    						//Getting file value in a String
    						String fValue = flatFileValuesMap.get(sbid).get(records).get(final_key);
    						//Comparing file value with db value and displaying the status in report
        					if(fValue.equalsIgnoreCase(dValue)){
        						//System.out.println("---------------------------- PASS ------------------  "+final_key+", FileValue: "+fValue+", DBValue:"+dValue);
        						logger.log(LogStatus.PASS,"Element Name : "+ final_key +"|----------FileValue : "+fValue+"----------DBValue : "+ dValue+"-------Status : Pass");
        						System.out.println("^^^^^Pass "+final_key+": "+fValue+" , "+dValue);  
        					}
        					else if((dValue.equalsIgnoreCase("NULL") && fValue.equalsIgnoreCase(""))||(fValue.equalsIgnoreCase("00000000") && dValue.equalsIgnoreCase("NULL"))||final_key.equalsIgnoreCase("RX_BIN_NBR")||final_key.equalsIgnoreCase("RX_PCN_NBR")||final_key.equalsIgnoreCase("GRP_POL_NBR")||final_key.equalsIgnoreCase("RX_ID_NBR")){
        						logger.log(LogStatus.PASS,"Element Name : "+ final_key +"|----------FileValue : "+fValue+"----------DBValue : "+ dValue+"-------Status : Pass ---- Value from the file has been transformed at the database. This is a pass.");
        						System.out.println("^^^^^Pass "+final_key+": "+fValue+" , "+dValue);
        					}
        					
        					else if(final_key.equalsIgnoreCase("LOB")){
        						logger.log(LogStatus.PASS,"Element Name : "+ final_key +"|----------FileValue : "+fValue+"-------Status : Pass");
        						System.out.println("^^^^^Pass "+final_key+": "+fValue+" , "+dValue);
        					}
        					else{
        						System.out.println("^^^^^Fail in else "+final_key+":******"+fValue+"*******"+dValue+"****************");
        						logger.log(LogStatus.FAIL,"Element Name : "+ final_key +"|----------FileValue : "+String.valueOf(fValue)+"----------DBValue : "+ dValue+"-------Status : Fail");
        						
        					}
        					}
        					catch (Exception e) {
        						try{
        							String fValue = flatFileValuesMap.get(sbid).get(records).get(final_key);
        				  		  if(dValue.equalsIgnoreCase("NULL")){
        				  			logger.log(LogStatus.PASS,"Element Name : "+ final_key +"|----------FileValue : "+fValue+"----------DBValue : "+ dValue+"-------Status : Pass ---- fvalue is NULL");
        				  			System.out.println("^^^^^Pass "+final_key+": "+fValue+" , "+dValue);
        				  		  }
        		        		System.out.println("------------------ Exception caught in IF-Else case  ------------------- "+final_key );
        		        		System.out.println("^^^^^Fail "+final_key+":******"+fValue+"*******"+dValue+"****************");
        		        		logger.log(LogStatus.FAIL,"Element Name : "+ final_key +"|----------FileValue : "+fValue+"----------DBValue : "+ dValue+"-------Status : Fail");
        		        		
        						}
        						catch (Exception e1) {
        							System.out.println("Failed at 476"+final_key+e1+"  "+final_key);
        						}
        		        	}
        				}
            			}
    					catch(Exception e)
	        			{
	        				
	        				System.out.println("---Failed at 486 due to final key loop "+e);
	        			}
        			}
        			
        			
        			}
        			
        			}
				
			}
			catch (Exception e) {
		  		  
        		System.out.println("Failed at 490"+e.getMessage());
 		 
			}
        }
        
       
        
       
		
       else if(strFileType.contains("GRP")){
    	   System.out.println("%%% Executed Second %%%"+grpSubID);
    	   String mappingsheet="ArgusOutFileVal";
        	
        	String[][] dbValue=null;
        	
        	String final_query="";
			String Sql_query ="";
			
			try{
				Sql_query= new ExcelUtilsExtended("src/test/resources/BscaCare1stMMTest.xlsx", mappingsheet).getQueryFromMappingSheet("GRGR_VAL".toUpperCase(), mappingsheet);
				final_query=Sql_query+" in ('"+grpSubID+"')";
				// grpSubID//'908973268' 
				
        			dbValue =  (String[][])new DBUtils().getTableArray("facets",final_query);
        			String dValue = dbValue[0][0]+ dbValue[0][1]+ dbValue[0][2]+ dbValue[0][3]+ dbValue[0][4];
        			System.out.println("DBValue before fetching file value of grp file: "+dValue);
        			
        			edi834Utility.getGroupFileData(
        					strCompleteFilePath, inputFileName,data,dValue);
        			
        			
			}
			catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
    					
        }
        }
			
	private  String [] funcSourceTargetTransformationLogic(String key,String fileValue,String dbValue) throws Exception{
		String fileModifiedValue,dbModifiedValue;
		String [] strReturn = new String[2];
		
		if(fileValue == null){
			fileValue = "[Blank]";
			fileModifiedValue = fileValue;
		}
		else{
			fileModifiedValue = fileValue;
		}
		
		if(dbValue == null){
			dbValue = "[Blank]";
			dbModifiedValue = dbValue;
		}
		else{
			dbModifiedValue = dbValue;
		}
		
		//Replacing null values with [Blank] for user understanding
		if(fileValue.toString().trim().equalsIgnoreCase(""))
			fileValue = "[Blank]";
		if(dbValue.toString().trim().equalsIgnoreCase(""))
			dbValue = "[Blank]";
		if(fileValue.equalsIgnoreCase(";")|| fileValue.equalsIgnoreCase(";;"))
			fileValue = "[Blank]";
		fileModifiedValue = fileValue.trim().toUpperCase();
		dbModifiedValue = dbValue.trim().toUpperCase();
		
		
		//To validate Primary County Code field field
		if(key.equalsIgnoreCase("Primary County_411")){					
			if(fileModifiedValue.contains(dbModifiedValue)){
				if(dbModifiedValue.equals("19") || dbModifiedValue.equals("37"));{
				}
			}
			else{
				System.out.println("Invalid County Code");
			}
		}
		
		 //To validate ETHNICITY field
		 if(key.equalsIgnoreCase("MEME_MCTR_ETHN_NVL")){
				String strQuery = "Select distinct FACETS_ETHNIC_CD from CU_ETHNIC_MAP_XREF where EDI_ETHNIC_CD = '" + fileValue + "'";
				Map<String,String> ethinicity = new HashMap<String,String>();
				ethinicity = new DBUtils().getOneRowResultSetAsMap("facets", strQuery);
				fileModifiedValue = ethinicity.get("FACETS_ETHNIC_CD");
				if(fileModifiedValue == null){
					fileModifiedValue = "[Blank]";
				}	
				/*if(fileModifiedValue.equalsIgnoreCase(dbModifiedValue)){
					logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + fileModifiedValue + " | Database value: " + dbModifiedValue + " >>");
			}
				else{
					logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + fileModifiedValue + " | Database value: " + dbModifiedValue + " >>");
				}*/
		} 
		 
		 
		 //To validate PRPR_ID field
		 if(key.equalsIgnoreCase("PRPR_ID")){
			 try{
				 String getPcpQuery = "SELECT PRPR_ID FROM PFI.PFI_LACARE_XWALK where LACARE_ID = '" + fileValue.trim() + "'";
				 System.out.println("prpr query"+getPcpQuery);
				 Map<String,String> prprMap = new HashMap <String,String>();
				 prprMap = new DBUtils().getOneRowResultSetAsMap("facets", getPcpQuery);
				 fileModifiedValue = prprMap.get("PRPR_ID");
				 System.out.println("file value" + fileModifiedValue);
				 if(fileModifiedValue == null){
					 fileModifiedValue = "[Blank]";
				 }
					/*else{
						System.out.println("is null value");
					}*/
					/*else{
						if((prprMap.get("prpr_id") != null ? prprMap.get("prpr_id") : "").trim().equalsIgnoreCase("")){
							fileModifiedValue = "[Blank]";
					}*/
			 }
			 catch (Exception e){
				 System.out.println("PRPR Id not found");
			 }
			 
				/*if(fileModifiedValue.equalsIgnoreCase(dbModifiedValue)){
					logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + fileModifiedValue + " | Database value: " + dbModifiedValue + " >>");
				}else{
					logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + fileModifiedValue + " | Database value: " + dbModifiedValue + " >>");
				}	*/
		 } 		
		 			 
		strReturn[0] = fileModifiedValue;
		strReturn[1] = 	dbModifiedValue;
		return strReturn;
	}

		
	//TODO: Replace valueExistsInDb with this logic whenever all data elements on the file and DB are accounted for
	/**
	 * Pefrom a diff between actual vs expected
	 * @param flatFileValuesMap
	 * @param sql1Map
	 * @return map diff as a sorted map of sorted maps
	 */
	
	@SuppressWarnings("unused")
	private MapDifference<String, SortedMap<String, String>> getMapDiff(
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap,
		SortedMap<String, SortedMap<String, String>> sql1Map) {
		MapDifference<String, SortedMap<String, String>> diff = Maps.difference(flatFileValuesMap, sql1Map);

		Set<String> keysOnlyInActual = diff.entriesOnlyOnLeft().keySet();
		Set<String> keysOnlyInExpected = diff.entriesOnlyOnRight().keySet();
		
		if (!keysOnlyInActual.isEmpty()) {
			System.out.println("Keys only in actual: ");
			for (String key : keysOnlyInActual){
				System.out.println(key);
			}
		}

		if (!keysOnlyInExpected.isEmpty()){
			System.out.println("Keys only in expected: ");
			for (String key : keysOnlyInExpected){
				System.out.println(key);
			}
		}

		if (!diff.areEqual()){
			Set<String> entriesDifferingKeySet = diff.entriesDiffering().keySet();
			Map<String, ValueDifference<SortedMap<String, String>>> entriesDifferring = diff.entriesDiffering();
			ValueDifference<SortedMap<String, String>> valuesDifference = null;
			System.out.println("Entries differring");
			System.out.println("------------------");
			for (String key : entriesDifferingKeySet){
				System.out.println("key = " + key);
				valuesDifference = entriesDifferring.get(key);
				System.out.println("ACTUAL: \t" + valuesDifference.leftValue());
				System.out.println("EXPECTED: \t" + valuesDifference.rightValue());
				System.out.println("\t\tActual \t\t|\t\t Expected");
				logger.log(LogStatus.INFO, "\t\tActual \t\t|\t\t Expected values for CINN number: " + key);
				
				//Developer needs to ensure that both the file map and database maps have the SAME number AND order of Key values.
				//If this is not done, additional logic will be requried to handle the comparison.
				for (String diffKey : valuesDifference.leftValue().keySet()){
					String left = valuesDifference.leftValue().get(diffKey);
					String right = valuesDifference.rightValue().get(diffKey);
					if (!(left == null && right == null) && !left.equals(right)){
						System.out.println(diffKey + ": " + left + " | " + right);
						logger.log(LogStatus.FAIL, diffKey + ": " + left + " | " + right);
					}
					else{
						logger.log(LogStatus.PASS, diffKey + ": " + left + " | " + right);
					}
				}
				System.out.println("\n");
			}
		}
		return diff;
	}

	/**
	 * //To run test method, this method will initiate the HTML report
	 * 
	 * @Override run is a hook before @Test method
	 */
	
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult){
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting Test " + testResult.getName());
		callBack.runTestMethod(testResult);
		//To display the failure count in console
		softAssert.assertAll(); 
	}
	
	// assigning test data excel file path to a local variable
	private Map<String, String> getData(String testMethodName) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		String xlsPath = "src/test/resources/" + this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, testMethodName);
		return dataMap;
	}
}
