package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileBody {

		private String LOB;
		private String WMDS_TEXT1;
		private String GRGR_ID;
		private String SBSB_ID;
		private String MEPE_EFF_DT;
		private String MEPE_TERM_DT;
		private String MEME_LAST_NAME;
		private String MEME_FIRST_NAME;
		private String Dual_Coverage_indicator;
		
		
		public String getLOB() {
			return LOB;
		}
		public void setLOB(String lOB) {
			LOB = lOB;
		}
		public String getDual_Coverage_indicator() {
			return Dual_Coverage_indicator;
		}
		public void setDual_Coverage_indicator(String dual_Coverage_indicator) {
			Dual_Coverage_indicator = dual_Coverage_indicator;
		}
		public String getWMDS_TEXT1() {
			return WMDS_TEXT1;
		}
		public void setWMDS_TEXT1(String wMDS_TEXT1) {
			WMDS_TEXT1 = wMDS_TEXT1;
		}
		public String getGRGR_ID() {
			return GRGR_ID;
		}
		public void setGRGR_ID(String gRGR_ID) {
			GRGR_ID = gRGR_ID;
		}
		public String getSBSB_ID() {
			return SBSB_ID;
		}
		public void setSBSB_ID(String sBSB_ID) {
			SBSB_ID = sBSB_ID;
		}
			
			public String getMEPE_EFF_DT() {
				return MEPE_EFF_DT;
			}
			public void setMEPE_EFF_DT(String mEPE_EFF_DT) {
				MEPE_EFF_DT = mEPE_EFF_DT;
			}
			public String getMEPE_TERM_DT() {
				return MEPE_TERM_DT;
			}
			public void setMEPE_TERM_DT(String ePE_TERM_DT) {
				MEPE_TERM_DT = ePE_TERM_DT;
			}
			public String getMEME_LAST_NAME() {
				return MEME_LAST_NAME;
			}
			public void setMEME_LAST_NAME(String mEME_LAST_NAME) {
				MEME_LAST_NAME = mEME_LAST_NAME;
			}
			public String getMEME_FIRST_NAME() {
				return MEME_FIRST_NAME;
			}
			public void setMEME_FIRST_NAME(String mEME_FIRST_NAME) {
				MEME_FIRST_NAME = mEME_FIRST_NAME;
			}
			
	}
	