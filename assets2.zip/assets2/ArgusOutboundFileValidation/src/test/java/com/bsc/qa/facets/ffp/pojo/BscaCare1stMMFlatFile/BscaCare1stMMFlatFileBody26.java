package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE.
public class BscaCare1stMMFlatFileBody26 {
	private String WMDS_TEXT1;
	private String GRGR_ID;
	private String SBSB_ID;
	private String MEME_SFX;
	private String REC_TYP_CD;
	private String MSP_RSN_CD;
	private String SBMT_EFF_DT;
	private String TERM_DT;
	private String RX_BIN_NBR;
	private String RX_PCN_NBR;
	private String GRP_POL_NBR;
	private String RX_ID_NBR;
	private String PERS_CD;
	
	
	public String getSBMT_EFF_DT() {
		return SBMT_EFF_DT;
	}
	public void setSBMT_EFF_DT(String sBMT_EFF_DT) {
		SBMT_EFF_DT = sBMT_EFF_DT;
	}
	public String getTERM_DT() {
		return TERM_DT;
	}
	public void setTERM_DT(String tERM_DT) {
		TERM_DT = tERM_DT;
	}
	public String getPERS_CD() {
		return PERS_CD;
	}
	public void setPERS_CD(String pERS_CD) {
		PERS_CD = pERS_CD;
	}
	public String getWMDS_TEXT1() {
		return WMDS_TEXT1;
	}
	public void setWMDS_TEXT1(String wMDS_TEXT1) {
		WMDS_TEXT1 = wMDS_TEXT1;
	}
	public String getGRGR_ID() {
		return GRGR_ID;
	}
	public void setGRGR_ID(String gRGR_ID) {
		GRGR_ID = gRGR_ID;
	}
	public String getSBSB_ID() {
		return SBSB_ID;
	}
	public void setSBSB_ID(String sBSB_ID) {
		SBSB_ID = sBSB_ID;
	}
	public String getMEME_SFX() {
		return MEME_SFX;
	}
	public void setMEME_SFX(String mEME_SFX) {
		MEME_SFX = mEME_SFX;
	}
	public String getREC_TYP_CD() {
		return REC_TYP_CD;
	}
	public void setREC_TYP_CD(String rEC_TYP_CD) {
		REC_TYP_CD = rEC_TYP_CD;
	}
	public String getMSP_RSN_CD() {
		return MSP_RSN_CD;
	}
	public void setMSP_RSN_CD(String mSP_RSN_CD) {
		MSP_RSN_CD = mSP_RSN_CD;
	}
	
	public String getRX_BIN_NBR() {
		return RX_BIN_NBR;
	}
	public void setRX_BIN_NBR(String rX_BIN_NBR) {
		RX_BIN_NBR = rX_BIN_NBR;
	}
	public String getRX_PCN_NBR() {
		return RX_PCN_NBR;
	}
	public void setRX_PCN_NBR(String rX_PCN_NBR) {
		RX_PCN_NBR = rX_PCN_NBR;
	}
	public String getGRP_POL_NBR() {
		return GRP_POL_NBR;
	}
	public void setGRP_POL_NBR(String gRP_POL_NBR) {
		GRP_POL_NBR = gRP_POL_NBR;
	}
	public String getRX_ID_NBR() {
		return RX_ID_NBR;
	}
	public void setRX_ID_NBR(String rX_ID_NBR) {
		RX_ID_NBR = rX_ID_NBR;
	}
	
	

}
