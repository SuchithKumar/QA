package com.bsc.qa.facets.tests;

import java.io.IOException;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.bsc.qes.facets.dfpojo.readers.BinderPaymentFileReader;
import com.relevantcodes.extentreports.LogStatus;

public class BinderPaymentE2EValidationTest extends BaseTest implements IHookable
{
	
    private static int bodyRowsCount;
    
    final private static String strUniqueIdentifier1 = "ACCOUNT_NUMBER"; // <= first 
    final private static String strUniqueIdentifier2 = "APPLICATION_ID"; // <= second
    
    private static BinderPaymentFileReader ffpExtract;
    
	private static List<Map<String, String>> testHeader;
	private static List<Map<String, String>> testBody;
	private static List<Map<String, String>> testFooter;
	
	public static int paymentAmount;
	public static int convenienceFee;
	public static int totalAmount; 
	public static int totalpaymentAmount;
	public static int toalconvenienceFee;
	public static int totaltotalAmount; 
    
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles", "FileSpecificFolderName"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
        
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) 
		{
			NameOfTestDataSheet = "Sheet1";
		}
		
        // Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
	 	
        //NOTE DB UTIL OBJECT CREATION! 
		objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
		
		filePAth = tesFile.getCompleteTestFilePath();	 
		 
        //read flat file before test 
		ffpExtract = new BinderPaymentFileReader(filePAth);
		 
        //Parse headers and store in to testHeaders list
			try 
			{
				testHeader = ffpExtract.getListOfHeaderValues();
			} 
			catch (IOException e) 
			{
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
        //Parse body and store in to testBody list 
			try 
			{
				testBody = ffpExtract.getListOfBodyValues(); // array list of hash map values 
				bodyRowsCount = testBody.size(); // body rows count
				//System.out.println(bodyRowsCount);
			} 
			catch (IOException e) 
			{
				System.out.println("BAD PARSING REQUEST testBody LIST NOT CREATED");
				e.printStackTrace();
			}

        //Parse footers and store in to testFooter list 
			try 
			{
				testFooter = ffpExtract.getListOfFooterValues();
			} 
			catch (IOException e) 
			{
				System.out.println("BAD PARSING REQUEST testFooter LIST NOT CREATED");
				e.printStackTrace();
			}
	}

	
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ Binder Payment - Header Validation ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

	// Method validates records count against rows of header elements	
	@Test(dataProvider = "masterDataProvider", priority = 1)
	public void testFullBinderPaymentFileHeader(Map<String, String> data) 
	{ 
		SoftAssert softAssertion= new SoftAssert();
		System.out.println("");
    	System.out.println("**********************************************************************************************************");
		System.out.println("---------------------------------------------------HEADER-------------------------------------------------");
		System.out.println("**********************************************************************************************************");
  
	    // get HashMap of header values form flat file
		Map<String, String> FlatFileMap = testHeader.get(0);
	    	
	    System.out.println("================================================================================");
	
    for (String BinderPaymentkey : FlatFileMap.keySet()) {
	    	     String[] ArrayResult = null ;	
	    	     
	    	     // pretty print log 
	    	     System.out.println("--------------------------------------------------------------------------------");
	    	     System.out.println("Testing Binder Payment Header Element " + BinderPaymentkey);
	    	     
	    	     logger.log(LogStatus.INFO, "Starting Test of * " + BinderPaymentkey + " *");
	    	     System.out.println("--------------------------------------------------------------------------------");     
	    	   
	    	     //  if (!"TRANSACTION_COUNT".equals(BinderPaymentkey.toUpperCase()))  
	    	     // { 
	    	     //get query from data sheet
	    	     String datasheetColumnName = "sql_header_"+ (BinderPaymentkey.toLowerCase().trim()).toString();
 	    	    
	    	     String SQLQuery = data.get(datasheetColumnName);

	    	     // case for no args queries 
 	 		     ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
 	 		     
 	 		     datasheetColumnName = null;
 			  
		         //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			     String[] strRecordSet = ArrayResult[0].split("#"); 
		
			     //get records colmn name to string 
			     String expectedFieldName = strRecordSet[0].trim(); 
			
			     //get records expected value to string
			     String expectedValue = strRecordSet[1];
					
		         // Test if DB Key exists in FF ste of Keys 
		         if (FlatFileMap.containsKey(expectedFieldName)) 
		        {
		           System.out.println("Actual Value is: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value is: " + expectedValue.trim());
				   System.out.println("");
		           
				   //compare values	 
	               softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    		
				   // Duplicated Validation for Extend Report Only
				   if ((FlatFileMap.get(expectedFieldName)).trim().equals(expectedValue.trim())) 
				   {
					  logger.log(LogStatus.PASS, "Actual Value is: " + "  " + (FlatFileMap.get(expectedFieldName)).trim() + "  " + " Expected Value is: " + "  " + expectedValue.trim());
				   }
				  else
				   {
					  logger.log(LogStatus.FAIL, "Actual Value is: " + "  " +(FlatFileMap.get(expectedFieldName)).trim() + "  " + " Expected Value is: " + "  " + expectedValue.trim());
				   }	        
		    	 } 
		         else
		           {
		    	   //key does not exists report failure 
		    	   softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), " Expected Header Element " + expectedFieldName + " is Required" );
		    	   logger.log(LogStatus.FAIL, "Element * " + expectedFieldName + " * ");
		    	   }	
	    	    } 
	//    } 
	    softAssertion.assertAll();	//<== absolutely must be here  
	}
	
	
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ Binder Payment - Body Validation ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
	
	@Test(dataProvider = "masterDataProvider", priority = 2)
	public void testFullBinderPaymentFileBody(Map<String, String> data) 
	{ 
		int rowIndex = 0 ;
		
		SoftAssert softAssertion= new SoftAssert();
		System.out.println("");
		System.out.println("**********************************************************************************************************");
		System.out.println("-----------------------------------------------------BODY-------------------------------------------------");
		System.out.println("**********************************************************************************************************");
	          
	    // loop for each row in Binder Payment file (footer and header ignored)
	    for (Map<String, String> FlatFileMap : testBody) 
	    {
	    	rowIndex ++;
	    	
	    	System.out.println("--------------------------------------------------------------------------------");
	    	System.out.println("============================== NEW ROW =========================================");
	    	System.out.println("--------------------------------------------------------------------------------");
	    	
	    	System.out.println("Reading Binder Payment File Body. Scanning Row Number " + rowIndex);

	        // loop for each keys set in hashmap 
	    	for (String BinderPaymentkey : FlatFileMap.keySet()) 
	    	{
	    	     String[] ArrayResult = null ;	
	    	     // get unique id value for each row
	    	     String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
	    	     String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
	    	     
	    	     // pretty print log 
	    	     System.out.println("--------------------------------------------------------------------------------");
	    	     System.out.println("Testing Binder Payment Body Element " + BinderPaymentkey);
	    	     logger.log(LogStatus.INFO, "Starting Test of * " + BinderPaymentkey + " * Element In Row # {" + rowIndex + "} UniqueId * " + strUniqueIdValueOne + " *");
	    	     System.out.println("--------------------------------------------------------------------------------");
	    	     
	    	     if (!"TRANSACTION_ID".equals(BinderPaymentkey.toUpperCase()))  
		    	 { 
	    	     //get query from data sheet
	    	     String SQLQuery = data.get("sql_"+ (BinderPaymentkey.toLowerCase().trim())).toString();
 		    
 		         if (BinderPaymentkey.equals("RECORD_TYPE")||BinderPaymentkey.equals("BILLER_ID") ) 
 		         {
 		        	 // case for no args queries 
 	 		         ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
 		         }
 		         else
 		         {
 				    // run sql query 
 				    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, strUniqueIdValueOne,strUniqueIdValueTwo);	
 		         }
	    	
	    	 
 	        //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
		
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
			
			String actualValue = FlatFileMap.get(expectedFieldName);
			
			if (actualValue == null || actualValue.isEmpty()) 
			{
				actualValue = "BLANK";
			}
			
		    // Test if DB Key exists in FF ste of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) 
		     {
		    	  System.out.println("Actual Value is: " + "  " +actualValue.trim() + "  " + " Expected Value: " + "  " + expectedValue.trim());
		    	  System.out.println("**********************************************************************************************************");
				  System.out.println("----------------------------------------------------------------------------------------------------------");
				  System.out.println("**********************************************************************************************************");
		    	  System.out.println("");
		    	  
		    	  //compare values	 
	              softAssertion.assertEquals(actualValue.trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
				 
				  // Duplicated Validation for Extend Report Only
				  if (actualValue.trim().equals(expectedValue.trim())) 
				  {
					  logger.log(LogStatus.PASS, "Actual Value: " + actualValue.trim() + " Expected Value: " + expectedValue.trim() + " * In Row # {" + rowIndex + "} UniqueId * " + strUniqueIdValueOne + " * ");
				  }
				  else
				  {
					  logger.log(LogStatus.FAIL, "Actual Value: " + actualValue.trim() + " Expected Value: " + expectedValue.trim() + " * In Row # {" + rowIndex + "} UniqueId * " + strUniqueIdValueOne + " * ");
				  }        
		    } 
		     else 
		          {
		    	   //key does not exists report failure 
		    	   softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    	   logger.log(LogStatus.FAIL, "Element * " + expectedFieldName + " * In Row # {" + rowIndex + "} UniqueId * " + strUniqueIdValueOne + " * - Not Found");
		    	  }	
		     
	    	    }// INNER LOOP for (String DBkey : FlatFileMap.keySet()) {
	    	System.out.println("********************************************************************************");
		    System.out.println("============================== NEXT ROW ========================================");
		    System.out.println("********************************************************************************");
	       } //<== END OF OUTER LOOP for (Map<String, String> FlatFileMap : testBody) {
	    }
	    softAssertion.assertAll();	//<== absolutely must be here  
	}
	
	
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ Binder Payment Body - Transaction ID Validation ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

    // Method validates records count against rows of body elements	
	@Test(dataProvider = "masterDataProvider", priority = 3) // data provider method all the way at the bottom of this class 
	public void testBinderPaymentBodyTransactionID(Map<String, String> data) 
	{ // <== note test method name also points to row number in test data sheet 
		
		SoftAssert softAssertion= new SoftAssert();
		
        //get records column name to string 
		String expectedFieldName = "TRANSACTION_ID"; // NO QUERY SO Field Name Coded <== RECORD COUNT ONLY
		
        // get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testBody.get(0);
		
         // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) 
	     {
	          String actualValue = flatFileValuesMap.get(expectedFieldName).toString().trim();
        		
              //testing the length of Transaction_ID field
        	  softAssertion.assertEquals(actualValue.length(), 21, " Expected length of RECORD_COUNT is 21 chars long ");
        		
        	  //testing if value exist since field is mandatory
        	  softAssertion.assertNotNull(actualValue, "Transaction ID is Mandatory");
        	  
        	  //testing if actual value is integer
        	  softAssertion.assertEquals(actualValue, expectedFieldName, "Value is integer");
                 //remove zeros from 000000005 to 5
        		 //actualValue = actualValue.replaceFirst("^0+(?!$)", "");
        		 
              //note the conversion of integer value 
        	  //softAssertion.assertEquals(actualValue.trim(), (String.valueOf(bodyRowsCount)).trim(), " Expected Value of Record Count: " + bodyRowsCount);
	    		
	    	  System.out.println("Actual Value of Transaction ID is: " + actualValue  );	
			  //System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
	    	  System.out.println("**********************************************************************************************************");
			  System.out.println("--------------------------------------Body - Transaction ID is validated----------------------------------");
			  System.out.println("**********************************************************************************************************");
			  
              // Duplicated Validation for Extend Report Only  
			  if (actualValue.trim().equals(expectedFieldName.trim()))
			  {
				  logger.log(LogStatus.PASS, "Actual Transaction ID is * " + actualValue + " * and Expected Transaction ID is * " + (expectedFieldName.trim()) + " *"  );
			  }
			  else
			  {
				  logger.log(LogStatus.FAIL, "Actual Transaction ID is * " + actualValue + " * and Expected Transaction ID is * " + (expectedFieldName.trim()) + " *" );
			  }	        
	    } 
	    else 
	    {	    	  
              //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    	  logger.log(LogStatus.FAIL, " Missing Body Element * TRANSACTION_ID * ");
	    }
	softAssertion.assertAll();	//<== absolutely must be here
	}

//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ Binder Payment - Footer Validation ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
	
   // Method validates records count against rows of footer elements	
   @Test(dataProvider = "masterDataProvider", priority = 4)
   public void testFullBinderPaymentFileFooter(Map<String, String> data) 
	{
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		  System.out.println("");
    	  System.out.println("**********************************************************************************************************");
		  System.out.println("-----------------------------------------------------FOOTER-----------------------------------------------");
		  System.out.println("**********************************************************************************************************");

		 String SQLQuery = data.get("sql_footer_record_type").toString();
	    
	     for (Map<String, String> FlatFileMap : testFooter) 
	     {
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
		    // Test if DB Key exists in FF ste of Keys 
		    if (FlatFileMap.containsKey(expectedFieldName)) 
		     {
		          //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    		
		    	  System.out.println(" Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
				  
		    	  // Duplicated Validation for Extend Report Only
				  if ((FlatFileMap.get(expectedFieldName)).trim().equals(expectedValue.trim())) 
				  {
					  logger.log(LogStatus.PASS, "Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
				 
				  }
				  else
				  {
					  logger.log(LogStatus.FAIL, "Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
				  }	        
		      } 
		     else 
		      {
		    	  //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Footer Element " + expectedFieldName + " is Required" );
		    	  
		    	  logger.log(LogStatus.FAIL, " Missing Footer Element * RECORD_TYPE * ");
		      }	
	    }
	      softAssertion.assertAll();	//<== absolutely must be here      				
	}
   
   
 //▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ Binder Payment Footer - Transaction Count Validation ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

   // Method validates records count against rows of body elements	
	@Test(dataProvider = "masterDataProvider", priority = 5) // data provider method all the way at the bottom of this class 
	public void testBinderPaymentFooterTransactionCount(Map<String, String> data) 
	{ // <== note test method name also points to row number in test data sheet 
		
		SoftAssert softAssertion= new SoftAssert();
		
       //get records column name to string 
		String expectedFieldName = "TRANSACTION_COUNT"; // NO QUERY SO Field Name Coded <== RECORD COUNT ONLY
		
       // get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testFooter.get(0);
		
        // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) 
	     {
	          String actualValue = flatFileValuesMap.get(expectedFieldName).toString().trim();
       		
             //testing the lenth of TOTAL_RECORDS field
       	  softAssertion.assertEquals(actualValue.length(), 6, " Expected length of RECORD_COUNT is 6 chars long ");
       		
                //remove zeros from 000000005 to 5
       		 //actualValue = actualValue.replaceFirst("^0+(?!$)", "");
       		 
             //note the conversion of integer value 
       	  softAssertion.assertEquals(actualValue.trim(), (String.valueOf(bodyRowsCount)).trim(), " Expected Value of Record Count: " + bodyRowsCount );
	    		
	    	  System.out.println("Actual Value of Transaction Count is: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim()  );	
			  //System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
	    	  System.out.println("**********************************************************************************************************");
			  System.out.println("--------------------------------------Footer - Transaction count is validated----------------------------------");
			  System.out.println("**********************************************************************************************************");
			  
             // Duplicated Validation for Extend Report Only
			  if (String.valueOf(bodyRowsCount).trim().equals(actualValue)) 
			  {
				  logger.log(LogStatus.PASS, "Actual Transaction Count is * " + actualValue + " * and Expected Count is * " + String.valueOf(bodyRowsCount) + " *"  );
			  }
			  else
			  {
				  logger.log(LogStatus.FAIL, "Actual Transaction Count is * " + actualValue + " * and Expected Count is * " + String.valueOf(bodyRowsCount) + " *" );
			  }	        
	    } 
	    else 
	    {	    	  
             //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Header Element " + expectedFieldName + " is Required" );
	    	  logger.log(LogStatus.FAIL, " Missing Footer Element * TRANSACTION_COUNT * ");
	    }
	softAssertion.assertAll();	//<== absolutely must be here
	}
	
	
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Test Methods that should be present in every test @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    
  private static DBUtils objDBUtility;//Mandatory declaration 
  private static String filePAth ;//Mandatory 

//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) 
	{	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) 
	{
		Object[][] data = null;
		Map<String, String> dataMap = new HashMap<String, String>();

		dataMap = ExcelUtils.getTestMethodData(method.getName());
		data = new Object[][] { { dataMap } };
		return data;
	}

	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
}
//┌───────────────────┐
//│ ╔═══╗ Delimited  │▒
//│ ╚═╦═╝ Files Test │▒
//╞═╤═╩═══╤══════════╡▒
//│ ├──┬──┤@ 2019    │▒
//│ └──┴──┘Automation│▒
//└─────