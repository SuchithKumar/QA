package com.bsc.qes.facets.ffpojo.dfp.mam;

public class BinderPaymentBodyFields 
{
	private String null_00;
	private String Record_Type;
	private String Transaction_Id;
	private String Biller_Id;
	private String Billing_Account;
	private String Sub_Account;
	private String Sub_Account_Type;
	private String Payment_Amount;
	private String Convenience_Fee;
	private String Total_Amount;
	private String Payment_Due_Date;
	private String Flex_Field1;
	private String Flex_Field2;
	private String Flex_Field3;
	private String Flex_Field4;
	private String Flex_Field5;
	private String Group_Id;
	private String Bill_Type;
	private String Hix_Id;
	private String First_Name;
	private String Last_Name;
	private String Flex_Field11;
	private String Flex_Field12;
	private String Flex_Field13;
	private String Flex_Field14;
	private String Flex_Field15;
	private String Flex_Field16;
	private String Flex_Field17;
	private String Flex_Field18;
	private String Flex_Field19;
	private String Flex_Field20;
	
	/**
	 * @return the null_00
	 */
	public String getNull_00() {
		return null_00;
	}
	/**
	 * @param null_00 the null_00 to set
	 */
	public void setNull_00(String null_00) {
		this.null_00 = null_00;
	}
	/**
	 * @return the Record_Type
	 */
	public String getRecord_Type() 
	{
		return Record_Type;
	}
	/**
	 * @param Record_Type the Record_Type to set
	 */
	public void setRecord_Type(String Record_Type) 
	{
		this.Record_Type = Record_Type;
	}
	/**
	 * @return the Transaction_Id
	 */
	public String getTransaction_Id() 
	{
		return Transaction_Id;
	}
	/**
	 * @param Transaction_Id the Transaction_Id to set
	 */
	public void setTransaction_Id(String Transaction_Id) 
	{
		this.Transaction_Id = Transaction_Id;
	}
	/**
	 * @return the Biller_Id
	 */
	public String getBiller_Id() 
	{
		return Biller_Id;
	}
	/**
	 * @param Biller_Id the Biller_Id to set
	 */
	public void setBiller_Id(String Biller_Id) 
	{
		this.Biller_Id = Biller_Id;
	}
	/**
	 * @return the Billing_Account
	 */
	public String getBilling_Account() 
	{
		return Billing_Account;
	}
	/**
	 * @param Billing_Account the Billing_Account to set
	 */
	public void setBilling_Account(String Billing_Account) 
	{
		this.Billing_Account = Billing_Account;
	}
	/**
	 * @return the Sub_Account
	 */
	public String getSub_Account() 
	{
		return Sub_Account;
	}
	/**
	 * @param Sub_Account the Sub_Account to set
	 */
	public void setSub_Account(String Sub_Account) 
	{
		this.Sub_Account = Sub_Account;
	}
	/**
	 * @return the Sub_Account_Type
	 */
	public String getSub_Account_Type() 
	{
		return Sub_Account_Type;
	}
	/**
	 * @param Sub_Account_Type the Sub_Account_Type to set
	 */
	public void setSub_Account_Type(String Sub_Account_Type) 
	{
		this.Sub_Account_Type = Sub_Account_Type;
	}
	/**
	 * @return the Payment_Amount
	 */
	public String getPayment_Amount() 
	{
		return Payment_Amount;
	}
	/**
	 * @param Payment_Amount the Payment_Amount to set
	 */
	public void setPayment_Amount(String Payment_Amount) 
	{
		this.Payment_Amount = Payment_Amount;
	}
	/**
	 * @return the Convenience_Fee
	 */
	public String getConvenience_Fee() 
	{
		return Convenience_Fee;
	}
	/**
	 * @param Convenience_Fee the Convenience_Fee to set
	 */
	public void setConvenience_Fee(String Convenience_Fee) 
	{
		this.Convenience_Fee = Convenience_Fee;
	}
	/**
	 * @return the Total_Amount
	 */
	public String getTotal_Amount() 
	{
		return Total_Amount;
	}
	/**
	 * @param Total_Amount the Total_Amount to set
	 */
	public void setTotal_Amount(String Total_Amount) 
	{
		this.Total_Amount = Total_Amount;
	}
	/**
	 * @return the Payment_Due_Date
	 */
	public String getPayment_Due_Date() 
	{
		return Payment_Due_Date;
	}
	/**
	 * @param Payment_Due_Date the Payment_Due_Date to set
	 */
	public void setPayment_Due_Date(String Payment_Due_Date) 
	{
		this.Payment_Due_Date = Payment_Due_Date;
	}
	/**
	 * @return the Flex_Field1
	 */
	public String getFlex_Field1() 
	{
		return Flex_Field1;
	}
	/**
	 * @param Flex_Field1 the Flex_Field1 to set
	 */
	public void setFlex_Field1(String Flex_Field1) 
	{
		this.Flex_Field1 = Flex_Field1;
	}
	/**
	 * @return the Flex_Field2
	 */
	public String getFlex_Field2() 
	{
		return Flex_Field2;
	}
	/**
	 * @param Flex_Field2 the Flex_Field2 to set
	 */
	public void setFlex_Field2(String Flex_Field2) 
	{
		this.Flex_Field2 = Flex_Field2;
	}
	/**
	 * @return the Flex_Field3
	 */
	public String getFlex_Field3() 
	{
		return Flex_Field3;
	}
	/**
	 * @param Flex_Field3 the Flex_Field3 to set
	 */
	public void setFlex_Field3(String Flex_Field3) 
	{
		this.Flex_Field3 = Flex_Field3;
	}
	/**
	 * @return the Flex_Field4
	 */
	public String getFlex_Field4() 
	{
		return Flex_Field4;
	}
	/**
	 * @param Flex_Field4 the Flex_Field4 to set
	 */
	public void setFlex_Field4(String Flex_Field4) 
	{
		this.Flex_Field4 = Flex_Field4;
	}
	/**
	 * @return the Flex_Field5
	 */
	public String getFlex_Field5() 
	{
		return Flex_Field5;
	}
	/**
	 * @param Flex_Field5 the Flex_Field5 to set
	 */
	public void setFlex_Field5(String Flex_Field5) 
	{
		this.Flex_Field5 = Flex_Field5;
	}
	/**
	 * @return the Group_Id
	 */
	public String getGroup_Id() 
	{
		return Group_Id;
	}
	/**
	 * @param Group_Id the Group_Id to set
	 */
	public void setGroup_Id(String Group_Id) 
	{
		this.Group_Id = Group_Id;
	}
	/**
	 * @return the Bill_Type
	 */
	public String getBill_Type() 
	{
		return Bill_Type;
	}
	/**
	 * @param Bill_Type the Bill_Type to set
	 */
	public void setBill_Type(String Bill_Type) 
	{
		this.Bill_Type = Bill_Type;
	}
	/**
	 * @return the Hix_Id
	 */
	public String getHix_Id() 
	{
		return Hix_Id;
	}
	/**
	 * @param Hix_Id the Hix_Id to set
	 */
	public void setHix_Id(String Hix_Id) 
	{
		this.Hix_Id = Hix_Id;
	}
	/**
	 * @return the First_Name
	 */
	public String getFirst_Name() 
	{
		return First_Name;
	}
	/**
	 * @param First_Name the First_Name to set
	 */
	public void setFirst_Name(String First_Name) 
	{
		this.First_Name = First_Name;
	}
	/**
	 * @return the Last_Name
	 */
	public String getLast_Name() 
	{
		return Last_Name;
	}
	/**
	 * @param Last_Name the Last_Name to set
	 */
	public void setLast_Name(String Last_Name) 
	{
		this.Last_Name = Last_Name;
	}
	/**
	 * @return the Flex_Field11
	 */
	public String getFlex_Field11() 
	{
		return Flex_Field11;
	}
	/**
	 * @param Flex_Field11 the Flex_Field11 to set
	 */
	public void setFlex_Field11(String Flex_Field11) 
	{
		this.Flex_Field11 = Flex_Field11;
	}
	/**
	 * @return the Flex_Field12
	 */
	public String getFlex_Field12() 
	{
		return Flex_Field12;
	}
	/**
	 * @param Flex_Field12 the Flex_Field12 to set
	 */
	public void setFlex_Field12(String Flex_Field12) 
	{
		this.Flex_Field12 = Flex_Field12;
	}
	/**
	 * @return the Flex_Field13
	 */
	public String getFlex_Field13() 
	{
		return Flex_Field13;
	}
	/**
	 * @param Flex_Field13 the Flex_Field13 to set
	 */
	public void setFlex_Field13(String Flex_Field13) 
	{
		this.Flex_Field13 = Flex_Field13;
	}
	/**
	 * @return the Flex_Field14
	 */
	public String getFlex_Field14() 
	{
		return Flex_Field14;
	}
	/**
	 * @param Flex_Field14 the Flex_Field14 to set
	 */
	public void setFlex_Field14(String Flex_Field14) 
	{
		this.Flex_Field14 = Flex_Field14;
	}
	/**
	 * @return the Flex_Field15
	 */
	public String getFlex_Field15() 
	{
		return Flex_Field15;
	}
	/**
	 * @param Flex_Field15 the Flex_Field15 to set
	 */
	public void setFlex_Field15(String Flex_Field15) 
	{
		this.Flex_Field15 = Flex_Field15;
	}
	/**
	 * @return the Flex_Field16
	 */
	public String getFlex_Field16() 
	{
		return Flex_Field16;
	}
	/**
	 * @param Flex_Field16 the Flex_Field16 to set
	 */
	public void setFlex_Field16(String Flex_Field16) 
	{
		this.Flex_Field16 = Flex_Field16;
	}
	/**
	 * @return the Flex_Field17
	 */
	public String getFlex_Field17() 
	{
		return Flex_Field17;
	}
	/**
	 * @param Flex_Field17 the Flex_Field17 to set
	 */
	public void setFlex_Field17(String Flex_Field17) 
	{
		this.Flex_Field17 = Flex_Field17;
	}
	/**
	 * @return the Flex_Field18
	 */
	public String getFlex_Field18() 
	{
		return Flex_Field18;
	}
	/**
	 * @param Flex_Field18 the Flex_Field18 to set
	 */
	public void setFlex_Field18(String Flex_Field18) 
	{
		this.Flex_Field18 = Flex_Field18;
	}
	/**
	 * @return the Flex_Field19
	 */
	public String getFlex_Field19() 
	{
		return Flex_Field19;
	}
	/**
	 * @param Flex_Field19 the Flex_Field19 to set
	 */
	public void setFlex_Field19(String Flex_Field19) 
	{
		this.Flex_Field19 = Flex_Field19;
	}
	/**
	 * @return the Flex_Field20
	 */
	public String getFlex_Field20() 
	{
		return Flex_Field20;
	}
	/**
	 * @param Flex_Field20 the Flex_Field20 to set
	 */
	public void setFlex_Field20(String Flex_Field20) 
	{
		this.Flex_Field20 = Flex_Field20;
	}	
}
