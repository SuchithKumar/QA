package com.bsc.qa.facets.tests;

import java.io.IOException;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.bsc.qes.facets.dfpojo.readers.BinderPaymentFileReader;
import com.relevantcodes.extentreports.LogStatus;

//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒SAMPLE SAMPLE SAMPLE SINGLE METHOD EXAMPLE CLASS SAMPLE SAMPLE SAMPLE▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒SAMPLE SAMPLE SAMPLE SINGLE METHOD EXAMPLE CLASS SAMPLE SAMPLE SAMPLE▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

public class MamSingleElementsValidation extends BaseTest implements IHookable{
	
	//private static String strSubscriber_ID;  
    private static int bodyRowsCount;
    
    final private static String strUniqueIdentifier1 = "ACCOUNT_NUMBER"; // <= first 
    //final private static String strUniqueIdentifier2 = "RELATIONSHIP_CODE"; // <= second
    
    private static BinderPaymentFileReader ffpExtract;
    
	private static List<Map<String, String>> testHeader;
	private static List<Map<String, String>> testBody;
	private static List<Map<String, String>> testFooter;
    
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles", "FileSpecificFolderName"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
        
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
	 	
		//NOTE DB UTIL OBJECT CREATION! 
		objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		 
		 TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
		 
		 filePAth = tesFile.getCompleteTestFilePath();	 
		 
		 //read flat file before test 
		  ffpExtract = new BinderPaymentFileReader(filePAth);
		 
			//Parse headers and store in to testHeaders
			try {
				
				testHeader = ffpExtract.getListOfHeaderValues();
			
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
				
			}
			
			//Parse body and store in to testBody list 
			try {			
				testBody = ffpExtract.getListOfBodyValues(); // array list of hash map values 
			
				bodyRowsCount = testBody.size(); // body rows count
				
				System.out.println(bodyRowsCount);
			
			} catch (IOException e) {
				
				System.out.println("BAD PARSING REQUEST testBody LIST NOT CREATED");
				e.printStackTrace();
				
			}

			
        	//Parse footers and store in to testFooter list 
			try {
				
				testFooter = ffpExtract.getListOfFooterValues();
				
			} catch (IOException e) {
				
				System.out.println("BAD PARSING REQUEST testFooter LIST NOT CREATED");
				
				e.printStackTrace();
			}
			
	}


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ HEADER TEST METHODS START @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

	@Test(dataProvider = "masterDataProvider") // data provider method all the way at the bottom of this class 
	private static void testMAMHeaderRecordType(Map<String, String> data) { // <== note test method name also points to row number in test data sheet 
		
		String[] ArrayResult = null;
		
		SoftAssert softAssertion= new SoftAssert();
		//get sql from test data sheet
	    String SQLQuery = data.get("sql_header_record_type").toString(); //<== points to column name
	   
	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    		
	    	  System.out.println("Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			  System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
			  System.out.println("__________________________________________________________________________________________________________");
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here
	}
	
	
	
	@Test(dataProvider = "masterDataProvider") // data provider method all the way at the bottom of this class 
	private static void testMAMHeaderBillerName(Map<String, String> data) { // <== note test method name also points to row number in test data sheet 
		
		String[] ArrayResult = null;
		
		SoftAssert softAssertion= new SoftAssert();
		
		//get sql from test data sheet
	    String SQLQuery = data.get("sql_header_biller_name").toString(); //<== points to column name
	   
	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    		
	    	  System.out.println("Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			  System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
			  System.out.println("__________________________________________________________________________________________________________");
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here
	}
	
	@Test(dataProvider = "masterDataProvider") // data provider method all the way at the bottom of this class 
	private static void testMAMHeaderBillerCode(Map<String, String> data) { // <== note test method name also points to row number in test data sheet 
		
		String[] ArrayResult = null;
		
		SoftAssert softAssertion= new SoftAssert();
		//get sql from test data sheet
	    String SQLQuery = data.get("sql_header_biller_code").toString(); //<== points to column name
	   
	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    		
	    	  System.out.println("Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			  System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
			  System.out.println("__________________________________________________________________________________________________________");
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here
	}

	@Test(dataProvider = "masterDataProvider") // data provider method all the way at the bottom of this class 
	private static void testMAMHeaderRecordCount(Map<String, String> data) { // <== note test method name also points to row number in test data sheet 
		
		SoftAssert softAssertion= new SoftAssert();
		//get records column name to string 
		String expectedFieldName = "RECORD_COUNT"; // NO QUERY SO Field Name Coded <== RECORD COUNT ONLY
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	    	 
	        	String actualValue = flatFileValuesMap.get(expectedFieldName).toString().trim();
        		
        		//testing the lenth of TOTAL_RECORDS field
        		softAssertion.assertEquals((actualValue.length() + 1), 10, " Expected lenth of RECORD_COUNT is 10 chars long ");
        		
        		//remove zeros from 000000005 to 5
        		 actualValue = actualValue.replaceFirst("^0+(?!$)", "");
        		 
        		 //note the conversion of integer value 
        		 
        		 softAssertion.assertEquals(actualValue.trim(), (String.valueOf(bodyRowsCount)).trim(), " Expected Value: " + bodyRowsCount );
	    		
	    	  System.out.println("Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim()  );	
			  System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
			  System.out.println("__________________________________________________________________________________________________________");
	    	  
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Header Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here
	     
	}
	
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ HEADER TEST METHODS END @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ BODY TEST METHODS START @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyRecordType(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_record_type").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
						
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " + FlatFileMap.get(strUniqueIdentifier1) );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim() + " For Record: "+ FlatFileMap.get(strUniqueIdentifier1));
					  System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
					  System.out.println("__________________________________________________________________________________________________________");
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}
		
		@Test(dataProvider = "masterDataProvider")//, enabled = false)
		private static void testMAMBodyRecordMode(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_record_mode").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}
		
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyAccountNumber(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_account_number").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyFirstName(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_first_name").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}		

		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyLastName(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_last_name").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}			
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyZipCode(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_zip_code").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}					
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyGroupId(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_group_id").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}				
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyDisablePayment(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_disable_payment").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}						
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyBillType(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_bill_type").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}								
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyApplicationId(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_application_id").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}								
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyHixId(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_hix_id").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}										
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyEmail(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_email").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}										
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyExchangeIndicator(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_exchange_indicator").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}										
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyPaymentAmount(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_payment_amount").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}											
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyBillDueDate(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_bill_due_date").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}													
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyBillCoverageStartDate(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_bill_coverage_start_date").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}															
		
		@Test(dataProvider = "masterDataProvider")
		private static void testMAMBodyBillCoverageThruDate(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_body_bill_coverage_thru_date").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}												
		
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ BODY TEST METHODS END @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ FOOTER TEST METHODS START @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

		@Test(dataProvider = "masterDataProvider")
		private static void testMAMFooterRecordType(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("sql_footer_record_type").toString(); 
		    
		    
		    for (Map<String, String> FlatFileMap : testFooter) {
		      
		    	String strUniqueIdValueOne = FlatFileMap.get(strUniqueIdentifier1);
		    	//String strUniqueIdValueTwo = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValueOne, null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName)).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    		
			    	  System.out.println("Actual Value: " + (FlatFileMap.get(expectedFieldName)).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		    
		    softAssertion.assertAll();	//<== absolutely must be here   
		     				
		}		
		
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ FOOTER TEST METHODS END @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Test Methods that should be present in every test                      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    
private static DBUtils objDBUtility;//Mandatory declaration 
private static String filePAth ;//Mandatory 

//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) {
		Object[][] data = null;
		Map<String, String> dataMap = new HashMap<String, String>();

		dataMap = ExcelUtils.getTestMethodData(method.getName());
		data = new Object[][] { { dataMap } };
		return data;
	}

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
}
//┌───────────────────┐
//│ ╔═══╗ Delimited  │▒
//│ ╚═╦═╝ Files Test │▒
//╞═╤═╩═══╤══════════╡▒
//│ ├──┬──┤@ 2019    │▒
//│ └──┴──┘Automation│▒
//└──────────────────┘▒