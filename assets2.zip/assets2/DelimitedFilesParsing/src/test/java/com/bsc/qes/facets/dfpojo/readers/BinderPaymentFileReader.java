package com.bsc.qes.facets.dfpojo.readers;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;





import com.github.ffpojo.FFPojoHelper;
import com.bsc.qes.facets.ffpojo.dfp.mam.BinderPaymentBodyFields;
import com.bsc.qes.facets.ffpojo.dfp.mam.BinderPaymentHeaderFields;
import com.bsc.qes.facets.ffpojo.dfp.mam.BinderPaymentTrailerFields;

public class BinderPaymentFileReader 
{
	String testFlatFileCompletePath; // <== Path to a test file  
	
	public BinderPaymentFileReader(String testFlatFileCompletePath) 
	{
		this.testFlatFileCompletePath = testFlatFileCompletePath;
	} 	
	
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ Reading Header Elements ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

	public List<Map<String, String>> getListOfHeaderValues() throws IOException
	{
		List<Map<String , String>> headerList  = new ArrayList<Map<String,String>>();
		// get file 
        File inputFile = new File(testFlatFileCompletePath);
    	//test if file exist 
		if (!inputFile.exists()) 
		{ 
		//cry if file does not exist 
		throw new IllegalStateException("File not found: " + testFlatFileCompletePath);	
		} 
		else 
		{ 
			FFPojoHelper ffpojo = FFPojoHelper.getInstance();
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
	        String next, line = reader.readLine();
	         
	         int rowCounter = 0;
	         for (boolean first = true, last = (line == null); !last; first = false, line = next) 
	         {  
	        	 last = ((next = reader.readLine()) == null);
	                if (first) 
	                {
	                	Map<String,String> HeaderMap = new HashMap<String, String>();
	                	BinderPaymentHeaderFields header = ffpojo.createFromText(BinderPaymentHeaderFields.class, line);
	    				
    				    //System.out.println(header.getHeaderField1()+ " -- " +header.getHeaderField2()+ " -- "+ header.getHeaderField3()+ " -- "+ header.getHeaderField4());
	                	HeaderMap.put("null_00".toUpperCase(), header.getNull_00()); //<== Add 
	                	HeaderMap.put("Record_Type".toUpperCase(), header.getRecord_Type()); //<== Add 
    				    HeaderMap.put("File_Indicator".toUpperCase(), header.getFile_Indicator()); //<== Add 
    				    HeaderMap.put("Version".toUpperCase(), header.getVersion()); //<== Add 
    				    HeaderMap.put("Creation_Date".toUpperCase(), header.getCreation_Date()); //<== Add 					
   					    headerList.add(rowCounter,HeaderMap); //<== Put Hash Map to Array List.
   					    rowCounter++;
	                } 
	                else if (last) 
	                {
	                    //footer fields are not collected 
	                	//System.out.println("last line: " + line);
	                } 
	                else 
	                {
	                	
	                   // body field and not collected 
	                  //System.out.println("normal line: " + line);	    
	                }
	            }
	            if (reader != null) try { reader.close(); } catch (IOException logOrIgnore) {}
	
	    } 
		return headerList; // method return value 
	} 
	
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ Reading Body Elements ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒

	public List<Map<String, String>> getListOfBodyValues() throws IOException
	{
		List<Map<String , String>> bodyList  = new ArrayList<Map<String,String>>();
		// get file 
        File inputFile = new File(testFlatFileCompletePath);
    	//test if file exist 
		if (!inputFile.exists()) 
		{ 
			//cry if file does not exist 
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
		} 
		else 
		{ 
			FFPojoHelper ffpojo = FFPojoHelper.getInstance();
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
	        String next, line = reader.readLine();
	         
	         int rowCounter = 0;
	         for (boolean first = true, last = (line == null); !last; first = false, line = next) {
	                
	        	 last = ((next = reader.readLine()) == null);
	                if (first) 
	                {
	                	//System.out.println("first line: " + line);
	                } 
	                else if (last) 
	                {
	                	//System.out.println("last line: " + line);
	                } 
	                else 
	                {
	                	Map<String,String> bodyMap = new HashMap<String, String>();
	            		BinderPaymentBodyFields body = ffpojo.createFromText(BinderPaymentBodyFields.class, line);
	    				
    				    //System.out.println(body.getField1()+ " -- " +body.getField2()+ " -- "+ body.getField3()+ " -- "+ body.getField4()+ " -- "+ body.getField5() );
	            		bodyMap.put("null_00".toUpperCase(), body.getNull_00()); //<== Add 
    				    bodyMap.put("Record_Type".toUpperCase(), body.getRecord_Type()); //<== Add 
    				    bodyMap.put("Transaction_Id".toUpperCase(), body.getTransaction_Id()); //<== Add 
    				    bodyMap.put("Biller_Id".toUpperCase(), body.getBiller_Id()); //<== Add 
    				    bodyMap.put("Billing_Account".toUpperCase(), body.getBilling_Account()); //<== Add 
    				    bodyMap.put("Sub_Account".toUpperCase(), body.getSub_Account()); //<== Add 
    				    bodyMap.put("Sub_Account_Type".toUpperCase(), body.getSub_Account_Type()); //<== Add 
    				    bodyMap.put("Payment_Amount".toUpperCase(), body.getPayment_Amount()); //<== Add 
    				    bodyMap.put("Convenience_Fee".toUpperCase(), body.getConvenience_Fee()); //<== Add 
    				    bodyMap.put("Total_Amount".toUpperCase(), body.getTotal_Amount()); //<== Add 
    				    bodyMap.put("Payment_Due_Date".toUpperCase(), body.getPayment_Due_Date()); //<== Add 
    				    bodyMap.put("Flex_Field1".toUpperCase(), body.getFlex_Field1()); //<== Add 
    				    bodyMap.put("Flex_Field2".toUpperCase(), body.getFlex_Field2()); //<== Add 
    				    bodyMap.put("Flex_Field3".toUpperCase(), body.getFlex_Field3()); //<== Add 
    				    bodyMap.put("Flex_Field4".toUpperCase(), body.getFlex_Field4()); //<== Add 
    				    bodyMap.put("Flex_Field5".toUpperCase(), body.getFlex_Field5()); //<== Add 
    				    bodyMap.put("Group_Id".toUpperCase(), body.getGroup_Id()); //<== Add 
    				    bodyMap.put("Bill_Type".toUpperCase(), body.getBill_Type()); //<== Add
    				    bodyMap.put("Hix_Id".toUpperCase(), body.getHix_Id()); //<== Add 
    				    bodyMap.put("First_Name".toUpperCase(), body.getFirst_Name()); //<== Add 
    				    bodyMap.put("Last_Name".toUpperCase(), body.getLast_Name()); //<== Add 
    				    bodyMap.put("Flex_Field11".toUpperCase(), body.getFlex_Field11()); //<== Add 
    				    bodyMap.put("Flex_Field12".toUpperCase(), body.getFlex_Field12()); //<== Add 
    				    bodyMap.put("Flex_Field13".toUpperCase(), body.getFlex_Field13()); //<== Add 
    				    bodyMap.put("Flex_Field14".toUpperCase(), body.getFlex_Field14()); //<== Add 
    				    bodyMap.put("Flex_Field15".toUpperCase(), body.getFlex_Field15()); //<== Add 
    				    bodyMap.put("Flex_Field16".toUpperCase(), body.getFlex_Field16()); //<== Add
    				    bodyMap.put("Flex_Field17".toUpperCase(), body.getFlex_Field17()); //<== Add 
    				    bodyMap.put("Flex_Field18".toUpperCase(), body.getFlex_Field18()); //<== Add 
    				    bodyMap.put("Flex_Field19".toUpperCase(), body.getFlex_Field19()); //<== Add 
    				    bodyMap.put("Flex_Field20".toUpperCase(), body.getFlex_Field20()); //<== Add 		
   					    bodyList.add(rowCounter,bodyMap); //<== Put Hash Map to Array List.
   					    rowCounter++;
	                }
	            }
	     
	            if (reader != null) try { reader.close(); } catch (IOException logOrIgnore) {}
	
	    } 
		return bodyList; // method return value 
	} 
	
//▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ Reading Footer Elements ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
	
	public List<Map<String, String>> getListOfFooterValues() throws IOException
	{
		List<Map<String , String>> footerList  = new ArrayList<Map<String,String>>();
		// get file 
        File inputFile = new File(testFlatFileCompletePath);
    	//test if file exist 
		if (!inputFile.exists()) 
		{ 
		//cry if file does not exist 
		throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
		} 
		else 
		{  
			FFPojoHelper ffpojo = FFPojoHelper.getInstance();
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));

	         String next, line = reader.readLine();
	         
	         int rowCounter = 0;
	         for (boolean first = true, last = (line == null); !last; first = false, line = next) {
	                
	        	 last = ((next = reader.readLine()) == null);

	                if (first) 
	                {
		               // header fields and not collected 
	                } 
	                else if (last) 
	                {
	                	Map<String,String> FooterMap = new HashMap<String, String>();
	                	BinderPaymentTrailerFields footer = ffpojo.createFromText(BinderPaymentTrailerFields.class, line);
	    				
    				    //System.out.println(footer.getFooterfield());
	                	
	                	FooterMap.put("null_00".toUpperCase(), footer.getNull_00()); //<== Add 
    				    FooterMap.put("Record_Type".toUpperCase(), footer.getRecord_Type()); //<== Add 
    				    FooterMap.put("Transaction_Count".toUpperCase(), footer.getTransaction_Count()); //<== Add 
    				    FooterMap.put("Total_Payment_Amount".toUpperCase(), footer.getTotal_Payment_Amount()); //<== Add 
    				    FooterMap.put("Total_Convenience_Fee".toUpperCase(), footer.getTotal_Convenience_Fee()); //<== Add 
    				    FooterMap.put("Total_Total_Amount".toUpperCase(), footer.getTotal_Total_Amount()); //<== Add 
   					    footerList.add(rowCounter,FooterMap); //<== Put Hash Map to Array List.
   					    rowCounter++;
	                } 
	                else 
	                {
	                   // body field and not collected 
	                  //System.out.println("normal line: " + line);	    
	                }
	                
	            }
	     
	            if (reader != null) try { reader.close(); } catch (IOException logOrIgnore) {}
	    } 
		return footerList; // method return value 
		
	} 
	
}

