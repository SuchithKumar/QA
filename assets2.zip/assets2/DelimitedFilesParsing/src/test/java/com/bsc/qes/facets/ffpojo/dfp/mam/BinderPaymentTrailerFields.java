package com.bsc.qes.facets.ffpojo.dfp.mam;

public class BinderPaymentTrailerFields 
{
	private String null_00;
	private String Record_Type;
	private String Transaction_Count;
	private String Total_Payment_Amount;
	private String Total_Convenience_Fee;
	private String Total_Total_Amount;

	/**
	 * @return the null_00
	 */
	public String getNull_00() {
		return null_00;
	}

	/**
	 * @param null_00 the null_00 to set
	 */
	public void setNull_00(String null_00) {
		this.null_00 = null_00;
	}

	/**
	 * @return the Record_Type
	 */
	public String getRecord_Type() 
	{
		return Record_Type;
	}

	/**
	 * @param Record_Type the Record_Type to set
	 */
	public void setRecord_Type(String Record_Type) 
	{
		this.Record_Type = Record_Type;
	}
	
	/**
	 * @return the Transaction_Count
	 */
	public String getTransaction_Count() 
	{
		return Transaction_Count;
	}

	/**
	 * @param Transaction_Count the Transaction_Count to set
	 */
	public void setTransaction_Count(String Transaction_Count) 
	{
		this.Transaction_Count = Transaction_Count;
	}
	/**
	 * @return the Total_Payment_Amount
	 */
	public String getTotal_Payment_Amount() 
	{
		return Total_Payment_Amount;
	}

	/**
	 * @param Total_Payment_Amount the Total_Payment_Amount to set
	 */
	public void setTotal_Payment_Amount(String Total_Payment_Amount) 
	{
		this.Total_Payment_Amount = Total_Payment_Amount;
	}
	
	/**
	 * @return the Total_Convenience_Fee
	 */
	public String getTotal_Convenience_Fee() 
	{
		return Total_Convenience_Fee;
	}

	/**
	 * @param Total_Convenience_Fee the Total_Convenience_Fee to set
	 */
	public void setTotal_Convenience_Fee(String Total_Convenience_Fee) 
	{
		this.Total_Convenience_Fee = Total_Convenience_Fee;
	}
	/**
	 * @return the Total_Total_Amount
	 */
	public String getTotal_Total_Amount() 
	{
		return Total_Total_Amount;
	}

	/**
	 * @param Total_Total_Amount the Total_Total_Amount to set
	 */
	public void setTotal_Total_Amount(String Total_Total_Amount) 
	{
		this.Total_Total_Amount = Total_Total_Amount;
	}	
}
