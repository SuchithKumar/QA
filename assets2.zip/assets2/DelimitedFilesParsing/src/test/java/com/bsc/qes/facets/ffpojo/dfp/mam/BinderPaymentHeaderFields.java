package com.bsc.qes.facets.ffpojo.dfp.mam;

public class BinderPaymentHeaderFields 
{
	private String null_00;
	private String Record_Type;
	private String File_Indicator;
	private String Version;
	private String Creation_Date;
	
	/**
	 * @return the null_00
	 */
	public String getNull_00() {
		return null_00;
	}
	/**
	 * @param null_00 the null_00 to set
	 */
	public void setNull_00(String null_00) {
		this.null_00 = null_00;
	}
	
	/**
	 * @return the Record_Type
	 */
	public String getRecord_Type() 
	{
		return Record_Type;
	}
	/**
	 * @param Record_Type the Record_Type to set
	 */
	public void setRecord_Type(String Record_Type) 
	{
		this.Record_Type = Record_Type;
	}
	/**
	 * @return the File_Indicator
	 */
	public String getFile_Indicator() 
	{
		return File_Indicator;
	}
	/**
	 * @param File_Indicator the File_Indicator to set
	 */
	public void setFile_Indicator(String File_Indicator) 
	{
		this.File_Indicator = File_Indicator;
	}
	/**
	 * @return the Version
	 */
	public String getVersion() 
	{
		return Version;
	}
	/**
	 * @param Version the Version to set
	 */
	public void setVersion(String Version) 
	{
		this.Version = Version;
	}
	/**
	 * @return the Creation_Date
	 */
	public String getCreation_Date() 
	{
		return Creation_Date;
	}
	/**
	 * @param Creation_Date the Creation_Date to set
	 */
	public void setCreation_Date(String Creation_Date) 
	{
		this.Creation_Date = Creation_Date;
	}
	
}
