package com.bsc.qa.facets.tests;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import org.apache.commons.io.FileUtils;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.OtherUtilities;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.bsc.qa.facets.ffpojo.utility.XMLParse;
import com.relevantcodes.extentreports.LogStatus;

public class BscaCare1stMMTest extends BaseTest implements IHookable {
public 	static String DB_Name_FromUI;
public static String DB_User_FromUI;
public  static String DB_Pwd_FromUI;
public static String RootLocationOfFlatFiles_FromUI;
public static String TestDataSheetLocation_FromUI;
public static String ResultsDestinationFolderPath_FromUI;
public static String filePath;
private static String sheetName;
public static DBUtils objDBUtility;//Mandatory declaration 
public static String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss")); 
private static Path path;
private static Path inputDataPath;
public static Path extentReportDestinationPath;
//private static String resultsDestinationFolderPath;
//private static String rootLocationOfInputFiles;
private static String SUCName;
private static ArrayList<String> transactionIdList = new ArrayList<String>();
private static ArrayList<String> idList;

static SoftAssert softAssertion= new SoftAssert();	
	

	//************************************** TEST METHODS************************
		@Test(dataProvider = "masterDataProvider")
		private static void testXMLToDBValidationProvider(Map<String, String> data) {
			
			try {
				 Map<String,String> claimIdMap = new HashMap<String,String>();
				 Map<String,String> querydataMap1 = new HashMap<String,String>();
				 Map<String,String> querydataMap2 = new HashMap<String,String>();
				Map<String,String> querydataMap3 = new HashMap<String,String>();
				 Map<String,String> querydataMap4 = new HashMap<String,String>();
				 Map<String,String> querydataMap5 = new HashMap<String,String>();
				 Map<String,String> querydataMap6 = new HashMap<String,String>();
				 Map<String,String> querydataMap7 = new HashMap<String,String>();
				 List< Map<String,String>> dBValuesList = new ArrayList< Map<String,String>>();
				 
				OtherUtilities.printTestCaseDeatilsInReport(data);
				//Retrieving data from test data sheet and storing data in variables
				
				SUCName = data.get("Keyword Name").toString();
				String xmlTag=data.get("Element TagName").toString().trim();	
				//String sheetName_MetadataSheet="Subscriber_EOB";
				String inputFileName=data.get("Input File Name").toString();
				String xmlFilePath = RootLocationOfFlatFiles_FromUI + "\\" + inputFileName;
				XMLParse.xmlSetup(xmlFilePath);
				String mappingSheetName="Mappingsheet_Provider";
				
			//	String mappingSheetPath="/DbToSubscriberXmlVal/src/test/resources/TestData.xlsx";
				transactionIdList = XMLParse.attributeValue(xmlTag,"stmt_num");
				
				//idList = XMLParse.attributeValue("claim", "payer_claim_control_num");
				
//for(int i=0;i<transactionIdList.size();i++){
					
					claimIdMap = XMLParse.extractClaimId("stmt", "claim", transactionIdList.get(0));
					
					
					String tcnId = transactionIdList.get(0).substring(0,16);
					
					String seqId = transactionIdList.get(0).substring(16,16+transactionIdList.get(0).length()-16);
					
			/*		System.out.println("The tcn id is "+tcnId+" the seq id is "+seqId);
					
					System.out.println("The claim tag index is "+XMLParse.claimIdIndex);*/
					
					
					for(int claimIndex = 1;claimIndex<=Integer.valueOf(claimIdMap.get("Index"));claimIndex++){
						
						String query1 = data.get("Query1");
						String query2 = data.get("Query2");
						
						String query3 = data.get("Query3");
						String query4 = data.get("Query4");
						String query5 = data.get("Query5");
						String query6 = data.get("Query6");
						String query7 = data.get("Query7");
						String claimId = claimIdMap.get(transactionIdList.get(0)+"_"+claimIndex);
						
						//System.out.println("The claim id is "+claimId);
						
						query1 = query1.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						
						query2 = query2.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
					
						
						query3 = query3.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						query4 = query4.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						query5 = query5.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						query6 = query6.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						query7 = query7.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						
						
						querydataMap1 =  objDBUtility.resultSetToDictionary(query1,claimId,transactionIdList.get(0));
						
					/*	querydataMap2 = objDBUtility.resultSetToDictionary(query2,claimId,transactionIdList.get(0));
						
						querydataMap3 = objDBUtility.resultSetToDictionary(query3,claimId,transactionIdList.get(0));
						
						querydataMap4 = objDBUtility.resultSetToDictionary(query4,claimId,transactionIdList.get(0));
						
						querydataMap5 = objDBUtility.resultSetToDictionary(query5,claimId,transactionIdList.get(0));
						
						querydataMap6 = objDBUtility.resultSetToDictionary(query6,claimId,transactionIdList.get(0));
						
						querydataMap7 = objDBUtility.resultSetToDictionary(query7,claimId,transactionIdList.get(0));
						*/
						
						
						System.out.println("The query map1 is "+ querydataMap1 );
						/*System.out.println("The query map2 is "+ querydataMap2);
						System.out.println("The query map3 is "+ querydataMap3 );
						System.out.println("The query map4 is "+ querydataMap4 );
						System.out.println("The query map5 is "+ querydataMap5 );
						System.out.println("The query map6 is "+ querydataMap6 );
						System.out.println("The query map7 is "+ querydataMap7 );
						*/
						dBValuesList.add(querydataMap1);
						
						/*dBValuesList.add(querydataMap2);
						
						dBValuesList.add(querydataMap3);
						
						dBValuesList.add(querydataMap4);
						
						dBValuesList.add(querydataMap5);
						
						dBValuesList.add(querydataMap6);
						
						dBValuesList.add(querydataMap7);
						*/
						//query = query.replaceAll(tcnId,"Trans_Id").replaceAll(seqId,"Seq_Id").replaceAll(claimId,"Claim_Id");
					}
					
					//System.out.println("The claim id map is "+claimIdMap.get(transactionIdList.get(2)+"_150"));
					//System.out.println("The transaction id's are "+transactionIdList.get(i));
					
					XMLParse.nodeExtraction(xmlTag,transactionIdList.get(0),mappingSheetName,claimIdMap,dBValuesList,softAssertion);
					
					
				
				
				/*for(int i=0;i<transactionIdList.size();i++){
					
					claimIdMap = XMLParse.extractClaimId("stmt", "claim", transactionIdList.get(i));
					
					
					String tcnId = transactionIdList.get(i).substring(0,16);
					
					String seqId = transactionIdList.get(i).substring(16,16+transactionIdList.get(i).length()-16);
					
					System.out.println("The tcn id is "+tcnId+" the seq id is "+seqId);
					
					System.out.println("The claim tag index is "+XMLParse.claimIdIndex);
					
					
					for(int claimIndex = 1;claimIndex<=Integer.valueOf(claimIdMap.get("Index"));claimIndex++){
						
						String query1 = data.get("Query1");
						String query2 = data.get("Query2");
						
						String query3 = data.get("Query3");
						String query4 = data.get("Query4");
						String query5 = data.get("Query5");
						String query6 = data.get("Query6");
						String query7 = data.get("Query7");
						String claimId = claimIdMap.get(transactionIdList.get(i)+"_"+claimIndex);
						
						//System.out.println("The claim id is "+claimId);
						
						query1 = query1.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						
						query2 = query2.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
					
						
						query3 = query3.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						query4 = query4.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						query5 = query5.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						query6 = query6.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						query7 = query7.replaceAll("Trans_Id", tcnId).replaceAll("Seq_Id", seqId).replaceAll("Claim_Id", claimId);
						
						
						querydataMap1 =  objDBUtility.resultSetToDictionary(query1,claimId,transactionIdList.get(i));
						
						querydataMap2 = objDBUtility.resultSetToDictionary(query2,claimId,transactionIdList.get(i));
						
						querydataMap3 = objDBUtility.resultSetToDictionary(query3,claimId,transactionIdList.get(i));
						
						querydataMap4 = objDBUtility.resultSetToDictionary(query4,claimId,transactionIdList.get(i));
						
						querydataMap5 = objDBUtility.resultSetToDictionary(query5,claimId,transactionIdList.get(i));
						
						querydataMap6 = objDBUtility.resultSetToDictionary(query6,claimId,transactionIdList.get(i));
						
						querydataMap7 = objDBUtility.resultSetToDictionary(query7,claimId,transactionIdList.get(i));
						
						
						
						System.out.println("The query map1 is "+ querydataMap1 );
						System.out.println("The query map2 is "+ querydataMap2);
						System.out.println("The query map3 is "+ querydataMap3 );
						System.out.println("The query map4 is "+ querydataMap4 );
						System.out.println("The query map5 is "+ querydataMap5 );
						System.out.println("The query map6 is "+ querydataMap6 );
						System.out.println("The query map7 is "+ querydataMap7 );
						
						dBValuesList.add(querydataMap1);
						
						dBValuesList.add(querydataMap2);
						
						dBValuesList.add(querydataMap3);
						
						dBValuesList.add(querydataMap4);
						
						dBValuesList.add(querydataMap5);
						
						dBValuesList.add(querydataMap6);
						
						dBValuesList.add(querydataMap7);
						
						//query = query.replaceAll(tcnId,"Trans_Id").replaceAll(seqId,"Seq_Id").replaceAll(claimId,"Claim_Id");
					}
					
					//System.out.println("The claim id map is "+claimIdMap.get(transactionIdList.get(2)+"_150"));
					//System.out.println("The transaction id's are "+transactionIdList.get(i));
					
					XMLParse.nodeExtraction(xmlTag,transactionIdList.get(i),mappingSheetName,claimIdMap,dBValuesList,softAssertion);
					
					
				}*/
				
				
				
				
				
				//XMLParse.nodeExtraction(xmlTag,transactionNo,mappingSheetName,subscriberId,softAssertion);
				//OtherUtilities.validate(sourceRowMap,queryDataMap,softAssertion);*/
				 } catch (Exception e){
						//System.out.println("Test Case Failed due to Exception.....!!");
						softAssertion.assertTrue(false, "Test Case Failed due to Exception.....!!"+e.getMessage() );
						e.printStackTrace();
					}finally{
						//softAssertion.assertAll();	//<== absolutely must be here
					}
					
		}
		
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","DB_Server","DB_Port"}) //Note parrams order	
	public void setUpTest(String NameOfTestDataSheet,  String DB_Server, String DB_Port){ 
		
		//HomeUI hi=new HomeUI();
		DB_Name_FromUI=HomeUI.environmentValue;
		DB_User_FromUI=HomeUI.dbUsername;
		DB_Pwd_FromUI=HomeUI.dbPassword;
		RootLocationOfFlatFiles_FromUI=HomeUI.pathForXML;
		TestDataSheetLocation_FromUI=HomeUI.pathForTestDataSheet;
		ResultsDestinationFolderPath_FromUI=HomeUI.pathForResults;
		
		System.out.println("The datasheet path is "+TestDataSheetLocation_FromUI);
		
		//Args order matters should match to params orders
		filePath=TestDataSheetLocation_FromUI;
		path = Paths.get("target\\Results\\"+timestamp);
		 if(!Files.exists(path)){
			try {
				Files.createDirectories(path);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		//System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		//test data sheet name
		sheetName=NameOfTestDataSheet;
		//path of the input test files
		//rootLocationOfInputFiles = RootLocationOfFlatFiles_FromUI;
		//path of the results folder 
		//resultsDestinationFolderPath=ResultsDestinationFolderPath;
		// Functional call to initialize cache from data sheet 
	//	ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name_FromUI, DB_User_FromUI, DB_Pwd_FromUI, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		//statement to set up databse connection
		 objDBUtility.setUpDBConnection();
		 //Below step is for setting up the path of the input file
		 //TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
			//Below step is for getting complete path of the input file		 
		 
		 //filePAth = tesFile.getCompleteTestFilePath();	 
		
	}


//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		Map map=(Map) callBack.getParameters()[0];
		String testCaseName= "EOBXML"/*+",SubscriberID:"+map.get("Query parameter1")*/;
		reportInit(testResult.getTestContext().getName(), testResult.getName(),testCaseName);
		System.out.println("testCaseName"+testCaseName);
		
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		
		try {
			ExcelUtils.writeToWorkBook(filePath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) throws Exception{


		  Object[][] columnArray=   ExcelUtils.getColumnArray(filePath, sheetName);
		  Object[][] testDataArray= ExcelUtils.getTableArray(filePath, sheetName);
		  List<Object> list=new ArrayList<Object>();
		
		  int noOfTestCases=0;
		  String runMode="Yes";
		  for(int row=0;row<=testDataArray.length-1;row++){
			if(method.getName().substring(4).equalsIgnoreCase(testDataArray[row][1].toString())&& runMode.equalsIgnoreCase(testDataArray[row][2].toString())){
				noOfTestCases++;
				//System.out.println("TestCase  Data Sheet:::"+testDataArray[row][1].toString());
				//map for storing all rows which are having run mode "yes"
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col=0;col<=columnArray[0].length-1;col++)
				{
				//looping through all teh columns and puting the values in rowmap
					rowDataMap.put(columnArray[0][col].toString(), testDataArray[row][col].toString());
					
				}
				//System.out.println("Row Datamap"+rowDataMap);
				list.add(rowDataMap);//adding rows map in to list
				//data[row][0]=rowDataMap;
			}
		}
		  Object[][] data = new Object[noOfTestCases][1];
		  for(int row=0;row<list.size();row++){
			  data[row][0]=list.get(row);//adding the rowmap data into object array
		  }
		
		return data;
	}
	@AfterClass
	public void afterClass() {
		//clsong the report after execution
		ReportFactory.closeReport();
	}
	
	@AfterMethod
	public void afterMethod() throws IOException{
		//path for results destination folder
		inputDataPath = Paths.get(ResultsDestinationFolderPath_FromUI+timestamp+"\\InputData");
		if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(inputDataPath);//Creating directory
			}
		File srcDir = new File(RootLocationOfFlatFiles_FromUI+"\\");//Input Data folder path
		Path SUCFolderPath = Paths.get(ResultsDestinationFolderPath_FromUI+timestamp+"\\InputData\\"+SUCName);
		if(!Files.exists(SUCFolderPath)){		//checking for the existance of inputDatapath
		Files.createDirectories(SUCFolderPath);//Creating directory
			}
		String destination = ResultsDestinationFolderPath_FromUI+timestamp+"\\InputData\\"+SUCName;
		File destDir = new File(destination);
		FileUtils.copyDirectory(srcDir, destDir);//copying directory
	}
	
		//after exection of all the tests in the suit,results and input data will be stored in results folder
	  @AfterSuite
	  public void afterSuite() {
			//assigning the resultsDestinationPath from testNG.xml
		try {
			//Copying Extent reports	
			Path extentReportSourcePath=Paths.get("target\\BSC-reports\\Report.html");//storing report source path in extentReportSourcePath
			File destReport = new File(ResultsDestinationFolderPath_FromUI+timestamp+"\\Report.html"); 
			extentReportDestinationPath=Paths.get(destReport.getAbsolutePath());//storing report source path in extentReportDestinationPath
			TestFileUtil.copyFile(extentReportSourcePath,extentReportDestinationPath);//copy function
			//TestFileUtil.copyFile(htmlReportSourcePath,htmlReportDestinationPath);//copy function
			//Creating folder for InputData
			inputDataPath = Paths.get(ResultsDestinationFolderPath_FromUI+timestamp+"\\InputData");
			if(!Files.exists(inputDataPath)){		//checking for the existance of inputDatapath
			Files.createDirectories(inputDataPath);//Creating directory
				}
			//Copying Data Sheet
			Path testDataSheetSourcePath=Paths.get(TestDataSheetLocation_FromUI);//storing report source path in testDataSourcePath
			File destFile = new File(ResultsDestinationFolderPath_FromUI+timestamp+"\\InputData\\TestData.xlsx");
			Path testDataSheetDestinationPath=Paths.get(destFile.getAbsolutePath());//storing report source path in testDataDestinationPath
			TestFileUtil.copyFile(testDataSheetSourcePath,testDataSheetDestinationPath);//copy function
			//Copying input files
			
			JOptionPane.showMessageDialog(null, "Process completed, check your folder..");
			
			
		} catch (IOException e) {
			e.printStackTrace();//Printing exception object 
		}

	  }
	 
	  
}
