package com.bsc.qa.facets.tests;

import java.awt.Desktop;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTextField;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.border.TitledBorder;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.UIManager;

import org.apache.commons.io.FileUtils;
import org.testng.TestNG;

import javax.swing.JProgressBar;

@SuppressWarnings("serial")
public class HomeUI extends JFrame {

	public JPanel contentPane;
	public static JTextField textField_xml;
	public static JTextField textField_testData;
	public int xx,xy;
	public static JTextField textField_DBUsername;
	public static JPasswordField passwordField_DBPassword;
	public static String pathForXML;
	public static String pathForTestDataSheet;
	public static String environmentValue;
	public static String rdbValue="DbToXml";
	public static String dbUsername,dbPassword;
	public static String pathForResults;
	public static String pathR;
	private JTextField textField_ResultsPath;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomeUI frame = new HomeUI();
					frame.setUndecorated(true);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HomeUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 726, 639);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, 0, 229, 646);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				xx=e.getX();
				xy=e.getY();
			}
		});
		lblNewLabel_1.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x =e.getXOnScreen();
				int y=e.getYOnScreen();
				
				HomeUI.this.setLocation(x-xx, y-xy);
				
			}
			
		});
		lblNewLabel_1.setIcon(new ImageIcon("\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\EOB Automation\\DbToProvXmlValBsc\\src\\test\\resources\\images\\logo.png"));
		lblNewLabel_1.setBounds(0, -15, 253, 238);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("XML VALIDATOR");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(10, 238, 200, 50);
		panel.add(lblNewLabel_2);
		
		JLabel lblinstructionsuploadTheEob = new JLabel("<html><body width='%1s'><h3>Steps to start validation:</h3><br>1. Browse EOB Xml file</br> <br>2. Browse Mapping Sheet</br><br>3. Select Environment</br> <br>4. Enter your Username & Password for selected Environment</br><br>5. Click START to initiate validation</br></html>");
		lblinstructionsuploadTheEob.setForeground(Color.WHITE);
		lblinstructionsuploadTheEob.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblinstructionsuploadTheEob.setBackground(Color.WHITE);
		lblinstructionsuploadTheEob.setBounds(10, 299, 200, 172);
		panel.add(lblinstructionsuploadTheEob);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\EOB Automation\\DbToProvXmlValBsc\\src\\test\\resources\\images\\xmlIcon2.jpg"));
		lblNewLabel.setBounds(291, 63, 69, 63);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("X");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setBounds(670, 11, 23, 39);
		contentPane.add(lblNewLabel_3);
		
		textField_xml = new JTextField();
		textField_xml.setBounds(370, 76, 206, 38);
		contentPane.add(textField_xml);
		textField_xml.setColumns(10);
		
		textField_testData = new JTextField();
		textField_testData.setBounds(370, 154, 206, 38);
		contentPane.add(textField_testData);
		textField_testData.setColumns(10);
		
		Button button_Launch = new Button("START");
		button_Launch.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				
				dbUsername=textField_DBUsername.getText();
				dbPassword=passwordField_DBPassword.getText();
				pathForResults=textField_ResultsPath.getText()+"\\";
				
				
				
				TestNG runner=new TestNG();
				 
				// Create a list of String 
				List<String> suitefiles=new ArrayList<String>();
				 
				// Add xml file which you have to execute
				suitefiles.add("C:\\bqsa\\workspace\\DbToProvXmlValBsc\\testng_qa2.xml");
				 
				// now set xml file for execution
				runner.setTestSuites(suitefiles);
				 
				// finally execute the runner using run method
				runner.run();
				
				
				
				
				System.out.println("XML path: "+pathForXML);
				System.out.println("Test Data Sheet path: "+pathForTestDataSheet);
				System.out.println("Select Environment: "+environmentValue);
				System.out.println("DB username & Password: "+dbUsername+" & "+dbPassword);
				System.out.println("Type of validation: "+rdbValue);
				System.out.println("pathFor results "+pathForResults);
				
				File report=BscaCare1stMMTest.extentReportDestinationPath.toFile();
				Desktop ds=Desktop.getDesktop();
				try {
					ds.open(report);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_Launch.setBackground(Color.LIGHT_GRAY);
		button_Launch.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_Launch.setBounds(370, 591, 206, 39);
		contentPane.add(button_Launch);
		
		Button button_xmlUpload = new Button("Browse");
		button_xmlUpload.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_xmlUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFileChooser chooserXML = new JFileChooser();
			    
			    int returnVal = chooserXML.showOpenDialog(null);
			    if(returnVal == JFileChooser.APPROVE_OPTION) {
			      
			             pathForXML=chooserXML.getSelectedFile().getParent();
			             
			             System.out.println("The xml path is "+pathForXML);
			            textField_xml.setText(pathForXML);
			    }
			 
				
				
			}
		});
		button_xmlUpload.setBackground(Color.LIGHT_GRAY);
		button_xmlUpload.setBounds(606, 76, 87, 38);
		contentPane.add(button_xmlUpload);
		
		Button button_dataSheetUpload = new Button("Browse");
		button_dataSheetUpload.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_dataSheetUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFileChooser chooserDataSheet = new JFileChooser();
			    
			    int returnVal = chooserDataSheet.showOpenDialog(null);
			    if(returnVal == JFileChooser.APPROVE_OPTION) {
			     
			             pathForTestDataSheet=chooserDataSheet.getSelectedFile().getAbsolutePath();
			            textField_testData.setText(pathForTestDataSheet);
			    }
			 
				
			}
		});
		button_dataSheetUpload.setBackground(Color.LIGHT_GRAY);
		button_dataSheetUpload.setBounds(606, 154, 87, 38);
		contentPane.add(button_dataSheetUpload);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.setIcon(new ImageIcon("\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\"
				+ "Automation\\EOB Automation\\DbToProvXmlValBsc\\src\\test\\resources\\images"
				+ "\\excelsheetLogo2.png"));
		lblNewLabel_4.setBounds(291, 142, 69, 63);
		contentPane.add(lblNewLabel_4);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", 
				TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(370, 299, 206, 187);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		textField_DBUsername = new JTextField();
		textField_DBUsername.setBounds(10, 46, 189, 35);
		panel_1.add(textField_DBUsername);
		textField_DBUsername.setColumns(10);
		
		passwordField_DBPassword = new JPasswordField();
		passwordField_DBPassword.setBounds(10, 127, 187, 35);
		panel_1.add(passwordField_DBPassword);
		
		JLabel lbl_DBUsername = new JLabel("Username");
		lbl_DBUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl_DBUsername.setBounds(10, 11, 200, 50);
		panel_1.add(lbl_DBUsername);
		
		JLabel lbl_DBPassword = new JLabel("Password");
		lbl_DBPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbl_DBPassword.setBounds(10, 91, 200, 50);
		panel_1.add(lbl_DBPassword);
		
		JLabel lblEnvironment = new JLabel("FACETS ENVIRONMENT");
		lblEnvironment.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblEnvironment.setBounds(248, 227, 121, 50);
		contentPane.add(lblEnvironment);
		
		JComboBox comboBox_Environment = new JComboBox();
		comboBox_Environment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				environmentValue=comboBox_Environment.getSelectedItem().toString();
				
			}
		});
		comboBox_Environment.setForeground(Color.DARK_GRAY);
		comboBox_Environment.setFont(new Font("Tahoma", Font.PLAIN, 12));
		comboBox_Environment.setBackground(Color.LIGHT_GRAY);
		comboBox_Environment.setModel(new DefaultComboBoxModel(new String[] {"SELECT", "FACN52A",
				"FACN51A", "FACH71A", "FACH70A", "FACH64A", "FACH63A"}));
		comboBox_Environment.setBounds(370, 235, 206, 35);
		contentPane.add(comboBox_Environment);
		
		textField_ResultsPath = new JTextField();
		textField_ResultsPath.setColumns(10);
		textField_ResultsPath.setBounds(370, 539, 206, 38);
		contentPane.add(textField_ResultsPath);
		
		JLabel lblPathForResults = new JLabel("Path for Results");
		lblPathForResults.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPathForResults.setBounds(248, 535, 121, 50);
		contentPane.add(lblPathForResults);
		
		/*JProgressBar progressBar = new JProgressBar();
		progressBar.setStringPainted(true);
		progressBar.setBounds(583, 602, 110, 17);
		contentPane.add(progressBar);*/
		
	/*	Button button_pathForResults = new Button("Browse");
		button_pathForResults.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFileChooser chooser = new JFileChooser();
			    chooser.setCurrentDirectory(new java.io.File("."));
			    chooser.setDialogTitle("choosertitle");
			    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			    chooser.setAcceptAllFileFilterUsed(false);

			    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			    	
			   try {
				 pathR= 	FileUtils.readFileToString(chooser.getCurrentDirectory(),"UTF-8");
				lblPathForResults.setText(pathR);
				
			} catch (IOException e1) {
				
				lblPathForResults.setText(pathR);
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			}
			}
		});
		button_pathForResults.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_pathForResults.setBackground(Color.LIGHT_GRAY);
		button_pathForResults.setBounds(606, 539, 87, 38);
		contentPane.add(button_pathForResults);*/
		
		
	}
}
