package com.bsc.qa.facets.ffpojo.utility;

import java.awt.Desktop;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import org.apache.commons.io.FileUtils;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.factory.ReportFactory;
import com.github.ffpojo.util.FileUtil;
import com.google.common.io.Files;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.awt.SystemColor;

public class DBConnection extends BaseTest{

	private JFrame frame;
	private DatabaseEnvironment environment;
	private JTextField UserName;
	private JPasswordField passwordField;
	private SelectValidation selectValidation;
	private static ArrayList<String> transactionIdList = new ArrayList<String>();
	private static ArrayList<String> idList;
	static DBUtils dbUtils;
	
	
	static SoftAssert softAssertion= new SoftAssert();	

	/**
	 * Launch the application.
	 */
	public static void dbConnection() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DBConnection window = new DBConnection();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DBConnection() {
		initialize();
		
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.setTitle("DbToXmlValidator!!");
		frame.setBounds(200, 200, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblEnvironment = new JLabel("Environment");
		lblEnvironment.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblEnvironment.setBounds(69, 57, 86, 14);
		frame.getContentPane().add(lblEnvironment);
		
		JComboBox SelectEnvironment = new JComboBox();
		SelectEnvironment.setModel(new DefaultComboBoxModel(new String[] {"-----Select-----", "FACN52A", "FACN51A", "FACH71A", "FACH70A", "FACH64A", "FACH63A"}));
		SelectEnvironment.setBounds(277, 55, 100, 20);
		frame.getContentPane().add(SelectEnvironment);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUsername.setBounds(69, 113, 86, 14);
		frame.getContentPane().add(lblUsername);
		
		UserName = new JTextField();
		UserName.setBounds(277, 111, 100, 20);
		frame.getContentPane().add(UserName);
		UserName.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPassword.setBounds(69, 164, 86, 14);
		frame.getContentPane().add(lblPassword);
		
		passwordField = new JPasswordField(20);
		passwordField.setBounds(277, 162, 100, 20);
		frame.getContentPane().add(passwordField);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
				if(SelectEnvironment.getSelectedIndex()!=0){
					
					if(UserName.getText()!=null&&!UserName.getText().equalsIgnoreCase("")){
						
						if(String.valueOf(passwordField.getPassword())!=null&&!String.valueOf(passwordField.getPassword()).equalsIgnoreCase("")){
							
							String dbName = SelectEnvironment.getSelectedItem().toString();
							
							System.out.println("The db name is "+dbName);
							
							String userName = UserName.getText();
							
							
							String password = String.valueOf(passwordField.getPassword());
							
							environment =  new DatabaseEnvironment();
							
							 environment.setEnvironment(dbName);
							 
							 String dbServer = environment.getDBServer();
							 
							 String dbPort = environment.getDBPort();
							
							 
							
							dbUtils = new DBUtils(dbName,userName,password,dbServer,dbPort);
							
							dbUtils.setUpDBConnection();
							
							
							
							
							
						}else{
							
							JOptionPane.showMessageDialog(null, "Please enter password!!");
						}
						
						
					}
					else{
						JOptionPane.showMessageDialog(null, "Please enter UserName!!");
					}
				}
				else{
					JOptionPane.showMessageDialog(null, "Please select Environment!!");
				}
				
			}catch(Exception E){
				
				E.printStackTrace();
			}
			}
		});
		btnNewButton.setBounds(107, 210, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnCompare = new JButton("Compare");
		btnCompare.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnCompare.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					Map<String,String> claimIdMap = new HashMap<String,String>();
				selectValidation = new SelectValidation();
				
				String testCaseName= "XML: "+selectValidation.xmlFile.getName();
				
				reportInit("DbToXmlValidation",testCaseName);
				
				XMLParse.xmlSetup(selectValidation.xmlFile.getAbsolutePath());
				
				String mappingSheetName="Mappingsheet_Provider";
				
				transactionIdList = XMLParse.attributeValue("stmt","stmt_num");
				
				//idList = XMLParse.attributeValue("claim", "payer_claim_control_num");
				
				claimIdMap = XMLParse.extractClaimId("stmt", "claim", transactionIdList.get(0));
				
				System.out.println("The claim id map is "+claimIdMap);
				XMLParse.nodeExtraction("stmt",transactionIdList.get(0),mappingSheetName,claimIdMap,softAssertion);
				
				
			/*	for(int i=0;i<transactionIdList.size();i++){
					
					claimIdMap = XMLParse.extractClaimId("stmt", "claim", transactionIdList.get(i));
					
					String tcnId = transactionIdList.get(i).substring(0,16);
					
					String seqId = transactionIdList.get(i).substring(16,16+(transactionIdList.get(i).length()-16));
					
					System.out.println("The tcnId is "+tcnId+"The seq id is "+seqId);
					for(int claimIndex =0;claimIndex<XMLParse.claimIdIndex;claimIndex++){
						
						
						
					}
					
					
					//System.out.println("The claim id map is "+claimIdMap.get(transactionIdList.get(2)+"_150"));
					//System.out.println("The transaction id's are "+transactionIdList.get(i));
					
					XMLParse.nodeExtraction("stmt",transactionIdList.get(i),mappingSheetName,claimIdMap,softAssertion);
					
					
				}*/
				
				JOptionPane.showMessageDialog(null, "Comparison is completed");
				
				File srcFile = new File(this.getClass().getResource("/Report.html").getFile());
				System.out.println(srcFile.getAbsolutePath());
				String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss"));
				
				//File destFile = new File("target/BSC-reports/"+timestamp+"/Report.html");
		
				
				
				
				ReportFactory.closeReport();
				
				File destFolder = new File(System.getProperty("user.dir")+"/target/BSC-reports/"+timestamp);
				if(destFolder.exists())
				{
					destFolder.delete();
				}
				destFolder.mkdirs();
				
				File destFile= new File(destFolder+"/Report.html");
				
				
				
				System.out.println(destFile.getAbsolutePath());
				
				java.nio.file.Files.copy(srcFile.toPath(), destFile.toPath());
								
								Desktop deskTop = Desktop.getDesktop();
								
								deskTop.open(destFolder);
								
								java.nio.file.Files.copy(SelectValidation.excelFile.toPath(),new File( destFolder+"/Result.xlsx").toPath());
				
				
			}catch(Exception E){
				
				JOptionPane.showMessageDialog(null, "Comparison is not successfull!!");
			
				E.printStackTrace();
			}
			}
		});
		btnCompare.setBounds(259, 210, 89, 23);
		frame.getContentPane().add(btnCompare);
	}
}
