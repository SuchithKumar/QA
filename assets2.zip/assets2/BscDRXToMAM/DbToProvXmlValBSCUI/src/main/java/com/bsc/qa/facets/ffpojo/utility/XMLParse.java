package com.bsc.qa.facets.ffpojo.utility;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.testng.asserts.SoftAssert;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.tests.BscaCare1stMMTest;
import com.relevantcodes.extentreports.LogStatus;

public class XMLParse extends BaseTest {

	private static DocumentBuilder dBuilder;
	private static Document doc;
	private static String uniqueId;
	public static int messageTextIndex;
	public static int hcpcsIndex;
	public static Map<String, String> claimListMap = new HashMap<String, String>();
	public static Map<String, String> claimMap = new HashMap<String, String>();
	public static int claimIdIndex;
	public static Map<String,String> claimidMap = new HashMap<String, String>();
	public static String claimId;
	public static int keyIndex;
	public static SoftAssert softAssertion;
	private static HashMap<Integer, String> collNumCellValueMap = new HashMap<Integer, String>();
	public static int claimTagIndex;
	private static int execNo_CollNum_Datasheet = 0;
	private static int elementName_CollNum_Datasheet = 1; 
	private static int xpath_Datasheet = 2;
	private static int expectedValue_CollNum_Datasheet = 3;
	
	private static int actualValueCollNum = 4;
	
	private static int resultCollNum = 5;
	private static int rowNum_Datasheet = 0;

	public static void xmlSetup(String xmlPath) {
		File fXmlFile = new File(xmlPath);// Creating file for the given path
		// ExcelUtilities.setUp();
		// creating instance for the DocumentBuilderFactory
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		try {
			// creating instance for the DocumentBuilder
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static ArrayList<String> attributeValue(String tagName,
			String attributename) {
		// System.out.println("Extracting attribute values!!");
		ArrayList<String> idList = new ArrayList<String>();// List for storing
															// attributes

		Map<String, ArrayList<String>> claimMap = new HashMap<String, ArrayList<String>>();
		// Accessing the the nodes having tagname
		NodeList PagesList = doc.getElementsByTagName(tagName);// tags are upto
																// refined
																// address
																// only.not
																// taking child
																// nodes like
																// address1
		// System.out.println("PagesList"+ PagesList);
		// Looping through the nodeslist
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {
			Node node = (Node) PagesList.item(nodeNo);
			// checking for the attributes in node
			if (node.hasAttributes()) {
				NamedNodeMap attributesList = node.getAttributes();// getting
																	// all the
																	// attributes
																	// in the
																	// node
				// looping through the attributes list
				for (int attribute_Number = 0; attribute_Number < attributesList
						.getLength(); attribute_Number++) {
					// getting Attributes in the attributes list
					Attr attr = (Attr) attributesList.item(attribute_Number);
					String attributeName = attr.getNodeName();
					String attributeValue = attr.getNodeValue();
					// System.out.println("The attribute values are !!!!"+attributeValue);

					if (attributeName.equalsIgnoreCase(attributename)
							&& (attributeValue.matches("^[0-9]*$"))) {

						idList.add(attributeValue);

					}
				}
			}
		}
		return idList;// retuning the attributes list

	}

	public static Map<String, String> extractClaimId(String tagName,
			String clamTagName, String uId) {

		ArrayList<String> claimList = new ArrayList<String>();
		NodeList PagesList = doc.getElementsByTagName(tagName);
		// System.out.println("size:"+PagesList.getLength());
		
		softAssertion = softAssert;// soft assertion for validation
		uniqueId = uId;// subscriber id value
		// System.out.println("index:"+getIndexOfTag(tagName,uniqueId));
		Node node = (Node) PagesList.item(getIndexOfTag(tagName, uniqueId));

		claimIdIndex = 1;
		// Node node1 =
		// (Node)PagesList.item(getIndexOfTag("refined_address",uniqueId));
		// System.out.println("list of node"+node);
		if (hasChildElements((Element) node)) {
			
			
			
			claimListMap = getClaimValues((Element) node);
			
			
					}
		return claimListMap;
	}

	// Method to extract s and attributes and its values
	public static void nodeExtraction(String tagName, String uId,
			String mappingSheetName, Map<String,String> claimIdMap, SoftAssert softAssert)
			throws Exception {
		// Accessing the the nodes having tagname
		// System.out.println("tagNmae:"+tagName);
		NodeList PagesList = doc.getElementsByTagName(tagName);
		// System.out.println("size:"+PagesList.getLength());

		softAssertion = softAssert;// soft assertion for validation
		uniqueId = uId;// subscriber id value

		messageTextIndex = 1;

		hcpcsIndex = 1;
		
		keyIndex = 1;
		
		claimTagIndex =1 ;
		claimidMap = claimIdMap;
		
		claimId = claimidMap.get(uniqueId+"_"+keyIndex);

		// System.out.println("index:"+getIndexOfTag(tagName,uniqueId));
		Node node = (Node) PagesList.item(getIndexOfTag(tagName, uniqueId));

		// Node node1 =
		// (Node)PagesList.item(getIndexOfTag("refined_address",uniqueId));
		// System.out.println("list of node"+node);
		if (hasChildElements((Element) node)) {// checking for node has child
												// elements or not
			getElementAtttributes((Element) node, mappingSheetName,
					claimId);// attributes elements of given node
			System.out.println("The sheet name is "+mappingSheetName);
			getChildElements((Element) node, mappingSheetName, claimId,
					tagName);// child elements of given node
		}

	}

	// Method to retrieve all the attributes of elements
	private static void getElementAtttributes(Element node, String sheetName,
			String Id) throws Exception {
		if (node.hasAttributes()) {// checking for attributes in node
			NamedNodeMap attributesList = node.getAttributes();// all attributes
																// in node
			for (int attribute_Number = 0; attribute_Number < attributesList
					.getLength(); attribute_Number++) {
				// Looping through the nodeslist and getting individual elements
				Attr attr = (Attr) attributesList.item(attribute_Number);
				String attributeName = attr.getNodeName();// Attribute name
				String attributeValue = attr.getNodeValue();// attribute value
				// System.out.println("attributeName: "+attributeName);
				// System.out.println("attributeValue: "+attributeValue);
				// System.out.println("Excel Sheet Value: "+Id);

				String xpath = getXPath(node);
				System.out.println("The xpath is " + xpath
						+ " attribute Name is " + attributeName
						+ "The expected Id is " + claimId + " The actual value is "
						+ attributeValue);
				if ( attributeName.equalsIgnoreCase("payer_claim_control_num")) {
					
					claimId =  claimidMap.get(uniqueId+"_"+keyIndex);
					

					// getting the query for the given element name
					String dbValue = getElementValueFromDB(xpath.trim(), Id,
							sheetName, node, hcpcsIndex, messageTextIndex);
					String ScrubbedDBVAlue = getscrubDBdata(node.getNodeName()
							.trim().toString(), dbValue);
					// System.out.println("I am inside If and getting DB value");
					// System.out.println("db value"+dbValue);
					if (dbValue != null) {

						// call validate method for validation of xml value and
						// db value
						validataXmlAndDbValues(attributeName
								.trim().toString(), attributeValue,
								ScrubbedDBVAlue, dbValue,xpath.trim(),String.valueOf(hcpcsIndex));
					}
					
					keyIndex++;
				} else if (attributeName.contains("provider_num")) {

					String dbValue = getElementValueFromDB(xpath, claimId,
							sheetName, node, hcpcsIndex, messageTextIndex);
					String ScrubbedDBVAlue = getscrubDBdata(node.getNodeName()
							.trim().toString(), dbValue);

					if (dbValue != null) {

						// call validate method for validation of xml value and
						// db value
						validataXmlAndDbValues(attributeName
								.trim().toString(), attributeValue,
								ScrubbedDBVAlue, dbValue,xpath.trim(),String.valueOf(hcpcsIndex));
					}
				}

				// }
			}
		}
	}

	private static void getValuesOfElement(Element node, String sheetName,
			String Id, int hcpcsIndex, int messageTextIndex)
			throws Exception {
		// getting the query for the given element name

		String xpath = getXPath(node);

		String dbValue = getElementValueFromDB(xpath, claimId, sheetName, node,
				hcpcsIndex, messageTextIndex);
		String ScrubbedDBVAlue = getscrubDBdata(xpath, dbValue);
		// System.out.println("Node Value = "+node.getNodeName().trim().toString());
		// String xPath = getXPath(node);
		String strValue = null;
		if (dbValue != null) {
			if (node.getNodeName().trim().toString()
					.equalsIgnoreCase("address_1")) {
				strValue = node.getTextContent().toUpperCase().replace(".", "");
				validataXmlAndDbValues(node.getNodeName()
						.trim().toString(), strValue, ScrubbedDBVAlue, dbValue,xpath.trim(),String.valueOf(hcpcsIndex));

			} else if (node.getNodeName().trim().toString()
					.equalsIgnoreCase("postal_code")) {
				strValue = node.getTextContent().toUpperCase().substring(0, 5);
				validataXmlAndDbValues(node.getNodeName()
						.trim().toString(), strValue, ScrubbedDBVAlue, dbValue,xpath.trim(),String.valueOf(hcpcsIndex));
				// System.out.println("The postal code is "+strValue);
			}

			else {

				// call validate method for validation of xml value and db value
				System.out.println("The hcpcsIndex is "+hcpcsIndex);
				validataXmlAndDbValues(node.getNodeName()
						.trim().toString(), node.getTextContent().trim()
						.toUpperCase(), ScrubbedDBVAlue, dbValue,xpath.trim(),String.valueOf(hcpcsIndex));
			}
		}
	}

	private static String getElementValueFromDB(String elemetName, String Id,
			String sheetName, Element node, int hcpcsIndex, int messageTextIndex)
			throws SQLException {
		// retrieve query for the given element name
		// System.out.println("elemetName Name:"+elemetName.trim().toString()+"|SheetName:"+sheetName);
		//SelectValidation selectValidation = new SelectValidation();
		ExcelUtils excelUtils = new ExcelUtils(SelectValidation.excelFile.getAbsolutePath(),sheetName);
		 
		String query = excelUtils.getQueryFromMappingSheet(elemetName,
				sheetName);
		String dbValue = null;
		// String xPath = getXPath(node);
		if (elemetName.equalsIgnoreCase("statement_mode")) {
			query = dbValue;
		} else if (elemetName.equalsIgnoreCase("correspondence")) {
			query = dbValue;
		}

		if (elemetName
				.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/original_composite_procedure/hcpcs_code")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_charge_amt")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/original_units_of_service_count")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_start_date")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/adjustment/contractual_obligation")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/allowed_amt")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/deductible_amt")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/service_supplemental_amt/copay_amt")
				|| elemetName
						.equalsIgnoreCase("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/claim/service/line_item_provider_pmt_amt_print")) {

			if (query != null) {// check for the null values of query
				// String SQLQuery=query.replace(
				// "VAR_SBSB_ID_VALUE",subscriberId);//replacing subscriber id

				String SQLQuery = query.replace("UniqueId", claimId);// replacing
																// subscriber id

				if (SQLQuery.contains("RowNo")) {
					SQLQuery = SQLQuery.replace("RowNo",
							String.valueOf(hcpcsIndex));

					System.out.println("Query after row no is replaced "
							+ SQLQuery);

				}
				// String SQLQuery=query.replace(
				// "{$PARAM1}",subscriberId);//replacing subscriber id
				// running the query and getting the database value
				dbValue = DBConnection.dbUtils
						.getDatabaseValue(SQLQuery);

				System.out.println("Db value after query replaced is "
						+ dbValue);

			}

		} else {

			if (query != null) {// check for the null values of query
				// String SQLQuery=query.replace(
				// "VAR_SBSB_ID_VALUE",subscriberId);//replacing subscriber id

				String SQLQuery = query.replace("UniqueId", claimId);// replacing
																// subscriber id

				// String SQLQuery=query.replace(
				// "{$PARAM1}",subscriberId);//replacing subscriber id
				// running the query and getting the database value
				dbValue = DBConnection.dbUtils
						.getDatabaseValue(SQLQuery);

			}
		}
		return dbValue;
	}

	// This method is to retrieve child nodes of node
	private static void getChildElements(Element nNode, String sheetName,
			String Id, String tagName) throws Exception {
		if(nNode.getNodeName().equalsIgnoreCase("claim")){
			
			claimTagIndex++;
			
		}
		
		NamedNodeMap attributesList = nNode.getAttributes();// all attributes in
		
		

		Node parent = nNode.getParentNode();
		System.out.println("parentnode is "+nNode.getNodeName());

		NodeList children = nNode.getChildNodes();// get child nodes of
													// node//child node is
		
		// System.out.println("children: "+children);
		String xpath = getXPath(nNode);
		
		for (int i = 0; i < children.getLength(); i++) { // loop through
															// child nodes
			Node node = (Node) children.item(i);
			// System.out.println("node children:"+node);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				if (hasChildElements((Element) node)) {// checking for child
					
					System.out.println("Verify The parent node name is "+node.getParentNode().getNodeName());
					if(claimTagIndex>1&&node.getParentNode().getNodeName().equalsIgnoreCase("claim")&&node.getNodeName().equalsIgnoreCase("claim_summary")){
						
						hcpcsIndex = 1;
						
						messageTextIndex =1;
					}
					
					getElementAtttributes((Element) node, sheetName, Id);// getting
																			// attributes
																			// of
																			// elements
					// System.out.println("Tag name : " + tagName);
					getChildElements((Element) node, sheetName, Id, tagName);// getting
																				// child
					
					
					
					// System.out.println("(Element)node"+(Element)node);

				}
				/*
				 * else if((node.toString().contains("allowed_amt"))&&
				 * (attributeValue.contains("270.00"))) { return; }
				 */
				else {
					if (node.getNodeName().equalsIgnoreCase("message_text")) {
						
						
						getValuesOfElement((Element) node, sheetName, Id,
								hcpcsIndex, messageTextIndex);
						messageTextIndex++;
					} else if (node.getNodeName()
							.equalsIgnoreCase("hcpcs_code")) {
						System.out.println("The hcpcsindex is " + hcpcsIndex);
						getValuesOfElement((Element) node, sheetName, Id,
								hcpcsIndex, messageTextIndex);
						hcpcsIndex++;
					} else {
						// System.out.println("I am in else printing DB");
						getValuesOfElement((Element) node, sheetName, Id,
								hcpcsIndex, messageTextIndex);// getting
																// values of
																// elements
					}
				}
			}

		}

	}

	private static boolean hasChildElements(Element el) {
		// get child nodes for the given node
		NodeList children = el.getChildNodes();

		for (int i = 0; i < children.getLength(); i++) {
			// looping through the nodes and checking for element node
			if (children.item(i).getNodeType() == Node.ELEMENT_NODE)// chck for
																	// element
																	// node

				return true;
		}
		return false;
	}

	public static int getIndexOfTag(String tagName, String uniqueId) {

		int tagIndex = 0;
		boolean flag = false;
		NodeList PagesList = doc.getElementsByTagName("*");
		for (int nodeNo = 0; nodeNo < PagesList.getLength(); nodeNo++) {

			Node node = (Node) PagesList.item(nodeNo);
			Element element = (Element) node;
			// System.out.println("element"+element);
			if (element.getTagName().toString().trim()
					.equalsIgnoreCase(tagName)) {
				tagIndex++;
			}
			/*
			 * else if(element.getTagName().toString().trim().equalsIgnoreCase(
			 * "refined_address")) { element.getFirstChild();
			 * 
			 * }
			 */

			if (node.hasAttributes()) {// check for node has attributes or not
				NamedNodeMap attributesList = node.getAttributes();// getting
																	// all
																	// attributes
																	// of node
				// looping through attributes list of element
				for (int attribute_Number = 0; attribute_Number < attributesList
						.getLength(); attribute_Number++) {
					Attr attr = (Attr) attributesList.item(attribute_Number);
					// String attributeName=attr.getNodeName();
					String attributeValue = attr.getNodeValue();// attribute
																// value
					// System.out.println("AttrValu:"+attributeValue+"|input:"+subscriberId+"|"+attributeValue.equals(subscriberId));
					if (attributeValue.toString().trim()
							.equalsIgnoreCase(uniqueId)) {// checking for the
															// attribute value
						flag = true;
						break;
					}
				}
				if (flag) {
					break;
				}
			}
		}
		return tagIndex;

	}

	public static String getscrubDBdata(String element, String value) {

		if (element
				.contains("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/bsc_line_of_business")) {
			value = value.replace("CARE1", "C1");
		}
		/*
		 * else if(element.contains("print_amt")) { value =
		 * value.replace("********270*DOLLARS*00*CTS*","270"); }
		 */
		else if (element
				.contains("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/payer_address/correspondence/refined_address/city")) {
			value = value.toUpperCase() + ",";
		} else if (element
				.contains("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/claim_batch/additional_funding_account_info/print_amt")) {
			try {

				if (value.indexOf(".") != 0) {
					value = "********" + value.substring(0, value.indexOf("."))
							+ "*DOLLARS*"
							+ value.substring(value.indexOf(".") + 1) + "*CTS*";
				}
			} catch (Exception e) {
				value = "********" + value + "*DOLLARS*" + "00*CTS*";
			}

		} else if (element
				.contains("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/fwd_claim/cover_sheet/return_address/refined_address/postal_code")) {
			value = value.substring(0, 5);

		} else if (element
				.contains("/claim_remittance_file/claim_remittance_batch/receiver_batch/claim_batch_group/stmt/provider/address/generic_address/address_1")) {
			value = value.replace(".", "");
			System.out.println(": " + value);

		}

		return value;

	}

	private static String getXPath(Node node) {
		Node parent = node.getParentNode();
		if (parent == null) {
			return "";
		}
		return getXPath(parent) + "/" + node.getNodeName();

	}

	public static Map<String,String> getClaimValues(Element nNode) {
		
		
		NodeList children = nNode.getChildNodes();// get child nodes of
		
		for (int i = 0; i < children.getLength(); i++) { // loop through
			// child nodes
			Node node = (Node) children.item(i);
			// System.out.println("node children:"+node);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				if (hasChildElements((Element) node)) {// checking for child
					System.out.println("The childnodename is "+node.getNodeName());
					if(node.getNodeName().trim().equalsIgnoreCase("claim")){
						
						if(node.hasAttributes()){
							
							NamedNodeMap attributeList = node.getAttributes();
							
							for(int attributeIndex =0;attributeIndex<attributeList.getLength();attributeIndex++){
								
								Attr attribute = (Attr) attributeList.item(attributeIndex);
								
								System.out.println("The attribute name is "+attribute.getName());
								if(attribute.getName().equalsIgnoreCase("payer_claim_control_num")){
									
									claimMap.put( uniqueId + "_" + String.valueOf(claimIdIndex),
											  attribute.getValue());
														  claimIdIndex++;
									
								}
								
							}
						}
					}
					
					else{
						
						getClaimValues((Element)node);
					}
					

				}
			
				
			}

		}
		return claimMap;

	}
	
	public static void updateDatasheet(String executionNo, String xpath,
			String element, String expectedXmlValue, 
			String dataSheetName,String actualValue,String result) throws Exception {
		
		
		SelectValidation selectValidation = new SelectValidation();
		
		ExcelUtils excelUtils = new ExcelUtils(SelectValidation.excelFile.getAbsolutePath(),"Result");
		
		
		
		if((!element.equalsIgnoreCase("insert_string"))&&(!element.equalsIgnoreCase("special_handling_code"))){
		
		collNumCellValueMap.put(execNo_CollNum_Datasheet, executionNo);//execution No Map
		
		collNumCellValueMap.put(xpath_Datasheet, xpath);//Eob Map
		
		collNumCellValueMap.put(elementName_CollNum_Datasheet, element);//Element Map
		
		collNumCellValueMap.put(expectedValue_CollNum_Datasheet, expectedXmlValue);
		
		collNumCellValueMap.put(actualValueCollNum, actualValue);
		
		collNumCellValueMap.put(resultCollNum, result);
		
		System.out.println("The datasheet name and row num is "+dataSheetName + rowNum_Datasheet );
		
		ExcelUtils.CreateRowAndCell(dataSheetName,
				rowNum_Datasheet, collNumCellValueMap);
		
		
		
		rowNum_Datasheet++;
		
		}
		
		//expected Value Map
		
		
		
		//Below one is to create row and columns in datasheet
		
		
	}
	
	 public static void validataXmlAndDbValues(String elementName,String xmlValue, String dbValue,String originalDbValue,String xpath,String index) throws Exception {
			//validation of the xml and db values
			softAssertion.assertEquals(xmlValue.replaceAll("\\s+",""), dbValue.replaceAll("\\s+",""),"xmlValue:"+xmlValue.replaceAll("\\s+","")+"| dbValue:"+dbValue.replaceAll("\\s+",""));
			String status="Fail";
			System.out.println("The hcpcs index in validatexmlanddb is "+index);
			if(xmlValue.replaceAll("\\s+","").equalsIgnoreCase(dbValue.replaceAll("\\s+",""))){
				status="Pass";
				logger.log(LogStatus.PASS," Element Name: " + elementName + "<br /> xmlValue: " +xmlValue+ "<br />dbValue: " + originalDbValue+"<br /> Status:"+status);
			    
				updateDatasheet( index,  xpath,
						elementName,  xmlValue, 
						 "Result", dbValue, status);
			}
			
			
			
			else{
				logger.log(LogStatus.FAIL," Element Name: " + elementName + "<br /> xmlValue: " +xmlValue+ "<br /> dbValue: " + originalDbValue+"<br /> Status:"+status);
				
				updateDatasheet( index,  xpath,
						elementName,  xmlValue, 
						 "Result", dbValue, status);
			
			}
			//logger for showing the results in extents report html file
			
			//System.out.println(" Element Name: " + elementName + "|---------- xmlValue: " +xmlValue.replaceAll("\\s+","")+ "----------dbValue: " + dbValue.replaceAll("\\s+",""));
				
		}

}
