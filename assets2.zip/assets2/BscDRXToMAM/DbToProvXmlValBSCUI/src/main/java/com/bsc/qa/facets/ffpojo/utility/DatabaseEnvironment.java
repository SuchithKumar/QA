package com.bsc.qa.facets.ffpojo.utility;

public class DatabaseEnvironment {
	
	private String DBServer;
	
	private String DBPort;

	public String getDBServer() {
		return DBServer;
	}

	public void setDBServer(String dBServer) {
		DBServer = dBServer;
	}

	public String getDBPort() {
		return DBPort;
	}

	public void setDBPort(String dBPort) {
		DBPort = dBPort;
	}
	
	public void setEnvironment(String serverName){
		
		try{
		
		if(serverName.trim().equalsIgnoreCase("FACN52A")){
			
			this.setDBPort("12521");
			
			this.setDBServer("uorc372n.dev.bscal.local");
			
			
		}
		else if (serverName.trim().equalsIgnoreCase("FACN51A")){
			
			this.setDBPort("12521");
			
			this.setDBServer("uorc398n.dev.bscal.local");
			
		}
		else if (serverName.trim().equalsIgnoreCase("FACH71A")){
			
			this.setDBPort("12521");
			
			this.setDBServer("uorc392h.dev.bscal.local");
			
		}
		else if (serverName.trim().equalsIgnoreCase("FACH70A")){
			
			this.setDBPort("12521");
			
			this.setDBServer("uorc395h.dev.bscal.local");
			
		}
		else if (serverName.trim().equalsIgnoreCase("FACH64A")){
			
			this.setDBPort("12521");
			
			this.setDBServer("uorc392h.dev.bscal.local");
			
		}
		else if (serverName.trim().equalsIgnoreCase("FACH63A")){
			
			this.setDBPort("12521");
			
			this.setDBServer("uorc395h.dev.bscal.local");
			
		}
		}catch(Exception E){
			
			System.out.println("Server and Port setup is not successfull");
		}
		
	}
	

}
