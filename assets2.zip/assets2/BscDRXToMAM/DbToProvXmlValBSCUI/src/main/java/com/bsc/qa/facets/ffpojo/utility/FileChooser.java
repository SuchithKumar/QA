package com.bsc.qa.facets.ffpojo.utility;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class FileChooser {
	private File file = null;
	
	public File getFile (){
		try{
		JFileChooser chooser = new JFileChooser();
		
		chooser.setDialogTitle("Choose File!!");
		
		chooser.setCurrentDirectory(new File("C:\\Users"+System.getProperty("user.name")+"\\Desktop"));
		
		chooser.setMultiSelectionEnabled(true);
		
		FileNameExtensionFilter extensionFilter = new FileNameExtensionFilter(null,"xml","xlsx","xls","pdf");
		
		chooser.setFileFilter(extensionFilter);
		
		int option = chooser.showOpenDialog(null);
		
		if(option == JFileChooser.APPROVE_OPTION){
			
			file = chooser.getSelectedFile();
		}else if((option == JFileChooser.CANCEL_OPTION)){
			
			JOptionPane.showMessageDialog(null, "Please select the file!!");
		}
		}catch(Exception E){
			
			
		}
		return file;
		
	}

}
