package com.bsc.qa.facets.ffpojo.utility;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;




import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import javax.swing.JPanel;
import javax.swing.JEditorPane;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.UIManager;

public class SelectValidation {

	private JFrame frame;
	
	public static File excelFile ;
	public static File xmlFile ;
	private DBConnection dbConnection;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SelectValidation window = new SelectValidation();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SelectValidation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.setTitle("XmlValidator!!");
		frame.setBounds(300, 300, 450, 450);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblUploadxml = new JLabel("Upload Xml:");
		lblUploadxml.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUploadxml.setBounds(77, 220, 88, 14);
		frame.getContentPane().add(lblUploadxml);
		
		JButton btnNewButton = new JButton("Upload Xml");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
				FileChooser fileChooser = new FileChooser();
				
			
				File file = fileChooser.getFile();
				
				if(file.getName().contains(".xml")){
					
					xmlFile = file;
					
					System.out.println("The xml file name is "+xmlFile.getName());
					
					JOptionPane.showMessageDialog(null, "Xml file is uploaded successfully!!");
				}}catch(Exception E){
					
					
				}
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(227, 211, 138, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblXmlvalidator = new JLabel("XmlValidator");
		lblXmlvalidator.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblXmlvalidator.setBounds(157, 11, 147, 23);
		frame.getContentPane().add(lblXmlvalidator);
		
		JRadioButton DbToXml = new JRadioButton("DbToXml");
		DbToXml.setBackground(UIManager.getColor("ToolBar.dockingBackground"));
		DbToXml.setFont(new Font("Tahoma", Font.PLAIN, 12));
		DbToXml.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(DbToXml.isSelected()&&excelFile!=null&&xmlFile!=null){
					
					//frame.dispose();
					
					dbConnection = new DBConnection();
					
					dbConnection.dbConnection();
				} else{
					
					JOptionPane.showMessageDialog(null, "Please upload Xml and Mappingsheet!!");
					
					DbToXml.setSelected(false);
					
				}
			}
		});
		DbToXml.setBounds(227, 320, 91, 23);
		frame.getContentPane().add(DbToXml);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("XmlToPdf");
		rdbtnNewRadioButton_1.setBackground(UIManager.getColor("ToolBar.floatingBackground"));
		rdbtnNewRadioButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnNewRadioButton_1.setBounds(332, 320, 88, 23);
		frame.getContentPane().add(rdbtnNewRadioButton_1);
		
		JLabel lblValidationType = new JLabel("Validation Type");
		lblValidationType.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblValidationType.setBounds(77, 323, 105, 14);
		frame.getContentPane().add(lblValidationType);
		
		JLabel lblUploadDatasheet = new JLabel("Upload Datasheet:");
		lblUploadDatasheet.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUploadDatasheet.setBounds(77, 271, 113, 14);
		frame.getContentPane().add(lblUploadDatasheet);
		
		JButton btnUploadDatasheet = new JButton("Upload Datasheet");
		btnUploadDatasheet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					
				try{
					FileChooser fileChooser = new FileChooser();
					
				
					File file = fileChooser.getFile();
					
					System.out.println("The file name is "+file.getName());
					
					if(file.getName().contains(".xls")||file.getName().contains(".xlsx")){
						
						excelFile = file;
						
						System.out.println("The  file name is "+excelFile.getName());
						
						JOptionPane.showMessageDialog(null, "Datasheet is uploaded successfully!!");
					}}catch(Exception E){
						
						
					}
				
			}
		});
		btnUploadDatasheet.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnUploadDatasheet.setBounds(227, 268, 138, 23);
		frame.getContentPane().add(btnUploadDatasheet);
		
		JPanel panel = new JPanel();
		panel.setBackground(UIManager.getColor("ToolTip.background"));
		panel.setBounds(31, 53, 251, 149);
		frame.getContentPane().add(panel);
		
		String html = "<html><body width='%1s'><h3>Instructions</h3>"
                + "<br>1.Upload the EOB Xml</br> "
                + "<br>2.Upload Mapping Sheet</br> "
                + "<br>3.Select type of validation</br>"+"</html>";
                
		
		
		JLabel lblNewLabel = new JLabel(html);
		lblNewLabel.setBackground(UIManager.getColor("ToolTip.background"));
		
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		
		
		panel.add(lblNewLabel);
		
	}
}
