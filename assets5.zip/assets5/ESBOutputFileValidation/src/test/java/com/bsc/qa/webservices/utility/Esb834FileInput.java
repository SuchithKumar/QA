package com.bsc.qa.webservices.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Stream;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

//import com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile.BscaCare1stMMFlatFileBody;
//import com.bsc.qa.facets.ffpojo.factory.BaseTest;
//import com.bsc.qa.facets.ffpojo.readers.BscaCare1stMMFlatFileReader;
import com.bsc.qa.framework.utility.DBUtils;




/*
 * Edi834Utility class that gets fields data from 834 file to be used for 834 file validation.
 * @author Automation team
 *
 */

public class Esb834FileInput{
	//public static BscaCare1stMMFlatFileReader ffpExtract;
	/*
	 *For getting 834 file data from 834 EDI file
	 * @param strCompleteFilePath: 834 file path
	 * @param strInputFileName: 834 file name
	 * @return
	 * @throws IOException 
	 * @throws Exception: To capture the exception
	 */
	
	public SortedMap<String, SortedMap<String, String>> get834FileData(String strCompleteFilePath, String strInputFileName,Map<Object, Object> mydata) throws Exception{
		String strFileType;
		String primaryKey;
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		SortedMap<String, String> singleRecordMap = null;
		strCompleteFilePath = strInputFileName;
		String strInputExactFileName = strInputFileName.substring(strInputFileName.lastIndexOf("\\") + 1);
		//To get 834 file type
		strFileType = fileType834(strInputExactFileName);
		flatFileValuesMap = new TreeMap<String, SortedMap<String, String>>();
		
		//To compare the specified scenario based file format
		String strSubCount = strInputExactFileName.split("_")[4].substring(2,3);
		String strDepCount = strInputExactFileName.split("_")[5].substring(2,3);
		String strMemCount = strInputExactFileName.split("_")[6].substring(2,3);		
		
		//Converting String to Integer
		int sub = Integer.parseInt(strSubCount);
		int dep =Integer.parseInt(strDepCount);
		int mem = Integer.parseInt(strMemCount);
		mem = sub + dep;
		
		//Converting integer to string
		String finalMemCount = Integer.toString(mem);
		
		// Checking for the 834 file type
		if (strFileType.contains("Calpers 834")){
			// For capturing all Email Id's from 834 file
			List<String> rowsListCINNNumbers = parse834FileForCINNNumbers(strCompleteFilePath, strFileType);
			
			// Looping through all email numbers for validation
			for (String strCINNNumber : rowsListCINNNumbers){
				if(strCINNNumber.contains(mydata.get("Email_ID").toString().toLowerCase())){
				singleRecordMap = new TreeMap<String, String>();
				primaryKey = strCINNNumber.trim();
				
				//For retrieving CINN number specific data from 834 file
				List<String> rowsList = parse834File(strCompleteFilePath, 
				primaryKey, strFileType);
				
				//To retrieve first subscriber section data in "NM1*IL*" segment
				int intSubscriber = 0;
				String line1 = "";
				String line2 = "";
				String line3 = "";
				
				//Email Id's storing in a map for comparison
				singleRecordMap.put("email_id", strCINNNumber.trim().toLowerCase());
				System.out.println("Email used while storing flat file data: " + strCINNNumber.trim());
				
					
				int subCount=0;
				int depCount = 0;
				int depCount1 = 0;
				int depCount2 = 0;
				int depFinalCount = 0;
				String subComp = "";
				String depComp = "";
				String memComp = "";
				
				for (int i = 0; i < rowsList.size(); i++){
					//Storing field values to validate specified file format based on the number of subscribers and dependents in the file
					if(rowsList.get(i).startsWith("INS*")){
						line1 = rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						if(line1.split("\\*")[2].equalsIgnoreCase("18")){
							subCount++;
						}
						else if (line1.split("\\*")[2].equalsIgnoreCase("19")){
							depCount++;
						}
						else if (line1.split("\\*")[2].equalsIgnoreCase("01")){
							depCount1++;
						}
						else if (line1.split("\\*")[2].equalsIgnoreCase("53")){
							depCount2++;
						}
					
						depFinalCount = depCount + depCount1 + depCount2;
						int memFinalCount = subCount + depFinalCount;
						
						//Converting integer to string
						subComp = Integer.toString(subCount);
						depComp = Integer.toString(depFinalCount);
						memComp = Integer.toString(memFinalCount);
						
						if(strSubCount.equalsIgnoreCase(subComp) && strDepCount.equalsIgnoreCase(depComp) 
							&& finalMemCount.equalsIgnoreCase(memComp)){
							singleRecordMap.put("FileNameCountFormat", "FileNameCountFormat");
						}
					}
			
				}
			
				String resAddress1 = "";
				String resAddress2 = "";
				String resCity = "";
				String resState = "";
				String resZipCode = "";
				String mailAddress1 = "";
				String mailAddress2 = "";
				String mailCity = "";
				String mailState = "";
				String mailZipCode = "";
				
				//Residential Address validation
				for (int i = 0; i < rowsList.size(); i++){
					try{
						if(rowsList.get(i).startsWith("N3*")){
							line1 = rowsList.get(i).toString();
							line2 = rowsList.get(i+1).toString();
							line1 = line1.replace("~", "");
							line2 = line2.replace("~", "");
								
							resAddress2 = line1.split("\\*")[2];
							resCity = line2.split("\\*")[1];
							resState = line2.split("\\*")[2];
							resZipCode = line2.split("\\*")[3];
							resAddress1 = line1.split("\\*")[1];
							
							singleRecordMap.put("resAddress1", resAddress1);
							singleRecordMap.put("resAddress2", resAddress2);
							singleRecordMap.put("resCity", resCity);
							singleRecordMap.put("resState", resState);
							singleRecordMap.put("resZipCode", resZipCode);
						}
					}
					catch(Exception e){
						System.out.println("Data is not valid.");
					}
				}
				
				//Mailing Address validation
				for (int i = 0; i < rowsList.size(); i++){
					try{
						if(rowsList.get(i).startsWith("NM1*31*1")){
							line2 =rowsList.get(i+1).toString();
							line3 =rowsList.get(i+2).toString();
							line2 = line2.replace("~", "");
							line3 = line3.replace("~", "");
							
							if(line2.startsWith("N3*") && line3.startsWith("N4*")){
								mailAddress1 = line2.split("\\*")[1];
								mailAddress2 = line2.split("\\*")[2];
								mailCity = line3.split("\\*")[1];
								mailState = line3.split("\\*")[2];
								mailZipCode = line3.split("\\*")[3];
								
								singleRecordMap.put("mailAddress1", mailAddress1);
								singleRecordMap.put("mailAddress2", mailAddress2);
								singleRecordMap.put("mailCity", mailCity);
								singleRecordMap.put("mailState", mailState);
								singleRecordMap.put("mailZipCode", mailZipCode);
							}
						}
					}
					catch(Exception e){
						System.out.println("Data is not valid.");
					}
				}
				
			
			

			//Looping through all Email Id's records to retrieve required values
			
			for (int i = 0; i < rowsList.size(); i++){
				//Storing field values to validate IndividualRelationCode scenarios
				
				if(rowsList.get(i).startsWith("INS*")){
						line1 = rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("IndividualRelationCode",line1.split("\\*")[2]);
							System.out.println("IndividualRelationCode " +singleRecordMap.get("IndividualRelationCode"));
							}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
				}
			
				//Storing field values to validate InsuranceLineCode and CoverageLevelCode scenarios
				if(rowsList.get(i).startsWith("HD*")){
					if (strFileType.equalsIgnoreCase("Calpers 834")){
						line1 = rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						System.out.println(line1);
						try{
							
							singleRecordMap.put("InsuranceLineCode",line1.split("\\*")[3]);
							singleRecordMap.put("CoverageLevelCode",line1.split("\\*")[5]);
						}
						catch(Exception e){
							System.out.println("Data not present for HD03 or HD04 validation");
						}
					}
					
				}

				//  Storing field values to validate HealthCoverageDates scenarios
				if (rowsList.get(i).startsWith("DTP*349")){
					if (strFileType.equalsIgnoreCase("Calpers 834")){
					line1 = rowsList.get(i).toString();
					line1 = line1.replace("~", "");
					try{
						singleRecordMap.put("HealthCoverageDates",line1.split("\\*")[1].replace("~", ""));
						System.out.println("HealthCoverageDates " +singleRecordMap.get("HealthCoverageDates"));
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
				}
				}

				//  Storing field values to validate MemberLevelDates scenarios
				if (rowsList.get(i).startsWith("DTP*357")){
					if (strFileType.equalsIgnoreCase("Calpers 834")){
					line1 = rowsList.get(i).toString();
					line1 = line1.replace("~", "");
					try{
						singleRecordMap.put("MemberLevelDates",line1.split("\\*")[1]);
					}
					catch(Exception e){
						System.out.println("Data not present for validation");
					}
					}
				}
				
				// Storing field values to validate FA_GRP_ID is loaded to WPR database 
				if (rowsList.get(i).startsWith("REF*1L")){
					if (strFileType.equalsIgnoreCase("Calpers 834")){
						line1 = rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("FA_GRP_ID",line1.split("\\*")[2]);
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
				// Storing FA_SBGRP_ID field data from file
				if (rowsList.get(i).startsWith("REF*17")){
					if (strFileType.equalsIgnoreCase("Calpers 834")){
						line1 = rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("FA_SBGRP_ID",line1.split("\\*")[2]);
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
				// Storing CALPERS_GRP_ID field data from file
				if (rowsList.get(i).startsWith("REF*Q4")){
					if (strFileType.equalsIgnoreCase("Calpers 834")){
						line1 = rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("CALPERS_GRP_ID",line1.split("\\*")[2]);
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
				// Storing EFF_YR field data from file
				if (rowsList.get(i).startsWith("DTP*348")){
					if (strFileType.equalsIgnoreCase("Calpers 834")){
						line1 = rowsList.get(i).toString();
						line1 = line1.replace("~", "");
						try{
							singleRecordMap.put("EFF_YR",line1.split("\\*")[3].substring(0,4));
						}
						catch(Exception e){
							System.out.println("Data not present for validation");
						}
					}
				}
				
			//Storing all subscriber filed values map as a value and subscriber id as key
			flatFileValuesMap.put(primaryKey, singleRecordMap);
			}
		}
	}
}
		
		// Returning SortedMap<String, SortedMap<String, String>> with 834 file values
		return flatFileValuesMap;
}


/**
 * Changing 834 EDI file format when it is having one line
 * @param strFlatFileCompletePath: 834 file complete path
 * @throws Exception: To capture exception
 */
	
public void fileFormatChange834(String strFlatFileCompletePath) throws Exception
{	
	FileWriter fileWriter = null;
	FileReader fileReader  = null;
	BufferedReader bufferedReader = null;
	
	try{
		File inputFile = new File(strFlatFileCompletePath);
		String strLines = "";
		String line = "";
		//Checking for the file existence
		if(!inputFile.exists()){ 
			throw new IllegalStateException("File not found: " + strFlatFileCompletePath);
		} 
		else{
			fileReader =  new FileReader(inputFile);
			bufferedReader =        new BufferedReader(fileReader);
			int intICounter = 0;
			//Reading each line from the file
			while((line = bufferedReader.readLine())!=null){
				strLines = strLines + line;
				intICounter += 1;
				//Checking for single line 834 file
				if(intICounter > 1){
					bufferedReader.close();
					return;
				}
			}
		
			byte [] strBytes = strLines.getBytes();
			String strAllLines = new String (strBytes,StandardCharsets.UTF_8);
			//Replacing "~" symbol with "~\r\n"
			String strFormatLines = strAllLines.replaceAll("~", "~\r\n");
			fileWriter = new FileWriter(strFlatFileCompletePath);
			//Writing the data once again into the file after changes
			fileWriter.write(strFormatLines);
		  }
	}
	
	//For capturing exception
	catch(Exception e){
		e.printStackTrace();
	}
	finally{
		try{
			//Closing all opened file objects
			fileReader.close();
			fileWriter.close();
			bufferedReader.close();
		}
		catch(Exception ex){
			//ex.printStackTrace();
		}
	}
}

/**
 * @param testFlatFileCompletePath: File complete path
 * @param strCINNNumber: To capture specific subscriber section
 * @param strFileName: 834 file type
 * @return: List of subscriber lines
 * @throws Exception" To capture the exception
 */

public  List<String> parse834File(String testFlatFileCompletePath,String strCINNNumber, String strFileName) throws Exception{
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 //For checking file existence
	 if(!inputFile.exists()){ 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } 
	 else{
		 //Changing the layout when it is having in one single line
		  fileFormatChange834(testFlatFileCompletePath);
		  if(strFileName.contains(("Calpers 834"))){
			  FileReader fileReader =  new FileReader(testFlatFileCompletePath);
			  bufferedReader = new BufferedReader(fileReader);
			  
			 /* line = bufferedReader.readLine();
			  String[] line1 = line.split("~");
			  System.out.println(line1);*/
			  
			  boolean flag=false;
			  //Reading each line in the file 
		      while((line = bufferedReader.readLine()) != null) {
		    	  //Checking for the CINN Number
				 if(line.contains(strCINNNumber)){
				       flag=true;
				  }
				  //Checking for the starting line for each subscriber section
				  if(line.startsWith("INS*Y*")){
					  if(flag){
						  break;
				       }else{
				    	   //To clear the records if it is not matches to the provided CINN number
				           rowsList.clear();
				        }
				   }
				   //Adding lines to the records list
				   	rowsList.add(line);
				  }   
		      }
		  	  else{
		  		  //Printing line when user has selected invalid file
				  System.out.println("Please select valid file type to retrieve data from flat file ");
			  }
  		}
	 
	 //To close the bufferedReader object
	 if(bufferedReader!=null)
		 bufferedReader.close();
	 	return rowsList;
}


/**
 * To capture CINN Numbers from 834 file
 * @param testFlatFileCompletePath: 834 File complete path
 * @param strFileName: 834 file type
 * @return: List of CINN Numbers
 * @throws Exception: Throwing exception
 */

public  List<String> parse834FileForCINNNumbers(String testFlatFileCompletePath, String strFileName){
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 try{
	    //Checking for the file existence
	    if(!inputFile.exists()){ 
	    	throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	    } 
	    else{
	    	//Changing the layout when it is not expected
	    	fileFormatChange834(testFlatFileCompletePath);
		    //To capture CINN Numbers from LACare file
		    if(strFileName.contains("Calpers 834")){
		    	FileReader fileReader =  new FileReader(testFlatFileCompletePath);
				bufferedReader = new BufferedReader(fileReader);
				//Looping through all lined for checking CINN Number line
				while((line = bufferedReader.readLine()) != null){
					if(line.contains("*EM*")){
						line = line.replace("~", "").trim();
						//////////Email_id goes here strFileName.substring(strFileName.lastIndexOf("\\") + 1);
				     	rowsList.add(line.substring(line.lastIndexOf("*")+1).toLowerCase());
				     	
					}
				}   
		    }
		    
			//To capture CINN Numbers from DHCS file
		    else if(strFileName.contains("DHCS")){
		    	FileReader fileReader =  new FileReader(testFlatFileCompletePath);
				bufferedReader = new BufferedReader(fileReader);
				//Looping through all lined for checking CINN Number line
				while((line = bufferedReader.readLine()) != null){
					if(line.startsWith("REF*0F*")){
						//Adding CINN number to the list
				        rowsList.add(line.split("\\*")[2].replace("~", ""));
				     }
				}  
		    }
		    else{
		    	System.out.println("Please select valid file type to retrieve data from flat file ");
			}
	 }
	    
	 //To close the bufferReader object
	 if(bufferedReader != null)
		bufferedReader.close();
}
	//To capture and print the exception
	catch (Exception e){
		
		e.printStackTrace();
	}
	//For returning list of email's numbers 
	return rowsList;
}


/**
 * To find file type for 834 care1st MM
 * @param strFileName: Name of the file
 * @return: File name used for coding
 */

public String fileType834(String strFileName){
	if(strFileName.contains("\\")){
		strFileName = strFileName.substring(strFileName.lastIndexOf("\\") + 1);
	}
	//Checking for the expected file name
	if(strFileName.contains("CFST.D"))
		return "LACounty_Medi-Cal_Members(LACare)834";
	else if(strFileName.contains("834"))
		return "Calpers 834";
	else if(strFileName.contains("TXBMD"))
		return "TXBMD_834";
	else if(strFileName.contains("TFEPO"))
		return "TFEPO_834";
	else if(strFileName.contains("59140IFPON"))
		return "59140IFPON_834";
	else if(strFileName.contains("TPERS"))
		return "TPERS_834";
	else if(strFileName.contains("59140IFPOFF"))
		return "59140IFPOFF_834";
	else if(strFileName.contains("CTRCOO"))
		return "CTRCOO_834";
	else
		System.out.println("This file name is invalid: " + strFileName );
		return null;
}

//below method is to handle the index out of bound exception
public String  partialStringRetrieval(String strKeyName,String line,int indexValue, int intStartPos, int intEndingPos){
	if(!(intStartPos == 0 && intEndingPos == 0)){
		 try{
             String strValue = line.split("\\*")[indexValue].substring(intStartPos,intEndingPos).replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    return strValue;
             }
		 }
		 catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
			return "";
		 }
	}
	else{
		 try{
             String strValue = line.split("\\*")[indexValue].replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
            	 return strValue;
             }
		 }
         catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
            return "";
       }
	}
	return "";
}

//below method is to handle the index out of bound exception
public String  partialStringRetrievalUsingFieldIndex(String strKeyName,String line,int indexLineValue,  String strDelimeter, int indexFieldValue){
		 try{
				line = line.replace("~", "").trim();
				   String strValue = line.split("\\*")[indexLineValue].split(strDelimeter)[indexFieldValue].replace("~", "").trim();
				   if(!(strValue.equalsIgnoreCase(""))){
				  return strValue;
           }
		 }
		 catch(Exception e){
          // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
			return "";
		 }
	
	return "";
}


public static  List<SortedMap<String,String>> parseFileWithOutHeaderByDelimeter(String delimeter,String testFlatFileCompletePath,String fieldColumnMappingFilePath,String mappingSheetName) throws IOException{
	 File inputFile = new File(testFlatFileCompletePath);
	 List<SortedMap<String,String>> listOfRows=new ArrayList<SortedMap<String,String>>();
	 String line=null;
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  }
	 else{
		 System.out.println("Starting of File Reading . . . . . .  . . . . ");
		 new ExcelUtilsExtended(fieldColumnMappingFilePath,mappingSheetName);
		 FileReader fileReader =  new FileReader(testFlatFileCompletePath);
		 @SuppressWarnings("resource")
	     BufferedReader bufferedReader = new BufferedReader(fileReader);
		 while((line = bufferedReader.readLine()) != null){
			 String[] columnsArray = line.split(delimeter);
			 SortedMap<String,String> rowMap=new TreeMap<String,String>();
			 int columnLength=columnsArray.length;
			 for(int i=0;i<columnLength;i++){
				 String fileFieldName=String.valueOf(i);
			     String columnNameKey=ExcelUtilsExtended.getDBColumnName(fileFieldName);
				 if(columnNameKey!=null){
					 rowMap.put(columnNameKey.toLowerCase(),columnsArray[i].toLowerCase());	//System.out.println(rowNo+"  columnlength::"+columnLength+" index: "+i+"  "+rowsList.get(rowNo)[i]);
				 }
			 }
		 listOfRows.add(rowMap);
		 }   	    
 	}
	return listOfRows;
}


public SortedMap<String,SortedMap<String,String>> sortedMapMergingRough(SortedMap<String,SortedMap<String,String>> map1,SortedMap<String,SortedMap<String,String>> map2){
	SortedMap<String,SortedMap<String,String>> map3Return = new TreeMap<String,SortedMap<String,String>>();
	SortedMap<String,String> tempMap1 = new TreeMap<String, String>();
	SortedMap<String,String> tempMap2 = new TreeMap<String, String>();
	SortedMap<String,String> tempMapMerged = new TreeMap<String, String>();
	String tempMapKey1 = null;
	String tempMapKey2 = null;
	Boolean blnFlag = false;
	
	for(Entry<String,SortedMap<String,String>> mapEntry1 : map1.entrySet()){
		tempMap1 = mapEntry1.getValue();
		tempMapKey1 = mapEntry1.getKey();
		for(Entry<String,SortedMap<String,String>> mapEntry2 : map2.entrySet()){
			tempMap2 = mapEntry2.getValue();
			tempMapKey2 = mapEntry1.getKey();
			if(tempMapKey1.equalsIgnoreCase(tempMapKey2)){
				tempMapMerged.putAll(tempMap1);
				tempMapMerged.putAll(tempMap2);
				map3Return.put(tempMapKey1, tempMapMerged);
				blnFlag = true;
			}
		}
	}
	
	if(!blnFlag && map1.size()!=0){
		map3Return.putAll(map1);
	}
	
	else if(!blnFlag && (map2.size()!=0)){
		map3Return.putAll(map2);
	}
	
	return map3Return;
	
}

// Function for merging of all the query maps into a single map
public SortedMap<String,SortedMap<String,String>> sortedMapMerging(SortedMap<String,SortedMap<String,String>> map1,SortedMap<String,SortedMap<String,String>> map2){
    SortedMap<String,SortedMap<String,String>> map3Return = new TreeMap<String,SortedMap<String,String>>();
    SortedMap<String,String> tempMap1 = new TreeMap<String, String>();
    SortedMap<String,String> tempMap2 = new TreeMap<String, String>();
    String tempMapKey1 = null;
    
    for(Entry<String,SortedMap<String,String>> mapEntry1 : map1.entrySet()){
    	tempMap1 = mapEntry1.getValue();
        tempMapKey1 = mapEntry1.getKey();
        if(map2.containsKey(tempMapKey1)){
        	SortedMap<String,String> tempMapMerged = new TreeMap<String, String>();
            tempMap2 = map2.get(tempMapKey1);
            tempMapMerged.putAll(tempMap1);
            tempMapMerged.putAll(tempMap2);
            map3Return.put(tempMapKey1, tempMapMerged);
         }
         else{
        	map3Return.put(tempMapKey1, tempMap1);
         }
    }
    
    for(Entry<String,SortedMap<String,String>> mapEntry2 : map2.entrySet()){
    	tempMap1 = mapEntry2.getValue();
        tempMapKey1 = mapEntry2.getKey();
        if(!map1.containsKey(tempMapKey1)){
        	map3Return.put(tempMapKey1, tempMap1);
        }  
    }
    
    return map3Return;
}

//Function to get Special Indicator data from database
public SortedMap<String, SortedMap<String, String>>  getSpecialIndicatorData(Set<String> strPrimaryKeySet, String strQuery, String strColumn1,String strColumn2,String strColumn3){
	SortedMap<String,String> strMap = new TreeMap<String,String>();
    SortedMap<String, SortedMap<String, String>> strMapReturn = new TreeMap<String, SortedMap<String, String>>();
    List<Map<String, Object>> specialIndicatorResultSet1 = null;
    String strQueryPrimaryKey = null;
    for(String strPrimaryKey: strPrimaryKeySet){
    	strQueryPrimaryKey = strQuery.replace("Parameter1", strPrimaryKey.toUpperCase());
        specialIndicatorResultSet1 = new DBUtils().getResultSetAsMapList("facets", strQueryPrimaryKey);
        strMap = resultSetToDictionarySpecificColumns(specialIndicatorResultSet1, strColumn1, strColumn2, strColumn3);
        strMapReturn.put(strPrimaryKey, strMap);
    }
    return strMapReturn;
}


public  SortedMap<String,String> resultSetToDictionarySpecificColumns(List<Map<String,Object>> queryResultList, String strColumn1,String strColumn2,String strColumn3){
	SortedMap<String,String> strMap = new TreeMap<String,String>();
	String strTempColumn1 = "";
	String strTempColumn2 = "";
	String strTempColumn3 = "";
	for(int intICounter=0;intICounter<queryResultList.size();intICounter++){
		if(queryResultList.get(intICounter).get(strColumn3)!=null){
			strTempColumn3 =  queryResultList.get(intICounter).get(strColumn3).toString();
		}
		else{
			strTempColumn3 = "[Blank]";
		}
		strTempColumn1 = queryResultList.get(intICounter).get(strColumn1).toString().toLowerCase();
		strTempColumn2 = queryResultList.get(intICounter).get(strColumn2).toString().toLowerCase();	
		strMap.put( strTempColumn1 + "_" +  strTempColumn2,strTempColumn3 );
	}
	return strMap;
	}
}
