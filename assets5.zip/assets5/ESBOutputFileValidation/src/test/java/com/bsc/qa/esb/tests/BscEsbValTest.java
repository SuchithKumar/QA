package com.bsc.qa.esb.tests;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.stream.Stream;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.Esb834FileInput;
import com.relevantcodes.extentreports.LogStatus;

public class BscEsbValTest extends BaseTest implements IHookable {

	public static String sTargetFiles_dir = System.getenv("INPUT_EDI_PATH");
	public static String activeSheetName = System.getenv("ENVNAME");
	private SoftAssert softAssert = null;

	@DataProvider(name = "data")
	// loading the data from excel file
	public Object[][] dataSupplier(Method method) throws IOException {
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";
		Object[][] columnArray = ExcelUtils.getColumnArray(xlsPath,
				activeSheetName);

		Object[][] testDataArray = ExcelUtils.getTableArray(xlsPath,
				activeSheetName);
		List<Object> list = new ArrayList<Object>();

		int noOfTestCases = 0;
		// String runMode = "Yes";
		for (int row = 0; row < testDataArray.length; row++) {

			if (method.getName().equalsIgnoreCase(
					testDataArray[row][1].toString())) {
				noOfTestCases++;

				System.out.println("TestCase Name From Data Sheet:::"
						+ testDataArray[row][0].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col = 0; col <= columnArray[0].length - 1; col++) {

					rowDataMap.put(columnArray[0][col].toString(),
							testDataArray[row][col].toString());
					rowDataMap.put("rowNum", String.valueOf(row));

				}
				/*
				 * rowDataMap.put("rowNum", String.valueOf(rowNum));
				 * 
				 * rowNum++;
				 */
				list.add(rowDataMap);

			}

		}

		Object[][] data = new Object[noOfTestCases][1];
		for (int row = 0; row < list.size(); row++) {
			data[row][0] = list.get(row);
		}

		return data;

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations1(Map<Object, Object> mydata)
			throws Exception {

		System.out
				.println("-------------testEDIOutputValidations1 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "IndividualRelationCode"
										// scenario, INS02 segment
										if (columnKey
												.contains("IndividualRelationCode")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& mydata
															.get("Email_ID")
															.toString()
															.equalsIgnoreCase(
																	"STT_ESB_TC01@noname.com")) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("IndividualRelationCode (INS02)")
																	.toString())) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"IndividualRelationCode (INS02)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"IndividualRelationCode (INS02)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getMessage();
													softAssert
															.fail("IndividualRelationCode (INS02) not found ",
																	e.getCause());
												}
											}
										}

									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}
	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations2(Map<Object, Object> mydata)
			throws Exception {

		System.out
				.println("-------------testEDIOutputValidations2 Test case started ----------------");
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "InsuranceLineCode"
										// scenario, HD03 segment - FSA
										if (columnKey
												.contains("InsuranceLineCode")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& mydata
															.get("Email_ID")
															.toString()
															.equalsIgnoreCase(
																	"STT_ESB_TC02@noname.com")) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("InsuranceLineCode (HD03)")
																	.toString())
															&& fileValue
																	.equalsIgnoreCase("FSA")) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"InsuranceLineCode (HD03)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"InsuranceLineCode (HD03)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getStackTrace();
													softAssert
															.fail("InsuranceLineCode (HD03) not found ",
																	e.getCause());

												}
											}
										}

									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);
			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations3(Map<Object, Object> mydata)
			throws Exception {
		System.out
				.println("-------------testEDIOutputValidations3 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "InsuranceLineCode"
										// scenario, HD03 code - HIA
										if (columnKey
												.contains("InsuranceLineCode")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& mydata
															.get("Email_ID")
															.toString()
															.equalsIgnoreCase(
																	"STT_ESB_TC03@noname.com")) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("InsuranceLineCode (HD03)")
																	.toString())
															&& fileValue
																	.equalsIgnoreCase("HIA")) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"InsuranceLineCode (HD03)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"InsuranceLineCode (HD03)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getStackTrace();
													softAssert
															.fail("InsuranceLineCode (HD03) not found ",
																	e.getCause());
												}
											}
										}

									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations4(Map<Object, Object> mydata)
			throws Exception {

		System.out
				.println("-------------testEDIOutputValidations4 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "InsuranceLineCode"
										// scenario, HD03 code - HRA
										if (columnKey
												.contains("InsuranceLineCode")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& mydata
															.get("Email_ID")
															.toString()
															.equalsIgnoreCase(
																	"STT_ESB_TC04@noname.com")) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("InsuranceLineCode (HD03)")
																	.toString())
															&& fileValue
																	.equalsIgnoreCase("HRA")) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"InsuranceLineCode (HD03)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"InsuranceLineCode (HD03)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getStackTrace();
													softAssert
															.fail("InsuranceLineCode (HD03) not found ",
																	e.getCause());
												}
											}
										}

									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations5(Map<Object, Object> mydata)
			throws Exception {

		System.out
				.println("-------------testEDIOutputValidations5 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "InsuranceLineCode"
										// scenario, HD03 code - HAS
										if (columnKey
												.contains("InsuranceLineCode")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& mydata
															.get("Email_ID")
															.toString()
															.equalsIgnoreCase(
																	"STT_ESB_TC05@noname.com")) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("InsuranceLineCode (HD03)")
																	.toString())
															&& fileValue
																	.equalsIgnoreCase("HAS")) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"InsuranceLineCode (HD03)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"InsuranceLineCode (HD03)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getStackTrace();
													softAssert
															.fail("InsuranceLineCode (HD03) not found ",
																	e.getCause());
												}
											}
										}

									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations6(Map<Object, Object> mydata)
			throws Exception {
		System.out
				.println("-------------testEDIOutputValidations6 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "HealthCoverageDates"
										// scenario, DTP01-Loop - 2300 (349)
										if (columnKey
												.contains("HealthCoverageDates")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& (mydata.get("Email_ID")
															.toString()
															.equalsIgnoreCase("STT_ESB_TC06@noname.com"))) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("HealthCoverageDates (DTP01 - Loop 2300)")
																	.toString())) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"HealthCoverageDates (DTP01 - Loop 2300)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"HealthCoverageDates (DTP01 - Loop 2300)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getMessage();
													softAssert
															.fail("HealthCoverageDates (DTP01 - Loop 2300) not found ",
																	e.getCause());
												}
											}
										}

										// To validate "MemberLevelDates"
										// scenario, DTP01-Loop - 2300 (357)
										if (columnKey
												.contains("MemberLevelDates")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& (mydata.get("Email_ID")
															.toString()
															.equalsIgnoreCase("STT_ESB_TC06@noname.com"))) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("MemberLevelDates (DTP01 - Loop 2000)")
																	.toString())) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"MemberLevelDates (DTP01 - Loop 2000)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"MemberLevelDates (DTP01 - Loop 2000)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getMessage();
													softAssert
															.fail("MemberLevelDates (DTP01 - Loop 2000) not found ",
																	e.getCause());
												}
											}
										}

									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations7(Map<Object, Object> mydata)
			throws Exception {
		System.out
				.println("-------------testEDIOutputValidations7 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "HealthCoverageDates"
										// scenario, DTP01-Loop - 2300 (349)
										if (columnKey
												.contains("HealthCoverageDates")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& (mydata.get("Email_ID")
															.toString()
															.equalsIgnoreCase("STT_ESB_TC07@noname.com"))) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("HealthCoverageDates (DTP01 - Loop 2300)")
																	.toString())) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"HealthCoverageDates (DTP01 - Loop 2300)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"HealthCoverageDates (DTP01 - Loop 2300)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getMessage();
													softAssert
															.fail("HealthCoverageDates (DTP01 - Loop 2300) not found ",
																	e.getCause());
												}
											}
										}

										// To validate "MemberLevelDates"
										// scenario, DTP01-Loop - 2300 (357)
										if (columnKey
												.contains("MemberLevelDates")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& (mydata.get("Email_ID")
															.toString()
															.equalsIgnoreCase("STT_ESB_TC07@noname.com"))) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("MemberLevelDates (DTP01 - Loop 2000)")
																	.toString())) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"MemberLevelDates (DTP01 - Loop 2000)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"MemberLevelDates (DTP01 - Loop 2000)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getMessage();
													softAssert
															.fail("MemberLevelDates (DTP01 - Loop 2000) not found ",
																	e.getCause());
												}
											}
										}
									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations8(Map<Object, Object> mydata)
			throws Exception {
		System.out
				.println("-------------testEDIOutputValidations8 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// Validating Residential Address and
										// Mailing Address are same
										if (rowMap.get("email_id")
												.equalsIgnoreCase(
														mydata.get("Email_ID")
																.toString())
												&& mydata
														.get("Email_ID")
														.toString()
														.equalsIgnoreCase(
																"STT_ESB_TC08@noname.com")) {
											try {
												if (rowMap
														.get("resAddress1")
														.equalsIgnoreCase(
																rowMap.get("mailAddress1"))
														&& rowMap
																.get("resAddress2")
																.equalsIgnoreCase(
																		rowMap.get("mailAddress2"))
														&& rowMap
																.get("resCity")
																.equalsIgnoreCase(
																		rowMap.get("mailCity"))
														&& rowMap
																.get("resState")
																.equalsIgnoreCase(
																		rowMap.get("mailState"))
														&& rowMap
																.get("resZipCode")
																.equalsIgnoreCase(
																		rowMap.get("mailZipCode"))) {

													logger.log(
															LogStatus.PASS,
															"Address line is copied successfully from Residential Address to Mailing Address, with Residential Address as: "
																	+ rowMap.get("resAddress1")
																	+ ", "
																	+ rowMap.get("resAddress2")
																	+ ", "
																	+ rowMap.get("resCity")
																	+ ", "
																	+ rowMap.get("resState")
																	+ ", "
																	+ rowMap.get("resZipCode")
																	+ " and Mailing Address as: "
																	+ rowMap.get("mailAddress1")
																	+ ", "
																	+ rowMap.get("mailAddress2")
																	+ ", "
																	+ rowMap.get("mailCity")
																	+ ", "
																	+ rowMap.get("mailState")
																	+ ", "
																	+ rowMap.get("mailZipCode")
																	+ ".");
												}
												break;
											} catch (Exception e) {
												logger.log(LogStatus.FAIL,
														"Address line is NOT copied from Residential Address to Mailing Address. ");
												softAssert
														.fail("Address line failure ",
																e.getCause());
												break;
											}
										}
									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations9(Map<Object, Object> mydata)
			throws Exception {
		System.out
				.println("-------------testEDIOutputValidations9 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// Validating FA_PLN_ID is loaded into
										// WPR database or not
										if (rowMap.get("email_id")
												.equalsIgnoreCase(
														mydata.get("Email_ID")
																.toString())
												&& mydata
														.get("Email_ID")
														.toString()
														.equalsIgnoreCase(
																"STT_ESB_TC09@noname.com")) {
											String grpNumber = rowMap
													.get("FA_GRP_ID");
											String subGrpNumber = rowMap
													.get("FA_SBGRP_ID");
											String CalGrpNumber = rowMap
													.get("CALPERS_GRP_ID");
											String benefitDate = rowMap
													.get("EFF_YR");
											String fileModifiedValue = "";
											String strQuery = "";

											strQuery = "select FA_PLN_ID from CALPERS_FA_CROSSWALK where FA_GRP_ID = '"
													+ grpNumber
													+ "' and FA_SBGRP_ID = '"
													+ subGrpNumber
													+ "' and CALPERS_GRP_ID = '"
													+ CalGrpNumber
													+ "' and EFF_YR = '"
													+ benefitDate + "'";
											System.out.println(strQuery);
											Map<String, String> planId = new HashMap<String, String>();
											System.out
													.println("***********************************Cheking DB configurations********************************");
											System.out.println(System
													.getenv("WPR_DB"));
											System.out.println(System
													.getenv("WPR_SERVER"));
											System.out.println(System
													.getenv("WPR_PORT"));
											System.out.println(System
													.getenv("WPR_PASSWORD"));
											System.out.println(System
													.getenv("WPR_USER"));
											try {
												planId = new DBUtils()
														.getOneRowResultSetAsMap(
																"wpr", strQuery);
												fileModifiedValue = planId
														.get("FA_PLN_ID");
												System.out.println("plan id "
														+ fileModifiedValue);
												if (fileModifiedValue != null) {
													logger.log(
															LogStatus.PASS,
															" Plan ID: "
																	+ fileModifiedValue
																	+ " is present in the "
																	+ System.getenv("WPR_DB")
																	+ " database XWALK table (CALPERS_FA_CROSSWALK). ");
												}
												break;
											} catch (Exception e) {
												System.out
														.println("Exception****"
																+ e);
												e.printStackTrace();
												logger.log(
														LogStatus.FAIL,
														" Plan ID is NOT found in "
																+ System.getenv("WPR_DB")
																+ " XWALK table (CALPERS_FA_CROSSWALK). ");
												softAssert
														.fail("Plan ID is NOT found in WPRH database ",
																e.getCause());
												break;
											}
										}
									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations10(Map<Object, Object> mydata)
			throws Exception {
		System.out
				.println("-------------testEDIOutputValidations10 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "FileNameCountFormat"
										// scenario
										if (rowMap.get("email_id")
												.equalsIgnoreCase(
														mydata.get("Email_ID")
																.toString())
												&& mydata
														.get("Email_ID")
														.toString()
														.equalsIgnoreCase(
																"STT_ESB_TC10@noname.com")) {

											// To compare the specified scenario
											// based file format
											String strSubCount = strFileName
													.split("_")[4].substring(2,
													3);
											String strDepCount = strFileName
													.split("_")[5].substring(2,
													3);
											String strMemCount = strFileName
													.split("_")[6].substring(2,
													3);
											/*
											 * //Converting String to Integer
											 * int sub =
											 * Integer.parseInt(strSubCount);
											 * int dep
											 * =Integer.parseInt(strDepCount);
											 * int mem =
											 * Integer.parseInt(strMemCount);
											 * mem = sub + dep;
											 * 
											 * //Converting integer to string
											 * String finalMemCount =
											 * Integer.toString(mem);
											 */

											try {
												if (rowMap
														.get("FileNameCountFormat")
														.equalsIgnoreCase(
																"FileNameCountFormat")) {
													logger.log(
															LogStatus.INFO,
															"834 Output File Name: "
																	+ strFileName
																	+ ".");
													logger.log(
															LogStatus.PASS,
															"SC# (Subscriber Count): "
																	+ strSubCount
																	+ ", DC# (Dependent Count): "
																	+ strDepCount
																	+ ", MC# (Member Count): "
																	+ strMemCount
																	+ "(SC# + DC# = MC#) -- VALID file name count format.");
												}
												break;
											} catch (Exception e) {
												logger.log(LogStatus.INFO,
														"834 Output File Name: "
																+ strFileName
																+ ".");
												logger.log(
														LogStatus.FAIL,
														"SC# (Subscriber Count): "
																+ strSubCount
																+ ", DC# (Dependent Count): "
																+ strDepCount
																+ ", MC# (Member Count): "
																+ strMemCount
																+ "(SC# + DC# = MC#) -- INVALID file name count format.");
												softAssert
														.fail("INVALID file name count ",
																e.getCause());
												break;
											}
										}

									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations11(Map<Object, Object> mydata)
			throws Exception {
		System.out
				.println("-------------testEDIOutputValidations11 Test case started ----------------");

		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "CoverageLevelCode"
										// scenario, HD05 segment - EMP
										if (columnKey
												.contains("CoverageLevelCode")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& mydata
															.get("Email_ID")
															.toString()
															.equalsIgnoreCase(
																	"STT_ESB_TC11@noname.com")) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("CoverageLevelCode (HD05)")
																	.toString())
															&& fileValue
																	.equalsIgnoreCase("EMP")) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"CoverageLevelCode (HD05)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"CoverageLevelCode (HD05)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getStackTrace();
													softAssert
															.fail("CoverageLevelCode (HD05) not found ",
																	e.getCause());
												}
											}
										}
									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}

	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations12(Map<Object, Object> mydata)
			throws Exception {
		System.out
				.println("-------------testEDIOutputValidations12 Test case started ----------------");
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "CoverageLevelCode"
										// scenario, HD05 segment - ESP
										if (columnKey
												.contains("CoverageLevelCode")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& mydata
															.get("Email_ID")
															.toString()
															.equalsIgnoreCase(
																	"STT_ESB_TC12@noname.com")) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("CoverageLevelCode (HD05)")
																	.toString())
															&& fileValue
																	.equalsIgnoreCase("ESP")) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"CoverageLevelCode (HD05)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"CoverageLevelCode (HD05)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getStackTrace();
													softAssert
															.fail("CoverageLevelCode (HD05) not found ",
																	e.getCause());
												}
											}
										}
									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}
	}

	@Test(dataProvider = "data")
	public void testEDIOutputValidations13(Map<Object, Object> mydata)
			throws Exception {
		System.out
				.println("-------------testEDIOutputValidations13 Test case started ----------------");
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		String strFileName = "";
		String strCompletePath = "";
		String str1 = "";
		Esb834FileInput edi = new Esb834FileInput(); // object creation of
		// EdiUtility

		File dir = new File(sTargetFiles_dir);

		// Check if the directory exists in given environmental path
		if (dir.exists() && dir.isDirectory()) {
			File[] directoryListing = dir.listFiles();
			int email = 0;
			for (File dfile : directoryListing) {
				// Check if directory is not empty
				try {
					str1 = dfile.toString();
					strFileName = str1.substring(str1.lastIndexOf("\\") + 1);
					strCompletePath = sTargetFiles_dir + "\\" + strFileName;
					// Check if email is present in files
					try (Stream<String> lines = Files.lines(Paths
							.get(strCompletePath))) {

						if (lines.anyMatch(l -> l.toLowerCase()
								.contains(
										mydata.get("Email_ID").toString()
												.toLowerCase()))) {

							System.out.println(mydata.get("Email_ID")
									.toString() + " found in " + strFileName);

							flatFileValuesMap = edi.get834FileData(
									sTargetFiles_dir, strCompletePath, mydata);

							// Check if 834 is present in read
							String strFileType = edi
									.fileType834(strCompletePath);

							// If test email is present in 834 file
							if (flatFileValuesMap.keySet().contains(
									mydata.get("Email_ID").toString()
											.toLowerCase())) {

								Set<String> primaryKeySet = flatFileValuesMap
										.keySet();

								for (String primaryKey : primaryKeySet) {

									// capture single subscriber data from
									// flatfilevaluesMap
									SortedMap<String, String> rowMap = flatFileValuesMap
											.get(primaryKey);

									// To be displayed report
									/*
									 * reportInit( "ESBOutputFileValidation ",
									 * ": Test Case : " +
									 * mydata.get("Test_Name") .toString());
									 */
									logger.log(LogStatus.INFO,
											"Starting Test - ESBOutputFileValidation ");

									logger.log(LogStatus.INFO, "File Path: "
											+ strCompletePath);

									logger.log(LogStatus.INFO,
											"Email used for validation is: "
													+ primaryKey.toUpperCase());

									for (String columnKey : rowMap.keySet()) {

										// Retrieving value from flat
										// file for each
										// of the keys

										String fileValue = rowMap
												.get(columnKey);

										// Retrieving value from
										// database for each
										// of the keys

										// To validate "CoverageLevelCode"
										// scenario, HD05 segment - E2D
										if (columnKey
												.contains("CoverageLevelCode")) {
											if (rowMap
													.get("email_id")
													.equalsIgnoreCase(
															mydata.get(
																	"Email_ID")
																	.toString())
													&& mydata
															.get("Email_ID")
															.toString()
															.equalsIgnoreCase(
																	"STT_ESB_TC13@noname.com")) {
												try {
													if (fileValue
															.equalsIgnoreCase(mydata
																	.get("CoverageLevelCode (HD05)")
																	.toString())
															&& fileValue
																	.equalsIgnoreCase("E2D")) {
														logger.log(
																LogStatus.PASS,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"CoverageLevelCode (HD05)")
																				.toString()
																		+ " >>");
													} else {
														logger.log(
																LogStatus.FAIL,
																" << Field name: "
																		+ columnKey
																		+ " | Actual (834 Output File) Value: "
																		+ fileValue
																		+ " | Expected (scenario value): "
																		+ mydata.get(
																				"CoverageLevelCode (HD05)")
																				.toString()
																		+ " >>");

													}
												} catch (Exception e) {
													e.getStackTrace();
													softAssert
															.fail("CoverageLevelCode (HD05) not found ",
																	e.getCause());
												}
											}
										}
									}
								}
							}

						} else {// counter increment to check if email is not
								// found in all files
							email++;
							// System.out.println(mydata.get("Email_ID").toString()
							// + " NOT found in " + strFileName);
						}
					} catch (Exception e) {
						System.out
								.println("Data in file is: " + e.getMessage());
					}
				} catch (Exception e) {
					System.out.println("No 834 files present in directory "
							+ e.getMessage());
				}
			}
			if (directoryListing.length == email) {// Logger for email not found
													// for respective scenarios

				System.out.println(mydata.get("Email_ID").toString()
						+ " NOT found");

				/*
				 * reportInit("ESBOutputFileValidation ", ": Test Case : " +
				 * mydata.get("Test_Name").toString());
				 */
				logger.log(
						LogStatus.FAIL,
						"Scenario associated with the email "
								+ mydata.get("Email_ID").toString()
								+ " is not present in any of the files at the location: "
								+ sTargetFiles_dir);

			}
		}
	}

	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {

		Map map = (Map) callBack.getParameters()[0];
		String testCaseName = "TestcaseName: " + map.get("Test_Name");
		reportInit(testResult.getMethod().getMethodName(), testCaseName);
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}

}