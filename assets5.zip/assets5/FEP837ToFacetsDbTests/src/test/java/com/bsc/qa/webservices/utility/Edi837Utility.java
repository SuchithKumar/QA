package com.bsc.qa.webservices.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;





/**
 * Edi834Utility class that gets fields data from 834 file to be used for 834 file validation.
 * @author Automation team
 *
 */
public class Edi837Utility {

	
	/**
	 *For getting 837 file data from 834 EDI file
	 * @param strCompleteFilePath: 834 file path
	 * @param strInputFileName: 834 file name
	 * @return
	 * @throws Exception: To capture the exception
	 */
	public SortedMap<String, SortedMap<String, String>> get837FileData(
			 String strInputFileName)
			throws Exception {
	
		
		String primaryKey;
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;
		SortedMap<String, String> singleRecordMap = null;
		
		
		
		// To get 837 file type
		flatFileValuesMap = new TreeMap<String, SortedMap<String, String>>();
		
	
			// For capturing all patient account numbers from 837 file
			List<String> rowsListPANumbers = parse837FileForPatientAccNumbers(strInputFileName);
			// Looping through all Patient Account numbers for validation
			for (String strPANumber : rowsListPANumbers) {
			
				singleRecordMap = new TreeMap<String, String>();
				
				primaryKey = strPANumber.trim().toLowerCase();
				// For retrieving Patient Account number specific data from 837 file
				List<String> rowsList = parse837File(strInputFileName, 
						primaryKey.toUpperCase());
				//To retrieve first subscriber section data in "NM1*IL*" segment
				int intSubscriber = 0;
				String line1 = "";
				
				//singleRecordMap.put("Patient Acc Number", strPANumber.trim().toLowerCase());
				System.out.println(" Patient Acc Number used while storing flat file data: " + strPANumber.trim().toLowerCase());

				// Displaying test data mandatory values in the logger

				// Looping through all CINN number records to retrieve required values				
				for (int i = 0; i < rowsList.size(); i++) {
					//  Storing field values to validate subscriber's First name, last Name and Middle initial				
					if (rowsList.get(i).startsWith("NM1*IL*")) {
						if (intSubscriber == 0) {
							line1 = rowsList.get(i).toString().toLowerCase();
							line1 = line1.replace("~", "");
							singleRecordMap.put("last_name",
									line1.split("\\*")[3]);
							singleRecordMap.put("first_name",
									line1.split("\\*")[4]);
							// flatFileValuesMap.put("MIDINIT",
							// line1.split("\\*")[5].replace("~", ""));
							
							intSubscriber = intSubscriber + 1;
						}

					}

					//  Storing field values to validate subscriber's Telephone Number
//					if (rowsList.get(i).startsWith("PER*IP*")) {
//						line1 = rowsList.get(i).toString().toLowerCase();
//						line1 = line1.replace("~", "");
//						singleRecordMap.put("telephone",
//								line1.split("\\*")[4].replace("~", ""));
//					}
					 // Storing field values to validate subscriber's Address
					if (rowsList.get(i).startsWith("N3*")) {
						line1 = rowsList.get(i).toString().toLowerCase();

						line1 = line1.replace("~", "");
						String[] address = line1.split("\\*");
						singleRecordMap.put("address1", address[1]
								.substring(0).replace("~", ""));
					
					}
					
			//  Storing field values to validate  Claim total Charges
					if (rowsList.get(i).startsWith("CLM*")) {
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						singleRecordMap.put("total_charge",
								line1.split("\\*")[2].replace("~", ""));
					}
					
			//  Storing field values to validate Date of Birth
					if (rowsList.get(i).startsWith("DMG*D8*")) {
						line1 = rowsList.get(i).toString().toLowerCase();
						line1 = line1.replace("~", "");
						singleRecordMap.put("dateofbirth",
								line1.split("\\*")[2].replace("~", ""));
					}
					

				
				}
				//Storing all subscriber filed values map as a value and subscriber id as key
				flatFileValuesMap.put(primaryKey, singleRecordMap);
			}	
		
		
		// Returning SortedMap<String, SortedMap<String, String>> with 834 file values
		return flatFileValuesMap;
	}

	


/**
 * Changing 837 EDI file format when it is having one line
 * @param strFlatFileCompletePath: 837 file complete path
 * @throws Exception: To capture exception
 */
public void fileFormatChange834(String strFlatFileCompletePath) throws Exception
{	
	FileWriter fileWriter = null;
	FileReader fileReader  = null;
	BufferedReader bufferedReader = null;
	
	try{
		File inputFile = new File(strFlatFileCompletePath);
		String strLines = "";
		String line = "";
		//Checking for the file existence
		if (!inputFile.exists()) { 
			  throw new IllegalStateException("File not found: " + strFlatFileCompletePath);
		  } 
		else 
		{
			fileReader =  new FileReader(inputFile);
			bufferedReader =        new BufferedReader(fileReader);
			int intICounter = 0;
			//Reading each line from the file
			while((line = bufferedReader.readLine())!=null)
			{
				strLines = strLines + line;
				intICounter += 1;
				//Checking for single line 834 file
				if(intICounter > 1)
				{
					bufferedReader.close();
					return;
				}
			}
		
			byte [] strBytes = strLines.getBytes();
			String strAllLines = new String (strBytes,StandardCharsets.UTF_8);
			//Replacing "~" symbol with "~\r\n"
			String strFormatLines = strAllLines.replaceAll("~", "~\r\n");
			fileWriter = new FileWriter(strFlatFileCompletePath);
			//Writing the data once again into the file after changes
			fileWriter.write(strFormatLines);
		  }
		
	}
	//For capturing exception
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try{
			//Closing all opened file objects
			fileReader.close();
			fileWriter.close();
			bufferedReader.close();
		}
		catch(Exception ex)
		{
			//ex.printStackTrace();
		}
	}
}

/**
 * @param testFlatFileCompletePath: File complete path
 * @param strCINNNumber: To capture specific subscriber section
 * @param strFileName: 837 file type
 * @return: List of subscriber lines
 * @throws Exception" To capture the exception
 */
public  List<String> parse837File(String testFlatFileCompletePath,String strPatAccNumber) throws Exception {
	
	 File inputFile = new File(testFlatFileCompletePath);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	 //For checking file existence
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
		  		
				 
						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						bufferedReader = new BufferedReader(fileReader);
						boolean flag=false;
						// Reading each line in the file 
				        while((line = bufferedReader.readLine()) != null) {
				        	//Checking for the patient Account  Number
				        	if(line.contains(strPatAccNumber)){
				        		 flag=true;
				        	}
			        	//Checking for the starting line for each claim section
				        	if(line.startsWith("ST")){
			        		if(flag){
				        			break;
				        		}else{
				        			//To clear the records if it is not matches to the provided patient account number
				        			rowsList.clear();
				        		}
				        	}
				        	//Adding lines to the records list
				        	rowsList.add(line);
				       		}   
				  
				  
			

  	}
	 //To close the bufferedReader object
	 if(bufferedReader!=null)
		 bufferedReader.close();

	return rowsList;
}


/**
 * To capture patient account  Numbers from 837 file
 * @param testFlatFileCompletePath: 837 File complete path
 * @param strFileName: 837 file type
 * @return: List of p Numbers
 * @throws Exception: Throwing exception
 */
public  List<String> parse837FileForPatientAccNumbers(String strFileName) {
	
	 File inputFile = new File(strFileName);
	 String line=null;
	 BufferedReader bufferedReader = null;
	 List<String> rowsList=new ArrayList<String>();
	try {
	//Checking for the file existence
	 if (!inputFile.exists())
	 { 
		  throw new IllegalStateException("File not found: " + strFileName);
	  } else {
		  		
		  		//To capture patient Account Numbers from 837 file
				  
						FileReader fileReader =  new FileReader(strFileName);
						bufferedReader = new BufferedReader(fileReader);
						//Looping through all lined for checking CINN Number line
				        while((line = bufferedReader.readLine()) != null)
				        {
				        	if(line.startsWith("CLM*"))
				        	{
				        		//Adding patient account number to the list
				        		rowsList.add(line.split("\\*")[1]);
				        	}
				
				 

  	}
				        
	  
	 //To close the bufferReader object
	if(bufferedReader != null)
		bufferedReader.close();

	  }
	 
	}
	//To capture and print the exception
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//For returning list of CINN numbers 
	return rowsList;
}





//below method is to handle the index out of bound exception
public String  partialStringRetrieval(String strKeyName,String line,int indexValue, int intStartPos, int intEndingPos){
       
	if(!(intStartPos == 0 && intEndingPos == 0)){
		 try{
             String strValue = line.split("\\*")[indexValue].substring(intStartPos,intEndingPos).replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    return strValue;
             }
             
       }
       catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
    	   return "";
       }
	}
	else{
      
		 try{
             String strValue = line.split("\\*")[indexValue].replace("~", "").trim();
             if(!(strValue.equalsIgnoreCase(""))){
                    
                    return strValue;
             }
             
       }
       catch(Exception e){
            // System.out.println("Flat file value is not present for '" + strKeyName + "' field");
             return "";
       }
	}
	return "";
       
}



public static  List<SortedMap<String,String>> parseFileWithOutHeaderByDelimeter(String delimeter,String testFlatFileCompletePath,String fieldColumnMappingFilePath,String mappingSheetName) throws IOException{
	
	 //String testFlatFileCompletePath="\\\\bsc\\it\\ITQA_Automation\\Care1st Member migration\\Automation\\SUC automation\\Required Documents\\12. SUC546265-DRX To MAM\\MAPDP_Complete_2018_20180401.bsc180401111900.txt";
	 File inputFile = new File(testFlatFileCompletePath);
	 List<SortedMap<String,String>> listOfRows=new ArrayList<SortedMap<String,String>>();
	 String line=null;
	 if (!inputFile.exists()) { 
		  throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	  } else {
						System.out.println("Starting of File Reading . . . . . .  . . . . ");
						//src/test/resources/TestData.xlsx
					//	new ExcelUtils("C:\\Users\\bgujja01\\bqsa32\\workspace\\Care1stMMInboundAndOutboundFileValidation\\src\\test\\resources\\FileFieldAndTableColumnMapping.xlsx","SUC580263");
						new ExcelUtilsExtended(fieldColumnMappingFilePath,mappingSheetName);

						FileReader fileReader =  new FileReader(testFlatFileCompletePath);
						@SuppressWarnings("resource")
						BufferedReader bufferedReader =        new BufferedReader(fileReader);
				        while((line = bufferedReader.readLine()) != null) {
			                String[] columnsArray = line.split(delimeter);
				        	  
			                SortedMap<String,String> rowMap=new TreeMap<String,String>();
							int columnLength=columnsArray.length;
							for(int i=0;i<columnLength;i++){
								String fileFieldName=String.valueOf(i);
							//	System.out.println("excel Value:"+ExcelUtils.getDBColumnName(fileFieldName)+" | "+columnsArray[i]);
								String columnNameKey=ExcelUtilsExtended.getDBColumnName(fileFieldName);
								if(columnNameKey!=null){
								rowMap.put(columnNameKey.toLowerCase(),columnsArray[i].toLowerCase());	//System.out.println(rowNo+"  columnlength::"+columnLength+" index: "+i+"  "+rowsList.get(rowNo)[i]);
								}
							}
							listOfRows.add(rowMap);
			                     		}   
						
				    
 	}
	return listOfRows;
}


	
}
