package com.bsc.qa.facets.ffp.pojo.BscAccumsToMHSA;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscAccumsToMHSABody {
	
	private String Record_Type; 
	private String Member_ID; 
	private String First_Name; 
	private String Middle_Name;
	private String Last_Name; 
	private String Gender; 
	private String DOB; 
	private String Accum_Type; 
	private String Filler_Unused; 
	private String Accum_Start_DT; 
	private String Accum_End_DT; 
	private String Accumul_Amount; 
	private String Accumulator_Quantity; 
	private String Filler_Unused2;
	

	public String getRecord_Type() {
		return Record_Type;
	}
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	public String getMember_ID() {
		return Member_ID;
	}
	public void setMember_ID(String member_ID) {
		Member_ID = member_ID;
	}
	public String getFirst_Name() {
		return First_Name;
	}
	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}
	public String getMiddle_Name() {
		return Middle_Name;
	}
	public void setMiddle_Name(String middle_Name) {
		Middle_Name = middle_Name;
	}
	public String getLast_Name() {
		return Last_Name;
	}
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getAccum_Type() {
		return Accum_Type;
	}
	public void setAccum_Type(String accum_Type) {
		Accum_Type = accum_Type;
	}
	public String getFiller_Unused() {
		return Filler_Unused;
	}
	public void setFiller_Unused(String filler_Unused) {
		Filler_Unused = filler_Unused;
	}
	public String getAccum_Start_DT() {
		return Accum_Start_DT;
	}
	public void setAccum_Start_DT(String accum_Start_DT) {
		Accum_Start_DT = accum_Start_DT;
	}
	public String getAccum_End_DT() {
		return Accum_End_DT;
	}
	public void setAccum_End_DT(String accum_End_DT) {
		Accum_End_DT = accum_End_DT;
	}
	public String getAccumul_Amount() {
		return Accumul_Amount;
	}
	public void setAccumul_Amount(String accumul_Amount) {
		Accumul_Amount = accumul_Amount;
	}
	public String getAccumulator_Quantity() {
		return Accumulator_Quantity;
	}
	public void setAccumulator_Quantity(String accumulator_Quantity) {
		Accumulator_Quantity = accumulator_Quantity;
	}
	public String getFiller_Unused2() {
		return Filler_Unused2;
	}
	public void setFiller_Unused2(String filler_Unused2) {
		Filler_Unused2 = filler_Unused2;
	} 


}
