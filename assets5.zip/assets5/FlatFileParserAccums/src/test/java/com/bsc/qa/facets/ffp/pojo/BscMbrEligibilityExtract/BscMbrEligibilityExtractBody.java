package com.bsc.qa.facets.ffp.pojo.BscMbrEligibilityExtract;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscMbrEligibilityExtractBody {
	
	private String Subscriber_Id;
	private String Member_Indicator;
	private String Member_Last_Name;
	private String Member_First_Name;
	private String Member_Relationship;
	private String Member_Middle_Initial;
	private String Home_Address_Line_1;
	private String Home_Address_Line_2;
	private String Home_Address_City;
	private String Home_Address_State;
	private String Home_Address_Zip_Code;
	private String Home_Address_Zip_Extension;
	private String Home_Phone_Number;
	private String Work_Phone_Number;
	private String Gender;
	private String Birth_Date;
	private String Group_Policy_Number;
	private String Subgroup_Policy_Number;
	private String Emp_Sub_Group_Effective_Date;
	private String Dental_Product_Code;
	private String Plan_Effective_Date;
	private String Billing_Tier_Code;
	private String Tier_Code_Eff_Date;
	private String Prov_Number;
	private String Prov_No_Eff_Date;
	private String Original_Dental_Effective_Date;
	private String Plan_Termination_Date;
	private String Plan_Benefit_Package;
	private String Filler5;
	private String ALT_ID;
	private String Student_Status;
	private String Handicapped;
	private String Written_Preference_Language;
	private String Written_Pref_Eff_Date;
	private String Spoken_Preference_Language;
	private String Spoken_Pref_Eff_Date;
	private String CA_Language_Assistance_Program_Eligibility_Indicator;
	private String Parent_Group;
	private String Previous_Subscriber_ID;
	private String Previous_Member_Suffix;
	private String Group_Organization_ID;
	private String Claims_Paid_To_Date;
	private String Medical_Coverage;
	private String Other_Member_Status;
	private String Mailing_Address_Line_1;
	private String Mailing_Address_Line_2;
	private String Mailing_Address_City;
	private String Mailing_Address_State;
	private String Mailing_Address_Zip;
	private String Mailing_Address_Zip_Extension;
	private String Alternate_Address_Line_1;
	private String Alternate_Address_Line_2;
	private String Alternate_Address_City;
	private String Alternate_Address_State;
	private String Alternate_Address_Zip_Extension;
	private String Eligibility_Through_Date;
	private String Subsidy_end_date;
	private String Exchange_Or_Shop_Indicator;
	private String Previous_Billing_Unit;
	private String Dental_Plan_Code;
	private String Previous_Group_Number;
	private String Accounting_Code;
	private String Member_SSN;
	private String Alternate_Address_Zip_Code;

	/**
	 * @return the Subscriber_Id
	 */
	public String getSubscriber_Id() {
		return Subscriber_Id;
	}
	/**
	 * @param Subscriber_Id the Subscriber_Id to set
	 */
	public void setSubscriber_Id(String subscriber_Id) {
		Subscriber_Id = subscriber_Id;
	}
	/**
	 * @return the Member_Indicator
	 */
	public String getMember_Indicator() {
		return Member_Indicator;
	}
	/**
	 * @param member_ID_Patient the member_ID_Patient to set
	 */
	public void setMember_Indicator(String member_Indicator) {
		Member_Indicator = member_Indicator;
	}

	/**
	 * @Return Member Last Name
	 */
	public String getMember_Last_Name(){
		return Member_Last_Name;
	
	}
	/**
	 * @param Member_Last_Name set to member_Last_Name
	 * 
	 */
	
	public void setMember_Last_Name(String member_Last_Name){
		Member_Last_Name=member_Last_Name;
	}
	
	/**
	 * @Return Member_First_Name
	 */
	public String getMember_First_Name(){
	return Member_First_Name;
	}
	/**
	 * @param set the Member_First_Name to member_First_Name
	 * 
	 */
	public void setMember_First_Name(String member_First_Name){
		Member_First_Name = member_First_Name;
	}
	
	/**
	 * @return 
	 */
	
	public String getMember_Relationship(){
		return Member_Relationship;
	}
	/**
	 * @param set Member_Relationship to member_Relationship
	 */
	public void setMember_Relationship(String member_Relationship){
		Member_Relationship = member_Relationship;
	}
	
	/**
	 * @return Member_Middle_Initial
	 */
	public String getMember_Middle_Initial(){
		return Member_Middle_Initial;
	}
	
	/**
	 * @param set Member_Middle_Initial to member_Middle_Initial
	 */
	public void setMember_Middle_Initial(String member_Middle_Initial){
		Member_Middle_Initial = member_Middle_Initial;
	}
	
	/**
	 * @return Home_Address_Line_1
	 */
	public String getHome_Address_Line_1(){
		return Home_Address_Line_1;
	}
	/**
	 * @param set Home_Address_Line_1 to Home_Address_Line_1 
	 */
	public void setHome_Address_Line_1(String home_Address_Line_1){
		Home_Address_Line_1 = home_Address_Line_1;
	}

	/**
	 * @return Home_Address_Line_2
	 */
	public String getHome_Address_Line_2(){
		return Home_Address_Line_2;
	}

	public void setHome_Address_Line_2(String home_Address_Line_2){
		Home_Address_Line_2 = home_Address_Line_2;
	}
	/**
	 * @return Home_Address_City 
	 */
	
	public String getHome_Address_City(){
		return Home_Address_City;
	}
	/**
	 * @param set Home_Address_City to home_Address_City
	 */
	public void setHome_Address_City(String home_Address_City){
		Home_Address_City=home_Address_City;
	}
	/**
	 * @return Home_Address_State
	 */
	public String getHome_Address_State(){
		return Home_Address_State;
	}
	/**
	 * @param set Home_Address_State to home_Address_State
	 */
	public void setHome_Address_State(String home_Address_State){
		Home_Address_State = home_Address_State;
	}
	/**
	 * @return Home_Address_Zip_Code
	 */
	public String getHome_Address_Zip_Code(){
		return Home_Address_Zip_Code;
	}
	/**
	 * @param set Home_Address_Zip_Code tro home_Address_Zip_Code
	 */
	public void setHome_Address_Zip_Code(String home_Address_Zip_Code){
		Home_Address_Zip_Code=home_Address_Zip_Code;
	}
	
	/**
	 * @return Home_Address_Zip_Extension
	 */
	public String getHome_Address_Zip_Extension(){
		return Home_Address_Zip_Extension;
	}
	/**
	 * @param set Home_Address_Zip_Extension to home_Address_Zip_Extension
	 */
	public void setHome_Address_Zip_Extension(String home_Address_Zip_Extension){
		Home_Address_Zip_Extension=home_Address_Zip_Extension;
	}

	/**
	 * @return Home_Phone_Number
	 * 
	 */
	public String getHome_Phone_Number(){
		return Home_Phone_Number;

	}
	/***
	 * @param set Home_Phone_Number to home_Phone_Number
	 */
	public void setHome_Phone_Number(String home_Phone_Number){
		Home_Phone_Number=home_Phone_Number;
	}
	
	/**
	 * @return Work_Phone_Number
	 */
	public String getWork_Phone_Number(){
		return Work_Phone_Number;
	}
	/**
	 * @param set Work_Phone_Number to work_Phone_Number
	 */
	public void setWork_Phone_Number(String work_Phone_Number){
		Work_Phone_Number=work_Phone_Number;
	}
	/**
	 * @param Gender 
	 * @return Gender
	 */
	public String getGender(){
		return Gender;
	}
	/***
	 * @param set Gender to gender
	 */
	public void setGender(String gender){
		Gender =gender;
	}
	/**
	 * @return Birth_Date
	 */
	public String getBirth_Date(){
		return Birth_Date;
	}
	/**
	 * @param set Birth_Date to birth_Date
	 */
	public void setBirth_Date(String birth_Date){
		Birth_Date =birth_Date;
	}
	/**
	 * @return Group_Policy_Number
	 */
	public String getGroup_Policy_Number(){
		return Group_Policy_Number;
	
	}
	/**
	 *@param set Group_Policy_Number to group_Policy_Number
	 */
	public void setGroup_Policy_Number(String group_Policy_Number){
		Group_Policy_Number=group_Policy_Number;
	}
	/**
	 * @return Subgroup_Policy_Number
	 * 
	 */
	public String getSubgroup_Policy_Number(){
		return Subgroup_Policy_Number;
	}
	/**
	 * @param set Subgroup_Policy_Number to subgroup_Policy_Number
	 */
	public void setSubgroup_Policy_Number(String subgroup_Policy_Number){
		Subgroup_Policy_Number =subgroup_Policy_Number;
	}

	/**
	 * @return Emp_Sub_Group_Effective_Date
	 */
	public String getEmp_Sub_Group_Effective_Date(){
		return Emp_Sub_Group_Effective_Date;
	}
	/**
	 * @param set Emp_Sub_Group_Effective_Date to emp_Sub_Group_Effective_Date
	 */
	public void setEmp_Sub_Group_Effective_Date(String emp_Sub_Group_Effective_Date){
		Emp_Sub_Group_Effective_Date = emp_Sub_Group_Effective_Date;
	}
	/**
	 * @return Dental_Product_Code
	 */
	public String getDental_Product_Code(){
		return Dental_Product_Code;
	}
	/**
	 * @oarm set Dental_Product_Code to dental_Product_Code
	 */
	public void setDental_Product_Code(String dental_Product_Code){
		Dental_Product_Code=dental_Product_Code;
	}
	/**
	 * @return 
	 */
	public String getPlan_Effective_Date(){
		return Plan_Effective_Date;
	}
	/**
	 * @param set Plan_Effective_Date to plan_Effective_Date
	 */
	public void setPlan_Effective_Date(String plan_Effective_Date){
		Plan_Effective_Date = plan_Effective_Date;
	}
	/***
	 * @return Billing_Tier_Code
	 */
	public String getBilling_Tier_Code(){
		return Billing_Tier_Code;
		
	}
	/**
	 * @param set Billing_Tier_Code to Billing_Tier_Code
	 */
	public void setBilling_Tier_Code(String billing_Tier_Code){
		Billing_Tier_Code =billing_Tier_Code;
	}
	/**
	 * @return Tier_Code_Eff_Date
	 */
	public String getTier_Code_Eff_Date(){
		return Tier_Code_Eff_Date;
	}
	/**
	 * @param set Tier_Code_Eff_Date to tier_Code_Eff_Date
	 */
	public void setTier_Code_Eff_Date(String tier_Code_Eff_Date){
		Tier_Code_Eff_Date = tier_Code_Eff_Date;
	}
	/**
	 * @param Prov_Number
	 */
	public String getProv_Number(){
		return Prov_Number;
	}
	/**
	 * @param set Prov_Number to prov_Number
	 */
	public void setProv_Number(String prov_Number){
		Prov_Number = prov_Number;
	}
	/**
	 * @return Prov_No_Eff_Date
	 */
	public String getProv_No_Eff_Date(){
		return Prov_No_Eff_Date;
	}
	/**
	 * @param set Prov_No_Eff_Date to prov_No_Eff_Date
	 */
	public void setProv_No_Eff_Date(String prov_No_Eff_Date){
		Prov_No_Eff_Date = prov_No_Eff_Date;
	}
	/**
	 * @return Original_Dental_Effective_Date
	 */
	public String getOriginal_Dental_Effective_Date(){
		return Original_Dental_Effective_Date;
	}
	/**
	 * @param set Original_Dental_Effective_Date to original_Dental_Effective_Date
	 */
	public void setOriginal_Dental_Effective_Date(String original_Dental_Effective_Date){
		Original_Dental_Effective_Date=original_Dental_Effective_Date;
	}
	/*
	 * @return Plan_Termination_Date
	 */
	public String getPlan_Termination_Date(){
		return Plan_Termination_Date;
	}
	/**
	 * @param set Plan_Termination_Date to plan_Termination_Date
	 */
	public void setPlan_Termination_Date(String plan_Termination_Date){
		Plan_Termination_Date = plan_Termination_Date;
	}
	/**
	 * @return Plan_Benefit_Package
	 */
	public String getPlan_Benefit_Package(){
		return Plan_Benefit_Package;
	}
	/**
	 * @param set Plan_Benefit_Package to plan_Benefit_Package
	 */
	public void setPlan_Benefit_Package(String plan_Benefit_Package){
		Plan_Benefit_Package=plan_Benefit_Package;
	}
	/**
	 * @return Filler
	 */
	public String getFiller5(){
		return Filler5;
	}
	/**
	 */
	public void setFiller5(String filler5){
		Filler5 =filler5;
	}
	/**
	 * @return ALT_ID
	 */
	public String getALT_ID(){
		return ALT_ID;
	}
	/**
	 * @param set ALT_ID to aLT_ID
	 */
	public void setALT_ID(String aLT_ID){
		ALT_ID = aLT_ID;
	}
	/**
	 * @Student_Status
	 *
	 */
	public String getStudent_Status(){
		return Student_Status;
	}
	/**
	 * @param set Student_Status to student_Status
	 */
	public void setStudent_Status(String student_Status){
		Student_Status= student_Status;
	}
	/**
	 * @return Handicapped
	 */
	public String getHandicapped(){
		return Handicapped;
	}
	/**
	 * @param set Handicapped to handicapped
	 */
	public void setHandicapped(String handicapped){
		Handicapped =handicapped;
	}
	/**
	 * @return Written_Preference_Language
	 */
	public String getWritten_Preference_Language(){
		return Written_Preference_Language;
	}
	/**
	 * @param set Written_Preference_Language to written_Preference_Language
	 */
	public void setWritten_Preference_Language(String written_Preference_Language){
		Written_Preference_Language =written_Preference_Language;
	}
/**
 * @return Written_Preference_Effective_Date
 * 
 */
	public String getWritten_Pref_Eff_Date(){
		return Written_Pref_Eff_Date;
	}
	/**
	 * @PARam set Written_Preference_Effective_Date to written_Preference_Effective_Date 
	 */
	public void setWritten_Pref_Eff_Date(String written_Pref_Eff_Date){
		Written_Pref_Eff_Date=written_Pref_Eff_Date;
	}

	/**
	 * @return Spoken_Preference_Language
	 */
	public String getSpoken_Preference_Language(){
		return Spoken_Preference_Language;
	}
	/**
	 * @param set Spoken_Preference_Language to spoken_Preference_Language
	 */
	public void setSpoken_Preference_Language(String spoken_Preference_Language){
		Spoken_Preference_Language = spoken_Preference_Language;
	}
	/**
	 * @return Spoken_Preference_Effective_Date
	 */
	public String getSpoken_Pref_Eff_Date(){
		return Spoken_Pref_Eff_Date;
	}
	/**
	 * @param set Spoken_Preference_Effective_Date to spoken_Preference_Effective_Date
	 */
	public void setSpoken_Pref_Eff_Date(String spoken_Pref_Eff_Date){
		Spoken_Pref_Eff_Date = spoken_Pref_Eff_Date;
	}
	/**
	 *@return CA_Language_Assistance_Program_Eligibility_Indicator
	 */
	public String getCA_Language_Assistance_Program_Eligibility_Indicator(){
		return CA_Language_Assistance_Program_Eligibility_Indicator;
	}
	/**
	 * @param set CA_Language_Assistance_Program_Eligibility_Indicator to cA_Language_Assistance_Program_Eligibility_Indicator
	 */
	public void setCA_Language_Assistance_Program_Eligibility_Indicator(String cA_Language_Assistance_Program_Eligibility_Indicator){
		CA_Language_Assistance_Program_Eligibility_Indicator=cA_Language_Assistance_Program_Eligibility_Indicator;
	}
	/*
	 *@return Parent_Group
	 */
	public String getParent_Group(){
		return Parent_Group;
	}
	/**
	 * @param set Parent_Group to parent_Group
	 */
	public void setParent_Group(String parent_Group){
		Parent_Group = parent_Group;
	}
	/*
	 *@return Previous_Subscriber_ID
	 */
	public String getPrevious_Subscriber_ID(){
		return Previous_Subscriber_ID;
	}
	/**
	 * @param set Previous_Subscriber_ID to previous_Subscriber_ID
	 */
	public void setPrevious_Subscriber_ID(String previous_Subscriber_ID){
		Previous_Subscriber_ID = previous_Subscriber_ID;
	}
	/**
	 * @retun Previous_Member_Suffix
	 */
	public String getPrevious_Member_Suffix(){
		return Previous_Member_Suffix;
	}
	/**
	 * @param set Previous_Member_Suffix to previous_Member_Suffix
	 */
	public void setPrevious_Member_Suffix(String previous_Member_Suffix){
		Previous_Member_Suffix = previous_Member_Suffix;
	}
	/**
	 * @return Group_Organization_ID
	 */
	public String getGroup_Organization_ID(){
		return Group_Organization_ID;
	}
	/**
	 * @param set Group_Organization_ID to group_Organization_ID
	 */
	public void setGroup_Organization_ID(String group_Organization_ID){
		Group_Organization_ID = group_Organization_ID;
	}
	/**
	 * @return Claims_Paid_To_Date
	 */
	public String getClaims_Paid_To_Date(){
		return Claims_Paid_To_Date;
	}
	/*
	 * @param set Claims_Paid_To_Date to claims_Paid_To_Date
	 */
	
	public void setClaims_Paid_To_Date(String claims_Paid_To_Date){
		Claims_Paid_To_Date = claims_Paid_To_Date;
	}
	/**
	 * @return Medical_Coverage
	 */
	public String getMedical_Coverage(){
		return Medical_Coverage;
	}
	/**
	 * @param set Medical_Coverage to medical_Coverage
	 */
	public void setMedical_Coverage(String medical_Coverage){
		Medical_Coverage = medical_Coverage;
	}
	/**
	 * @return Other_Member_Status
	 */
	public String getOther_Member_Status(){
		return Other_Member_Status;
	}
	/**
	 * @param set Other_Member_Status to other_Member_Status
	 */
	public void setOther_Member_Status(String other_Member_Status){
		Other_Member_Status = other_Member_Status;
	}
	/**
	 * @return Mailing_Address_Line_1
	 */
	public String getMailing_Address_Line_1(){
		return Mailing_Address_Line_1;
	}
	/*
	 * @param set Mailing_Address_Line_1 to mailing_Address_Line_1
	 */
	public void setMailing_Address_Line_1(String mailing_Address_Line_1){
		Mailing_Address_Line_1 = mailing_Address_Line_1;
	}
	
	/**
	 * @return Mailing_Address_Line_2
	 */
	public String getMailing_Address_Line_2(){
		return Mailing_Address_Line_2;
	}
	/**
	 * @param set Mailing_Address_Line_2 to mailing_Address_Line_2
	 */
	
	public void setMailing_Address_Line_2(String mailing_Address_Line_2){
		Mailing_Address_Line_2 = mailing_Address_Line_2;
	}
	/**
	 * @return Mailing_Address_City
	 */
	public String getMailing_Address_City(){
		return Mailing_Address_City;
	}
	/**
	 * @param set Mailing_Address_City to mailing_Address_City
	 */
	public void setMailing_Address_City(String mailing_Address_City){
		Mailing_Address_City = mailing_Address_City;
	}
	/**
	 * @return Mailing_Address_State
	 */
	public String getMailing_Address_State(){
		return Mailing_Address_State;
	}
	/**
	 * @param set Mailing_Address_State to mailing_Address_State
	 */
	public void setMailing_Address_State(String mailing_Address_State){
		Mailing_Address_State = mailing_Address_State;
	}
	/**
	 * @return Mailing_Address_Zip
	 */
	public String getMailing_Address_Zip(){
		return Mailing_Address_Zip;
	}
	/**
	 * @param set Mailing_Address_Zip to mailing_Address_Zip
	 */
	public void setMailing_Address_Zip(String mailing_Address_Zip){
		Mailing_Address_Zip = mailing_Address_Zip;
	}
	/**
	 * @return Mailing_Address_Zip_Extension
	 */
	public String getMailing_Address_Zip_Extension(){
		return Mailing_Address_Zip_Extension;
	}
	/**
	 * @param set Mailing_Address_Zip_Extension to mailing_Address_Zip_Extension
	 */
	public void setMailing_Address_Zip_Extension(String mailing_Address_Zip_Extension){
		Mailing_Address_Zip_Extension =mailing_Address_Zip_Extension;
	}
	
	/**
	 * @return Mailing_Address_Line_1
	 */
	public String getAlternate_Address_Line_1(){
		return Alternate_Address_Line_1;
	}
	/*
	 * @param set Alternate_Address_Line_1 to Alternate_Address_Line_1
	 */
	public void setAlternate_Address_Line_1(String alternate_Address_Line_1){
		Alternate_Address_Line_1 = alternate_Address_Line_1;
	}
	
	/**
	 * @return Alternate_Address_Line_2
	 */
	public String getAlternate_Address_Line_2(){
		return Alternate_Address_Line_2;
	}
	/**
	 * @param set Alternate_Address_Line_2 to Alternate_Address_Line_2
	 */
	
	public void setAlternate_Address_Line_2(String alternate_Address_Line_2){
		Alternate_Address_Line_2 = alternate_Address_Line_2;
	}
	/**
	 * @return Alternate_Address_City
	 */
	public String getAlternate_Address_City(){
		return Alternate_Address_City;
	}
	/**
	 * @param set Alternate_Address_City to Alternate_Address_City
	 */
	public void setAlternate_Address_City(String alternate_Address_City){
		Alternate_Address_City = alternate_Address_City;
	}
	/**
	 * @return Alternate_Address_State
	 */
	public String getAlternate_Address_State(){
		return Alternate_Address_State;
	}
	/**
	 * @param set Alternate_Address_State to Alternate_Address_State
	 */
	public void setAlternate_Address_State(String alternate_Address_State){
		Alternate_Address_State = alternate_Address_State;
	}
	/**
	 * @return Alternate_Address_Zip
	 */
	public String getAlternate_Address_Zip_Code(){
		return Alternate_Address_Zip_Code;
	}
	/**
	 * @param set Alternate_Address_Zip to Alternate_Address_Zip
	 */
	public void setAlternate_Address_Zip_Code(String alternate_Address_Zip_Code){
		Alternate_Address_Zip_Code = alternate_Address_Zip_Code;
	}
	/**
	 * @return Alternate_Address_Zip_Extension
	 */
	public String getAlternate_Address_Zip_Extension(){
		return Alternate_Address_Zip_Extension;
	}
	/**
	 * @param set Alternate_Address_Zip_Extension to Alternate_Address_Zip_Extension
	 */
	public void setAlternate_Address_Zip_Extension(String alternate_Address_Zip_Extension){
		Alternate_Address_Zip_Extension =alternate_Address_Zip_Extension;
	}
	/**
	 * @return Member_SSN
	 */
	public String getMember_SSN(){
		return Member_SSN;
	}
	/**
	 * @param set Member_SSN to member_SSN
	 */
	public void setMember_SSN(String member_SSN){
		Member_SSN=member_SSN;
	}
	/**
	 * @return Accounting_Code
	 */
	public String getAccounting_Code(){
		return Accounting_Code;
	}
	/**
	 * @param set Accounting_Code to Accounting_Code
	 */
	public void setAccounting_Code(String accounting_Code){
		Accounting_Code = accounting_Code;
	}
	/**
	 * @return Dental_Plan_Code
	 */
	public String getDental_Plan_Code(){
		return Dental_Plan_Code;
	}
	/**
	 * @param set Dental_Plan_Code to dental_Plan_Code
	 */
	public void setDental_Plan_Code(String dental_Plan_Code){
		Dental_Plan_Code= dental_Plan_Code;
	}
	
	/**
	 * @return Previous_Group_Number
	 */
	public String getPrevious_Group_Number(){
		return Previous_Group_Number;
	}
	/**
	 * @param set Previous_Group_Number to previous_Group_Number
	 */
	public void setPrevious_Group_Number(String previous_Group_Number){
		Previous_Group_Number = previous_Group_Number;
	}
	/**
	 * @return Previous_Billing_Unit
	 */
	public String getPrevious_Billing_Unit(){
		return Previous_Billing_Unit;
	}
	/**
	 * @param set Previous_Billing_Unit to previous_Billing_Unit
	 */
	public void setPrevious_Billing_Unit(String previous_Billing_Unit){
		Previous_Billing_Unit = previous_Billing_Unit;
	}
	/**
	 * @return Exchange_Or_Shop_Indicator
	 */
	public String getExchange_Or_Shop_Indicator(){
		return Exchange_Or_Shop_Indicator;
	}
	/**
	 * @param set Exchange_Or_Shop_Indicator to exchange_Or_Shop_Indicator
	 */
	public void setExchange_Or_Shop_Indicator(String exchange_Or_Shop_Indicator){
		Exchange_Or_Shop_Indicator = exchange_Or_Shop_Indicator;
	}
	/**
	 * @return Subsidy_end_date
	 */
	public String getSubsidy_end_date(){
		return Subsidy_end_date;
	}
	/**
	 * @param set Subsidy_end_date to subsidy_end_date
	 */

	public void setSubsidy_end_date(String subsidy_end_date){
		Subsidy_end_date = subsidy_end_date;
	}
	/**
	 * @return "Eligibility_Through_Date"
	 */
	public String getEligibility_Through_Date(){
		return Eligibility_Through_Date;
	}
	/**
	 * @param set "Eligibility_Through_Date" to "eligibility_Through_Date"
	 */
	public void setEligibility_Through_Date(String eligibility_Through_Date){
		Eligibility_Through_Date =eligibility_Through_Date;
	}
	
}



