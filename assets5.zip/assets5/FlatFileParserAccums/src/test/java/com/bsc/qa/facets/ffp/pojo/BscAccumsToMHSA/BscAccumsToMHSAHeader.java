package com.bsc.qa.facets.ffp.pojo.BscAccumsToMHSA;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscAccumsToMHSAHeader {
	
	private String Record_Type;
	private String Filler_Unused;
	private String Company_Name;
	private String Creation_Date;
	private String Filler_Unused2;
	private String Frequency;
	private String Company_Contro_Code;
	private String Filler;
	/**
	 * @return the record_Type
	 */
	public String getRecord_Type() {
		return Record_Type;
	}
	/**
	 * @param record_Type the record_Type to set
	 */
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	/**
	 * @return the filler_Unused
	 */
	public String getFiller_Unused() {
		return Filler_Unused;
	}
	/**
	 * @param filler_Unused the filler_Unused to set
	 */
	public void setFiller_Unused(String filler_Unused) {
		Filler_Unused = filler_Unused;
	}
	/**
	 * @return the company_Name
	 */
	public String getCompany_Name() {
		return Company_Name;
	}
	/**
	 * @param company_Name the company_Name to set
	 */
	public void setCompany_Name(String company_Name) {
		Company_Name = company_Name;
	}
	/**
	 * @return the creation_Date
	 */
	public String getCreation_Date() {
		return Creation_Date;
	}
	/**
	 * @param creation_Date the creation_Date to set
	 */
	public void setCreation_Date(String creation_Date) {
		Creation_Date = creation_Date;
	}
	/**
	 * @return the filler_Unused2
	 */
	public String getFiller_Unused2() {
		return Filler_Unused2;
	}
	/**
	 * @param filler_Unused2 the filler_Unused2 to set
	 */
	public void setFiller_Unused2(String filler_Unused2) {
		Filler_Unused2 = filler_Unused2;
	}
	/**
	 * @return the frequency
	 */
	public String getFrequency() {
		return Frequency;
	}
	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(String frequency) {
		Frequency = frequency;
	}
	/**
	 * @return the company_Contro_Code
	 */
	public String getCompany_Contro_Code() {
		return Company_Contro_Code;
	}
	/**
	 * @param company_Contro_Code the company_Contro_Code to set
	 */
	public void setCompany_Contro_Code(String company_Contro_Code) {
		Company_Contro_Code = company_Contro_Code;
	}
	/**
	 * @return the filler
	 */
	public String getFiller() {
		return Filler;
	}
	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		Filler = filler;
	}

	

}
