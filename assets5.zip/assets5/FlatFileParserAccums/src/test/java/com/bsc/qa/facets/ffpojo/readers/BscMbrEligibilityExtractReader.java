package com.bsc.qa.facets.ffpojo.readers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bsc.qa.facets.ffp.pojo.BscMbrEligibilityExtract.*;
import com.bsc.qa.facets.ffp.pojo.BscShdwAccumsToAshp.BscShdwAccumsToAshpBody;
import com.bsc.qa.facets.ffp.pojo.BscShdwAccumsToAshp.BscShdwAccumsToAshpHeader;
import com.bsc.qa.facets.ffp.pojo.BscShdwAccumsToAshp.BscShdwAccumsToAshpTrailer;
import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.file.reader.RecordType;


public class BscMbrEligibilityExtractReader{
	
	String testFlatFileCompletePath; // <== Path to a test file  
	
	public BscMbrEligibilityExtractReader(String testFlatFileCompletePath) {
		this.testFlatFileCompletePath = testFlatFileCompletePath;
	} 


	////////////////////////////////FLAT FILE HEADER TO LIST////////////////////
	public List<Map<String, String>> getListOfHeaderValues() throws IOException{
						
		List<Map<String , String>> headersList  = new ArrayList<Map<String,String>>();
		
        File inputFile = new File(testFlatFileCompletePath);
    	
		if (!inputFile.exists()) { 
			
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { // if (!inputFile.exists()) { 
			
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscMbrEligibilityExtractBody.class);   // <== BODY
			ffDefinition.setHeader(BscMbrEligibilityExtractHeader.class); ffDefinition.setTrailer(BscMbrEligibilityExtractTrailer.class);
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		
			for (Object record : ffReader) {
				
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.HEADER) { //<=== Headers 
					
					Map<String,String> headersMap = new HashMap<String, String>();
					
					//System.out.println("HEADER FOUND: ");
					
					BscMbrEligibilityExtractHeader header = (BscMbrEligibilityExtractHeader)record;
					headersMap.put("FILLER", header.getFILLER());
					headersMap.put("RECORD_TYPE", header.getRECORD_TYPE());
					headersMap.put("FILLER1", header.getFILLER1());
					headersMap.put("DATA_TYPE", header.getDATA_TYPE());
					headersMap.put("FILLER2", header.getFILLER2());
					headersMap.put("CREATION_DATE", header.getCREATION_DATE());
					headersMap.put("FILLER3", header.getFILLER3());
					headersMap.put("FILE_TYPE", header.getFILE_TYPE());
					headersMap.put("FILLER4", header.getFILLER4());
					headersMap.put("ENVIRONMENT", header.getENVIRONMENT());
					headersMap.put("FILLER_UNUSED", header.getFILLER_UNUSED());
					headersList.add(0,headersMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
				    			
				} //if (recordType == RecordType.HEADER)
				
			} // <== for (Object record : ffReader) {
			
			ffReader.close(); //Close Object 
		
		} // if (!inputFile.exists()) { 
	
		return headersList; // method return value 
						
	} 
	
	////////////////////////////////FLAT FILE BODY TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfBodyValues() throws IOException{
				
		List<Map<String , String>> bodyList  = new ArrayList<Map<String,String>>();
		// get file 
        File inputFile = new File(testFlatFileCompletePath);
    	//test if file exist 
		if (!inputFile.exists()) { 
			//cry if file does not exist 
			throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
			
		} else { //if (!inputFile.exists()) { 
			// do the magic if file exists 
			FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscMbrEligibilityExtractBody.class);   // <== BODY
			ffDefinition.setHeader(BscMbrEligibilityExtractHeader.class); ffDefinition.setTrailer(BscMbrEligibilityExtractTrailer.class);
			
			
			FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		    int counter = 0;
		    
			for (Object record : ffReader) {
				
				RecordType recordType = ffReader.getRecordType();
				
				if (recordType == RecordType.BODY) { //<=== BODY 
					
					Map<String,String> bodyMap = new HashMap<String, String>(); //<== NEW HASH MAP ON EVERY LOOP 
					
					BscMbrEligibilityExtractBody body = (BscMbrEligibilityExtractBody)record;
					bodyMap.put("Subscriber_Id".toUpperCase(), body.getSubscriber_Id()); //<== Add
					bodyMap.put("Member_Indicator".toUpperCase(), body.getMember_Indicator());
					bodyMap.put("Member_Last_Name".toUpperCase(), body.getMember_Last_Name());
					bodyMap.put("Member_First_Name".toUpperCase(), body.getMember_First_Name());
					bodyMap.put("Member_Relationship".toUpperCase(), body.getMember_Relationship());
					bodyMap.put("Member_Middle_Initial".toUpperCase(), body.getMember_Middle_Initial());
					bodyMap.put("Home_Address_Line_1".toUpperCase(), body.getHome_Address_Line_1());
					bodyMap.put("Home_Address_Line_2".toUpperCase(), body.getHome_Address_Line_2());
					bodyMap.put("Home_Address_City".toUpperCase(),body.getHome_Address_City());
					bodyMap.put("Home_Address_State".toUpperCase(), body.getHome_Address_State());
					bodyMap.put("Home_Address_Zip_Code".toUpperCase(), body.getHome_Address_Zip_Code());
					bodyMap.put("Home_Address_Zip_Extension".toUpperCase(), body.getHome_Address_Zip_Extension());
					bodyMap.put("Home_Phone_Number".toUpperCase(), body.getHome_Phone_Number());
					bodyMap.put("Work_Phone_Number".toUpperCase(), body.getWork_Phone_Number());
					bodyMap.put("Gender".toUpperCase(), body.getGender());
					bodyMap.put("Birth_Date".toUpperCase(), body.getBirth_Date());;
					bodyMap.put("Group_Policy_Number".toUpperCase(), body.getGroup_Policy_Number());
					bodyMap.put("Subgroup_Policy_Number".toUpperCase(), body.getSubgroup_Policy_Number());
					bodyMap.put("Emp_Sub_Group_Effective_Date".toUpperCase(), body.getEmp_Sub_Group_Effective_Date());
					bodyMap.put("Dental_Product_Code".toUpperCase(), body.getDental_Product_Code());
					bodyMap.put("Plan_Effective_Date".toUpperCase(), body.getPlan_Effective_Date());
					bodyMap.put("Billing_Tier_Code".toUpperCase(), body.getBilling_Tier_Code());
					bodyMap.put("Tier_Code_Eff_Date".toUpperCase(), body.getTier_Code_Eff_Date());
					bodyMap.put("Prov_Number".toUpperCase(), body.getProv_Number());
					bodyMap.put("Prov_No_Eff_Date".toUpperCase(), body.getProv_No_Eff_Date());
					bodyMap.put("Original_Dental_Effective_Date".toUpperCase(), body.getOriginal_Dental_Effective_Date());
					bodyMap.put("Plan_Termination_Date".toUpperCase(), body.getPlan_Termination_Date());
					bodyMap.put("Plan_Benefit_Package".toUpperCase(), body.getPlan_Benefit_Package());
					bodyMap.put("Filler5".toUpperCase(), body.getFiller5());
					bodyMap.put("ALT_ID".toUpperCase(), body.getALT_ID());;
					bodyMap.put("Student_Status".toUpperCase(), body.getStudent_Status());
					bodyMap.put("Handicapped".toUpperCase(), body.getHandicapped());
					bodyMap.put("Written_Preference_Language".toUpperCase(), body.getWritten_Preference_Language());
					bodyMap.put("Written_Pref_Eff_Date".toUpperCase(), body.getWritten_Pref_Eff_Date());
					bodyMap.put("Spoken_Preference_Language".toUpperCase(), body.getSpoken_Preference_Language());
					bodyMap.put("Spoken_Pref_Eff_Date".toUpperCase(), body.getSpoken_Pref_Eff_Date());
					bodyMap.put("CA_Language_Assistance_Program_Eligibility_Indicator".toUpperCase(), body.getCA_Language_Assistance_Program_Eligibility_Indicator());
					bodyMap.put("Parent_Group".toUpperCase(), body.getParent_Group());
					bodyMap.put("Previous_Subscriber_ID".toUpperCase(), body.getPrevious_Subscriber_ID());
					bodyMap.put("Previous_Member_Suffix".toUpperCase(), body.getPrevious_Member_Suffix());
					bodyMap.put("Group_Organization_ID".toUpperCase(), body.getGroup_Organization_ID());
					bodyMap.put("Claims_Paid_To_Date".toUpperCase(), body.getClaims_Paid_To_Date());
					bodyMap.put("Medical_Coverage".toUpperCase(), body.getMedical_Coverage());
					bodyMap.put("Other_Member_Status".toUpperCase(), body.getOther_Member_Status());
					bodyMap.put("Mailing_Address_Line_1".toUpperCase(), body.getMailing_Address_Line_1());
					bodyMap.put("Mailing_Address_Line_2".toUpperCase(), body.getMailing_Address_Line_2());
					bodyMap.put("Mailing_Address_City".toUpperCase(), body.getMailing_Address_City());
					bodyMap.put("Mailing_Address_State".toUpperCase(), body.getMailing_Address_State());
					bodyMap.put("Mailing_Address_Zip".toUpperCase(), body.getMailing_Address_Zip());
					bodyMap.put("Mailing_Address_Zip_Extension".toUpperCase(), body.getMailing_Address_Zip_Extension());
					bodyMap.put("Alternate_Address_Line_1".toUpperCase(), body.getAlternate_Address_Line_1());
					bodyMap.put("Alternate_Address_Line_2".toUpperCase(), body.getAlternate_Address_Line_2());
					bodyMap.put("Alternate_Address_City".toUpperCase(), body.getAlternate_Address_City());
					bodyMap.put("Alternate_Address_State".toUpperCase(), body.getAlternate_Address_State());
					bodyMap.put("Alternate_Address_Zip_Code".toUpperCase(), body.getAlternate_Address_Zip_Code());
					bodyMap.put("Alternate_Address_Zip_Extension".toUpperCase(), body.getAlternate_Address_Zip_Extension());
					bodyMap.put("Member_SSN".toUpperCase(), body.getMember_SSN());
					bodyMap.put("Accounting_Code".toUpperCase(), body.getAccounting_Code());
					bodyMap.put("Dental_Plan_Code".toUpperCase(), body.getDental_Plan_Code());
					bodyMap.put("Previous_Group_Number".toUpperCase(), body.getPrevious_Group_Number());
					bodyMap.put("Previous_Billing_Unit".toUpperCase(), body.getPrevious_Billing_Unit());
					bodyMap.put("Exchange_Or_Shop_Indicator".toUpperCase(), body.getExchange_Or_Shop_Indicator());
					bodyMap.put("Subsidy_end_date".toUpperCase(), body.getSubsidy_end_date());
					bodyMap.put("Eligibility_Through_Date".toUpperCase(),body.getEligibility_Through_Date());					
					//<== Add
					bodyList.add(counter,bodyMap); //<== Put Hash Map to Array List. 
					counter++;
				    			
				}			
			 } // <== for (Object record : ffReader) {
			
			ffReader.close(); //Close Object 	
			
		} // if (!inputFile.exists()) { 
		
		return bodyList; // method return value 
	
	} 
	
	
	////////////////////////////////FLAT TRAILER VALUES TO LIST/////////////////////////////////	
	public List<Map<String, String>> getListOfTrailerValues() throws IOException{
	//return list map 	
    List<Map<String , String>> trailerList  = new ArrayList<Map<String,String>>();

    File inputFile = new File(testFlatFileCompletePath); // <== Import of file under test 

    if (!inputFile.exists()) { 
	
	   throw new IllegalStateException("File not found: " + testFlatFileCompletePath);
	
    } else { // if (!inputFile.exists()) {
		FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(BscMbrEligibilityExtractBody.class);   // <== BODY
		ffDefinition.setHeader(BscMbrEligibilityExtractHeader.class); ffDefinition.setTrailer(BscMbrEligibilityExtractTrailer.class);
		

        FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);

        for (Object record : ffReader) {
   	
   	      RecordType recordType = ffReader.getRecordType();
   	
   	      if (recordType == RecordType.TRAILER) { //<=== TRAILER 
   		
   		    Map<String,String> TrailerMap = new HashMap<String, String>();
   		
   		   // System.out.println("Trailer FOUND: ");
   		
   		 BscMbrEligibilityExtractTrailer trailer = (BscMbrEligibilityExtractTrailer)record;
   	
   		  TrailerMap.put("Filler6".toUpperCase(), trailer.getFiller6()); //<== Add
   		  TrailerMap.put("Trailer_Record_Type".toUpperCase(), trailer.getTrailer_Record_Type()); //<== Add
   		  TrailerMap.put("Trailer_Filler_Unused_1".toUpperCase(), trailer.getTrailer_Filler_Unused_1()); //<== Add
   		  TrailerMap.put("Trailer_Filler_Unused_2".toUpperCase(), trailer.getTrailer_Filler_Unused_2()); //<== Add
   		  TrailerMap.put("Trailer_Filler_Unused_3".toUpperCase(), trailer.getTrailer_Filler_Unused_3()); //<== Add
   		  TrailerMap.put("File_Record_Count".toUpperCase(), trailer.getFile_Record_Count()); //<== Add
 		  TrailerMap.put("Trailer_Filler_Unused_4".toUpperCase(), trailer.getTrailer_Filler_Unused_4()); //<== Add
 		  TrailerMap.put("Subscriber_Detail_Count".toUpperCase(), trailer.getSubscriber_Detail_Count()); //<== Add
 		  TrailerMap.put("Trailer_Filler_Unused_5".toUpperCase(), trailer.getTrailer_Filler_Unused_5()); //<== Add
 		  TrailerMap.put("Dependent_Detail_Count".toUpperCase(), trailer.getDependent_Detail_Count()); //<== Add
 		  TrailerMap.put("Trailer_Filler_Unused_6".toUpperCase(), trailer.getTrailer_Filler_Unused_6()); //<== Add	
 		  TrailerMap.put("Total_Detail_Count".toUpperCase(), trailer.getTotal_Detail_Count()); //<== Add
		  TrailerMap.put("Trailer_Filler_Unused_7".toUpperCase(), trailer.getTrailer_Filler_Unused_7()); //<== Add
   						
   		  trailerList.add(0,TrailerMap); //<== Put Hash Map to Array List. Note Header has only  one line, so it's hardcoded to zero index 
   	    			
   	      }
   	
        } // <== for (Object record : ffReader) {

    ffReader.close(); //Close Object 
    
    } //if (!inputFile.exists()) {

	
     return trailerList; // method return value 
		
	}	// <== public List<Map<String, String>> getListOfTrailerValues(){
	
	

}
