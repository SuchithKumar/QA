package com.bsc.qa.facets.ffp.pojo.BscAccumsToSavemart;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscAccumsToSavemartBody {

	private String DETAIL_INDICATOR;
	private String CLASS_ID;
	private String MEMBER_IDENTIFICATION_NUMBER;
	private String MEMBER_SUFFIX;
	private String RELATIONSHIP_CODE;
	private String GENDER;
	private String MEMBER_FIRST_NAME;
	private String MEMBER_LAST_NAME;
	private String MEMBER_DOB;
	private String PLAN_CODE;
	private String DED_NW_IND;
	private String DED_AMT;
	private String OOPM_NW_IND;
	private String OOPM_AMOUNT;
	private String BENEFIT_YEAR;
	private String FILLER;
	/**
	 * @return the dETAIL_INDICATOR
	 */
	public String getDETAIL_INDICATOR() {
		return DETAIL_INDICATOR;
	}
	/**
	 * @param dETAIL_INDICATOR the dETAIL_INDICATOR to set
	 */
	public void setDETAIL_INDICATOR(String dETAIL_INDICATOR) {
		DETAIL_INDICATOR = dETAIL_INDICATOR;
	}
	/**
	 * @return the cLASS_ID
	 */
	public String getCLASS_ID() {
		return CLASS_ID;
	}
	/**
	 * @param cLASS_ID the cLASS_ID to set
	 */
	public void setCLASS_ID(String cLASS_ID) {
		CLASS_ID = cLASS_ID;
	}
	/**
	 * @return the mEMBER_IDENTIFICATION_NUMBER
	 */
	public String getMEMBER_IDENTIFICATION_NUMBER() {
		return MEMBER_IDENTIFICATION_NUMBER;
	}
	/**
	 * @param mEMBER_IDENTIFICATION_NUMBER the mEMBER_IDENTIFICATION_NUMBER to set
	 */
	public void setMEMBER_IDENTIFICATION_NUMBER(String mEMBER_IDENTIFICATION_NUMBER) {
		MEMBER_IDENTIFICATION_NUMBER = mEMBER_IDENTIFICATION_NUMBER;
	}
	/**
	 * @return the mEMBER_SUFFIX
	 */
	public String getMEMBER_SUFFIX() {
		return MEMBER_SUFFIX;
	}
	/**
	 * @param mEMBER_SUFFIX the mEMBER_SUFFIX to set
	 */
	public void setMEMBER_SUFFIX(String mEMBER_SUFFIX) {
		MEMBER_SUFFIX = mEMBER_SUFFIX;
	}
	/**
	 * @return the rELATIONSHIP_CODE
	 */
	public String getRELATIONSHIP_CODE() {
		return RELATIONSHIP_CODE;
	}
	/**
	 * @param rELATIONSHIP_CODE the rELATIONSHIP_CODE to set
	 */
	public void setRELATIONSHIP_CODE(String rELATIONSHIP_CODE) {
		RELATIONSHIP_CODE = rELATIONSHIP_CODE;
	}
	/**
	 * @return the gENDER
	 */
	public String getGENDER() {
		return GENDER;
	}
	/**
	 * @param gENDER the gENDER to set
	 */
	public void setGENDER(String gENDER) {
		GENDER = gENDER;
	}
	/**
	 * @return the mEMBER_FIRST_NAME
	 */
	public String getMEMBER_FIRST_NAME() {
		return MEMBER_FIRST_NAME;
	}
	/**
	 * @param mEMBER_FIRST_NAME the mEMBER_FIRST_NAME to set
	 */
	public void setMEMBER_FIRST_NAME(String mEMBER_FIRST_NAME) {
		MEMBER_FIRST_NAME = mEMBER_FIRST_NAME;
	}
	/**
	 * @return the mEMBER_LAST_NAME
	 */
	public String getMEMBER_LAST_NAME() {
		return MEMBER_LAST_NAME;
	}
	/**
	 * @param mEMBER_LAST_NAME the mEMBER_LAST_NAME to set
	 */
	public void setMEMBER_LAST_NAME(String mEMBER_LAST_NAME) {
		MEMBER_LAST_NAME = mEMBER_LAST_NAME;
	}
	/**
	 * @return the mEMBER_DOB
	 */
	public String getMEMBER_DOB() {
		return MEMBER_DOB;
	}
	/**
	 * @param mEMBER_DOB the mEMBER_DOB to set
	 */
	public void setMEMBER_DOB(String mEMBER_DOB) {
		MEMBER_DOB = mEMBER_DOB;
	}
	/**
	 * @return the pLAN_CODE
	 */
	public String getPLAN_CODE() {
		return PLAN_CODE;
	}
	/**
	 * @param pLAN_CODE the pLAN_CODE to set
	 */
	public void setPLAN_CODE(String pLAN_CODE) {
		PLAN_CODE = pLAN_CODE;
	}
	/**
	 * @return the dED_NW_IND
	 */
	public String getDED_NW_IND() {
		return DED_NW_IND;
	}
	/**
	 * @param dED_NW_IND the dED_NW_IND to set
	 */
	public void setDED_NW_IND(String dED_NW_IND) {
		DED_NW_IND = dED_NW_IND;
	}
	/**
	 * @return the dED_AMT
	 */
	public String getDED_AMT() {
		return DED_AMT;
	}
	/**
	 * @param dED_AMT the dED_AMT to set
	 */
	public void setDED_AMT(String dED_AMT) {
		DED_AMT = dED_AMT;
	}
	/**
	 * @return the oOPM_NW_IND
	 */
	public String getOOPM_NW_IND() {
		return OOPM_NW_IND;
	}
	/**
	 * @param oOPM_NW_IND the oOPM_NW_IND to set
	 */
	public void setOOPM_NW_IND(String oOPM_NW_IND) {
		OOPM_NW_IND = oOPM_NW_IND;
	}
	/**
	 * @return the oOPM_AMOUNT
	 */
	public String getOOPM_AMOUNT() {
		return OOPM_AMOUNT;
	}
	/**
	 * @param oOPM_AMOUNT the oOPM_AMOUNT to set
	 */
	public void setOOPM_AMOUNT(String oOPM_AMOUNT) {
		OOPM_AMOUNT = oOPM_AMOUNT;
	}
	/**
	 * @return the bENEFIT_YEAR
	 */
	public String getBENEFIT_YEAR() {
		return BENEFIT_YEAR;
	}
	/**
	 * @param bENEFIT_YEAR the bENEFIT_YEAR to set
	 */
	public void setBENEFIT_YEAR(String bENEFIT_YEAR) {
		BENEFIT_YEAR = bENEFIT_YEAR;
	}
	/**
	 * @return the fILLER
	 */
	public String getFILLER() {
		return FILLER;
	}
	/**
	 * @param fILLER the fILLER to set
	 */
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
