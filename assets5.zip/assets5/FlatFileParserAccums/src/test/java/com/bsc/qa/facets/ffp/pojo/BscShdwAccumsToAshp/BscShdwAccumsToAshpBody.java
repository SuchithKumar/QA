package com.bsc.qa.facets.ffp.pojo.BscShdwAccumsToAshp;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscShdwAccumsToAshpBody {
	
	private String Record_Type;
	private String Member_ID_Patient;
	private String First_Name;
	private String Middle_Name;
	private String Last_Name;
	private String Gender;
	private String DOB;
	private String Type_of_accumulator;
	private String Filler_Unused1;
	private String Accumulator_start_date;
	private String Accumulator_end_date;
	private String Accumulator_dollar_amount;
	private String Filler_Unused2;
	/**
	 * @return the record_Type
	 */
	public String getRecord_Type() {
		return Record_Type;
	}
	/**
	 * @param record_Type the record_Type to set
	 */
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	/**
	 * @return the member_ID_Patient
	 */
	public String getMember_ID_Patient() {
		return Member_ID_Patient;
	}
	/**
	 * @param member_ID_Patient the member_ID_Patient to set
	 */
	public void setMember_ID_Patient(String member_ID_Patient) {
		Member_ID_Patient = member_ID_Patient;
	}
	/**
	 * @return the first_Name
	 */
	public String getFirst_Name() {
		return First_Name;
	}
	/**
	 * @param first_Name the first_Name to set
	 */
	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}
	/**
	 * @return the middle_Name
	 */
	public String getMiddle_Name() {
		return Middle_Name;
	}
	/**
	 * @param middle_Name the middle_Name to set
	 */
	public void setMiddle_Name(String middle_Name) {
		Middle_Name = middle_Name;
	}
	/**
	 * @return the last_Name
	 */
	public String getLast_Name() {
		return Last_Name;
	}
	/**
	 * @param last_Name the last_Name to set
	 */
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return Gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		Gender = gender;
	}
	/**
	 * @return the dOB
	 */
	public String getDOB() {
		return DOB;
	}
	/**
	 * @param dOB the dOB to set
	 */
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	/**
	 * @return the type_of_accumulator
	 */
	public String getType_of_accumulator() {
		return Type_of_accumulator;
	}
	/**
	 * @param type_of_accumulator the type_of_accumulator to set
	 */
	public void setType_of_accumulator(String type_of_accumulator) {
		Type_of_accumulator = type_of_accumulator;
	}
	/**
	 * @return the filler_Unused1
	 */
	public String getFiller_Unused1() {
		return Filler_Unused1;
	}
	/**
	 * @param filler_Unused1 the filler_Unused1 to set
	 */
	public void setFiller_Unused1(String filler_Unused1) {
		Filler_Unused1 = filler_Unused1;
	}
	/**
	 * @return the accumulator_start_date
	 */
	public String getAccumulator_start_date() {
		return Accumulator_start_date;
	}
	/**
	 * @param accumulator_start_date the accumulator_start_date to set
	 */
	public void setAccumulator_start_date(String accumulator_start_date) {
		Accumulator_start_date = accumulator_start_date;
	}
	/**
	 * @return the accumulator_end_date
	 */
	public String getAccumulator_end_date() {
		return Accumulator_end_date;
	}
	/**
	 * @param accumulator_end_date the accumulator_end_date to set
	 */
	public void setAccumulator_end_date(String accumulator_end_date) {
		Accumulator_end_date = accumulator_end_date;
	}
	/**
	 * @return the accumulator_dollar_amount
	 */
	public String getAccumulator_dollar_amount() {
		return Accumulator_dollar_amount;
	}
	/**
	 * @param accumulator_dollar_amount the accumulator_dollar_amount to set
	 */
	public void setAccumulator_dollar_amount(String accumulator_dollar_amount) {
		Accumulator_dollar_amount = accumulator_dollar_amount;
	}
	/**
	 * @return the filler_Unused2
	 */
	public String getFiller_Unused2() {
		return Filler_Unused2;
	}
	/**
	 * @param filler_Unused2 the filler_Unused2 to set
	 */
	public void setFiller_Unused2(String filler_Unused2) {
		Filler_Unused2 = filler_Unused2;
	}

	
	
	
	
	
	
	}

