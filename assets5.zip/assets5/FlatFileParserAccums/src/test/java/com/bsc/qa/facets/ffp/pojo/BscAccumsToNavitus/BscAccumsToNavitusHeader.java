package com.bsc.qa.facets.ffp.pojo.BscAccumsToNavitus;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true)

public class BscAccumsToNavitusHeader {
	
	
	private String HEADER_INDICATOR;
	private String CLIENT_NAME;
	private String FILE_DATE;
	private String FILLER;
	
	
	/**
	 * @return the HEADER_INDICATOR
	 */
	public String getHEADER_INDICATOR() {
		return HEADER_INDICATOR;
	}
	/**
	 * @param HEADER_INDICATOR the HEADER_INDICATOR to set
	 */
	public void setHEADER_INDICATOR(String HEADER_INDICATOR) {
		this.HEADER_INDICATOR = HEADER_INDICATOR;
	}
	/**
	 * @return the CLIENT_NAME
	 */
	public String getCLIENT_NAME() {
		return CLIENT_NAME;
	}
	/**
	 * @param CLIENT_NAME the CLIENT_NAME to set
	 */
	public void setCLIENT_NAME(String CLIENT_NAME) {
		this.CLIENT_NAME = CLIENT_NAME;
	}
	/**
	 * @return the FILE_DATE
	 */
	public String getFILE_DATE() {
		return FILE_DATE ;
	}
	/**
	 * @param FILE_DATE the FILE_DATE to set
	 */
	public void setFILE_DATE(String FILE_DATE) {
		this.FILE_DATE = FILE_DATE;
	}
	/**
	 
	 * @return the FILLER
	 */
	public String getFILLER() {
		return FILLER;
	}
	/**
	 * @param FILLER the FILLER to set
	 */
	public void setFILLER(String FILLER) {
		this.FILLER = FILLER;
	}



}
