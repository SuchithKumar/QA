package com.bsc.qa.facets.ffp.pojo.BscMbrEligibilityExtract;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true)

public class BscMbrEligibilityExtractHeader {
	
	
	private String FILLER;
	private String RECORD_TYPE;
	private String FILLER1;
	private String DATA_TYPE;
	private String FILLER2;
	private String CREATION_DATE;
	private String FILLER3;
	private String FILE_TYPE;
	private String FILLER4;
	private String ENVIRONMENT;
	private String FILLER_UNUSED;
	

	
	/**
	 * @return the FILLER
	 */
	public String getFILLER() {
		return FILLER;
	}
	/**
	 * @param FILLER the FILLER to set
	 */
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	/**
	 * @return the RECORDTYPE
	 */
	public String getRECORD_TYPE() {
		return RECORD_TYPE;
	}
	/**
	 * @param RECORD_TYPE the RECORD_TYPE to set
	 */
	public void setRECORD_TYPE(String rECORD_TYPE) {
		RECORD_TYPE = rECORD_TYPE;
	}

	
	/**
	 * @ return the FILLER1
	 **/
	public String getFILLER1(){
		return FILLER1;
	}
	/**
	 * @Parm FILLER1 the FILLER1 to set
	 */
	public void setFILLER1(String fILLER1){
		FILLER1 = fILLER1;
	}
	/**
	 * @ return DATA_TYPE
	 */
	
	public String getDATA_TYPE(){
		return DATA_TYPE;
	}
	/**
	 * @parm DATA_TYPE the DATA_TYPE to set
	 */
	public void setDATA_TYPE(String dATA_TYPE){
		DATA_TYPE= dATA_TYPE;
	}
	/**
	 * @return FILLER2
	 */
	public String getFILLER2(){
		return FILLER2;
	}
	/**
	 * @Parm FILLER2 the FILLER2 to set
	 */
	public void setFILLER2(String fILLER2){
		FILLER2=fILLER2;
	}
	/**
	 * @return CREATION_DATE
	 */
	public String getCREATION_DATE(){
		return CREATION_DATE;
	}
	/***
	 * @parm CREATION_DATE the CREATION_DATE to set
	 */
	public void setCREATION_DATE(String cREATION_DATE){
		CREATION_DATE=cREATION_DATE;
	}
	/**
	 * @return FILLER3
	 */
	public String getFILLER3(){
		return FILLER3;
	}
	/**
	 * @parm FILLER3 the FILLER3 to set
	 */
	public void setFILLER3(String fILLER3){
		FILLER3=fILLER3;
	}
	/**
	 * @return FILE_TYPE
	 */
	public String getFILE_TYPE(){
		return FILE_TYPE;
	}
	/***
	 * @parm String the String to set
	 */
	public void setFILE_TYPE(String fILE_TYPE){
		FILE_TYPE=fILE_TYPE;
	}
	/**
	 * @return FILLER4
	 */
	public String getFILLER4(){
		return FILLER4;
	}
	/**
	 * @parm FILLER4 the FILLER4 to set
	 */
	public void setFILLER4(String fILLER4){
		FILLER4=fILLER4;
	}
	/**
	 * @return ENVIRONMENT
	 */
	public String getENVIRONMENT(){
		return ENVIRONMENT;
	}
	/**
	 * @parm ENVIRONMENT the ENVIRONMENT to set
	 */
	public void setENVIRONMENT(String eNVIRONMENT){
		ENVIRONMENT=eNVIRONMENT;
	}
	/**
	 * @return FILLER_UNUSED
	 */
	public String getFILLER_UNUSED(){
		return FILLER_UNUSED;
	}
	/**
	 * @parm FILLER_UNUSED the FILLER_UNUSED to set
	 */
	public void setFILLER_UNUSED(String fILLER_UNUSED){
		FILLER_UNUSED=fILLER_UNUSED;
	}
}
		
		
	
	
	
	