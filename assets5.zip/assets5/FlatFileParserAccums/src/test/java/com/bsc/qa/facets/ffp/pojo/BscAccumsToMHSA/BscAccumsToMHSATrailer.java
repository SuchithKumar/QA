package com.bsc.qa.facets.ffp.pojo.BscAccumsToMHSA;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE 

public class BscAccumsToMHSATrailer {
	

	private String Record_Type; 
	private String Filler_Unused; 
	private String Total_Records; 
	private String Total_Amount; 
	private String Total_Quantity; 
	private String Filler_Unused2;
	/**
	 * @return the record_Type
	 */
	public String getRecord_Type() {
		return Record_Type;
	}
	/**
	 * @param record_Type the record_Type to set
	 */
	public void setRecord_Type(String record_Type) {
		Record_Type = record_Type;
	}
	/**
	 * @return the filler_Unused
	 */
	public String getFiller_Unused() {
		return Filler_Unused;
	}
	/**
	 * @param filler_Unused the filler_Unused to set
	 */
	public void setFiller_Unused(String filler_Unused) {
		Filler_Unused = filler_Unused;
	}
	/**
	 * @return the total_Records
	 */
	public String getTotal_Records() {
		return Total_Records;
	}
	/**
	 * @param total_Records the total_Records to set
	 */
	public void setTotal_Records(String total_Records) {
		Total_Records = total_Records;
	}
	/**
	 * @return the total_Amount
	 */
	public String getTotal_Amount() {
		return Total_Amount;
	}
	/**
	 * @param total_Amount the total_Amount to set
	 */
	public void setTotal_Amount(String total_Amount) {
		Total_Amount = total_Amount;
	}
	/**
	 * @return the total_Quantity
	 */
	public String getTotal_Quantity() {
		return Total_Quantity;
	}
	/**
	 * @param total_Quantity the total_Quantity to set
	 */
	public void setTotal_Quantity(String total_Quantity) {
		Total_Quantity = total_Quantity;
	}
	/**
	 * @return the filler_Unused2
	 */
	public String getFiller_Unused2() {
		return Filler_Unused2;
	}
	/**
	 * @param filler_Unused2 the filler_Unused2 to set
	 */
	public void setFiller_Unused2(String filler_Unused2) {
		Filler_Unused2 = filler_Unused2;
	} 
	
	
	
	
}
