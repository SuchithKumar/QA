package com.bsc.qa.facets.ffp.pojo.BscMbrEligibilityExtract;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;// <== Mandatory 

@PositionalRecord(ignorePositionNotFound=true) // <== Mandatory 

public class BscMbrEligibilityExtractTrailer {
	

	private String Filler6;
	private String Trailer_Record_Type;
	private String Trailer_Filler_Unused_1;
	private String Trailer_Filler_Unused_2;
	private String Trailer_Filler_Unused_3;
	private String File_Record_Count;
	private String Trailer_Filler_Unused_4;
	private String Subscriber_Detail_Count;
	private String Trailer_Filler_Unused_5;
	private String Dependent_Detail_Count;
	private String Trailer_Filler_Unused_6;
	private String Total_Detail_Count;
	private String Trailer_Filler_Unused_7;


	/**
	 * @return Filler6
	 */
	public String getFiller6(){
		return Filler6;
	}
	/**
	 * @param set Filler6 to Filler6
	 */
	public void setFiller6(String filler6){
		Filler6 = filler6;
	}
	/**
	 * @return Record_Type
	 */
	public String getTrailer_Record_Type(){
		return Trailer_Record_Type;
	}
	/**
	 * @param set Trailer_Record_Type to trailer_Record_Type
	 */
	public void setTrailer_Record_Type(String trailer_Record_Type){
		Trailer_Record_Type = trailer_Record_Type;
	}
	
	/**
	 * @return Trailer_Filler_Unused_1
	 */
	public String getTrailer_Filler_Unused_1(){
		return Trailer_Filler_Unused_1;
	}
	/**
	@param set Trailer_Filler_Unused_1to trailer_Filler_Unused_1
	*/
	public void setTrailer_Filler_Unused_1(String trailer_Filler_Unused_1){
		Trailer_Filler_Unused_1 = trailer_Filler_Unused_1;
	}
	/**
	 * @return Trailer_Filler_Unused_2
	 */
	public String getTrailer_Filler_Unused_2(){
		return Trailer_Filler_Unused_2;
	}
	/**
	 * @param set Trailer_Filler_Unused_2 to trailer_Filler_Unused_2
	 */
	public void setTrailer_Filler_Unused_2(String trailer_Filler_Unused_2){
		Trailer_Filler_Unused_2 = trailer_Filler_Unused_2;
	}
	/**
	 * @return Trailer_Filler_Unused_3
	 */
	public String getTrailer_Filler_Unused_3(){
		return Trailer_Filler_Unused_3;
	}
	/***
	 * @param set Trailer_Filler_Unused_3 to Trailer_Filler_Unused_3
	 */
	public void setTrailer_Filler_Unused_3(String trailer_Filler_Unused_3){
		Trailer_Filler_Unused_3 = trailer_Filler_Unused_3;
	}
	/**
	 * @return File_Record_Count
	 * 
	 */
	public String getFile_Record_Count(){
		return File_Record_Count;
	}
	/**
	 * @param set File_Record_Count to file_Record_Count
	 */
	public void setFile_Record_Count(String file_Record_Count){
		File_Record_Count = file_Record_Count;
	}
	
	/**
	 * @return Trailer_Filler_Unused_4
	 */
	public String getTrailer_Filler_Unused_4(){
		return Trailer_Filler_Unused_4;
	}
	/**
	 * @param set Trailer_Filler_Unused_4 to trailer_Filler_Unused_4
	 */
	public void setTrailer_Filler_Unused_4(String trailer_Filler_Unused_4){
		Trailer_Filler_Unused_4 =trailer_Filler_Unused_4;
	}
	/**
	 * @return Subscriber_Detail_Count
	 */
	public String getSubscriber_Detail_Count(){
		return Subscriber_Detail_Count;
	}

	/**
	 * @param set Subscriber_Detail_Count to subscriber_Detail_Count
	 */
	public void setSubscriber_Detail_Count(String subscriber_Detail_Count){
		Subscriber_Detail_Count=subscriber_Detail_Count;
	}
	/**
	 * @return Trailer_Filler_Unused_5
	 */
	public String getTrailer_Filler_Unused_5(){
		return Trailer_Filler_Unused_5;
	}
	/**
	 * @param set Trailer_Filler_Unused_5 to trailer_Filler_Unused_5
	 */
	public void setTrailer_Filler_Unused_5(String trailer_Filler_Unused_5){
		Trailer_Filler_Unused_5 = trailer_Filler_Unused_5;
	}
	/**
	 * @return Dependent_Detail_Count
	 */
	public String getDependent_Detail_Count(){
		return Dependent_Detail_Count;
		
	}
	/**
	 * @param set Dependent_Detail_Count to dependent_Detail_Count
	 */
	public void setDependent_Detail_Count(String dependent_Detail_Count){
		Dependent_Detail_Count= dependent_Detail_Count;
	}
	/**
	 * @return Trailer_Filler_Unused_6
	 */
	public String getTrailer_Filler_Unused_6(){
		return Trailer_Filler_Unused_6;
	}
	/**
	 * @param set Trailer_Filler_Unused_6 to trailer_Filler_Unused_6
	 */
	public void setTrailer_Filler_Unused_6(String trailer_Filler_Unused_6){
		Trailer_Filler_Unused_6=trailer_Filler_Unused_6;
	}
	/**
	 * @return Total_Detail_Count
	 */
	public String getTotal_Detail_Count(){
		return Total_Detail_Count;
	}
	/**
	 * @param set Total_Detail_Count to total_Detail_Count
	 */
	public void setTotal_Detail_Count(String total_Detail_Count){
		Total_Detail_Count = total_Detail_Count;
	}
	/**
	 * @return Trailer_Filler_Unused_7
	 */
	public String getTrailer_Filler_Unused_7(){
		return Trailer_Filler_Unused_7;
	}
	/**
	 * @param set Trailer_Filler_Unused_7 to trailer_Filler_Unused_7
	 */
	public void setTrailer_Filler_Unused_7(String trailer_Filler_Unused_7){
		Trailer_Filler_Unused_7 = trailer_Filler_Unused_7;
	}

}
