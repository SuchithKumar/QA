package com.bsc.qa.facets.tests;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.readers.BscMbrEligibilityExtractReader;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
//import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
//import com.relevantcodes.extentreports.ExtentTest;


public class BscMbrEligibilityExtractTest extends BaseTest implements IHookable{
	
	//private static String strMEMBER_IDENTIFICATION_NUMBER;  
    private static int bodyRowsCount;
    //private static String strMEMBER_SUFFIX;
    //static ExtentReports log;
    //comments added for Verificaiton
    //final private static String strUniqueIdentifier1= "MEMBER_IDENTIFICATION_NUMBER";    
    //final private static String strUniqueIdentifier2 = "MEMBER_SUFFIX";  
    private static BscMbrEligibilityExtractReader ffpExtract;
    
	private static List<Map<String, String>> testHeader;
	private static List<Map<String, String>> testBody;
	private static List<Map<String, String>> testTrailer;
	private static String expectedValue;
	

	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles", "FileSpecificFolderName"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
        	
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
	 	
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		 
		 TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
		 	
		 filePAth = tesFile.getCompleteTestFilePath()[0];
		 fileNAme = tesFile.getCompleteTestFilePath()[1].toUpperCase();
		 FileNameSplit = fileNAme.split("_");
		 		 
		 //read flat file before test 
		  ffpExtract = new BscMbrEligibilityExtractReader(filePAth);
		 
			//Parse headers and store in to testHeaders
			try {
				testHeader = ffpExtract.getListOfHeaderValues();
			
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			//Parse headers and store in to testHeaders
			try {
				testBody = ffpExtract.getListOfBodyValues(); // array list of hash map values 
				bodyRowsCount = testBody.size(); // body rows count
				
				// check with serhiy... no need of below lie. header doesn't requirer unique id . there will always be only one header line
							
				//please note the index zero. Assumption is made here that body of contained single row of data. 
				//String strSubscriber_ID = testBody.get(0).get(strUniqueIdentifier1); // <== Unique ID will vary from file to file
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			
			//Parse headers and store in to testTrailers
			try {
				testTrailer = ffpExtract.getListOfTrailerValues();
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
	}
	

	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  HEADER TEST METHODS  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	
	@Test(dataProvider = "masterDataProvider")
	private static void testFileName(Map<String, String> data){
	
		SoftAssert softAssertion=new SoftAssert(); 
		softAssertion.assertTrue(fileNAme.matches("^BSCFACETS_OPTUM(ELIG|GROUP)_(FULL|DELTA)_\\d{8}_\\d{6}(.TXT)$"));
		logger.log(LogStatus.INFO, " Actual Value: " + fileNAme +" Expected File Name format: BSCFACETS_OPTUMXXX_YYYY_MMDDYYYY_HHMMSS.TXT ");
		System.out.println(" Actual Value: " + fileNAme +" Expected Value: ");
		softAssertion.assertAll();
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderFiller(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		//LogStatus LogDetails = new LogStatus();
		
		String SQLQuery = data.get("sql_Filler").toString();
		
		//run SQL Query
		ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);
		
		//get result set to Array. PLeae not hardcoded index of arrya. Agreement is to create queries taht return string set of expected data. rest will eb ignored.
		String[] strRecordSet = ArrayResult[0].split("#");
		
		//get records column name to string
		String expectedFieldName = strRecordSet[0].trim();
		
		//Get record expecetd value to string
		String expectedValue = strRecordSet[1];
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
					
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			System.out.println("Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			} else {
				
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderRecord_Type(Map<String, String> data){
		String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		
		String SQLQuery = data.get("sql_Record_Type").toString();
		
		//run SQL Query
		ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);
		
		//get result set to Array. PLeae not hardcoded index of arrya. Agreement is to create queries taht return string set of expected data. rest will eb ignored.
		String[] strRecordSet = ArrayResult[0].split("#");
		
		//get records column name to string
		String expectedFieldName = strRecordSet[0].trim();
		
		//Get record expecetd value to string
		String expectedValue = strRecordSet[1];
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			System.out.println("ACtual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}
	

	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderFiller1(Map<String, String> data){
		String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		
		String SQLQuery = data.get("sql_Filler1").toString();
		
		//run SQL Query
		ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);
		
		//get result set to Array. PLeae not hardcoded index of arrya. Agreement is to create queries taht return string set of expected data. rest will eb ignored.
		String[] strRecordSet = ArrayResult[0].split("#");
		
		//get records column name to string
		String expectedFieldName = strRecordSet[0].trim();
		
		//Get record expecetd value to string
		String expectedValue = strRecordSet[1];
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			System.out.println("ACtual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderData_Type(Map<String, String> data){
		String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		
		String SQLQuery = data.get("sql_Data_Type").toString();
		
		//run SQL Query
		ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);
		
		//get result set to Array. PLeae not hardcoded index of arrya. Agreement is to create queries taht return string set of expected data. rest will eb ignored.
		String[] strRecordSet = ArrayResult[0].split("#");
		
		//get records column name to string
		String expectedFieldName = strRecordSet[0].trim();
		
		//Get record expecetd value to string
		String expectedValue = strRecordSet[1];
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			System.out.println("ACtual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderFiller2(Map<String, String> data){
		String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		
		String SQLQuery = data.get("sql_Filler2").toString();
		
		//run SQL Query
		ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);
		
		//get result set to Array. PLeae not hardcoded index of arrya. Agreement is to create queries taht return string set of expected data. rest will eb ignored.
		String[] strRecordSet = ArrayResult[0].split("#");
		
		//get records column name to string
		String expectedFieldName = strRecordSet[0].trim();
		
		//Get record expecetd value to string
		String expectedValue = strRecordSet[1];
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			System.out.println("ACtual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderCreation_Date(Map<String, String> data){
		//String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		
		//get records column name to string
		String expectedFieldName = "CREATION_DATE";
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Validating with Date formateCompare Values
			softAssertion.assertTrue(flatFileValuesMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
			+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
			+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
			+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$")); // It has been covered Feb 29/General days in FEB/31 day in month/30 day in month
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Format Value: Date Format ");
			System.out.println("Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim()+" Expected Format Value: Date Format");
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Header Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderFiller3(Map<String, String> data){
		String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		
		String SQLQuery = data.get("sql_Filler3").toString();
		
		//run SQL Query
		ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);
		
		//get result set to Array. PLeae not hardcoded index of arrya. Agreement is to create queries taht return string set of expected data. rest will eb ignored.
		String[] strRecordSet = ArrayResult[0].split("#");
		
		//get records column name to string
		String expectedFieldName = strRecordSet[0].trim();
		
		//Get record expecetd value to string
		String expectedValue = strRecordSet[1];
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			System.out.println("ACtual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}

	

	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderFile_Type(Map<String, String> data){
		
		SoftAssert softAssertion=new SoftAssert(); 
		String expectedFieldName = "FILE_TYPE".toUpperCase();

		//Reading the File tyoe value from File name and assigning the Correct File_type
		if (FileNameSplit[2].contains("FULL")){
			expectedValue = "FULL SNAP 365TM";
		} else if(FileNameSplit[2].contains("DELTA")){
			expectedValue = "TRANSACTIONAL".toUpperCase();
			
		}
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			System.out.println("ACtual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}
	

	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderFiller4(Map<String, String> data){
		String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		
		String SQLQuery = data.get("sql_Filler4").toString();
		
		//run SQL Query
		ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);
		
		//get result set to Array. PLeae not hardcoded index of arrya. Agreement is to create queries taht return string set of expected data. rest will eb ignored.
		String[] strRecordSet = ArrayResult[0].split("#");
		
		//get records column name to string
		String expectedFieldName = strRecordSet[0].trim();
		
		//Get record expecetd value to string
		String expectedValue = strRecordSet[1];
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			System.out.println("ACtual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}
	
	

	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderEnvironment(Map<String, String> data){
		String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		
		String SQLQuery = data.get("sql_Environment").toString();
		
		//run SQL Query
		ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);
		
		//get result set to Array. PLeae not hardcoded index of arrya. Agreement is to create queries taht return string set of expected data. rest will eb ignored.
		String[] strRecordSet = ArrayResult[0].split("#");
		
		//get records column name to string
		String expectedFieldName = strRecordSet[0].trim();
		
		//Get record expecetd value to string
		String expectedValue = strRecordSet[1];
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			System.out.println("ACtual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}
	
	

	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderFiller_Unused(Map<String, String> data){
		String[] ArrayResult;
		SoftAssert softAssertion=new SoftAssert(); 
		
		String SQLQuery = data.get("sql_Filler_Unused").toString();
		
		//run SQL Query
		ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);
		
		//get result set to Array. PLeae not hardcoded index of arrya. Agreement is to create queries taht return string set of expected data. rest will eb ignored.
		String[] strRecordSet = ArrayResult[0].split("#");
		
		//get records column name to string
		String expectedFieldName = strRecordSet[0].trim();
		
		//Get record expecetd value to string
		String expectedValue = strRecordSet[1];
		
		//get Hashmap of header valeus from Flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
		//Test if DB keys exisits in FF 
		if (flatFileValuesMap.containsKey(expectedFieldName)){
			//Compare Values
			softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" +expectedFieldName + ">> " );
			logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			System.out.println("ACtual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			
		} else {
				//Key does not exists report failure.
			  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expecetd Body Element" + expectedFieldName + " is Required" );
			}
		softAssertion.assertAll();
	}

	
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  BODY TEST METHODS  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodySubscriber_Id(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
			//Assigning colmn name to string 
			String expectedFieldName = "SUBSCRIBER_ID"; 
			//get records expected value to string
			//String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^\\d{9}$"));
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Subscriber ID - Numeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Subscriber ID - Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMember_Indicator(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
			//Assigning colmn name to string 
			String expectedFieldName = "MEMBER_INDICATOR"; 
			//get records expected value to string
			//String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^\\d{2}$"));
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator- Numeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator- Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMember_Last_Name(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
			//Assigning colmn name to string 
			String expectedFieldName = "MEMBER_LAST_NAME"; 
			//get records expected value to string
			//String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[A-Za-z]+$"));
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Last name - Alphabets ");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Last name - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMember_First_Name(Map<String, String> data){

		SoftAssert softAssertion= new SoftAssert();
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
			//Assigning colmn name to string 
			String expectedFieldName = "Member_First_Name".toUpperCase(); 
			//get records expected value to string
			//String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[A-Za-z]+$"));
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: First name - Alphabets ");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: First name - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMember_Relationship(Map<String, String> data){

		SoftAssert softAssertion= new SoftAssert();
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
			//Assigning Key name to string 
			String expectedFieldName = "Member_Relationship".toUpperCase(); 
						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[A-Za-z]{2}$"));
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + "Expected Format Value: Relationship - Alphabets ");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Relationship -Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMember_Middle_Initial(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Member_Middle_Initial").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  
		    	 softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	 logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyHome_Address_Line_1(Map<String, String> data){
	
		SoftAssert softAssertion= new SoftAssert();
		
		//Assigning Key name to string 
		String expectedFieldName = "Home_Address_Line_1".toUpperCase();
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
 
						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9, ]+$"));
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	@Test(dataProvider = "masterDataProvider")
	private static void testBodyHome_Address_Line_2(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		    	
		//Assigning Key name to string 
		String expectedFieldName = "Home_Address_Line_2".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	 softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9, ]+$" + "|^$"));
		    	 logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric/ Spaces");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric / SPaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyHome_Address_City(Map<String, String> data){
	
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Home_Address_City".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z ]+$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: City - Alphabets");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: City - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyHome_Address_State(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Home_Address_State".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    							
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z]{2}$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: State - Alphabets");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: State - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyHome_Address_Zip_Code(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
		//Assigning Key name to string 
		String expectedFieldName = "Home_Address_Zip_Code".toUpperCase(); 
					
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("\\d{5}"));		    	  
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip - Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyHome_Address_Zip_Extension(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Home_Address_Zip_Extension".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9 ]+$" + "|^$"));		    	  
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip COde Extension - Numeric/ Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyHome_Phone_Number(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Home_Phone_Number".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    					
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9]{3}-[0-9]{3}-[0-9]{4}$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Phone Number - Numeric/Spaces");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Phone Number - Numeric/Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyWork_Phone_Number(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
    	
		//Assigning Key name to string 
		String expectedFieldName = "Work_Phone_Number".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9]{3}-[0-9]{3}-[0-9]{4}$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Phone Number - Numeric/Spaces");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Phone Number - Numeric/Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyGender(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Gender".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z]$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Phone Number - Numeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Phone Number - Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyBirth_Date(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
		//Assigning Key name to string 
		String expectedFieldName = "Birth_Date".toUpperCase(); 
					
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
		    				+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Birth date - Date Format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Birth date - Date Format");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyGroup_Policy_Number(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Group_Policy_Number".toUpperCase(); 
					
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9]+$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Group - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Group - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodySubgroup_Policy_Number(Map<String, String> data){
	
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Subgroup_Policy_Number".toUpperCase(); 
					
 
	    for (Map<String, String> FlatFileMap : testBody) {

		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9]+$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Sub Group - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Sub Group - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyEmp_Sub_Group_Effective_Date(Map<String, String> data){
	
		SoftAssert softAssertion= new SoftAssert();
		
		//Assigning Key name to string 
		String expectedFieldName = "Emp_Sub_Group_Effective_Date".toUpperCase(); 
					
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
		    				+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Group EFF Date - Date format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Group EFF Date - Date format");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyDental_Product_Code(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Dental_Product_Code".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9]+$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Dental Code - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Dental Code - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyPlan_Effective_Date(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Plan_Effective_Date".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
		    				+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Plan EFF Date - Date format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Plan EFF Date - Date format");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyBilling_Tier_Code(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Billing_Tier_Code".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z]+$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Tier Code - Alphabets");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Tier Code - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyTier_Code_Eff_Date(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Tier_Code_Eff_Date".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
		    				+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Tier Code EFF Date - Date format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Tier Code EFF Date - Date format");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyProv_Number(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
		//Assigning Key name to string 
		String expectedFieldName = "Prov_Number".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^\\d{12}$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Provider Number - Numeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Provider Number - Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyProv_No_Eff_Date(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Prov_No_Eff_Date").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyOriginal_Dental_Effective_Date(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Original_Dental_Effective_Date".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
		    				+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Original_Dental_Effective_Date - Date format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Original_Dental_Effective_Date - Date format");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyPlan_Termination_Date(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Plan_Termination_Date".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    							
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
		    				+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Plan_Termination_Date - Date format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Plan_Termination_Date - Date format");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyPlan_Benefit_Package(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Plan_Benefit_Package").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyFiller5(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Filler5").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	@Test(dataProvider = "masterDataProvider")
	private static void testBodyALT_ID(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_ALT_ID").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyStudent_Status(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Student_Status").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyHandicapped(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Handicapped").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyWritten_Preference_Language(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Written_Preference_Language").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	

	@Test(dataProvider = "masterDataProvider")
	private static void testBodyWritten_Pref_Eff_Date(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Written_Pref_Eff_Date").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodySpoken_Preference_Language(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Spoken_Preference_Language").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	

	@Test(dataProvider = "masterDataProvider")
	private static void testBodySpoken_Pref_Eff_Date(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Spoken_Pref_Eff_Date").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyCA_Language_Assistance_Program_Eligibility_Indicator(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "CA_Language_Assistance_Program_Eligibility_Indicator".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z]$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator - Alphabets");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyParent_Group(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Parent_Group".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9]+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyPrevious_Subscriber_ID(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Previous_Subscriber_ID".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9]+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyPrevious_Member_Suffix(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Previous_Member_Suffix".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9]{2}+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")	
	private static void testBodyGroup_Organization_ID(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Group_Organization_ID".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9]{4}$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Organization ID - Numeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Organization ID - Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyClaims_Paid_To_Date(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Claims_Paid_To_Date".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    							
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
		    				+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Claims_Paid_To_Date - Date format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Claims_Paid_To_Date - Date format");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMedical_Coverage(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
    	
		//Assigning Key name to string 
		String expectedFieldName = "Medical_Coverage".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z]{1}$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Claims_Paid_To_Date - Date format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Indicator - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyOther_Member_Status(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Other_Member_Status").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testBody) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMailing_Address_Line_1(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
		//Assigning Key name to string 
		String expectedFieldName = "Mailing_Address_Line_1".toUpperCase();
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
 
						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9, ]+$" +"|^$"));
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMailing_Address_Line_2(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
		    	
		//Assigning Key name to string 
		String expectedFieldName = "Mailing_Address_Line_2".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		 
		    	 
		    	 softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9, ]+$" + "|^$"));
		    	 logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric / Spaces");		    	 		    
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric / Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMailing_Address_City(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Mailing_Address_City".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z ]+$" +"|^$"));
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: City - Alphabets");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: City - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMailing_Address_State(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Mailing_Address_State".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    							
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z]{2}$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: State - Alphabets");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: State - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMailing_Address_Zip(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
		//Assigning Key name to string 
		String expectedFieldName = "Mailing_Address_Zip".toUpperCase(); 
					
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("\\d{5}" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip - Numeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip - Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMailing_Address_Zip_Extension(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Mailing_Address_Zip_Extension".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9 ]+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip COde Extension - Numeric/ Spaces");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip COde Extension - Numeric/ Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyAlternate_Address_Line_1(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
		//Assigning Key name to string 
		String expectedFieldName = "Alternate_Address_Line_1".toUpperCase();
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
 
						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9, ]+$" + "|^$"));
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	@Test(dataProvider = "masterDataProvider")
	private static void testBodyAlternate_Address_Line_2(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
		    	
		//Assigning Key name to string 
		String expectedFieldName = "Alternate_Address_Line_2".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		 
		    	 
		    	 softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9, ]+$" + "|^$"));
		    	 logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric / Spaces");		    	 		    
		    	 System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Address - AlphaNumeric / Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyAlternate_Address_City(Map<String, String> data){
			
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Alternate_Address_City".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z ]+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: City - Alphabets");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: City - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyAlternate_Address_State(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
		//Assigning Key name to string 
		String expectedFieldName = "Alternate_Address_State".toUpperCase(); 
 
	    for (Map<String, String> FlatFileMap : testBody) {
	    							
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z]{2}$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: State - Alphabets");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: State - Alphabets");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyAlternate_Address_Zip_Code(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
		
		//Assigning Key name to string 
		String expectedFieldName = "Alternate_Address_Zip_Code".toUpperCase(); 
					
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("\\d{5}"+ "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip - Numeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip - Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyAlternate_Address_Zip_Extension(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Alternate_Address_Zip_Extension".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9 ]+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip COde Extension - Numeric/ Spaces");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Zip COde Extension - Numeric/ Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMember_SSN(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Member_SSN".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9]+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Member_SSN - Numeric/ Spaces");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Member_SSN - Numeric/ Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyAccounting_Code(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Accounting_Code".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9]+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Accounting_Code - Numeric/ Spaces");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Accounting_Code - Numeric/ Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyDental_Plan_Code(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Dental_Plan_Code".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9]{8}$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Accounting_Code - AlphaNumeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Accounting_Code - AlphaNumeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyPrevious_Group_Number(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Previous_Group_Number".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9]+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Previous_Group_Number - AlphaNumeric/Spaces");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Previous_Group_Number - AlphaNumeric/Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyPrevious_Billing_Unit(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Previous_Billing_Unit".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z0-9]+$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Previous_Billing_Unit - AlphaNumeric/Spaces");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Previous_Billing_Unit - AlphaNumeric/Spaces");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyExchange_Or_Shop_Indicator(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Exchange_Or_Shop_Indicator".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[a-zA-Z]$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: testBodyExchange_Or_Shop_Indicator - Alphabet");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: testBodyExchange_Or_Shop_Indicator - Alphabet");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodySubsidy_end_date(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Subsidy_end_date".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    							
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
		    				+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Subsidy_end_date - Date format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Subsidy_end_date - Date format");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyEligibility_Through_Date(Map<String, String> data){
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Eligibility_Through_Date".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testBody) {
	    							
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^(0229(2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26]))))$" 
		    				+ "|^(02(0[1-9]|1[0-9]|2[0-8])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[13578]|10|12)(0[1-9]|[12][0-9]|3[01])((19|2[0-9])[0-9]{2}))$" 
		    				+ "|^((0[469]|11)(0[1-9]|[12][0-9]|30)((19|2[0-9])[0-9]{2}))$" + "|^$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Eligibility_Through_Date - Date format");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Eligibility_Through_Date - Date format");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Trailer record MEthos @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerFiller6(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Filler6").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testTrailer) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerTrailer_Record_Type(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Trailer_Record_Type").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testTrailer) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerTrailer_Filler_Unused_1(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Trailer_Filler_Unused_1").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testTrailer) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerTrailer_Filler_Unused_2(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Trailer_Filler_Unused_2").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testTrailer) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerTrailer_Filler_Unused_3(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Trailer_Filler_Unused_3").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testTrailer) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerFile_Record_Count(Map<String, String> data) {

		SoftAssert softAssertion= new SoftAssert();

	    for (Map<String, String> FlatFileMap : testTrailer) {

			//get records colmn name to string 
			String expectedFieldName = "File_Record_Count".toUpperCase() ;// strRecordSet[0].trim(); 
			String DetailCOunt = "Total_Detail_Count".toUpperCase();
		    // Test if DB Key exists in FF ste of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		    	 
	        	int actualValue = Integer.parseInt(FlatFileMap.get(expectedFieldName).toString());
	        		
	        		//testing the lenth of TOTAL_RECORDS field
	        		//softAssertion.assertEquals(actualValue.length(), 30, " Expected lenth of TOTAL_RECORDS is 9 chars long ");
	        		
	        		FlatFileMap.get(DetailCOunt);
	        		int totalRecord = Integer.parseInt(FlatFileMap.get(DetailCOunt)) + 2;
	        		 softAssertion.assertEquals(actualValue, totalRecord, " Expected Value: " + totalRecord );
	        		 logger.log(LogStatus.INFO, "Actual Value: "+ actualValue + " Expected Value: " + totalRecord );
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim()  );
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Trailer Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }   
	    
	    softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	

	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerTrailer_Filler_Unused_4(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Trailer_Filler_Unused_4").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testTrailer) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerSubscriber_Detail_Count(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Subscriber_Detail_Count".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testTrailer) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9]+$"));		    	  
		    	  logger.log(LogStatus.INFO, " Actual Value: " + FlatFileMap.get(expectedFieldName).toString() + " Expected Format Value: Subscriber_Detail_Count - Numeric");
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Subscriber_Detail_Count - Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerTrailer_Filler_Unused_5(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Trailer_Filler_Unused_5").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testTrailer) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerDependent_Detail_Count(Map<String, String> data){
		
		
		SoftAssert softAssertion= new SoftAssert();
 
		//Assigning Key name to string 
		String expectedFieldName = "Dependent_Detail_Count".toUpperCase(); 
	    for (Map<String, String> FlatFileMap : testTrailer) {
	    	

						
		    // Test Key name exists in File Array list
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertTrue(FlatFileMap.get(expectedFieldName).matches("^[0-9]+$"));		    	  
		    	  logger.log(LogStatus.INFO, "Actual Value: " + FlatFileMap.get(expectedFieldName).toString() + "Expected Value: Numeric: Dependent_Detail_Count - Numeric " );
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Format Value: Dependent_Detail_Count - Numeric");
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerTrailer_Filler_Unused_6(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Trailer_Filler_Unused_6").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testTrailer) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	

	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerTotal_Detail_Count(Map<String, String> data) {

		SoftAssert softAssertion= new SoftAssert();

	    for (Map<String, String> FlatFileMap : testTrailer) {

			//get records colmn name to string 
			String expectedFieldName = "Total_Detail_Count".toUpperCase() ;// strRecordSet[0].trim(); 
			String SubscriberCount = "Subscriber_Detail_Count".toUpperCase();
			String DependentCount = "Dependent_Detail_Count".toUpperCase();
		    // Test if DB Key exists in FF ste of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		    	 
	        	int actualValue = Integer.parseInt(FlatFileMap.get(expectedFieldName).toString());
	        		
	        		//testing the lenth of TOTAL_RECORDS field
	        		//softAssertion.assertEquals(actualValue.length(), 30, " Expected lenth of TOTAL_RECORDS is 9 chars long ");

	        		 int DetailCount = Integer.parseInt(FlatFileMap.get(SubscriberCount)) + Integer.parseInt(FlatFileMap.get(DependentCount));
	        		 //note the conversion of integer value 
	        		 
	        		 softAssertion.assertEquals(actualValue,DetailCount , " Expected Value: " + bodyRowsCount );
	        		 logger.log(LogStatus.INFO, "Actual Value:" + actualValue + " Expected Value :" + DetailCount);
	        		 System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim());	
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Trailer Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }   
	    
	    softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	

	@Test(dataProvider = "masterDataProvider")
	private static void testTrailerTrailer_Filler_Unused_7(Map<String, String> data){
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		
		// get SQL QRY from Data Sheets
		String SQLQuery = data.get("sql_Trailer_Filler_Unused_7").toString();
		// for every element in body of file     
	    for (Map<String, String> FlatFileMap : testTrailer) {
	   	   	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in Flat File set of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Test Methods that should be present in every test @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    
private static DBUtils objDBUtility;//Mandatory declaration 
private static String filePAth ;//Mandatory
private static String fileNAme;//Mandatory
private static String[] FileNameSplit;
//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) {
		Object[][] data = null;
		Map<String, String> dataMap = new HashMap<String, String>();

		dataMap = ExcelUtils.getTestMethodData(method.getName());
		data = new Object[][] { { dataMap } };
		return data;
	}

	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
}

