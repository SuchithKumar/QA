package com.bsc.qa.facets.tests;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.bsc.qa.facets.ffpojo.readers.BscAccumsToDBPSHDWReader;
import com.bsc.qa.facets.ffpojo.utility.DBUtils;
import com.bsc.qa.facets.ffpojo.utility.ExcelUtils;
import com.bsc.qa.facets.ffpojo.utility.TestFileUtil;
import com.relevantcodes.extentreports.LogStatus;

public class BscaAccumToDBPSHDWTest extends BaseTest implements IHookable{
	
	//private static String strSUBSCRIBER_NUMBER;  
    private static int bodyRowsCount;
    //private static String strRELATIONSHIP_CODE;
    
    final private static String strUniqueIdentifier1= "SUBSCRIBER_NUMBER";    
    final private static String strUniqueIdentifier2 = "RELATIONSHIP_CODE";  
 //   final private static String strUniqueIdentifier3 = "BENEFIT_LEVEL";  
    
    private static BscAccumsToDBPSHDWReader ffpExtract;
    
	private static List<Map<String, String>> testHeader;
	private static List<Map<String, String>> testBody;
	private static List<Map<String, String>> testTrailer;
    
	@BeforeClass
	@Parameters({"NameOfTestDataSheet","TestDataSheetLocation","DB_Name","DB_User","DB_Pwd","DB_Server","DB_Port","RootLocationOfFlatFiles", "FileSpecificFolderName"}) //Note parrams order
	public void setUpTest(String NameOfTestDataSheet, String TestDataSheetLocation, String DB_Name, String DB_User, String DB_Pwd , String DB_Server, String DB_Port, String RootLocationOfFlatFiles, String FileSpecificFolderName){	//Args order matters should match to params order
        
		System.out.println("LOADING DATA SHEET::::>> " + NameOfTestDataSheet);
        
		if (NameOfTestDataSheet == null || "".equals(NameOfTestDataSheet)) {
			NameOfTestDataSheet = "Sheet1";
		}
		
		// Functional call to initialize cache from data sheet 
		ExcelUtils.initCache(TestDataSheetLocation, NameOfTestDataSheet);
	 	
		//NOTE DB UTIL OBJECT CREATION! 
		 objDBUtility = new DBUtils(DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port); //<== DB_Name, DB_User, DB_Pwd, DB_Server, DB_Port Args are required ! 
		 
		 TestFileUtil tesFile = new TestFileUtil(RootLocationOfFlatFiles, FileSpecificFolderName); //second folder is file location folder 
		 
		 filePAth = tesFile.getCompleteTestFilePath()[0];
		 fileNAme = tesFile.getCompleteTestFilePath()[1];	  
		 
		 //read flat file before test 
		  ffpExtract = new BscAccumsToDBPSHDWReader(filePAth);
		 
			//Parse headers and store in to testHeaders
			try {
				testHeader = ffpExtract.getListOfHeaderValues();
			
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			//Parse headers and store in to testHeaders
			try {
				testBody = ffpExtract.getListOfBodyValues(); // array list of hash map values 
				
				bodyRowsCount = testBody.size(); // body rows count
				
				// check with serhiy... no need of below lie. header doesn't requirer unique id . there will always be only one header line
				
				
				//please note the index zero. Assumption is made here that body of contained single row of data. 
				//String strSubscriber_ID = testBody.get(0).get(strUniqueIdentifier1); // <== Unique ID will vary from file to file
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			
			//Parse headers and store in to testHeaders
			try {
				testTrailer = ffpExtract.getListOfTrailerValues();
				
			} catch (IOException e) {
				System.out.println("BAD PARSING REQUEST");
				e.printStackTrace();
			}
			
			
		 
	}
	

	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@HEADER TEST METHODS
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderIndicator(Map<String, String> data) {

		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
	    
		String SQLQuery = data.get("SQLHeaderIndicator").toString();

	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    	  logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
				//System.out.println("Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
	    	  System.out.println("Acctual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here
				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderClientName(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
	    String SQLQuery = data.get("SqlClientName").toString();

	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, null, null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0);
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    	  logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
	    	  System.out.println("Acctual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here

				
	}
	
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testHeaderFileDate(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
	    String SQLQuery = data.get("SqlFileDate").toString();

	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testHeader.get(0); //<== Index one 
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    	  logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
	    	  System.out.println("Acctual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here 	
	     				
	}
	
	
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@BODY TEST METHODS
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyDetailIndicator(Map<String, String> data) {

		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
	    
		String SQLQuery = data.get("SQLDetailIndicator").toString();

	    // run sql query 
	    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
	    
	    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
		String[] strRecordSet = ArrayResult[0].split("#"); 
		
		//get records colmn name to string 
		String expectedFieldName = strRecordSet[0].trim(); 
		
		//get records expected value to string
		String expectedValue = strRecordSet[1];
		
		// get HashMap of header values form flat file
		Map<String, String> flatFileValuesMap = testBody.get(0);
		
	    // Test if DB Key exists in FF ste of Keys 
	     if (flatFileValuesMap.containsKey(expectedFieldName)) {
	        //compare values	 
	    	  softAssertion.assertEquals((flatFileValuesMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
	    	  logger.log(LogStatus.INFO, " Actual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
	    	  System.out.println("Acctual Value: " + (flatFileValuesMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
	    			        
	    	} else {
	    	   //key does not exists report failure 
	    	  softAssertion.assertTrue(flatFileValuesMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
	    		
	    	}
        
	     softAssertion.assertAll();	//<== absolutely must be here
				
	}
	
		
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyGroupId(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		String SQLQuery = data.get("SqlGroupId").toString();
			    
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
	    	    	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, FlatFileMap.get(strUniqueIdentifier1), FlatFileMap.get(strUniqueIdentifier2));	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
			
			
	
			
		    // Test if DB Key exists in FF ste of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
		
	@Test(dataProvider = "masterDataProvider")
	private static void testBodySubscriberNum(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		String SQLQuery = data.get("SqlSUBSCRIBER_NUMBER").toString();
		    
	    for (Map<String, String> FlatFileMap : testBody) {
	    	
	    	String UniqueIdentifier1 = FlatFileMap.get(strUniqueIdentifier1);
	    	String UniqueIdentifier2 = FlatFileMap.get(strUniqueIdentifier2);
    	
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, UniqueIdentifier1, UniqueIdentifier2);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in FF ste of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
	
	@Test(dataProvider = "masterDataProvider")
	private static void testBodyMemberDOB(Map<String, String> data) {
		
		String[] ArrayResult;
		SoftAssert softAssertion= new SoftAssert();
		String SQLQuery = data.get("sqlDOB").toString();

	    for (Map<String, String> FlatFileMap : testBody) {
	      
	    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
	    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
		    // run sql query 
		    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);	
		    
		    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
			String[] strRecordSet = ArrayResult[0].split("#"); 
			
			//get records colmn name to string 
			String expectedFieldName = strRecordSet[0].trim(); 
			
			//get records expected value to string
			String expectedValue = strRecordSet[1];
	
			
		    // Test if DB Key exists in FF ste of Keys 
		     if (FlatFileMap.containsKey(expectedFieldName)) {
		        //compare values	 
		    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
		    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
		    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
		    			        
		    	} else {
		    	   //key does not exists report failure 
		    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
		    		
		    	}	
	    	
	    }
	     softAssertion.assertAll();	//<== absolutely must be here     
	     				
	}
	
		
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyRelationshipCode(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlRelationshipCode").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     //softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyMemberIdentifyNum(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlMEm_Ident_Num").toString();
			    
		    for (Map<String, String> FlatFileMap : testBody) {
		    	
		    	String UniqueIdentifier1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String UniqueIdentifier2 = FlatFileMap.get(strUniqueIdentifier2);
	    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery, UniqueIdentifier1, UniqueIdentifier2);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
			
		
	
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyMemberLastName(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlMemberLastName").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);	
			    
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyMemberFirstName(Map<String, String> data) {  
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlMemberFirstName").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);	
			    
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyGender(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlGender").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     //softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyBenefitLevel(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlBenefitLevel").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyPlanCode(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlPlanCode").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);	
			    
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodySHDWAccumType(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlSHDWAccumType").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodySHDWAccumAmount(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlSHDWAccumAmount").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
		    	//String strUniqueIdValue3 = FlatFileMap.get(strUniqueIdentifier3);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyBenefitYear(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlBenefitYear").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	String strUniqueIdValue1 = FlatFileMap.get(strUniqueIdentifier1);
		    	String strUniqueIdValue2 = FlatFileMap.get(strUniqueIdentifier2);
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,strUniqueIdValue1,strUniqueIdValue2);
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		
		
		@Test(dataProvider = "masterDataProvider")
		private static void testBodyFiller(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlBodyFiller").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	//String strUniqueIdValue = FlatFileMap.get(strUniqueIdentifier);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     //softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		
		///@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Trailer Methods
		
		@Test(dataProvider = "masterDataProvider")
		private static void testTrailerIndicator(Map<String, String> data) {
			
			String[] ArrayResult;
			SoftAssert softAssertion= new SoftAssert();
			String SQLQuery = data.get("SqlTrailerIdicator").toString();
		    
		    
		    for (Map<String, String> FlatFileMap : testBody) {
		      
		    	//String strUniqueIdValue = FlatFileMap.get(strUniqueIdentifier);
		    	
			    // run sql query 
			    ArrayResult = (String[]) objDBUtility.getDelimitedArrayFromDB(SQLQuery,null,null);	
			    
			    //get result set to array. Please note hardcoded index of array. Agreement is to create queries that return sing set of expected data. Rest will be ignored. 
				String[] strRecordSet = ArrayResult[0].split("#"); 
				
				//get records colmn name to string 
				String expectedFieldName = strRecordSet[0].trim(); 
				
				//get records expected value to string
				String expectedValue = strRecordSet[1];
		
				
			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			        //compare values	 
			    	  softAssertion.assertEquals((FlatFileMap.get(expectedFieldName).toString()).trim(), (expectedValue).trim(), "<<" + expectedFieldName + ">> " );
			    	  logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + expectedValue.trim());
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() + " Expected Value: " + expectedValue.trim());
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }
		     //softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
		
		@Test(dataProvider = "masterDataProvider")
		private static void testTrailerTotalRecords(Map<String, String> data) {
	
			SoftAssert softAssertion= new SoftAssert();

		    for (Map<String, String> FlatFileMap : testTrailer) {

				//get records colmn name to string 
				String expectedFieldName = "TOTAL_RECORDS" ;// strRecordSet[0].trim(); 

			    // Test if DB Key exists in FF ste of Keys 
			     if (FlatFileMap.containsKey(expectedFieldName)) {
			    	 
		        	String actualValue = FlatFileMap.get(expectedFieldName).toString().trim();
		        		
		        		//testing the lenth of TOTAL_RECORDS field
		        		softAssertion.assertEquals(actualValue.length() , 30, " Expected lenth of TOTAL_RECORDS is 9 chars long ");
		        		
		        		//remove zeros from 000000005 to 5
		        		 actualValue = actualValue.replaceFirst("^0+(?!$)", "");
		        		 
		        		 //note the conversion of integer value 
		        		 
		        		 softAssertion.assertEquals(actualValue.trim(), (String.valueOf(bodyRowsCount )).trim(), " Expected Value: " + bodyRowsCount );//Anjali added + 1 to body rows for getting no: of records in trailer 
		        		 logger.log(LogStatus.INFO, " Actual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim() +" Expected Value: " + bodyRowsCount);
			    	  System.out.println("Acctual Value: " + (FlatFileMap.get(expectedFieldName).toString()).trim()  );
			    			        
			    	} else {
			    	   //key does not exists report failure 
			    	  softAssertion.assertTrue(FlatFileMap.containsKey(expectedFieldName), "Expected Body Element " + expectedFieldName + " is Required" );
			    		
			    	}	
		    	
		    }   
		    
		    softAssertion.assertAll();	//<== absolutely must be here     
		     				
		}
	
	
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Trailer TEST METHODS
	


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Test Methods that should be present in every test @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'loadExcelSheetData', 	'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    
private static DBUtils objDBUtility;//Mandatory declaration 
private static String filePAth ;//Mandatory 
private static String fileNAme;//Mandatory

//SoftAssert - collects errors during @Test (no exception is thrown) and if you call org.testng.asserts.SoftAssert#assertAll at the end of @Test exception is thrown if there was any and test suite again continue with next @Test
//private static SoftAssert softAssertion= new SoftAssert();

     /**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {	
		reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO,"Starting test "+testResult.getName());
		callBack.runTestMethod(testResult);	
		softAssert.assertAll();				
	}	
	
	@DataProvider(name = "masterDataProvider") // NOTE the dataProvider anotation
	private static Object[][] getData(Method method) {
		Object[][] data = null;
		Map<String, String> dataMap = new HashMap<String, String>();

		dataMap = ExcelUtils.getTestMethodData(method.getName());
		data = new Object[][] { { dataMap } };
		return data;
	}

	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2 Mandatory methods Required: 'run', 'getData'//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
}