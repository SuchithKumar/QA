package com.bsc.qa.facets.ffpojo.utility;

/**
 * Serhiy Malyy 
 * Class allows to locate most recent file in folder by last date/time modified
 * It enables file-based test to run and select files under test from folder and eliminates the need to hardcode file name
 * 
 */

import java.io.File;
import java.io.FileFilter;

public class TestFileUtil {

	String FlatFileRootDirectory;
	String InterfaceSpecoficFolder; 
	
	
	public TestFileUtil(String flatFileRootDirectory,String interfaceSpecoficFolder) {
		
		FlatFileRootDirectory = flatFileRootDirectory;
		InterfaceSpecoficFolder = interfaceSpecoficFolder;
	}

	public static File lastFileModified(String dir) {
	    File fl = new File(dir);
	    File[] files = fl.listFiles(new FileFilter() {          
	        public boolean accept(File file) {
	            return file.isFile();
	        }
	    });
	    long lastMod = Long.MIN_VALUE;
	    File choice = null;
	    for (File file : files) {
	        if (file.lastModified() > lastMod) {
	            choice = file;
	            lastMod = file.lastModified();
	        }
	    }
	    return choice; //lastFileModified
	}
	
	public File getTestFile(){
		
		String completePath = null; 
		
		// determine if test file location is part of project source folder stracture
		if (FlatFileRootDirectory.contains("src/")) {
			
			completePath = FlatFileRootDirectory + "/" + InterfaceSpecoficFolder;
			
		}else{ // if test files located in some network or other folders stracture
			
			completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		}
		
		System.out.println("Test file root directory is:" + FlatFileRootDirectory);
		System.out.println("Test file spefic directory is:" + InterfaceSpecoficFolder);
		
		File objFile = lastFileModified (completePath);
		
		return objFile;
	
	}
	
	public String[] getCompleteTestFilePath(){
		
		//String completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		
		String completePath = null; 
		
		// determine if test file location is part of project source folder stracture
		if (FlatFileRootDirectory.contains("src/")) {
			
			completePath = FlatFileRootDirectory + "/" + InterfaceSpecoficFolder;
			
		}else{ // if test files located in some network or other folders stracture
			
			completePath = FlatFileRootDirectory + "\\" + InterfaceSpecoficFolder;
		}
		System.out.println("----------------------Test Folder Info -------------------------------------");
		System.out.println(" ");
		System.out.println("Complete folder path of test file is: "+ completePath);
		System.out.println(" ");
		System.out.println("----------------------Test Folder Info -------------------------------------");
		
		File objFile = lastFileModified (completePath);
		String FileName = objFile.getName();
		String obsPath = objFile.getAbsolutePath();	
		
		System.out.println("Checking File Extension.....  ");
		System.out.println(" ");
		
		//final check for file extention FFPOJO will work with text files only 
		if (obsPath.toUpperCase().endsWith(".TXT")){
		
		System.out.println("Test File Extension is Confirmed ");
		
		System.out.println(" ");
		System.out.println("----------------------Test File Info -------------------------------------");
		System.out.println(" ");
		System.out.println("Complete path of test file is: "+ obsPath);
		System.out.println(" ");
		System.out.println("----------------------Test File Info -------------------------------------");
		System.out.println(" ");
		
		} else{
		
		System.out.println(" ");
		
		System.out.println("---------------------- WARNING BAD TEST FILE INFO -------------------------------------");
		System.out.println("---------------------- WARNING BAD TEST FILE INFO -------------------------------------");
		System.out.println("---------------------- WARNING BAD TEST FILE INFO -------------------------------------");
		System.out.println("-------------  Cannot Confirm Test File Extension. Your Test May Fail   --------------");
		System.out.println("Please review your test file path or check folder for missing test file :"+ obsPath);	
		System.out.println("---------------------- WARNING BAD TEST FILE INFO -------------------------------------");
		System.out.println("---------------------- WARNING BAD TEST FILE INFO -------------------------------------");
		System.out.println("---------------------- WARNING BAD TEST FILE INFO -------------------------------------");
		System.out.println(" ");

			
		}
		
		return new String[] {obsPath, FileName};
		
	
	}

}
