package com.bsc.qa.webservices.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;

import org.testng.Assert;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.bsc.qa.webservices.utility.Edi837Utility;
import com.relevantcodes.extentreports.LogStatus;

public class BscaFEPTest extends BaseTest implements IHookable {
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	
	public BscaFEPTest(String inputFileName) {
		this.inputFileName = inputFileName;
	}
	
	// ************************************** TEST
	// METHODS************************

	// Main test method to validate 837 file against FACETS database.
	@Test()
	private void test837FileValidation()  {
		SortedMap<String, SortedMap<String, String>> flatFileValuesMap = null;

		
		//Creating Edi837Utility class object
		Edi837Utility edi837Utility = new Edi837Utility();
		

		try {
			
			flatFileValuesMap = edi837Utility.get837FileData(
					 inputFileName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Retrieve's all primary keys into flatfilevaluemap
		Set<String> keys = flatFileValuesMap.keySet();
		
		
		String  inClauseStringBuilderstr = "";
        int intICounter = 0;
        List<String> strKeysList = new ArrayList<String>();
        
        //Loop used to get the subscribers data to pass it is input to the query
        for (String key : keys) {
            intICounter++;
            inClauseStringBuilderstr = inClauseStringBuilderstr + "'" + key + "',";
            //Storing 1000 subscribers data in a list variable
            if(intICounter >=1000){
                //Removing extra ',' at the end of the map
                inClauseStringBuilderstr = inClauseStringBuilderstr.substring(0, (inClauseStringBuilderstr.length()-1));
                //Adding the 1000 subscribers data to list
                strKeysList.add(inClauseStringBuilderstr);
                intICounter = 0;
                inClauseStringBuilderstr = "";
                            
            }
		
        //Storing last subscribers data which are less than 1000
            else if((intICounter < 1000) && (intICounter !=0)){
            //Removing extra ',' at the end of the map
            inClauseStringBuilderstr = inClauseStringBuilderstr.substring(0, (inClauseStringBuilderstr.length()-1));
            strKeysList.add(inClauseStringBuilderstr);
            inClauseStringBuilderstr = "";
		}
		
        }

		
		Map<String, String> data = null;
		try {
			data = getData("test837FileValidation");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String strQuery = "";
		
		
	
		try{
		//Loop used to get 1000 subscribers data and store the same in main SortedMap
        for(String strKeySet : strKeysList ){
        	
            //Creating where clause statement for each 1000 subscribers data
        	strQuery = strQuery + data.get("PRIMARY_KEY") + " in (" + strKeySet + ")" + " Or ";
	        
	       
     
        }

        strQuery = strQuery.substring(0, strQuery.length()-4).trim();
        SortedMap<String, SortedMap<String, String>> sql1Map = null;
        String strActualQuery = ""; 
       
      //Replaces 'in clause' string in the query with all subscriber ids in comma separated format
        sql1Map = new DBUtils().getResultSetAsSortedMap(
                         "facets", data.get("SQL_TEMPLATE") + "  " + strQuery.toString().toUpperCase(), data.get("PRIMARY_KEY"));
    	strActualQuery = data.get("SQL_TEMPLATE") + "  " + strQuery.toString().toUpperCase();
    	
    	strActualQuery=strActualQuery+data.get("CONDITION1");
        
        Set<String> primaryKeySet = flatFileValuesMap.keySet();
        //int intJCounter = 1;
        //SoftAssert softAssertion = new SoftAssert();
        
		//Below section will loop on each primaryKey in the "flatfilevaluemap"
		for (String primaryKey: primaryKeySet) {
			
			//capture single subscriber id from flatfilevaluemap
			SortedMap<String, String> rowMap = flatFileValuesMap.get(primaryKey);
			
			//To get the report for each subscriber in the XML
			//Parameters: to display report header in the HTML
			//if(intJCounter >= 1){
				reportInit("Test837FiletoXCDbValidations", ": Patient account Number:" +primaryKey);
				logger.log(LogStatus.INFO, "Starting  test837FileValidation ");
			
			//intJCounter++;
			logger.log(LogStatus.INFO, "File Path: " + inputFileName);
			
			logger.log(LogStatus.INFO, "Query used to fecth database data: " + strActualQuery );
			
			//logger.log(LogStatus.INFO, "Field Name: Actual | Expected");
			
			
			try{
					//Retrieving value from database for each of the keys				
					SortedMap<String,String> ClaimDetails = sql1Map.get(primaryKey);
					
					
					String Claimid=sql1Map.get(primaryKey).get("claim_id");
					
					if(Claimid.isEmpty())
					{
						logger.log(LogStatus.FAIL," This claim with patient Acc Number  (" + primaryKey + ") is NOT loaded into FACETS");
					}
					
					//Retrieving Claim Status
					String claimstatus=sql1Map.get(primaryKey).get("claim_status");
					
					
					boolean flag=claimstatus.equalsIgnoreCase("16");
					
					if(flag)
					{
						logger.log(LogStatus.PASS, "Claim:"+Claimid+" Status is 16");
					}else{
						logger.log(LogStatus.FAIL,"Claim:"+Claimid+" Status is not 16");
						
					}
					
					softAssert.assertEquals(claimstatus, "16", "Claim: "+Claimid+"Status is not as expected");
					
					//Below section will loop on each key in the flatfilevaluemap
					for (String columnKey : rowMap.keySet()) {
						
						//Retrieving value from flat file for each of the keys 
						String fileValue = rowMap.get(columnKey);
						String dbValue = "";
						//Retrieving value from database for each of the keys				
						dbValue = ClaimDetails.get(columnKey);
						
						
						//Comparing source and target values to report in the logger
						if(fileValue.equalsIgnoreCase(dbValue)){
							logger.log(LogStatus.PASS," << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
						}else{
							logger.log(LogStatus.FAIL, " << Field name: " + columnKey + " | Flat file value: " + fileValue + " | Database value: " + dbValue + " >>");
						}
						//System.out.println(columnKey + ": " + fileValue + " | " + dbValue);
						
						
						
						
						softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " not found");
					
						
					}
					
					
				
				}
//				//Reporting subscriber ID in HTML report when it is not loaded into FACETS
				catch(Exception e){
				logger.log(LogStatus.FAIL," This claim with patient Acc Number  (" + primaryKey + ") is NOT loaded into FACETS");
				//softAssert.assertEquals(fileValue, dbValue, primaryKey + ": " + columnKey + "=" + fileValue + " not found");
				
				softAssert.assertFalse(true, "This claim with patient Acc Number  (" + primaryKey + ") is NOT loaded into FACETS");
		}
			

			
		}
		}
		catch(Exception e){
			System.out.println("Test script Failed due to Exception.....!!");
			logger.log(LogStatus.FAIL, "Test script Failed due to Exception.....!!" + e.getMessage() );
			e.printStackTrace();
		}
		finally{
			softAssert.assertAll();	//<== absolutely must be here
		}
		
		
		
	}

		


	/**
	 * //To run test method, this method will initiate the HTML report
	 * 
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {

		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();

	}

	private Map<String, String> getData(String testMethodName) throws Exception {
		Map<String, String> dataMap = new HashMap<String, String>();
		// assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, testMethodName);

		return dataMap;

	}

}
