package com.bsc.qa.facets.ffpojo.utility;

import java.time.Month;
import java.util.List;
import java.util.Map;


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.ffpojo.factory.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import java.lang.Object;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;


public class OtherUtilities extends BaseTest{
	// Validating in bound file and FACETS database column values
	public static void validate(Map<String, String> flatFileValuesMap,	Map<String, String> queryDataMap,SoftAssert softAssertion) {
		//SoftAssert softAssertion= new SoftAssert();
		for(String key:queryDataMap.keySet()){			
			if (key.equalsIgnoreCase("ELECTRONICQ1")) {				
				flatFileValuesMap.put("ELECTRONICQ1".toUpperCase(), flatFileValuesMap.get("ELECTRONICCOMMUNICATIONQUESTION1"));
			}if (key.equalsIgnoreCase("ELECTRONICQ2")) {				
				flatFileValuesMap.put("ELECTRONICQ2".toUpperCase(), flatFileValuesMap.get("ELECTRONICCOMMUNICATIONQUESTION2"));
			}
			
			if(flatFileValuesMap.containsKey(key)){ 
				
				// Added this code based on the front end portal new requirement
				if(key.equalsIgnoreCase("MAILINGADDRESS1") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
					key = "ApplicantAddress1".toUpperCase();
				if(key.equalsIgnoreCase("MAILINGADDRESS2") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
					key = "ApplicantAddress2".toUpperCase();
				if(key.equalsIgnoreCase("ApplicantAddress3") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
					key = "ApplicantAddress3".toUpperCase();
				if(key.equalsIgnoreCase("MailingCity") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
					key = "ApplicantCity".toUpperCase();
				if(key.equalsIgnoreCase("MailingState") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
					key = "ApplicantState".toUpperCase();
				if(key.equalsIgnoreCase("MailingZip") && flatFileValuesMap.get("MAILINGADDRESS1").toString().trim().length()==0)
					key = "ApplicantZip".toUpperCase();
				
				
				
				OtherUtilities.validateActualAndExpectedValues(key,flatFileValuesMap.get(key),queryDataMap.get(key),softAssertion);
				//System.out.println(" Key Name: " + key + ", Acctual Value: " + flatFileValuesMap.get(key) + ", Expected Value: " + queryDataMap.get(key));
			}else{
				 softAssertion.assertTrue(flatFileValuesMap.containsKey(key), "Element " + key + " is not present" );
				 logger.log(LogStatus.INFO, key+" is not present Input File");
			}			
		}		
	}


	
	
	// Validating in bound file and FACETS database column values 
	private static void validateActualAndExpectedValues(String key,String flatFileValue,String dbValue,SoftAssert softAssertion) {
		String strFlatFileDate = "";
		String strdbValue = "";
		String strflatFileValue = "";
		flatFileValue = flatFileValue.trim();		
		if(dbValue != null )	{
		dbValue = dbValue.trim();
		}
		if(dbValue == null)
			dbValue = "";
		switch (key){
			//	Validating APPLICANTBIRTHDATE field value in In bound file and FACETS Database
			case "MEMBERBIRTHDATE":
				String strDate;
				if(flatFileValue != null && flatFileValue.length()>0){
					strDate = flatFileValue.substring(4) + "-"+flatFileValue.substring(0, 2) + "-"+ flatFileValue.substring(2, 4);
				}else{
					strDate = flatFileValue;
				}
				assertContainLogger(key, strDate, dbValue, softAssertion);
				//softAssertion.assertTrue(dbValue.contains(strDate), " << Field name: " + key + " | Flat file value: " + strDate + " | Database value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strDate+ "---------------Database Value: " + dbValue));
				break;
			//Validating OEC_InsertedWhen,SubmitDate field values in In bound file and FACETS Database
			case "OEC_INSERTEDWHEN":
			case "SUBMITDATE":
				if(dbValue != null && dbValue.length()>0){
					strdbValue = dbValue.substring(5,7) + dbValue.substring(8,10) + dbValue.substring(0,4); 
				}
				assertEqualLogger(key, flatFileValue, strdbValue, softAssertion);
				//softAssertion.assertEquals(flatFileValue,strdbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + strdbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + strdbValue));
				break;
			//Validating MedicarePartA,MedicarePartA field values in In bound file and FACETS Database
			case "MEDICAREPARTA":
			case "MEDICAREPARTB":
				if(flatFileValue != null && flatFileValue.length()>0){
					strFlatFileDate = "01-" + (Month.of(Integer.parseInt(flatFileValue.substring(0,2))).name().substring(0,3)) + "-"+ flatFileValue.substring(4);
				}
				if(dbValue != null && dbValue.length()>0){
					strdbValue = dbValue.substring(8,10) + "-" + (Month.of(Integer.parseInt(dbValue.substring(5,7))).name().substring(0,3)) + "-"+ dbValue.substring(2,4);
				}
				assertEqualLogger(key, strFlatFileDate, strdbValue, softAssertion);
				break;
			//Validating SubmitTime field value in In bound file and FACETS Database				
			case "SUBMITTIME":
				/*if(flatFileValue != null && flatFileValue.length()>0)
				strFlatFileDate = flatFileValue.substring(0,19);
				if(dbValue != null && dbValue.length()>0)
				strdbValue = dbValue.substring(0,19) ;*/
				
				/*if(flatFileValue != null && flatFileValue.length()>0)
					
		
				softAssertion.assertEquals(strFlatFileDate,strdbValue, " << Field name: " + key + " | Flat file value: " + strFlatFileDate + " | Database value: " + strdbValue + " >>");
				logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strFlatFileDate+ "---------------Database Value: " + strdbValue));*/
				break;
			case "SUBSIDYPERCENTAGE":
				break;
			
			//Validating AgencyID field value in In bound file and FACETS Database				
			case "AGENCYID":
				if(flatFileValue != null && flatFileValue.length()>0){
					strflatFileValue = flatFileValue.replaceAll("[^a-zA-Z0-9]","");
				}
				assertEqualLogger(key, strflatFileValue, dbValue, softAssertion);
				//softAssertion.assertEquals(strflatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + strflatFileValue + " | Database value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strflatFileValue+ "---------------Database Value: " + dbValue));
				break;
			//Validating ApplicantSSN field value in In bound file and FACETS Database				
			case "APPLICANTSSN":
				if(flatFileValue != null && flatFileValue.length()>0)
				strflatFileValue = flatFileValue.replaceAll("[^a-zA-Z0-9]","");
				assertEqualLogger(key, strflatFileValue, dbValue, softAssertion);
				//softAssertion.assertEquals(strflatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + strflatFileValue + " | Database value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(strflatFileValue+ "---------------Database Value: " + dbValue));
				break;
			//Validating PremiumWithhold field value in In bound file and FACETS Database	
			case "PREMIUMWITHHOLD":
				if (flatFileValue.equalsIgnoreCase(dbValue)){
					assertEqualLogger(key, flatFileValue, dbValue, softAssertion);
					//softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
					//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
				}else if (flatFileValue.equalsIgnoreCase("")){
					logger.log(LogStatus.PASS," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value:  "));
				}else{
					assertFailLogger(key, flatFileValue, dbValue, softAssertion);
					//softAssertion.assertTrue(false, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");			
					//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
				}
				break;
				//Validating PRIMARYCAREPHYSICIAN field value in In bound file and FACETS Database	
			case "PRIMARYCAREPHYSICIAN":
				if (flatFileValue.contains(","))
					flatFileValue = flatFileValue.replace(",", "");
				if (flatFileValue.contains("."))
					flatFileValue = flatFileValue.replace(".", "");
				if (dbValue.contains(","))
					dbValue = dbValue.replace(",", "");
				if (dbValue.contains("."))
					dbValue = dbValue.replace(".", "");
				assertContainLogger(key, flatFileValue, dbValue, softAssertion);
				//softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");			
				//logger.log(LogStatus.INFO," Key Name: " + key + " Inbound File Value: " +(flatFileValue+ "---------------Database Value: " + dbValue));
			
				break;
			default:
				// Changing flat file value to "Y" instead of "Yes"
				if (flatFileValue!= null && flatFileValue.equalsIgnoreCase("Yes") ) {			
					flatFileValue="Y";			
				}			
				// Changing flat file value to "N" instead of "No"
				else if (flatFileValue!= null && flatFileValue.equalsIgnoreCase("No")) {		
					flatFileValue="N";
				}
				// Added this code based on the front end portal new requirement
				if(dbValue.equalsIgnoreCase("N") && flatFileValue.equalsIgnoreCase("")){
					dbValue="";
				}
				
				assertEqualLogger(key, flatFileValue, dbValue, softAssertion);
				//softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
				//logger.log(LogStatus.INFO, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
				break;
				
				
		}
	
	}

	
	
	public static void assertEqualLogger(String key, String flatFileValue, String dbValue,SoftAssert softAssertion ){
		
		softAssertion.assertEquals(flatFileValue,dbValue, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(flatFileValue.equalsIgnoreCase(dbValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		}
	}
	
	public static void assertContainLogger(String key, String flatFileValue, String dbValue,SoftAssert softAssertion ){
		
		softAssertion.assertTrue(dbValue.contains(flatFileValue), " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		if(dbValue.contains(flatFileValue)){
			logger.log(LogStatus.PASS," << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		}else{
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		}
	}
	
	public static void assertFailLogger(String key, String flatFileValue, String dbValue, SoftAssert softAssertion ){
		
		softAssertion.assertTrue(false, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
		
			logger.log(LogStatus.FAIL, " << Field name: " + key + " | Flat file value: " + flatFileValue + " | Database value: " + dbValue + " >>");
	}

//To print the test case details in the logger
	public static void printTestCaseDeatilsInReport(Map<String, String> data) {		
		
		String strSUCName= data.get("SUC Name").toString();		
		String strTestCaseId = data.get("Test Case ID").toString();		
		String strTestCaseName = data.get("Test Case Name").toString();		
		String strStepNumber = data.get("Step Number").toString();
		//String strInputFileName = data.get("Input File Name").toString();
		logger.log(LogStatus.INFO," SUC Name: " + strSUCName + ", Test Case ID: " + strTestCaseId + ", Test Case Name: " + strTestCaseName + ", Step Number:" + strStepNumber);
		//logger.log(LogStatus.INFO," Input File Name: " + strInputFileName);
	}
	


	
	
	//below method is to check whether the given number is numeric or not
		public static boolean isNumeric(String str) {
		    int size = str.length();
		    for (int i = 0; i < size; i++) {
		        if (!Character.isDigit(str.charAt(i))) {
		            return false;
		        }
		    }

		    return size > 0;
		} 

}
