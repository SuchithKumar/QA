package com.bsc.qa.facets.tests;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.text.StrSubstitutor;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bsc.qa.facets.utility.ExcelUtilsExtended;
import com.bsc.qa.facets.utility.XMLParse;
import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.relevantcodes.extentreports.LogStatus;

public class BscaITSTest extends BaseTest implements IHookable {
	
	private String inputFileName = null;
	private SoftAssert softAssert = null;
	private XMLParse xMLParse = null;
	
	public BscaITSTest(String inputFileName) {
		this.inputFileName = inputFileName;
	}
	
	
	//To validate XML fields with database values for 835 xmls
	@Test()
	
	private void test835XMLToDBValidation() {

		try {
			xMLParse = new XMLParse();
			//For fetching test data from test data excel file 
			Map<String, String> data = null;
			try {
				data = getData("test835XMLToDBValidation");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//to retrieve parent tag from test data sheet
			String xmlTag = data.get("ELEMENT_TAG_NAME").toString().trim();
			//to retrieve file path from environment variable
			//String xmlFilePath = inputFileName;
			/*File dirfolder=new File(System.getenv("OUTPUT_835_XML_PATH"));
			File[] xmlfiles=dirfolder.listFiles();
			for(File file:xmlfiles){
				
				System.out.println("&&&&&&&&&&&&&&& "+file.getPath());
				String xmlFilePath =file.getPath();	*/
			//For the initial XML setup
			xMLParse.xmlSetup(inputFileName);
			//assigning mapping sheet name in test data sheet to local variable
			String mappingSheetName = "Mappingsheet_IDcard";
			//To fetch all subscribers from XML, multiple subscriber data will be retrieved with pipe (|) delimiter
			String strClaimIDList = xMLParse.UniqueDetailsExtraction(xmlTag,"THG835X2_2100_CLP07__PayerClaimControlNumber");
			System.out.println(strClaimIDList);
			//testdbvalues_IDcard(strClaimIDList);
			//Verifying valid subscribers details from XML
			if(!strClaimIDList.equalsIgnoreCase("")) {
				
				String [] strClaimIDArray = strClaimIDList.split("\\|");
				//Iterating for a ll subscribers to validate XML versus Database values
				System.out.println(strClaimIDArray.length);
				
				for(int intICounter = 1; intICounter< strClaimIDArray.length ; intICounter++){
					//To skip the first report which is initialized in the run method
			//		if(intICounter > 1 )
					
						
						//To get the report for each subscriber in the XML
						//Parameters: to display report header in the HTML						
						reportInit("835XmlToDbValidation", "Claim ID:" + strClaimIDArray[intICounter]);
						logger.log(LogStatus.INFO, "Starting test : test835XMLToDBValidation");
						
					
					//To log the XML file path in HTML report
					logger.log(LogStatus.INFO, "XML file path: " + inputFileName);
					//To log the subscriber details in HTML report
					logger.log(LogStatus.INFO, "Validating Claim ID: " + strClaimIDArray[intICounter]);
					System.out.println("Validating Claim ID: " + strClaimIDArray[intICounter]);
					//validating specific subscribers data, this is the main method for validating ID Cards
					xMLParse.nodeExtraction(xmlTag, mappingSheetName, strClaimIDArray[intICounter], softAssert);
					
				}
				
			}
			
			//To report the statement when file does not have subscribers
			else {
				logger.log(LogStatus.FAIL, "Please provide valid file name and inputs to fetch claim data") ;
			}
			//testdbvalues_IDcard(strClaimIDList);

		//} 
		}
		catch (Exception e)	{
			System.out.println("Test script Failed due to Exception.....!!");
			logger.log(LogStatus.FAIL, "Test script Failed due to Exception.....!!" + e.getMessage() );
			e.printStackTrace();
		}finally{
			softAssert.assertAll();	//<== absolutely must be here
		}

	}

	/**
	 * //To run test method, this method will initiate the HTML report
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		//reportInit(testResult.getTestContext().getName(), testResult.getName());
		softAssert = new SoftAssert();
		//logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		//To execute test method multiple times
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
	}

	/**
	 * DataProvider for returning the specific test data based on test method
	 * name
	 * 
	 * @param String: Method name
	 * @return
	 */

	private Map<String,String> getData(String method) throws Exception{
		Map<String, String> dataMap = new HashMap<String, String>();
		//assigning test data excel file path to a local variable
		String xlsPath = "src/test/resources/"
				+ this.getClass().getSimpleName() + ".xlsx";
		//Fetching data from test data excel file based on method name
		dataMap = ExcelUtils.getTestMethodData(xlsPath, method);
		
		return dataMap;
	}

}
