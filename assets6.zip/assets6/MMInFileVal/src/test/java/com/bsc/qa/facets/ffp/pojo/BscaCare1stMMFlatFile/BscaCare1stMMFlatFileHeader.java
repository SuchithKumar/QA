package com.bsc.qa.facets.ffp.pojo.BscaCare1stMMFlatFile;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord(ignorePositionNotFound=true) // <== ABSOLUTLEY MUST BE HERE
public class BscaCare1stMMFlatFileHeader {

	private String Record_Type_Header;
	private String Contract_Number_Header;
	private String Payment_Date;
	
	
	
	
	public String getRecord_Type_Header() {
		return Record_Type_Header;
	}
	public void setRecord_Type_Header(String record_Type_Header) {
		Record_Type_Header = record_Type_Header;
	}
	public String getContract_Number_Header() {
		return Contract_Number_Header;
	}
	public void setContract_Number_Header(String contract_Number_Header) {
		Contract_Number_Header = contract_Number_Header;
	}
	public String getPayment_Date() {
		return Payment_Date;
	}
	public void setPayment_Date(String payment_Date) {
		Payment_Date = payment_Date;
	}
	
	
}
