package com.bsc.qa.web.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class AuthAccelMemberPage extends BasePage {

	WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='subscriberId']") })
	WebElement memberId;

	@FindAll({ @FindBy(how = How.NAME, using = "dateOfBirth_dateTextField") })
	WebElement dateOfBirth;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']") })
	List<WebElement> buttonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_')]/following::table[@class='listTable']/tbody/tr") })
	List<WebElement> memberType;
	
	

	@FindAll({ @FindBy(how = How.XPATH, using = "//table/tbody/tr/td/div/div[text()='HICN']") })
	WebElement LOB;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_MemberSearchForm_')]/following::table/tbody/tr/td[6]/div/nobr") })
	List<WebElement> lobname;

	public void searchMembers(String memberid, String buttonName,
			WebDriver driver, ExtentTest logger) throws InterruptedException {

		logger.log(LogStatus.INFO, "Search for member with member Id!!");

		memberId = webUtils.explicitWaitByVisibilityofElement(driver, memberId);
		logger.log(LogStatus.INFO, "Enter member id!!");
		memberId.sendKeys(memberid);
		logger.log(LogStatus.INFO, "Click on search!!");

		webUtils.clickButtonOrLink(buttonList, buttonName, logger, driver);

		logger.log(LogStatus.INFO, "Select subscriber member!!");
		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//div[contains(@id,'isc_MemberSearchForm_')]/following::table/tbody/tr");

		for (WebElement membertype : memberType) {

			webUtils.horizontalScroll(driver, LOB);
			
			

			if ((membertype.getText().trim().contains("Subscriber")
					&& !membertype.getCssValue("color").trim().equalsIgnoreCase(
							"rgba(214, 73, 73, 1)") && membertype.getText().trim()
					.contains("MEDI.CAL")||membertype.getText().trim()
					.contains("MAPD.IND"))
					 ) {

				membertype.click();

				webUtils.doubleClick(driver, membertype);

				break;
			}
			else if((membertype.getText().trim().contains("Subscriber")
					&& !membertype.getCssValue("color").trim()
					.equalsIgnoreCase("rgba(214, 73, 73, 1)") && membertype
			.getText().trim().contains("CA.CCI"))){
				
				membertype.click();

				webUtils.doubleClick(driver, membertype);

				break;
				
			}
			
			else{
				
				System.out.println("In else ");
			}
		}
		
	}

}
