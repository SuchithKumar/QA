package com.bsc.qa.web.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class AuthAccelHomePage extends BasePage {

	WebUtils webUtils = new WebUtils();
	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='isc_20']") })
	WebElement dropDown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@role='presentation']") })
	List<WebElement> dropDownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[@role='listitem']/td/div/nobr[text()='Pharmacy']") })
	WebElement pharmacy;

	@FindAll({ @FindBy(how = How.XPATH, using = "//*[@id='isc_12']/table/tbody/tr/td/table/tbody/tr/td[2]") })
	WebElement search;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[@role='menuitem']/td[2]/div") })
	List<WebElement> searchList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_PortletWorkspace_1']/div[contains(@eventproxy,'isc_HLayout_')]/div/div[1]") })
	WebElement myFax;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PortletWorkspace_4_2')]/following::div[contains(@eventproxy,'isc_PortletLink_1_3')]/div") })
	WebElement unassignedTasks;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid')]/div/div/div[3]") })
	List<WebElement> assignedReceivedDateList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid')]/div/div/div[3]") })
	WebElement unassignedReceivedDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//table[@class='menuTable']/tbody/tr[2]") })
	WebElement sortDescending;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_HLayout_')]/div/div/div/following::div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table[@class='listTable']/tbody/tr[1]") })
	WebElement unassignedTaskList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_HLayout_')]/div/div/div/following::div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table[@class='listTable']/tbody/tr") })
	List<WebElement> listSize;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_HLayout_')]/div/div/div/following::div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table[@class='listTable']/tbody/tr[1]") })
	List<WebElement> assignedTaskList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//table[@class='menuTable']/tbody/tr[4]/td[2]/div/nobr[contains(text(),'Claim')]") })
	WebElement claim;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='formCell']") })
	List<WebElement> pageNo;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='currentPage']") })
	WebElement currentPage;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'action_last')]") })
	WebElement forwardButton;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'action_last')]") })
	List<WebElement> forwardButtonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_Toolbar_1')]/div/table/tbody/tr/td/div/div[text()='Received Date']") })
	WebElement recievedDatePharmacy;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_HLayout_')]/div/div/div/following::div[contains(@eventproxy,'isc_PagingListGrid_1_1_body')]/div/table[@class='listTable']/tbody/tr[1]") })
	WebElement pharmacytaskList;

	public void selectRole(String role, WebDriver driver,ExtentTest logger)
			throws InterruptedException {
		
		logger.log(LogStatus.INFO, "Select the type of role");
		
		dropDown = webUtils.explicitWaitByElementToBeClickable(driver, dropDown);
		
		dropDown.click();

		webUtils.clickButtonOrLink(dropDownList, role,logger,driver);

	}

	public void search(String role,ExtentTest logger,WebDriver driver) throws InterruptedException {
		
		logger.log(LogStatus.INFO, "Select the type of search!!");

		search.click();

		webUtils.clickButtonOrLink(searchList, role,logger,driver);

	}

	/**
	 * Select the task from unassigned task list
	 * @param driver
	 * @param logger
	 * @throws Exception
	 */
	public void taskSelection(WebDriver driver, ExtentTest logger)
			throws Exception {

		logger.log(LogStatus.INFO, "Select the task from unassigned tasks!!!");

		webUtils.doubleClick(driver, unassignedTasks);

		// webUtils.explicitWaitByVisibilityOfAllElements(driver, listSize);

		// Thread.sleep(3000);

		// System.out.println("The task list size is !!!"+listSize.size());

		/*
		 * webUtils.scrollDown(driver, pageNo.get(3));
		 * 
		 * Thread.sleep(5000);
		 */
		/*
		 * if (forwardButton.isDisplayed()) { forwardButton.click(); }
		 */

		webUtils.explicitWaitByElementToBeClickable(driver, unassignedTaskList);
		webUtils.moveToClickableElement(unassignedReceivedDate, driver);

		Thread.sleep(3000);

		webUtils.moveToClickableElement(unassignedReceivedDate, driver);

		/*
		 * unassignedTaskList = webUtils .explicitWaitByPresenceofElement(
		 * driver,
		 * "//div[contains(@eventproxy,'isc_HLayout_')]/div/div/div/following::div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table[@class='listTable']/tbody/tr[1]"
		 * );
		 */

		Thread.sleep(5000);

		/*
		 * webUtils.rightClick(driver, unassignedTaskList);
		 * 
		 * webUtils.moveToClickableElement(claim, driver);
		 * 
		 * Thread.sleep(3000);
		 * 
		 * webUtils.scrollUp(driver);
		 * 
		 * webUtils.moveToClickableElement(myFax, driver);
		 * 
		 * Thread.sleep(4000);
		 * 
		 * if (forwardButtonList.get(0).isDisplayed()) {
		 * 
		 * //webUtils.explicitWaitByElementToBeClickable(driver,
		 * forwardButtonList.get(0));
		 * 
		 * forwardButtonList.get(0).click(); }
		 * 
		 * webUtils.moveToClickableElement(assignedReceivedDateList.get(0),
		 * driver);
		 * 
		 * Thread.sleep(3000);
		 * 
		 * webUtils.moveToClickableElement(assignedTaskList.get(0), driver);
		 */

		webUtils.moveToClickableElement(unassignedTaskList, driver);
		webUtils.doubleClick(driver, unassignedTaskList);

		Thread.sleep(5000);
	}

	/**
	 * Edit the prior authorization request
	 * @param driver
	 * @param logger
	 * @throws Exception
	 */
	public void editPriorAuth(WebDriver driver, ExtentTest logger)
			throws Exception {

		logger.log(LogStatus.INFO,
				"Select the task to deny the case from pharmacy task list!!!");

		webUtils.explicitWaitByVisibilityofElement(driver, pharmacytaskList);

		webUtils.scrollDown(driver, pharmacytaskList);

		Thread.sleep(3000);

		webUtils.moveToClickableElement(recievedDatePharmacy, driver);

		webUtils.explicitWaitByVisibilityofElement(driver, pharmacytaskList);

		webUtils.moveToClickableElement(recievedDatePharmacy, driver);

		webUtils.explicitWaitByVisibilityofElement(driver, pharmacytaskList);

		pharmacytaskList.click();

		webUtils.doubleClick(driver, pharmacytaskList);

	}
}
