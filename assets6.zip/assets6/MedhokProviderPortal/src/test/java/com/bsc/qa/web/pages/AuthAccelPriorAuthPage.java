package com.bsc.qa.web.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.ExcelUtilities;
import WebUtils.WebUtils;

public class AuthAccelPriorAuthPage {

	WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(@class,'formTitle')]/b[contains(text(),'Request Type')]/following::div[contains(@class,'selectItemText')]") })
	List<WebElement> dropDownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_PickListMenu_0_body$28s')]/following::table/tbody/tr") })
	List<WebElement> dropdownNames;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='manualReceivedDate_dateTextField']") })
	WebElement manualReceivedDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='nextReviewDate_dateTextField']") })
	WebElement nextReviewDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_UmAuthShortIntake_22_0_body$28s')]/following::table[@class='listTable']/tbody/tr/td[1]") })
	List<WebElement> codeAreaList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_UmAuthShortIntake_71_0_body']/div/table/tbody/tr/td[2]") })
	WebElement codeAreaList1;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_UmAuthShortIntake_71_0_body']/div/table/tbody/tr/td[3]") })
	WebElement codeAreaList2;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_UmAuthShortIntake_71_0_body']/div/table/tbody/tr/td[4]") })
	WebElement codeAreaList3;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@eventproxy='isc_UmAuthShortIntake_71_0_body']/div/table/tbody/tr/td[5]") })
	WebElement codeAreaList4;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='formCell']/following::img[contains(@src,'search_picker')]") })
	List<WebElement> searchPicker;

	@FindAll({ @FindBy(how = How.NAME, using = "description") })
	WebElement description;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='description']/following::div[contains(text(),'Search')]") })
	WebElement search;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='description']/following::div[contains(text(),'Cancel')]") })
	WebElement cancel;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='description']/following::div[contains(text(),'Cancel')]/following::table[@class='listTable']/tbody/tr[1]") })
	WebElement codeSelect;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='ipfrom_dateTextField']") })
	WebElement fromdate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='ipthru_dateTextField']") })
	WebElement thru;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[contains(@eventproxy,'isc_DynamicForm_')]/table/tbody") })
	WebElement dropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='pickListCell']") })
	List<WebElement> bedTypeDropdownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr") })
	List<WebElement> commondropdownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='admissionDate_dateTextField']") })
	WebElement admissionDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='dischargeDate_dateTextField']") })
	WebElement dischargeDate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='orgname']") })
	WebElement organization;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']") })
	List<WebElement> buttonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ListGrid_4_body')]/div/table/tbody/tr[1]") })
	WebElement providerSearch;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='serviceProviderSame_id']") })
	List<WebElement> radioButtonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[contains(text(),'Submit')]") })
	WebElement submitButton;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[text()='Facility']") })
	WebElement facility;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div") })
	WebElement referenceNumber;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(text(),'CSC Follow Up')]") })
	WebElement statusReasonDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='Submit']") })
	WebElement submit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='requestingFax']") })
	WebElement fax;

	// input[@name='servicingFax']

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='servicingFax']") })
	WebElement servicingFax;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='facilityFax']") })
	WebElement facilityFax;

	@FindAll({ @FindBy(how = How.XPATH, using = "// div[contains(@eventproxy,'isc_globalWarn_closeButton')]/img[contains(@src,'close')]") })
	WebElement close;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(@class,'formTitle')]/b[contains(text(),'Source')]/following::td[1]") })
	WebElement source;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(@class,'formTitle')]/b[contains(text(),'Place of Service')]/following::td[1]") })
	WebElement placeOfService;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Place of Service')]/following::td[1]") })
	WebElement medicationPOS;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(@class,'formTitle')]/b[contains(text(),'Request Type')]/following::td[1]") })
	WebElement requestTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Requester')]/following::td[1]") })
	WebElement requesterTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Review Type')]/following::td[1]") })
	WebElement reviewTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Priority')]/following::td[1]") })
	WebElement PriorityDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td/b[contains(text(),'Admission BedType')]/following::td[1]") })
	WebElement admissionBedTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Service Category')]/following::td[1]") })
	WebElement serviceCategoryDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Sub Category')]/following::td[1]") })
	WebElement subCategoryDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td/b[contains(text(),'Inquiry Outcome')]/following::td[1]") })
	WebElement inquiryOutcomeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Outcome Reason')]/following::td[1]") })
	WebElement outcomeReasonDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td[contains(text(),'Admit From')]/following::td[1]") })
	WebElement admitFromDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = ".//td/b[contains(text(),'Admit Type')]/following::td[1]") })
	WebElement admitTypeDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr/td[text()='Enter valid Data']") })
	WebElement validDataPopUp;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'hsplit_snap')]") })
	WebElement hsplit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr/td[text()='The requested facility is out of service area']") })
	WebElement outOfService;

	public void eventIntake(String requestTypeName, String placeOfServiceName,
			String sourceName, String receivedDate, WebDriver driver,
			ExtentTest logger) throws Exception {

		logger.log(LogStatus.INFO, "Provide the details for Event Intake");
		webUtils.explicitWaitByVisibilityofElement(driver, requestTypeDropdown);

		logger.log(LogStatus.INFO, "Select the request type name!!");
		requestTypeDropdown.click();

		webUtils.clickButtonOrLink(dropdownNames, requestTypeName, logger,
				driver);
		logger.log(LogStatus.INFO, "Select the place of service");
		if (requestTypeName.equalsIgnoreCase("Medication")
				|| requestTypeName.equalsIgnoreCase("Service Post Review")
				|| requestTypeName.equalsIgnoreCase("Inpatient Post Review")) {
			webUtils.explicitWaitByElementToBeClickable(driver, medicationPOS);

			medicationPOS.click();
		} else if (requestTypeName.equalsIgnoreCase("Inpatient")
				|| requestTypeName
						.equalsIgnoreCase("Service Request (Prior Auth)")) {
			webUtils.explicitWaitByElementToBeClickable(driver, placeOfService);

			placeOfService.click();

		}

		Thread.sleep(5000);
		webUtils.clickButtonOrLink(dropdownNames, placeOfServiceName, logger,
				driver);

		logger.log(LogStatus.INFO, "Select the source!!");
		source.click();

		webUtils.clickButtonOrLink(dropdownNames, sourceName, logger, driver);

		logger.log(LogStatus.INFO,
				"Enter the manual received date and next reaview date!!");
		manualReceivedDate.sendKeys(receivedDate);

		// nextReviewDate.sendKeys(reviewDate);

	}

	public void addDiagnosisCodes(WebDriver driver, String diagnosisDesc,
			ExtentTest logger) throws Exception {

		logger.log(LogStatus.INFO, "Add diagnosis codes!!");

		webUtils.explicitWaitByPresenceofAllElements(
				driver,
				"//div[contains(@id,'isc_UmAuthShortIntake_22_0_body$28s')]/following::table[@class='listTable']/tbody/tr/td[1]");

		codeAreaList.get(0).click();

		webUtils.explicitWaitByVisibilityofElement(driver, searchPicker.get(2));

		searchPicker.get(2).click();

		description.sendKeys(diagnosisDesc);

		search.click();

		webUtils.explicitWaitByElementToBeClickable(driver, codeSelect);

		codeSelect.click();

		webUtils.doubleClick(driver, codeSelect);

	}

	public void addServiceCodes(String serviceDesc, WebDriver driver,
			ExtentTest logger) throws Exception {

		logger.log(LogStatus.INFO, "Add service codes!!");

		webUtils.moveToClickableElement(codeAreaList.get(2), driver);

		boolean isPresent = false;

		try {
			webUtils.explicitWaitByVisibilityofElement(driver, validDataPopUp);
			isPresent = validDataPopUp.isDisplayed();

		} catch (Exception E) {

		}

		if (isPresent) {

			close.click();

			webUtils.moveToClickableElement(codeAreaList.get(2), driver);
		} else {

			System.out.println("Popup is not displayed!!");
		}

		webUtils.explicitWaitByElementToBeClickable(driver, searchPicker.get(2));

		searchPicker.get(2).click();

		description.sendKeys(serviceDesc);

		search.click();

		webUtils.explicitWaitByElementToBeClickable(driver, codeSelect);

		codeSelect.click();

		webUtils.doubleClick(driver, codeSelect);

	}

	public void inPatientDays(String fromDate, String toDate, String bedType,
			String revCode, String drgCode, WebDriver driver, ExtentTest logger)
			throws Exception {

		// webUtils.explicitWaitByVisibilityofElement(driver,
		// codeAreaList.get(4));

		// webUtils.scrollDown(driver, codeAreaList.get(4));

		webUtils.moveToClickableElement(codeAreaList.get(4), driver);

		webUtils.explicitWaitByVisibilityofElement(driver, fromdate);

		fromdate.sendKeys(fromDate);

		Thread.sleep(5000);

		webUtils.moveToClickableElement(codeAreaList1, driver);

		// webUtils.explicitWaitByVisibilityofElement(driver, thru);

		thru.sendKeys(toDate);
		Thread.sleep(5000);

		webUtils.moveToClickableElement(codeAreaList2, driver);

		webUtils.explicitWaitByVisibilityofElement(driver, dropdown);

		dropdown.click();

		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");

		webUtils.clickButtonOrLink(commondropdownList, bedType, logger, driver);

		Thread.sleep(5000);

		webUtils.moveToClickableElement(codeAreaList3, driver);

		webUtils.explicitWaitByVisibilityofElement(driver, dropdown);

		dropdown.click();

		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");

		webUtils.clickButtonOrLink(commondropdownList, revCode, logger, driver);

		Thread.sleep(5000);

		webUtils.moveToClickableElement(codeAreaList4, driver);

		webUtils.explicitWaitByVisibilityofElement(driver, dropdown);

		dropdown.click();

		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//div[contains(@class,'pickListMenuBody')]/div/table/tbody/tr");

		webUtils.clickButtonOrLink(commondropdownList, drgCode, logger, driver);

	}

	public void inPatient(String admissiondate, String requestTypeName,
			String admitType, String admitFrom, WebDriver driver,
			ExtentTest logger) throws Exception {

		logger.log(LogStatus.INFO, "Provide admission date!!");

		webUtils.moveToClickableElement(admissionDate, driver);

		admissionDate.sendKeys(admissiondate);

		logger.log(LogStatus.INFO, "Select the admit Type!!");

		Thread.sleep(5000);

		webUtils.moveToClickableElement(admitTypeDropdown, driver);

		webUtils.clickButtonOrLink(commondropdownList, admitType, logger,
				driver);
		/*
		 * Robot robot = new Robot();
		 * 
		 * robot.keyPress(KeyEvent.VK_TAB);
		 * 
		 * robot.keyRelease(KeyEvent.VK_TAB);
		 * 
		 * robot.keyPress(KeyEvent.VK_TAB);
		 * 
		 * robot.keyRelease(KeyEvent.VK_TAB);
		 * 
		 * robot.keyPress(KeyEvent.VK_DOWN); robot.keyRelease(KeyEvent.VK_DOWN);
		 * 
		 * robot.keyPress(KeyEvent.VK_DOWN);
		 * 
		 * robot.keyRelease(KeyEvent.VK_DOWN);
		 */

		logger.log(LogStatus.INFO, "Select the admit from!!");

		webUtils.moveToClickableElement(admitFromDropdown, driver);

		webUtils.clickButtonOrLink(commondropdownList, admitFrom, logger,
				driver);

		/*
		 * logger.log(LogStatus.INFO, "Provide the discharge date");
		 * 
		 * webUtils.moveToClickableElement(dischargeDate, driver);
		 * 
		 * // dischargeDate.sendKeys(dischargedate);
		 */
	}

	public void requestingProvider(String organisation, WebDriver driver,
			String requester, String serviceType, ExtentTest logger)
			throws Exception {

		logger.log(LogStatus.INFO, "Select the requester!!!");

		webUtils.moveToClickableElement(requesterTypeDropdown, driver);

		webUtils.clickButtonOrLink(commondropdownList, requester, logger,
				driver);

		/*
		 * if (serviceType.equalsIgnoreCase("Inpatient") ||
		 * serviceType.equalsIgnoreCase("Inpatient Post Review")) {
		 * 
		 * webUtils.moveToClickableElement(dropDownList.get(12), driver);
		 * 
		 * webUtils.clickButtonOrLink(commondropdownList, requester, logger,
		 * driver); }
		 * 
		 * else if (serviceType.equalsIgnoreCase("Medication") ||
		 * serviceType.equalsIgnoreCase("Service Post Review") ||
		 * serviceType.equalsIgnoreCase("Service Request (Prior Auth)")) {
		 * webUtils.moveToClickableElement(dropDownList.get(11), driver);
		 * 
		 * webUtils.clickButtonOrLink(commondropdownList, requester, logger,
		 * driver); }
		 */

		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//td[@class='formCell']/following::img[contains(@src,'search_picker')]");

		logger.log(LogStatus.INFO, "Select the provider!!!");

		webUtils.moveToClickableElement(searchPicker.get(0), driver);

		organization.sendKeys(organisation);

		webUtils.clickButtonOrLink(buttonList, "Extended Search", logger,
				driver);

		Thread.sleep(5000);

		providerSearch.click();

		webUtils.doubleClick(driver, providerSearch);

		webUtils.explicitWaitByElementToBeClickable(driver, fax);

		// webUtils.explicitWait(driver, fax);

		webUtils.moveToClickableElement(fax, driver);

		fax.sendKeys("1000000000");

	}

	public void servicingProviderSame(String servicingProviderSame,
			WebDriver driver, ExtentTest logger) throws Exception {

		logger.log(LogStatus.INFO,
				"Select the answer for servicing provider same!!");
		if (servicingProviderSame.equalsIgnoreCase("No")) {

			servicingProvider(driver, "adventis", "Extended Search", logger);
		} else {

			webUtils.moveToClickableElement(radioButtonList.get(0), driver);

			Thread.sleep(5000);
		}

	}

	public void servicingProvider(WebDriver driver, String organisation,
			String searchType, ExtentTest logger) throws Exception {

		logger.log(LogStatus.INFO, "Select the servicing provider!!");

		webUtils.moveToClickableElement(radioButtonList.get(1), driver);

		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//td[@class='formCell']/following::img[contains(@src,'search_picker')]");

		webUtils.moveToClickableElement(searchPicker.get(1), driver);

		organization.sendKeys(organisation);

		webUtils.clickButtonOrLink(buttonList, searchType, logger, driver);

		// webUtils.explicitWait(driver, providerSearch);

		Thread.sleep(5000);

		providerSearch.click();

		webUtils.doubleClick(driver, providerSearch);

		Thread.sleep(5000);

		// webUtils.explicitWait(driver, fax);

		webUtils.moveToClickableElement(servicingFax, driver);

		servicingFax.sendKeys("1000000000");

	}

	public void facilityProvider(WebDriver driver, String organisation,
			ExtentTest logger) throws Exception {

		logger.log(LogStatus.INFO, "Select the facility provider!!");
		webUtils.moveToClickableElement(facility, driver);

		webUtils.explicitWaitByPresenceofAllElements(driver,
				"//td[@class='formCell']/following::img[contains(@src,'search_picker')]");

		webUtils.moveToClickableElement(searchPicker.get(2), driver);

		organization.sendKeys(organisation);

		webUtils.clickButtonOrLink(buttonList, "Extended Search", logger,
				driver);

		Thread.sleep(5000);

		providerSearch.click();

		webUtils.doubleClick(driver, providerSearch);

		boolean isPresent = false;

		try {
			webUtils.explicitWaitByVisibilityofElement(driver, outOfService);
			isPresent = outOfService.isDisplayed();

		} catch (Exception E) {

		}

		if (isPresent) {

			close.click();

		} else {

			System.out.println("Popup is not displayed!!");
		}

		webUtils.explicitWaitByElementToBeClickable(driver, facilityFax);

		// webUtils.explicitWait(driver, fax);

		webUtils.moveToClickableElement(facilityFax, driver);

		facilityFax.sendKeys("1000000000");

	}

	public void reviewIntake(WebDriver driver, String reviewType,
			String priority, String admissionBedType, String serviceType,
			String serviceCategory, String subCategory, ExtentTest logger)
			throws Exception {

		if (serviceType.equalsIgnoreCase("Inpatient")
				|| serviceType.equalsIgnoreCase("Inpatient Post Review")) {
			webUtils.moveToClickableElement(reviewTypeDropdown, driver);

			logger.log(LogStatus.INFO, "Select the review type!!");

			webUtils.clickButtonOrLink(commondropdownList, reviewType, logger,
					driver);

			logger.log(LogStatus.INFO, "Select the priority!!");

			webUtils.moveToClickableElement(PriorityDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, priority, logger,
					driver);
			logger.log(LogStatus.INFO, "Select the admission bed type!!");

			if (serviceType.equalsIgnoreCase("Inpatient")) {
				webUtils.moveToClickableElement(admissionBedTypeDropdown,
						driver);

				webUtils.clickButtonOrLink(commondropdownList,
						admissionBedType, logger, driver);
			}
		} else if (serviceType.equalsIgnoreCase("Medication")
				|| serviceType.equalsIgnoreCase("Service Post Review")
				|| serviceType.equalsIgnoreCase("Service Request (Prior Auth)")) {

			logger.log(LogStatus.INFO, "Select the review type!!");

			webUtils.moveToClickableElement(reviewTypeDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, reviewType, logger,
					driver);

			logger.log(LogStatus.INFO, "Select the priority!!");

			webUtils.moveToClickableElement(PriorityDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, priority, logger,
					driver);

			logger.log(LogStatus.INFO, "Select the serviceCategory!!");

			webUtils.moveToClickableElement(serviceCategoryDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, serviceCategory,
					logger, driver);

			/*
			 * logger.log(LogStatus.INFO, "Select the subCategory!!");
			 * 
			 * webUtils.moveToClickableElement(subCategoryDropdown, driver);
			 * 
			 * webUtils.clickButtonOrLink(commondropdownList, subCategory,
			 * logger, driver);
			 */

		}

	}

	public void inquiryOutcome(WebDriver driver, String inquiryOutcome,
			String outcomeReason, String buttonType, String serviceType,
			ExtentTest logger) throws Exception {
		if (serviceType.equalsIgnoreCase("Inpatient")
				|| serviceType.equalsIgnoreCase("Inpatient Post Review")) {

			logger.log(LogStatus.INFO, "Select the inquiry outcome!!");

			webUtils.moveToClickableElement(inquiryOutcomeDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, inquiryOutcome,
					logger, driver);

			logger.log(LogStatus.INFO, "Select the outcomeReason!!");

			webUtils.moveToClickableElement(outcomeReasonDropdown, driver);

			webUtils.clickButtonOrLink(commondropdownList, outcomeReason,
					logger, driver);

			webUtils.moveToClickableElement(submitButton, driver);

			Thread.sleep(5000);
		} else if (serviceType.equalsIgnoreCase("Medication")
				|| serviceType.equalsIgnoreCase("Service Post Review")
				|| serviceType.equalsIgnoreCase("Service Request (Prior Auth)")) {
			webUtils.moveToClickableElement(inquiryOutcomeDropdown, driver);

			logger.log(LogStatus.INFO, "Select the inquiry outcome!!");

			webUtils.clickButtonOrLink(commondropdownList, inquiryOutcome,
					logger, driver);

			webUtils.moveToClickableElement(outcomeReasonDropdown, driver);

			logger.log(LogStatus.INFO, "Select the outcomeReason!!");

			webUtils.clickButtonOrLink(commondropdownList, outcomeReason,
					logger, driver);

			webUtils.moveToClickableElement(submitButton, driver);

			Thread.sleep(5000);
		}

	}

	public void assignToNurseReview(String reason, WebDriver driver,
			String rowNum, ExtentTest logger, String testCaseName)
			throws Exception {

		// webUtils.explicitWait(driver, "//div[@class='staticTextItem']");

		logger.log(LogStatus.INFO, "Assign the case to Nurse review!!");

		webUtils.explicitWaitByElementToBeClickable(driver, hsplit);

		hsplit.click();

		Wait<WebDriver> Wait = new FluentWait<WebDriver>(driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);

		WebElement referenceNumber = Wait
				.until(new Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver driver) {
						return driver.findElement(By
								.xpath("//div[contains(@eventproxy,'isc_DynamicForm_')]/form/table/tbody/tr[2]/td/nobr[contains(text(),'Reference #')]/following::td/div"));
					}
				});
		String referenceNo = referenceNumber.getText();

		logger.log(LogStatus.INFO, "The reference number is " + referenceNo);

		System.out.println("The reference no is " + referenceNo);

		webUtils.moveToClickableElement(statusReasonDropdown, driver);

		Wait<WebDriver> stubbornWait = new FluentWait<WebDriver>(driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);

		WebElement foo = stubbornWait
				.until(new Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver driver) {
						return driver.findElement(By
								.xpath("//div[contains(@id,'isc_PickListMenu_0_body$28s')]/following::table/tbody/tr[1]/td/div/nobr[text()='Nurse Review']"));
					}
				});
		// Thread.sleep(5000);

		webUtils.clickButtonOrLink(dropdownNames, reason, logger, driver);

		ExcelUtilities.setCellData("testingSheetName", Integer.valueOf(rowNum),
				9, referenceNo);

		webUtils.takeSnapShot(driver, "test-output/BSC-reports/screenshots/"
				+ testCaseName.trim() + ".png");

		submit.click();

		Thread.sleep(10000);

	}
}
