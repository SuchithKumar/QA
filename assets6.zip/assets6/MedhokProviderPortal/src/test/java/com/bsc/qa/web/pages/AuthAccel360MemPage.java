package com.bsc.qa.web.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import WebUtils.WebUtils;

public class AuthAccel360MemPage extends BasePage {

	WebUtils webUtils = new WebUtils();

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='toolbarButton']") })
	
	List<WebElement> serviceType;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='sectionHeaderclosed']/div/div") })
	
	List<WebElement> authorizationTypes;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_PagingListGrid_')]/div/table/tbody/tr[1]/td[2]/div/nobr[text()='Inpatient']/ancestor::tr") })
	
	WebElement listTable;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//table[contains(@id,'table')]/tbody/tr") })
	List<WebElement> faxlistTable;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_ContextMenu_1_0_body$28s')]/following::tr") })
	
	List<WebElement> contextMenu;
	
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//td[(text()='No items to show.')]") })
	
	WebElement noItems;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'opener_opened')]") })
	
	WebElement opener;
	
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_ContextMenu')]/following::table/tbody/tr[3]") })
	WebElement Add;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_ContextMenu_')]/following::table/tbody/tr[10]") })
	WebElement sendToIntake;

	@FindAll({ @FindBy(how = How.XPATH, using = "//table[@class='selectItemControl']/tbody/tr/td/div") })
	List<WebElement> dropDownList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@id='isc_PickListMenu_0_body$28s']/following::table[@class='listTable']/tbody/tr[15]/td/div") })
	WebElement option;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@id='isc_PickListMenu_0_body$28s']/following::table[@class='listTable']/tbody/tr") })
	List<WebElement> queue;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@id='isc_PickListMenu_0_body$28s']/following::table[@class='listTable']/tbody/tr[6]/td/div") })
	WebElement pharmacyRXIntake;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='file']") })
	WebElement choseFiles;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[contains(text(),'Upload')]") })
	WebElement upload;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@class='windowBody']/div/div/div/following::div/div/table/tbody/tr/td/div/div[contains(text(),'Save')]") })
	List<WebElement> saveButton;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@id,'isc_PagingListGrid')]/following::table/tbody/tr[1]/td[6]/div/nobr[text()='View']/preceding::td[5]/parent::tr") })
	WebElement selectDocument;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'EnhancedMemberProfile_headerLabelParent')]//following::div[contains(@eventproxy,'EnhancedMemberProfile_closeButton')]/img[contains(@src,'close.gif')]") })
	WebElement close;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span[@role='button']/img[contains(@src,'help')]") })
	WebElement questionaire;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='OK']") })
	WebElement ok;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'DERMainForm0')]/form/table/tbody/tr[17]/td[2]/table") })
	WebElement statusDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[@role='listitem']/td[1]/div/nobr[text()='Denied']") })
	WebElement denied;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'DERMainForm0')]/form/table/tbody/tr[17]/td[4]/table") })
	WebElement statusReasonDropdown;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[@class='pickListMenuBody']/div/table/tbody/tr") })
	List<WebElement> statusReasonList;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[21]/td[3]/table/tbody/tr/td[1]/textarea") })
	WebElement denialText;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='pharmacistDecision_id']/following::td[1]/label[text()='Agree']") })
	WebElement agree;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='button']/div/div[text()='Submit']") })
	WebElement submit;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_globalWarn_closeButton')]/img") })
	WebElement closeQuestionaire;

	@FindAll({ @FindBy(how = How.XPATH, using = "//td[@class='formCellDisabled']/div[@style='min-width:146px;white-space:normal;']") })
	WebElement rxCaseNo;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_ContextMenu_')]/div/div/table/tbody/tr[2]") })
	WebElement editRXPreAuth;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_DERWorkSpace_')]/div[contains(@eventproxy,'isc_MemberClientInterface_')]") })
	WebElement blueArea;

	@FindAll({ @FindBy(how = How.XPATH, using = "//span/input[@name='name']") })
	WebElement textBox;

	@FindAll({ @FindBy(how = How.XPATH, using = "//img[contains(@src,'preview')]") })
	WebElement preview;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_CorrespondanceGrid_')]/div/table/tbody/tr[1]/td[2]/div/nobr[contains(text(),'PRx MediCal')]") })
	WebElement denialLetter;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_Toolbar_')]/div[2]/table/tbody/tr/td/div/div[text()='Request Type']") })
	WebElement requestType;

	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_Toolbar_')]/div[1]/table/tbody/tr/td/div/div[text()='Name']") })
	WebElement Name;
	@FindAll({ @FindBy(how = How.XPATH, using = "//div[contains(@eventproxy,'isc_Toolbar_')]/div[1]/table/tbody/tr/td/div/div[text()='Name']") })
	WebElement fileUpload;

	@FindAll({ @FindBy(how = How.XPATH, using = "//tr[21]/td[@class='formTitle']") })
	WebElement letterTemplate;

	@FindAll({ @FindBy(how = How.XPATH, using = "//input[@name='drugQuantity']") })
	WebElement drugQuantity;
	

	public void initiatePreAuthorization(String buttonName, String authType,
			WebDriver driver,ExtentTest logger) throws InterruptedException {
		
		logger.log(LogStatus.INFO, "Initiating Prior Authorization!!");
		
		webUtils.explicitWaitByPresenceofElement(driver, "//td[@class='toolbarButton']");
		
		logger.log(LogStatus.INFO, "Click on Authorization!!");
		
		webUtils.clickButtonOrLink(serviceType, buttonName,logger,driver);
		
		logger.log(LogStatus.INFO, "Click on Authorization type!!");
		for (WebElement authorizationType : authorizationTypes) {

			System.out.println("The authorization types are !!!"
					+ authorizationType.getText());

			if (authorizationType.getText().equalsIgnoreCase(authType)) {

				authorizationType.click();

				break;
			}

		}

		

	}

	public void createPreAuthorization(String menuName, WebDriver driver,ExtentTest logger)
			throws Exception {
		
		logger.log(LogStatus.INFO, "Create Pre Authorization request!!");
		boolean isPresent = false;
		webUtils.scrollDown(driver, opener);
		
		
		try{
			
			webUtils.explicitWaitByVisibilityofElement(driver, noItems);
		 isPresent = noItems.isDisplayed();
		}catch(Exception E){
			System.out.println("The exception is "+E);
		}
		
		
			
		if(isPresent){
			
			webUtils.rightClick(driver, noItems);
			
			webUtils.clickButtonOrLink(contextMenu, menuName,logger,driver);
		}
		
		else{
			
			webUtils.explicitWaitByElementToBeClickable(driver, listTable);
			
			
			webUtils.rightClick(driver, listTable);
			
			webUtils.explicitWaitByVisibilityOfAllElements(driver, contextMenu);
			
			webUtils.clickButtonOrLink(contextMenu, menuName,logger,driver);
		}
	}
	
	/**
	 * Create Prior Authorization Request
	 * @param menuName
	 * @param doc
	 * @param driver
	 * @param logger
	 * @throws Exception
	 */
	public void createPreAuthorizationByFax(String menuName, String doc,
			WebDriver driver, ExtentTest logger) throws Exception {
		/*
		 * JavascriptExecutor js = (JavascriptExecutor) driver;
		 * 
		 * js.executeScript("arguments[0].scrollIntoView();", listTable.get(3));
		 */

		webUtils.explicitWaitByVisibilityofElement(driver, opener);
		
		Thread.sleep(5000);

		logger.log(LogStatus.INFO, "Rightclik and select Add");

		webUtils.rightClick(driver, faxlistTable.get(1));
		
		Thread.sleep(5000);

		Add.click();

		logger.log(LogStatus.INFO, "Click on drop down and select the option!!");

		dropDownList.get(1).click();

		option.click();
		logger.log(LogStatus.INFO, "Chose file to upload!!");
		
		String homeDirectory = System.getProperty("user.dir");
		
		System.out.println("the homedirectory is "+homeDirectory);

		choseFiles.sendKeys(homeDirectory+doc);

		/*
		 * Thread.sleep(3000);
		 * 
		 * ((JavascriptExecutor) driver).executeScript("alert('Focus window')");
		 * driver.switchTo().alert().accept();
		 * 
		 * Thread.sleep(3000);
		 * 
		 * webUtils.uploadFileWithRobot(doc);
		 */
		Thread.sleep(5000);

		upload.click();

		Thread.sleep(3000);

		webUtils.scrollDown(driver, Name);

		webUtils.explicitwaitByinvisibilityOfElementLocated(driver,
				"//img[contains(@src,'loadingSmall')]");

		Thread.sleep(3000);

		webUtils.waitUntilElementclickable(selectDocument,driver);
		// driver.manage().timeouts().setScriptTimeout(5, TimeUnit.SECONDS);
		// webUtils.explicitWaitByVisibilityofElement(driver, selectDocument);
		// webUtils.WaitForAjax(driver);
		// selectDocument.click();

		logger.log(LogStatus.INFO,
				"Right click and select sendtointake option!!");

		webUtils.rightClick(driver, selectDocument);

		webUtils.explicitWaitByVisibilityofElement(driver, sendToIntake);

		webUtils.moveToClickableElement(sendToIntake, driver);

		// sendToIntake.click();

		logger.log(LogStatus.INFO,
				"Click on dropdown and select PromiseRxIntake!!");

		webUtils.explicitWaitByVisibilityofElement(driver, dropDownList.get(2));

		dropDownList.get(2).click();
		
		webUtils.clickButtonOrLink(queue, "Promise UM IN Inpatient", logger, driver);

		//promiseRXIntake.click();

		logger.log(LogStatus.INFO, "Click on save button!!");

		saveButton.get(0).click();

		Thread.sleep(5000);

		// webUtils.scrollUp(driver);

		webUtils.moveToClickableElement(close, driver);

		// close.click();

		/*
		 * webUtils.explicitWait(driver,
		 * "//div[contains(@id,'isc_ContextMenu_1_0_body$28s')]/following::tr");
		 */

		/*
		 * webUtils.clickButtonOrLink(contextMenu, menuName);
		 * 
		 * Thread.sleep(10000);
		 */
	}
	
		

	}


