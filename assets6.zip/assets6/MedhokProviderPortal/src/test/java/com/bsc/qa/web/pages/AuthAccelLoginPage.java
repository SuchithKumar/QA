package com.bsc.qa.web.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.bsc.bqsa.AutomationStringUtilities;
import com.bsc.qa.framework.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class AuthAccelLoginPage extends BasePage {

	@FindAll({ @FindBy(how = How.ID_OR_NAME, using = "username"), })
	@CacheLookup
	WebElement userName;

	@FindAll({ @FindBy(how = How.NAME, using = "j_password") })
	@CacheLookup
	WebElement passwordTextbox;

	@FindAll({ @FindBy(how = How.ID_OR_NAME, using = "_eventId_proceed") })
	@CacheLookup
	WebElement loginButton;

	@FindAll({ @FindBy(how = How.ID_OR_NAME, using = "donotcache") })
	@CacheLookup
	WebElement dontRemember;
	@FindAll({ @FindBy(how = How.ID_OR_NAME, using = "_shib_idp_revokeConsent") })
	@CacheLookup
	WebElement clearGranting;

	public void applicationLogin(String username, String passWord,ExtentTest logger)
			throws InterruptedException {
		logger.log(LogStatus.INFO, "Log into application");
		logger.log(LogStatus.INFO, "Enter username!!");
		userName.sendKeys(username);
		logger.log(LogStatus.INFO,"Enter password!!");
		String Password = AutomationStringUtilities.decryptValue(passWord);
		passwordTextbox.sendKeys(Password);
		logger.log(LogStatus.INFO, "click on login button!!");
		loginButton.click();

	}

}
