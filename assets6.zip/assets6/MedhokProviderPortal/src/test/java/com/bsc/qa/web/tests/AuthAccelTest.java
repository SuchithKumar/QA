/**
 * @author hkhera01
 * @category testcase
 * @class UnAuthenicatedPageLinksTest
 * @Uses PageObject CitrixLandingPage , MemberWhyBlueShieldPage, memberFindAPlanPage
 * @since 3/24/2017
 * 
 */
package com.bsc.qa.web.tests;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import WebUtils.ExcelUtilities;

import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.factory.BrowserFactoryManager;
import com.bsc.qa.web.pages.AuthAccelHomePage;
import com.bsc.qa.web.pages.AuthAccelLoginPage;
import com.bsc.qa.web.pages.AuthAccelMemberPage;
import com.bsc.qa.web.pages.AuthAccel360MemPage;
import com.bsc.qa.web.pages.AuthAccelPriorAuthPage;
import com.relevantcodes.extentreports.LogStatus;

public class AuthAccelTest extends BaseTest implements IHookable {

	private static String environment;
	private static String DataSheet;
	private AuthAccelLoginPage authAccelLoginPage;

	private AuthAccelHomePage authAccelHomePage;
	private AuthAccel360MemPage authAccel360MemPage;
	private AuthAccelMemberPage authAccelMemberPage;
	private AuthAccelPriorAuthPage authAccelPriorAuthPage;

	HashMap<String, String> dataMap = new HashMap<String, String>();

	@DataProvider(name = "UMTestCases")
	private static Object[][] getData(Method method) {

		int rowNum = 1;
		Object[][] columnArray = ExcelUtilities.getColumnArray(
				DataSheet, environment);
		Object[][] testDataArray = ExcelUtilities.getTableArray(
				DataSheet, environment);
		List<Object> list = new ArrayList<Object>();
		for (int i = 0; i < columnArray[0].length; i++) {

		}

		int noOfTestCases = 0;
		String runMode = "Yes";
		for (int row = 0; row <= testDataArray.length - 1; row++) {

			if (method.getName().equalsIgnoreCase(
					testDataArray[row][1].toString())
					&& runMode.equalsIgnoreCase(testDataArray[row][2]
							.toString())) {
				noOfTestCases++;

				System.out.println("TestCase Name Form Data Sheet:::"
						+ testDataArray[row][1].toString());
				Map<String, String> rowDataMap = new HashMap<String, String>();
				for (int col = 0; col <= columnArray[0].length - 1; col++) {

					rowDataMap.put(columnArray[0][col].toString(),
							testDataArray[row][col].toString());
					rowDataMap.put("rowNum", String.valueOf(rowNum));

					rowNum++;
				}
				list.add(rowDataMap);

			} else {
				rowNum++;
			}

		}

		Object[][] data = new Object[noOfTestCases][1];
		for (int row = 0; row < list.size(); row++) {
			data[row][0] = list.get(row);
		}

		return data;

	}

	/**
	 * setUp is a @BeforeMethod executed before execution of a @Test
	 * 
	 * @param browser_
	 * @param driver_
	 * @param env_
	 * @param url_
	 * @throws Exception
	 */
	@BeforeClass
	@Parameters({ "Browser_", "Driver_", "Env_", "URL_","Datasheet" })
	public void setUp(@Optional("browser") String browser_,
			@Optional("webDriver") String driver_,
			@Optional("Env_") String env_, @Optional("url") String url_,@Optional("Datasheet") String datasheet)
			throws Exception {
		// boolean error = false;
		browser = browser_;
		webDriver = driver_;
		environment = env_; // System.getenv("ENVNAME");
		System.out.print(environment);
		url = url_;
		DataSheet = datasheet;
		// ExcelUtilities.setUpExcel(DataSheet);
	}

	/**
	 * @Override run is a hook before @Test method
	 */
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		initBrowser(testResult.getTestName(), testResult.getMethod()
				.getMethodName());
		System.out.println("after InitBrowser Method");
		reportInit(testResult.getTestContext().getName(), browser,
				callBack.getParameters()[0].toString(), testResult.getMethod()
						.getMethodName());
		softAssert = new SoftAssert();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssert.assertAll();
		System.out.println("soft assert complete");
		try {
			ExcelUtilities
					.writeToWorkBook(DataSheet);
		} catch (Exception e) {
			
			e.printStackTrace();
		}

		try {
			ExcelUtilities.closefile();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

	/**
	 * Run when the test method runs
	 */
	protected void initBrowser(String testCaseName, String testMethodName) {
		WebDriver driver = BrowserFactoryManager.getDriver();

		authAccelLoginPage = PageFactory.initElements(driver,
				AuthAccelLoginPage.class);

		authAccelLoginPage.setPage(driver, browser, environment, testCaseName);

		authAccelHomePage = PageFactory.initElements(driver,
				AuthAccelHomePage.class);
		authAccelHomePage.setPage(driver, browser, environment, testCaseName);

		authAccelMemberPage = PageFactory.initElements(driver,
				AuthAccelMemberPage.class);
		authAccelMemberPage.setPage(driver, browser, environment, testCaseName);

		authAccel360MemPage = PageFactory.initElements(driver,
				AuthAccel360MemPage.class);

		authAccel360MemPage.setPage(driver, browser, environment, testCaseName);

		authAccelPriorAuthPage = PageFactory.initElements(driver,
				AuthAccelPriorAuthPage.class);

	}
	
	@Test(dataProvider = "UMTestCases")
	public void testFaxIntake(Map<String, String> data)
			throws Exception {
		
		WebDriver driver = BrowserFactoryManager.getDriver();

		Map<String, String> inputData;
		
		if (data.get("MemberSearch").equalsIgnoreCase("Yes")) {

			inputData = retrieveData("MemberSearch", data);

			authAccelLoginPage.applicationLogin(data.get("UserName"),
					data.get("Password"),logger);

			authAccelHomePage.selectRole(data.get("Select"), driver,logger);

			authAccelHomePage.search(data.get("Search"),logger,driver);

			authAccelMemberPage.searchMembers(inputData.get("Member Id"),
					inputData.get("Select Option"), driver,logger);

			authAccel360MemPage.initiatePreAuthorization(
					inputData.get("Type of Request"),
					inputData.get("Type of Communication"), driver,logger);

			authAccel360MemPage.createPreAuthorizationByFax("Add",inputData.get("Document"), driver,logger);

		}

		
		
	}
	

	/**
	 * Test verify the links on Home Page
	 * 
	 * @throws InterruptedException
	 */
	@Test(dataProvider = "UMTestCases")
	public void priorAuthorizationForInpatient(Map<String, String> data)
			throws Exception {
		try{
		WebDriver driver = BrowserFactoryManager.getDriver();

		Map<String, String> inputData;

		if (data.get("MemberSearch").equalsIgnoreCase("Yes")) {

			inputData = retrieveData("MemberSearch", data);

			authAccelLoginPage.applicationLogin(data.get("UserName"),
					data.get("Password"),logger);

			authAccelHomePage.selectRole(data.get("Select"), driver,logger);

			authAccelHomePage.search(data.get("Search"),logger,driver);

			authAccelMemberPage.searchMembers(inputData.get("Member Id"),
					inputData.get("Select Option"), driver,logger);

			authAccel360MemPage.initiatePreAuthorization(
					inputData.get("Type of Request"),
					inputData.get("Type of Authorization"), driver,logger);

			authAccel360MemPage.createPreAuthorization("Add", driver,logger);

		}

		if (data.get("PriorAuthRequestCreation").equalsIgnoreCase("Yes")) {

			inputData = retrieveData("PriorAuthRequestCreation", data);

			authAccelPriorAuthPage.eventIntake(inputData.get("Request Type"),
					inputData.get("Place of Service"), inputData.get("Source"),
					inputData.get("Manual Received Date")
					, driver,logger);

			authAccelPriorAuthPage.addDiagnosisCodes(driver,
					inputData.get("Diagnosis Description"),logger);

			authAccelPriorAuthPage.addServiceCodes(
					inputData.get("Service Description"), driver,logger);

			 authAccelPriorAuthPage.inPatientDays("07/12/2018", "07/14/2018",
			 inputData.get("BedType"), "171", "100",driver,logger);
			 
			authAccelPriorAuthPage.inPatient(inputData.get("Admission Date"),inputData.get("Request Type"),
					inputData.get("Admit Type"), inputData.get("Admit From")
					, driver,logger);

			authAccelPriorAuthPage.requestingProvider(
					inputData.get("Provider Organization")
					, driver,
					inputData.get("Requester"), inputData.get("Request Type"),logger);

			authAccelPriorAuthPage.servicingProviderSame(
					inputData.get("Servicing Provider Same"), driver,logger);

			authAccelPriorAuthPage.facilityProvider(driver,
					inputData.get("Facility Provider Organization"),
					logger);

			authAccelPriorAuthPage.reviewIntake(driver,
					inputData.get("Review Type"), inputData.get("Priority"),
					inputData.get("Admission Bed Type"),
					inputData.get("Request Type"),
					inputData.get("Service Category"),
					inputData.get("Sub Category"),logger);

			authAccelPriorAuthPage.inquiryOutcome(driver,
					inputData.get("Inquiry Outcome"),
					inputData.get("Outcome Reason"), "Submit",
					inputData.get("Request Type"),logger);

			authAccelPriorAuthPage.assignToNurseReview(
					inputData.get("Status Reason"), driver,
					inputData.get("rowNum"),logger,inputData.get("TestCaseName"));

		}
		}
		catch(Exception E){
			
			logger.log(LogStatus.FAIL, E);
		}

	}

	private Map<String, String> retrieveData(String sheetName,
			Map<String, String> data) {
		Map<String, String> rowDataMap = new HashMap<String, String>();
		Object[][] columnArray = ExcelUtilities.getColumnArray(
				DataSheet, sheetName);
		Object[][] testDataArray = ExcelUtilities.getTableArray(
				DataSheet, sheetName);
		String runMode = "Yes";
		for (int row = 0; row <= testDataArray.length - 1; row++) {

			if (runMode.equalsIgnoreCase(testDataArray[row][2].toString())&& data.get("TestCaseName").equalsIgnoreCase(
					testDataArray[row][0].toString())) {

				System.out.println("TestCase Name Form Data Sheet:::"
						+ testDataArray[row][1].toString());

				for (int col = 0; col <= columnArray[0].length - 1; col++) {

					System.out.println("The key:: "
							+ columnArray[0][col].toString() + " value:: "
							+ (String) testDataArray[row][col]);
					if (data.get("TestMethod").equals(testDataArray[row][1])) {
						rowDataMap.put(columnArray[0][col].toString(),
								(String) testDataArray[row][col]);
						rowDataMap.put("rowNum", String.valueOf(row + 1));

					}
				}

			} else {

			}

		}
		return rowDataMap;

	}

	@Test(dataProvider = "UMTestCases")
	public void priorAuthorizationForMedication(Map<String, String> data)
			throws Exception {
		System.out.println("In test Method");

		WebDriver driver = BrowserFactoryManager.getDriver();
		Map<String, String> inputData;

		if (data.get("MemberSearch").equalsIgnoreCase("Yes")) {

			inputData = retrieveData("MemberSearch", data);

			authAccelLoginPage.applicationLogin(data.get("UserName"),
					data.get("Password"),logger);

			authAccelHomePage.selectRole(data.get("Select"), driver,logger);

			authAccelHomePage.search(data.get("Search"),logger,driver);

			authAccelMemberPage.searchMembers(inputData.get("Member Id"),
					inputData.get("Select Option"), driver,logger);

			authAccel360MemPage.initiatePreAuthorization(
					inputData.get("Type of Request"),
					inputData.get("Type of Authorization"), driver,logger);

			authAccel360MemPage.createPreAuthorization("Add", driver,logger);

		}

		if (data.get("PriorAuthRequestCreation").equalsIgnoreCase("Yes")) {

			inputData = retrieveData("PriorAuthRequestCreation", data);

			authAccelPriorAuthPage.eventIntake(inputData.get("Request Type"),
					inputData.get("Place of Service"), inputData.get("Source"),
					inputData.get("Manual Received Date")
					, driver,logger);

			authAccelPriorAuthPage.addDiagnosisCodes(driver,
					inputData.get("Diagnosis Description"),logger);

			authAccelPriorAuthPage.addServiceCodes(
					inputData.get("Service Description"), driver,logger);

			authAccelPriorAuthPage.requestingProvider(
					inputData.get("Provider Organization"),
					 driver,
					inputData.get("Requester"), inputData.get("Request Type"),logger);

			authAccelPriorAuthPage.servicingProviderSame(
					inputData.get("Servicing Provider Same"), driver,logger);

			authAccelPriorAuthPage.facilityProvider(driver,
					inputData.get("Facility Provider Organization"),
					logger);

			authAccelPriorAuthPage.reviewIntake(driver,
					inputData.get("Review Type"), inputData.get("Priority"),
					inputData.get("Admission Bed Type"),
					inputData.get("Request Type"),
					inputData.get("Service Category"),
					inputData.get("Sub Category"),logger);

			authAccelPriorAuthPage.inquiryOutcome(driver,
					inputData.get("Inquiry Outcome"),
					inputData.get("Outcome Reason"), "Submit",
					inputData.get("Request Type"),logger);

			authAccelPriorAuthPage.assignToNurseReview(
					inputData.get("Status Reason"), driver,
					inputData.get("rowNum"),logger,inputData.get("TestCaseName"));

		}

	}

}
